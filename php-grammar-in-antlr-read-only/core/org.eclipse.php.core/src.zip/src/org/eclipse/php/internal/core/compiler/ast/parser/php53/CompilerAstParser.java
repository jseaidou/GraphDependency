// $ANTLR 3.1.3 Mar 17, 2009 19:23:44 /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g 2009-07-19 20:49:02

  package org.eclipse.php.internal.core.compiler.ast.parser.php53;
  
 import org.antlr.runtime.*;
import org.eclipse.php.internal.core.compiler.ast.parser.AbstractASTParser;

public class CompilerAstParser extends AbstractASTParser {

	public CompilerAstParser(TokenStream input) {
		super(input);
		// TODO Auto-generated constructor stub
	}

//    public static final String[] tokenNames = new String[] {
//        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "ModuleDeclaration", "ClassDeclaration", "PROG", "CLASS_BODY", "FIELD_DECL", "METHOD_DECL", "TYPE", "PARAMETER", "BLOCK", "VAR_DECL", "STATEMENT", "CONDITION", "LIST", "INDEX", "MEMBERACCESS", "CALL", "ELIST", "EXPR", "ASSIGN", "LIST_DECL", "SCALAR_ELEMENT", "SCALAR_VAR", "CAST", "LABEL", "ITERATE", "USE_DECL", "ARGU", "CALLED_OBJ", "PREFIX", "POSTFIX", "NAMESPACE", "EMPTYSTATEMENT", "IDENTIFIER", "STRINGLITERAL", "BACKTRICKLITERAL", "STATIC", "INTLITERAL", "FLOATLITERAL", "DOUBLELITERRAL", "IntegerNumber", "LongSuffix", "HexPrefix", "HexDigit", "NonIntegerNumber", "FloatSuffix", "DoubleSuffix", "Exponent", "EscapeSequence", "IdentifierStart", "IdentifierPart", "WS", "COMMENT", "LINE_COMMENT", "'<?'", "'php'", "'?>'", "'__halt_compiler'", "'('", "')'", "';'", "'class'", "'extends'", "'implements'", "'{'", "'}'", "'interface'", "'abstract'", "'final'", "'function'", "'&'", "'while'", "'do'", "'for'", "'switch'", "'break'", "'continue'", "'return'", "'global'", "'static'", "'echo'", "'foreach'", "'as'", "'declare'", "'try'", "'throw'", "'use'", "'=>'", "'const'", "'::'", "','", "'='", "'if'", "'elseif'", "'else'", "':'", "'endif'", "'endswitch'", "'case'", "'default'", "'catch'", "'endfor'", "'endwhile'", "'endforeach'", "'enddeclare'", "'var'", "'public'", "'protected'", "'private'", "'OR'", "'XOR'", "'AND'", "'+='", "'-='", "'*='", "'/='", "'.='", "'%='", "'&='", "'|='", "'^='", "'<<='", "'>>='", "'?'", "'||'", "'&&'", "'|'", "'^'", "'.'", "'=='", "'!='", "'==='", "'!=='", "'<'", "'>'", "'<='", "'>='", "'<<'", "'>>'", "'+'", "'-'", "'*'", "'/'", "'%'", "'bool'", "'boolean'", "'int'", "'float'", "'double'", "'real'", "'string'", "'unset'", "'clone'", "'object'", "'array'", "'~'", "'!'", "'++'", "'--'", "'instanceof'", "'@'", "'list'", "'new'", "'exit'", "'->'", "'$'", "'['", "']'", "'__CLASS__'", "'__DIR__'", "'__FILE__'", "'__FUNCTION__'", "'__METHOD__'", "'__NAMESPACE__'"
//    };
//    public static final int CAST=26;
//    public static final int PREFIX=32;
//    public static final int POSTFIX=33;
//    public static final int T__159=159;
//    public static final int T__158=158;
//    public static final int T__160=160;
//    public static final int VAR_DECL=13;
//    public static final int CONDITION=15;
//    public static final int T__167=167;
//    public static final int T__168=168;
//    public static final int EOF=-1;
//    public static final int T__165=165;
//    public static final int T__166=166;
//    public static final int STATEMENT=14;
//    public static final int T__163=163;
//    public static final int T__164=164;
//    public static final int TYPE=10;
//    public static final int T__161=161;
//    public static final int T__162=162;
//    public static final int T__93=93;
//    public static final int T__94=94;
//    public static final int CALLED_OBJ=31;
//    public static final int T__91=91;
//    public static final int T__92=92;
//    public static final int T__148=148;
//    public static final int T__147=147;
//    public static final int T__90=90;
//    public static final int T__149=149;
//    public static final int ELIST=20;
//    public static final int FloatSuffix=48;
//    public static final int NonIntegerNumber=47;
//    public static final int PARAMETER=11;
//    public static final int ARGU=30;
//    public static final int COMMENT=55;
//    public static final int T__154=154;
//    public static final int T__155=155;
//    public static final int T__156=156;
//    public static final int T__157=157;
//    public static final int T__99=99;
//    public static final int T__150=150;
//    public static final int T__98=98;
//    public static final int T__151=151;
//    public static final int T__97=97;
//    public static final int T__152=152;
//    public static final int T__96=96;
//    public static final int HexPrefix=45;
//    public static final int T__153=153;
//    public static final int T__95=95;
//    public static final int T__139=139;
//    public static final int T__138=138;
//    public static final int T__137=137;
//    public static final int T__136=136;
//    public static final int T__80=80;
//    public static final int T__81=81;
//    public static final int T__82=82;
//    public static final int T__83=83;
//    public static final int LINE_COMMENT=56;
//    public static final int STATIC=39;
//    public static final int IdentifierStart=52;
//    public static final int INTLITERAL=40;
//    public static final int T__85=85;
//    public static final int T__141=141;
//    public static final int LIST=16;
//    public static final int T__84=84;
//    public static final int T__142=142;
//    public static final int T__87=87;
//    public static final int T__86=86;
//    public static final int T__140=140;
//    public static final int T__145=145;
//    public static final int T__89=89;
//    public static final int NAMESPACE=34;
//    public static final int T__146=146;
//    public static final int T__88=88;
//    public static final int T__143=143;
//    public static final int LongSuffix=44;
//    public static final int T__144=144;
//    public static final int T__126=126;
//    public static final int T__125=125;
//    public static final int T__128=128;
//    public static final int EMPTYSTATEMENT=35;
//    public static final int T__127=127;
//    public static final int WS=54;
//    public static final int T__71=71;
//    public static final int T__72=72;
//    public static final int T__129=129;
//    public static final int T__70=70;
//    public static final int MEMBERACCESS=18;
//    public static final int CALL=19;
//    public static final int SCALAR_ELEMENT=24;
//    public static final int T__76=76;
//    public static final int T__75=75;
//    public static final int T__74=74;
//    public static final int T__130=130;
//    public static final int EscapeSequence=51;
//    public static final int T__73=73;
//    public static final int T__131=131;
//    public static final int T__132=132;
//    public static final int T__79=79;
//    public static final int T__133=133;
//    public static final int T__78=78;
//    public static final int T__134=134;
//    public static final int T__77=77;
//    public static final int T__135=135;
//    public static final int T__68=68;
//    public static final int T__69=69;
//    public static final int T__66=66;
//    public static final int T__67=67;
//    public static final int T__64=64;
//    public static final int T__65=65;
//    public static final int T__62=62;
//    public static final int T__63=63;
//    public static final int IntegerNumber=43;
//    public static final int T__118=118;
//    public static final int T__119=119;
//    public static final int T__116=116;
//    public static final int T__117=117;
//    public static final int T__114=114;
//    public static final int DOUBLELITERRAL=42;
//    public static final int T__115=115;
//    public static final int T__124=124;
//    public static final int T__123=123;
//    public static final int Exponent=50;
//    public static final int METHOD_DECL=9;
//    public static final int T__122=122;
//    public static final int T__121=121;
//    public static final int T__120=120;
//    public static final int T__61=61;
//    public static final int T__60=60;
//    public static final int HexDigit=46;
//    public static final int INDEX=17;
//    public static final int T__57=57;
//    public static final int PROG=6;
//    public static final int T__58=58;
//    public static final int EXPR=21;
//    public static final int USE_DECL=29;
//    public static final int T__107=107;
//    public static final int T__108=108;
//    public static final int T__109=109;
//    public static final int IDENTIFIER=36;
//    public static final int T__59=59;
//    public static final int T__103=103;
//    public static final int T__104=104;
//    public static final int T__105=105;
//    public static final int T__106=106;
//    public static final int T__111=111;
//    public static final int T__110=110;
//    public static final int T__113=113;
//    public static final int T__112=112;
//    public static final int SCALAR_VAR=25;
//    public static final int IdentifierPart=53;
//    public static final int FIELD_DECL=8;
//    public static final int T__102=102;
//    public static final int T__101=101;
//    public static final int T__100=100;
//    public static final int CLASS_BODY=7;
//    public static final int LIST_DECL=23;
//    public static final int ModuleDeclaration=4;
//    public static final int BACKTRICKLITERAL=38;
//    public static final int T__175=175;
//    public static final int T__174=174;
//    public static final int ITERATE=28;
//    public static final int T__173=173;
//    public static final int T__172=172;
//    public static final int DoubleSuffix=49;
//    public static final int T__176=176;
//    public static final int LABEL=27;
//    public static final int STRINGLITERAL=37;
//    public static final int T__171=171;
//    public static final int BLOCK=12;
//    public static final int T__170=170;
//    public static final int ASSIGN=22;
//    public static final int FLOATLITERAL=41;
//    public static final int ClassDeclaration=5;
//    public static final int T__169=169;
//
//    // delegates
//    // delegators
//
//
//        public CompilerAstParser(TokenStream input) {
//            this(input, new RecognizerSharedState());
//        }
//        public CompilerAstParser(TokenStream input, RecognizerSharedState state) {
//            super(input, state);
//             
//        }
//        
//    protected TreeAdaptor adaptor = new CommonTreeAdaptor();
//
//    public void setTreeAdaptor(TreeAdaptor adaptor) {
//        this.adaptor = adaptor;
//    }
//    public TreeAdaptor getTreeAdaptor() {
//        return adaptor;
//    }
//
//    public String[] getTokenNames() { return CompilerAstParser.tokenNames; }
//    public String getGrammarFileName() { return "/home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g"; }
//
//
//    public static class php_source_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "php_source"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:77:1: php_source : '<?' ( 'php' )? ( top_statement_list )? '?>' -> ^( ModuleDeclaration ( top_statement_list )? ) ;
//    public final CompilerAstParser.php_source_return php_source() throws RecognitionException {
//        CompilerAstParser.php_source_return retval = new CompilerAstParser.php_source_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token string_literal1=null;
//        Token string_literal2=null;
//        Token string_literal4=null;
//        CompilerAstParser.top_statement_list_return top_statement_list3 = null;
//
//
//        CommonTree string_literal1_tree=null;
//        CommonTree string_literal2_tree=null;
//        CommonTree string_literal4_tree=null;
//        RewriteRuleTokenStream stream_59=new RewriteRuleTokenStream(adaptor,"token 59");
//        RewriteRuleTokenStream stream_58=new RewriteRuleTokenStream(adaptor,"token 58");
//        RewriteRuleTokenStream stream_57=new RewriteRuleTokenStream(adaptor,"token 57");
//        RewriteRuleSubtreeStream stream_top_statement_list=new RewriteRuleSubtreeStream(adaptor,"rule top_statement_list");
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:78:3: ( '<?' ( 'php' )? ( top_statement_list )? '?>' -> ^( ModuleDeclaration ( top_statement_list )? ) )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:78:5: '<?' ( 'php' )? ( top_statement_list )? '?>'
//            {
//            string_literal1=(Token)match(input,57,FOLLOW_57_in_php_source211); if (state.failed) return retval; 
//            if ( state.backtracking==0 ) stream_57.add(string_literal1);
//
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:78:10: ( 'php' )?
//            int alt1=2;
//            int LA1_0 = input.LA(1);
//
//            if ( (LA1_0==58) ) {
//                alt1=1;
//            }
//            switch (alt1) {
//                case 1 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:78:10: 'php'
//                    {
//                    string_literal2=(Token)match(input,58,FOLLOW_58_in_php_source213); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_58.add(string_literal2);
//
//
//                    }
//                    break;
//
//            }
//
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:78:17: ( top_statement_list )?
//            int alt2=2;
//            int LA2_0 = input.LA(1);
//
//            if ( ((LA2_0>=IDENTIFIER && LA2_0<=DOUBLELITERRAL)||(LA2_0>=60 && LA2_0<=61)||(LA2_0>=63 && LA2_0<=64)||LA2_0==67||(LA2_0>=69 && LA2_0<=84)||(LA2_0>=86 && LA2_0<=89)||LA2_0==95||(LA2_0>=142 && LA2_0<=143)||(LA2_0>=154 && LA2_0<=155)||(LA2_0>=157 && LA2_0<=161)||(LA2_0>=163 && LA2_0<=166)||LA2_0==168||(LA2_0>=171 && LA2_0<=176)) ) {
//                alt2=1;
//            }
//            switch (alt2) {
//                case 1 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:78:17: top_statement_list
//                    {
//                    pushFollow(FOLLOW_top_statement_list_in_php_source216);
//                    top_statement_list3=top_statement_list();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) stream_top_statement_list.add(top_statement_list3.getTree());
//
//                    }
//                    break;
//
//            }
//
//            string_literal4=(Token)match(input,59,FOLLOW_59_in_php_source219); if (state.failed) return retval; 
//            if ( state.backtracking==0 ) stream_59.add(string_literal4);
//
//
//
//            // AST REWRITE
//            // elements: top_statement_list
//            // token labels: 
//            // rule labels: retval
//            // token list labels: 
//            // rule list labels: 
//            // wildcard labels: 
//            if ( state.backtracking==0 ) {
//            retval.tree = root_0;
//            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//            root_0 = (CommonTree)adaptor.nil();
//            // 78:43: -> ^( ModuleDeclaration ( top_statement_list )? )
//            {
//                // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:78:46: ^( ModuleDeclaration ( top_statement_list )? )
//                {
//                CommonTree root_1 = (CommonTree)adaptor.nil();
//                root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(ModuleDeclaration, "ModuleDeclaration"), root_1);
//
//                // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:78:66: ( top_statement_list )?
//                if ( stream_top_statement_list.hasNext() ) {
//                    adaptor.addChild(root_1, stream_top_statement_list.nextTree());
//
//                }
//                stream_top_statement_list.reset();
//
//                adaptor.addChild(root_0, root_1);
//                }
//
//            }
//
//            retval.tree = root_0;}
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "php_source"
//
//    public static class top_statement_list_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "top_statement_list"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:81:1: top_statement_list : ( top_statement )+ ;
//    public final CompilerAstParser.top_statement_list_return top_statement_list() throws RecognitionException {
//        CompilerAstParser.top_statement_list_return retval = new CompilerAstParser.top_statement_list_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        CompilerAstParser.top_statement_return top_statement5 = null;
//
//
//
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:82:3: ( ( top_statement )+ )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:82:5: ( top_statement )+
//            {
//            root_0 = (CommonTree)adaptor.nil();
//
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:82:5: ( top_statement )+
//            int cnt3=0;
//            loop3:
//            do {
//                int alt3=2;
//                int LA3_0 = input.LA(1);
//
//                if ( ((LA3_0>=IDENTIFIER && LA3_0<=DOUBLELITERRAL)||(LA3_0>=60 && LA3_0<=61)||(LA3_0>=63 && LA3_0<=64)||LA3_0==67||(LA3_0>=69 && LA3_0<=84)||(LA3_0>=86 && LA3_0<=89)||LA3_0==95||(LA3_0>=142 && LA3_0<=143)||(LA3_0>=154 && LA3_0<=155)||(LA3_0>=157 && LA3_0<=161)||(LA3_0>=163 && LA3_0<=166)||LA3_0==168||(LA3_0>=171 && LA3_0<=176)) ) {
//                    alt3=1;
//                }
//
//
//                switch (alt3) {
//            	case 1 :
//            	    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:82:5: top_statement
//            	    {
//            	    pushFollow(FOLLOW_top_statement_in_top_statement_list242);
//            	    top_statement5=top_statement();
//
//            	    state._fsp--;
//            	    if (state.failed) return retval;
//            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, top_statement5.getTree());
//
//            	    }
//            	    break;
//
//            	default :
//            	    if ( cnt3 >= 1 ) break loop3;
//            	    if (state.backtracking>0) {state.failed=true; return retval;}
//                        EarlyExitException eee =
//                            new EarlyExitException(3, input);
//                        throw eee;
//                }
//                cnt3++;
//            } while (true);
//
//
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "top_statement_list"
//
//    public static class top_statement_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "top_statement"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:85:1: top_statement : ( statement | function_declaration_statement | class_declaration_statement | halt_compiler_statement );
//    public final CompilerAstParser.top_statement_return top_statement() throws RecognitionException {
//        CompilerAstParser.top_statement_return retval = new CompilerAstParser.top_statement_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        CompilerAstParser.statement_return statement6 = null;
//
//        CompilerAstParser.function_declaration_statement_return function_declaration_statement7 = null;
//
//        CompilerAstParser.class_declaration_statement_return class_declaration_statement8 = null;
//
//        CompilerAstParser.halt_compiler_statement_return halt_compiler_statement9 = null;
//
//
//
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:86:3: ( statement | function_declaration_statement | class_declaration_statement | halt_compiler_statement )
//            int alt4=4;
//            switch ( input.LA(1) ) {
//            case IDENTIFIER:
//            case STRINGLITERAL:
//            case BACKTRICKLITERAL:
//            case STATIC:
//            case INTLITERAL:
//            case FLOATLITERAL:
//            case DOUBLELITERRAL:
//            case 61:
//            case 63:
//            case 67:
//            case 73:
//            case 74:
//            case 75:
//            case 76:
//            case 77:
//            case 78:
//            case 79:
//            case 80:
//            case 81:
//            case 82:
//            case 83:
//            case 84:
//            case 86:
//            case 87:
//            case 88:
//            case 89:
//            case 95:
//            case 142:
//            case 143:
//            case 154:
//            case 155:
//            case 157:
//            case 158:
//            case 159:
//            case 160:
//            case 161:
//            case 163:
//            case 164:
//            case 165:
//            case 166:
//            case 168:
//            case 171:
//            case 172:
//            case 173:
//            case 174:
//            case 175:
//            case 176:
//                {
//                alt4=1;
//                }
//                break;
//            case 72:
//                {
//                switch ( input.LA(2) ) {
//                case 73:
//                    {
//                    int LA4_5 = input.LA(3);
//
//                    if ( (LA4_5==IDENTIFIER) ) {
//                        alt4=2;
//                    }
//                    else if ( (LA4_5==61) ) {
//                        alt4=1;
//                    }
//                    else {
//                        if (state.backtracking>0) {state.failed=true; return retval;}
//                        NoViableAltException nvae =
//                            new NoViableAltException("", 4, 5, input);
//
//                        throw nvae;
//                    }
//                    }
//                    break;
//                case IDENTIFIER:
//                    {
//                    alt4=2;
//                    }
//                    break;
//                case 61:
//                    {
//                    alt4=1;
//                    }
//                    break;
//                default:
//                    if (state.backtracking>0) {state.failed=true; return retval;}
//                    NoViableAltException nvae =
//                        new NoViableAltException("", 4, 2, input);
//
//                    throw nvae;
//                }
//
//                }
//                break;
//            case 64:
//            case 69:
//            case 70:
//            case 71:
//                {
//                alt4=3;
//                }
//                break;
//            case 60:
//                {
//                alt4=4;
//                }
//                break;
//            default:
//                if (state.backtracking>0) {state.failed=true; return retval;}
//                NoViableAltException nvae =
//                    new NoViableAltException("", 4, 0, input);
//
//                throw nvae;
//            }
//
//            switch (alt4) {
//                case 1 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:86:5: statement
//                    {
//                    root_0 = (CommonTree)adaptor.nil();
//
//                    pushFollow(FOLLOW_statement_in_top_statement256);
//                    statement6=statement();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) adaptor.addChild(root_0, statement6.getTree());
//
//                    }
//                    break;
//                case 2 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:87:5: function_declaration_statement
//                    {
//                    root_0 = (CommonTree)adaptor.nil();
//
//                    pushFollow(FOLLOW_function_declaration_statement_in_top_statement262);
//                    function_declaration_statement7=function_declaration_statement();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) adaptor.addChild(root_0, function_declaration_statement7.getTree());
//
//                    }
//                    break;
//                case 3 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:88:5: class_declaration_statement
//                    {
//                    root_0 = (CommonTree)adaptor.nil();
//
//                    pushFollow(FOLLOW_class_declaration_statement_in_top_statement268);
//                    class_declaration_statement8=class_declaration_statement();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) adaptor.addChild(root_0, class_declaration_statement8.getTree());
//
//                    }
//                    break;
//                case 4 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:89:5: halt_compiler_statement
//                    {
//                    root_0 = (CommonTree)adaptor.nil();
//
//                    pushFollow(FOLLOW_halt_compiler_statement_in_top_statement274);
//                    halt_compiler_statement9=halt_compiler_statement();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) adaptor.addChild(root_0, halt_compiler_statement9.getTree());
//
//                    }
//                    break;
//
//            }
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "top_statement"
//
//    public static class inner_statement_list_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "inner_statement_list"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:92:1: inner_statement_list : ( inner_statement )+ ;
//    public final CompilerAstParser.inner_statement_list_return inner_statement_list() throws RecognitionException {
//        CompilerAstParser.inner_statement_list_return retval = new CompilerAstParser.inner_statement_list_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        CompilerAstParser.inner_statement_return inner_statement10 = null;
//
//
//
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:93:3: ( ( inner_statement )+ )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:93:5: ( inner_statement )+
//            {
//            root_0 = (CommonTree)adaptor.nil();
//
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:93:5: ( inner_statement )+
//            int cnt5=0;
//            loop5:
//            do {
//                int alt5=2;
//                int LA5_0 = input.LA(1);
//
//                if ( ((LA5_0>=IDENTIFIER && LA5_0<=DOUBLELITERRAL)||(LA5_0>=60 && LA5_0<=61)||(LA5_0>=63 && LA5_0<=64)||LA5_0==67||(LA5_0>=69 && LA5_0<=84)||(LA5_0>=86 && LA5_0<=89)||LA5_0==95||(LA5_0>=142 && LA5_0<=143)||(LA5_0>=154 && LA5_0<=155)||(LA5_0>=157 && LA5_0<=161)||(LA5_0>=163 && LA5_0<=166)||LA5_0==168||(LA5_0>=171 && LA5_0<=176)) ) {
//                    alt5=1;
//                }
//
//
//                switch (alt5) {
//            	case 1 :
//            	    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:93:6: inner_statement
//            	    {
//            	    pushFollow(FOLLOW_inner_statement_in_inner_statement_list290);
//            	    inner_statement10=inner_statement();
//
//            	    state._fsp--;
//            	    if (state.failed) return retval;
//            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, inner_statement10.getTree());
//
//            	    }
//            	    break;
//
//            	default :
//            	    if ( cnt5 >= 1 ) break loop5;
//            	    if (state.backtracking>0) {state.failed=true; return retval;}
//                        EarlyExitException eee =
//                            new EarlyExitException(5, input);
//                        throw eee;
//                }
//                cnt5++;
//            } while (true);
//
//
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "inner_statement_list"
//
//    public static class inner_statement_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "inner_statement"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:96:1: inner_statement : ( statement | function_declaration_statement | class_declaration_statement | halt_compiler_statement );
//    public final CompilerAstParser.inner_statement_return inner_statement() throws RecognitionException {
//        CompilerAstParser.inner_statement_return retval = new CompilerAstParser.inner_statement_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        CompilerAstParser.statement_return statement11 = null;
//
//        CompilerAstParser.function_declaration_statement_return function_declaration_statement12 = null;
//
//        CompilerAstParser.class_declaration_statement_return class_declaration_statement13 = null;
//
//        CompilerAstParser.halt_compiler_statement_return halt_compiler_statement14 = null;
//
//
//
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:97:3: ( statement | function_declaration_statement | class_declaration_statement | halt_compiler_statement )
//            int alt6=4;
//            switch ( input.LA(1) ) {
//            case IDENTIFIER:
//            case STRINGLITERAL:
//            case BACKTRICKLITERAL:
//            case STATIC:
//            case INTLITERAL:
//            case FLOATLITERAL:
//            case DOUBLELITERRAL:
//            case 61:
//            case 63:
//            case 67:
//            case 73:
//            case 74:
//            case 75:
//            case 76:
//            case 77:
//            case 78:
//            case 79:
//            case 80:
//            case 81:
//            case 82:
//            case 83:
//            case 84:
//            case 86:
//            case 87:
//            case 88:
//            case 89:
//            case 95:
//            case 142:
//            case 143:
//            case 154:
//            case 155:
//            case 157:
//            case 158:
//            case 159:
//            case 160:
//            case 161:
//            case 163:
//            case 164:
//            case 165:
//            case 166:
//            case 168:
//            case 171:
//            case 172:
//            case 173:
//            case 174:
//            case 175:
//            case 176:
//                {
//                alt6=1;
//                }
//                break;
//            case 72:
//                {
//                switch ( input.LA(2) ) {
//                case 73:
//                    {
//                    int LA6_5 = input.LA(3);
//
//                    if ( (LA6_5==IDENTIFIER) ) {
//                        alt6=2;
//                    }
//                    else if ( (LA6_5==61) ) {
//                        alt6=1;
//                    }
//                    else {
//                        if (state.backtracking>0) {state.failed=true; return retval;}
//                        NoViableAltException nvae =
//                            new NoViableAltException("", 6, 5, input);
//
//                        throw nvae;
//                    }
//                    }
//                    break;
//                case 61:
//                    {
//                    alt6=1;
//                    }
//                    break;
//                case IDENTIFIER:
//                    {
//                    alt6=2;
//                    }
//                    break;
//                default:
//                    if (state.backtracking>0) {state.failed=true; return retval;}
//                    NoViableAltException nvae =
//                        new NoViableAltException("", 6, 2, input);
//
//                    throw nvae;
//                }
//
//                }
//                break;
//            case 64:
//            case 69:
//            case 70:
//            case 71:
//                {
//                alt6=3;
//                }
//                break;
//            case 60:
//                {
//                alt6=4;
//                }
//                break;
//            default:
//                if (state.backtracking>0) {state.failed=true; return retval;}
//                NoViableAltException nvae =
//                    new NoViableAltException("", 6, 0, input);
//
//                throw nvae;
//            }
//
//            switch (alt6) {
//                case 1 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:97:5: statement
//                    {
//                    root_0 = (CommonTree)adaptor.nil();
//
//                    pushFollow(FOLLOW_statement_in_inner_statement307);
//                    statement11=statement();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) adaptor.addChild(root_0, statement11.getTree());
//
//                    }
//                    break;
//                case 2 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:98:5: function_declaration_statement
//                    {
//                    root_0 = (CommonTree)adaptor.nil();
//
//                    pushFollow(FOLLOW_function_declaration_statement_in_inner_statement313);
//                    function_declaration_statement12=function_declaration_statement();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) adaptor.addChild(root_0, function_declaration_statement12.getTree());
//
//                    }
//                    break;
//                case 3 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:99:5: class_declaration_statement
//                    {
//                    root_0 = (CommonTree)adaptor.nil();
//
//                    pushFollow(FOLLOW_class_declaration_statement_in_inner_statement319);
//                    class_declaration_statement13=class_declaration_statement();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) adaptor.addChild(root_0, class_declaration_statement13.getTree());
//
//                    }
//                    break;
//                case 4 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:100:5: halt_compiler_statement
//                    {
//                    root_0 = (CommonTree)adaptor.nil();
//
//                    pushFollow(FOLLOW_halt_compiler_statement_in_inner_statement325);
//                    halt_compiler_statement14=halt_compiler_statement();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) adaptor.addChild(root_0, halt_compiler_statement14.getTree());
//
//                    }
//                    break;
//
//            }
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "inner_statement"
//
//    public static class halt_compiler_statement_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "halt_compiler_statement"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:103:1: halt_compiler_statement : '__halt_compiler' '(' ')' ';' -> '__halt_compiler' ;
//    public final CompilerAstParser.halt_compiler_statement_return halt_compiler_statement() throws RecognitionException {
//        CompilerAstParser.halt_compiler_statement_return retval = new CompilerAstParser.halt_compiler_statement_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token string_literal15=null;
//        Token char_literal16=null;
//        Token char_literal17=null;
//        Token char_literal18=null;
//
//        CommonTree string_literal15_tree=null;
//        CommonTree char_literal16_tree=null;
//        CommonTree char_literal17_tree=null;
//        CommonTree char_literal18_tree=null;
//        RewriteRuleTokenStream stream_62=new RewriteRuleTokenStream(adaptor,"token 62");
//        RewriteRuleTokenStream stream_63=new RewriteRuleTokenStream(adaptor,"token 63");
//        RewriteRuleTokenStream stream_60=new RewriteRuleTokenStream(adaptor,"token 60");
//        RewriteRuleTokenStream stream_61=new RewriteRuleTokenStream(adaptor,"token 61");
//
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:104:3: ( '__halt_compiler' '(' ')' ';' -> '__halt_compiler' )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:104:5: '__halt_compiler' '(' ')' ';'
//            {
//            string_literal15=(Token)match(input,60,FOLLOW_60_in_halt_compiler_statement340); if (state.failed) return retval; 
//            if ( state.backtracking==0 ) stream_60.add(string_literal15);
//
//            char_literal16=(Token)match(input,61,FOLLOW_61_in_halt_compiler_statement342); if (state.failed) return retval; 
//            if ( state.backtracking==0 ) stream_61.add(char_literal16);
//
//            char_literal17=(Token)match(input,62,FOLLOW_62_in_halt_compiler_statement344); if (state.failed) return retval; 
//            if ( state.backtracking==0 ) stream_62.add(char_literal17);
//
//            char_literal18=(Token)match(input,63,FOLLOW_63_in_halt_compiler_statement346); if (state.failed) return retval; 
//            if ( state.backtracking==0 ) stream_63.add(char_literal18);
//
//
//
//            // AST REWRITE
//            // elements: 60
//            // token labels: 
//            // rule labels: retval
//            // token list labels: 
//            // rule list labels: 
//            // wildcard labels: 
//            if ( state.backtracking==0 ) {
//            retval.tree = root_0;
//            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//            root_0 = (CommonTree)adaptor.nil();
//            // 104:36: -> '__halt_compiler'
//            {
//                adaptor.addChild(root_0, stream_60.nextNode());
//
//            }
//
//            retval.tree = root_0;}
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "halt_compiler_statement"
//
//    public static class class_declaration_statement_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "class_declaration_statement"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:107:1: class_declaration_statement : ( ( ( class_entr_type )? 'class' IDENTIFIER ( 'extends' fully_qualified_class_name )? ( 'implements' fully_qualified_class_name_list )? '{' ( class_statement_list )? '}' -> ^( 'class' ( class_entr_type )? IDENTIFIER ( ^( 'extends' fully_qualified_class_name ) )? ( ^( 'implements' fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? ) ) | ( 'interface' IDENTIFIER ( 'extends' fully_qualified_class_name_list )? ( 'implements' fully_qualified_class_name_list )? '{' ( class_statement_list )? '}' -> ^( 'interface' IDENTIFIER ( ^( 'extends' fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? ) ) );
//    public final CompilerAstParser.class_declaration_statement_return class_declaration_statement() throws RecognitionException {
//        CompilerAstParser.class_declaration_statement_return retval = new CompilerAstParser.class_declaration_statement_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token string_literal20=null;
//        Token IDENTIFIER21=null;
//        Token string_literal22=null;
//        Token string_literal24=null;
//        Token char_literal26=null;
//        Token char_literal28=null;
//        Token string_literal29=null;
//        Token IDENTIFIER30=null;
//        Token string_literal31=null;
//        Token string_literal33=null;
//        Token char_literal35=null;
//        Token char_literal37=null;
//        CompilerAstParser.class_entr_type_return class_entr_type19 = null;
//
//        CompilerAstParser.fully_qualified_class_name_return fully_qualified_class_name23 = null;
//
//        CompilerAstParser.fully_qualified_class_name_list_return fully_qualified_class_name_list25 = null;
//
//        CompilerAstParser.class_statement_list_return class_statement_list27 = null;
//
//        CompilerAstParser.fully_qualified_class_name_list_return fully_qualified_class_name_list32 = null;
//
//        CompilerAstParser.fully_qualified_class_name_list_return fully_qualified_class_name_list34 = null;
//
//        CompilerAstParser.class_statement_list_return class_statement_list36 = null;
//
//
//        CommonTree string_literal20_tree=null;
//        CommonTree IDENTIFIER21_tree=null;
//        CommonTree string_literal22_tree=null;
//        CommonTree string_literal24_tree=null;
//        CommonTree char_literal26_tree=null;
//        CommonTree char_literal28_tree=null;
//        CommonTree string_literal29_tree=null;
//        CommonTree IDENTIFIER30_tree=null;
//        CommonTree string_literal31_tree=null;
//        CommonTree string_literal33_tree=null;
//        CommonTree char_literal35_tree=null;
//        CommonTree char_literal37_tree=null;
//        RewriteRuleTokenStream stream_67=new RewriteRuleTokenStream(adaptor,"token 67");
//        RewriteRuleTokenStream stream_66=new RewriteRuleTokenStream(adaptor,"token 66");
//        RewriteRuleTokenStream stream_69=new RewriteRuleTokenStream(adaptor,"token 69");
//        RewriteRuleTokenStream stream_68=new RewriteRuleTokenStream(adaptor,"token 68");
//        RewriteRuleTokenStream stream_64=new RewriteRuleTokenStream(adaptor,"token 64");
//        RewriteRuleTokenStream stream_65=new RewriteRuleTokenStream(adaptor,"token 65");
//        RewriteRuleTokenStream stream_IDENTIFIER=new RewriteRuleTokenStream(adaptor,"token IDENTIFIER");
//        RewriteRuleSubtreeStream stream_fully_qualified_class_name=new RewriteRuleSubtreeStream(adaptor,"rule fully_qualified_class_name");
//        RewriteRuleSubtreeStream stream_fully_qualified_class_name_list=new RewriteRuleSubtreeStream(adaptor,"rule fully_qualified_class_name_list");
//        RewriteRuleSubtreeStream stream_class_entr_type=new RewriteRuleSubtreeStream(adaptor,"rule class_entr_type");
//        RewriteRuleSubtreeStream stream_class_statement_list=new RewriteRuleSubtreeStream(adaptor,"rule class_statement_list");
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:108:3: ( ( ( class_entr_type )? 'class' IDENTIFIER ( 'extends' fully_qualified_class_name )? ( 'implements' fully_qualified_class_name_list )? '{' ( class_statement_list )? '}' -> ^( 'class' ( class_entr_type )? IDENTIFIER ( ^( 'extends' fully_qualified_class_name ) )? ( ^( 'implements' fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? ) ) | ( 'interface' IDENTIFIER ( 'extends' fully_qualified_class_name_list )? ( 'implements' fully_qualified_class_name_list )? '{' ( class_statement_list )? '}' -> ^( 'interface' IDENTIFIER ( ^( 'extends' fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? ) ) )
//            int alt14=2;
//            int LA14_0 = input.LA(1);
//
//            if ( (LA14_0==64||(LA14_0>=70 && LA14_0<=71)) ) {
//                alt14=1;
//            }
//            else if ( (LA14_0==69) ) {
//                alt14=2;
//            }
//            else {
//                if (state.backtracking>0) {state.failed=true; return retval;}
//                NoViableAltException nvae =
//                    new NoViableAltException("", 14, 0, input);
//
//                throw nvae;
//            }
//            switch (alt14) {
//                case 1 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:108:5: ( ( class_entr_type )? 'class' IDENTIFIER ( 'extends' fully_qualified_class_name )? ( 'implements' fully_qualified_class_name_list )? '{' ( class_statement_list )? '}' -> ^( 'class' ( class_entr_type )? IDENTIFIER ( ^( 'extends' fully_qualified_class_name ) )? ( ^( 'implements' fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? ) )
//                    {
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:108:5: ( ( class_entr_type )? 'class' IDENTIFIER ( 'extends' fully_qualified_class_name )? ( 'implements' fully_qualified_class_name_list )? '{' ( class_statement_list )? '}' -> ^( 'class' ( class_entr_type )? IDENTIFIER ( ^( 'extends' fully_qualified_class_name ) )? ( ^( 'implements' fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? ) )
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:108:7: ( class_entr_type )? 'class' IDENTIFIER ( 'extends' fully_qualified_class_name )? ( 'implements' fully_qualified_class_name_list )? '{' ( class_statement_list )? '}'
//                    {
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:108:7: ( class_entr_type )?
//                    int alt7=2;
//                    int LA7_0 = input.LA(1);
//
//                    if ( ((LA7_0>=70 && LA7_0<=71)) ) {
//                        alt7=1;
//                    }
//                    switch (alt7) {
//                        case 1 :
//                            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:108:7: class_entr_type
//                            {
//                            pushFollow(FOLLOW_class_entr_type_in_class_declaration_statement368);
//                            class_entr_type19=class_entr_type();
//
//                            state._fsp--;
//                            if (state.failed) return retval;
//                            if ( state.backtracking==0 ) stream_class_entr_type.add(class_entr_type19.getTree());
//
//                            }
//                            break;
//
//                    }
//
//                    string_literal20=(Token)match(input,64,FOLLOW_64_in_class_declaration_statement371); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_64.add(string_literal20);
//
//                    IDENTIFIER21=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_class_declaration_statement373); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER21);
//
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:108:43: ( 'extends' fully_qualified_class_name )?
//                    int alt8=2;
//                    int LA8_0 = input.LA(1);
//
//                    if ( (LA8_0==65) ) {
//                        alt8=1;
//                    }
//                    switch (alt8) {
//                        case 1 :
//                            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:108:44: 'extends' fully_qualified_class_name
//                            {
//                            string_literal22=(Token)match(input,65,FOLLOW_65_in_class_declaration_statement376); if (state.failed) return retval; 
//                            if ( state.backtracking==0 ) stream_65.add(string_literal22);
//
//                            pushFollow(FOLLOW_fully_qualified_class_name_in_class_declaration_statement378);
//                            fully_qualified_class_name23=fully_qualified_class_name();
//
//                            state._fsp--;
//                            if (state.failed) return retval;
//                            if ( state.backtracking==0 ) stream_fully_qualified_class_name.add(fully_qualified_class_name23.getTree());
//
//                            }
//                            break;
//
//                    }
//
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:108:83: ( 'implements' fully_qualified_class_name_list )?
//                    int alt9=2;
//                    int LA9_0 = input.LA(1);
//
//                    if ( (LA9_0==66) ) {
//                        alt9=1;
//                    }
//                    switch (alt9) {
//                        case 1 :
//                            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:108:84: 'implements' fully_qualified_class_name_list
//                            {
//                            string_literal24=(Token)match(input,66,FOLLOW_66_in_class_declaration_statement383); if (state.failed) return retval; 
//                            if ( state.backtracking==0 ) stream_66.add(string_literal24);
//
//                            pushFollow(FOLLOW_fully_qualified_class_name_list_in_class_declaration_statement385);
//                            fully_qualified_class_name_list25=fully_qualified_class_name_list();
//
//                            state._fsp--;
//                            if (state.failed) return retval;
//                            if ( state.backtracking==0 ) stream_fully_qualified_class_name_list.add(fully_qualified_class_name_list25.getTree());
//
//                            }
//                            break;
//
//                    }
//
//                    char_literal26=(Token)match(input,67,FOLLOW_67_in_class_declaration_statement395); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_67.add(char_literal26);
//
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:109:11: ( class_statement_list )?
//                    int alt10=2;
//                    int LA10_0 = input.LA(1);
//
//                    if ( ((LA10_0>=70 && LA10_0<=72)||LA10_0==82||LA10_0==91||(LA10_0>=108 && LA10_0<=111)) ) {
//                        alt10=1;
//                    }
//                    switch (alt10) {
//                        case 1 :
//                            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:109:11: class_statement_list
//                            {
//                            pushFollow(FOLLOW_class_statement_list_in_class_declaration_statement397);
//                            class_statement_list27=class_statement_list();
//
//                            state._fsp--;
//                            if (state.failed) return retval;
//                            if ( state.backtracking==0 ) stream_class_statement_list.add(class_statement_list27.getTree());
//
//                            }
//                            break;
//
//                    }
//
//                    char_literal28=(Token)match(input,68,FOLLOW_68_in_class_declaration_statement400); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_68.add(char_literal28);
//
//
//
//                    // AST REWRITE
//                    // elements: class_statement_list, fully_qualified_class_name_list, IDENTIFIER, class_entr_type, 64, 65, 66, fully_qualified_class_name
//                    // token labels: 
//                    // rule labels: retval
//                    // token list labels: 
//                    // rule list labels: 
//                    // wildcard labels: 
//                    if ( state.backtracking==0 ) {
//                    retval.tree = root_0;
//                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//                    root_0 = (CommonTree)adaptor.nil();
//                    // 110:5: -> ^( 'class' ( class_entr_type )? IDENTIFIER ( ^( 'extends' fully_qualified_class_name ) )? ( ^( 'implements' fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? )
//                    {
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:110:8: ^( 'class' ( class_entr_type )? IDENTIFIER ( ^( 'extends' fully_qualified_class_name ) )? ( ^( 'implements' fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? )
//                        {
//                        CommonTree root_1 = (CommonTree)adaptor.nil();
//                        root_1 = (CommonTree)adaptor.becomeRoot(stream_64.nextNode(), root_1);
//
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:110:18: ( class_entr_type )?
//                        if ( stream_class_entr_type.hasNext() ) {
//                            adaptor.addChild(root_1, stream_class_entr_type.nextTree());
//
//                        }
//                        stream_class_entr_type.reset();
//                        adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:110:46: ( ^( 'extends' fully_qualified_class_name ) )?
//                        if ( stream_65.hasNext()||stream_fully_qualified_class_name.hasNext() ) {
//                            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:110:46: ^( 'extends' fully_qualified_class_name )
//                            {
//                            CommonTree root_2 = (CommonTree)adaptor.nil();
//                            root_2 = (CommonTree)adaptor.becomeRoot(stream_65.nextNode(), root_2);
//
//                            adaptor.addChild(root_2, stream_fully_qualified_class_name.nextTree());
//
//                            adaptor.addChild(root_1, root_2);
//                            }
//
//                        }
//                        stream_65.reset();
//                        stream_fully_qualified_class_name.reset();
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:110:87: ( ^( 'implements' fully_qualified_class_name_list ) )?
//                        if ( stream_fully_qualified_class_name_list.hasNext()||stream_66.hasNext() ) {
//                            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:110:87: ^( 'implements' fully_qualified_class_name_list )
//                            {
//                            CommonTree root_2 = (CommonTree)adaptor.nil();
//                            root_2 = (CommonTree)adaptor.becomeRoot(stream_66.nextNode(), root_2);
//
//                            adaptor.addChild(root_2, stream_fully_qualified_class_name_list.nextTree());
//
//                            adaptor.addChild(root_1, root_2);
//                            }
//
//                        }
//                        stream_fully_qualified_class_name_list.reset();
//                        stream_66.reset();
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:111:6: ( ^( CLASS_BODY class_statement_list ) )?
//                        if ( stream_class_statement_list.hasNext() ) {
//                            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:111:6: ^( CLASS_BODY class_statement_list )
//                            {
//                            CommonTree root_2 = (CommonTree)adaptor.nil();
//                            root_2 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(CLASS_BODY, "CLASS_BODY"), root_2);
//
//                            adaptor.addChild(root_2, stream_class_statement_list.nextTree());
//
//                            adaptor.addChild(root_1, root_2);
//                            }
//
//                        }
//                        stream_class_statement_list.reset();
//
//                        adaptor.addChild(root_0, root_1);
//                        }
//
//                    }
//
//                    retval.tree = root_0;}
//                    }
//
//
//                    }
//                    break;
//                case 2 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:113:6: ( 'interface' IDENTIFIER ( 'extends' fully_qualified_class_name_list )? ( 'implements' fully_qualified_class_name_list )? '{' ( class_statement_list )? '}' -> ^( 'interface' IDENTIFIER ( ^( 'extends' fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? ) )
//                    {
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:113:6: ( 'interface' IDENTIFIER ( 'extends' fully_qualified_class_name_list )? ( 'implements' fully_qualified_class_name_list )? '{' ( class_statement_list )? '}' -> ^( 'interface' IDENTIFIER ( ^( 'extends' fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? ) )
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:113:7: 'interface' IDENTIFIER ( 'extends' fully_qualified_class_name_list )? ( 'implements' fully_qualified_class_name_list )? '{' ( class_statement_list )? '}'
//                    {
//                    string_literal29=(Token)match(input,69,FOLLOW_69_in_class_declaration_statement452); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_69.add(string_literal29);
//
//                    IDENTIFIER30=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_class_declaration_statement454); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER30);
//
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:113:30: ( 'extends' fully_qualified_class_name_list )?
//                    int alt11=2;
//                    int LA11_0 = input.LA(1);
//
//                    if ( (LA11_0==65) ) {
//                        alt11=1;
//                    }
//                    switch (alt11) {
//                        case 1 :
//                            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:113:31: 'extends' fully_qualified_class_name_list
//                            {
//                            string_literal31=(Token)match(input,65,FOLLOW_65_in_class_declaration_statement457); if (state.failed) return retval; 
//                            if ( state.backtracking==0 ) stream_65.add(string_literal31);
//
//                            pushFollow(FOLLOW_fully_qualified_class_name_list_in_class_declaration_statement459);
//                            fully_qualified_class_name_list32=fully_qualified_class_name_list();
//
//                            state._fsp--;
//                            if (state.failed) return retval;
//                            if ( state.backtracking==0 ) stream_fully_qualified_class_name_list.add(fully_qualified_class_name_list32.getTree());
//
//                            }
//                            break;
//
//                    }
//
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:113:75: ( 'implements' fully_qualified_class_name_list )?
//                    int alt12=2;
//                    int LA12_0 = input.LA(1);
//
//                    if ( (LA12_0==66) ) {
//                        alt12=1;
//                    }
//                    switch (alt12) {
//                        case 1 :
//                            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:113:76: 'implements' fully_qualified_class_name_list
//                            {
//                            string_literal33=(Token)match(input,66,FOLLOW_66_in_class_declaration_statement464); if (state.failed) return retval; 
//                            if ( state.backtracking==0 ) stream_66.add(string_literal33);
//
//                            pushFollow(FOLLOW_fully_qualified_class_name_list_in_class_declaration_statement466);
//                            fully_qualified_class_name_list34=fully_qualified_class_name_list();
//
//                            state._fsp--;
//                            if (state.failed) return retval;
//                            if ( state.backtracking==0 ) stream_fully_qualified_class_name_list.add(fully_qualified_class_name_list34.getTree());
//
//                            }
//                            break;
//
//                    }
//
//                    char_literal35=(Token)match(input,67,FOLLOW_67_in_class_declaration_statement476); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_67.add(char_literal35);
//
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:114:11: ( class_statement_list )?
//                    int alt13=2;
//                    int LA13_0 = input.LA(1);
//
//                    if ( ((LA13_0>=70 && LA13_0<=72)||LA13_0==82||LA13_0==91||(LA13_0>=108 && LA13_0<=111)) ) {
//                        alt13=1;
//                    }
//                    switch (alt13) {
//                        case 1 :
//                            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:114:11: class_statement_list
//                            {
//                            pushFollow(FOLLOW_class_statement_list_in_class_declaration_statement478);
//                            class_statement_list36=class_statement_list();
//
//                            state._fsp--;
//                            if (state.failed) return retval;
//                            if ( state.backtracking==0 ) stream_class_statement_list.add(class_statement_list36.getTree());
//
//                            }
//                            break;
//
//                    }
//
//                    char_literal37=(Token)match(input,68,FOLLOW_68_in_class_declaration_statement481); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_68.add(char_literal37);
//
//
//
//                    // AST REWRITE
//                    // elements: class_statement_list, 69, 65, IDENTIFIER, fully_qualified_class_name_list
//                    // token labels: 
//                    // rule labels: retval
//                    // token list labels: 
//                    // rule list labels: 
//                    // wildcard labels: 
//                    if ( state.backtracking==0 ) {
//                    retval.tree = root_0;
//                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//                    root_0 = (CommonTree)adaptor.nil();
//                    // 115:5: -> ^( 'interface' IDENTIFIER ( ^( 'extends' fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? )
//                    {
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:115:8: ^( 'interface' IDENTIFIER ( ^( 'extends' fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? )
//                        {
//                        CommonTree root_1 = (CommonTree)adaptor.nil();
//                        root_1 = (CommonTree)adaptor.becomeRoot(stream_69.nextNode(), root_1);
//
//                        adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:115:33: ( ^( 'extends' fully_qualified_class_name_list ) )?
//                        if ( stream_65.hasNext()||stream_fully_qualified_class_name_list.hasNext() ) {
//                            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:115:33: ^( 'extends' fully_qualified_class_name_list )
//                            {
//                            CommonTree root_2 = (CommonTree)adaptor.nil();
//                            root_2 = (CommonTree)adaptor.becomeRoot(stream_65.nextNode(), root_2);
//
//                            adaptor.addChild(root_2, stream_fully_qualified_class_name_list.nextTree());
//
//                            adaptor.addChild(root_1, root_2);
//                            }
//
//                        }
//                        stream_65.reset();
//                        stream_fully_qualified_class_name_list.reset();
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:116:6: ( ^( CLASS_BODY class_statement_list ) )?
//                        if ( stream_class_statement_list.hasNext() ) {
//                            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:116:6: ^( CLASS_BODY class_statement_list )
//                            {
//                            CommonTree root_2 = (CommonTree)adaptor.nil();
//                            root_2 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(CLASS_BODY, "CLASS_BODY"), root_2);
//
//                            adaptor.addChild(root_2, stream_class_statement_list.nextTree());
//
//                            adaptor.addChild(root_1, root_2);
//                            }
//
//                        }
//                        stream_class_statement_list.reset();
//
//                        adaptor.addChild(root_0, root_1);
//                        }
//
//                    }
//
//                    retval.tree = root_0;}
//                    }
//
//
//                    }
//                    break;
//
//            }
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "class_declaration_statement"
//
//    public static class class_entr_type_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "class_entr_type"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:120:1: class_entr_type : ( 'abstract' | 'final' );
//    public final CompilerAstParser.class_entr_type_return class_entr_type() throws RecognitionException {
//        CompilerAstParser.class_entr_type_return retval = new CompilerAstParser.class_entr_type_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token set38=null;
//
//        CommonTree set38_tree=null;
//
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:121:3: ( 'abstract' | 'final' )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:
//            {
//            root_0 = (CommonTree)adaptor.nil();
//
//            set38=(Token)input.LT(1);
//            if ( (input.LA(1)>=70 && input.LA(1)<=71) ) {
//                input.consume();
//                if ( state.backtracking==0 ) adaptor.addChild(root_0, (CommonTree)adaptor.create(set38));
//                state.errorRecovery=false;state.failed=false;
//            }
//            else {
//                if (state.backtracking>0) {state.failed=true; return retval;}
//                MismatchedSetException mse = new MismatchedSetException(null,input);
//                throw mse;
//            }
//
//
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "class_entr_type"
//
//    public static class class_statement_list_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "class_statement_list"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:125:1: class_statement_list : ( class_statement )+ -> ( class_statement )+ ;
//    public final CompilerAstParser.class_statement_list_return class_statement_list() throws RecognitionException {
//        CompilerAstParser.class_statement_list_return retval = new CompilerAstParser.class_statement_list_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        CompilerAstParser.class_statement_return class_statement39 = null;
//
//
//        RewriteRuleSubtreeStream stream_class_statement=new RewriteRuleSubtreeStream(adaptor,"rule class_statement");
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:126:3: ( ( class_statement )+ -> ( class_statement )+ )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:126:5: ( class_statement )+
//            {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:126:5: ( class_statement )+
//            int cnt15=0;
//            loop15:
//            do {
//                int alt15=2;
//                int LA15_0 = input.LA(1);
//
//                if ( ((LA15_0>=70 && LA15_0<=72)||LA15_0==82||LA15_0==91||(LA15_0>=108 && LA15_0<=111)) ) {
//                    alt15=1;
//                }
//
//
//                switch (alt15) {
//            	case 1 :
//            	    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:126:6: class_statement
//            	    {
//            	    pushFollow(FOLLOW_class_statement_in_class_statement_list553);
//            	    class_statement39=class_statement();
//
//            	    state._fsp--;
//            	    if (state.failed) return retval;
//            	    if ( state.backtracking==0 ) stream_class_statement.add(class_statement39.getTree());
//
//            	    }
//            	    break;
//
//            	default :
//            	    if ( cnt15 >= 1 ) break loop15;
//            	    if (state.backtracking>0) {state.failed=true; return retval;}
//                        EarlyExitException eee =
//                            new EarlyExitException(15, input);
//                        throw eee;
//                }
//                cnt15++;
//            } while (true);
//
//
//
//            // AST REWRITE
//            // elements: class_statement
//            // token labels: 
//            // rule labels: retval
//            // token list labels: 
//            // rule list labels: 
//            // wildcard labels: 
//            if ( state.backtracking==0 ) {
//            retval.tree = root_0;
//            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//            root_0 = (CommonTree)adaptor.nil();
//            // 126:26: -> ( class_statement )+
//            {
//                if ( !(stream_class_statement.hasNext()) ) {
//                    throw new RewriteEarlyExitException();
//                }
//                while ( stream_class_statement.hasNext() ) {
//                    adaptor.addChild(root_0, stream_class_statement.nextTree());
//
//                }
//                stream_class_statement.reset();
//
//            }
//
//            retval.tree = root_0;}
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "class_statement_list"
//
//    public static class class_statement_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "class_statement"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:129:1: class_statement : ( variable_modifiers static_var_list ';' -> ^( FIELD_DECL variable_modifiers static_var_list ) | ( modifier )? method_declaration -> ^( METHOD_DECL ( modifier )? method_declaration ) | class_constant_declaration ';' -> ^( FIELD_DECL class_constant_declaration ) );
//    public final CompilerAstParser.class_statement_return class_statement() throws RecognitionException {
//        CompilerAstParser.class_statement_return retval = new CompilerAstParser.class_statement_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token char_literal42=null;
//        Token char_literal46=null;
//        CompilerAstParser.variable_modifiers_return variable_modifiers40 = null;
//
//        CompilerAstParser.static_var_list_return static_var_list41 = null;
//
//        CompilerAstParser.modifier_return modifier43 = null;
//
//        CompilerAstParser.method_declaration_return method_declaration44 = null;
//
//        CompilerAstParser.class_constant_declaration_return class_constant_declaration45 = null;
//
//
//        CommonTree char_literal42_tree=null;
//        CommonTree char_literal46_tree=null;
//        RewriteRuleTokenStream stream_63=new RewriteRuleTokenStream(adaptor,"token 63");
//        RewriteRuleSubtreeStream stream_modifier=new RewriteRuleSubtreeStream(adaptor,"rule modifier");
//        RewriteRuleSubtreeStream stream_class_constant_declaration=new RewriteRuleSubtreeStream(adaptor,"rule class_constant_declaration");
//        RewriteRuleSubtreeStream stream_method_declaration=new RewriteRuleSubtreeStream(adaptor,"rule method_declaration");
//        RewriteRuleSubtreeStream stream_static_var_list=new RewriteRuleSubtreeStream(adaptor,"rule static_var_list");
//        RewriteRuleSubtreeStream stream_variable_modifiers=new RewriteRuleSubtreeStream(adaptor,"rule variable_modifiers");
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:130:3: ( variable_modifiers static_var_list ';' -> ^( FIELD_DECL variable_modifiers static_var_list ) | ( modifier )? method_declaration -> ^( METHOD_DECL ( modifier )? method_declaration ) | class_constant_declaration ';' -> ^( FIELD_DECL class_constant_declaration ) )
//            int alt17=3;
//            alt17 = dfa17.predict(input);
//            switch (alt17) {
//                case 1 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:130:5: variable_modifiers static_var_list ';'
//                    {
//                    pushFollow(FOLLOW_variable_modifiers_in_class_statement576);
//                    variable_modifiers40=variable_modifiers();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) stream_variable_modifiers.add(variable_modifiers40.getTree());
//                    pushFollow(FOLLOW_static_var_list_in_class_statement578);
//                    static_var_list41=static_var_list();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) stream_static_var_list.add(static_var_list41.getTree());
//                    char_literal42=(Token)match(input,63,FOLLOW_63_in_class_statement580); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_63.add(char_literal42);
//
//
//
//                    // AST REWRITE
//                    // elements: static_var_list, variable_modifiers
//                    // token labels: 
//                    // rule labels: retval
//                    // token list labels: 
//                    // rule list labels: 
//                    // wildcard labels: 
//                    if ( state.backtracking==0 ) {
//                    retval.tree = root_0;
//                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//                    root_0 = (CommonTree)adaptor.nil();
//                    // 130:45: -> ^( FIELD_DECL variable_modifiers static_var_list )
//                    {
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:130:48: ^( FIELD_DECL variable_modifiers static_var_list )
//                        {
//                        CommonTree root_1 = (CommonTree)adaptor.nil();
//                        root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(FIELD_DECL, "FIELD_DECL"), root_1);
//
//                        adaptor.addChild(root_1, stream_variable_modifiers.nextTree());
//                        adaptor.addChild(root_1, stream_static_var_list.nextTree());
//
//                        adaptor.addChild(root_0, root_1);
//                        }
//
//                    }
//
//                    retval.tree = root_0;}
//                    }
//                    break;
//                case 2 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:131:5: ( modifier )? method_declaration
//                    {
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:131:5: ( modifier )?
//                    int alt16=2;
//                    int LA16_0 = input.LA(1);
//
//                    if ( ((LA16_0>=70 && LA16_0<=71)||LA16_0==82||(LA16_0>=109 && LA16_0<=111)) ) {
//                        alt16=1;
//                    }
//                    switch (alt16) {
//                        case 1 :
//                            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:131:5: modifier
//                            {
//                            pushFollow(FOLLOW_modifier_in_class_statement597);
//                            modifier43=modifier();
//
//                            state._fsp--;
//                            if (state.failed) return retval;
//                            if ( state.backtracking==0 ) stream_modifier.add(modifier43.getTree());
//
//                            }
//                            break;
//
//                    }
//
//                    pushFollow(FOLLOW_method_declaration_in_class_statement600);
//                    method_declaration44=method_declaration();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) stream_method_declaration.add(method_declaration44.getTree());
//
//
//                    // AST REWRITE
//                    // elements: modifier, method_declaration
//                    // token labels: 
//                    // rule labels: retval
//                    // token list labels: 
//                    // rule list labels: 
//                    // wildcard labels: 
//                    if ( state.backtracking==0 ) {
//                    retval.tree = root_0;
//                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//                    root_0 = (CommonTree)adaptor.nil();
//                    // 131:37: -> ^( METHOD_DECL ( modifier )? method_declaration )
//                    {
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:131:40: ^( METHOD_DECL ( modifier )? method_declaration )
//                        {
//                        CommonTree root_1 = (CommonTree)adaptor.nil();
//                        root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(METHOD_DECL, "METHOD_DECL"), root_1);
//
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:131:54: ( modifier )?
//                        if ( stream_modifier.hasNext() ) {
//                            adaptor.addChild(root_1, stream_modifier.nextTree());
//
//                        }
//                        stream_modifier.reset();
//                        adaptor.addChild(root_1, stream_method_declaration.nextTree());
//
//                        adaptor.addChild(root_0, root_1);
//                        }
//
//                    }
//
//                    retval.tree = root_0;}
//                    }
//                    break;
//                case 3 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:132:5: class_constant_declaration ';'
//                    {
//                    pushFollow(FOLLOW_class_constant_declaration_in_class_statement620);
//                    class_constant_declaration45=class_constant_declaration();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) stream_class_constant_declaration.add(class_constant_declaration45.getTree());
//                    char_literal46=(Token)match(input,63,FOLLOW_63_in_class_statement622); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_63.add(char_literal46);
//
//
//
//                    // AST REWRITE
//                    // elements: class_constant_declaration
//                    // token labels: 
//                    // rule labels: retval
//                    // token list labels: 
//                    // rule list labels: 
//                    // wildcard labels: 
//                    if ( state.backtracking==0 ) {
//                    retval.tree = root_0;
//                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//                    root_0 = (CommonTree)adaptor.nil();
//                    // 132:40: -> ^( FIELD_DECL class_constant_declaration )
//                    {
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:132:43: ^( FIELD_DECL class_constant_declaration )
//                        {
//                        CommonTree root_1 = (CommonTree)adaptor.nil();
//                        root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(FIELD_DECL, "FIELD_DECL"), root_1);
//
//                        adaptor.addChild(root_1, stream_class_constant_declaration.nextTree());
//
//                        adaptor.addChild(root_0, root_1);
//                        }
//
//                    }
//
//                    retval.tree = root_0;}
//                    }
//                    break;
//
//            }
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "class_statement"
//
//    public static class function_declaration_statement_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "function_declaration_statement"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:135:1: function_declaration_statement : 'function' ( '&' )? IDENTIFIER '(' ( parameter_list )? ')' block -> ^( 'function' ( '&' )? IDENTIFIER ( parameter_list )? block ) ;
//    public final CompilerAstParser.function_declaration_statement_return function_declaration_statement() throws RecognitionException {
//        CompilerAstParser.function_declaration_statement_return retval = new CompilerAstParser.function_declaration_statement_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token string_literal47=null;
//        Token char_literal48=null;
//        Token IDENTIFIER49=null;
//        Token char_literal50=null;
//        Token char_literal52=null;
//        CompilerAstParser.parameter_list_return parameter_list51 = null;
//
//        CompilerAstParser.block_return block53 = null;
//
//
//        CommonTree string_literal47_tree=null;
//        CommonTree char_literal48_tree=null;
//        CommonTree IDENTIFIER49_tree=null;
//        CommonTree char_literal50_tree=null;
//        CommonTree char_literal52_tree=null;
//        RewriteRuleTokenStream stream_62=new RewriteRuleTokenStream(adaptor,"token 62");
//        RewriteRuleTokenStream stream_72=new RewriteRuleTokenStream(adaptor,"token 72");
//        RewriteRuleTokenStream stream_IDENTIFIER=new RewriteRuleTokenStream(adaptor,"token IDENTIFIER");
//        RewriteRuleTokenStream stream_73=new RewriteRuleTokenStream(adaptor,"token 73");
//        RewriteRuleTokenStream stream_61=new RewriteRuleTokenStream(adaptor,"token 61");
//        RewriteRuleSubtreeStream stream_block=new RewriteRuleSubtreeStream(adaptor,"rule block");
//        RewriteRuleSubtreeStream stream_parameter_list=new RewriteRuleSubtreeStream(adaptor,"rule parameter_list");
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:136:3: ( 'function' ( '&' )? IDENTIFIER '(' ( parameter_list )? ')' block -> ^( 'function' ( '&' )? IDENTIFIER ( parameter_list )? block ) )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:136:5: 'function' ( '&' )? IDENTIFIER '(' ( parameter_list )? ')' block
//            {
//            string_literal47=(Token)match(input,72,FOLLOW_72_in_function_declaration_statement649); if (state.failed) return retval; 
//            if ( state.backtracking==0 ) stream_72.add(string_literal47);
//
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:136:16: ( '&' )?
//            int alt18=2;
//            int LA18_0 = input.LA(1);
//
//            if ( (LA18_0==73) ) {
//                alt18=1;
//            }
//            switch (alt18) {
//                case 1 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:136:16: '&'
//                    {
//                    char_literal48=(Token)match(input,73,FOLLOW_73_in_function_declaration_statement651); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_73.add(char_literal48);
//
//
//                    }
//                    break;
//
//            }
//
//            IDENTIFIER49=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_function_declaration_statement654); if (state.failed) return retval; 
//            if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER49);
//
//            char_literal50=(Token)match(input,61,FOLLOW_61_in_function_declaration_statement656); if (state.failed) return retval; 
//            if ( state.backtracking==0 ) stream_61.add(char_literal50);
//
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:136:36: ( parameter_list )?
//            int alt19=2;
//            int LA19_0 = input.LA(1);
//
//            if ( (LA19_0==IDENTIFIER||LA19_0==73||LA19_0==91||(LA19_0>=147 && LA19_0<=157)||LA19_0==168) ) {
//                alt19=1;
//            }
//            switch (alt19) {
//                case 1 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:136:36: parameter_list
//                    {
//                    pushFollow(FOLLOW_parameter_list_in_function_declaration_statement658);
//                    parameter_list51=parameter_list();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) stream_parameter_list.add(parameter_list51.getTree());
//
//                    }
//                    break;
//
//            }
//
//            char_literal52=(Token)match(input,62,FOLLOW_62_in_function_declaration_statement661); if (state.failed) return retval; 
//            if ( state.backtracking==0 ) stream_62.add(char_literal52);
//
//            pushFollow(FOLLOW_block_in_function_declaration_statement666);
//            block53=block();
//
//            state._fsp--;
//            if (state.failed) return retval;
//            if ( state.backtracking==0 ) stream_block.add(block53.getTree());
//
//
//            // AST REWRITE
//            // elements: block, 73, IDENTIFIER, 72, parameter_list
//            // token labels: 
//            // rule labels: retval
//            // token list labels: 
//            // rule list labels: 
//            // wildcard labels: 
//            if ( state.backtracking==0 ) {
//            retval.tree = root_0;
//            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//            root_0 = (CommonTree)adaptor.nil();
//            // 138:2: -> ^( 'function' ( '&' )? IDENTIFIER ( parameter_list )? block )
//            {
//                // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:138:5: ^( 'function' ( '&' )? IDENTIFIER ( parameter_list )? block )
//                {
//                CommonTree root_1 = (CommonTree)adaptor.nil();
//                root_1 = (CommonTree)adaptor.becomeRoot(stream_72.nextNode(), root_1);
//
//                // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:138:18: ( '&' )?
//                if ( stream_73.hasNext() ) {
//                    adaptor.addChild(root_1, stream_73.nextNode());
//
//                }
//                stream_73.reset();
//                adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());
//                // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:138:34: ( parameter_list )?
//                if ( stream_parameter_list.hasNext() ) {
//                    adaptor.addChild(root_1, stream_parameter_list.nextTree());
//
//                }
//                stream_parameter_list.reset();
//                adaptor.addChild(root_1, stream_block.nextTree());
//
//                adaptor.addChild(root_0, root_1);
//                }
//
//            }
//
//            retval.tree = root_0;}
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "function_declaration_statement"
//
//    public static class block_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "block"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:141:1: block : '{' ( inner_statement_list )? '}' -> ^( BLOCK ( inner_statement_list )? ) ;
//    public final CompilerAstParser.block_return block() throws RecognitionException {
//        CompilerAstParser.block_return retval = new CompilerAstParser.block_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token char_literal54=null;
//        Token char_literal56=null;
//        CompilerAstParser.inner_statement_list_return inner_statement_list55 = null;
//
//
//        CommonTree char_literal54_tree=null;
//        CommonTree char_literal56_tree=null;
//        RewriteRuleTokenStream stream_67=new RewriteRuleTokenStream(adaptor,"token 67");
//        RewriteRuleTokenStream stream_68=new RewriteRuleTokenStream(adaptor,"token 68");
//        RewriteRuleSubtreeStream stream_inner_statement_list=new RewriteRuleSubtreeStream(adaptor,"rule inner_statement_list");
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:142:2: ( '{' ( inner_statement_list )? '}' -> ^( BLOCK ( inner_statement_list )? ) )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:142:4: '{' ( inner_statement_list )? '}'
//            {
//            char_literal54=(Token)match(input,67,FOLLOW_67_in_block696); if (state.failed) return retval; 
//            if ( state.backtracking==0 ) stream_67.add(char_literal54);
//
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:142:8: ( inner_statement_list )?
//            int alt20=2;
//            int LA20_0 = input.LA(1);
//
//            if ( ((LA20_0>=IDENTIFIER && LA20_0<=DOUBLELITERRAL)||(LA20_0>=60 && LA20_0<=61)||(LA20_0>=63 && LA20_0<=64)||LA20_0==67||(LA20_0>=69 && LA20_0<=84)||(LA20_0>=86 && LA20_0<=89)||LA20_0==95||(LA20_0>=142 && LA20_0<=143)||(LA20_0>=154 && LA20_0<=155)||(LA20_0>=157 && LA20_0<=161)||(LA20_0>=163 && LA20_0<=166)||LA20_0==168||(LA20_0>=171 && LA20_0<=176)) ) {
//                alt20=1;
//            }
//            switch (alt20) {
//                case 1 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:142:8: inner_statement_list
//                    {
//                    pushFollow(FOLLOW_inner_statement_list_in_block698);
//                    inner_statement_list55=inner_statement_list();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) stream_inner_statement_list.add(inner_statement_list55.getTree());
//
//                    }
//                    break;
//
//            }
//
//            char_literal56=(Token)match(input,68,FOLLOW_68_in_block701); if (state.failed) return retval; 
//            if ( state.backtracking==0 ) stream_68.add(char_literal56);
//
//
//
//            // AST REWRITE
//            // elements: inner_statement_list
//            // token labels: 
//            // rule labels: retval
//            // token list labels: 
//            // rule list labels: 
//            // wildcard labels: 
//            if ( state.backtracking==0 ) {
//            retval.tree = root_0;
//            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//            root_0 = (CommonTree)adaptor.nil();
//            // 142:35: -> ^( BLOCK ( inner_statement_list )? )
//            {
//                // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:142:38: ^( BLOCK ( inner_statement_list )? )
//                {
//                CommonTree root_1 = (CommonTree)adaptor.nil();
//                root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(BLOCK, "BLOCK"), root_1);
//
//                // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:142:46: ( inner_statement_list )?
//                if ( stream_inner_statement_list.hasNext() ) {
//                    adaptor.addChild(root_1, stream_inner_statement_list.nextTree());
//
//                }
//                stream_inner_statement_list.reset();
//
//                adaptor.addChild(root_0, root_1);
//                }
//
//            }
//
//            retval.tree = root_0;}
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "block"
//
//    public static class statement_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "statement"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:145:1: statement : ( block | if_stat | 'while' '(' expression ')' while_statement -> ^( 'while' ^( CONDITION expression ) while_statement ) | 'do' statement 'while' '(' expression ')' ';' -> ^( 'do' ^( CONDITION expression ) statement ) | 'for' '(' (e1= expr_list )? ';' (e2= expr_list )? ';' (e3= expr_list )? ')' ( for_statement )? -> ^( 'for' ( $e1)? ^( CONDITION ( $e2)? ) ^( ITERATE ( $e3)? ) ( for_statement )? ) | 'switch' '(' expression ')' switch_case_list -> ^( 'switch' ^( CONDITION expression ) switch_case_list ) | 'break' ( expression )? ';' -> ^( 'break' ( expression )? ) | 'continue' ( expression )? ';' -> ^( 'continue' ( expression )? ) | 'return' ( expression )? ';' -> ^( 'return' ( expression )? ) | 'global' variable_list ';' -> ^( 'global' variable_list ) | 'static' static_var_list ';' -> ^( 'static' static_var_list ) | 'echo' expr_list ';' -> ^( 'echo' expr_list ) | expression ';' | 'foreach' '(' expression 'as' foreach_variable ')' foreach_statement -> ^( 'foreach' ^( 'as' expression foreach_variable ) foreach_statement ) | 'declare' '(' directive ')' declare_statement -> ^( 'declare' ^( CONDITION directive ) ( declare_statement )? ) | ';' -> ^( EMPTYSTATEMENT ) | 'try' '{' top_statement '}' ( catch_branch )+ -> ^( 'try' ^( BLOCK top_statement ) ( catch_branch )+ ) | 'throw' expression ';' -> ^( 'throw' expression ) | 'use' use_filename ';' -> ^( 'use' use_filename ) );
//    public final CompilerAstParser.statement_return statement() throws RecognitionException {
//        CompilerAstParser.statement_return retval = new CompilerAstParser.statement_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token string_literal59=null;
//        Token char_literal60=null;
//        Token char_literal62=null;
//        Token string_literal64=null;
//        Token string_literal66=null;
//        Token char_literal67=null;
//        Token char_literal69=null;
//        Token char_literal70=null;
//        Token string_literal71=null;
//        Token char_literal72=null;
//        Token char_literal73=null;
//        Token char_literal74=null;
//        Token char_literal75=null;
//        Token string_literal77=null;
//        Token char_literal78=null;
//        Token char_literal80=null;
//        Token string_literal82=null;
//        Token char_literal84=null;
//        Token string_literal85=null;
//        Token char_literal87=null;
//        Token string_literal88=null;
//        Token char_literal90=null;
//        Token string_literal91=null;
//        Token char_literal93=null;
//        Token string_literal94=null;
//        Token char_literal96=null;
//        Token string_literal97=null;
//        Token char_literal99=null;
//        Token char_literal101=null;
//        Token string_literal102=null;
//        Token char_literal103=null;
//        Token string_literal105=null;
//        Token char_literal107=null;
//        Token string_literal109=null;
//        Token char_literal110=null;
//        Token char_literal112=null;
//        Token char_literal114=null;
//        Token string_literal115=null;
//        Token char_literal116=null;
//        Token char_literal118=null;
//        Token string_literal120=null;
//        Token char_literal122=null;
//        Token string_literal123=null;
//        Token char_literal125=null;
//        CompilerAstParser.expr_list_return e1 = null;
//
//        CompilerAstParser.expr_list_return e2 = null;
//
//        CompilerAstParser.expr_list_return e3 = null;
//
//        CompilerAstParser.block_return block57 = null;
//
//        CompilerAstParser.if_stat_return if_stat58 = null;
//
//        CompilerAstParser.expression_return expression61 = null;
//
//        CompilerAstParser.while_statement_return while_statement63 = null;
//
//        CompilerAstParser.statement_return statement65 = null;
//
//        CompilerAstParser.expression_return expression68 = null;
//
//        CompilerAstParser.for_statement_return for_statement76 = null;
//
//        CompilerAstParser.expression_return expression79 = null;
//
//        CompilerAstParser.switch_case_list_return switch_case_list81 = null;
//
//        CompilerAstParser.expression_return expression83 = null;
//
//        CompilerAstParser.expression_return expression86 = null;
//
//        CompilerAstParser.expression_return expression89 = null;
//
//        CompilerAstParser.variable_list_return variable_list92 = null;
//
//        CompilerAstParser.static_var_list_return static_var_list95 = null;
//
//        CompilerAstParser.expr_list_return expr_list98 = null;
//
//        CompilerAstParser.expression_return expression100 = null;
//
//        CompilerAstParser.expression_return expression104 = null;
//
//        CompilerAstParser.foreach_variable_return foreach_variable106 = null;
//
//        CompilerAstParser.foreach_statement_return foreach_statement108 = null;
//
//        CompilerAstParser.directive_return directive111 = null;
//
//        CompilerAstParser.declare_statement_return declare_statement113 = null;
//
//        CompilerAstParser.top_statement_return top_statement117 = null;
//
//        CompilerAstParser.catch_branch_return catch_branch119 = null;
//
//        CompilerAstParser.expression_return expression121 = null;
//
//        CompilerAstParser.use_filename_return use_filename124 = null;
//
//
//        CommonTree string_literal59_tree=null;
//        CommonTree char_literal60_tree=null;
//        CommonTree char_literal62_tree=null;
//        CommonTree string_literal64_tree=null;
//        CommonTree string_literal66_tree=null;
//        CommonTree char_literal67_tree=null;
//        CommonTree char_literal69_tree=null;
//        CommonTree char_literal70_tree=null;
//        CommonTree string_literal71_tree=null;
//        CommonTree char_literal72_tree=null;
//        CommonTree char_literal73_tree=null;
//        CommonTree char_literal74_tree=null;
//        CommonTree char_literal75_tree=null;
//        CommonTree string_literal77_tree=null;
//        CommonTree char_literal78_tree=null;
//        CommonTree char_literal80_tree=null;
//        CommonTree string_literal82_tree=null;
//        CommonTree char_literal84_tree=null;
//        CommonTree string_literal85_tree=null;
//        CommonTree char_literal87_tree=null;
//        CommonTree string_literal88_tree=null;
//        CommonTree char_literal90_tree=null;
//        CommonTree string_literal91_tree=null;
//        CommonTree char_literal93_tree=null;
//        CommonTree string_literal94_tree=null;
//        CommonTree char_literal96_tree=null;
//        CommonTree string_literal97_tree=null;
//        CommonTree char_literal99_tree=null;
//        CommonTree char_literal101_tree=null;
//        CommonTree string_literal102_tree=null;
//        CommonTree char_literal103_tree=null;
//        CommonTree string_literal105_tree=null;
//        CommonTree char_literal107_tree=null;
//        CommonTree string_literal109_tree=null;
//        CommonTree char_literal110_tree=null;
//        CommonTree char_literal112_tree=null;
//        CommonTree char_literal114_tree=null;
//        CommonTree string_literal115_tree=null;
//        CommonTree char_literal116_tree=null;
//        CommonTree char_literal118_tree=null;
//        CommonTree string_literal120_tree=null;
//        CommonTree char_literal122_tree=null;
//        CommonTree string_literal123_tree=null;
//        CommonTree char_literal125_tree=null;
//        RewriteRuleTokenStream stream_67=new RewriteRuleTokenStream(adaptor,"token 67");
//        RewriteRuleTokenStream stream_79=new RewriteRuleTokenStream(adaptor,"token 79");
//        RewriteRuleTokenStream stream_78=new RewriteRuleTokenStream(adaptor,"token 78");
//        RewriteRuleTokenStream stream_68=new RewriteRuleTokenStream(adaptor,"token 68");
//        RewriteRuleTokenStream stream_77=new RewriteRuleTokenStream(adaptor,"token 77");
//        RewriteRuleTokenStream stream_82=new RewriteRuleTokenStream(adaptor,"token 82");
//        RewriteRuleTokenStream stream_83=new RewriteRuleTokenStream(adaptor,"token 83");
//        RewriteRuleTokenStream stream_62=new RewriteRuleTokenStream(adaptor,"token 62");
//        RewriteRuleTokenStream stream_80=new RewriteRuleTokenStream(adaptor,"token 80");
//        RewriteRuleTokenStream stream_63=new RewriteRuleTokenStream(adaptor,"token 63");
//        RewriteRuleTokenStream stream_81=new RewriteRuleTokenStream(adaptor,"token 81");
//        RewriteRuleTokenStream stream_86=new RewriteRuleTokenStream(adaptor,"token 86");
//        RewriteRuleTokenStream stream_87=new RewriteRuleTokenStream(adaptor,"token 87");
//        RewriteRuleTokenStream stream_61=new RewriteRuleTokenStream(adaptor,"token 61");
//        RewriteRuleTokenStream stream_74=new RewriteRuleTokenStream(adaptor,"token 74");
//        RewriteRuleTokenStream stream_88=new RewriteRuleTokenStream(adaptor,"token 88");
//        RewriteRuleTokenStream stream_84=new RewriteRuleTokenStream(adaptor,"token 84");
//        RewriteRuleTokenStream stream_75=new RewriteRuleTokenStream(adaptor,"token 75");
//        RewriteRuleTokenStream stream_89=new RewriteRuleTokenStream(adaptor,"token 89");
//        RewriteRuleTokenStream stream_85=new RewriteRuleTokenStream(adaptor,"token 85");
//        RewriteRuleTokenStream stream_76=new RewriteRuleTokenStream(adaptor,"token 76");
//        RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");
//        RewriteRuleSubtreeStream stream_while_statement=new RewriteRuleSubtreeStream(adaptor,"rule while_statement");
//        RewriteRuleSubtreeStream stream_static_var_list=new RewriteRuleSubtreeStream(adaptor,"rule static_var_list");
//        RewriteRuleSubtreeStream stream_declare_statement=new RewriteRuleSubtreeStream(adaptor,"rule declare_statement");
//        RewriteRuleSubtreeStream stream_statement=new RewriteRuleSubtreeStream(adaptor,"rule statement");
//        RewriteRuleSubtreeStream stream_use_filename=new RewriteRuleSubtreeStream(adaptor,"rule use_filename");
//        RewriteRuleSubtreeStream stream_variable_list=new RewriteRuleSubtreeStream(adaptor,"rule variable_list");
//        RewriteRuleSubtreeStream stream_catch_branch=new RewriteRuleSubtreeStream(adaptor,"rule catch_branch");
//        RewriteRuleSubtreeStream stream_foreach_statement=new RewriteRuleSubtreeStream(adaptor,"rule foreach_statement");
//        RewriteRuleSubtreeStream stream_top_statement=new RewriteRuleSubtreeStream(adaptor,"rule top_statement");
//        RewriteRuleSubtreeStream stream_for_statement=new RewriteRuleSubtreeStream(adaptor,"rule for_statement");
//        RewriteRuleSubtreeStream stream_directive=new RewriteRuleSubtreeStream(adaptor,"rule directive");
//        RewriteRuleSubtreeStream stream_foreach_variable=new RewriteRuleSubtreeStream(adaptor,"rule foreach_variable");
//        RewriteRuleSubtreeStream stream_expr_list=new RewriteRuleSubtreeStream(adaptor,"rule expr_list");
//        RewriteRuleSubtreeStream stream_switch_case_list=new RewriteRuleSubtreeStream(adaptor,"rule switch_case_list");
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:146:3: ( block | if_stat | 'while' '(' expression ')' while_statement -> ^( 'while' ^( CONDITION expression ) while_statement ) | 'do' statement 'while' '(' expression ')' ';' -> ^( 'do' ^( CONDITION expression ) statement ) | 'for' '(' (e1= expr_list )? ';' (e2= expr_list )? ';' (e3= expr_list )? ')' ( for_statement )? -> ^( 'for' ( $e1)? ^( CONDITION ( $e2)? ) ^( ITERATE ( $e3)? ) ( for_statement )? ) | 'switch' '(' expression ')' switch_case_list -> ^( 'switch' ^( CONDITION expression ) switch_case_list ) | 'break' ( expression )? ';' -> ^( 'break' ( expression )? ) | 'continue' ( expression )? ';' -> ^( 'continue' ( expression )? ) | 'return' ( expression )? ';' -> ^( 'return' ( expression )? ) | 'global' variable_list ';' -> ^( 'global' variable_list ) | 'static' static_var_list ';' -> ^( 'static' static_var_list ) | 'echo' expr_list ';' -> ^( 'echo' expr_list ) | expression ';' | 'foreach' '(' expression 'as' foreach_variable ')' foreach_statement -> ^( 'foreach' ^( 'as' expression foreach_variable ) foreach_statement ) | 'declare' '(' directive ')' declare_statement -> ^( 'declare' ^( CONDITION directive ) ( declare_statement )? ) | ';' -> ^( EMPTYSTATEMENT ) | 'try' '{' top_statement '}' ( catch_branch )+ -> ^( 'try' ^( BLOCK top_statement ) ( catch_branch )+ ) | 'throw' expression ';' -> ^( 'throw' expression ) | 'use' use_filename ';' -> ^( 'use' use_filename ) )
//            int alt29=19;
//            switch ( input.LA(1) ) {
//            case 67:
//                {
//                alt29=1;
//                }
//                break;
//            case 95:
//                {
//                alt29=2;
//                }
//                break;
//            case 74:
//                {
//                alt29=3;
//                }
//                break;
//            case 75:
//                {
//                alt29=4;
//                }
//                break;
//            case 76:
//                {
//                alt29=5;
//                }
//                break;
//            case 77:
//                {
//                alt29=6;
//                }
//                break;
//            case 78:
//                {
//                alt29=7;
//                }
//                break;
//            case 79:
//                {
//                alt29=8;
//                }
//                break;
//            case 80:
//                {
//                alt29=9;
//                }
//                break;
//            case 81:
//                {
//                alt29=10;
//                }
//                break;
//            case 82:
//                {
//                alt29=11;
//                }
//                break;
//            case 83:
//                {
//                alt29=12;
//                }
//                break;
//            case IDENTIFIER:
//            case STRINGLITERAL:
//            case BACKTRICKLITERAL:
//            case STATIC:
//            case INTLITERAL:
//            case FLOATLITERAL:
//            case DOUBLELITERRAL:
//            case 61:
//            case 72:
//            case 73:
//            case 142:
//            case 143:
//            case 154:
//            case 155:
//            case 157:
//            case 158:
//            case 159:
//            case 160:
//            case 161:
//            case 163:
//            case 164:
//            case 165:
//            case 166:
//            case 168:
//            case 171:
//            case 172:
//            case 173:
//            case 174:
//            case 175:
//            case 176:
//                {
//                alt29=13;
//                }
//                break;
//            case 84:
//                {
//                alt29=14;
//                }
//                break;
//            case 86:
//                {
//                alt29=15;
//                }
//                break;
//            case 63:
//                {
//                alt29=16;
//                }
//                break;
//            case 87:
//                {
//                alt29=17;
//                }
//                break;
//            case 88:
//                {
//                alt29=18;
//                }
//                break;
//            case 89:
//                {
//                alt29=19;
//                }
//                break;
//            default:
//                if (state.backtracking>0) {state.failed=true; return retval;}
//                NoViableAltException nvae =
//                    new NoViableAltException("", 29, 0, input);
//
//                throw nvae;
//            }
//
//            switch (alt29) {
//                case 1 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:146:5: block
//                    {
//                    root_0 = (CommonTree)adaptor.nil();
//
//                    pushFollow(FOLLOW_block_in_statement725);
//                    block57=block();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) adaptor.addChild(root_0, block57.getTree());
//
//                    }
//                    break;
//                case 2 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:147:5: if_stat
//                    {
//                    root_0 = (CommonTree)adaptor.nil();
//
//                    pushFollow(FOLLOW_if_stat_in_statement731);
//                    if_stat58=if_stat();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) adaptor.addChild(root_0, if_stat58.getTree());
//
//                    }
//                    break;
//                case 3 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:148:5: 'while' '(' expression ')' while_statement
//                    {
//                    string_literal59=(Token)match(input,74,FOLLOW_74_in_statement737); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_74.add(string_literal59);
//
//                    char_literal60=(Token)match(input,61,FOLLOW_61_in_statement739); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_61.add(char_literal60);
//
//                    pushFollow(FOLLOW_expression_in_statement741);
//                    expression61=expression();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) stream_expression.add(expression61.getTree());
//                    char_literal62=(Token)match(input,62,FOLLOW_62_in_statement743); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_62.add(char_literal62);
//
//                    pushFollow(FOLLOW_while_statement_in_statement745);
//                    while_statement63=while_statement();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) stream_while_statement.add(while_statement63.getTree());
//
//
//                    // AST REWRITE
//                    // elements: expression, while_statement, 74
//                    // token labels: 
//                    // rule labels: retval
//                    // token list labels: 
//                    // rule list labels: 
//                    // wildcard labels: 
//                    if ( state.backtracking==0 ) {
//                    retval.tree = root_0;
//                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//                    root_0 = (CommonTree)adaptor.nil();
//                    // 148:49: -> ^( 'while' ^( CONDITION expression ) while_statement )
//                    {
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:148:52: ^( 'while' ^( CONDITION expression ) while_statement )
//                        {
//                        CommonTree root_1 = (CommonTree)adaptor.nil();
//                        root_1 = (CommonTree)adaptor.becomeRoot(stream_74.nextNode(), root_1);
//
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:148:62: ^( CONDITION expression )
//                        {
//                        CommonTree root_2 = (CommonTree)adaptor.nil();
//                        root_2 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(CONDITION, "CONDITION"), root_2);
//
//                        adaptor.addChild(root_2, stream_expression.nextTree());
//
//                        adaptor.addChild(root_1, root_2);
//                        }
//                        adaptor.addChild(root_1, stream_while_statement.nextTree());
//
//                        adaptor.addChild(root_0, root_1);
//                        }
//
//                    }
//
//                    retval.tree = root_0;}
//                    }
//                    break;
//                case 4 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:149:5: 'do' statement 'while' '(' expression ')' ';'
//                    {
//                    string_literal64=(Token)match(input,75,FOLLOW_75_in_statement766); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_75.add(string_literal64);
//
//                    pushFollow(FOLLOW_statement_in_statement768);
//                    statement65=statement();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) stream_statement.add(statement65.getTree());
//                    string_literal66=(Token)match(input,74,FOLLOW_74_in_statement770); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_74.add(string_literal66);
//
//                    char_literal67=(Token)match(input,61,FOLLOW_61_in_statement772); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_61.add(char_literal67);
//
//                    pushFollow(FOLLOW_expression_in_statement774);
//                    expression68=expression();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) stream_expression.add(expression68.getTree());
//                    char_literal69=(Token)match(input,62,FOLLOW_62_in_statement776); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_62.add(char_literal69);
//
//                    char_literal70=(Token)match(input,63,FOLLOW_63_in_statement778); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_63.add(char_literal70);
//
//
//
//                    // AST REWRITE
//                    // elements: expression, statement, 75
//                    // token labels: 
//                    // rule labels: retval
//                    // token list labels: 
//                    // rule list labels: 
//                    // wildcard labels: 
//                    if ( state.backtracking==0 ) {
//                    retval.tree = root_0;
//                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//                    root_0 = (CommonTree)adaptor.nil();
//                    // 149:51: -> ^( 'do' ^( CONDITION expression ) statement )
//                    {
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:149:54: ^( 'do' ^( CONDITION expression ) statement )
//                        {
//                        CommonTree root_1 = (CommonTree)adaptor.nil();
//                        root_1 = (CommonTree)adaptor.becomeRoot(stream_75.nextNode(), root_1);
//
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:149:61: ^( CONDITION expression )
//                        {
//                        CommonTree root_2 = (CommonTree)adaptor.nil();
//                        root_2 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(CONDITION, "CONDITION"), root_2);
//
//                        adaptor.addChild(root_2, stream_expression.nextTree());
//
//                        adaptor.addChild(root_1, root_2);
//                        }
//                        adaptor.addChild(root_1, stream_statement.nextTree());
//
//                        adaptor.addChild(root_0, root_1);
//                        }
//
//                    }
//
//                    retval.tree = root_0;}
//                    }
//                    break;
//                case 5 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:150:5: 'for' '(' (e1= expr_list )? ';' (e2= expr_list )? ';' (e3= expr_list )? ')' ( for_statement )?
//                    {
//                    string_literal71=(Token)match(input,76,FOLLOW_76_in_statement798); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_76.add(string_literal71);
//
//                    char_literal72=(Token)match(input,61,FOLLOW_61_in_statement800); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_61.add(char_literal72);
//
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:150:17: (e1= expr_list )?
//                    int alt21=2;
//                    int LA21_0 = input.LA(1);
//
//                    if ( ((LA21_0>=IDENTIFIER && LA21_0<=DOUBLELITERRAL)||LA21_0==61||(LA21_0>=72 && LA21_0<=73)||(LA21_0>=142 && LA21_0<=143)||(LA21_0>=154 && LA21_0<=155)||(LA21_0>=157 && LA21_0<=161)||(LA21_0>=163 && LA21_0<=166)||LA21_0==168||(LA21_0>=171 && LA21_0<=176)) ) {
//                        alt21=1;
//                    }
//                    switch (alt21) {
//                        case 1 :
//                            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:150:17: e1= expr_list
//                            {
//                            pushFollow(FOLLOW_expr_list_in_statement804);
//                            e1=expr_list();
//
//                            state._fsp--;
//                            if (state.failed) return retval;
//                            if ( state.backtracking==0 ) stream_expr_list.add(e1.getTree());
//
//                            }
//                            break;
//
//                    }
//
//                    char_literal73=(Token)match(input,63,FOLLOW_63_in_statement807); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_63.add(char_literal73);
//
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:150:35: (e2= expr_list )?
//                    int alt22=2;
//                    int LA22_0 = input.LA(1);
//
//                    if ( ((LA22_0>=IDENTIFIER && LA22_0<=DOUBLELITERRAL)||LA22_0==61||(LA22_0>=72 && LA22_0<=73)||(LA22_0>=142 && LA22_0<=143)||(LA22_0>=154 && LA22_0<=155)||(LA22_0>=157 && LA22_0<=161)||(LA22_0>=163 && LA22_0<=166)||LA22_0==168||(LA22_0>=171 && LA22_0<=176)) ) {
//                        alt22=1;
//                    }
//                    switch (alt22) {
//                        case 1 :
//                            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:150:35: e2= expr_list
//                            {
//                            pushFollow(FOLLOW_expr_list_in_statement811);
//                            e2=expr_list();
//
//                            state._fsp--;
//                            if (state.failed) return retval;
//                            if ( state.backtracking==0 ) stream_expr_list.add(e2.getTree());
//
//                            }
//                            break;
//
//                    }
//
//                    char_literal74=(Token)match(input,63,FOLLOW_63_in_statement814); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_63.add(char_literal74);
//
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:150:53: (e3= expr_list )?
//                    int alt23=2;
//                    int LA23_0 = input.LA(1);
//
//                    if ( ((LA23_0>=IDENTIFIER && LA23_0<=DOUBLELITERRAL)||LA23_0==61||(LA23_0>=72 && LA23_0<=73)||(LA23_0>=142 && LA23_0<=143)||(LA23_0>=154 && LA23_0<=155)||(LA23_0>=157 && LA23_0<=161)||(LA23_0>=163 && LA23_0<=166)||LA23_0==168||(LA23_0>=171 && LA23_0<=176)) ) {
//                        alt23=1;
//                    }
//                    switch (alt23) {
//                        case 1 :
//                            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:150:53: e3= expr_list
//                            {
//                            pushFollow(FOLLOW_expr_list_in_statement818);
//                            e3=expr_list();
//
//                            state._fsp--;
//                            if (state.failed) return retval;
//                            if ( state.backtracking==0 ) stream_expr_list.add(e3.getTree());
//
//                            }
//                            break;
//
//                    }
//
//                    char_literal75=(Token)match(input,62,FOLLOW_62_in_statement821); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_62.add(char_literal75);
//
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:150:69: ( for_statement )?
//                    int alt24=2;
//                    int LA24_0 = input.LA(1);
//
//                    if ( (LA24_0==98) ) {
//                        alt24=1;
//                    }
//                    switch (alt24) {
//                        case 1 :
//                            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:150:69: for_statement
//                            {
//                            pushFollow(FOLLOW_for_statement_in_statement823);
//                            for_statement76=for_statement();
//
//                            state._fsp--;
//                            if (state.failed) return retval;
//                            if ( state.backtracking==0 ) stream_for_statement.add(for_statement76.getTree());
//
//                            }
//                            break;
//
//                    }
//
//
//
//                    // AST REWRITE
//                    // elements: e1, 76, e2, for_statement, e3
//                    // token labels: 
//                    // rule labels: e3, retval, e1, e2
//                    // token list labels: 
//                    // rule list labels: 
//                    // wildcard labels: 
//                    if ( state.backtracking==0 ) {
//                    retval.tree = root_0;
//                    RewriteRuleSubtreeStream stream_e3=new RewriteRuleSubtreeStream(adaptor,"rule e3",e3!=null?e3.tree:null);
//                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//                    RewriteRuleSubtreeStream stream_e1=new RewriteRuleSubtreeStream(adaptor,"rule e1",e1!=null?e1.tree:null);
//                    RewriteRuleSubtreeStream stream_e2=new RewriteRuleSubtreeStream(adaptor,"rule e2",e2!=null?e2.tree:null);
//
//                    root_0 = (CommonTree)adaptor.nil();
//                    // 150:85: -> ^( 'for' ( $e1)? ^( CONDITION ( $e2)? ) ^( ITERATE ( $e3)? ) ( for_statement )? )
//                    {
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:150:88: ^( 'for' ( $e1)? ^( CONDITION ( $e2)? ) ^( ITERATE ( $e3)? ) ( for_statement )? )
//                        {
//                        CommonTree root_1 = (CommonTree)adaptor.nil();
//                        root_1 = (CommonTree)adaptor.becomeRoot(stream_76.nextNode(), root_1);
//
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:150:96: ( $e1)?
//                        if ( stream_e1.hasNext() ) {
//                            adaptor.addChild(root_1, stream_e1.nextTree());
//
//                        }
//                        stream_e1.reset();
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:150:101: ^( CONDITION ( $e2)? )
//                        {
//                        CommonTree root_2 = (CommonTree)adaptor.nil();
//                        root_2 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(CONDITION, "CONDITION"), root_2);
//
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:150:113: ( $e2)?
//                        if ( stream_e2.hasNext() ) {
//                            adaptor.addChild(root_2, stream_e2.nextTree());
//
//                        }
//                        stream_e2.reset();
//
//                        adaptor.addChild(root_1, root_2);
//                        }
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:150:119: ^( ITERATE ( $e3)? )
//                        {
//                        CommonTree root_2 = (CommonTree)adaptor.nil();
//                        root_2 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(ITERATE, "ITERATE"), root_2);
//
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:150:129: ( $e3)?
//                        if ( stream_e3.hasNext() ) {
//                            adaptor.addChild(root_2, stream_e3.nextTree());
//
//                        }
//                        stream_e3.reset();
//
//                        adaptor.addChild(root_1, root_2);
//                        }
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:150:135: ( for_statement )?
//                        if ( stream_for_statement.hasNext() ) {
//                            adaptor.addChild(root_1, stream_for_statement.nextTree());
//
//                        }
//                        stream_for_statement.reset();
//
//                        adaptor.addChild(root_0, root_1);
//                        }
//
//                    }
//
//                    retval.tree = root_0;}
//                    }
//                    break;
//                case 6 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:151:5: 'switch' '(' expression ')' switch_case_list
//                    {
//                    string_literal77=(Token)match(input,77,FOLLOW_77_in_statement860); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_77.add(string_literal77);
//
//                    char_literal78=(Token)match(input,61,FOLLOW_61_in_statement862); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_61.add(char_literal78);
//
//                    pushFollow(FOLLOW_expression_in_statement864);
//                    expression79=expression();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) stream_expression.add(expression79.getTree());
//                    char_literal80=(Token)match(input,62,FOLLOW_62_in_statement866); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_62.add(char_literal80);
//
//                    pushFollow(FOLLOW_switch_case_list_in_statement868);
//                    switch_case_list81=switch_case_list();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) stream_switch_case_list.add(switch_case_list81.getTree());
//
//
//                    // AST REWRITE
//                    // elements: switch_case_list, expression, 77
//                    // token labels: 
//                    // rule labels: retval
//                    // token list labels: 
//                    // rule list labels: 
//                    // wildcard labels: 
//                    if ( state.backtracking==0 ) {
//                    retval.tree = root_0;
//                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//                    root_0 = (CommonTree)adaptor.nil();
//                    // 151:50: -> ^( 'switch' ^( CONDITION expression ) switch_case_list )
//                    {
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:151:53: ^( 'switch' ^( CONDITION expression ) switch_case_list )
//                        {
//                        CommonTree root_1 = (CommonTree)adaptor.nil();
//                        root_1 = (CommonTree)adaptor.becomeRoot(stream_77.nextNode(), root_1);
//
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:151:64: ^( CONDITION expression )
//                        {
//                        CommonTree root_2 = (CommonTree)adaptor.nil();
//                        root_2 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(CONDITION, "CONDITION"), root_2);
//
//                        adaptor.addChild(root_2, stream_expression.nextTree());
//
//                        adaptor.addChild(root_1, root_2);
//                        }
//                        adaptor.addChild(root_1, stream_switch_case_list.nextTree());
//
//                        adaptor.addChild(root_0, root_1);
//                        }
//
//                    }
//
//                    retval.tree = root_0;}
//                    }
//                    break;
//                case 7 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:152:5: 'break' ( expression )? ';'
//                    {
//                    string_literal82=(Token)match(input,78,FOLLOW_78_in_statement888); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_78.add(string_literal82);
//
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:152:13: ( expression )?
//                    int alt25=2;
//                    int LA25_0 = input.LA(1);
//
//                    if ( ((LA25_0>=IDENTIFIER && LA25_0<=DOUBLELITERRAL)||LA25_0==61||(LA25_0>=72 && LA25_0<=73)||(LA25_0>=142 && LA25_0<=143)||(LA25_0>=154 && LA25_0<=155)||(LA25_0>=157 && LA25_0<=161)||(LA25_0>=163 && LA25_0<=166)||LA25_0==168||(LA25_0>=171 && LA25_0<=176)) ) {
//                        alt25=1;
//                    }
//                    switch (alt25) {
//                        case 1 :
//                            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:152:13: expression
//                            {
//                            pushFollow(FOLLOW_expression_in_statement890);
//                            expression83=expression();
//
//                            state._fsp--;
//                            if (state.failed) return retval;
//                            if ( state.backtracking==0 ) stream_expression.add(expression83.getTree());
//
//                            }
//                            break;
//
//                    }
//
//                    char_literal84=(Token)match(input,63,FOLLOW_63_in_statement893); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_63.add(char_literal84);
//
//
//
//                    // AST REWRITE
//                    // elements: 78, expression
//                    // token labels: 
//                    // rule labels: retval
//                    // token list labels: 
//                    // rule list labels: 
//                    // wildcard labels: 
//                    if ( state.backtracking==0 ) {
//                    retval.tree = root_0;
//                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//                    root_0 = (CommonTree)adaptor.nil();
//                    // 152:35: -> ^( 'break' ( expression )? )
//                    {
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:152:38: ^( 'break' ( expression )? )
//                        {
//                        CommonTree root_1 = (CommonTree)adaptor.nil();
//                        root_1 = (CommonTree)adaptor.becomeRoot(stream_78.nextNode(), root_1);
//
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:152:48: ( expression )?
//                        if ( stream_expression.hasNext() ) {
//                            adaptor.addChild(root_1, stream_expression.nextTree());
//
//                        }
//                        stream_expression.reset();
//
//                        adaptor.addChild(root_0, root_1);
//                        }
//
//                    }
//
//                    retval.tree = root_0;}
//                    }
//                    break;
//                case 8 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:153:5: 'continue' ( expression )? ';'
//                    {
//                    string_literal85=(Token)match(input,79,FOLLOW_79_in_statement914); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_79.add(string_literal85);
//
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:153:16: ( expression )?
//                    int alt26=2;
//                    int LA26_0 = input.LA(1);
//
//                    if ( ((LA26_0>=IDENTIFIER && LA26_0<=DOUBLELITERRAL)||LA26_0==61||(LA26_0>=72 && LA26_0<=73)||(LA26_0>=142 && LA26_0<=143)||(LA26_0>=154 && LA26_0<=155)||(LA26_0>=157 && LA26_0<=161)||(LA26_0>=163 && LA26_0<=166)||LA26_0==168||(LA26_0>=171 && LA26_0<=176)) ) {
//                        alt26=1;
//                    }
//                    switch (alt26) {
//                        case 1 :
//                            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:153:16: expression
//                            {
//                            pushFollow(FOLLOW_expression_in_statement916);
//                            expression86=expression();
//
//                            state._fsp--;
//                            if (state.failed) return retval;
//                            if ( state.backtracking==0 ) stream_expression.add(expression86.getTree());
//
//                            }
//                            break;
//
//                    }
//
//                    char_literal87=(Token)match(input,63,FOLLOW_63_in_statement919); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_63.add(char_literal87);
//
//
//
//                    // AST REWRITE
//                    // elements: 79, expression
//                    // token labels: 
//                    // rule labels: retval
//                    // token list labels: 
//                    // rule list labels: 
//                    // wildcard labels: 
//                    if ( state.backtracking==0 ) {
//                    retval.tree = root_0;
//                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//                    root_0 = (CommonTree)adaptor.nil();
//                    // 153:37: -> ^( 'continue' ( expression )? )
//                    {
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:153:40: ^( 'continue' ( expression )? )
//                        {
//                        CommonTree root_1 = (CommonTree)adaptor.nil();
//                        root_1 = (CommonTree)adaptor.becomeRoot(stream_79.nextNode(), root_1);
//
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:153:53: ( expression )?
//                        if ( stream_expression.hasNext() ) {
//                            adaptor.addChild(root_1, stream_expression.nextTree());
//
//                        }
//                        stream_expression.reset();
//
//                        adaptor.addChild(root_0, root_1);
//                        }
//
//                    }
//
//                    retval.tree = root_0;}
//                    }
//                    break;
//                case 9 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:154:5: 'return' ( expression )? ';'
//                    {
//                    string_literal88=(Token)match(input,80,FOLLOW_80_in_statement939); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_80.add(string_literal88);
//
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:154:14: ( expression )?
//                    int alt27=2;
//                    int LA27_0 = input.LA(1);
//
//                    if ( ((LA27_0>=IDENTIFIER && LA27_0<=DOUBLELITERRAL)||LA27_0==61||(LA27_0>=72 && LA27_0<=73)||(LA27_0>=142 && LA27_0<=143)||(LA27_0>=154 && LA27_0<=155)||(LA27_0>=157 && LA27_0<=161)||(LA27_0>=163 && LA27_0<=166)||LA27_0==168||(LA27_0>=171 && LA27_0<=176)) ) {
//                        alt27=1;
//                    }
//                    switch (alt27) {
//                        case 1 :
//                            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:154:14: expression
//                            {
//                            pushFollow(FOLLOW_expression_in_statement941);
//                            expression89=expression();
//
//                            state._fsp--;
//                            if (state.failed) return retval;
//                            if ( state.backtracking==0 ) stream_expression.add(expression89.getTree());
//
//                            }
//                            break;
//
//                    }
//
//                    char_literal90=(Token)match(input,63,FOLLOW_63_in_statement944); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_63.add(char_literal90);
//
//
//
//                    // AST REWRITE
//                    // elements: 80, expression
//                    // token labels: 
//                    // rule labels: retval
//                    // token list labels: 
//                    // rule list labels: 
//                    // wildcard labels: 
//                    if ( state.backtracking==0 ) {
//                    retval.tree = root_0;
//                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//                    root_0 = (CommonTree)adaptor.nil();
//                    // 154:35: -> ^( 'return' ( expression )? )
//                    {
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:154:38: ^( 'return' ( expression )? )
//                        {
//                        CommonTree root_1 = (CommonTree)adaptor.nil();
//                        root_1 = (CommonTree)adaptor.becomeRoot(stream_80.nextNode(), root_1);
//
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:154:49: ( expression )?
//                        if ( stream_expression.hasNext() ) {
//                            adaptor.addChild(root_1, stream_expression.nextTree());
//
//                        }
//                        stream_expression.reset();
//
//                        adaptor.addChild(root_0, root_1);
//                        }
//
//                    }
//
//                    retval.tree = root_0;}
//                    }
//                    break;
//                case 10 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:155:5: 'global' variable_list ';'
//                    {
//                    string_literal91=(Token)match(input,81,FOLLOW_81_in_statement964); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_81.add(string_literal91);
//
//                    pushFollow(FOLLOW_variable_list_in_statement966);
//                    variable_list92=variable_list();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) stream_variable_list.add(variable_list92.getTree());
//                    char_literal93=(Token)match(input,63,FOLLOW_63_in_statement968); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_63.add(char_literal93);
//
//
//
//                    // AST REWRITE
//                    // elements: 81, variable_list
//                    // token labels: 
//                    // rule labels: retval
//                    // token list labels: 
//                    // rule list labels: 
//                    // wildcard labels: 
//                    if ( state.backtracking==0 ) {
//                    retval.tree = root_0;
//                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//                    root_0 = (CommonTree)adaptor.nil();
//                    // 155:37: -> ^( 'global' variable_list )
//                    {
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:155:40: ^( 'global' variable_list )
//                        {
//                        CommonTree root_1 = (CommonTree)adaptor.nil();
//                        root_1 = (CommonTree)adaptor.becomeRoot(stream_81.nextNode(), root_1);
//
//                        adaptor.addChild(root_1, stream_variable_list.nextTree());
//
//                        adaptor.addChild(root_0, root_1);
//                        }
//
//                    }
//
//                    retval.tree = root_0;}
//                    }
//                    break;
//                case 11 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:156:5: 'static' static_var_list ';'
//                    {
//                    string_literal94=(Token)match(input,82,FOLLOW_82_in_statement987); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_82.add(string_literal94);
//
//                    pushFollow(FOLLOW_static_var_list_in_statement989);
//                    static_var_list95=static_var_list();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) stream_static_var_list.add(static_var_list95.getTree());
//                    char_literal96=(Token)match(input,63,FOLLOW_63_in_statement991); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_63.add(char_literal96);
//
//
//
//                    // AST REWRITE
//                    // elements: 82, static_var_list
//                    // token labels: 
//                    // rule labels: retval
//                    // token list labels: 
//                    // rule list labels: 
//                    // wildcard labels: 
//                    if ( state.backtracking==0 ) {
//                    retval.tree = root_0;
//                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//                    root_0 = (CommonTree)adaptor.nil();
//                    // 156:38: -> ^( 'static' static_var_list )
//                    {
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:156:41: ^( 'static' static_var_list )
//                        {
//                        CommonTree root_1 = (CommonTree)adaptor.nil();
//                        root_1 = (CommonTree)adaptor.becomeRoot(stream_82.nextNode(), root_1);
//
//                        adaptor.addChild(root_1, stream_static_var_list.nextTree());
//
//                        adaptor.addChild(root_0, root_1);
//                        }
//
//                    }
//
//                    retval.tree = root_0;}
//                    }
//                    break;
//                case 12 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:157:5: 'echo' expr_list ';'
//                    {
//                    string_literal97=(Token)match(input,83,FOLLOW_83_in_statement1009); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_83.add(string_literal97);
//
//                    pushFollow(FOLLOW_expr_list_in_statement1011);
//                    expr_list98=expr_list();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) stream_expr_list.add(expr_list98.getTree());
//                    char_literal99=(Token)match(input,63,FOLLOW_63_in_statement1013); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_63.add(char_literal99);
//
//
//
//                    // AST REWRITE
//                    // elements: expr_list, 83
//                    // token labels: 
//                    // rule labels: retval
//                    // token list labels: 
//                    // rule list labels: 
//                    // wildcard labels: 
//                    if ( state.backtracking==0 ) {
//                    retval.tree = root_0;
//                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//                    root_0 = (CommonTree)adaptor.nil();
//                    // 157:32: -> ^( 'echo' expr_list )
//                    {
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:157:35: ^( 'echo' expr_list )
//                        {
//                        CommonTree root_1 = (CommonTree)adaptor.nil();
//                        root_1 = (CommonTree)adaptor.becomeRoot(stream_83.nextNode(), root_1);
//
//                        adaptor.addChild(root_1, stream_expr_list.nextTree());
//
//                        adaptor.addChild(root_0, root_1);
//                        }
//
//                    }
//
//                    retval.tree = root_0;}
//                    }
//                    break;
//                case 13 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:158:5: expression ';'
//                    {
//                    root_0 = (CommonTree)adaptor.nil();
//
//                    pushFollow(FOLLOW_expression_in_statement1033);
//                    expression100=expression();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) adaptor.addChild(root_0, expression100.getTree());
//                    char_literal101=(Token)match(input,63,FOLLOW_63_in_statement1035); if (state.failed) return retval;
//
//                    }
//                    break;
//                case 14 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:159:5: 'foreach' '(' expression 'as' foreach_variable ')' foreach_statement
//                    {
//                    string_literal102=(Token)match(input,84,FOLLOW_84_in_statement1042); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_84.add(string_literal102);
//
//                    char_literal103=(Token)match(input,61,FOLLOW_61_in_statement1044); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_61.add(char_literal103);
//
//                    pushFollow(FOLLOW_expression_in_statement1046);
//                    expression104=expression();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) stream_expression.add(expression104.getTree());
//                    string_literal105=(Token)match(input,85,FOLLOW_85_in_statement1048); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_85.add(string_literal105);
//
//                    pushFollow(FOLLOW_foreach_variable_in_statement1050);
//                    foreach_variable106=foreach_variable();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) stream_foreach_variable.add(foreach_variable106.getTree());
//                    char_literal107=(Token)match(input,62,FOLLOW_62_in_statement1052); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_62.add(char_literal107);
//
//                    pushFollow(FOLLOW_foreach_statement_in_statement1062);
//                    foreach_statement108=foreach_statement();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) stream_foreach_statement.add(foreach_statement108.getTree());
//
//
//                    // AST REWRITE
//                    // elements: 84, foreach_statement, 85, foreach_variable, expression
//                    // token labels: 
//                    // rule labels: retval
//                    // token list labels: 
//                    // rule list labels: 
//                    // wildcard labels: 
//                    if ( state.backtracking==0 ) {
//                    retval.tree = root_0;
//                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//                    root_0 = (CommonTree)adaptor.nil();
//                    // 161:6: -> ^( 'foreach' ^( 'as' expression foreach_variable ) foreach_statement )
//                    {
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:161:9: ^( 'foreach' ^( 'as' expression foreach_variable ) foreach_statement )
//                        {
//                        CommonTree root_1 = (CommonTree)adaptor.nil();
//                        root_1 = (CommonTree)adaptor.becomeRoot(stream_84.nextNode(), root_1);
//
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:161:21: ^( 'as' expression foreach_variable )
//                        {
//                        CommonTree root_2 = (CommonTree)adaptor.nil();
//                        root_2 = (CommonTree)adaptor.becomeRoot(stream_85.nextNode(), root_2);
//
//                        adaptor.addChild(root_2, stream_expression.nextTree());
//                        adaptor.addChild(root_2, stream_foreach_variable.nextTree());
//
//                        adaptor.addChild(root_1, root_2);
//                        }
//                        adaptor.addChild(root_1, stream_foreach_statement.nextTree());
//
//                        adaptor.addChild(root_0, root_1);
//                        }
//
//                    }
//
//                    retval.tree = root_0;}
//                    }
//                    break;
//                case 15 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:162:5: 'declare' '(' directive ')' declare_statement
//                    {
//                    string_literal109=(Token)match(input,86,FOLLOW_86_in_statement1089); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_86.add(string_literal109);
//
//                    char_literal110=(Token)match(input,61,FOLLOW_61_in_statement1091); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_61.add(char_literal110);
//
//                    pushFollow(FOLLOW_directive_in_statement1093);
//                    directive111=directive();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) stream_directive.add(directive111.getTree());
//                    char_literal112=(Token)match(input,62,FOLLOW_62_in_statement1095); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_62.add(char_literal112);
//
//                    pushFollow(FOLLOW_declare_statement_in_statement1097);
//                    declare_statement113=declare_statement();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) stream_declare_statement.add(declare_statement113.getTree());
//
//
//                    // AST REWRITE
//                    // elements: 86, declare_statement, directive
//                    // token labels: 
//                    // rule labels: retval
//                    // token list labels: 
//                    // rule list labels: 
//                    // wildcard labels: 
//                    if ( state.backtracking==0 ) {
//                    retval.tree = root_0;
//                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//                    root_0 = (CommonTree)adaptor.nil();
//                    // 162:51: -> ^( 'declare' ^( CONDITION directive ) ( declare_statement )? )
//                    {
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:162:54: ^( 'declare' ^( CONDITION directive ) ( declare_statement )? )
//                        {
//                        CommonTree root_1 = (CommonTree)adaptor.nil();
//                        root_1 = (CommonTree)adaptor.becomeRoot(stream_86.nextNode(), root_1);
//
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:162:66: ^( CONDITION directive )
//                        {
//                        CommonTree root_2 = (CommonTree)adaptor.nil();
//                        root_2 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(CONDITION, "CONDITION"), root_2);
//
//                        adaptor.addChild(root_2, stream_directive.nextTree());
//
//                        adaptor.addChild(root_1, root_2);
//                        }
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:162:89: ( declare_statement )?
//                        if ( stream_declare_statement.hasNext() ) {
//                            adaptor.addChild(root_1, stream_declare_statement.nextTree());
//
//                        }
//                        stream_declare_statement.reset();
//
//                        adaptor.addChild(root_0, root_1);
//                        }
//
//                    }
//
//                    retval.tree = root_0;}
//                    }
//                    break;
//                case 16 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:163:5: ';'
//                    {
//                    char_literal114=(Token)match(input,63,FOLLOW_63_in_statement1118); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_63.add(char_literal114);
//
//
//
//                    // AST REWRITE
//                    // elements: 
//                    // token labels: 
//                    // rule labels: retval
//                    // token list labels: 
//                    // rule list labels: 
//                    // wildcard labels: 
//                    if ( state.backtracking==0 ) {
//                    retval.tree = root_0;
//                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//                    root_0 = (CommonTree)adaptor.nil();
//                    // 163:20: -> ^( EMPTYSTATEMENT )
//                    {
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:163:23: ^( EMPTYSTATEMENT )
//                        {
//                        CommonTree root_1 = (CommonTree)adaptor.nil();
//                        root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(EMPTYSTATEMENT, "EMPTYSTATEMENT"), root_1);
//
//                        adaptor.addChild(root_0, root_1);
//                        }
//
//                    }
//
//                    retval.tree = root_0;}
//                    }
//                    break;
//                case 17 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:164:5: 'try' '{' top_statement '}' ( catch_branch )+
//                    {
//                    string_literal115=(Token)match(input,87,FOLLOW_87_in_statement1141); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_87.add(string_literal115);
//
//                    char_literal116=(Token)match(input,67,FOLLOW_67_in_statement1143); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_67.add(char_literal116);
//
//                    pushFollow(FOLLOW_top_statement_in_statement1145);
//                    top_statement117=top_statement();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) stream_top_statement.add(top_statement117.getTree());
//                    char_literal118=(Token)match(input,68,FOLLOW_68_in_statement1147); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_68.add(char_literal118);
//
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:164:33: ( catch_branch )+
//                    int cnt28=0;
//                    loop28:
//                    do {
//                        int alt28=2;
//                        int LA28_0 = input.LA(1);
//
//                        if ( (LA28_0==103) ) {
//                            alt28=1;
//                        }
//
//
//                        switch (alt28) {
//                    	case 1 :
//                    	    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:164:33: catch_branch
//                    	    {
//                    	    pushFollow(FOLLOW_catch_branch_in_statement1149);
//                    	    catch_branch119=catch_branch();
//
//                    	    state._fsp--;
//                    	    if (state.failed) return retval;
//                    	    if ( state.backtracking==0 ) stream_catch_branch.add(catch_branch119.getTree());
//
//                    	    }
//                    	    break;
//
//                    	default :
//                    	    if ( cnt28 >= 1 ) break loop28;
//                    	    if (state.backtracking>0) {state.failed=true; return retval;}
//                                EarlyExitException eee =
//                                    new EarlyExitException(28, input);
//                                throw eee;
//                        }
//                        cnt28++;
//                    } while (true);
//
//
//
//                    // AST REWRITE
//                    // elements: 87, top_statement, catch_branch
//                    // token labels: 
//                    // rule labels: retval
//                    // token list labels: 
//                    // rule list labels: 
//                    // wildcard labels: 
//                    if ( state.backtracking==0 ) {
//                    retval.tree = root_0;
//                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//                    root_0 = (CommonTree)adaptor.nil();
//                    // 164:48: -> ^( 'try' ^( BLOCK top_statement ) ( catch_branch )+ )
//                    {
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:164:51: ^( 'try' ^( BLOCK top_statement ) ( catch_branch )+ )
//                        {
//                        CommonTree root_1 = (CommonTree)adaptor.nil();
//                        root_1 = (CommonTree)adaptor.becomeRoot(stream_87.nextNode(), root_1);
//
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:164:59: ^( BLOCK top_statement )
//                        {
//                        CommonTree root_2 = (CommonTree)adaptor.nil();
//                        root_2 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(BLOCK, "BLOCK"), root_2);
//
//                        adaptor.addChild(root_2, stream_top_statement.nextTree());
//
//                        adaptor.addChild(root_1, root_2);
//                        }
//                        if ( !(stream_catch_branch.hasNext()) ) {
//                            throw new RewriteEarlyExitException();
//                        }
//                        while ( stream_catch_branch.hasNext() ) {
//                            adaptor.addChild(root_1, stream_catch_branch.nextTree());
//
//                        }
//                        stream_catch_branch.reset();
//
//                        adaptor.addChild(root_0, root_1);
//                        }
//
//                    }
//
//                    retval.tree = root_0;}
//                    }
//                    break;
//                case 18 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:165:5: 'throw' expression ';'
//                    {
//                    string_literal120=(Token)match(input,88,FOLLOW_88_in_statement1172); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_88.add(string_literal120);
//
//                    pushFollow(FOLLOW_expression_in_statement1174);
//                    expression121=expression();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) stream_expression.add(expression121.getTree());
//                    char_literal122=(Token)match(input,63,FOLLOW_63_in_statement1176); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_63.add(char_literal122);
//
//
//
//                    // AST REWRITE
//                    // elements: 88, expression
//                    // token labels: 
//                    // rule labels: retval
//                    // token list labels: 
//                    // rule list labels: 
//                    // wildcard labels: 
//                    if ( state.backtracking==0 ) {
//                    retval.tree = root_0;
//                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//                    root_0 = (CommonTree)adaptor.nil();
//                    // 165:34: -> ^( 'throw' expression )
//                    {
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:165:37: ^( 'throw' expression )
//                        {
//                        CommonTree root_1 = (CommonTree)adaptor.nil();
//                        root_1 = (CommonTree)adaptor.becomeRoot(stream_88.nextNode(), root_1);
//
//                        adaptor.addChild(root_1, stream_expression.nextTree());
//
//                        adaptor.addChild(root_0, root_1);
//                        }
//
//                    }
//
//                    retval.tree = root_0;}
//                    }
//                    break;
//                case 19 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:166:5: 'use' use_filename ';'
//                    {
//                    string_literal123=(Token)match(input,89,FOLLOW_89_in_statement1196); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_89.add(string_literal123);
//
//                    pushFollow(FOLLOW_use_filename_in_statement1198);
//                    use_filename124=use_filename();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) stream_use_filename.add(use_filename124.getTree());
//                    char_literal125=(Token)match(input,63,FOLLOW_63_in_statement1200); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_63.add(char_literal125);
//
//
//
//                    // AST REWRITE
//                    // elements: use_filename, 89
//                    // token labels: 
//                    // rule labels: retval
//                    // token list labels: 
//                    // rule list labels: 
//                    // wildcard labels: 
//                    if ( state.backtracking==0 ) {
//                    retval.tree = root_0;
//                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//                    root_0 = (CommonTree)adaptor.nil();
//                    // 166:34: -> ^( 'use' use_filename )
//                    {
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:166:37: ^( 'use' use_filename )
//                        {
//                        CommonTree root_1 = (CommonTree)adaptor.nil();
//                        root_1 = (CommonTree)adaptor.becomeRoot(stream_89.nextNode(), root_1);
//
//                        adaptor.addChild(root_1, stream_use_filename.nextTree());
//
//                        adaptor.addChild(root_0, root_1);
//                        }
//
//                    }
//
//                    retval.tree = root_0;}
//                    }
//                    break;
//
//            }
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "statement"
//
//    public static class foreach_variable_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "foreach_variable"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:172:1: foreach_variable : (v1= variable -> variable ) ( '=>' v2= variable -> ^( '=>' $v1 $v2) )? ;
//    public final CompilerAstParser.foreach_variable_return foreach_variable() throws RecognitionException {
//        CompilerAstParser.foreach_variable_return retval = new CompilerAstParser.foreach_variable_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token string_literal126=null;
//        CompilerAstParser.variable_return v1 = null;
//
//        CompilerAstParser.variable_return v2 = null;
//
//
//        CommonTree string_literal126_tree=null;
//        RewriteRuleTokenStream stream_90=new RewriteRuleTokenStream(adaptor,"token 90");
//        RewriteRuleSubtreeStream stream_variable=new RewriteRuleSubtreeStream(adaptor,"rule variable");
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:173:2: ( (v1= variable -> variable ) ( '=>' v2= variable -> ^( '=>' $v1 $v2) )? )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:173:4: (v1= variable -> variable ) ( '=>' v2= variable -> ^( '=>' $v1 $v2) )?
//            {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:173:4: (v1= variable -> variable )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:173:5: v1= variable
//            {
//            pushFollow(FOLLOW_variable_in_foreach_variable1234);
//            v1=variable();
//
//            state._fsp--;
//            if (state.failed) return retval;
//            if ( state.backtracking==0 ) stream_variable.add(v1.getTree());
//
//
//            // AST REWRITE
//            // elements: variable
//            // token labels: 
//            // rule labels: retval
//            // token list labels: 
//            // rule list labels: 
//            // wildcard labels: 
//            if ( state.backtracking==0 ) {
//            retval.tree = root_0;
//            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//            root_0 = (CommonTree)adaptor.nil();
//            // 173:17: -> variable
//            {
//                adaptor.addChild(root_0, stream_variable.nextTree());
//
//            }
//
//            retval.tree = root_0;}
//            }
//
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:174:3: ( '=>' v2= variable -> ^( '=>' $v1 $v2) )?
//            int alt30=2;
//            int LA30_0 = input.LA(1);
//
//            if ( (LA30_0==90) ) {
//                alt30=1;
//            }
//            switch (alt30) {
//                case 1 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:174:4: '=>' v2= variable
//                    {
//                    string_literal126=(Token)match(input,90,FOLLOW_90_in_foreach_variable1244); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_90.add(string_literal126);
//
//                    pushFollow(FOLLOW_variable_in_foreach_variable1248);
//                    v2=variable();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) stream_variable.add(v2.getTree());
//
//
//                    // AST REWRITE
//                    // elements: v1, v2, 90
//                    // token labels: 
//                    // rule labels: v1, retval, v2
//                    // token list labels: 
//                    // rule list labels: 
//                    // wildcard labels: 
//                    if ( state.backtracking==0 ) {
//                    retval.tree = root_0;
//                    RewriteRuleSubtreeStream stream_v1=new RewriteRuleSubtreeStream(adaptor,"rule v1",v1!=null?v1.tree:null);
//                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//                    RewriteRuleSubtreeStream stream_v2=new RewriteRuleSubtreeStream(adaptor,"rule v2",v2!=null?v2.tree:null);
//
//                    root_0 = (CommonTree)adaptor.nil();
//                    // 174:21: -> ^( '=>' $v1 $v2)
//                    {
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:174:24: ^( '=>' $v1 $v2)
//                        {
//                        CommonTree root_1 = (CommonTree)adaptor.nil();
//                        root_1 = (CommonTree)adaptor.becomeRoot(stream_90.nextNode(), root_1);
//
//                        adaptor.addChild(root_1, stream_v1.nextTree());
//                        adaptor.addChild(root_1, stream_v2.nextTree());
//
//                        adaptor.addChild(root_0, root_1);
//                        }
//
//                    }
//
//                    retval.tree = root_0;}
//                    }
//                    break;
//
//            }
//
//
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "foreach_variable"
//
//    public static class use_filename_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "use_filename"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:177:1: use_filename : ( STRINGLITERAL | '(' STRINGLITERAL ')' );
//    public final CompilerAstParser.use_filename_return use_filename() throws RecognitionException {
//        CompilerAstParser.use_filename_return retval = new CompilerAstParser.use_filename_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token STRINGLITERAL127=null;
//        Token char_literal128=null;
//        Token STRINGLITERAL129=null;
//        Token char_literal130=null;
//
//        CommonTree STRINGLITERAL127_tree=null;
//        CommonTree char_literal128_tree=null;
//        CommonTree STRINGLITERAL129_tree=null;
//        CommonTree char_literal130_tree=null;
//
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:178:2: ( STRINGLITERAL | '(' STRINGLITERAL ')' )
//            int alt31=2;
//            int LA31_0 = input.LA(1);
//
//            if ( (LA31_0==STRINGLITERAL) ) {
//                alt31=1;
//            }
//            else if ( (LA31_0==61) ) {
//                alt31=2;
//            }
//            else {
//                if (state.backtracking>0) {state.failed=true; return retval;}
//                NoViableAltException nvae =
//                    new NoViableAltException("", 31, 0, input);
//
//                throw nvae;
//            }
//            switch (alt31) {
//                case 1 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:178:4: STRINGLITERAL
//                    {
//                    root_0 = (CommonTree)adaptor.nil();
//
//                    STRINGLITERAL127=(Token)match(input,STRINGLITERAL,FOLLOW_STRINGLITERAL_in_use_filename1275); if (state.failed) return retval;
//                    if ( state.backtracking==0 ) {
//                    STRINGLITERAL127_tree = (CommonTree)adaptor.create(STRINGLITERAL127);
//                    adaptor.addChild(root_0, STRINGLITERAL127_tree);
//                    }
//
//                    }
//                    break;
//                case 2 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:179:4: '(' STRINGLITERAL ')'
//                    {
//                    root_0 = (CommonTree)adaptor.nil();
//
//                    char_literal128=(Token)match(input,61,FOLLOW_61_in_use_filename1280); if (state.failed) return retval;
//                    STRINGLITERAL129=(Token)match(input,STRINGLITERAL,FOLLOW_STRINGLITERAL_in_use_filename1283); if (state.failed) return retval;
//                    if ( state.backtracking==0 ) {
//                    STRINGLITERAL129_tree = (CommonTree)adaptor.create(STRINGLITERAL129);
//                    adaptor.addChild(root_0, STRINGLITERAL129_tree);
//                    }
//                    char_literal130=(Token)match(input,62,FOLLOW_62_in_use_filename1285); if (state.failed) return retval;
//
//                    }
//                    break;
//
//            }
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "use_filename"
//
//    public static class method_declaration_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "method_declaration"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:182:1: method_declaration : 'function' ( '&' )? IDENTIFIER '(' ( parameter_list )? ')' ( ';' -> ^( 'function' ( '&' )? IDENTIFIER ( parameter_list )? EMPTYSTATEMENT ) | block -> ^( 'function' ( '&' )? IDENTIFIER ( parameter_list )? block ) ) ;
//    public final CompilerAstParser.method_declaration_return method_declaration() throws RecognitionException {
//        CompilerAstParser.method_declaration_return retval = new CompilerAstParser.method_declaration_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token string_literal131=null;
//        Token char_literal132=null;
//        Token IDENTIFIER133=null;
//        Token char_literal134=null;
//        Token char_literal136=null;
//        Token char_literal137=null;
//        CompilerAstParser.parameter_list_return parameter_list135 = null;
//
//        CompilerAstParser.block_return block138 = null;
//
//
//        CommonTree string_literal131_tree=null;
//        CommonTree char_literal132_tree=null;
//        CommonTree IDENTIFIER133_tree=null;
//        CommonTree char_literal134_tree=null;
//        CommonTree char_literal136_tree=null;
//        CommonTree char_literal137_tree=null;
//        RewriteRuleTokenStream stream_62=new RewriteRuleTokenStream(adaptor,"token 62");
//        RewriteRuleTokenStream stream_72=new RewriteRuleTokenStream(adaptor,"token 72");
//        RewriteRuleTokenStream stream_IDENTIFIER=new RewriteRuleTokenStream(adaptor,"token IDENTIFIER");
//        RewriteRuleTokenStream stream_63=new RewriteRuleTokenStream(adaptor,"token 63");
//        RewriteRuleTokenStream stream_73=new RewriteRuleTokenStream(adaptor,"token 73");
//        RewriteRuleTokenStream stream_61=new RewriteRuleTokenStream(adaptor,"token 61");
//        RewriteRuleSubtreeStream stream_block=new RewriteRuleSubtreeStream(adaptor,"rule block");
//        RewriteRuleSubtreeStream stream_parameter_list=new RewriteRuleSubtreeStream(adaptor,"rule parameter_list");
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:183:3: ( 'function' ( '&' )? IDENTIFIER '(' ( parameter_list )? ')' ( ';' -> ^( 'function' ( '&' )? IDENTIFIER ( parameter_list )? EMPTYSTATEMENT ) | block -> ^( 'function' ( '&' )? IDENTIFIER ( parameter_list )? block ) ) )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:183:5: 'function' ( '&' )? IDENTIFIER '(' ( parameter_list )? ')' ( ';' -> ^( 'function' ( '&' )? IDENTIFIER ( parameter_list )? EMPTYSTATEMENT ) | block -> ^( 'function' ( '&' )? IDENTIFIER ( parameter_list )? block ) )
//            {
//            string_literal131=(Token)match(input,72,FOLLOW_72_in_method_declaration1300); if (state.failed) return retval; 
//            if ( state.backtracking==0 ) stream_72.add(string_literal131);
//
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:183:16: ( '&' )?
//            int alt32=2;
//            int LA32_0 = input.LA(1);
//
//            if ( (LA32_0==73) ) {
//                alt32=1;
//            }
//            switch (alt32) {
//                case 1 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:183:16: '&'
//                    {
//                    char_literal132=(Token)match(input,73,FOLLOW_73_in_method_declaration1302); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_73.add(char_literal132);
//
//
//                    }
//                    break;
//
//            }
//
//            IDENTIFIER133=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_method_declaration1305); if (state.failed) return retval; 
//            if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER133);
//
//            char_literal134=(Token)match(input,61,FOLLOW_61_in_method_declaration1307); if (state.failed) return retval; 
//            if ( state.backtracking==0 ) stream_61.add(char_literal134);
//
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:183:36: ( parameter_list )?
//            int alt33=2;
//            int LA33_0 = input.LA(1);
//
//            if ( (LA33_0==IDENTIFIER||LA33_0==73||LA33_0==91||(LA33_0>=147 && LA33_0<=157)||LA33_0==168) ) {
//                alt33=1;
//            }
//            switch (alt33) {
//                case 1 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:183:36: parameter_list
//                    {
//                    pushFollow(FOLLOW_parameter_list_in_method_declaration1309);
//                    parameter_list135=parameter_list();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) stream_parameter_list.add(parameter_list135.getTree());
//
//                    }
//                    break;
//
//            }
//
//            char_literal136=(Token)match(input,62,FOLLOW_62_in_method_declaration1312); if (state.failed) return retval; 
//            if ( state.backtracking==0 ) stream_62.add(char_literal136);
//
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:184:4: ( ';' -> ^( 'function' ( '&' )? IDENTIFIER ( parameter_list )? EMPTYSTATEMENT ) | block -> ^( 'function' ( '&' )? IDENTIFIER ( parameter_list )? block ) )
//            int alt34=2;
//            int LA34_0 = input.LA(1);
//
//            if ( (LA34_0==63) ) {
//                alt34=1;
//            }
//            else if ( (LA34_0==67) ) {
//                alt34=2;
//            }
//            else {
//                if (state.backtracking>0) {state.failed=true; return retval;}
//                NoViableAltException nvae =
//                    new NoViableAltException("", 34, 0, input);
//
//                throw nvae;
//            }
//            switch (alt34) {
//                case 1 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:185:4: ';'
//                    {
//                    char_literal137=(Token)match(input,63,FOLLOW_63_in_method_declaration1323); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_63.add(char_literal137);
//
//
//
//                    // AST REWRITE
//                    // elements: parameter_list, 72, 73, IDENTIFIER
//                    // token labels: 
//                    // rule labels: retval
//                    // token list labels: 
//                    // rule list labels: 
//                    // wildcard labels: 
//                    if ( state.backtracking==0 ) {
//                    retval.tree = root_0;
//                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//                    root_0 = (CommonTree)adaptor.nil();
//                    // 185:9: -> ^( 'function' ( '&' )? IDENTIFIER ( parameter_list )? EMPTYSTATEMENT )
//                    {
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:185:12: ^( 'function' ( '&' )? IDENTIFIER ( parameter_list )? EMPTYSTATEMENT )
//                        {
//                        CommonTree root_1 = (CommonTree)adaptor.nil();
//                        root_1 = (CommonTree)adaptor.becomeRoot(stream_72.nextNode(), root_1);
//
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:185:25: ( '&' )?
//                        if ( stream_73.hasNext() ) {
//                            adaptor.addChild(root_1, stream_73.nextNode());
//
//                        }
//                        stream_73.reset();
//                        adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:185:41: ( parameter_list )?
//                        if ( stream_parameter_list.hasNext() ) {
//                            adaptor.addChild(root_1, stream_parameter_list.nextTree());
//
//                        }
//                        stream_parameter_list.reset();
//                        adaptor.addChild(root_1, (CommonTree)adaptor.create(EMPTYSTATEMENT, "EMPTYSTATEMENT"));
//
//                        adaptor.addChild(root_0, root_1);
//                        }
//
//                    }
//
//                    retval.tree = root_0;}
//                    }
//                    break;
//                case 2 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:187:4: block
//                    {
//                    pushFollow(FOLLOW_block_in_method_declaration1350);
//                    block138=block();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) stream_block.add(block138.getTree());
//
//
//                    // AST REWRITE
//                    // elements: 72, block, IDENTIFIER, 73, parameter_list
//                    // token labels: 
//                    // rule labels: retval
//                    // token list labels: 
//                    // rule list labels: 
//                    // wildcard labels: 
//                    if ( state.backtracking==0 ) {
//                    retval.tree = root_0;
//                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//                    root_0 = (CommonTree)adaptor.nil();
//                    // 187:10: -> ^( 'function' ( '&' )? IDENTIFIER ( parameter_list )? block )
//                    {
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:187:13: ^( 'function' ( '&' )? IDENTIFIER ( parameter_list )? block )
//                        {
//                        CommonTree root_1 = (CommonTree)adaptor.nil();
//                        root_1 = (CommonTree)adaptor.becomeRoot(stream_72.nextNode(), root_1);
//
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:187:26: ( '&' )?
//                        if ( stream_73.hasNext() ) {
//                            adaptor.addChild(root_1, stream_73.nextNode());
//
//                        }
//                        stream_73.reset();
//                        adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:187:42: ( parameter_list )?
//                        if ( stream_parameter_list.hasNext() ) {
//                            adaptor.addChild(root_1, stream_parameter_list.nextTree());
//
//                        }
//                        stream_parameter_list.reset();
//                        adaptor.addChild(root_1, stream_block.nextTree());
//
//                        adaptor.addChild(root_0, root_1);
//                        }
//
//                    }
//
//                    retval.tree = root_0;}
//                    }
//                    break;
//
//            }
//
//
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "method_declaration"
//
//    public static class class_constant_declaration_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "class_constant_declaration"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:192:1: class_constant_declaration : 'const' directive -> ^( VAR_DECL 'const' directive ) ;
//    public final CompilerAstParser.class_constant_declaration_return class_constant_declaration() throws RecognitionException {
//        CompilerAstParser.class_constant_declaration_return retval = new CompilerAstParser.class_constant_declaration_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token string_literal139=null;
//        CompilerAstParser.directive_return directive140 = null;
//
//
//        CommonTree string_literal139_tree=null;
//        RewriteRuleTokenStream stream_91=new RewriteRuleTokenStream(adaptor,"token 91");
//        RewriteRuleSubtreeStream stream_directive=new RewriteRuleSubtreeStream(adaptor,"rule directive");
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:193:3: ( 'const' directive -> ^( VAR_DECL 'const' directive ) )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:193:5: 'const' directive
//            {
//            string_literal139=(Token)match(input,91,FOLLOW_91_in_class_constant_declaration1391); if (state.failed) return retval; 
//            if ( state.backtracking==0 ) stream_91.add(string_literal139);
//
//            pushFollow(FOLLOW_directive_in_class_constant_declaration1393);
//            directive140=directive();
//
//            state._fsp--;
//            if (state.failed) return retval;
//            if ( state.backtracking==0 ) stream_directive.add(directive140.getTree());
//
//
//            // AST REWRITE
//            // elements: 91, directive
//            // token labels: 
//            // rule labels: retval
//            // token list labels: 
//            // rule list labels: 
//            // wildcard labels: 
//            if ( state.backtracking==0 ) {
//            retval.tree = root_0;
//            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//            root_0 = (CommonTree)adaptor.nil();
//            // 194:4: -> ^( VAR_DECL 'const' directive )
//            {
//                // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:194:7: ^( VAR_DECL 'const' directive )
//                {
//                CommonTree root_1 = (CommonTree)adaptor.nil();
//                root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(VAR_DECL, "VAR_DECL"), root_1);
//
//                adaptor.addChild(root_1, stream_91.nextNode());
//                adaptor.addChild(root_1, stream_directive.nextTree());
//
//                adaptor.addChild(root_0, root_1);
//                }
//
//            }
//
//            retval.tree = root_0;}
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "class_constant_declaration"
//
//    public static class static_scalar_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "static_scalar"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:197:1: static_scalar : ( constant | IDENTIFIER ( '::' IDENTIFIER )* );
//    public final CompilerAstParser.static_scalar_return static_scalar() throws RecognitionException {
//        CompilerAstParser.static_scalar_return retval = new CompilerAstParser.static_scalar_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token IDENTIFIER142=null;
//        Token string_literal143=null;
//        Token IDENTIFIER144=null;
//        CompilerAstParser.constant_return constant141 = null;
//
//
//        CommonTree IDENTIFIER142_tree=null;
//        CommonTree string_literal143_tree=null;
//        CommonTree IDENTIFIER144_tree=null;
//
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:198:3: ( constant | IDENTIFIER ( '::' IDENTIFIER )* )
//            int alt36=2;
//            int LA36_0 = input.LA(1);
//
//            if ( (LA36_0==STRINGLITERAL||(LA36_0>=INTLITERAL && LA36_0<=DOUBLELITERRAL)||(LA36_0>=171 && LA36_0<=176)) ) {
//                alt36=1;
//            }
//            else if ( (LA36_0==IDENTIFIER) ) {
//                alt36=2;
//            }
//            else {
//                if (state.backtracking>0) {state.failed=true; return retval;}
//                NoViableAltException nvae =
//                    new NoViableAltException("", 36, 0, input);
//
//                throw nvae;
//            }
//            switch (alt36) {
//                case 1 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:198:5: constant
//                    {
//                    root_0 = (CommonTree)adaptor.nil();
//
//                    pushFollow(FOLLOW_constant_in_static_scalar1421);
//                    constant141=constant();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) adaptor.addChild(root_0, constant141.getTree());
//
//                    }
//                    break;
//                case 2 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:199:5: IDENTIFIER ( '::' IDENTIFIER )*
//                    {
//                    root_0 = (CommonTree)adaptor.nil();
//
//                    IDENTIFIER142=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_static_scalar1427); if (state.failed) return retval;
//                    if ( state.backtracking==0 ) {
//                    IDENTIFIER142_tree = (CommonTree)adaptor.create(IDENTIFIER142);
//                    adaptor.addChild(root_0, IDENTIFIER142_tree);
//                    }
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:199:16: ( '::' IDENTIFIER )*
//                    loop35:
//                    do {
//                        int alt35=2;
//                        int LA35_0 = input.LA(1);
//
//                        if ( (LA35_0==92) ) {
//                            alt35=1;
//                        }
//
//
//                        switch (alt35) {
//                    	case 1 :
//                    	    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:199:17: '::' IDENTIFIER
//                    	    {
//                    	    string_literal143=(Token)match(input,92,FOLLOW_92_in_static_scalar1430); if (state.failed) return retval;
//                    	    if ( state.backtracking==0 ) {
//                    	    string_literal143_tree = (CommonTree)adaptor.create(string_literal143);
//                    	    adaptor.addChild(root_0, string_literal143_tree);
//                    	    }
//                    	    IDENTIFIER144=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_static_scalar1432); if (state.failed) return retval;
//                    	    if ( state.backtracking==0 ) {
//                    	    IDENTIFIER144_tree = (CommonTree)adaptor.create(IDENTIFIER144);
//                    	    adaptor.addChild(root_0, IDENTIFIER144_tree);
//                    	    }
//
//                    	    }
//                    	    break;
//
//                    	default :
//                    	    break loop35;
//                        }
//                    } while (true);
//
//
//                    }
//                    break;
//
//            }
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "static_scalar"
//
//    public static class fully_qualified_class_name_list_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "fully_qualified_class_name_list"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:203:1: fully_qualified_class_name_list : fully_qualified_class_name ( ',' fully_qualified_class_name )* -> ( fully_qualified_class_name )+ ;
//    public final CompilerAstParser.fully_qualified_class_name_list_return fully_qualified_class_name_list() throws RecognitionException {
//        CompilerAstParser.fully_qualified_class_name_list_return retval = new CompilerAstParser.fully_qualified_class_name_list_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token char_literal146=null;
//        CompilerAstParser.fully_qualified_class_name_return fully_qualified_class_name145 = null;
//
//        CompilerAstParser.fully_qualified_class_name_return fully_qualified_class_name147 = null;
//
//
//        CommonTree char_literal146_tree=null;
//        RewriteRuleTokenStream stream_93=new RewriteRuleTokenStream(adaptor,"token 93");
//        RewriteRuleSubtreeStream stream_fully_qualified_class_name=new RewriteRuleSubtreeStream(adaptor,"rule fully_qualified_class_name");
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:204:2: ( fully_qualified_class_name ( ',' fully_qualified_class_name )* -> ( fully_qualified_class_name )+ )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:204:4: fully_qualified_class_name ( ',' fully_qualified_class_name )*
//            {
//            pushFollow(FOLLOW_fully_qualified_class_name_in_fully_qualified_class_name_list1451);
//            fully_qualified_class_name145=fully_qualified_class_name();
//
//            state._fsp--;
//            if (state.failed) return retval;
//            if ( state.backtracking==0 ) stream_fully_qualified_class_name.add(fully_qualified_class_name145.getTree());
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:204:31: ( ',' fully_qualified_class_name )*
//            loop37:
//            do {
//                int alt37=2;
//                int LA37_0 = input.LA(1);
//
//                if ( (LA37_0==93) ) {
//                    alt37=1;
//                }
//
//
//                switch (alt37) {
//            	case 1 :
//            	    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:204:32: ',' fully_qualified_class_name
//            	    {
//            	    char_literal146=(Token)match(input,93,FOLLOW_93_in_fully_qualified_class_name_list1454); if (state.failed) return retval; 
//            	    if ( state.backtracking==0 ) stream_93.add(char_literal146);
//
//            	    pushFollow(FOLLOW_fully_qualified_class_name_in_fully_qualified_class_name_list1456);
//            	    fully_qualified_class_name147=fully_qualified_class_name();
//
//            	    state._fsp--;
//            	    if (state.failed) return retval;
//            	    if ( state.backtracking==0 ) stream_fully_qualified_class_name.add(fully_qualified_class_name147.getTree());
//
//            	    }
//            	    break;
//
//            	default :
//            	    break loop37;
//                }
//            } while (true);
//
//
//
//            // AST REWRITE
//            // elements: fully_qualified_class_name
//            // token labels: 
//            // rule labels: retval
//            // token list labels: 
//            // rule list labels: 
//            // wildcard labels: 
//            if ( state.backtracking==0 ) {
//            retval.tree = root_0;
//            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//            root_0 = (CommonTree)adaptor.nil();
//            // 204:66: -> ( fully_qualified_class_name )+
//            {
//                if ( !(stream_fully_qualified_class_name.hasNext()) ) {
//                    throw new RewriteEarlyExitException();
//                }
//                while ( stream_fully_qualified_class_name.hasNext() ) {
//                    adaptor.addChild(root_0, stream_fully_qualified_class_name.nextTree());
//
//                }
//                stream_fully_qualified_class_name.reset();
//
//            }
//
//            retval.tree = root_0;}
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "fully_qualified_class_name_list"
//
//    public static class fully_qualified_class_name_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "fully_qualified_class_name"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:207:1: fully_qualified_class_name : IDENTIFIER ( '::' IDENTIFIER )* ( '::' )? ;
//    public final CompilerAstParser.fully_qualified_class_name_return fully_qualified_class_name() throws RecognitionException {
//        CompilerAstParser.fully_qualified_class_name_return retval = new CompilerAstParser.fully_qualified_class_name_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token IDENTIFIER148=null;
//        Token string_literal149=null;
//        Token IDENTIFIER150=null;
//        Token string_literal151=null;
//
//        CommonTree IDENTIFIER148_tree=null;
//        CommonTree string_literal149_tree=null;
//        CommonTree IDENTIFIER150_tree=null;
//        CommonTree string_literal151_tree=null;
//
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:208:2: ( IDENTIFIER ( '::' IDENTIFIER )* ( '::' )? )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:208:4: IDENTIFIER ( '::' IDENTIFIER )* ( '::' )?
//            {
//            root_0 = (CommonTree)adaptor.nil();
//
//            IDENTIFIER148=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_fully_qualified_class_name1475); if (state.failed) return retval;
//            if ( state.backtracking==0 ) {
//            IDENTIFIER148_tree = (CommonTree)adaptor.create(IDENTIFIER148);
//            adaptor.addChild(root_0, IDENTIFIER148_tree);
//            }
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:208:15: ( '::' IDENTIFIER )*
//            loop38:
//            do {
//                int alt38=2;
//                int LA38_0 = input.LA(1);
//
//                if ( (LA38_0==92) ) {
//                    int LA38_1 = input.LA(2);
//
//                    if ( (LA38_1==IDENTIFIER) ) {
//                        alt38=1;
//                    }
//
//
//                }
//
//
//                switch (alt38) {
//            	case 1 :
//            	    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:208:16: '::' IDENTIFIER
//            	    {
//            	    string_literal149=(Token)match(input,92,FOLLOW_92_in_fully_qualified_class_name1478); if (state.failed) return retval;
//            	    if ( state.backtracking==0 ) {
//            	    string_literal149_tree = (CommonTree)adaptor.create(string_literal149);
//            	    root_0 = (CommonTree)adaptor.becomeRoot(string_literal149_tree, root_0);
//            	    }
//            	    IDENTIFIER150=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_fully_qualified_class_name1481); if (state.failed) return retval;
//            	    if ( state.backtracking==0 ) {
//            	    IDENTIFIER150_tree = (CommonTree)adaptor.create(IDENTIFIER150);
//            	    adaptor.addChild(root_0, IDENTIFIER150_tree);
//            	    }
//
//            	    }
//            	    break;
//
//            	default :
//            	    break loop38;
//                }
//            } while (true);
//
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:208:35: ( '::' )?
//            int alt39=2;
//            int LA39_0 = input.LA(1);
//
//            if ( (LA39_0==92) ) {
//                alt39=1;
//            }
//            switch (alt39) {
//                case 1 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:208:35: '::'
//                    {
//                    string_literal151=(Token)match(input,92,FOLLOW_92_in_fully_qualified_class_name1485); if (state.failed) return retval;
//                    if ( state.backtracking==0 ) {
//                    string_literal151_tree = (CommonTree)adaptor.create(string_literal151);
//                    adaptor.addChild(root_0, string_literal151_tree);
//                    }
//
//                    }
//                    break;
//
//            }
//
//
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "fully_qualified_class_name"
//
//    public static class static_array_pair_list_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "static_array_pair_list"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:211:1: static_array_pair_list : static_scalar_element ( ',' static_scalar_element )* -> ( ^( SCALAR_ELEMENT static_scalar_element ) )+ ;
//    public final CompilerAstParser.static_array_pair_list_return static_array_pair_list() throws RecognitionException {
//        CompilerAstParser.static_array_pair_list_return retval = new CompilerAstParser.static_array_pair_list_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token char_literal153=null;
//        CompilerAstParser.static_scalar_element_return static_scalar_element152 = null;
//
//        CompilerAstParser.static_scalar_element_return static_scalar_element154 = null;
//
//
//        CommonTree char_literal153_tree=null;
//        RewriteRuleTokenStream stream_93=new RewriteRuleTokenStream(adaptor,"token 93");
//        RewriteRuleSubtreeStream stream_static_scalar_element=new RewriteRuleSubtreeStream(adaptor,"rule static_scalar_element");
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:212:3: ( static_scalar_element ( ',' static_scalar_element )* -> ( ^( SCALAR_ELEMENT static_scalar_element ) )+ )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:212:5: static_scalar_element ( ',' static_scalar_element )*
//            {
//            pushFollow(FOLLOW_static_scalar_element_in_static_array_pair_list1500);
//            static_scalar_element152=static_scalar_element();
//
//            state._fsp--;
//            if (state.failed) return retval;
//            if ( state.backtracking==0 ) stream_static_scalar_element.add(static_scalar_element152.getTree());
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:212:27: ( ',' static_scalar_element )*
//            loop40:
//            do {
//                int alt40=2;
//                int LA40_0 = input.LA(1);
//
//                if ( (LA40_0==93) ) {
//                    alt40=1;
//                }
//
//
//                switch (alt40) {
//            	case 1 :
//            	    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:212:28: ',' static_scalar_element
//            	    {
//            	    char_literal153=(Token)match(input,93,FOLLOW_93_in_static_array_pair_list1503); if (state.failed) return retval; 
//            	    if ( state.backtracking==0 ) stream_93.add(char_literal153);
//
//            	    pushFollow(FOLLOW_static_scalar_element_in_static_array_pair_list1505);
//            	    static_scalar_element154=static_scalar_element();
//
//            	    state._fsp--;
//            	    if (state.failed) return retval;
//            	    if ( state.backtracking==0 ) stream_static_scalar_element.add(static_scalar_element154.getTree());
//
//            	    }
//            	    break;
//
//            	default :
//            	    break loop40;
//                }
//            } while (true);
//
//
//
//            // AST REWRITE
//            // elements: static_scalar_element
//            // token labels: 
//            // rule labels: retval
//            // token list labels: 
//            // rule list labels: 
//            // wildcard labels: 
//            if ( state.backtracking==0 ) {
//            retval.tree = root_0;
//            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//            root_0 = (CommonTree)adaptor.nil();
//            // 212:56: -> ( ^( SCALAR_ELEMENT static_scalar_element ) )+
//            {
//                if ( !(stream_static_scalar_element.hasNext()) ) {
//                    throw new RewriteEarlyExitException();
//                }
//                while ( stream_static_scalar_element.hasNext() ) {
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:212:59: ^( SCALAR_ELEMENT static_scalar_element )
//                    {
//                    CommonTree root_1 = (CommonTree)adaptor.nil();
//                    root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(SCALAR_ELEMENT, "SCALAR_ELEMENT"), root_1);
//
//                    adaptor.addChild(root_1, stream_static_scalar_element.nextTree());
//
//                    adaptor.addChild(root_0, root_1);
//                    }
//
//                }
//                stream_static_scalar_element.reset();
//
//            }
//
//            retval.tree = root_0;}
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "static_array_pair_list"
//
//    public static class static_scalar_element_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "static_scalar_element"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:215:1: static_scalar_element : static_scalar ( '=>' static_scalar )? ;
//    public final CompilerAstParser.static_scalar_element_return static_scalar_element() throws RecognitionException {
//        CompilerAstParser.static_scalar_element_return retval = new CompilerAstParser.static_scalar_element_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token string_literal156=null;
//        CompilerAstParser.static_scalar_return static_scalar155 = null;
//
//        CompilerAstParser.static_scalar_return static_scalar157 = null;
//
//
//        CommonTree string_literal156_tree=null;
//
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:216:3: ( static_scalar ( '=>' static_scalar )? )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:216:5: static_scalar ( '=>' static_scalar )?
//            {
//            root_0 = (CommonTree)adaptor.nil();
//
//            pushFollow(FOLLOW_static_scalar_in_static_scalar_element1530);
//            static_scalar155=static_scalar();
//
//            state._fsp--;
//            if (state.failed) return retval;
//            if ( state.backtracking==0 ) adaptor.addChild(root_0, static_scalar155.getTree());
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:216:19: ( '=>' static_scalar )?
//            int alt41=2;
//            int LA41_0 = input.LA(1);
//
//            if ( (LA41_0==90) ) {
//                alt41=1;
//            }
//            switch (alt41) {
//                case 1 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:216:20: '=>' static_scalar
//                    {
//                    string_literal156=(Token)match(input,90,FOLLOW_90_in_static_scalar_element1533); if (state.failed) return retval;
//                    if ( state.backtracking==0 ) {
//                    string_literal156_tree = (CommonTree)adaptor.create(string_literal156);
//                    root_0 = (CommonTree)adaptor.becomeRoot(string_literal156_tree, root_0);
//                    }
//                    pushFollow(FOLLOW_static_scalar_in_static_scalar_element1536);
//                    static_scalar157=static_scalar();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) adaptor.addChild(root_0, static_scalar157.getTree());
//
//                    }
//                    break;
//
//            }
//
//
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "static_scalar_element"
//
//    public static class static_var_list_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "static_var_list"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:219:1: static_var_list : static_var_element ( ',' static_var_element )* -> ( ^( SCALAR_VAR static_var_element ) )+ ;
//    public final CompilerAstParser.static_var_list_return static_var_list() throws RecognitionException {
//        CompilerAstParser.static_var_list_return retval = new CompilerAstParser.static_var_list_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token char_literal159=null;
//        CompilerAstParser.static_var_element_return static_var_element158 = null;
//
//        CompilerAstParser.static_var_element_return static_var_element160 = null;
//
//
//        CommonTree char_literal159_tree=null;
//        RewriteRuleTokenStream stream_93=new RewriteRuleTokenStream(adaptor,"token 93");
//        RewriteRuleSubtreeStream stream_static_var_element=new RewriteRuleSubtreeStream(adaptor,"rule static_var_element");
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:220:2: ( static_var_element ( ',' static_var_element )* -> ( ^( SCALAR_VAR static_var_element ) )+ )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:220:4: static_var_element ( ',' static_var_element )*
//            {
//            pushFollow(FOLLOW_static_var_element_in_static_var_list1552);
//            static_var_element158=static_var_element();
//
//            state._fsp--;
//            if (state.failed) return retval;
//            if ( state.backtracking==0 ) stream_static_var_element.add(static_var_element158.getTree());
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:220:23: ( ',' static_var_element )*
//            loop42:
//            do {
//                int alt42=2;
//                int LA42_0 = input.LA(1);
//
//                if ( (LA42_0==93) ) {
//                    alt42=1;
//                }
//
//
//                switch (alt42) {
//            	case 1 :
//            	    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:220:24: ',' static_var_element
//            	    {
//            	    char_literal159=(Token)match(input,93,FOLLOW_93_in_static_var_list1555); if (state.failed) return retval; 
//            	    if ( state.backtracking==0 ) stream_93.add(char_literal159);
//
//            	    pushFollow(FOLLOW_static_var_element_in_static_var_list1557);
//            	    static_var_element160=static_var_element();
//
//            	    state._fsp--;
//            	    if (state.failed) return retval;
//            	    if ( state.backtracking==0 ) stream_static_var_element.add(static_var_element160.getTree());
//
//            	    }
//            	    break;
//
//            	default :
//            	    break loop42;
//                }
//            } while (true);
//
//
//
//            // AST REWRITE
//            // elements: static_var_element
//            // token labels: 
//            // rule labels: retval
//            // token list labels: 
//            // rule list labels: 
//            // wildcard labels: 
//            if ( state.backtracking==0 ) {
//            retval.tree = root_0;
//            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//            root_0 = (CommonTree)adaptor.nil();
//            // 220:49: -> ( ^( SCALAR_VAR static_var_element ) )+
//            {
//                if ( !(stream_static_var_element.hasNext()) ) {
//                    throw new RewriteEarlyExitException();
//                }
//                while ( stream_static_var_element.hasNext() ) {
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:220:52: ^( SCALAR_VAR static_var_element )
//                    {
//                    CommonTree root_1 = (CommonTree)adaptor.nil();
//                    root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(SCALAR_VAR, "SCALAR_VAR"), root_1);
//
//                    adaptor.addChild(root_1, stream_static_var_element.nextTree());
//
//                    adaptor.addChild(root_0, root_1);
//                    }
//
//                }
//                stream_static_var_element.reset();
//
//            }
//
//            retval.tree = root_0;}
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "static_var_list"
//
//    public static class static_var_element_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "static_var_element"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:223:1: static_var_element : pure_variable ( '=' static_scalar )? ;
//    public final CompilerAstParser.static_var_element_return static_var_element() throws RecognitionException {
//        CompilerAstParser.static_var_element_return retval = new CompilerAstParser.static_var_element_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token char_literal162=null;
//        CompilerAstParser.pure_variable_return pure_variable161 = null;
//
//        CompilerAstParser.static_scalar_return static_scalar163 = null;
//
//
//        CommonTree char_literal162_tree=null;
//
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:224:2: ( pure_variable ( '=' static_scalar )? )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:224:4: pure_variable ( '=' static_scalar )?
//            {
//            root_0 = (CommonTree)adaptor.nil();
//
//            pushFollow(FOLLOW_pure_variable_in_static_var_element1579);
//            pure_variable161=pure_variable();
//
//            state._fsp--;
//            if (state.failed) return retval;
//            if ( state.backtracking==0 ) adaptor.addChild(root_0, pure_variable161.getTree());
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:224:18: ( '=' static_scalar )?
//            int alt43=2;
//            int LA43_0 = input.LA(1);
//
//            if ( (LA43_0==94) ) {
//                alt43=1;
//            }
//            switch (alt43) {
//                case 1 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:224:19: '=' static_scalar
//                    {
//                    char_literal162=(Token)match(input,94,FOLLOW_94_in_static_var_element1582); if (state.failed) return retval;
//                    if ( state.backtracking==0 ) {
//                    char_literal162_tree = (CommonTree)adaptor.create(char_literal162);
//                    root_0 = (CommonTree)adaptor.becomeRoot(char_literal162_tree, root_0);
//                    }
//                    pushFollow(FOLLOW_static_scalar_in_static_var_element1585);
//                    static_scalar163=static_scalar();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) adaptor.addChild(root_0, static_scalar163.getTree());
//
//                    }
//                    break;
//
//            }
//
//
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "static_var_element"
//
//    public static class if_stat_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "if_stat"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:227:1: if_stat : 'if' '(' eIfCond= expression ')' (s1= statement ( options {k=1; backtrack=true; } : 'elseif' '(' eElseCond= expression ')' s2= statement )* ( options {k=1; backtrack=true; } : 'else' s3= statement )? -> ^( 'if' ^( CONDITION $eIfCond) $s1 ( ^( 'elseif' ^( CONDITION $eElseCond) $s2) )* ( ^( 'else' $s3) )? ) | ':' ( inner_statement_list )? ( new_elseif_branch )* ( options {k=1; backtrack=true; } : 'else' ':' s4= statement )? 'endif' ';' -> ^( 'if' ^( CONDITION $eIfCond) ( inner_statement_list )? ( new_elseif_branch )* ( ^( 'else' $s4) )? ) ) ;
//    public final CompilerAstParser.if_stat_return if_stat() throws RecognitionException {
//        CompilerAstParser.if_stat_return retval = new CompilerAstParser.if_stat_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token string_literal164=null;
//        Token char_literal165=null;
//        Token char_literal166=null;
//        Token string_literal167=null;
//        Token char_literal168=null;
//        Token char_literal169=null;
//        Token string_literal170=null;
//        Token char_literal171=null;
//        Token string_literal174=null;
//        Token char_literal175=null;
//        Token string_literal176=null;
//        Token char_literal177=null;
//        CompilerAstParser.expression_return eIfCond = null;
//
//        CompilerAstParser.statement_return s1 = null;
//
//        CompilerAstParser.expression_return eElseCond = null;
//
//        CompilerAstParser.statement_return s2 = null;
//
//        CompilerAstParser.statement_return s3 = null;
//
//        CompilerAstParser.statement_return s4 = null;
//
//        CompilerAstParser.inner_statement_list_return inner_statement_list172 = null;
//
//        CompilerAstParser.new_elseif_branch_return new_elseif_branch173 = null;
//
//
//        CommonTree string_literal164_tree=null;
//        CommonTree char_literal165_tree=null;
//        CommonTree char_literal166_tree=null;
//        CommonTree string_literal167_tree=null;
//        CommonTree char_literal168_tree=null;
//        CommonTree char_literal169_tree=null;
//        CommonTree string_literal170_tree=null;
//        CommonTree char_literal171_tree=null;
//        CommonTree string_literal174_tree=null;
//        CommonTree char_literal175_tree=null;
//        CommonTree string_literal176_tree=null;
//        CommonTree char_literal177_tree=null;
//        RewriteRuleTokenStream stream_98=new RewriteRuleTokenStream(adaptor,"token 98");
//        RewriteRuleTokenStream stream_97=new RewriteRuleTokenStream(adaptor,"token 97");
//        RewriteRuleTokenStream stream_96=new RewriteRuleTokenStream(adaptor,"token 96");
//        RewriteRuleTokenStream stream_95=new RewriteRuleTokenStream(adaptor,"token 95");
//        RewriteRuleTokenStream stream_62=new RewriteRuleTokenStream(adaptor,"token 62");
//        RewriteRuleTokenStream stream_63=new RewriteRuleTokenStream(adaptor,"token 63");
//        RewriteRuleTokenStream stream_99=new RewriteRuleTokenStream(adaptor,"token 99");
//        RewriteRuleTokenStream stream_61=new RewriteRuleTokenStream(adaptor,"token 61");
//        RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");
//        RewriteRuleSubtreeStream stream_statement=new RewriteRuleSubtreeStream(adaptor,"rule statement");
//        RewriteRuleSubtreeStream stream_inner_statement_list=new RewriteRuleSubtreeStream(adaptor,"rule inner_statement_list");
//        RewriteRuleSubtreeStream stream_new_elseif_branch=new RewriteRuleSubtreeStream(adaptor,"rule new_elseif_branch");
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:228:3: ( 'if' '(' eIfCond= expression ')' (s1= statement ( options {k=1; backtrack=true; } : 'elseif' '(' eElseCond= expression ')' s2= statement )* ( options {k=1; backtrack=true; } : 'else' s3= statement )? -> ^( 'if' ^( CONDITION $eIfCond) $s1 ( ^( 'elseif' ^( CONDITION $eElseCond) $s2) )* ( ^( 'else' $s3) )? ) | ':' ( inner_statement_list )? ( new_elseif_branch )* ( options {k=1; backtrack=true; } : 'else' ':' s4= statement )? 'endif' ';' -> ^( 'if' ^( CONDITION $eIfCond) ( inner_statement_list )? ( new_elseif_branch )* ( ^( 'else' $s4) )? ) ) )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:228:5: 'if' '(' eIfCond= expression ')' (s1= statement ( options {k=1; backtrack=true; } : 'elseif' '(' eElseCond= expression ')' s2= statement )* ( options {k=1; backtrack=true; } : 'else' s3= statement )? -> ^( 'if' ^( CONDITION $eIfCond) $s1 ( ^( 'elseif' ^( CONDITION $eElseCond) $s2) )* ( ^( 'else' $s3) )? ) | ':' ( inner_statement_list )? ( new_elseif_branch )* ( options {k=1; backtrack=true; } : 'else' ':' s4= statement )? 'endif' ';' -> ^( 'if' ^( CONDITION $eIfCond) ( inner_statement_list )? ( new_elseif_branch )* ( ^( 'else' $s4) )? ) )
//            {
//            string_literal164=(Token)match(input,95,FOLLOW_95_in_if_stat1601); if (state.failed) return retval; 
//            if ( state.backtracking==0 ) stream_95.add(string_literal164);
//
//            char_literal165=(Token)match(input,61,FOLLOW_61_in_if_stat1603); if (state.failed) return retval; 
//            if ( state.backtracking==0 ) stream_61.add(char_literal165);
//
//            pushFollow(FOLLOW_expression_in_if_stat1607);
//            eIfCond=expression();
//
//            state._fsp--;
//            if (state.failed) return retval;
//            if ( state.backtracking==0 ) stream_expression.add(eIfCond.getTree());
//            char_literal166=(Token)match(input,62,FOLLOW_62_in_if_stat1609); if (state.failed) return retval; 
//            if ( state.backtracking==0 ) stream_62.add(char_literal166);
//
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:229:5: (s1= statement ( options {k=1; backtrack=true; } : 'elseif' '(' eElseCond= expression ')' s2= statement )* ( options {k=1; backtrack=true; } : 'else' s3= statement )? -> ^( 'if' ^( CONDITION $eIfCond) $s1 ( ^( 'elseif' ^( CONDITION $eElseCond) $s2) )* ( ^( 'else' $s3) )? ) | ':' ( inner_statement_list )? ( new_elseif_branch )* ( options {k=1; backtrack=true; } : 'else' ':' s4= statement )? 'endif' ';' -> ^( 'if' ^( CONDITION $eIfCond) ( inner_statement_list )? ( new_elseif_branch )* ( ^( 'else' $s4) )? ) )
//            int alt49=2;
//            int LA49_0 = input.LA(1);
//
//            if ( ((LA49_0>=IDENTIFIER && LA49_0<=DOUBLELITERRAL)||LA49_0==61||LA49_0==63||LA49_0==67||(LA49_0>=72 && LA49_0<=84)||(LA49_0>=86 && LA49_0<=89)||LA49_0==95||(LA49_0>=142 && LA49_0<=143)||(LA49_0>=154 && LA49_0<=155)||(LA49_0>=157 && LA49_0<=161)||(LA49_0>=163 && LA49_0<=166)||LA49_0==168||(LA49_0>=171 && LA49_0<=176)) ) {
//                alt49=1;
//            }
//            else if ( (LA49_0==98) ) {
//                alt49=2;
//            }
//            else {
//                if (state.backtracking>0) {state.failed=true; return retval;}
//                NoViableAltException nvae =
//                    new NoViableAltException("", 49, 0, input);
//
//                throw nvae;
//            }
//            switch (alt49) {
//                case 1 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:230:7: s1= statement ( options {k=1; backtrack=true; } : 'elseif' '(' eElseCond= expression ')' s2= statement )* ( options {k=1; backtrack=true; } : 'else' s3= statement )?
//                    {
//                    pushFollow(FOLLOW_statement_in_if_stat1625);
//                    s1=statement();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) stream_statement.add(s1.getTree());
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:230:20: ( options {k=1; backtrack=true; } : 'elseif' '(' eElseCond= expression ')' s2= statement )*
//                    loop44:
//                    do {
//                        int alt44=2;
//                        alt44 = dfa44.predict(input);
//                        switch (alt44) {
//                    	case 1 :
//                    	    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:230:53: 'elseif' '(' eElseCond= expression ')' s2= statement
//                    	    {
//                    	    string_literal167=(Token)match(input,96,FOLLOW_96_in_if_stat1641); if (state.failed) return retval; 
//                    	    if ( state.backtracking==0 ) stream_96.add(string_literal167);
//
//                    	    char_literal168=(Token)match(input,61,FOLLOW_61_in_if_stat1643); if (state.failed) return retval; 
//                    	    if ( state.backtracking==0 ) stream_61.add(char_literal168);
//
//                    	    pushFollow(FOLLOW_expression_in_if_stat1647);
//                    	    eElseCond=expression();
//
//                    	    state._fsp--;
//                    	    if (state.failed) return retval;
//                    	    if ( state.backtracking==0 ) stream_expression.add(eElseCond.getTree());
//                    	    char_literal169=(Token)match(input,62,FOLLOW_62_in_if_stat1649); if (state.failed) return retval; 
//                    	    if ( state.backtracking==0 ) stream_62.add(char_literal169);
//
//                    	    pushFollow(FOLLOW_statement_in_if_stat1653);
//                    	    s2=statement();
//
//                    	    state._fsp--;
//                    	    if (state.failed) return retval;
//                    	    if ( state.backtracking==0 ) stream_statement.add(s2.getTree());
//
//                    	    }
//                    	    break;
//
//                    	default :
//                    	    break loop44;
//                        }
//                    } while (true);
//
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:231:8: ( options {k=1; backtrack=true; } : 'else' s3= statement )?
//                    int alt45=2;
//                    alt45 = dfa45.predict(input);
//                    switch (alt45) {
//                        case 1 :
//                            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:231:41: 'else' s3= statement
//                            {
//                            string_literal170=(Token)match(input,97,FOLLOW_97_in_if_stat1678); if (state.failed) return retval; 
//                            if ( state.backtracking==0 ) stream_97.add(string_literal170);
//
//                            pushFollow(FOLLOW_statement_in_if_stat1682);
//                            s3=statement();
//
//                            state._fsp--;
//                            if (state.failed) return retval;
//                            if ( state.backtracking==0 ) stream_statement.add(s3.getTree());
//
//                            }
//                            break;
//
//                    }
//
//
//
//                    // AST REWRITE
//                    // elements: eIfCond, eElseCond, 96, s1, 95, s3, s2, 97
//                    // token labels: 
//                    // rule labels: retval, s2, s1, eIfCond, s3, eElseCond
//                    // token list labels: 
//                    // rule list labels: 
//                    // wildcard labels: 
//                    if ( state.backtracking==0 ) {
//                    retval.tree = root_0;
//                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//                    RewriteRuleSubtreeStream stream_s2=new RewriteRuleSubtreeStream(adaptor,"rule s2",s2!=null?s2.tree:null);
//                    RewriteRuleSubtreeStream stream_s1=new RewriteRuleSubtreeStream(adaptor,"rule s1",s1!=null?s1.tree:null);
//                    RewriteRuleSubtreeStream stream_eIfCond=new RewriteRuleSubtreeStream(adaptor,"rule eIfCond",eIfCond!=null?eIfCond.tree:null);
//                    RewriteRuleSubtreeStream stream_s3=new RewriteRuleSubtreeStream(adaptor,"rule s3",s3!=null?s3.tree:null);
//                    RewriteRuleSubtreeStream stream_eElseCond=new RewriteRuleSubtreeStream(adaptor,"rule eElseCond",eElseCond!=null?eElseCond.tree:null);
//
//                    root_0 = (CommonTree)adaptor.nil();
//                    // 232:7: -> ^( 'if' ^( CONDITION $eIfCond) $s1 ( ^( 'elseif' ^( CONDITION $eElseCond) $s2) )* ( ^( 'else' $s3) )? )
//                    {
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:232:10: ^( 'if' ^( CONDITION $eIfCond) $s1 ( ^( 'elseif' ^( CONDITION $eElseCond) $s2) )* ( ^( 'else' $s3) )? )
//                        {
//                        CommonTree root_1 = (CommonTree)adaptor.nil();
//                        root_1 = (CommonTree)adaptor.becomeRoot(stream_95.nextNode(), root_1);
//
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:232:17: ^( CONDITION $eIfCond)
//                        {
//                        CommonTree root_2 = (CommonTree)adaptor.nil();
//                        root_2 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(CONDITION, "CONDITION"), root_2);
//
//                        adaptor.addChild(root_2, stream_eIfCond.nextTree());
//
//                        adaptor.addChild(root_1, root_2);
//                        }
//                        adaptor.addChild(root_1, stream_s1.nextTree());
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:232:44: ( ^( 'elseif' ^( CONDITION $eElseCond) $s2) )*
//                        while ( stream_eElseCond.hasNext()||stream_96.hasNext()||stream_s2.hasNext() ) {
//                            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:232:44: ^( 'elseif' ^( CONDITION $eElseCond) $s2)
//                            {
//                            CommonTree root_2 = (CommonTree)adaptor.nil();
//                            root_2 = (CommonTree)adaptor.becomeRoot(stream_96.nextNode(), root_2);
//
//                            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:232:55: ^( CONDITION $eElseCond)
//                            {
//                            CommonTree root_3 = (CommonTree)adaptor.nil();
//                            root_3 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(CONDITION, "CONDITION"), root_3);
//
//                            adaptor.addChild(root_3, stream_eElseCond.nextTree());
//
//                            adaptor.addChild(root_2, root_3);
//                            }
//                            adaptor.addChild(root_2, stream_s2.nextTree());
//
//                            adaptor.addChild(root_1, root_2);
//                            }
//
//                        }
//                        stream_eElseCond.reset();
//                        stream_96.reset();
//                        stream_s2.reset();
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:232:85: ( ^( 'else' $s3) )?
//                        if ( stream_s3.hasNext()||stream_97.hasNext() ) {
//                            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:232:85: ^( 'else' $s3)
//                            {
//                            CommonTree root_2 = (CommonTree)adaptor.nil();
//                            root_2 = (CommonTree)adaptor.becomeRoot(stream_97.nextNode(), root_2);
//
//                            adaptor.addChild(root_2, stream_s3.nextTree());
//
//                            adaptor.addChild(root_1, root_2);
//                            }
//
//                        }
//                        stream_s3.reset();
//                        stream_97.reset();
//
//                        adaptor.addChild(root_0, root_1);
//                        }
//
//                    }
//
//                    retval.tree = root_0;}
//                    }
//                    break;
//                case 2 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:233:9: ':' ( inner_statement_list )? ( new_elseif_branch )* ( options {k=1; backtrack=true; } : 'else' ':' s4= statement )? 'endif' ';'
//                    {
//                    char_literal171=(Token)match(input,98,FOLLOW_98_in_if_stat1740); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_98.add(char_literal171);
//
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:233:13: ( inner_statement_list )?
//                    int alt46=2;
//                    int LA46_0 = input.LA(1);
//
//                    if ( ((LA46_0>=IDENTIFIER && LA46_0<=DOUBLELITERRAL)||(LA46_0>=60 && LA46_0<=61)||(LA46_0>=63 && LA46_0<=64)||LA46_0==67||(LA46_0>=69 && LA46_0<=84)||(LA46_0>=86 && LA46_0<=89)||LA46_0==95||(LA46_0>=142 && LA46_0<=143)||(LA46_0>=154 && LA46_0<=155)||(LA46_0>=157 && LA46_0<=161)||(LA46_0>=163 && LA46_0<=166)||LA46_0==168||(LA46_0>=171 && LA46_0<=176)) ) {
//                        alt46=1;
//                    }
//                    switch (alt46) {
//                        case 1 :
//                            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:233:13: inner_statement_list
//                            {
//                            pushFollow(FOLLOW_inner_statement_list_in_if_stat1742);
//                            inner_statement_list172=inner_statement_list();
//
//                            state._fsp--;
//                            if (state.failed) return retval;
//                            if ( state.backtracking==0 ) stream_inner_statement_list.add(inner_statement_list172.getTree());
//
//                            }
//                            break;
//
//                    }
//
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:233:35: ( new_elseif_branch )*
//                    loop47:
//                    do {
//                        int alt47=2;
//                        int LA47_0 = input.LA(1);
//
//                        if ( (LA47_0==96) ) {
//                            alt47=1;
//                        }
//
//
//                        switch (alt47) {
//                    	case 1 :
//                    	    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:233:35: new_elseif_branch
//                    	    {
//                    	    pushFollow(FOLLOW_new_elseif_branch_in_if_stat1745);
//                    	    new_elseif_branch173=new_elseif_branch();
//
//                    	    state._fsp--;
//                    	    if (state.failed) return retval;
//                    	    if ( state.backtracking==0 ) stream_new_elseif_branch.add(new_elseif_branch173.getTree());
//
//                    	    }
//                    	    break;
//
//                    	default :
//                    	    break loop47;
//                        }
//                    } while (true);
//
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:233:54: ( options {k=1; backtrack=true; } : 'else' ':' s4= statement )?
//                    int alt48=2;
//                    int LA48_0 = input.LA(1);
//
//                    if ( (LA48_0==97) ) {
//                        alt48=1;
//                    }
//                    switch (alt48) {
//                        case 1 :
//                            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:233:87: 'else' ':' s4= statement
//                            {
//                            string_literal174=(Token)match(input,97,FOLLOW_97_in_if_stat1762); if (state.failed) return retval; 
//                            if ( state.backtracking==0 ) stream_97.add(string_literal174);
//
//                            char_literal175=(Token)match(input,98,FOLLOW_98_in_if_stat1764); if (state.failed) return retval; 
//                            if ( state.backtracking==0 ) stream_98.add(char_literal175);
//
//                            pushFollow(FOLLOW_statement_in_if_stat1768);
//                            s4=statement();
//
//                            state._fsp--;
//                            if (state.failed) return retval;
//                            if ( state.backtracking==0 ) stream_statement.add(s4.getTree());
//
//                            }
//                            break;
//
//                    }
//
//                    string_literal176=(Token)match(input,99,FOLLOW_99_in_if_stat1772); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_99.add(string_literal176);
//
//                    char_literal177=(Token)match(input,63,FOLLOW_63_in_if_stat1774); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_63.add(char_literal177);
//
//
//
//                    // AST REWRITE
//                    // elements: s4, 97, inner_statement_list, eIfCond, 95, new_elseif_branch
//                    // token labels: 
//                    // rule labels: retval, eIfCond, s4
//                    // token list labels: 
//                    // rule list labels: 
//                    // wildcard labels: 
//                    if ( state.backtracking==0 ) {
//                    retval.tree = root_0;
//                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//                    RewriteRuleSubtreeStream stream_eIfCond=new RewriteRuleSubtreeStream(adaptor,"rule eIfCond",eIfCond!=null?eIfCond.tree:null);
//                    RewriteRuleSubtreeStream stream_s4=new RewriteRuleSubtreeStream(adaptor,"rule s4",s4!=null?s4.tree:null);
//
//                    root_0 = (CommonTree)adaptor.nil();
//                    // 234:7: -> ^( 'if' ^( CONDITION $eIfCond) ( inner_statement_list )? ( new_elseif_branch )* ( ^( 'else' $s4) )? )
//                    {
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:234:10: ^( 'if' ^( CONDITION $eIfCond) ( inner_statement_list )? ( new_elseif_branch )* ( ^( 'else' $s4) )? )
//                        {
//                        CommonTree root_1 = (CommonTree)adaptor.nil();
//                        root_1 = (CommonTree)adaptor.becomeRoot(stream_95.nextNode(), root_1);
//
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:234:17: ^( CONDITION $eIfCond)
//                        {
//                        CommonTree root_2 = (CommonTree)adaptor.nil();
//                        root_2 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(CONDITION, "CONDITION"), root_2);
//
//                        adaptor.addChild(root_2, stream_eIfCond.nextTree());
//
//                        adaptor.addChild(root_1, root_2);
//                        }
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:234:39: ( inner_statement_list )?
//                        if ( stream_inner_statement_list.hasNext() ) {
//                            adaptor.addChild(root_1, stream_inner_statement_list.nextTree());
//
//                        }
//                        stream_inner_statement_list.reset();
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:234:61: ( new_elseif_branch )*
//                        while ( stream_new_elseif_branch.hasNext() ) {
//                            adaptor.addChild(root_1, stream_new_elseif_branch.nextTree());
//
//                        }
//                        stream_new_elseif_branch.reset();
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:234:80: ( ^( 'else' $s4) )?
//                        if ( stream_s4.hasNext()||stream_97.hasNext() ) {
//                            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:234:80: ^( 'else' $s4)
//                            {
//                            CommonTree root_2 = (CommonTree)adaptor.nil();
//                            root_2 = (CommonTree)adaptor.becomeRoot(stream_97.nextNode(), root_2);
//
//                            adaptor.addChild(root_2, stream_s4.nextTree());
//
//                            adaptor.addChild(root_1, root_2);
//                            }
//
//                        }
//                        stream_s4.reset();
//                        stream_97.reset();
//
//                        adaptor.addChild(root_0, root_1);
//                        }
//
//                    }
//
//                    retval.tree = root_0;}
//                    }
//                    break;
//
//            }
//
//
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "if_stat"
//
//    public static class new_elseif_branch_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "new_elseif_branch"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:238:1: new_elseif_branch : 'elseif' '(' expression ')' ':' ( inner_statement_list )? -> ^( 'elseif' ^( CONDITION expression ) ( inner_statement_list )? ) ;
//    public final CompilerAstParser.new_elseif_branch_return new_elseif_branch() throws RecognitionException {
//        CompilerAstParser.new_elseif_branch_return retval = new CompilerAstParser.new_elseif_branch_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token string_literal178=null;
//        Token char_literal179=null;
//        Token char_literal181=null;
//        Token char_literal182=null;
//        CompilerAstParser.expression_return expression180 = null;
//
//        CompilerAstParser.inner_statement_list_return inner_statement_list183 = null;
//
//
//        CommonTree string_literal178_tree=null;
//        CommonTree char_literal179_tree=null;
//        CommonTree char_literal181_tree=null;
//        CommonTree char_literal182_tree=null;
//        RewriteRuleTokenStream stream_98=new RewriteRuleTokenStream(adaptor,"token 98");
//        RewriteRuleTokenStream stream_96=new RewriteRuleTokenStream(adaptor,"token 96");
//        RewriteRuleTokenStream stream_62=new RewriteRuleTokenStream(adaptor,"token 62");
//        RewriteRuleTokenStream stream_61=new RewriteRuleTokenStream(adaptor,"token 61");
//        RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");
//        RewriteRuleSubtreeStream stream_inner_statement_list=new RewriteRuleSubtreeStream(adaptor,"rule inner_statement_list");
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:239:2: ( 'elseif' '(' expression ')' ':' ( inner_statement_list )? -> ^( 'elseif' ^( CONDITION expression ) ( inner_statement_list )? ) )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:239:4: 'elseif' '(' expression ')' ':' ( inner_statement_list )?
//            {
//            string_literal178=(Token)match(input,96,FOLLOW_96_in_new_elseif_branch1827); if (state.failed) return retval; 
//            if ( state.backtracking==0 ) stream_96.add(string_literal178);
//
//            char_literal179=(Token)match(input,61,FOLLOW_61_in_new_elseif_branch1829); if (state.failed) return retval; 
//            if ( state.backtracking==0 ) stream_61.add(char_literal179);
//
//            pushFollow(FOLLOW_expression_in_new_elseif_branch1831);
//            expression180=expression();
//
//            state._fsp--;
//            if (state.failed) return retval;
//            if ( state.backtracking==0 ) stream_expression.add(expression180.getTree());
//            char_literal181=(Token)match(input,62,FOLLOW_62_in_new_elseif_branch1833); if (state.failed) return retval; 
//            if ( state.backtracking==0 ) stream_62.add(char_literal181);
//
//            char_literal182=(Token)match(input,98,FOLLOW_98_in_new_elseif_branch1835); if (state.failed) return retval; 
//            if ( state.backtracking==0 ) stream_98.add(char_literal182);
//
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:239:36: ( inner_statement_list )?
//            int alt50=2;
//            int LA50_0 = input.LA(1);
//
//            if ( ((LA50_0>=IDENTIFIER && LA50_0<=DOUBLELITERRAL)||(LA50_0>=60 && LA50_0<=61)||(LA50_0>=63 && LA50_0<=64)||LA50_0==67||(LA50_0>=69 && LA50_0<=84)||(LA50_0>=86 && LA50_0<=89)||LA50_0==95||(LA50_0>=142 && LA50_0<=143)||(LA50_0>=154 && LA50_0<=155)||(LA50_0>=157 && LA50_0<=161)||(LA50_0>=163 && LA50_0<=166)||LA50_0==168||(LA50_0>=171 && LA50_0<=176)) ) {
//                alt50=1;
//            }
//            switch (alt50) {
//                case 1 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:239:36: inner_statement_list
//                    {
//                    pushFollow(FOLLOW_inner_statement_list_in_new_elseif_branch1837);
//                    inner_statement_list183=inner_statement_list();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) stream_inner_statement_list.add(inner_statement_list183.getTree());
//
//                    }
//                    break;
//
//            }
//
//
//
//            // AST REWRITE
//            // elements: expression, 96, inner_statement_list
//            // token labels: 
//            // rule labels: retval
//            // token list labels: 
//            // rule list labels: 
//            // wildcard labels: 
//            if ( state.backtracking==0 ) {
//            retval.tree = root_0;
//            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//            root_0 = (CommonTree)adaptor.nil();
//            // 239:59: -> ^( 'elseif' ^( CONDITION expression ) ( inner_statement_list )? )
//            {
//                // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:239:62: ^( 'elseif' ^( CONDITION expression ) ( inner_statement_list )? )
//                {
//                CommonTree root_1 = (CommonTree)adaptor.nil();
//                root_1 = (CommonTree)adaptor.becomeRoot(stream_96.nextNode(), root_1);
//
//                // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:239:73: ^( CONDITION expression )
//                {
//                CommonTree root_2 = (CommonTree)adaptor.nil();
//                root_2 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(CONDITION, "CONDITION"), root_2);
//
//                adaptor.addChild(root_2, stream_expression.nextTree());
//
//                adaptor.addChild(root_1, root_2);
//                }
//                // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:239:97: ( inner_statement_list )?
//                if ( stream_inner_statement_list.hasNext() ) {
//                    adaptor.addChild(root_1, stream_inner_statement_list.nextTree());
//
//                }
//                stream_inner_statement_list.reset();
//
//                adaptor.addChild(root_0, root_1);
//                }
//
//            }
//
//            retval.tree = root_0;}
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "new_elseif_branch"
//
//    public static class switch_case_list_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "switch_case_list"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:242:1: switch_case_list : ( '{' ( ';' )? ( case_list )+ '}' -> ( case_list )+ | ':' ( ';' )? ( case_list )+ 'endswitch' ';' -> ( case_list )+ );
//    public final CompilerAstParser.switch_case_list_return switch_case_list() throws RecognitionException {
//        CompilerAstParser.switch_case_list_return retval = new CompilerAstParser.switch_case_list_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token char_literal184=null;
//        Token char_literal185=null;
//        Token char_literal187=null;
//        Token char_literal188=null;
//        Token char_literal189=null;
//        Token string_literal191=null;
//        Token char_literal192=null;
//        CompilerAstParser.case_list_return case_list186 = null;
//
//        CompilerAstParser.case_list_return case_list190 = null;
//
//
//        CommonTree char_literal184_tree=null;
//        CommonTree char_literal185_tree=null;
//        CommonTree char_literal187_tree=null;
//        CommonTree char_literal188_tree=null;
//        CommonTree char_literal189_tree=null;
//        CommonTree string_literal191_tree=null;
//        CommonTree char_literal192_tree=null;
//        RewriteRuleTokenStream stream_98=new RewriteRuleTokenStream(adaptor,"token 98");
//        RewriteRuleTokenStream stream_67=new RewriteRuleTokenStream(adaptor,"token 67");
//        RewriteRuleTokenStream stream_68=new RewriteRuleTokenStream(adaptor,"token 68");
//        RewriteRuleTokenStream stream_63=new RewriteRuleTokenStream(adaptor,"token 63");
//        RewriteRuleTokenStream stream_100=new RewriteRuleTokenStream(adaptor,"token 100");
//        RewriteRuleSubtreeStream stream_case_list=new RewriteRuleSubtreeStream(adaptor,"rule case_list");
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:243:3: ( '{' ( ';' )? ( case_list )+ '}' -> ( case_list )+ | ':' ( ';' )? ( case_list )+ 'endswitch' ';' -> ( case_list )+ )
//            int alt55=2;
//            int LA55_0 = input.LA(1);
//
//            if ( (LA55_0==67) ) {
//                alt55=1;
//            }
//            else if ( (LA55_0==98) ) {
//                alt55=2;
//            }
//            else {
//                if (state.backtracking>0) {state.failed=true; return retval;}
//                NoViableAltException nvae =
//                    new NoViableAltException("", 55, 0, input);
//
//                throw nvae;
//            }
//            switch (alt55) {
//                case 1 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:243:5: '{' ( ';' )? ( case_list )+ '}'
//                    {
//                    char_literal184=(Token)match(input,67,FOLLOW_67_in_switch_case_list1867); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_67.add(char_literal184);
//
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:243:9: ( ';' )?
//                    int alt51=2;
//                    int LA51_0 = input.LA(1);
//
//                    if ( (LA51_0==63) ) {
//                        alt51=1;
//                    }
//                    switch (alt51) {
//                        case 1 :
//                            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:243:9: ';'
//                            {
//                            char_literal185=(Token)match(input,63,FOLLOW_63_in_switch_case_list1869); if (state.failed) return retval; 
//                            if ( state.backtracking==0 ) stream_63.add(char_literal185);
//
//
//                            }
//                            break;
//
//                    }
//
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:243:14: ( case_list )+
//                    int cnt52=0;
//                    loop52:
//                    do {
//                        int alt52=2;
//                        int LA52_0 = input.LA(1);
//
//                        if ( ((LA52_0>=101 && LA52_0<=102)) ) {
//                            alt52=1;
//                        }
//
//
//                        switch (alt52) {
//                    	case 1 :
//                    	    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:243:14: case_list
//                    	    {
//                    	    pushFollow(FOLLOW_case_list_in_switch_case_list1872);
//                    	    case_list186=case_list();
//
//                    	    state._fsp--;
//                    	    if (state.failed) return retval;
//                    	    if ( state.backtracking==0 ) stream_case_list.add(case_list186.getTree());
//
//                    	    }
//                    	    break;
//
//                    	default :
//                    	    if ( cnt52 >= 1 ) break loop52;
//                    	    if (state.backtracking>0) {state.failed=true; return retval;}
//                                EarlyExitException eee =
//                                    new EarlyExitException(52, input);
//                                throw eee;
//                        }
//                        cnt52++;
//                    } while (true);
//
//                    char_literal187=(Token)match(input,68,FOLLOW_68_in_switch_case_list1875); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_68.add(char_literal187);
//
//
//
//                    // AST REWRITE
//                    // elements: case_list
//                    // token labels: 
//                    // rule labels: retval
//                    // token list labels: 
//                    // rule list labels: 
//                    // wildcard labels: 
//                    if ( state.backtracking==0 ) {
//                    retval.tree = root_0;
//                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//                    root_0 = (CommonTree)adaptor.nil();
//                    // 243:34: -> ( case_list )+
//                    {
//                        if ( !(stream_case_list.hasNext()) ) {
//                            throw new RewriteEarlyExitException();
//                        }
//                        while ( stream_case_list.hasNext() ) {
//                            adaptor.addChild(root_0, stream_case_list.nextTree());
//
//                        }
//                        stream_case_list.reset();
//
//                    }
//
//                    retval.tree = root_0;}
//                    }
//                    break;
//                case 2 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:244:5: ':' ( ';' )? ( case_list )+ 'endswitch' ';'
//                    {
//                    char_literal188=(Token)match(input,98,FOLLOW_98_in_switch_case_list1891); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_98.add(char_literal188);
//
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:244:9: ( ';' )?
//                    int alt53=2;
//                    int LA53_0 = input.LA(1);
//
//                    if ( (LA53_0==63) ) {
//                        alt53=1;
//                    }
//                    switch (alt53) {
//                        case 1 :
//                            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:244:9: ';'
//                            {
//                            char_literal189=(Token)match(input,63,FOLLOW_63_in_switch_case_list1893); if (state.failed) return retval; 
//                            if ( state.backtracking==0 ) stream_63.add(char_literal189);
//
//
//                            }
//                            break;
//
//                    }
//
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:244:14: ( case_list )+
//                    int cnt54=0;
//                    loop54:
//                    do {
//                        int alt54=2;
//                        int LA54_0 = input.LA(1);
//
//                        if ( ((LA54_0>=101 && LA54_0<=102)) ) {
//                            alt54=1;
//                        }
//
//
//                        switch (alt54) {
//                    	case 1 :
//                    	    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:244:14: case_list
//                    	    {
//                    	    pushFollow(FOLLOW_case_list_in_switch_case_list1896);
//                    	    case_list190=case_list();
//
//                    	    state._fsp--;
//                    	    if (state.failed) return retval;
//                    	    if ( state.backtracking==0 ) stream_case_list.add(case_list190.getTree());
//
//                    	    }
//                    	    break;
//
//                    	default :
//                    	    if ( cnt54 >= 1 ) break loop54;
//                    	    if (state.backtracking>0) {state.failed=true; return retval;}
//                                EarlyExitException eee =
//                                    new EarlyExitException(54, input);
//                                throw eee;
//                        }
//                        cnt54++;
//                    } while (true);
//
//                    string_literal191=(Token)match(input,100,FOLLOW_100_in_switch_case_list1899); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_100.add(string_literal191);
//
//                    char_literal192=(Token)match(input,63,FOLLOW_63_in_switch_case_list1901); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_63.add(char_literal192);
//
//
//
//                    // AST REWRITE
//                    // elements: case_list
//                    // token labels: 
//                    // rule labels: retval
//                    // token list labels: 
//                    // rule list labels: 
//                    // wildcard labels: 
//                    if ( state.backtracking==0 ) {
//                    retval.tree = root_0;
//                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//                    root_0 = (CommonTree)adaptor.nil();
//                    // 244:43: -> ( case_list )+
//                    {
//                        if ( !(stream_case_list.hasNext()) ) {
//                            throw new RewriteEarlyExitException();
//                        }
//                        while ( stream_case_list.hasNext() ) {
//                            adaptor.addChild(root_0, stream_case_list.nextTree());
//
//                        }
//                        stream_case_list.reset();
//
//                    }
//
//                    retval.tree = root_0;}
//                    }
//                    break;
//
//            }
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "switch_case_list"
//
//    public static class case_list_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "case_list"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:247:1: case_list : ( 'case' expression ( ':' | ';' ) ( inner_statement_list )? -> ^( 'case' expression ( inner_statement_list )? ) | 'default' ( ':' | ';' ) ( inner_statement_list )? -> ^( 'default' ( inner_statement_list )? ) );
//    public final CompilerAstParser.case_list_return case_list() throws RecognitionException {
//        CompilerAstParser.case_list_return retval = new CompilerAstParser.case_list_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token string_literal193=null;
//        Token char_literal195=null;
//        Token char_literal196=null;
//        Token string_literal198=null;
//        Token char_literal199=null;
//        Token char_literal200=null;
//        CompilerAstParser.expression_return expression194 = null;
//
//        CompilerAstParser.inner_statement_list_return inner_statement_list197 = null;
//
//        CompilerAstParser.inner_statement_list_return inner_statement_list201 = null;
//
//
//        CommonTree string_literal193_tree=null;
//        CommonTree char_literal195_tree=null;
//        CommonTree char_literal196_tree=null;
//        CommonTree string_literal198_tree=null;
//        CommonTree char_literal199_tree=null;
//        CommonTree char_literal200_tree=null;
//        RewriteRuleTokenStream stream_98=new RewriteRuleTokenStream(adaptor,"token 98");
//        RewriteRuleTokenStream stream_63=new RewriteRuleTokenStream(adaptor,"token 63");
//        RewriteRuleTokenStream stream_102=new RewriteRuleTokenStream(adaptor,"token 102");
//        RewriteRuleTokenStream stream_101=new RewriteRuleTokenStream(adaptor,"token 101");
//        RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");
//        RewriteRuleSubtreeStream stream_inner_statement_list=new RewriteRuleSubtreeStream(adaptor,"rule inner_statement_list");
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:248:3: ( 'case' expression ( ':' | ';' ) ( inner_statement_list )? -> ^( 'case' expression ( inner_statement_list )? ) | 'default' ( ':' | ';' ) ( inner_statement_list )? -> ^( 'default' ( inner_statement_list )? ) )
//            int alt60=2;
//            int LA60_0 = input.LA(1);
//
//            if ( (LA60_0==101) ) {
//                alt60=1;
//            }
//            else if ( (LA60_0==102) ) {
//                alt60=2;
//            }
//            else {
//                if (state.backtracking>0) {state.failed=true; return retval;}
//                NoViableAltException nvae =
//                    new NoViableAltException("", 60, 0, input);
//
//                throw nvae;
//            }
//            switch (alt60) {
//                case 1 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:248:5: 'case' expression ( ':' | ';' ) ( inner_statement_list )?
//                    {
//                    string_literal193=(Token)match(input,101,FOLLOW_101_in_case_list1921); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_101.add(string_literal193);
//
//                    pushFollow(FOLLOW_expression_in_case_list1923);
//                    expression194=expression();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) stream_expression.add(expression194.getTree());
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:248:23: ( ':' | ';' )
//                    int alt56=2;
//                    int LA56_0 = input.LA(1);
//
//                    if ( (LA56_0==98) ) {
//                        alt56=1;
//                    }
//                    else if ( (LA56_0==63) ) {
//                        alt56=2;
//                    }
//                    else {
//                        if (state.backtracking>0) {state.failed=true; return retval;}
//                        NoViableAltException nvae =
//                            new NoViableAltException("", 56, 0, input);
//
//                        throw nvae;
//                    }
//                    switch (alt56) {
//                        case 1 :
//                            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:248:24: ':'
//                            {
//                            char_literal195=(Token)match(input,98,FOLLOW_98_in_case_list1926); if (state.failed) return retval; 
//                            if ( state.backtracking==0 ) stream_98.add(char_literal195);
//
//
//                            }
//                            break;
//                        case 2 :
//                            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:248:30: ';'
//                            {
//                            char_literal196=(Token)match(input,63,FOLLOW_63_in_case_list1930); if (state.failed) return retval; 
//                            if ( state.backtracking==0 ) stream_63.add(char_literal196);
//
//
//                            }
//                            break;
//
//                    }
//
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:248:35: ( inner_statement_list )?
//                    int alt57=2;
//                    int LA57_0 = input.LA(1);
//
//                    if ( ((LA57_0>=IDENTIFIER && LA57_0<=DOUBLELITERRAL)||(LA57_0>=60 && LA57_0<=61)||(LA57_0>=63 && LA57_0<=64)||LA57_0==67||(LA57_0>=69 && LA57_0<=84)||(LA57_0>=86 && LA57_0<=89)||LA57_0==95||(LA57_0>=142 && LA57_0<=143)||(LA57_0>=154 && LA57_0<=155)||(LA57_0>=157 && LA57_0<=161)||(LA57_0>=163 && LA57_0<=166)||LA57_0==168||(LA57_0>=171 && LA57_0<=176)) ) {
//                        alt57=1;
//                    }
//                    switch (alt57) {
//                        case 1 :
//                            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:248:35: inner_statement_list
//                            {
//                            pushFollow(FOLLOW_inner_statement_list_in_case_list1933);
//                            inner_statement_list197=inner_statement_list();
//
//                            state._fsp--;
//                            if (state.failed) return retval;
//                            if ( state.backtracking==0 ) stream_inner_statement_list.add(inner_statement_list197.getTree());
//
//                            }
//                            break;
//
//                    }
//
//
//
//                    // AST REWRITE
//                    // elements: 101, inner_statement_list, expression
//                    // token labels: 
//                    // rule labels: retval
//                    // token list labels: 
//                    // rule list labels: 
//                    // wildcard labels: 
//                    if ( state.backtracking==0 ) {
//                    retval.tree = root_0;
//                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//                    root_0 = (CommonTree)adaptor.nil();
//                    // 248:58: -> ^( 'case' expression ( inner_statement_list )? )
//                    {
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:248:61: ^( 'case' expression ( inner_statement_list )? )
//                        {
//                        CommonTree root_1 = (CommonTree)adaptor.nil();
//                        root_1 = (CommonTree)adaptor.becomeRoot(stream_101.nextNode(), root_1);
//
//                        adaptor.addChild(root_1, stream_expression.nextTree());
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:248:81: ( inner_statement_list )?
//                        if ( stream_inner_statement_list.hasNext() ) {
//                            adaptor.addChild(root_1, stream_inner_statement_list.nextTree());
//
//                        }
//                        stream_inner_statement_list.reset();
//
//                        adaptor.addChild(root_0, root_1);
//                        }
//
//                    }
//
//                    retval.tree = root_0;}
//                    }
//                    break;
//                case 2 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:249:5: 'default' ( ':' | ';' ) ( inner_statement_list )?
//                    {
//                    string_literal198=(Token)match(input,102,FOLLOW_102_in_case_list1952); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_102.add(string_literal198);
//
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:249:15: ( ':' | ';' )
//                    int alt58=2;
//                    int LA58_0 = input.LA(1);
//
//                    if ( (LA58_0==98) ) {
//                        alt58=1;
//                    }
//                    else if ( (LA58_0==63) ) {
//                        alt58=2;
//                    }
//                    else {
//                        if (state.backtracking>0) {state.failed=true; return retval;}
//                        NoViableAltException nvae =
//                            new NoViableAltException("", 58, 0, input);
//
//                        throw nvae;
//                    }
//                    switch (alt58) {
//                        case 1 :
//                            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:249:16: ':'
//                            {
//                            char_literal199=(Token)match(input,98,FOLLOW_98_in_case_list1955); if (state.failed) return retval; 
//                            if ( state.backtracking==0 ) stream_98.add(char_literal199);
//
//
//                            }
//                            break;
//                        case 2 :
//                            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:249:22: ';'
//                            {
//                            char_literal200=(Token)match(input,63,FOLLOW_63_in_case_list1959); if (state.failed) return retval; 
//                            if ( state.backtracking==0 ) stream_63.add(char_literal200);
//
//
//                            }
//                            break;
//
//                    }
//
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:249:27: ( inner_statement_list )?
//                    int alt59=2;
//                    int LA59_0 = input.LA(1);
//
//                    if ( ((LA59_0>=IDENTIFIER && LA59_0<=DOUBLELITERRAL)||(LA59_0>=60 && LA59_0<=61)||(LA59_0>=63 && LA59_0<=64)||LA59_0==67||(LA59_0>=69 && LA59_0<=84)||(LA59_0>=86 && LA59_0<=89)||LA59_0==95||(LA59_0>=142 && LA59_0<=143)||(LA59_0>=154 && LA59_0<=155)||(LA59_0>=157 && LA59_0<=161)||(LA59_0>=163 && LA59_0<=166)||LA59_0==168||(LA59_0>=171 && LA59_0<=176)) ) {
//                        alt59=1;
//                    }
//                    switch (alt59) {
//                        case 1 :
//                            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:249:27: inner_statement_list
//                            {
//                            pushFollow(FOLLOW_inner_statement_list_in_case_list1962);
//                            inner_statement_list201=inner_statement_list();
//
//                            state._fsp--;
//                            if (state.failed) return retval;
//                            if ( state.backtracking==0 ) stream_inner_statement_list.add(inner_statement_list201.getTree());
//
//                            }
//                            break;
//
//                    }
//
//
//
//                    // AST REWRITE
//                    // elements: 102, inner_statement_list
//                    // token labels: 
//                    // rule labels: retval
//                    // token list labels: 
//                    // rule list labels: 
//                    // wildcard labels: 
//                    if ( state.backtracking==0 ) {
//                    retval.tree = root_0;
//                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//                    root_0 = (CommonTree)adaptor.nil();
//                    // 249:52: -> ^( 'default' ( inner_statement_list )? )
//                    {
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:249:55: ^( 'default' ( inner_statement_list )? )
//                        {
//                        CommonTree root_1 = (CommonTree)adaptor.nil();
//                        root_1 = (CommonTree)adaptor.becomeRoot(stream_102.nextNode(), root_1);
//
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:249:67: ( inner_statement_list )?
//                        if ( stream_inner_statement_list.hasNext() ) {
//                            adaptor.addChild(root_1, stream_inner_statement_list.nextTree());
//
//                        }
//                        stream_inner_statement_list.reset();
//
//                        adaptor.addChild(root_0, root_1);
//                        }
//
//                    }
//
//                    retval.tree = root_0;}
//                    }
//                    break;
//
//            }
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "case_list"
//
//    public static class catch_branch_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "catch_branch"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:252:1: catch_branch : 'catch' '(' IDENTIFIER variable ')' block -> ^( 'catch' IDENTIFIER variable block ) ;
//    public final CompilerAstParser.catch_branch_return catch_branch() throws RecognitionException {
//        CompilerAstParser.catch_branch_return retval = new CompilerAstParser.catch_branch_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token string_literal202=null;
//        Token char_literal203=null;
//        Token IDENTIFIER204=null;
//        Token char_literal206=null;
//        CompilerAstParser.variable_return variable205 = null;
//
//        CompilerAstParser.block_return block207 = null;
//
//
//        CommonTree string_literal202_tree=null;
//        CommonTree char_literal203_tree=null;
//        CommonTree IDENTIFIER204_tree=null;
//        CommonTree char_literal206_tree=null;
//        RewriteRuleTokenStream stream_62=new RewriteRuleTokenStream(adaptor,"token 62");
//        RewriteRuleTokenStream stream_IDENTIFIER=new RewriteRuleTokenStream(adaptor,"token IDENTIFIER");
//        RewriteRuleTokenStream stream_103=new RewriteRuleTokenStream(adaptor,"token 103");
//        RewriteRuleTokenStream stream_61=new RewriteRuleTokenStream(adaptor,"token 61");
//        RewriteRuleSubtreeStream stream_block=new RewriteRuleSubtreeStream(adaptor,"rule block");
//        RewriteRuleSubtreeStream stream_variable=new RewriteRuleSubtreeStream(adaptor,"rule variable");
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:253:3: ( 'catch' '(' IDENTIFIER variable ')' block -> ^( 'catch' IDENTIFIER variable block ) )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:253:5: 'catch' '(' IDENTIFIER variable ')' block
//            {
//            string_literal202=(Token)match(input,103,FOLLOW_103_in_catch_branch1989); if (state.failed) return retval; 
//            if ( state.backtracking==0 ) stream_103.add(string_literal202);
//
//            char_literal203=(Token)match(input,61,FOLLOW_61_in_catch_branch1991); if (state.failed) return retval; 
//            if ( state.backtracking==0 ) stream_61.add(char_literal203);
//
//            IDENTIFIER204=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_catch_branch1993); if (state.failed) return retval; 
//            if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER204);
//
//            pushFollow(FOLLOW_variable_in_catch_branch1995);
//            variable205=variable();
//
//            state._fsp--;
//            if (state.failed) return retval;
//            if ( state.backtracking==0 ) stream_variable.add(variable205.getTree());
//            char_literal206=(Token)match(input,62,FOLLOW_62_in_catch_branch1997); if (state.failed) return retval; 
//            if ( state.backtracking==0 ) stream_62.add(char_literal206);
//
//            pushFollow(FOLLOW_block_in_catch_branch2003);
//            block207=block();
//
//            state._fsp--;
//            if (state.failed) return retval;
//            if ( state.backtracking==0 ) stream_block.add(block207.getTree());
//
//
//            // AST REWRITE
//            // elements: block, variable, IDENTIFIER, 103
//            // token labels: 
//            // rule labels: retval
//            // token list labels: 
//            // rule list labels: 
//            // wildcard labels: 
//            if ( state.backtracking==0 ) {
//            retval.tree = root_0;
//            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//            root_0 = (CommonTree)adaptor.nil();
//            // 255:5: -> ^( 'catch' IDENTIFIER variable block )
//            {
//                // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:255:8: ^( 'catch' IDENTIFIER variable block )
//                {
//                CommonTree root_1 = (CommonTree)adaptor.nil();
//                root_1 = (CommonTree)adaptor.becomeRoot(stream_103.nextNode(), root_1);
//
//                adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());
//                adaptor.addChild(root_1, stream_variable.nextTree());
//                adaptor.addChild(root_1, stream_block.nextTree());
//
//                adaptor.addChild(root_0, root_1);
//                }
//
//            }
//
//            retval.tree = root_0;}
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "catch_branch"
//
//    public static class for_statement_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "for_statement"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:258:1: for_statement : ':' ( inner_statement_list )? 'endfor' ';' -> ( inner_statement_list )? ;
//    public final CompilerAstParser.for_statement_return for_statement() throws RecognitionException {
//        CompilerAstParser.for_statement_return retval = new CompilerAstParser.for_statement_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token char_literal208=null;
//        Token string_literal210=null;
//        Token char_literal211=null;
//        CompilerAstParser.inner_statement_list_return inner_statement_list209 = null;
//
//
//        CommonTree char_literal208_tree=null;
//        CommonTree string_literal210_tree=null;
//        CommonTree char_literal211_tree=null;
//        RewriteRuleTokenStream stream_98=new RewriteRuleTokenStream(adaptor,"token 98");
//        RewriteRuleTokenStream stream_104=new RewriteRuleTokenStream(adaptor,"token 104");
//        RewriteRuleTokenStream stream_63=new RewriteRuleTokenStream(adaptor,"token 63");
//        RewriteRuleSubtreeStream stream_inner_statement_list=new RewriteRuleSubtreeStream(adaptor,"rule inner_statement_list");
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:259:2: ( ':' ( inner_statement_list )? 'endfor' ';' -> ( inner_statement_list )? )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:259:4: ':' ( inner_statement_list )? 'endfor' ';'
//            {
//            char_literal208=(Token)match(input,98,FOLLOW_98_in_for_statement2031); if (state.failed) return retval; 
//            if ( state.backtracking==0 ) stream_98.add(char_literal208);
//
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:259:8: ( inner_statement_list )?
//            int alt61=2;
//            int LA61_0 = input.LA(1);
//
//            if ( ((LA61_0>=IDENTIFIER && LA61_0<=DOUBLELITERRAL)||(LA61_0>=60 && LA61_0<=61)||(LA61_0>=63 && LA61_0<=64)||LA61_0==67||(LA61_0>=69 && LA61_0<=84)||(LA61_0>=86 && LA61_0<=89)||LA61_0==95||(LA61_0>=142 && LA61_0<=143)||(LA61_0>=154 && LA61_0<=155)||(LA61_0>=157 && LA61_0<=161)||(LA61_0>=163 && LA61_0<=166)||LA61_0==168||(LA61_0>=171 && LA61_0<=176)) ) {
//                alt61=1;
//            }
//            switch (alt61) {
//                case 1 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:259:8: inner_statement_list
//                    {
//                    pushFollow(FOLLOW_inner_statement_list_in_for_statement2033);
//                    inner_statement_list209=inner_statement_list();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) stream_inner_statement_list.add(inner_statement_list209.getTree());
//
//                    }
//                    break;
//
//            }
//
//            string_literal210=(Token)match(input,104,FOLLOW_104_in_for_statement2036); if (state.failed) return retval; 
//            if ( state.backtracking==0 ) stream_104.add(string_literal210);
//
//            char_literal211=(Token)match(input,63,FOLLOW_63_in_for_statement2038); if (state.failed) return retval; 
//            if ( state.backtracking==0 ) stream_63.add(char_literal211);
//
//
//
//            // AST REWRITE
//            // elements: inner_statement_list
//            // token labels: 
//            // rule labels: retval
//            // token list labels: 
//            // rule list labels: 
//            // wildcard labels: 
//            if ( state.backtracking==0 ) {
//            retval.tree = root_0;
//            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//            root_0 = (CommonTree)adaptor.nil();
//            // 259:44: -> ( inner_statement_list )?
//            {
//                // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:259:47: ( inner_statement_list )?
//                if ( stream_inner_statement_list.hasNext() ) {
//                    adaptor.addChild(root_0, stream_inner_statement_list.nextTree());
//
//                }
//                stream_inner_statement_list.reset();
//
//            }
//
//            retval.tree = root_0;}
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "for_statement"
//
//    public static class while_statement_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "while_statement"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:262:1: while_statement : ( statement -> statement | ':' ( inner_statement_list )? 'endwhile' ';' -> ( inner_statement_list )? );
//    public final CompilerAstParser.while_statement_return while_statement() throws RecognitionException {
//        CompilerAstParser.while_statement_return retval = new CompilerAstParser.while_statement_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token char_literal213=null;
//        Token string_literal215=null;
//        Token char_literal216=null;
//        CompilerAstParser.statement_return statement212 = null;
//
//        CompilerAstParser.inner_statement_list_return inner_statement_list214 = null;
//
//
//        CommonTree char_literal213_tree=null;
//        CommonTree string_literal215_tree=null;
//        CommonTree char_literal216_tree=null;
//        RewriteRuleTokenStream stream_98=new RewriteRuleTokenStream(adaptor,"token 98");
//        RewriteRuleTokenStream stream_105=new RewriteRuleTokenStream(adaptor,"token 105");
//        RewriteRuleTokenStream stream_63=new RewriteRuleTokenStream(adaptor,"token 63");
//        RewriteRuleSubtreeStream stream_statement=new RewriteRuleSubtreeStream(adaptor,"rule statement");
//        RewriteRuleSubtreeStream stream_inner_statement_list=new RewriteRuleSubtreeStream(adaptor,"rule inner_statement_list");
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:263:2: ( statement -> statement | ':' ( inner_statement_list )? 'endwhile' ';' -> ( inner_statement_list )? )
//            int alt63=2;
//            int LA63_0 = input.LA(1);
//
//            if ( ((LA63_0>=IDENTIFIER && LA63_0<=DOUBLELITERRAL)||LA63_0==61||LA63_0==63||LA63_0==67||(LA63_0>=72 && LA63_0<=84)||(LA63_0>=86 && LA63_0<=89)||LA63_0==95||(LA63_0>=142 && LA63_0<=143)||(LA63_0>=154 && LA63_0<=155)||(LA63_0>=157 && LA63_0<=161)||(LA63_0>=163 && LA63_0<=166)||LA63_0==168||(LA63_0>=171 && LA63_0<=176)) ) {
//                alt63=1;
//            }
//            else if ( (LA63_0==98) ) {
//                alt63=2;
//            }
//            else {
//                if (state.backtracking>0) {state.failed=true; return retval;}
//                NoViableAltException nvae =
//                    new NoViableAltException("", 63, 0, input);
//
//                throw nvae;
//            }
//            switch (alt63) {
//                case 1 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:263:4: statement
//                    {
//                    pushFollow(FOLLOW_statement_in_while_statement2056);
//                    statement212=statement();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) stream_statement.add(statement212.getTree());
//
//
//                    // AST REWRITE
//                    // elements: statement
//                    // token labels: 
//                    // rule labels: retval
//                    // token list labels: 
//                    // rule list labels: 
//                    // wildcard labels: 
//                    if ( state.backtracking==0 ) {
//                    retval.tree = root_0;
//                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//                    root_0 = (CommonTree)adaptor.nil();
//                    // 263:22: -> statement
//                    {
//                        adaptor.addChild(root_0, stream_statement.nextTree());
//
//                    }
//
//                    retval.tree = root_0;}
//                    }
//                    break;
//                case 2 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:264:4: ':' ( inner_statement_list )? 'endwhile' ';'
//                    {
//                    char_literal213=(Token)match(input,98,FOLLOW_98_in_while_statement2073); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_98.add(char_literal213);
//
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:264:8: ( inner_statement_list )?
//                    int alt62=2;
//                    int LA62_0 = input.LA(1);
//
//                    if ( ((LA62_0>=IDENTIFIER && LA62_0<=DOUBLELITERRAL)||(LA62_0>=60 && LA62_0<=61)||(LA62_0>=63 && LA62_0<=64)||LA62_0==67||(LA62_0>=69 && LA62_0<=84)||(LA62_0>=86 && LA62_0<=89)||LA62_0==95||(LA62_0>=142 && LA62_0<=143)||(LA62_0>=154 && LA62_0<=155)||(LA62_0>=157 && LA62_0<=161)||(LA62_0>=163 && LA62_0<=166)||LA62_0==168||(LA62_0>=171 && LA62_0<=176)) ) {
//                        alt62=1;
//                    }
//                    switch (alt62) {
//                        case 1 :
//                            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:264:8: inner_statement_list
//                            {
//                            pushFollow(FOLLOW_inner_statement_list_in_while_statement2075);
//                            inner_statement_list214=inner_statement_list();
//
//                            state._fsp--;
//                            if (state.failed) return retval;
//                            if ( state.backtracking==0 ) stream_inner_statement_list.add(inner_statement_list214.getTree());
//
//                            }
//                            break;
//
//                    }
//
//                    string_literal215=(Token)match(input,105,FOLLOW_105_in_while_statement2078); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_105.add(string_literal215);
//
//                    char_literal216=(Token)match(input,63,FOLLOW_63_in_while_statement2080); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_63.add(char_literal216);
//
//
//
//                    // AST REWRITE
//                    // elements: inner_statement_list
//                    // token labels: 
//                    // rule labels: retval
//                    // token list labels: 
//                    // rule list labels: 
//                    // wildcard labels: 
//                    if ( state.backtracking==0 ) {
//                    retval.tree = root_0;
//                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//                    root_0 = (CommonTree)adaptor.nil();
//                    // 264:46: -> ( inner_statement_list )?
//                    {
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:264:49: ( inner_statement_list )?
//                        if ( stream_inner_statement_list.hasNext() ) {
//                            adaptor.addChild(root_0, stream_inner_statement_list.nextTree());
//
//                        }
//                        stream_inner_statement_list.reset();
//
//                    }
//
//                    retval.tree = root_0;}
//                    }
//                    break;
//
//            }
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "while_statement"
//
//    public static class foreach_statement_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "foreach_statement"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:267:1: foreach_statement : ( statement -> statement | ':' ( inner_statement_list )? 'endforeach' ';' -> ( inner_statement_list )? );
//    public final CompilerAstParser.foreach_statement_return foreach_statement() throws RecognitionException {
//        CompilerAstParser.foreach_statement_return retval = new CompilerAstParser.foreach_statement_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token char_literal218=null;
//        Token string_literal220=null;
//        Token char_literal221=null;
//        CompilerAstParser.statement_return statement217 = null;
//
//        CompilerAstParser.inner_statement_list_return inner_statement_list219 = null;
//
//
//        CommonTree char_literal218_tree=null;
//        CommonTree string_literal220_tree=null;
//        CommonTree char_literal221_tree=null;
//        RewriteRuleTokenStream stream_98=new RewriteRuleTokenStream(adaptor,"token 98");
//        RewriteRuleTokenStream stream_106=new RewriteRuleTokenStream(adaptor,"token 106");
//        RewriteRuleTokenStream stream_63=new RewriteRuleTokenStream(adaptor,"token 63");
//        RewriteRuleSubtreeStream stream_statement=new RewriteRuleSubtreeStream(adaptor,"rule statement");
//        RewriteRuleSubtreeStream stream_inner_statement_list=new RewriteRuleSubtreeStream(adaptor,"rule inner_statement_list");
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:268:3: ( statement -> statement | ':' ( inner_statement_list )? 'endforeach' ';' -> ( inner_statement_list )? )
//            int alt65=2;
//            int LA65_0 = input.LA(1);
//
//            if ( ((LA65_0>=IDENTIFIER && LA65_0<=DOUBLELITERRAL)||LA65_0==61||LA65_0==63||LA65_0==67||(LA65_0>=72 && LA65_0<=84)||(LA65_0>=86 && LA65_0<=89)||LA65_0==95||(LA65_0>=142 && LA65_0<=143)||(LA65_0>=154 && LA65_0<=155)||(LA65_0>=157 && LA65_0<=161)||(LA65_0>=163 && LA65_0<=166)||LA65_0==168||(LA65_0>=171 && LA65_0<=176)) ) {
//                alt65=1;
//            }
//            else if ( (LA65_0==98) ) {
//                alt65=2;
//            }
//            else {
//                if (state.backtracking>0) {state.failed=true; return retval;}
//                NoViableAltException nvae =
//                    new NoViableAltException("", 65, 0, input);
//
//                throw nvae;
//            }
//            switch (alt65) {
//                case 1 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:268:5: statement
//                    {
//                    pushFollow(FOLLOW_statement_in_foreach_statement2099);
//                    statement217=statement();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) stream_statement.add(statement217.getTree());
//
//
//                    // AST REWRITE
//                    // elements: statement
//                    // token labels: 
//                    // rule labels: retval
//                    // token list labels: 
//                    // rule list labels: 
//                    // wildcard labels: 
//                    if ( state.backtracking==0 ) {
//                    retval.tree = root_0;
//                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//                    root_0 = (CommonTree)adaptor.nil();
//                    // 268:23: -> statement
//                    {
//                        adaptor.addChild(root_0, stream_statement.nextTree());
//
//                    }
//
//                    retval.tree = root_0;}
//                    }
//                    break;
//                case 2 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:269:5: ':' ( inner_statement_list )? 'endforeach' ';'
//                    {
//                    char_literal218=(Token)match(input,98,FOLLOW_98_in_foreach_statement2117); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_98.add(char_literal218);
//
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:269:9: ( inner_statement_list )?
//                    int alt64=2;
//                    int LA64_0 = input.LA(1);
//
//                    if ( ((LA64_0>=IDENTIFIER && LA64_0<=DOUBLELITERRAL)||(LA64_0>=60 && LA64_0<=61)||(LA64_0>=63 && LA64_0<=64)||LA64_0==67||(LA64_0>=69 && LA64_0<=84)||(LA64_0>=86 && LA64_0<=89)||LA64_0==95||(LA64_0>=142 && LA64_0<=143)||(LA64_0>=154 && LA64_0<=155)||(LA64_0>=157 && LA64_0<=161)||(LA64_0>=163 && LA64_0<=166)||LA64_0==168||(LA64_0>=171 && LA64_0<=176)) ) {
//                        alt64=1;
//                    }
//                    switch (alt64) {
//                        case 1 :
//                            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:269:9: inner_statement_list
//                            {
//                            pushFollow(FOLLOW_inner_statement_list_in_foreach_statement2119);
//                            inner_statement_list219=inner_statement_list();
//
//                            state._fsp--;
//                            if (state.failed) return retval;
//                            if ( state.backtracking==0 ) stream_inner_statement_list.add(inner_statement_list219.getTree());
//
//                            }
//                            break;
//
//                    }
//
//                    string_literal220=(Token)match(input,106,FOLLOW_106_in_foreach_statement2122); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_106.add(string_literal220);
//
//                    char_literal221=(Token)match(input,63,FOLLOW_63_in_foreach_statement2124); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_63.add(char_literal221);
//
//
//
//                    // AST REWRITE
//                    // elements: inner_statement_list
//                    // token labels: 
//                    // rule labels: retval
//                    // token list labels: 
//                    // rule list labels: 
//                    // wildcard labels: 
//                    if ( state.backtracking==0 ) {
//                    retval.tree = root_0;
//                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//                    root_0 = (CommonTree)adaptor.nil();
//                    // 269:48: -> ( inner_statement_list )?
//                    {
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:269:51: ( inner_statement_list )?
//                        if ( stream_inner_statement_list.hasNext() ) {
//                            adaptor.addChild(root_0, stream_inner_statement_list.nextTree());
//
//                        }
//                        stream_inner_statement_list.reset();
//
//                    }
//
//                    retval.tree = root_0;}
//                    }
//                    break;
//
//            }
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "foreach_statement"
//
//    public static class declare_statement_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "declare_statement"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:272:1: declare_statement : ( statement -> statement | ':' ( inner_statement_list )? 'enddeclare' ';' -> ( inner_statement_list )? );
//    public final CompilerAstParser.declare_statement_return declare_statement() throws RecognitionException {
//        CompilerAstParser.declare_statement_return retval = new CompilerAstParser.declare_statement_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token char_literal223=null;
//        Token string_literal225=null;
//        Token char_literal226=null;
//        CompilerAstParser.statement_return statement222 = null;
//
//        CompilerAstParser.inner_statement_list_return inner_statement_list224 = null;
//
//
//        CommonTree char_literal223_tree=null;
//        CommonTree string_literal225_tree=null;
//        CommonTree char_literal226_tree=null;
//        RewriteRuleTokenStream stream_98=new RewriteRuleTokenStream(adaptor,"token 98");
//        RewriteRuleTokenStream stream_107=new RewriteRuleTokenStream(adaptor,"token 107");
//        RewriteRuleTokenStream stream_63=new RewriteRuleTokenStream(adaptor,"token 63");
//        RewriteRuleSubtreeStream stream_statement=new RewriteRuleSubtreeStream(adaptor,"rule statement");
//        RewriteRuleSubtreeStream stream_inner_statement_list=new RewriteRuleSubtreeStream(adaptor,"rule inner_statement_list");
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:273:3: ( statement -> statement | ':' ( inner_statement_list )? 'enddeclare' ';' -> ( inner_statement_list )? )
//            int alt67=2;
//            int LA67_0 = input.LA(1);
//
//            if ( ((LA67_0>=IDENTIFIER && LA67_0<=DOUBLELITERRAL)||LA67_0==61||LA67_0==63||LA67_0==67||(LA67_0>=72 && LA67_0<=84)||(LA67_0>=86 && LA67_0<=89)||LA67_0==95||(LA67_0>=142 && LA67_0<=143)||(LA67_0>=154 && LA67_0<=155)||(LA67_0>=157 && LA67_0<=161)||(LA67_0>=163 && LA67_0<=166)||LA67_0==168||(LA67_0>=171 && LA67_0<=176)) ) {
//                alt67=1;
//            }
//            else if ( (LA67_0==98) ) {
//                alt67=2;
//            }
//            else {
//                if (state.backtracking>0) {state.failed=true; return retval;}
//                NoViableAltException nvae =
//                    new NoViableAltException("", 67, 0, input);
//
//                throw nvae;
//            }
//            switch (alt67) {
//                case 1 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:273:5: statement
//                    {
//                    pushFollow(FOLLOW_statement_in_declare_statement2144);
//                    statement222=statement();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) stream_statement.add(statement222.getTree());
//
//
//                    // AST REWRITE
//                    // elements: statement
//                    // token labels: 
//                    // rule labels: retval
//                    // token list labels: 
//                    // rule list labels: 
//                    // wildcard labels: 
//                    if ( state.backtracking==0 ) {
//                    retval.tree = root_0;
//                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//                    root_0 = (CommonTree)adaptor.nil();
//                    // 273:23: -> statement
//                    {
//                        adaptor.addChild(root_0, stream_statement.nextTree());
//
//                    }
//
//                    retval.tree = root_0;}
//                    }
//                    break;
//                case 2 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:274:5: ':' ( inner_statement_list )? 'enddeclare' ';'
//                    {
//                    char_literal223=(Token)match(input,98,FOLLOW_98_in_declare_statement2162); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_98.add(char_literal223);
//
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:274:9: ( inner_statement_list )?
//                    int alt66=2;
//                    int LA66_0 = input.LA(1);
//
//                    if ( ((LA66_0>=IDENTIFIER && LA66_0<=DOUBLELITERRAL)||(LA66_0>=60 && LA66_0<=61)||(LA66_0>=63 && LA66_0<=64)||LA66_0==67||(LA66_0>=69 && LA66_0<=84)||(LA66_0>=86 && LA66_0<=89)||LA66_0==95||(LA66_0>=142 && LA66_0<=143)||(LA66_0>=154 && LA66_0<=155)||(LA66_0>=157 && LA66_0<=161)||(LA66_0>=163 && LA66_0<=166)||LA66_0==168||(LA66_0>=171 && LA66_0<=176)) ) {
//                        alt66=1;
//                    }
//                    switch (alt66) {
//                        case 1 :
//                            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:274:9: inner_statement_list
//                            {
//                            pushFollow(FOLLOW_inner_statement_list_in_declare_statement2164);
//                            inner_statement_list224=inner_statement_list();
//
//                            state._fsp--;
//                            if (state.failed) return retval;
//                            if ( state.backtracking==0 ) stream_inner_statement_list.add(inner_statement_list224.getTree());
//
//                            }
//                            break;
//
//                    }
//
//                    string_literal225=(Token)match(input,107,FOLLOW_107_in_declare_statement2167); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_107.add(string_literal225);
//
//                    char_literal226=(Token)match(input,63,FOLLOW_63_in_declare_statement2169); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_63.add(char_literal226);
//
//
//
//                    // AST REWRITE
//                    // elements: inner_statement_list
//                    // token labels: 
//                    // rule labels: retval
//                    // token list labels: 
//                    // rule list labels: 
//                    // wildcard labels: 
//                    if ( state.backtracking==0 ) {
//                    retval.tree = root_0;
//                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//                    root_0 = (CommonTree)adaptor.nil();
//                    // 274:48: -> ( inner_statement_list )?
//                    {
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:274:51: ( inner_statement_list )?
//                        if ( stream_inner_statement_list.hasNext() ) {
//                            adaptor.addChild(root_0, stream_inner_statement_list.nextTree());
//
//                        }
//                        stream_inner_statement_list.reset();
//
//                    }
//
//                    retval.tree = root_0;}
//                    }
//                    break;
//
//            }
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "declare_statement"
//
//    public static class parameter_list_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "parameter_list"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:277:1: parameter_list : parameter ( ',' parameter )* -> ( parameter )+ ;
//    public final CompilerAstParser.parameter_list_return parameter_list() throws RecognitionException {
//        CompilerAstParser.parameter_list_return retval = new CompilerAstParser.parameter_list_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token char_literal228=null;
//        CompilerAstParser.parameter_return parameter227 = null;
//
//        CompilerAstParser.parameter_return parameter229 = null;
//
//
//        CommonTree char_literal228_tree=null;
//        RewriteRuleTokenStream stream_93=new RewriteRuleTokenStream(adaptor,"token 93");
//        RewriteRuleSubtreeStream stream_parameter=new RewriteRuleSubtreeStream(adaptor,"rule parameter");
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:278:3: ( parameter ( ',' parameter )* -> ( parameter )+ )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:278:5: parameter ( ',' parameter )*
//            {
//            pushFollow(FOLLOW_parameter_in_parameter_list2189);
//            parameter227=parameter();
//
//            state._fsp--;
//            if (state.failed) return retval;
//            if ( state.backtracking==0 ) stream_parameter.add(parameter227.getTree());
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:278:15: ( ',' parameter )*
//            loop68:
//            do {
//                int alt68=2;
//                int LA68_0 = input.LA(1);
//
//                if ( (LA68_0==93) ) {
//                    alt68=1;
//                }
//
//
//                switch (alt68) {
//            	case 1 :
//            	    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:278:16: ',' parameter
//            	    {
//            	    char_literal228=(Token)match(input,93,FOLLOW_93_in_parameter_list2192); if (state.failed) return retval; 
//            	    if ( state.backtracking==0 ) stream_93.add(char_literal228);
//
//            	    pushFollow(FOLLOW_parameter_in_parameter_list2194);
//            	    parameter229=parameter();
//
//            	    state._fsp--;
//            	    if (state.failed) return retval;
//            	    if ( state.backtracking==0 ) stream_parameter.add(parameter229.getTree());
//
//            	    }
//            	    break;
//
//            	default :
//            	    break loop68;
//                }
//            } while (true);
//
//
//
//            // AST REWRITE
//            // elements: parameter
//            // token labels: 
//            // rule labels: retval
//            // token list labels: 
//            // rule list labels: 
//            // wildcard labels: 
//            if ( state.backtracking==0 ) {
//            retval.tree = root_0;
//            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//            root_0 = (CommonTree)adaptor.nil();
//            // 278:36: -> ( parameter )+
//            {
//                if ( !(stream_parameter.hasNext()) ) {
//                    throw new RewriteEarlyExitException();
//                }
//                while ( stream_parameter.hasNext() ) {
//                    adaptor.addChild(root_0, stream_parameter.nextTree());
//
//                }
//                stream_parameter.reset();
//
//            }
//
//            retval.tree = root_0;}
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "parameter_list"
//
//    public static class parameter_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "parameter"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:281:1: parameter : ( parameter_type )? ( 'const' )? pure_variable ( options {k=1; backtrack=true; } : '=' static_scalar )? -> ^( PARAMETER ( ^( TYPE parameter_type ) )? ( 'const' )? pure_variable ( static_scalar )? ) ;
//    public final CompilerAstParser.parameter_return parameter() throws RecognitionException {
//        CompilerAstParser.parameter_return retval = new CompilerAstParser.parameter_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token string_literal231=null;
//        Token char_literal233=null;
//        CompilerAstParser.parameter_type_return parameter_type230 = null;
//
//        CompilerAstParser.pure_variable_return pure_variable232 = null;
//
//        CompilerAstParser.static_scalar_return static_scalar234 = null;
//
//
//        CommonTree string_literal231_tree=null;
//        CommonTree char_literal233_tree=null;
//        RewriteRuleTokenStream stream_94=new RewriteRuleTokenStream(adaptor,"token 94");
//        RewriteRuleTokenStream stream_91=new RewriteRuleTokenStream(adaptor,"token 91");
//        RewriteRuleSubtreeStream stream_static_scalar=new RewriteRuleSubtreeStream(adaptor,"rule static_scalar");
//        RewriteRuleSubtreeStream stream_parameter_type=new RewriteRuleSubtreeStream(adaptor,"rule parameter_type");
//        RewriteRuleSubtreeStream stream_pure_variable=new RewriteRuleSubtreeStream(adaptor,"rule pure_variable");
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:282:3: ( ( parameter_type )? ( 'const' )? pure_variable ( options {k=1; backtrack=true; } : '=' static_scalar )? -> ^( PARAMETER ( ^( TYPE parameter_type ) )? ( 'const' )? pure_variable ( static_scalar )? ) )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:282:5: ( parameter_type )? ( 'const' )? pure_variable ( options {k=1; backtrack=true; } : '=' static_scalar )?
//            {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:282:5: ( parameter_type )?
//            int alt69=2;
//            int LA69_0 = input.LA(1);
//
//            if ( (LA69_0==IDENTIFIER||(LA69_0>=147 && LA69_0<=157)) ) {
//                alt69=1;
//            }
//            switch (alt69) {
//                case 1 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:282:5: parameter_type
//                    {
//                    pushFollow(FOLLOW_parameter_type_in_parameter2220);
//                    parameter_type230=parameter_type();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) stream_parameter_type.add(parameter_type230.getTree());
//
//                    }
//                    break;
//
//            }
//
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:282:21: ( 'const' )?
//            int alt70=2;
//            int LA70_0 = input.LA(1);
//
//            if ( (LA70_0==91) ) {
//                alt70=1;
//            }
//            switch (alt70) {
//                case 1 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:282:21: 'const'
//                    {
//                    string_literal231=(Token)match(input,91,FOLLOW_91_in_parameter2223); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_91.add(string_literal231);
//
//
//                    }
//                    break;
//
//            }
//
//            pushFollow(FOLLOW_pure_variable_in_parameter2226);
//            pure_variable232=pure_variable();
//
//            state._fsp--;
//            if (state.failed) return retval;
//            if ( state.backtracking==0 ) stream_pure_variable.add(pure_variable232.getTree());
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:282:44: ( options {k=1; backtrack=true; } : '=' static_scalar )?
//            int alt71=2;
//            int LA71_0 = input.LA(1);
//
//            if ( (LA71_0==94) ) {
//                alt71=1;
//            }
//            switch (alt71) {
//                case 1 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:282:76: '=' static_scalar
//                    {
//                    char_literal233=(Token)match(input,94,FOLLOW_94_in_parameter2242); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_94.add(char_literal233);
//
//                    pushFollow(FOLLOW_static_scalar_in_parameter2244);
//                    static_scalar234=static_scalar();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) stream_static_scalar.add(static_scalar234.getTree());
//
//                    }
//                    break;
//
//            }
//
//
//
//            // AST REWRITE
//            // elements: 91, pure_variable, parameter_type, static_scalar
//            // token labels: 
//            // rule labels: retval
//            // token list labels: 
//            // rule list labels: 
//            // wildcard labels: 
//            if ( state.backtracking==0 ) {
//            retval.tree = root_0;
//            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//            root_0 = (CommonTree)adaptor.nil();
//            // 283:3: -> ^( PARAMETER ( ^( TYPE parameter_type ) )? ( 'const' )? pure_variable ( static_scalar )? )
//            {
//                // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:283:6: ^( PARAMETER ( ^( TYPE parameter_type ) )? ( 'const' )? pure_variable ( static_scalar )? )
//                {
//                CommonTree root_1 = (CommonTree)adaptor.nil();
//                root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(PARAMETER, "PARAMETER"), root_1);
//
//                // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:283:18: ( ^( TYPE parameter_type ) )?
//                if ( stream_parameter_type.hasNext() ) {
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:283:18: ^( TYPE parameter_type )
//                    {
//                    CommonTree root_2 = (CommonTree)adaptor.nil();
//                    root_2 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(TYPE, "TYPE"), root_2);
//
//                    adaptor.addChild(root_2, stream_parameter_type.nextTree());
//
//                    adaptor.addChild(root_1, root_2);
//                    }
//
//                }
//                stream_parameter_type.reset();
//                // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:283:42: ( 'const' )?
//                if ( stream_91.hasNext() ) {
//                    adaptor.addChild(root_1, stream_91.nextNode());
//
//                }
//                stream_91.reset();
//                adaptor.addChild(root_1, stream_pure_variable.nextTree());
//                // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:283:65: ( static_scalar )?
//                if ( stream_static_scalar.hasNext() ) {
//                    adaptor.addChild(root_1, stream_static_scalar.nextTree());
//
//                }
//                stream_static_scalar.reset();
//
//                adaptor.addChild(root_0, root_1);
//                }
//
//            }
//
//            retval.tree = root_0;}
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "parameter"
//
//    public static class parameter_type_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "parameter_type"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:286:1: parameter_type : ( fully_qualified_class_name | cast_option );
//    public final CompilerAstParser.parameter_type_return parameter_type() throws RecognitionException {
//        CompilerAstParser.parameter_type_return retval = new CompilerAstParser.parameter_type_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        CompilerAstParser.fully_qualified_class_name_return fully_qualified_class_name235 = null;
//
//        CompilerAstParser.cast_option_return cast_option236 = null;
//
//
//
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:287:2: ( fully_qualified_class_name | cast_option )
//            int alt72=2;
//            int LA72_0 = input.LA(1);
//
//            if ( (LA72_0==IDENTIFIER) ) {
//                alt72=1;
//            }
//            else if ( ((LA72_0>=147 && LA72_0<=157)) ) {
//                alt72=2;
//            }
//            else {
//                if (state.backtracking>0) {state.failed=true; return retval;}
//                NoViableAltException nvae =
//                    new NoViableAltException("", 72, 0, input);
//
//                throw nvae;
//            }
//            switch (alt72) {
//                case 1 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:287:4: fully_qualified_class_name
//                    {
//                    root_0 = (CommonTree)adaptor.nil();
//
//                    pushFollow(FOLLOW_fully_qualified_class_name_in_parameter_type2283);
//                    fully_qualified_class_name235=fully_qualified_class_name();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) adaptor.addChild(root_0, fully_qualified_class_name235.getTree());
//
//                    }
//                    break;
//                case 2 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:287:33: cast_option
//                    {
//                    root_0 = (CommonTree)adaptor.nil();
//
//                    pushFollow(FOLLOW_cast_option_in_parameter_type2287);
//                    cast_option236=cast_option();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) adaptor.addChild(root_0, cast_option236.getTree());
//
//                    }
//                    break;
//
//            }
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "parameter_type"
//
//    public static class variable_list_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "variable_list"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:290:1: variable_list : variable ( ',' variable )* -> ( variable )+ ;
//    public final CompilerAstParser.variable_list_return variable_list() throws RecognitionException {
//        CompilerAstParser.variable_list_return retval = new CompilerAstParser.variable_list_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token char_literal238=null;
//        CompilerAstParser.variable_return variable237 = null;
//
//        CompilerAstParser.variable_return variable239 = null;
//
//
//        CommonTree char_literal238_tree=null;
//        RewriteRuleTokenStream stream_93=new RewriteRuleTokenStream(adaptor,"token 93");
//        RewriteRuleSubtreeStream stream_variable=new RewriteRuleSubtreeStream(adaptor,"rule variable");
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:291:2: ( variable ( ',' variable )* -> ( variable )+ )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:291:4: variable ( ',' variable )*
//            {
//            pushFollow(FOLLOW_variable_in_variable_list2300);
//            variable237=variable();
//
//            state._fsp--;
//            if (state.failed) return retval;
//            if ( state.backtracking==0 ) stream_variable.add(variable237.getTree());
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:291:13: ( ',' variable )*
//            loop73:
//            do {
//                int alt73=2;
//                int LA73_0 = input.LA(1);
//
//                if ( (LA73_0==93) ) {
//                    alt73=1;
//                }
//
//
//                switch (alt73) {
//            	case 1 :
//            	    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:291:14: ',' variable
//            	    {
//            	    char_literal238=(Token)match(input,93,FOLLOW_93_in_variable_list2303); if (state.failed) return retval; 
//            	    if ( state.backtracking==0 ) stream_93.add(char_literal238);
//
//            	    pushFollow(FOLLOW_variable_in_variable_list2305);
//            	    variable239=variable();
//
//            	    state._fsp--;
//            	    if (state.failed) return retval;
//            	    if ( state.backtracking==0 ) stream_variable.add(variable239.getTree());
//
//            	    }
//            	    break;
//
//            	default :
//            	    break loop73;
//                }
//            } while (true);
//
//
//
//            // AST REWRITE
//            // elements: variable
//            // token labels: 
//            // rule labels: retval
//            // token list labels: 
//            // rule list labels: 
//            // wildcard labels: 
//            if ( state.backtracking==0 ) {
//            retval.tree = root_0;
//            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//            root_0 = (CommonTree)adaptor.nil();
//            // 291:30: -> ( variable )+
//            {
//                if ( !(stream_variable.hasNext()) ) {
//                    throw new RewriteEarlyExitException();
//                }
//                while ( stream_variable.hasNext() ) {
//                    adaptor.addChild(root_0, stream_variable.nextTree());
//
//                }
//                stream_variable.reset();
//
//            }
//
//            retval.tree = root_0;}
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "variable_list"
//
//    public static class variable_modifiers_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "variable_modifiers"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:294:1: variable_modifiers : ( 'var' | modifier );
//    public final CompilerAstParser.variable_modifiers_return variable_modifiers() throws RecognitionException {
//        CompilerAstParser.variable_modifiers_return retval = new CompilerAstParser.variable_modifiers_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token string_literal240=null;
//        CompilerAstParser.modifier_return modifier241 = null;
//
//
//        CommonTree string_literal240_tree=null;
//
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:295:3: ( 'var' | modifier )
//            int alt74=2;
//            int LA74_0 = input.LA(1);
//
//            if ( (LA74_0==108) ) {
//                alt74=1;
//            }
//            else if ( ((LA74_0>=70 && LA74_0<=71)||LA74_0==82||(LA74_0>=109 && LA74_0<=111)) ) {
//                alt74=2;
//            }
//            else {
//                if (state.backtracking>0) {state.failed=true; return retval;}
//                NoViableAltException nvae =
//                    new NoViableAltException("", 74, 0, input);
//
//                throw nvae;
//            }
//            switch (alt74) {
//                case 1 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:295:5: 'var'
//                    {
//                    root_0 = (CommonTree)adaptor.nil();
//
//                    string_literal240=(Token)match(input,108,FOLLOW_108_in_variable_modifiers2327); if (state.failed) return retval;
//                    if ( state.backtracking==0 ) {
//                    string_literal240_tree = (CommonTree)adaptor.create(string_literal240);
//                    adaptor.addChild(root_0, string_literal240_tree);
//                    }
//
//                    }
//                    break;
//                case 2 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:296:5: modifier
//                    {
//                    root_0 = (CommonTree)adaptor.nil();
//
//                    pushFollow(FOLLOW_modifier_in_variable_modifiers2333);
//                    modifier241=modifier();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) adaptor.addChild(root_0, modifier241.getTree());
//
//                    }
//                    break;
//
//            }
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "variable_modifiers"
//
//    public static class modifier_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "modifier"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:299:1: modifier : ( 'public' | 'protected' | 'private' | 'static' | 'abstract' | 'final' )+ ;
//    public final CompilerAstParser.modifier_return modifier() throws RecognitionException {
//        CompilerAstParser.modifier_return retval = new CompilerAstParser.modifier_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token set242=null;
//
//        CommonTree set242_tree=null;
//
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:300:3: ( ( 'public' | 'protected' | 'private' | 'static' | 'abstract' | 'final' )+ )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:300:5: ( 'public' | 'protected' | 'private' | 'static' | 'abstract' | 'final' )+
//            {
//            root_0 = (CommonTree)adaptor.nil();
//
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:300:5: ( 'public' | 'protected' | 'private' | 'static' | 'abstract' | 'final' )+
//            int cnt75=0;
//            loop75:
//            do {
//                int alt75=2;
//                int LA75_0 = input.LA(1);
//
//                if ( ((LA75_0>=70 && LA75_0<=71)||LA75_0==82||(LA75_0>=109 && LA75_0<=111)) ) {
//                    alt75=1;
//                }
//
//
//                switch (alt75) {
//            	case 1 :
//            	    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:
//            	    {
//            	    set242=(Token)input.LT(1);
//            	    if ( (input.LA(1)>=70 && input.LA(1)<=71)||input.LA(1)==82||(input.LA(1)>=109 && input.LA(1)<=111) ) {
//            	        input.consume();
//            	        if ( state.backtracking==0 ) adaptor.addChild(root_0, (CommonTree)adaptor.create(set242));
//            	        state.errorRecovery=false;state.failed=false;
//            	    }
//            	    else {
//            	        if (state.backtracking>0) {state.failed=true; return retval;}
//            	        MismatchedSetException mse = new MismatchedSetException(null,input);
//            	        throw mse;
//            	    }
//
//
//            	    }
//            	    break;
//
//            	default :
//            	    if ( cnt75 >= 1 ) break loop75;
//            	    if (state.backtracking>0) {state.failed=true; return retval;}
//                        EarlyExitException eee =
//                            new EarlyExitException(75, input);
//                        throw eee;
//                }
//                cnt75++;
//            } while (true);
//
//
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "modifier"
//
//    public static class directive_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "directive"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:308:1: directive : IDENTIFIER '=' expression ( ',' IDENTIFIER '=' expression )* -> ^( '=' IDENTIFIER expression ) ;
//    public final CompilerAstParser.directive_return directive() throws RecognitionException {
//        CompilerAstParser.directive_return retval = new CompilerAstParser.directive_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token IDENTIFIER243=null;
//        Token char_literal244=null;
//        Token char_literal246=null;
//        Token IDENTIFIER247=null;
//        Token char_literal248=null;
//        CompilerAstParser.expression_return expression245 = null;
//
//        CompilerAstParser.expression_return expression249 = null;
//
//
//        CommonTree IDENTIFIER243_tree=null;
//        CommonTree char_literal244_tree=null;
//        CommonTree char_literal246_tree=null;
//        CommonTree IDENTIFIER247_tree=null;
//        CommonTree char_literal248_tree=null;
//        RewriteRuleTokenStream stream_94=new RewriteRuleTokenStream(adaptor,"token 94");
//        RewriteRuleTokenStream stream_93=new RewriteRuleTokenStream(adaptor,"token 93");
//        RewriteRuleTokenStream stream_IDENTIFIER=new RewriteRuleTokenStream(adaptor,"token IDENTIFIER");
//        RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:309:3: ( IDENTIFIER '=' expression ( ',' IDENTIFIER '=' expression )* -> ^( '=' IDENTIFIER expression ) )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:309:5: IDENTIFIER '=' expression ( ',' IDENTIFIER '=' expression )*
//            {
//            IDENTIFIER243=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_directive2398); if (state.failed) return retval; 
//            if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER243);
//
//            char_literal244=(Token)match(input,94,FOLLOW_94_in_directive2400); if (state.failed) return retval; 
//            if ( state.backtracking==0 ) stream_94.add(char_literal244);
//
//            pushFollow(FOLLOW_expression_in_directive2402);
//            expression245=expression();
//
//            state._fsp--;
//            if (state.failed) return retval;
//            if ( state.backtracking==0 ) stream_expression.add(expression245.getTree());
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:309:31: ( ',' IDENTIFIER '=' expression )*
//            loop76:
//            do {
//                int alt76=2;
//                int LA76_0 = input.LA(1);
//
//                if ( (LA76_0==93) ) {
//                    alt76=1;
//                }
//
//
//                switch (alt76) {
//            	case 1 :
//            	    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:309:32: ',' IDENTIFIER '=' expression
//            	    {
//            	    char_literal246=(Token)match(input,93,FOLLOW_93_in_directive2405); if (state.failed) return retval; 
//            	    if ( state.backtracking==0 ) stream_93.add(char_literal246);
//
//            	    IDENTIFIER247=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_directive2407); if (state.failed) return retval; 
//            	    if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER247);
//
//            	    char_literal248=(Token)match(input,94,FOLLOW_94_in_directive2409); if (state.failed) return retval; 
//            	    if ( state.backtracking==0 ) stream_94.add(char_literal248);
//
//            	    pushFollow(FOLLOW_expression_in_directive2411);
//            	    expression249=expression();
//
//            	    state._fsp--;
//            	    if (state.failed) return retval;
//            	    if ( state.backtracking==0 ) stream_expression.add(expression249.getTree());
//
//            	    }
//            	    break;
//
//            	default :
//            	    break loop76;
//                }
//            } while (true);
//
//
//
//            // AST REWRITE
//            // elements: expression, IDENTIFIER, 94
//            // token labels: 
//            // rule labels: retval
//            // token list labels: 
//            // rule list labels: 
//            // wildcard labels: 
//            if ( state.backtracking==0 ) {
//            retval.tree = root_0;
//            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//            root_0 = (CommonTree)adaptor.nil();
//            // 309:64: -> ^( '=' IDENTIFIER expression )
//            {
//                // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:309:67: ^( '=' IDENTIFIER expression )
//                {
//                CommonTree root_1 = (CommonTree)adaptor.nil();
//                root_1 = (CommonTree)adaptor.becomeRoot(stream_94.nextNode(), root_1);
//
//                adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());
//                adaptor.addChild(root_1, stream_expression.nextTree());
//
//                adaptor.addChild(root_0, root_1);
//                }
//
//            }
//
//            retval.tree = root_0;}
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "directive"
//
//    public static class expr_list_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "expr_list"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:312:1: expr_list : expression ( ',' expression )* -> ( expression )+ ;
//    public final CompilerAstParser.expr_list_return expr_list() throws RecognitionException {
//        CompilerAstParser.expr_list_return retval = new CompilerAstParser.expr_list_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token char_literal251=null;
//        CompilerAstParser.expression_return expression250 = null;
//
//        CompilerAstParser.expression_return expression252 = null;
//
//
//        CommonTree char_literal251_tree=null;
//        RewriteRuleTokenStream stream_93=new RewriteRuleTokenStream(adaptor,"token 93");
//        RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:313:2: ( expression ( ',' expression )* -> ( expression )+ )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:313:4: expression ( ',' expression )*
//            {
//            pushFollow(FOLLOW_expression_in_expr_list2437);
//            expression250=expression();
//
//            state._fsp--;
//            if (state.failed) return retval;
//            if ( state.backtracking==0 ) stream_expression.add(expression250.getTree());
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:313:15: ( ',' expression )*
//            loop77:
//            do {
//                int alt77=2;
//                int LA77_0 = input.LA(1);
//
//                if ( (LA77_0==93) ) {
//                    alt77=1;
//                }
//
//
//                switch (alt77) {
//            	case 1 :
//            	    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:313:16: ',' expression
//            	    {
//            	    char_literal251=(Token)match(input,93,FOLLOW_93_in_expr_list2440); if (state.failed) return retval; 
//            	    if ( state.backtracking==0 ) stream_93.add(char_literal251);
//
//            	    pushFollow(FOLLOW_expression_in_expr_list2442);
//            	    expression252=expression();
//
//            	    state._fsp--;
//            	    if (state.failed) return retval;
//            	    if ( state.backtracking==0 ) stream_expression.add(expression252.getTree());
//
//            	    }
//            	    break;
//
//            	default :
//            	    break loop77;
//                }
//            } while (true);
//
//
//
//            // AST REWRITE
//            // elements: expression
//            // token labels: 
//            // rule labels: retval
//            // token list labels: 
//            // rule list labels: 
//            // wildcard labels: 
//            if ( state.backtracking==0 ) {
//            retval.tree = root_0;
//            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//            root_0 = (CommonTree)adaptor.nil();
//            // 313:34: -> ( expression )+
//            {
//                if ( !(stream_expression.hasNext()) ) {
//                    throw new RewriteEarlyExitException();
//                }
//                while ( stream_expression.hasNext() ) {
//                    adaptor.addChild(root_0, stream_expression.nextTree());
//
//                }
//                stream_expression.reset();
//
//            }
//
//            retval.tree = root_0;}
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "expr_list"
//
//    public static class expression_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "expression"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:316:1: expression : logical_text_or_expr -> ^( EXPR logical_text_or_expr ) ;
//    public final CompilerAstParser.expression_return expression() throws RecognitionException {
//        CompilerAstParser.expression_return retval = new CompilerAstParser.expression_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        CompilerAstParser.logical_text_or_expr_return logical_text_or_expr253 = null;
//
//
//        RewriteRuleSubtreeStream stream_logical_text_or_expr=new RewriteRuleSubtreeStream(adaptor,"rule logical_text_or_expr");
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:317:3: ( logical_text_or_expr -> ^( EXPR logical_text_or_expr ) )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:317:5: logical_text_or_expr
//            {
//            pushFollow(FOLLOW_logical_text_or_expr_in_expression2465);
//            logical_text_or_expr253=logical_text_or_expr();
//
//            state._fsp--;
//            if (state.failed) return retval;
//            if ( state.backtracking==0 ) stream_logical_text_or_expr.add(logical_text_or_expr253.getTree());
//
//
//            // AST REWRITE
//            // elements: logical_text_or_expr
//            // token labels: 
//            // rule labels: retval
//            // token list labels: 
//            // rule list labels: 
//            // wildcard labels: 
//            if ( state.backtracking==0 ) {
//            retval.tree = root_0;
//            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//            root_0 = (CommonTree)adaptor.nil();
//            // 317:26: -> ^( EXPR logical_text_or_expr )
//            {
//                // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:317:29: ^( EXPR logical_text_or_expr )
//                {
//                CommonTree root_1 = (CommonTree)adaptor.nil();
//                root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(EXPR, "EXPR"), root_1);
//
//                adaptor.addChild(root_1, stream_logical_text_or_expr.nextTree());
//
//                adaptor.addChild(root_0, root_1);
//                }
//
//            }
//
//            retval.tree = root_0;}
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "expression"
//
//    public static class logical_text_or_expr_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "logical_text_or_expr"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:320:1: logical_text_or_expr : logical_text_xor_expr ( 'OR' logical_text_xor_expr )* ;
//    public final CompilerAstParser.logical_text_or_expr_return logical_text_or_expr() throws RecognitionException {
//        CompilerAstParser.logical_text_or_expr_return retval = new CompilerAstParser.logical_text_or_expr_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token string_literal255=null;
//        CompilerAstParser.logical_text_xor_expr_return logical_text_xor_expr254 = null;
//
//        CompilerAstParser.logical_text_xor_expr_return logical_text_xor_expr256 = null;
//
//
//        CommonTree string_literal255_tree=null;
//
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:321:3: ( logical_text_xor_expr ( 'OR' logical_text_xor_expr )* )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:321:5: logical_text_xor_expr ( 'OR' logical_text_xor_expr )*
//            {
//            root_0 = (CommonTree)adaptor.nil();
//
//            pushFollow(FOLLOW_logical_text_xor_expr_in_logical_text_or_expr2487);
//            logical_text_xor_expr254=logical_text_xor_expr();
//
//            state._fsp--;
//            if (state.failed) return retval;
//            if ( state.backtracking==0 ) adaptor.addChild(root_0, logical_text_xor_expr254.getTree());
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:321:27: ( 'OR' logical_text_xor_expr )*
//            loop78:
//            do {
//                int alt78=2;
//                int LA78_0 = input.LA(1);
//
//                if ( (LA78_0==112) ) {
//                    alt78=1;
//                }
//
//
//                switch (alt78) {
//            	case 1 :
//            	    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:321:28: 'OR' logical_text_xor_expr
//            	    {
//            	    string_literal255=(Token)match(input,112,FOLLOW_112_in_logical_text_or_expr2490); if (state.failed) return retval;
//            	    if ( state.backtracking==0 ) {
//            	    string_literal255_tree = (CommonTree)adaptor.create(string_literal255);
//            	    root_0 = (CommonTree)adaptor.becomeRoot(string_literal255_tree, root_0);
//            	    }
//            	    pushFollow(FOLLOW_logical_text_xor_expr_in_logical_text_or_expr2493);
//            	    logical_text_xor_expr256=logical_text_xor_expr();
//
//            	    state._fsp--;
//            	    if (state.failed) return retval;
//            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, logical_text_xor_expr256.getTree());
//
//            	    }
//            	    break;
//
//            	default :
//            	    break loop78;
//                }
//            } while (true);
//
//
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "logical_text_or_expr"
//
//    public static class logical_text_xor_expr_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "logical_text_xor_expr"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:324:1: logical_text_xor_expr : logical_text_and_expr ( 'XOR' logical_text_and_expr )* ;
//    public final CompilerAstParser.logical_text_xor_expr_return logical_text_xor_expr() throws RecognitionException {
//        CompilerAstParser.logical_text_xor_expr_return retval = new CompilerAstParser.logical_text_xor_expr_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token string_literal258=null;
//        CompilerAstParser.logical_text_and_expr_return logical_text_and_expr257 = null;
//
//        CompilerAstParser.logical_text_and_expr_return logical_text_and_expr259 = null;
//
//
//        CommonTree string_literal258_tree=null;
//
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:325:3: ( logical_text_and_expr ( 'XOR' logical_text_and_expr )* )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:325:5: logical_text_and_expr ( 'XOR' logical_text_and_expr )*
//            {
//            root_0 = (CommonTree)adaptor.nil();
//
//            pushFollow(FOLLOW_logical_text_and_expr_in_logical_text_xor_expr2508);
//            logical_text_and_expr257=logical_text_and_expr();
//
//            state._fsp--;
//            if (state.failed) return retval;
//            if ( state.backtracking==0 ) adaptor.addChild(root_0, logical_text_and_expr257.getTree());
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:325:27: ( 'XOR' logical_text_and_expr )*
//            loop79:
//            do {
//                int alt79=2;
//                int LA79_0 = input.LA(1);
//
//                if ( (LA79_0==113) ) {
//                    alt79=1;
//                }
//
//
//                switch (alt79) {
//            	case 1 :
//            	    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:325:28: 'XOR' logical_text_and_expr
//            	    {
//            	    string_literal258=(Token)match(input,113,FOLLOW_113_in_logical_text_xor_expr2511); if (state.failed) return retval;
//            	    if ( state.backtracking==0 ) {
//            	    string_literal258_tree = (CommonTree)adaptor.create(string_literal258);
//            	    root_0 = (CommonTree)adaptor.becomeRoot(string_literal258_tree, root_0);
//            	    }
//            	    pushFollow(FOLLOW_logical_text_and_expr_in_logical_text_xor_expr2514);
//            	    logical_text_and_expr259=logical_text_and_expr();
//
//            	    state._fsp--;
//            	    if (state.failed) return retval;
//            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, logical_text_and_expr259.getTree());
//
//            	    }
//            	    break;
//
//            	default :
//            	    break loop79;
//                }
//            } while (true);
//
//
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "logical_text_xor_expr"
//
//    public static class logical_text_and_expr_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "logical_text_and_expr"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:328:1: logical_text_and_expr : assignment_expr ( 'AND' assignment_expr )* ;
//    public final CompilerAstParser.logical_text_and_expr_return logical_text_and_expr() throws RecognitionException {
//        CompilerAstParser.logical_text_and_expr_return retval = new CompilerAstParser.logical_text_and_expr_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token string_literal261=null;
//        CompilerAstParser.assignment_expr_return assignment_expr260 = null;
//
//        CompilerAstParser.assignment_expr_return assignment_expr262 = null;
//
//
//        CommonTree string_literal261_tree=null;
//
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:329:3: ( assignment_expr ( 'AND' assignment_expr )* )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:329:5: assignment_expr ( 'AND' assignment_expr )*
//            {
//            root_0 = (CommonTree)adaptor.nil();
//
//            pushFollow(FOLLOW_assignment_expr_in_logical_text_and_expr2529);
//            assignment_expr260=assignment_expr();
//
//            state._fsp--;
//            if (state.failed) return retval;
//            if ( state.backtracking==0 ) adaptor.addChild(root_0, assignment_expr260.getTree());
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:329:21: ( 'AND' assignment_expr )*
//            loop80:
//            do {
//                int alt80=2;
//                int LA80_0 = input.LA(1);
//
//                if ( (LA80_0==114) ) {
//                    alt80=1;
//                }
//
//
//                switch (alt80) {
//            	case 1 :
//            	    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:329:22: 'AND' assignment_expr
//            	    {
//            	    string_literal261=(Token)match(input,114,FOLLOW_114_in_logical_text_and_expr2532); if (state.failed) return retval;
//            	    if ( state.backtracking==0 ) {
//            	    string_literal261_tree = (CommonTree)adaptor.create(string_literal261);
//            	    root_0 = (CommonTree)adaptor.becomeRoot(string_literal261_tree, root_0);
//            	    }
//            	    pushFollow(FOLLOW_assignment_expr_in_logical_text_and_expr2535);
//            	    assignment_expr262=assignment_expr();
//
//            	    state._fsp--;
//            	    if (state.failed) return retval;
//            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, assignment_expr262.getTree());
//
//            	    }
//            	    break;
//
//            	default :
//            	    break loop80;
//                }
//            } while (true);
//
//
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "logical_text_and_expr"
//
//    public static class assignment_expr_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "assignment_expr"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:332:1: assignment_expr : conditional_expr ( assignment_operator conditional_expr )* ;
//    public final CompilerAstParser.assignment_expr_return assignment_expr() throws RecognitionException {
//        CompilerAstParser.assignment_expr_return retval = new CompilerAstParser.assignment_expr_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        CompilerAstParser.conditional_expr_return conditional_expr263 = null;
//
//        CompilerAstParser.assignment_operator_return assignment_operator264 = null;
//
//        CompilerAstParser.conditional_expr_return conditional_expr265 = null;
//
//
//
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:333:3: ( conditional_expr ( assignment_operator conditional_expr )* )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:333:5: conditional_expr ( assignment_operator conditional_expr )*
//            {
//            root_0 = (CommonTree)adaptor.nil();
//
//            pushFollow(FOLLOW_conditional_expr_in_assignment_expr2550);
//            conditional_expr263=conditional_expr();
//
//            state._fsp--;
//            if (state.failed) return retval;
//            if ( state.backtracking==0 ) adaptor.addChild(root_0, conditional_expr263.getTree());
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:333:22: ( assignment_operator conditional_expr )*
//            loop81:
//            do {
//                int alt81=2;
//                int LA81_0 = input.LA(1);
//
//                if ( (LA81_0==94||(LA81_0>=115 && LA81_0<=125)) ) {
//                    alt81=1;
//                }
//
//
//                switch (alt81) {
//            	case 1 :
//            	    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:333:23: assignment_operator conditional_expr
//            	    {
//            	    pushFollow(FOLLOW_assignment_operator_in_assignment_expr2553);
//            	    assignment_operator264=assignment_operator();
//
//            	    state._fsp--;
//            	    if (state.failed) return retval;
//            	    if ( state.backtracking==0 ) root_0 = (CommonTree)adaptor.becomeRoot(assignment_operator264.getTree(), root_0);
//            	    pushFollow(FOLLOW_conditional_expr_in_assignment_expr2556);
//            	    conditional_expr265=conditional_expr();
//
//            	    state._fsp--;
//            	    if (state.failed) return retval;
//            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, conditional_expr265.getTree());
//
//            	    }
//            	    break;
//
//            	default :
//            	    break loop81;
//                }
//            } while (true);
//
//
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "assignment_expr"
//
//    public static class assignment_operator_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "assignment_operator"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:336:1: assignment_operator : ( '=' | '+=' | '-=' | '*=' | '/=' | '.=' | '%=' | '&=' | '|=' | '^=' | '<<=' | '>>=' );
//    public final CompilerAstParser.assignment_operator_return assignment_operator() throws RecognitionException {
//        CompilerAstParser.assignment_operator_return retval = new CompilerAstParser.assignment_operator_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token set266=null;
//
//        CommonTree set266_tree=null;
//
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:337:3: ( '=' | '+=' | '-=' | '*=' | '/=' | '.=' | '%=' | '&=' | '|=' | '^=' | '<<=' | '>>=' )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:
//            {
//            root_0 = (CommonTree)adaptor.nil();
//
//            set266=(Token)input.LT(1);
//            if ( input.LA(1)==94||(input.LA(1)>=115 && input.LA(1)<=125) ) {
//                input.consume();
//                if ( state.backtracking==0 ) adaptor.addChild(root_0, (CommonTree)adaptor.create(set266));
//                state.errorRecovery=false;state.failed=false;
//            }
//            else {
//                if (state.backtracking>0) {state.failed=true; return retval;}
//                MismatchedSetException mse = new MismatchedSetException(null,input);
//                throw mse;
//            }
//
//
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "assignment_operator"
//
//    public static class conditional_expr_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "conditional_expr"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:351:1: conditional_expr : (ll= logical_or_expr -> $ll) ( '?' ( expression )? ':' lr= logical_or_expr -> ^( '?' $ll ^( ':' ( expression )? $lr) ) )? ;
//    public final CompilerAstParser.conditional_expr_return conditional_expr() throws RecognitionException {
//        CompilerAstParser.conditional_expr_return retval = new CompilerAstParser.conditional_expr_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token char_literal267=null;
//        Token char_literal269=null;
//        CompilerAstParser.logical_or_expr_return ll = null;
//
//        CompilerAstParser.logical_or_expr_return lr = null;
//
//        CompilerAstParser.expression_return expression268 = null;
//
//
//        CommonTree char_literal267_tree=null;
//        CommonTree char_literal269_tree=null;
//        RewriteRuleTokenStream stream_98=new RewriteRuleTokenStream(adaptor,"token 98");
//        RewriteRuleTokenStream stream_126=new RewriteRuleTokenStream(adaptor,"token 126");
//        RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");
//        RewriteRuleSubtreeStream stream_logical_or_expr=new RewriteRuleSubtreeStream(adaptor,"rule logical_or_expr");
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:352:3: ( (ll= logical_or_expr -> $ll) ( '?' ( expression )? ':' lr= logical_or_expr -> ^( '?' $ll ^( ':' ( expression )? $lr) ) )? )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:352:5: (ll= logical_or_expr -> $ll) ( '?' ( expression )? ':' lr= logical_or_expr -> ^( '?' $ll ^( ':' ( expression )? $lr) ) )?
//            {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:352:5: (ll= logical_or_expr -> $ll)
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:352:6: ll= logical_or_expr
//            {
//            pushFollow(FOLLOW_logical_or_expr_in_conditional_expr2679);
//            ll=logical_or_expr();
//
//            state._fsp--;
//            if (state.failed) return retval;
//            if ( state.backtracking==0 ) stream_logical_or_expr.add(ll.getTree());
//
//
//            // AST REWRITE
//            // elements: ll
//            // token labels: 
//            // rule labels: retval, ll
//            // token list labels: 
//            // rule list labels: 
//            // wildcard labels: 
//            if ( state.backtracking==0 ) {
//            retval.tree = root_0;
//            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//            RewriteRuleSubtreeStream stream_ll=new RewriteRuleSubtreeStream(adaptor,"rule ll",ll!=null?ll.tree:null);
//
//            root_0 = (CommonTree)adaptor.nil();
//            // 352:25: -> $ll
//            {
//                adaptor.addChild(root_0, stream_ll.nextTree());
//
//            }
//
//            retval.tree = root_0;}
//            }
//
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:353:4: ( '?' ( expression )? ':' lr= logical_or_expr -> ^( '?' $ll ^( ':' ( expression )? $lr) ) )?
//            int alt83=2;
//            int LA83_0 = input.LA(1);
//
//            if ( (LA83_0==126) ) {
//                alt83=1;
//            }
//            switch (alt83) {
//                case 1 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:353:5: '?' ( expression )? ':' lr= logical_or_expr
//                    {
//                    char_literal267=(Token)match(input,126,FOLLOW_126_in_conditional_expr2691); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_126.add(char_literal267);
//
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:353:9: ( expression )?
//                    int alt82=2;
//                    int LA82_0 = input.LA(1);
//
//                    if ( ((LA82_0>=IDENTIFIER && LA82_0<=DOUBLELITERRAL)||LA82_0==61||(LA82_0>=72 && LA82_0<=73)||(LA82_0>=142 && LA82_0<=143)||(LA82_0>=154 && LA82_0<=155)||(LA82_0>=157 && LA82_0<=161)||(LA82_0>=163 && LA82_0<=166)||LA82_0==168||(LA82_0>=171 && LA82_0<=176)) ) {
//                        alt82=1;
//                    }
//                    switch (alt82) {
//                        case 1 :
//                            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:353:9: expression
//                            {
//                            pushFollow(FOLLOW_expression_in_conditional_expr2693);
//                            expression268=expression();
//
//                            state._fsp--;
//                            if (state.failed) return retval;
//                            if ( state.backtracking==0 ) stream_expression.add(expression268.getTree());
//
//                            }
//                            break;
//
//                    }
//
//                    char_literal269=(Token)match(input,98,FOLLOW_98_in_conditional_expr2696); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_98.add(char_literal269);
//
//                    pushFollow(FOLLOW_logical_or_expr_in_conditional_expr2700);
//                    lr=logical_or_expr();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) stream_logical_or_expr.add(lr.getTree());
//
//
//                    // AST REWRITE
//                    // elements: expression, lr, 126, 98, ll
//                    // token labels: 
//                    // rule labels: retval, ll, lr
//                    // token list labels: 
//                    // rule list labels: 
//                    // wildcard labels: 
//                    if ( state.backtracking==0 ) {
//                    retval.tree = root_0;
//                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//                    RewriteRuleSubtreeStream stream_ll=new RewriteRuleSubtreeStream(adaptor,"rule ll",ll!=null?ll.tree:null);
//                    RewriteRuleSubtreeStream stream_lr=new RewriteRuleSubtreeStream(adaptor,"rule lr",lr!=null?lr.tree:null);
//
//                    root_0 = (CommonTree)adaptor.nil();
//                    // 353:44: -> ^( '?' $ll ^( ':' ( expression )? $lr) )
//                    {
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:353:47: ^( '?' $ll ^( ':' ( expression )? $lr) )
//                        {
//                        CommonTree root_1 = (CommonTree)adaptor.nil();
//                        root_1 = (CommonTree)adaptor.becomeRoot(stream_126.nextNode(), root_1);
//
//                        adaptor.addChild(root_1, stream_ll.nextTree());
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:353:57: ^( ':' ( expression )? $lr)
//                        {
//                        CommonTree root_2 = (CommonTree)adaptor.nil();
//                        root_2 = (CommonTree)adaptor.becomeRoot(stream_98.nextNode(), root_2);
//
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:353:63: ( expression )?
//                        if ( stream_expression.hasNext() ) {
//                            adaptor.addChild(root_2, stream_expression.nextTree());
//
//                        }
//                        stream_expression.reset();
//                        adaptor.addChild(root_2, stream_lr.nextTree());
//
//                        adaptor.addChild(root_1, root_2);
//                        }
//
//                        adaptor.addChild(root_0, root_1);
//                        }
//
//                    }
//
//                    retval.tree = root_0;}
//                    }
//                    break;
//
//            }
//
//
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "conditional_expr"
//
//    public static class logical_or_expr_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "logical_or_expr"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:356:1: logical_or_expr : logical_and_expr ( '||' logical_and_expr )* ;
//    public final CompilerAstParser.logical_or_expr_return logical_or_expr() throws RecognitionException {
//        CompilerAstParser.logical_or_expr_return retval = new CompilerAstParser.logical_or_expr_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token string_literal271=null;
//        CompilerAstParser.logical_and_expr_return logical_and_expr270 = null;
//
//        CompilerAstParser.logical_and_expr_return logical_and_expr272 = null;
//
//
//        CommonTree string_literal271_tree=null;
//
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:357:3: ( logical_and_expr ( '||' logical_and_expr )* )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:357:5: logical_and_expr ( '||' logical_and_expr )*
//            {
//            root_0 = (CommonTree)adaptor.nil();
//
//            pushFollow(FOLLOW_logical_and_expr_in_logical_or_expr2734);
//            logical_and_expr270=logical_and_expr();
//
//            state._fsp--;
//            if (state.failed) return retval;
//            if ( state.backtracking==0 ) adaptor.addChild(root_0, logical_and_expr270.getTree());
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:357:22: ( '||' logical_and_expr )*
//            loop84:
//            do {
//                int alt84=2;
//                int LA84_0 = input.LA(1);
//
//                if ( (LA84_0==127) ) {
//                    alt84=1;
//                }
//
//
//                switch (alt84) {
//            	case 1 :
//            	    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:357:23: '||' logical_and_expr
//            	    {
//            	    string_literal271=(Token)match(input,127,FOLLOW_127_in_logical_or_expr2737); if (state.failed) return retval;
//            	    if ( state.backtracking==0 ) {
//            	    string_literal271_tree = (CommonTree)adaptor.create(string_literal271);
//            	    root_0 = (CommonTree)adaptor.becomeRoot(string_literal271_tree, root_0);
//            	    }
//            	    pushFollow(FOLLOW_logical_and_expr_in_logical_or_expr2740);
//            	    logical_and_expr272=logical_and_expr();
//
//            	    state._fsp--;
//            	    if (state.failed) return retval;
//            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, logical_and_expr272.getTree());
//
//            	    }
//            	    break;
//
//            	default :
//            	    break loop84;
//                }
//            } while (true);
//
//
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "logical_or_expr"
//
//    public static class logical_and_expr_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "logical_and_expr"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:360:1: logical_and_expr : bitwise_or_expr ( '&&' bitwise_or_expr )* ;
//    public final CompilerAstParser.logical_and_expr_return logical_and_expr() throws RecognitionException {
//        CompilerAstParser.logical_and_expr_return retval = new CompilerAstParser.logical_and_expr_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token string_literal274=null;
//        CompilerAstParser.bitwise_or_expr_return bitwise_or_expr273 = null;
//
//        CompilerAstParser.bitwise_or_expr_return bitwise_or_expr275 = null;
//
//
//        CommonTree string_literal274_tree=null;
//
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:361:3: ( bitwise_or_expr ( '&&' bitwise_or_expr )* )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:361:5: bitwise_or_expr ( '&&' bitwise_or_expr )*
//            {
//            root_0 = (CommonTree)adaptor.nil();
//
//            pushFollow(FOLLOW_bitwise_or_expr_in_logical_and_expr2755);
//            bitwise_or_expr273=bitwise_or_expr();
//
//            state._fsp--;
//            if (state.failed) return retval;
//            if ( state.backtracking==0 ) adaptor.addChild(root_0, bitwise_or_expr273.getTree());
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:361:21: ( '&&' bitwise_or_expr )*
//            loop85:
//            do {
//                int alt85=2;
//                int LA85_0 = input.LA(1);
//
//                if ( (LA85_0==128) ) {
//                    alt85=1;
//                }
//
//
//                switch (alt85) {
//            	case 1 :
//            	    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:361:22: '&&' bitwise_or_expr
//            	    {
//            	    string_literal274=(Token)match(input,128,FOLLOW_128_in_logical_and_expr2758); if (state.failed) return retval;
//            	    if ( state.backtracking==0 ) {
//            	    string_literal274_tree = (CommonTree)adaptor.create(string_literal274);
//            	    root_0 = (CommonTree)adaptor.becomeRoot(string_literal274_tree, root_0);
//            	    }
//            	    pushFollow(FOLLOW_bitwise_or_expr_in_logical_and_expr2761);
//            	    bitwise_or_expr275=bitwise_or_expr();
//
//            	    state._fsp--;
//            	    if (state.failed) return retval;
//            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, bitwise_or_expr275.getTree());
//
//            	    }
//            	    break;
//
//            	default :
//            	    break loop85;
//                }
//            } while (true);
//
//
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "logical_and_expr"
//
//    public static class bitwise_or_expr_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "bitwise_or_expr"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:364:1: bitwise_or_expr : bitwise_xor_expr ( '|' bitwise_xor_expr )* ;
//    public final CompilerAstParser.bitwise_or_expr_return bitwise_or_expr() throws RecognitionException {
//        CompilerAstParser.bitwise_or_expr_return retval = new CompilerAstParser.bitwise_or_expr_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token char_literal277=null;
//        CompilerAstParser.bitwise_xor_expr_return bitwise_xor_expr276 = null;
//
//        CompilerAstParser.bitwise_xor_expr_return bitwise_xor_expr278 = null;
//
//
//        CommonTree char_literal277_tree=null;
//
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:365:3: ( bitwise_xor_expr ( '|' bitwise_xor_expr )* )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:365:5: bitwise_xor_expr ( '|' bitwise_xor_expr )*
//            {
//            root_0 = (CommonTree)adaptor.nil();
//
//            pushFollow(FOLLOW_bitwise_xor_expr_in_bitwise_or_expr2776);
//            bitwise_xor_expr276=bitwise_xor_expr();
//
//            state._fsp--;
//            if (state.failed) return retval;
//            if ( state.backtracking==0 ) adaptor.addChild(root_0, bitwise_xor_expr276.getTree());
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:365:22: ( '|' bitwise_xor_expr )*
//            loop86:
//            do {
//                int alt86=2;
//                int LA86_0 = input.LA(1);
//
//                if ( (LA86_0==129) ) {
//                    alt86=1;
//                }
//
//
//                switch (alt86) {
//            	case 1 :
//            	    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:365:23: '|' bitwise_xor_expr
//            	    {
//            	    char_literal277=(Token)match(input,129,FOLLOW_129_in_bitwise_or_expr2779); if (state.failed) return retval;
//            	    if ( state.backtracking==0 ) {
//            	    char_literal277_tree = (CommonTree)adaptor.create(char_literal277);
//            	    root_0 = (CommonTree)adaptor.becomeRoot(char_literal277_tree, root_0);
//            	    }
//            	    pushFollow(FOLLOW_bitwise_xor_expr_in_bitwise_or_expr2782);
//            	    bitwise_xor_expr278=bitwise_xor_expr();
//
//            	    state._fsp--;
//            	    if (state.failed) return retval;
//            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, bitwise_xor_expr278.getTree());
//
//            	    }
//            	    break;
//
//            	default :
//            	    break loop86;
//                }
//            } while (true);
//
//
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "bitwise_or_expr"
//
//    public static class bitwise_xor_expr_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "bitwise_xor_expr"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:368:1: bitwise_xor_expr : bitwise_and_expr ( '^' bitwise_and_expr )* ;
//    public final CompilerAstParser.bitwise_xor_expr_return bitwise_xor_expr() throws RecognitionException {
//        CompilerAstParser.bitwise_xor_expr_return retval = new CompilerAstParser.bitwise_xor_expr_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token char_literal280=null;
//        CompilerAstParser.bitwise_and_expr_return bitwise_and_expr279 = null;
//
//        CompilerAstParser.bitwise_and_expr_return bitwise_and_expr281 = null;
//
//
//        CommonTree char_literal280_tree=null;
//
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:369:3: ( bitwise_and_expr ( '^' bitwise_and_expr )* )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:369:5: bitwise_and_expr ( '^' bitwise_and_expr )*
//            {
//            root_0 = (CommonTree)adaptor.nil();
//
//            pushFollow(FOLLOW_bitwise_and_expr_in_bitwise_xor_expr2797);
//            bitwise_and_expr279=bitwise_and_expr();
//
//            state._fsp--;
//            if (state.failed) return retval;
//            if ( state.backtracking==0 ) adaptor.addChild(root_0, bitwise_and_expr279.getTree());
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:369:22: ( '^' bitwise_and_expr )*
//            loop87:
//            do {
//                int alt87=2;
//                int LA87_0 = input.LA(1);
//
//                if ( (LA87_0==130) ) {
//                    alt87=1;
//                }
//
//
//                switch (alt87) {
//            	case 1 :
//            	    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:369:23: '^' bitwise_and_expr
//            	    {
//            	    char_literal280=(Token)match(input,130,FOLLOW_130_in_bitwise_xor_expr2800); if (state.failed) return retval;
//            	    if ( state.backtracking==0 ) {
//            	    char_literal280_tree = (CommonTree)adaptor.create(char_literal280);
//            	    root_0 = (CommonTree)adaptor.becomeRoot(char_literal280_tree, root_0);
//            	    }
//            	    pushFollow(FOLLOW_bitwise_and_expr_in_bitwise_xor_expr2803);
//            	    bitwise_and_expr281=bitwise_and_expr();
//
//            	    state._fsp--;
//            	    if (state.failed) return retval;
//            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, bitwise_and_expr281.getTree());
//
//            	    }
//            	    break;
//
//            	default :
//            	    break loop87;
//                }
//            } while (true);
//
//
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "bitwise_xor_expr"
//
//    public static class bitwise_and_expr_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "bitwise_and_expr"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:372:1: bitwise_and_expr : concat_expr ( '.' concat_expr )* ;
//    public final CompilerAstParser.bitwise_and_expr_return bitwise_and_expr() throws RecognitionException {
//        CompilerAstParser.bitwise_and_expr_return retval = new CompilerAstParser.bitwise_and_expr_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token char_literal283=null;
//        CompilerAstParser.concat_expr_return concat_expr282 = null;
//
//        CompilerAstParser.concat_expr_return concat_expr284 = null;
//
//
//        CommonTree char_literal283_tree=null;
//
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:373:3: ( concat_expr ( '.' concat_expr )* )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:373:5: concat_expr ( '.' concat_expr )*
//            {
//            root_0 = (CommonTree)adaptor.nil();
//
//            pushFollow(FOLLOW_concat_expr_in_bitwise_and_expr2818);
//            concat_expr282=concat_expr();
//
//            state._fsp--;
//            if (state.failed) return retval;
//            if ( state.backtracking==0 ) adaptor.addChild(root_0, concat_expr282.getTree());
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:373:17: ( '.' concat_expr )*
//            loop88:
//            do {
//                int alt88=2;
//                int LA88_0 = input.LA(1);
//
//                if ( (LA88_0==131) ) {
//                    alt88=1;
//                }
//
//
//                switch (alt88) {
//            	case 1 :
//            	    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:373:18: '.' concat_expr
//            	    {
//            	    char_literal283=(Token)match(input,131,FOLLOW_131_in_bitwise_and_expr2821); if (state.failed) return retval;
//            	    if ( state.backtracking==0 ) {
//            	    char_literal283_tree = (CommonTree)adaptor.create(char_literal283);
//            	    root_0 = (CommonTree)adaptor.becomeRoot(char_literal283_tree, root_0);
//            	    }
//            	    pushFollow(FOLLOW_concat_expr_in_bitwise_and_expr2824);
//            	    concat_expr284=concat_expr();
//
//            	    state._fsp--;
//            	    if (state.failed) return retval;
//            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, concat_expr284.getTree());
//
//            	    }
//            	    break;
//
//            	default :
//            	    break loop88;
//                }
//            } while (true);
//
//
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "bitwise_and_expr"
//
//    public static class concat_expr_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "concat_expr"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:376:1: concat_expr : equality_expr ( '&' equality_expr )* ;
//    public final CompilerAstParser.concat_expr_return concat_expr() throws RecognitionException {
//        CompilerAstParser.concat_expr_return retval = new CompilerAstParser.concat_expr_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token char_literal286=null;
//        CompilerAstParser.equality_expr_return equality_expr285 = null;
//
//        CompilerAstParser.equality_expr_return equality_expr287 = null;
//
//
//        CommonTree char_literal286_tree=null;
//
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:377:3: ( equality_expr ( '&' equality_expr )* )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:377:5: equality_expr ( '&' equality_expr )*
//            {
//            root_0 = (CommonTree)adaptor.nil();
//
//            pushFollow(FOLLOW_equality_expr_in_concat_expr2839);
//            equality_expr285=equality_expr();
//
//            state._fsp--;
//            if (state.failed) return retval;
//            if ( state.backtracking==0 ) adaptor.addChild(root_0, equality_expr285.getTree());
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:377:19: ( '&' equality_expr )*
//            loop89:
//            do {
//                int alt89=2;
//                int LA89_0 = input.LA(1);
//
//                if ( (LA89_0==73) ) {
//                    alt89=1;
//                }
//
//
//                switch (alt89) {
//            	case 1 :
//            	    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:377:20: '&' equality_expr
//            	    {
//            	    char_literal286=(Token)match(input,73,FOLLOW_73_in_concat_expr2842); if (state.failed) return retval;
//            	    if ( state.backtracking==0 ) {
//            	    char_literal286_tree = (CommonTree)adaptor.create(char_literal286);
//            	    root_0 = (CommonTree)adaptor.becomeRoot(char_literal286_tree, root_0);
//            	    }
//            	    pushFollow(FOLLOW_equality_expr_in_concat_expr2845);
//            	    equality_expr287=equality_expr();
//
//            	    state._fsp--;
//            	    if (state.failed) return retval;
//            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, equality_expr287.getTree());
//
//            	    }
//            	    break;
//
//            	default :
//            	    break loop89;
//                }
//            } while (true);
//
//
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "concat_expr"
//
//    public static class equality_expr_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "equality_expr"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:380:1: equality_expr : relational_expr ( ( '==' | '!=' | '===' | '!==' ) relational_expr )* ;
//    public final CompilerAstParser.equality_expr_return equality_expr() throws RecognitionException {
//        CompilerAstParser.equality_expr_return retval = new CompilerAstParser.equality_expr_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token set289=null;
//        CompilerAstParser.relational_expr_return relational_expr288 = null;
//
//        CompilerAstParser.relational_expr_return relational_expr290 = null;
//
//
//        CommonTree set289_tree=null;
//
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:381:3: ( relational_expr ( ( '==' | '!=' | '===' | '!==' ) relational_expr )* )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:381:5: relational_expr ( ( '==' | '!=' | '===' | '!==' ) relational_expr )*
//            {
//            root_0 = (CommonTree)adaptor.nil();
//
//            pushFollow(FOLLOW_relational_expr_in_equality_expr2860);
//            relational_expr288=relational_expr();
//
//            state._fsp--;
//            if (state.failed) return retval;
//            if ( state.backtracking==0 ) adaptor.addChild(root_0, relational_expr288.getTree());
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:381:21: ( ( '==' | '!=' | '===' | '!==' ) relational_expr )*
//            loop90:
//            do {
//                int alt90=2;
//                int LA90_0 = input.LA(1);
//
//                if ( ((LA90_0>=132 && LA90_0<=135)) ) {
//                    alt90=1;
//                }
//
//
//                switch (alt90) {
//            	case 1 :
//            	    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:381:22: ( '==' | '!=' | '===' | '!==' ) relational_expr
//            	    {
//            	    set289=(Token)input.LT(1);
//            	    set289=(Token)input.LT(1);
//            	    if ( (input.LA(1)>=132 && input.LA(1)<=135) ) {
//            	        input.consume();
//            	        if ( state.backtracking==0 ) root_0 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(set289), root_0);
//            	        state.errorRecovery=false;state.failed=false;
//            	    }
//            	    else {
//            	        if (state.backtracking>0) {state.failed=true; return retval;}
//            	        MismatchedSetException mse = new MismatchedSetException(null,input);
//            	        throw mse;
//            	    }
//
//            	    pushFollow(FOLLOW_relational_expr_in_equality_expr2880);
//            	    relational_expr290=relational_expr();
//
//            	    state._fsp--;
//            	    if (state.failed) return retval;
//            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, relational_expr290.getTree());
//
//            	    }
//            	    break;
//
//            	default :
//            	    break loop90;
//                }
//            } while (true);
//
//
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "equality_expr"
//
//    public static class relational_expr_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "relational_expr"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:384:1: relational_expr : shift_expr ( ( '<' | '>' | '<=' | '>=' ) shift_expr )* ;
//    public final CompilerAstParser.relational_expr_return relational_expr() throws RecognitionException {
//        CompilerAstParser.relational_expr_return retval = new CompilerAstParser.relational_expr_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token set292=null;
//        CompilerAstParser.shift_expr_return shift_expr291 = null;
//
//        CompilerAstParser.shift_expr_return shift_expr293 = null;
//
//
//        CommonTree set292_tree=null;
//
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:385:3: ( shift_expr ( ( '<' | '>' | '<=' | '>=' ) shift_expr )* )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:385:5: shift_expr ( ( '<' | '>' | '<=' | '>=' ) shift_expr )*
//            {
//            root_0 = (CommonTree)adaptor.nil();
//
//            pushFollow(FOLLOW_shift_expr_in_relational_expr2895);
//            shift_expr291=shift_expr();
//
//            state._fsp--;
//            if (state.failed) return retval;
//            if ( state.backtracking==0 ) adaptor.addChild(root_0, shift_expr291.getTree());
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:385:16: ( ( '<' | '>' | '<=' | '>=' ) shift_expr )*
//            loop91:
//            do {
//                int alt91=2;
//                int LA91_0 = input.LA(1);
//
//                if ( ((LA91_0>=136 && LA91_0<=139)) ) {
//                    alt91=1;
//                }
//
//
//                switch (alt91) {
//            	case 1 :
//            	    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:385:17: ( '<' | '>' | '<=' | '>=' ) shift_expr
//            	    {
//            	    set292=(Token)input.LT(1);
//            	    set292=(Token)input.LT(1);
//            	    if ( (input.LA(1)>=136 && input.LA(1)<=139) ) {
//            	        input.consume();
//            	        if ( state.backtracking==0 ) root_0 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(set292), root_0);
//            	        state.errorRecovery=false;state.failed=false;
//            	    }
//            	    else {
//            	        if (state.backtracking>0) {state.failed=true; return retval;}
//            	        MismatchedSetException mse = new MismatchedSetException(null,input);
//            	        throw mse;
//            	    }
//
//            	    pushFollow(FOLLOW_shift_expr_in_relational_expr2915);
//            	    shift_expr293=shift_expr();
//
//            	    state._fsp--;
//            	    if (state.failed) return retval;
//            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, shift_expr293.getTree());
//
//            	    }
//            	    break;
//
//            	default :
//            	    break loop91;
//                }
//            } while (true);
//
//
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "relational_expr"
//
//    public static class shift_expr_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "shift_expr"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:388:1: shift_expr : additive_expr ( ( '<<' | '>>' ) additive_expr )* ;
//    public final CompilerAstParser.shift_expr_return shift_expr() throws RecognitionException {
//        CompilerAstParser.shift_expr_return retval = new CompilerAstParser.shift_expr_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token set295=null;
//        CompilerAstParser.additive_expr_return additive_expr294 = null;
//
//        CompilerAstParser.additive_expr_return additive_expr296 = null;
//
//
//        CommonTree set295_tree=null;
//
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:389:3: ( additive_expr ( ( '<<' | '>>' ) additive_expr )* )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:389:5: additive_expr ( ( '<<' | '>>' ) additive_expr )*
//            {
//            root_0 = (CommonTree)adaptor.nil();
//
//            pushFollow(FOLLOW_additive_expr_in_shift_expr2930);
//            additive_expr294=additive_expr();
//
//            state._fsp--;
//            if (state.failed) return retval;
//            if ( state.backtracking==0 ) adaptor.addChild(root_0, additive_expr294.getTree());
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:389:19: ( ( '<<' | '>>' ) additive_expr )*
//            loop92:
//            do {
//                int alt92=2;
//                int LA92_0 = input.LA(1);
//
//                if ( ((LA92_0>=140 && LA92_0<=141)) ) {
//                    alt92=1;
//                }
//
//
//                switch (alt92) {
//            	case 1 :
//            	    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:389:20: ( '<<' | '>>' ) additive_expr
//            	    {
//            	    set295=(Token)input.LT(1);
//            	    set295=(Token)input.LT(1);
//            	    if ( (input.LA(1)>=140 && input.LA(1)<=141) ) {
//            	        input.consume();
//            	        if ( state.backtracking==0 ) root_0 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(set295), root_0);
//            	        state.errorRecovery=false;state.failed=false;
//            	    }
//            	    else {
//            	        if (state.backtracking>0) {state.failed=true; return retval;}
//            	        MismatchedSetException mse = new MismatchedSetException(null,input);
//            	        throw mse;
//            	    }
//
//            	    pushFollow(FOLLOW_additive_expr_in_shift_expr2942);
//            	    additive_expr296=additive_expr();
//
//            	    state._fsp--;
//            	    if (state.failed) return retval;
//            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, additive_expr296.getTree());
//
//            	    }
//            	    break;
//
//            	default :
//            	    break loop92;
//                }
//            } while (true);
//
//
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "shift_expr"
//
//    public static class additive_expr_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "additive_expr"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:392:1: additive_expr : multiplicative_expr ( ( '+' | '-' ) multiplicative_expr )* ;
//    public final CompilerAstParser.additive_expr_return additive_expr() throws RecognitionException {
//        CompilerAstParser.additive_expr_return retval = new CompilerAstParser.additive_expr_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token set298=null;
//        CompilerAstParser.multiplicative_expr_return multiplicative_expr297 = null;
//
//        CompilerAstParser.multiplicative_expr_return multiplicative_expr299 = null;
//
//
//        CommonTree set298_tree=null;
//
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:393:3: ( multiplicative_expr ( ( '+' | '-' ) multiplicative_expr )* )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:393:5: multiplicative_expr ( ( '+' | '-' ) multiplicative_expr )*
//            {
//            root_0 = (CommonTree)adaptor.nil();
//
//            pushFollow(FOLLOW_multiplicative_expr_in_additive_expr2957);
//            multiplicative_expr297=multiplicative_expr();
//
//            state._fsp--;
//            if (state.failed) return retval;
//            if ( state.backtracking==0 ) adaptor.addChild(root_0, multiplicative_expr297.getTree());
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:393:25: ( ( '+' | '-' ) multiplicative_expr )*
//            loop93:
//            do {
//                int alt93=2;
//                int LA93_0 = input.LA(1);
//
//                if ( ((LA93_0>=142 && LA93_0<=143)) ) {
//                    alt93=1;
//                }
//
//
//                switch (alt93) {
//            	case 1 :
//            	    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:393:26: ( '+' | '-' ) multiplicative_expr
//            	    {
//            	    set298=(Token)input.LT(1);
//            	    set298=(Token)input.LT(1);
//            	    if ( (input.LA(1)>=142 && input.LA(1)<=143) ) {
//            	        input.consume();
//            	        if ( state.backtracking==0 ) root_0 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(set298), root_0);
//            	        state.errorRecovery=false;state.failed=false;
//            	    }
//            	    else {
//            	        if (state.backtracking>0) {state.failed=true; return retval;}
//            	        MismatchedSetException mse = new MismatchedSetException(null,input);
//            	        throw mse;
//            	    }
//
//            	    pushFollow(FOLLOW_multiplicative_expr_in_additive_expr2969);
//            	    multiplicative_expr299=multiplicative_expr();
//
//            	    state._fsp--;
//            	    if (state.failed) return retval;
//            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, multiplicative_expr299.getTree());
//
//            	    }
//            	    break;
//
//            	default :
//            	    break loop93;
//                }
//            } while (true);
//
//
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "additive_expr"
//
//    public static class multiplicative_expr_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "multiplicative_expr"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:396:1: multiplicative_expr : cast_expr ( ( '*' | '/' | '%' ) cast_expr )* ;
//    public final CompilerAstParser.multiplicative_expr_return multiplicative_expr() throws RecognitionException {
//        CompilerAstParser.multiplicative_expr_return retval = new CompilerAstParser.multiplicative_expr_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token set301=null;
//        CompilerAstParser.cast_expr_return cast_expr300 = null;
//
//        CompilerAstParser.cast_expr_return cast_expr302 = null;
//
//
//        CommonTree set301_tree=null;
//
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:397:3: ( cast_expr ( ( '*' | '/' | '%' ) cast_expr )* )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:397:5: cast_expr ( ( '*' | '/' | '%' ) cast_expr )*
//            {
//            root_0 = (CommonTree)adaptor.nil();
//
//            pushFollow(FOLLOW_cast_expr_in_multiplicative_expr2984);
//            cast_expr300=cast_expr();
//
//            state._fsp--;
//            if (state.failed) return retval;
//            if ( state.backtracking==0 ) adaptor.addChild(root_0, cast_expr300.getTree());
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:397:15: ( ( '*' | '/' | '%' ) cast_expr )*
//            loop94:
//            do {
//                int alt94=2;
//                int LA94_0 = input.LA(1);
//
//                if ( ((LA94_0>=144 && LA94_0<=146)) ) {
//                    alt94=1;
//                }
//
//
//                switch (alt94) {
//            	case 1 :
//            	    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:397:16: ( '*' | '/' | '%' ) cast_expr
//            	    {
//            	    set301=(Token)input.LT(1);
//            	    set301=(Token)input.LT(1);
//            	    if ( (input.LA(1)>=144 && input.LA(1)<=146) ) {
//            	        input.consume();
//            	        if ( state.backtracking==0 ) root_0 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(set301), root_0);
//            	        state.errorRecovery=false;state.failed=false;
//            	    }
//            	    else {
//            	        if (state.backtracking>0) {state.failed=true; return retval;}
//            	        MismatchedSetException mse = new MismatchedSetException(null,input);
//            	        throw mse;
//            	    }
//
//            	    pushFollow(FOLLOW_cast_expr_in_multiplicative_expr3000);
//            	    cast_expr302=cast_expr();
//
//            	    state._fsp--;
//            	    if (state.failed) return retval;
//            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, cast_expr302.getTree());
//
//            	    }
//            	    break;
//
//            	default :
//            	    break loop94;
//                }
//            } while (true);
//
//
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "multiplicative_expr"
//
//    public static class cast_expr_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "cast_expr"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:400:1: cast_expr : ( '(' cast_option ')' )* unary_expr ;
//    public final CompilerAstParser.cast_expr_return cast_expr() throws RecognitionException {
//        CompilerAstParser.cast_expr_return retval = new CompilerAstParser.cast_expr_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token char_literal303=null;
//        Token char_literal305=null;
//        CompilerAstParser.cast_option_return cast_option304 = null;
//
//        CompilerAstParser.unary_expr_return unary_expr306 = null;
//
//
//        CommonTree char_literal303_tree=null;
//        CommonTree char_literal305_tree=null;
//
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:401:3: ( ( '(' cast_option ')' )* unary_expr )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:401:5: ( '(' cast_option ')' )* unary_expr
//            {
//            root_0 = (CommonTree)adaptor.nil();
//
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:401:5: ( '(' cast_option ')' )*
//            loop95:
//            do {
//                int alt95=2;
//                int LA95_0 = input.LA(1);
//
//                if ( (LA95_0==61) ) {
//                    switch ( input.LA(2) ) {
//                    case 157:
//                        {
//                        int LA95_3 = input.LA(3);
//
//                        if ( (LA95_3==62) ) {
//                            alt95=1;
//                        }
//
//
//                        }
//                        break;
//                    case 155:
//                        {
//                        int LA95_4 = input.LA(3);
//
//                        if ( (LA95_4==62) ) {
//                            alt95=1;
//                        }
//
//
//                        }
//                        break;
//                    case 154:
//                        {
//                        int LA95_5 = input.LA(3);
//
//                        if ( (LA95_5==62) ) {
//                            alt95=1;
//                        }
//
//
//                        }
//                        break;
//                    case 147:
//                    case 148:
//                    case 149:
//                    case 150:
//                    case 151:
//                    case 152:
//                    case 153:
//                    case 156:
//                        {
//                        alt95=1;
//                        }
//                        break;
//
//                    }
//
//                }
//
//
//                switch (alt95) {
//            	case 1 :
//            	    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:401:6: '(' cast_option ')'
//            	    {
//            	    char_literal303=(Token)match(input,61,FOLLOW_61_in_cast_expr3016); if (state.failed) return retval;
//            	    pushFollow(FOLLOW_cast_option_in_cast_expr3019);
//            	    cast_option304=cast_option();
//
//            	    state._fsp--;
//            	    if (state.failed) return retval;
//            	    if ( state.backtracking==0 ) root_0 = (CommonTree)adaptor.becomeRoot(cast_option304.getTree(), root_0);
//            	    char_literal305=(Token)match(input,62,FOLLOW_62_in_cast_expr3022); if (state.failed) return retval;
//
//            	    }
//            	    break;
//
//            	default :
//            	    break loop95;
//                }
//            } while (true);
//
//            pushFollow(FOLLOW_unary_expr_in_cast_expr3027);
//            unary_expr306=unary_expr();
//
//            state._fsp--;
//            if (state.failed) return retval;
//            if ( state.backtracking==0 ) adaptor.addChild(root_0, unary_expr306.getTree());
//
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "cast_expr"
//
//    public static class cast_option_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "cast_option"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:404:1: cast_option : ( 'bool' | 'boolean' | 'int' | 'float' | 'double' | 'real' | 'string' | 'unset' | 'clone' | 'object' | 'array' ) ;
//    public final CompilerAstParser.cast_option_return cast_option() throws RecognitionException {
//        CompilerAstParser.cast_option_return retval = new CompilerAstParser.cast_option_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token set307=null;
//
//        CommonTree set307_tree=null;
//
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:405:1: ( ( 'bool' | 'boolean' | 'int' | 'float' | 'double' | 'real' | 'string' | 'unset' | 'clone' | 'object' | 'array' ) )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:405:3: ( 'bool' | 'boolean' | 'int' | 'float' | 'double' | 'real' | 'string' | 'unset' | 'clone' | 'object' | 'array' )
//            {
//            root_0 = (CommonTree)adaptor.nil();
//
//            set307=(Token)input.LT(1);
//            if ( (input.LA(1)>=147 && input.LA(1)<=157) ) {
//                input.consume();
//                if ( state.backtracking==0 ) adaptor.addChild(root_0, (CommonTree)adaptor.create(set307));
//                state.errorRecovery=false;state.failed=false;
//            }
//            else {
//                if (state.backtracking>0) {state.failed=true; return retval;}
//                MismatchedSetException mse = new MismatchedSetException(null,input);
//                throw mse;
//            }
//
//
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "cast_option"
//
//    public static class unary_expr_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "unary_expr"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:419:1: unary_expr : ( ( '&' | '+' | '-' | '~' | '!' ) )* prefix_inc_dec_expr ;
//    public final CompilerAstParser.unary_expr_return unary_expr() throws RecognitionException {
//        CompilerAstParser.unary_expr_return retval = new CompilerAstParser.unary_expr_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token set308=null;
//        CompilerAstParser.prefix_inc_dec_expr_return prefix_inc_dec_expr309 = null;
//
//
//        CommonTree set308_tree=null;
//
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:420:3: ( ( ( '&' | '+' | '-' | '~' | '!' ) )* prefix_inc_dec_expr )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:420:5: ( ( '&' | '+' | '-' | '~' | '!' ) )* prefix_inc_dec_expr
//            {
//            root_0 = (CommonTree)adaptor.nil();
//
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:420:5: ( ( '&' | '+' | '-' | '~' | '!' ) )*
//            loop96:
//            do {
//                int alt96=2;
//                int LA96_0 = input.LA(1);
//
//                if ( (LA96_0==73||(LA96_0>=142 && LA96_0<=143)||(LA96_0>=158 && LA96_0<=159)) ) {
//                    alt96=1;
//                }
//
//
//                switch (alt96) {
//            	case 1 :
//            	    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:420:6: ( '&' | '+' | '-' | '~' | '!' )
//            	    {
//            	    set308=(Token)input.LT(1);
//            	    set308=(Token)input.LT(1);
//            	    if ( input.LA(1)==73||(input.LA(1)>=142 && input.LA(1)<=143)||(input.LA(1)>=158 && input.LA(1)<=159) ) {
//            	        input.consume();
//            	        if ( state.backtracking==0 ) root_0 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(set308), root_0);
//            	        state.errorRecovery=false;state.failed=false;
//            	    }
//            	    else {
//            	        if (state.backtracking>0) {state.failed=true; return retval;}
//            	        MismatchedSetException mse = new MismatchedSetException(null,input);
//            	        throw mse;
//            	    }
//
//
//            	    }
//            	    break;
//
//            	default :
//            	    break loop96;
//                }
//            } while (true);
//
//            pushFollow(FOLLOW_prefix_inc_dec_expr_in_unary_expr3145);
//            prefix_inc_dec_expr309=prefix_inc_dec_expr();
//
//            state._fsp--;
//            if (state.failed) return retval;
//            if ( state.backtracking==0 ) adaptor.addChild(root_0, prefix_inc_dec_expr309.getTree());
//
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "unary_expr"
//
//    public static class prefix_inc_dec_expr_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "prefix_inc_dec_expr"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:424:1: prefix_inc_dec_expr : ( ( '++' | '--' )* ) post_inc_dec_expr ;
//    public final CompilerAstParser.prefix_inc_dec_expr_return prefix_inc_dec_expr() throws RecognitionException {
//        CompilerAstParser.prefix_inc_dec_expr_return retval = new CompilerAstParser.prefix_inc_dec_expr_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token set310=null;
//        CompilerAstParser.post_inc_dec_expr_return post_inc_dec_expr311 = null;
//
//
//        CommonTree set310_tree=null;
//
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:425:3: ( ( ( '++' | '--' )* ) post_inc_dec_expr )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:425:5: ( ( '++' | '--' )* ) post_inc_dec_expr
//            {
//            root_0 = (CommonTree)adaptor.nil();
//
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:425:5: ( ( '++' | '--' )* )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:425:6: ( '++' | '--' )*
//            {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:425:6: ( '++' | '--' )*
//            loop97:
//            do {
//                int alt97=2;
//                int LA97_0 = input.LA(1);
//
//                if ( ((LA97_0>=160 && LA97_0<=161)) ) {
//                    alt97=1;
//                }
//
//
//                switch (alt97) {
//            	case 1 :
//            	    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:
//            	    {
//            	    set310=(Token)input.LT(1);
//            	    if ( (input.LA(1)>=160 && input.LA(1)<=161) ) {
//            	        input.consume();
//            	        if ( state.backtracking==0 ) adaptor.addChild(root_0, (CommonTree)adaptor.create(set310));
//            	        state.errorRecovery=false;state.failed=false;
//            	    }
//            	    else {
//            	        if (state.backtracking>0) {state.failed=true; return retval;}
//            	        MismatchedSetException mse = new MismatchedSetException(null,input);
//            	        throw mse;
//            	    }
//
//
//            	    }
//            	    break;
//
//            	default :
//            	    break loop97;
//                }
//            } while (true);
//
//
//            }
//
//            pushFollow(FOLLOW_post_inc_dec_expr_in_prefix_inc_dec_expr3171);
//            post_inc_dec_expr311=post_inc_dec_expr();
//
//            state._fsp--;
//            if (state.failed) return retval;
//            if ( state.backtracking==0 ) adaptor.addChild(root_0, post_inc_dec_expr311.getTree());
//
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "prefix_inc_dec_expr"
//
//    public static class post_inc_dec_expr_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "post_inc_dec_expr"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:428:1: post_inc_dec_expr : instance_expr ( ( '++' | '--' )* ) ;
//    public final CompilerAstParser.post_inc_dec_expr_return post_inc_dec_expr() throws RecognitionException {
//        CompilerAstParser.post_inc_dec_expr_return retval = new CompilerAstParser.post_inc_dec_expr_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token set313=null;
//        CompilerAstParser.instance_expr_return instance_expr312 = null;
//
//
//        CommonTree set313_tree=null;
//
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:429:3: ( instance_expr ( ( '++' | '--' )* ) )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:429:5: instance_expr ( ( '++' | '--' )* )
//            {
//            root_0 = (CommonTree)adaptor.nil();
//
//            pushFollow(FOLLOW_instance_expr_in_post_inc_dec_expr3186);
//            instance_expr312=instance_expr();
//
//            state._fsp--;
//            if (state.failed) return retval;
//            if ( state.backtracking==0 ) adaptor.addChild(root_0, instance_expr312.getTree());
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:429:19: ( ( '++' | '--' )* )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:429:20: ( '++' | '--' )*
//            {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:429:20: ( '++' | '--' )*
//            loop98:
//            do {
//                int alt98=2;
//                int LA98_0 = input.LA(1);
//
//                if ( ((LA98_0>=160 && LA98_0<=161)) ) {
//                    alt98=1;
//                }
//
//
//                switch (alt98) {
//            	case 1 :
//            	    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:
//            	    {
//            	    set313=(Token)input.LT(1);
//            	    if ( (input.LA(1)>=160 && input.LA(1)<=161) ) {
//            	        input.consume();
//            	        if ( state.backtracking==0 ) adaptor.addChild(root_0, (CommonTree)adaptor.create(set313));
//            	        state.errorRecovery=false;state.failed=false;
//            	    }
//            	    else {
//            	        if (state.backtracking>0) {state.failed=true; return retval;}
//            	        MismatchedSetException mse = new MismatchedSetException(null,input);
//            	        throw mse;
//            	    }
//
//
//            	    }
//            	    break;
//
//            	default :
//            	    break loop98;
//                }
//            } while (true);
//
//
//            }
//
//
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "post_inc_dec_expr"
//
//    public static class instance_expr_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "instance_expr"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:432:1: instance_expr : atom_expr ( 'instanceof' class_name_reference )? ;
//    public final CompilerAstParser.instance_expr_return instance_expr() throws RecognitionException {
//        CompilerAstParser.instance_expr_return retval = new CompilerAstParser.instance_expr_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token string_literal315=null;
//        CompilerAstParser.atom_expr_return atom_expr314 = null;
//
//        CompilerAstParser.class_name_reference_return class_name_reference316 = null;
//
//
//        CommonTree string_literal315_tree=null;
//
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:433:3: ( atom_expr ( 'instanceof' class_name_reference )? )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:433:5: atom_expr ( 'instanceof' class_name_reference )?
//            {
//            root_0 = (CommonTree)adaptor.nil();
//
//            pushFollow(FOLLOW_atom_expr_in_instance_expr3211);
//            atom_expr314=atom_expr();
//
//            state._fsp--;
//            if (state.failed) return retval;
//            if ( state.backtracking==0 ) adaptor.addChild(root_0, atom_expr314.getTree());
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:433:15: ( 'instanceof' class_name_reference )?
//            int alt99=2;
//            int LA99_0 = input.LA(1);
//
//            if ( (LA99_0==162) ) {
//                alt99=1;
//            }
//            switch (alt99) {
//                case 1 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:433:16: 'instanceof' class_name_reference
//                    {
//                    string_literal315=(Token)match(input,162,FOLLOW_162_in_instance_expr3214); if (state.failed) return retval;
//                    if ( state.backtracking==0 ) {
//                    string_literal315_tree = (CommonTree)adaptor.create(string_literal315);
//                    root_0 = (CommonTree)adaptor.becomeRoot(string_literal315_tree, root_0);
//                    }
//                    pushFollow(FOLLOW_class_name_reference_in_instance_expr3217);
//                    class_name_reference316=class_name_reference();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) adaptor.addChild(root_0, class_name_reference316.getTree());
//
//                    }
//                    break;
//
//            }
//
//
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "instance_expr"
//
//    public static class atom_expr_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "atom_expr"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:436:1: atom_expr : ( ( '@' )? variable | ( '@' )? constant | '(' expression ')' | 'list' '(' assignment_list ')' -> ^( 'list' assignment_list ) | 'array' '(' ( array_pair_list )? ')' -> ^( 'array' ( array_pair_list )? ) | 'new' class_name_reference -> ^( 'new' class_name_reference ) | 'clone' variable -> ^( 'clone' variable ) | 'exit' ( '(' ( expression )? ')' )? -> ^( 'exit' ( expression )? ) | 'unset' '(' variable_list ')' -> ^( 'unset' variable_list ) | lambda_function_declaration | backtrick_expr );
//    public final CompilerAstParser.atom_expr_return atom_expr() throws RecognitionException {
//        CompilerAstParser.atom_expr_return retval = new CompilerAstParser.atom_expr_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token char_literal317=null;
//        Token char_literal319=null;
//        Token char_literal321=null;
//        Token char_literal323=null;
//        Token string_literal324=null;
//        Token char_literal325=null;
//        Token char_literal327=null;
//        Token string_literal328=null;
//        Token char_literal329=null;
//        Token char_literal331=null;
//        Token string_literal332=null;
//        Token string_literal334=null;
//        Token string_literal336=null;
//        Token char_literal337=null;
//        Token char_literal339=null;
//        Token string_literal340=null;
//        Token char_literal341=null;
//        Token char_literal343=null;
//        CompilerAstParser.variable_return variable318 = null;
//
//        CompilerAstParser.constant_return constant320 = null;
//
//        CompilerAstParser.expression_return expression322 = null;
//
//        CompilerAstParser.assignment_list_return assignment_list326 = null;
//
//        CompilerAstParser.array_pair_list_return array_pair_list330 = null;
//
//        CompilerAstParser.class_name_reference_return class_name_reference333 = null;
//
//        CompilerAstParser.variable_return variable335 = null;
//
//        CompilerAstParser.expression_return expression338 = null;
//
//        CompilerAstParser.variable_list_return variable_list342 = null;
//
//        CompilerAstParser.lambda_function_declaration_return lambda_function_declaration344 = null;
//
//        CompilerAstParser.backtrick_expr_return backtrick_expr345 = null;
//
//
//        CommonTree char_literal317_tree=null;
//        CommonTree char_literal319_tree=null;
//        CommonTree char_literal321_tree=null;
//        CommonTree char_literal323_tree=null;
//        CommonTree string_literal324_tree=null;
//        CommonTree char_literal325_tree=null;
//        CommonTree char_literal327_tree=null;
//        CommonTree string_literal328_tree=null;
//        CommonTree char_literal329_tree=null;
//        CommonTree char_literal331_tree=null;
//        CommonTree string_literal332_tree=null;
//        CommonTree string_literal334_tree=null;
//        CommonTree string_literal336_tree=null;
//        CommonTree char_literal337_tree=null;
//        CommonTree char_literal339_tree=null;
//        CommonTree string_literal340_tree=null;
//        CommonTree char_literal341_tree=null;
//        CommonTree char_literal343_tree=null;
//        RewriteRuleTokenStream stream_164=new RewriteRuleTokenStream(adaptor,"token 164");
//        RewriteRuleTokenStream stream_62=new RewriteRuleTokenStream(adaptor,"token 62");
//        RewriteRuleTokenStream stream_166=new RewriteRuleTokenStream(adaptor,"token 166");
//        RewriteRuleTokenStream stream_157=new RewriteRuleTokenStream(adaptor,"token 157");
//        RewriteRuleTokenStream stream_165=new RewriteRuleTokenStream(adaptor,"token 165");
//        RewriteRuleTokenStream stream_61=new RewriteRuleTokenStream(adaptor,"token 61");
//        RewriteRuleTokenStream stream_155=new RewriteRuleTokenStream(adaptor,"token 155");
//        RewriteRuleTokenStream stream_154=new RewriteRuleTokenStream(adaptor,"token 154");
//        RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");
//        RewriteRuleSubtreeStream stream_variable_list=new RewriteRuleSubtreeStream(adaptor,"rule variable_list");
//        RewriteRuleSubtreeStream stream_array_pair_list=new RewriteRuleSubtreeStream(adaptor,"rule array_pair_list");
//        RewriteRuleSubtreeStream stream_class_name_reference=new RewriteRuleSubtreeStream(adaptor,"rule class_name_reference");
//        RewriteRuleSubtreeStream stream_assignment_list=new RewriteRuleSubtreeStream(adaptor,"rule assignment_list");
//        RewriteRuleSubtreeStream stream_variable=new RewriteRuleSubtreeStream(adaptor,"rule variable");
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:437:3: ( ( '@' )? variable | ( '@' )? constant | '(' expression ')' | 'list' '(' assignment_list ')' -> ^( 'list' assignment_list ) | 'array' '(' ( array_pair_list )? ')' -> ^( 'array' ( array_pair_list )? ) | 'new' class_name_reference -> ^( 'new' class_name_reference ) | 'clone' variable -> ^( 'clone' variable ) | 'exit' ( '(' ( expression )? ')' )? -> ^( 'exit' ( expression )? ) | 'unset' '(' variable_list ')' -> ^( 'unset' variable_list ) | lambda_function_declaration | backtrick_expr )
//            int alt105=11;
//            alt105 = dfa105.predict(input);
//            switch (alt105) {
//                case 1 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:437:6: ( '@' )? variable
//                    {
//                    root_0 = (CommonTree)adaptor.nil();
//
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:437:6: ( '@' )?
//                    int alt100=2;
//                    int LA100_0 = input.LA(1);
//
//                    if ( (LA100_0==163) ) {
//                        alt100=1;
//                    }
//                    switch (alt100) {
//                        case 1 :
//                            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:437:6: '@'
//                            {
//                            char_literal317=(Token)match(input,163,FOLLOW_163_in_atom_expr3235); if (state.failed) return retval;
//                            if ( state.backtracking==0 ) {
//                            char_literal317_tree = (CommonTree)adaptor.create(char_literal317);
//                            adaptor.addChild(root_0, char_literal317_tree);
//                            }
//
//                            }
//                            break;
//
//                    }
//
//                    pushFollow(FOLLOW_variable_in_atom_expr3238);
//                    variable318=variable();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) adaptor.addChild(root_0, variable318.getTree());
//
//                    }
//                    break;
//                case 2 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:438:6: ( '@' )? constant
//                    {
//                    root_0 = (CommonTree)adaptor.nil();
//
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:438:6: ( '@' )?
//                    int alt101=2;
//                    int LA101_0 = input.LA(1);
//
//                    if ( (LA101_0==163) ) {
//                        alt101=1;
//                    }
//                    switch (alt101) {
//                        case 1 :
//                            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:438:6: '@'
//                            {
//                            char_literal319=(Token)match(input,163,FOLLOW_163_in_atom_expr3245); if (state.failed) return retval;
//                            if ( state.backtracking==0 ) {
//                            char_literal319_tree = (CommonTree)adaptor.create(char_literal319);
//                            adaptor.addChild(root_0, char_literal319_tree);
//                            }
//
//                            }
//                            break;
//
//                    }
//
//                    pushFollow(FOLLOW_constant_in_atom_expr3248);
//                    constant320=constant();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) adaptor.addChild(root_0, constant320.getTree());
//
//                    }
//                    break;
//                case 3 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:439:6: '(' expression ')'
//                    {
//                    root_0 = (CommonTree)adaptor.nil();
//
//                    char_literal321=(Token)match(input,61,FOLLOW_61_in_atom_expr3255); if (state.failed) return retval;
//                    if ( state.backtracking==0 ) {
//                    char_literal321_tree = (CommonTree)adaptor.create(char_literal321);
//                    adaptor.addChild(root_0, char_literal321_tree);
//                    }
//                    pushFollow(FOLLOW_expression_in_atom_expr3257);
//                    expression322=expression();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) adaptor.addChild(root_0, expression322.getTree());
//                    char_literal323=(Token)match(input,62,FOLLOW_62_in_atom_expr3259); if (state.failed) return retval;
//                    if ( state.backtracking==0 ) {
//                    char_literal323_tree = (CommonTree)adaptor.create(char_literal323);
//                    adaptor.addChild(root_0, char_literal323_tree);
//                    }
//
//                    }
//                    break;
//                case 4 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:440:6: 'list' '(' assignment_list ')'
//                    {
//                    string_literal324=(Token)match(input,164,FOLLOW_164_in_atom_expr3266); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_164.add(string_literal324);
//
//                    char_literal325=(Token)match(input,61,FOLLOW_61_in_atom_expr3268); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_61.add(char_literal325);
//
//                    pushFollow(FOLLOW_assignment_list_in_atom_expr3270);
//                    assignment_list326=assignment_list();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) stream_assignment_list.add(assignment_list326.getTree());
//                    char_literal327=(Token)match(input,62,FOLLOW_62_in_atom_expr3272); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_62.add(char_literal327);
//
//
//
//                    // AST REWRITE
//                    // elements: assignment_list, 164
//                    // token labels: 
//                    // rule labels: retval
//                    // token list labels: 
//                    // rule list labels: 
//                    // wildcard labels: 
//                    if ( state.backtracking==0 ) {
//                    retval.tree = root_0;
//                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//                    root_0 = (CommonTree)adaptor.nil();
//                    // 440:39: -> ^( 'list' assignment_list )
//                    {
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:440:42: ^( 'list' assignment_list )
//                        {
//                        CommonTree root_1 = (CommonTree)adaptor.nil();
//                        root_1 = (CommonTree)adaptor.becomeRoot(stream_164.nextNode(), root_1);
//
//                        adaptor.addChild(root_1, stream_assignment_list.nextTree());
//
//                        adaptor.addChild(root_0, root_1);
//                        }
//
//                    }
//
//                    retval.tree = root_0;}
//                    }
//                    break;
//                case 5 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:441:6: 'array' '(' ( array_pair_list )? ')'
//                    {
//                    string_literal328=(Token)match(input,157,FOLLOW_157_in_atom_expr3289); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_157.add(string_literal328);
//
//                    char_literal329=(Token)match(input,61,FOLLOW_61_in_atom_expr3291); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_61.add(char_literal329);
//
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:441:18: ( array_pair_list )?
//                    int alt102=2;
//                    int LA102_0 = input.LA(1);
//
//                    if ( ((LA102_0>=IDENTIFIER && LA102_0<=DOUBLELITERRAL)||LA102_0==61||(LA102_0>=72 && LA102_0<=73)||(LA102_0>=142 && LA102_0<=143)||(LA102_0>=154 && LA102_0<=155)||(LA102_0>=157 && LA102_0<=161)||(LA102_0>=163 && LA102_0<=166)||LA102_0==168||(LA102_0>=171 && LA102_0<=176)) ) {
//                        alt102=1;
//                    }
//                    switch (alt102) {
//                        case 1 :
//                            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:441:18: array_pair_list
//                            {
//                            pushFollow(FOLLOW_array_pair_list_in_atom_expr3293);
//                            array_pair_list330=array_pair_list();
//
//                            state._fsp--;
//                            if (state.failed) return retval;
//                            if ( state.backtracking==0 ) stream_array_pair_list.add(array_pair_list330.getTree());
//
//                            }
//                            break;
//
//                    }
//
//                    char_literal331=(Token)match(input,62,FOLLOW_62_in_atom_expr3296); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_62.add(char_literal331);
//
//
//
//                    // AST REWRITE
//                    // elements: 157, array_pair_list
//                    // token labels: 
//                    // rule labels: retval
//                    // token list labels: 
//                    // rule list labels: 
//                    // wildcard labels: 
//                    if ( state.backtracking==0 ) {
//                    retval.tree = root_0;
//                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//                    root_0 = (CommonTree)adaptor.nil();
//                    // 441:40: -> ^( 'array' ( array_pair_list )? )
//                    {
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:441:43: ^( 'array' ( array_pair_list )? )
//                        {
//                        CommonTree root_1 = (CommonTree)adaptor.nil();
//                        root_1 = (CommonTree)adaptor.becomeRoot(stream_157.nextNode(), root_1);
//
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:441:53: ( array_pair_list )?
//                        if ( stream_array_pair_list.hasNext() ) {
//                            adaptor.addChild(root_1, stream_array_pair_list.nextTree());
//
//                        }
//                        stream_array_pair_list.reset();
//
//                        adaptor.addChild(root_0, root_1);
//                        }
//
//                    }
//
//                    retval.tree = root_0;}
//                    }
//                    break;
//                case 6 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:442:6: 'new' class_name_reference
//                    {
//                    string_literal332=(Token)match(input,165,FOLLOW_165_in_atom_expr3313); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_165.add(string_literal332);
//
//                    pushFollow(FOLLOW_class_name_reference_in_atom_expr3315);
//                    class_name_reference333=class_name_reference();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) stream_class_name_reference.add(class_name_reference333.getTree());
//
//
//                    // AST REWRITE
//                    // elements: class_name_reference, 165
//                    // token labels: 
//                    // rule labels: retval
//                    // token list labels: 
//                    // rule list labels: 
//                    // wildcard labels: 
//                    if ( state.backtracking==0 ) {
//                    retval.tree = root_0;
//                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//                    root_0 = (CommonTree)adaptor.nil();
//                    // 442:33: -> ^( 'new' class_name_reference )
//                    {
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:442:36: ^( 'new' class_name_reference )
//                        {
//                        CommonTree root_1 = (CommonTree)adaptor.nil();
//                        root_1 = (CommonTree)adaptor.becomeRoot(stream_165.nextNode(), root_1);
//
//                        adaptor.addChild(root_1, stream_class_name_reference.nextTree());
//
//                        adaptor.addChild(root_0, root_1);
//                        }
//
//                    }
//
//                    retval.tree = root_0;}
//                    }
//                    break;
//                case 7 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:443:6: 'clone' variable
//                    {
//                    string_literal334=(Token)match(input,155,FOLLOW_155_in_atom_expr3330); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_155.add(string_literal334);
//
//                    pushFollow(FOLLOW_variable_in_atom_expr3332);
//                    variable335=variable();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) stream_variable.add(variable335.getTree());
//
//
//                    // AST REWRITE
//                    // elements: 155, variable
//                    // token labels: 
//                    // rule labels: retval
//                    // token list labels: 
//                    // rule list labels: 
//                    // wildcard labels: 
//                    if ( state.backtracking==0 ) {
//                    retval.tree = root_0;
//                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//                    root_0 = (CommonTree)adaptor.nil();
//                    // 443:26: -> ^( 'clone' variable )
//                    {
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:443:29: ^( 'clone' variable )
//                        {
//                        CommonTree root_1 = (CommonTree)adaptor.nil();
//                        root_1 = (CommonTree)adaptor.becomeRoot(stream_155.nextNode(), root_1);
//
//                        adaptor.addChild(root_1, stream_variable.nextTree());
//
//                        adaptor.addChild(root_0, root_1);
//                        }
//
//                    }
//
//                    retval.tree = root_0;}
//                    }
//                    break;
//                case 8 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:444:6: 'exit' ( '(' ( expression )? ')' )?
//                    {
//                    string_literal336=(Token)match(input,166,FOLLOW_166_in_atom_expr3350); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_166.add(string_literal336);
//
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:444:13: ( '(' ( expression )? ')' )?
//                    int alt104=2;
//                    int LA104_0 = input.LA(1);
//
//                    if ( (LA104_0==61) ) {
//                        alt104=1;
//                    }
//                    switch (alt104) {
//                        case 1 :
//                            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:444:14: '(' ( expression )? ')'
//                            {
//                            char_literal337=(Token)match(input,61,FOLLOW_61_in_atom_expr3353); if (state.failed) return retval; 
//                            if ( state.backtracking==0 ) stream_61.add(char_literal337);
//
//                            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:444:18: ( expression )?
//                            int alt103=2;
//                            int LA103_0 = input.LA(1);
//
//                            if ( ((LA103_0>=IDENTIFIER && LA103_0<=DOUBLELITERRAL)||LA103_0==61||(LA103_0>=72 && LA103_0<=73)||(LA103_0>=142 && LA103_0<=143)||(LA103_0>=154 && LA103_0<=155)||(LA103_0>=157 && LA103_0<=161)||(LA103_0>=163 && LA103_0<=166)||LA103_0==168||(LA103_0>=171 && LA103_0<=176)) ) {
//                                alt103=1;
//                            }
//                            switch (alt103) {
//                                case 1 :
//                                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:444:18: expression
//                                    {
//                                    pushFollow(FOLLOW_expression_in_atom_expr3355);
//                                    expression338=expression();
//
//                                    state._fsp--;
//                                    if (state.failed) return retval;
//                                    if ( state.backtracking==0 ) stream_expression.add(expression338.getTree());
//
//                                    }
//                                    break;
//
//                            }
//
//                            char_literal339=(Token)match(input,62,FOLLOW_62_in_atom_expr3358); if (state.failed) return retval; 
//                            if ( state.backtracking==0 ) stream_62.add(char_literal339);
//
//
//                            }
//                            break;
//
//                    }
//
//
//
//                    // AST REWRITE
//                    // elements: expression, 166
//                    // token labels: 
//                    // rule labels: retval
//                    // token list labels: 
//                    // rule list labels: 
//                    // wildcard labels: 
//                    if ( state.backtracking==0 ) {
//                    retval.tree = root_0;
//                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//                    root_0 = (CommonTree)adaptor.nil();
//                    // 444:36: -> ^( 'exit' ( expression )? )
//                    {
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:444:39: ^( 'exit' ( expression )? )
//                        {
//                        CommonTree root_1 = (CommonTree)adaptor.nil();
//                        root_1 = (CommonTree)adaptor.becomeRoot(stream_166.nextNode(), root_1);
//
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:444:48: ( expression )?
//                        if ( stream_expression.hasNext() ) {
//                            adaptor.addChild(root_1, stream_expression.nextTree());
//
//                        }
//                        stream_expression.reset();
//
//                        adaptor.addChild(root_0, root_1);
//                        }
//
//                    }
//
//                    retval.tree = root_0;}
//                    }
//                    break;
//                case 9 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:445:6: 'unset' '(' variable_list ')'
//                    {
//                    string_literal340=(Token)match(input,154,FOLLOW_154_in_atom_expr3376); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_154.add(string_literal340);
//
//                    char_literal341=(Token)match(input,61,FOLLOW_61_in_atom_expr3378); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_61.add(char_literal341);
//
//                    pushFollow(FOLLOW_variable_list_in_atom_expr3380);
//                    variable_list342=variable_list();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) stream_variable_list.add(variable_list342.getTree());
//                    char_literal343=(Token)match(input,62,FOLLOW_62_in_atom_expr3382); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_62.add(char_literal343);
//
//
//
//                    // AST REWRITE
//                    // elements: 154, variable_list
//                    // token labels: 
//                    // rule labels: retval
//                    // token list labels: 
//                    // rule list labels: 
//                    // wildcard labels: 
//                    if ( state.backtracking==0 ) {
//                    retval.tree = root_0;
//                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//                    root_0 = (CommonTree)adaptor.nil();
//                    // 445:36: -> ^( 'unset' variable_list )
//                    {
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:445:39: ^( 'unset' variable_list )
//                        {
//                        CommonTree root_1 = (CommonTree)adaptor.nil();
//                        root_1 = (CommonTree)adaptor.becomeRoot(stream_154.nextNode(), root_1);
//
//                        adaptor.addChild(root_1, stream_variable_list.nextTree());
//
//                        adaptor.addChild(root_0, root_1);
//                        }
//
//                    }
//
//                    retval.tree = root_0;}
//                    }
//                    break;
//                case 10 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:446:6: lambda_function_declaration
//                    {
//                    root_0 = (CommonTree)adaptor.nil();
//
//                    pushFollow(FOLLOW_lambda_function_declaration_in_atom_expr3397);
//                    lambda_function_declaration344=lambda_function_declaration();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) adaptor.addChild(root_0, lambda_function_declaration344.getTree());
//
//                    }
//                    break;
//                case 11 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:447:6: backtrick_expr
//                    {
//                    root_0 = (CommonTree)adaptor.nil();
//
//                    pushFollow(FOLLOW_backtrick_expr_in_atom_expr3404);
//                    backtrick_expr345=backtrick_expr();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) adaptor.addChild(root_0, backtrick_expr345.getTree());
//
//                    }
//                    break;
//
//            }
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "atom_expr"
//
//    public static class lambda_function_declaration_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "lambda_function_declaration"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:451:1: lambda_function_declaration : 'function' ( '&' )? '(' ( parameter_list )? ')' ( 'use' '(' ( expr_list )? ')' )? block -> ^( METHOD_DECL ( '&' )? ( parameter_list )? ( ^( 'use' ( expr_list )? ) )? block ) ;
//    public final CompilerAstParser.lambda_function_declaration_return lambda_function_declaration() throws RecognitionException {
//        CompilerAstParser.lambda_function_declaration_return retval = new CompilerAstParser.lambda_function_declaration_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token string_literal346=null;
//        Token char_literal347=null;
//        Token char_literal348=null;
//        Token char_literal350=null;
//        Token string_literal351=null;
//        Token char_literal352=null;
//        Token char_literal354=null;
//        CompilerAstParser.parameter_list_return parameter_list349 = null;
//
//        CompilerAstParser.expr_list_return expr_list353 = null;
//
//        CompilerAstParser.block_return block355 = null;
//
//
//        CommonTree string_literal346_tree=null;
//        CommonTree char_literal347_tree=null;
//        CommonTree char_literal348_tree=null;
//        CommonTree char_literal350_tree=null;
//        CommonTree string_literal351_tree=null;
//        CommonTree char_literal352_tree=null;
//        CommonTree char_literal354_tree=null;
//        RewriteRuleTokenStream stream_62=new RewriteRuleTokenStream(adaptor,"token 62");
//        RewriteRuleTokenStream stream_72=new RewriteRuleTokenStream(adaptor,"token 72");
//        RewriteRuleTokenStream stream_73=new RewriteRuleTokenStream(adaptor,"token 73");
//        RewriteRuleTokenStream stream_61=new RewriteRuleTokenStream(adaptor,"token 61");
//        RewriteRuleTokenStream stream_89=new RewriteRuleTokenStream(adaptor,"token 89");
//        RewriteRuleSubtreeStream stream_block=new RewriteRuleSubtreeStream(adaptor,"rule block");
//        RewriteRuleSubtreeStream stream_parameter_list=new RewriteRuleSubtreeStream(adaptor,"rule parameter_list");
//        RewriteRuleSubtreeStream stream_expr_list=new RewriteRuleSubtreeStream(adaptor,"rule expr_list");
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:452:2: ( 'function' ( '&' )? '(' ( parameter_list )? ')' ( 'use' '(' ( expr_list )? ')' )? block -> ^( METHOD_DECL ( '&' )? ( parameter_list )? ( ^( 'use' ( expr_list )? ) )? block ) )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:452:4: 'function' ( '&' )? '(' ( parameter_list )? ')' ( 'use' '(' ( expr_list )? ')' )? block
//            {
//            string_literal346=(Token)match(input,72,FOLLOW_72_in_lambda_function_declaration3418); if (state.failed) return retval; 
//            if ( state.backtracking==0 ) stream_72.add(string_literal346);
//
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:452:15: ( '&' )?
//            int alt106=2;
//            int LA106_0 = input.LA(1);
//
//            if ( (LA106_0==73) ) {
//                alt106=1;
//            }
//            switch (alt106) {
//                case 1 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:452:15: '&'
//                    {
//                    char_literal347=(Token)match(input,73,FOLLOW_73_in_lambda_function_declaration3420); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_73.add(char_literal347);
//
//
//                    }
//                    break;
//
//            }
//
//            char_literal348=(Token)match(input,61,FOLLOW_61_in_lambda_function_declaration3423); if (state.failed) return retval; 
//            if ( state.backtracking==0 ) stream_61.add(char_literal348);
//
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:452:24: ( parameter_list )?
//            int alt107=2;
//            int LA107_0 = input.LA(1);
//
//            if ( (LA107_0==IDENTIFIER||LA107_0==73||LA107_0==91||(LA107_0>=147 && LA107_0<=157)||LA107_0==168) ) {
//                alt107=1;
//            }
//            switch (alt107) {
//                case 1 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:452:24: parameter_list
//                    {
//                    pushFollow(FOLLOW_parameter_list_in_lambda_function_declaration3425);
//                    parameter_list349=parameter_list();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) stream_parameter_list.add(parameter_list349.getTree());
//
//                    }
//                    break;
//
//            }
//
//            char_literal350=(Token)match(input,62,FOLLOW_62_in_lambda_function_declaration3428); if (state.failed) return retval; 
//            if ( state.backtracking==0 ) stream_62.add(char_literal350);
//
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:452:44: ( 'use' '(' ( expr_list )? ')' )?
//            int alt109=2;
//            int LA109_0 = input.LA(1);
//
//            if ( (LA109_0==89) ) {
//                alt109=1;
//            }
//            switch (alt109) {
//                case 1 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:452:45: 'use' '(' ( expr_list )? ')'
//                    {
//                    string_literal351=(Token)match(input,89,FOLLOW_89_in_lambda_function_declaration3431); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_89.add(string_literal351);
//
//                    char_literal352=(Token)match(input,61,FOLLOW_61_in_lambda_function_declaration3433); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_61.add(char_literal352);
//
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:452:55: ( expr_list )?
//                    int alt108=2;
//                    int LA108_0 = input.LA(1);
//
//                    if ( ((LA108_0>=IDENTIFIER && LA108_0<=DOUBLELITERRAL)||LA108_0==61||(LA108_0>=72 && LA108_0<=73)||(LA108_0>=142 && LA108_0<=143)||(LA108_0>=154 && LA108_0<=155)||(LA108_0>=157 && LA108_0<=161)||(LA108_0>=163 && LA108_0<=166)||LA108_0==168||(LA108_0>=171 && LA108_0<=176)) ) {
//                        alt108=1;
//                    }
//                    switch (alt108) {
//                        case 1 :
//                            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:452:55: expr_list
//                            {
//                            pushFollow(FOLLOW_expr_list_in_lambda_function_declaration3435);
//                            expr_list353=expr_list();
//
//                            state._fsp--;
//                            if (state.failed) return retval;
//                            if ( state.backtracking==0 ) stream_expr_list.add(expr_list353.getTree());
//
//                            }
//                            break;
//
//                    }
//
//                    char_literal354=(Token)match(input,62,FOLLOW_62_in_lambda_function_declaration3438); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_62.add(char_literal354);
//
//
//                    }
//                    break;
//
//            }
//
//            pushFollow(FOLLOW_block_in_lambda_function_declaration3444);
//            block355=block();
//
//            state._fsp--;
//            if (state.failed) return retval;
//            if ( state.backtracking==0 ) stream_block.add(block355.getTree());
//
//
//            // AST REWRITE
//            // elements: parameter_list, 73, 89, expr_list, block
//            // token labels: 
//            // rule labels: retval
//            // token list labels: 
//            // rule list labels: 
//            // wildcard labels: 
//            if ( state.backtracking==0 ) {
//            retval.tree = root_0;
//            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//            root_0 = (CommonTree)adaptor.nil();
//            // 454:2: -> ^( METHOD_DECL ( '&' )? ( parameter_list )? ( ^( 'use' ( expr_list )? ) )? block )
//            {
//                // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:454:5: ^( METHOD_DECL ( '&' )? ( parameter_list )? ( ^( 'use' ( expr_list )? ) )? block )
//                {
//                CommonTree root_1 = (CommonTree)adaptor.nil();
//                root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(METHOD_DECL, "METHOD_DECL"), root_1);
//
//                // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:454:19: ( '&' )?
//                if ( stream_73.hasNext() ) {
//                    adaptor.addChild(root_1, stream_73.nextNode());
//
//                }
//                stream_73.reset();
//                // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:454:24: ( parameter_list )?
//                if ( stream_parameter_list.hasNext() ) {
//                    adaptor.addChild(root_1, stream_parameter_list.nextTree());
//
//                }
//                stream_parameter_list.reset();
//                // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:454:40: ( ^( 'use' ( expr_list )? ) )?
//                if ( stream_89.hasNext()||stream_expr_list.hasNext() ) {
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:454:40: ^( 'use' ( expr_list )? )
//                    {
//                    CommonTree root_2 = (CommonTree)adaptor.nil();
//                    root_2 = (CommonTree)adaptor.becomeRoot(stream_89.nextNode(), root_2);
//
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:454:48: ( expr_list )?
//                    if ( stream_expr_list.hasNext() ) {
//                        adaptor.addChild(root_2, stream_expr_list.nextTree());
//
//                    }
//                    stream_expr_list.reset();
//
//                    adaptor.addChild(root_1, root_2);
//                    }
//
//                }
//                stream_89.reset();
//                stream_expr_list.reset();
//                adaptor.addChild(root_1, stream_block.nextTree());
//
//                adaptor.addChild(root_0, root_1);
//                }
//
//            }
//
//            retval.tree = root_0;}
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "lambda_function_declaration"
//
//    public static class backtrick_expr_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "backtrick_expr"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:458:1: backtrick_expr : BACKTRICKLITERAL ;
//    public final CompilerAstParser.backtrick_expr_return backtrick_expr() throws RecognitionException {
//        CompilerAstParser.backtrick_expr_return retval = new CompilerAstParser.backtrick_expr_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token BACKTRICKLITERAL356=null;
//
//        CommonTree BACKTRICKLITERAL356_tree=null;
//
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:459:2: ( BACKTRICKLITERAL )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:459:4: BACKTRICKLITERAL
//            {
//            root_0 = (CommonTree)adaptor.nil();
//
//            BACKTRICKLITERAL356=(Token)match(input,BACKTRICKLITERAL,FOLLOW_BACKTRICKLITERAL_in_backtrick_expr3481); if (state.failed) return retval;
//            if ( state.backtracking==0 ) {
//            BACKTRICKLITERAL356_tree = (CommonTree)adaptor.create(BACKTRICKLITERAL356);
//            adaptor.addChild(root_0, BACKTRICKLITERAL356_tree);
//            }
//
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "backtrick_expr"
//
//    public static class class_name_reference_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "class_name_reference"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:462:1: class_name_reference : variable ;
//    public final CompilerAstParser.class_name_reference_return class_name_reference() throws RecognitionException {
//        CompilerAstParser.class_name_reference_return retval = new CompilerAstParser.class_name_reference_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        CompilerAstParser.variable_return variable357 = null;
//
//
//
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:463:3: ( variable )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:463:5: variable
//            {
//            root_0 = (CommonTree)adaptor.nil();
//
//            pushFollow(FOLLOW_variable_in_class_name_reference3497);
//            variable357=variable();
//
//            state._fsp--;
//            if (state.failed) return retval;
//            if ( state.backtracking==0 ) adaptor.addChild(root_0, variable357.getTree());
//
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "class_name_reference"
//
//    public static class assignment_list_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "assignment_list"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:466:1: assignment_list : ( assignment_element )? ( ',' ( assignment_element )? )* ;
//    public final CompilerAstParser.assignment_list_return assignment_list() throws RecognitionException {
//        CompilerAstParser.assignment_list_return retval = new CompilerAstParser.assignment_list_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token char_literal359=null;
//        CompilerAstParser.assignment_element_return assignment_element358 = null;
//
//        CompilerAstParser.assignment_element_return assignment_element360 = null;
//
//
//        CommonTree char_literal359_tree=null;
//
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:467:3: ( ( assignment_element )? ( ',' ( assignment_element )? )* )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:467:5: ( assignment_element )? ( ',' ( assignment_element )? )*
//            {
//            root_0 = (CommonTree)adaptor.nil();
//
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:467:5: ( assignment_element )?
//            int alt110=2;
//            int LA110_0 = input.LA(1);
//
//            if ( (LA110_0==IDENTIFIER||LA110_0==STATIC||LA110_0==164||LA110_0==168) ) {
//                alt110=1;
//            }
//            switch (alt110) {
//                case 1 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:467:5: assignment_element
//                    {
//                    pushFollow(FOLLOW_assignment_element_in_assignment_list3514);
//                    assignment_element358=assignment_element();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) adaptor.addChild(root_0, assignment_element358.getTree());
//
//                    }
//                    break;
//
//            }
//
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:467:25: ( ',' ( assignment_element )? )*
//            loop112:
//            do {
//                int alt112=2;
//                int LA112_0 = input.LA(1);
//
//                if ( (LA112_0==93) ) {
//                    alt112=1;
//                }
//
//
//                switch (alt112) {
//            	case 1 :
//            	    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:467:26: ',' ( assignment_element )?
//            	    {
//            	    char_literal359=(Token)match(input,93,FOLLOW_93_in_assignment_list3518); if (state.failed) return retval;
//            	    if ( state.backtracking==0 ) {
//            	    char_literal359_tree = (CommonTree)adaptor.create(char_literal359);
//            	    adaptor.addChild(root_0, char_literal359_tree);
//            	    }
//            	    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:467:30: ( assignment_element )?
//            	    int alt111=2;
//            	    int LA111_0 = input.LA(1);
//
//            	    if ( (LA111_0==IDENTIFIER||LA111_0==STATIC||LA111_0==164||LA111_0==168) ) {
//            	        alt111=1;
//            	    }
//            	    switch (alt111) {
//            	        case 1 :
//            	            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:467:30: assignment_element
//            	            {
//            	            pushFollow(FOLLOW_assignment_element_in_assignment_list3520);
//            	            assignment_element360=assignment_element();
//
//            	            state._fsp--;
//            	            if (state.failed) return retval;
//            	            if ( state.backtracking==0 ) adaptor.addChild(root_0, assignment_element360.getTree());
//
//            	            }
//            	            break;
//
//            	    }
//
//
//            	    }
//            	    break;
//
//            	default :
//            	    break loop112;
//                }
//            } while (true);
//
//
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "assignment_list"
//
//    public static class assignment_element_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "assignment_element"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:470:1: assignment_element : ( variable | 'list' '(' assignment_list ')' -> ^( 'list' assignment_list ) );
//    public final CompilerAstParser.assignment_element_return assignment_element() throws RecognitionException {
//        CompilerAstParser.assignment_element_return retval = new CompilerAstParser.assignment_element_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token string_literal362=null;
//        Token char_literal363=null;
//        Token char_literal365=null;
//        CompilerAstParser.variable_return variable361 = null;
//
//        CompilerAstParser.assignment_list_return assignment_list364 = null;
//
//
//        CommonTree string_literal362_tree=null;
//        CommonTree char_literal363_tree=null;
//        CommonTree char_literal365_tree=null;
//        RewriteRuleTokenStream stream_164=new RewriteRuleTokenStream(adaptor,"token 164");
//        RewriteRuleTokenStream stream_62=new RewriteRuleTokenStream(adaptor,"token 62");
//        RewriteRuleTokenStream stream_61=new RewriteRuleTokenStream(adaptor,"token 61");
//        RewriteRuleSubtreeStream stream_assignment_list=new RewriteRuleSubtreeStream(adaptor,"rule assignment_list");
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:471:3: ( variable | 'list' '(' assignment_list ')' -> ^( 'list' assignment_list ) )
//            int alt113=2;
//            int LA113_0 = input.LA(1);
//
//            if ( (LA113_0==IDENTIFIER||LA113_0==STATIC||LA113_0==168) ) {
//                alt113=1;
//            }
//            else if ( (LA113_0==164) ) {
//                alt113=2;
//            }
//            else {
//                if (state.backtracking>0) {state.failed=true; return retval;}
//                NoViableAltException nvae =
//                    new NoViableAltException("", 113, 0, input);
//
//                throw nvae;
//            }
//            switch (alt113) {
//                case 1 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:471:5: variable
//                    {
//                    root_0 = (CommonTree)adaptor.nil();
//
//                    pushFollow(FOLLOW_variable_in_assignment_element3537);
//                    variable361=variable();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) adaptor.addChild(root_0, variable361.getTree());
//
//                    }
//                    break;
//                case 2 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:472:5: 'list' '(' assignment_list ')'
//                    {
//                    string_literal362=(Token)match(input,164,FOLLOW_164_in_assignment_element3543); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_164.add(string_literal362);
//
//                    char_literal363=(Token)match(input,61,FOLLOW_61_in_assignment_element3545); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_61.add(char_literal363);
//
//                    pushFollow(FOLLOW_assignment_list_in_assignment_element3547);
//                    assignment_list364=assignment_list();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) stream_assignment_list.add(assignment_list364.getTree());
//                    char_literal365=(Token)match(input,62,FOLLOW_62_in_assignment_element3549); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_62.add(char_literal365);
//
//
//
//                    // AST REWRITE
//                    // elements: 164, assignment_list
//                    // token labels: 
//                    // rule labels: retval
//                    // token list labels: 
//                    // rule list labels: 
//                    // wildcard labels: 
//                    if ( state.backtracking==0 ) {
//                    retval.tree = root_0;
//                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//                    root_0 = (CommonTree)adaptor.nil();
//                    // 472:36: -> ^( 'list' assignment_list )
//                    {
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:472:39: ^( 'list' assignment_list )
//                        {
//                        CommonTree root_1 = (CommonTree)adaptor.nil();
//                        root_1 = (CommonTree)adaptor.becomeRoot(stream_164.nextNode(), root_1);
//
//                        adaptor.addChild(root_1, stream_assignment_list.nextTree());
//
//                        adaptor.addChild(root_0, root_1);
//                        }
//
//                    }
//
//                    retval.tree = root_0;}
//                    }
//                    break;
//
//            }
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "assignment_element"
//
//    public static class array_pair_list_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "array_pair_list"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:475:1: array_pair_list : array_pair_element ( ',' array_pair_element )* ( ',' )? -> ( array_pair_element )+ ;
//    public final CompilerAstParser.array_pair_list_return array_pair_list() throws RecognitionException {
//        CompilerAstParser.array_pair_list_return retval = new CompilerAstParser.array_pair_list_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token char_literal367=null;
//        Token char_literal369=null;
//        CompilerAstParser.array_pair_element_return array_pair_element366 = null;
//
//        CompilerAstParser.array_pair_element_return array_pair_element368 = null;
//
//
//        CommonTree char_literal367_tree=null;
//        CommonTree char_literal369_tree=null;
//        RewriteRuleTokenStream stream_93=new RewriteRuleTokenStream(adaptor,"token 93");
//        RewriteRuleSubtreeStream stream_array_pair_element=new RewriteRuleSubtreeStream(adaptor,"rule array_pair_element");
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:476:3: ( array_pair_element ( ',' array_pair_element )* ( ',' )? -> ( array_pair_element )+ )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:476:5: array_pair_element ( ',' array_pair_element )* ( ',' )?
//            {
//            pushFollow(FOLLOW_array_pair_element_in_array_pair_list3572);
//            array_pair_element366=array_pair_element();
//
//            state._fsp--;
//            if (state.failed) return retval;
//            if ( state.backtracking==0 ) stream_array_pair_element.add(array_pair_element366.getTree());
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:476:24: ( ',' array_pair_element )*
//            loop114:
//            do {
//                int alt114=2;
//                int LA114_0 = input.LA(1);
//
//                if ( (LA114_0==93) ) {
//                    int LA114_1 = input.LA(2);
//
//                    if ( ((LA114_1>=IDENTIFIER && LA114_1<=DOUBLELITERRAL)||LA114_1==61||(LA114_1>=72 && LA114_1<=73)||(LA114_1>=142 && LA114_1<=143)||(LA114_1>=154 && LA114_1<=155)||(LA114_1>=157 && LA114_1<=161)||(LA114_1>=163 && LA114_1<=166)||LA114_1==168||(LA114_1>=171 && LA114_1<=176)) ) {
//                        alt114=1;
//                    }
//
//
//                }
//
//
//                switch (alt114) {
//            	case 1 :
//            	    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:476:25: ',' array_pair_element
//            	    {
//            	    char_literal367=(Token)match(input,93,FOLLOW_93_in_array_pair_list3575); if (state.failed) return retval; 
//            	    if ( state.backtracking==0 ) stream_93.add(char_literal367);
//
//            	    pushFollow(FOLLOW_array_pair_element_in_array_pair_list3577);
//            	    array_pair_element368=array_pair_element();
//
//            	    state._fsp--;
//            	    if (state.failed) return retval;
//            	    if ( state.backtracking==0 ) stream_array_pair_element.add(array_pair_element368.getTree());
//
//            	    }
//            	    break;
//
//            	default :
//            	    break loop114;
//                }
//            } while (true);
//
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:476:50: ( ',' )?
//            int alt115=2;
//            int LA115_0 = input.LA(1);
//
//            if ( (LA115_0==93) ) {
//                alt115=1;
//            }
//            switch (alt115) {
//                case 1 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:476:50: ','
//                    {
//                    char_literal369=(Token)match(input,93,FOLLOW_93_in_array_pair_list3581); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_93.add(char_literal369);
//
//
//                    }
//                    break;
//
//            }
//
//
//
//            // AST REWRITE
//            // elements: array_pair_element
//            // token labels: 
//            // rule labels: retval
//            // token list labels: 
//            // rule list labels: 
//            // wildcard labels: 
//            if ( state.backtracking==0 ) {
//            retval.tree = root_0;
//            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//            root_0 = (CommonTree)adaptor.nil();
//            // 476:56: -> ( array_pair_element )+
//            {
//                if ( !(stream_array_pair_element.hasNext()) ) {
//                    throw new RewriteEarlyExitException();
//                }
//                while ( stream_array_pair_element.hasNext() ) {
//                    adaptor.addChild(root_0, stream_array_pair_element.nextTree());
//
//                }
//                stream_array_pair_element.reset();
//
//            }
//
//            retval.tree = root_0;}
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "array_pair_list"
//
//    public static class array_pair_element_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "array_pair_element"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:479:1: array_pair_element : expression ( '=>' expression )? ;
//    public final CompilerAstParser.array_pair_element_return array_pair_element() throws RecognitionException {
//        CompilerAstParser.array_pair_element_return retval = new CompilerAstParser.array_pair_element_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token string_literal371=null;
//        CompilerAstParser.expression_return expression370 = null;
//
//        CompilerAstParser.expression_return expression372 = null;
//
//
//        CommonTree string_literal371_tree=null;
//
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:480:3: ( expression ( '=>' expression )? )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:480:5: expression ( '=>' expression )?
//            {
//            root_0 = (CommonTree)adaptor.nil();
//
//            pushFollow(FOLLOW_expression_in_array_pair_element3603);
//            expression370=expression();
//
//            state._fsp--;
//            if (state.failed) return retval;
//            if ( state.backtracking==0 ) adaptor.addChild(root_0, expression370.getTree());
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:480:16: ( '=>' expression )?
//            int alt116=2;
//            int LA116_0 = input.LA(1);
//
//            if ( (LA116_0==90) ) {
//                alt116=1;
//            }
//            switch (alt116) {
//                case 1 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:480:17: '=>' expression
//                    {
//                    string_literal371=(Token)match(input,90,FOLLOW_90_in_array_pair_element3606); if (state.failed) return retval;
//                    if ( state.backtracking==0 ) {
//                    string_literal371_tree = (CommonTree)adaptor.create(string_literal371);
//                    root_0 = (CommonTree)adaptor.becomeRoot(string_literal371_tree, root_0);
//                    }
//                    pushFollow(FOLLOW_expression_in_array_pair_element3609);
//                    expression372=expression();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) adaptor.addChild(root_0, expression372.getTree());
//
//                    }
//                    break;
//
//            }
//
//
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "array_pair_element"
//
//    public static class variable_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "variable"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:483:1: variable : ( base_variable_with_function_calls -> base_variable_with_function_calls ) ( '->' object_property ( ctor_arguments )? -> ^( CALL $variable ^( CALLED_OBJ object_property ( ctor_arguments )? ) ) )* ;
//    public final CompilerAstParser.variable_return variable() throws RecognitionException {
//        CompilerAstParser.variable_return retval = new CompilerAstParser.variable_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token string_literal374=null;
//        CompilerAstParser.base_variable_with_function_calls_return base_variable_with_function_calls373 = null;
//
//        CompilerAstParser.object_property_return object_property375 = null;
//
//        CompilerAstParser.ctor_arguments_return ctor_arguments376 = null;
//
//
//        CommonTree string_literal374_tree=null;
//        RewriteRuleTokenStream stream_167=new RewriteRuleTokenStream(adaptor,"token 167");
//        RewriteRuleSubtreeStream stream_ctor_arguments=new RewriteRuleSubtreeStream(adaptor,"rule ctor_arguments");
//        RewriteRuleSubtreeStream stream_object_property=new RewriteRuleSubtreeStream(adaptor,"rule object_property");
//        RewriteRuleSubtreeStream stream_base_variable_with_function_calls=new RewriteRuleSubtreeStream(adaptor,"rule base_variable_with_function_calls");
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:484:3: ( ( base_variable_with_function_calls -> base_variable_with_function_calls ) ( '->' object_property ( ctor_arguments )? -> ^( CALL $variable ^( CALLED_OBJ object_property ( ctor_arguments )? ) ) )* )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:484:5: ( base_variable_with_function_calls -> base_variable_with_function_calls ) ( '->' object_property ( ctor_arguments )? -> ^( CALL $variable ^( CALLED_OBJ object_property ( ctor_arguments )? ) ) )*
//            {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:484:5: ( base_variable_with_function_calls -> base_variable_with_function_calls )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:484:6: base_variable_with_function_calls
//            {
//            pushFollow(FOLLOW_base_variable_with_function_calls_in_variable3629);
//            base_variable_with_function_calls373=base_variable_with_function_calls();
//
//            state._fsp--;
//            if (state.failed) return retval;
//            if ( state.backtracking==0 ) stream_base_variable_with_function_calls.add(base_variable_with_function_calls373.getTree());
//
//
//            // AST REWRITE
//            // elements: base_variable_with_function_calls
//            // token labels: 
//            // rule labels: retval
//            // token list labels: 
//            // rule list labels: 
//            // wildcard labels: 
//            if ( state.backtracking==0 ) {
//            retval.tree = root_0;
//            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//            root_0 = (CommonTree)adaptor.nil();
//            // 484:40: -> base_variable_with_function_calls
//            {
//                adaptor.addChild(root_0, stream_base_variable_with_function_calls.nextTree());
//
//            }
//
//            retval.tree = root_0;}
//            }
//
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:485:4: ( '->' object_property ( ctor_arguments )? -> ^( CALL $variable ^( CALLED_OBJ object_property ( ctor_arguments )? ) ) )*
//            loop118:
//            do {
//                int alt118=2;
//                int LA118_0 = input.LA(1);
//
//                if ( (LA118_0==167) ) {
//                    alt118=1;
//                }
//
//
//                switch (alt118) {
//            	case 1 :
//            	    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:485:5: '->' object_property ( ctor_arguments )?
//            	    {
//            	    string_literal374=(Token)match(input,167,FOLLOW_167_in_variable3640); if (state.failed) return retval; 
//            	    if ( state.backtracking==0 ) stream_167.add(string_literal374);
//
//            	    pushFollow(FOLLOW_object_property_in_variable3642);
//            	    object_property375=object_property();
//
//            	    state._fsp--;
//            	    if (state.failed) return retval;
//            	    if ( state.backtracking==0 ) stream_object_property.add(object_property375.getTree());
//            	    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:485:26: ( ctor_arguments )?
//            	    int alt117=2;
//            	    int LA117_0 = input.LA(1);
//
//            	    if ( (LA117_0==61) ) {
//            	        alt117=1;
//            	    }
//            	    switch (alt117) {
//            	        case 1 :
//            	            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:485:26: ctor_arguments
//            	            {
//            	            pushFollow(FOLLOW_ctor_arguments_in_variable3644);
//            	            ctor_arguments376=ctor_arguments();
//
//            	            state._fsp--;
//            	            if (state.failed) return retval;
//            	            if ( state.backtracking==0 ) stream_ctor_arguments.add(ctor_arguments376.getTree());
//
//            	            }
//            	            break;
//
//            	    }
//
//
//
//            	    // AST REWRITE
//            	    // elements: ctor_arguments, object_property, variable
//            	    // token labels: 
//            	    // rule labels: retval
//            	    // token list labels: 
//            	    // rule list labels: 
//            	    // wildcard labels: 
//            	    if ( state.backtracking==0 ) {
//            	    retval.tree = root_0;
//            	    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//            	    root_0 = (CommonTree)adaptor.nil();
//            	    // 486:4: -> ^( CALL $variable ^( CALLED_OBJ object_property ( ctor_arguments )? ) )
//            	    {
//            	        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:486:7: ^( CALL $variable ^( CALLED_OBJ object_property ( ctor_arguments )? ) )
//            	        {
//            	        CommonTree root_1 = (CommonTree)adaptor.nil();
//            	        root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(CALL, "CALL"), root_1);
//
//            	        adaptor.addChild(root_1, stream_retval.nextTree());
//            	        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:486:24: ^( CALLED_OBJ object_property ( ctor_arguments )? )
//            	        {
//            	        CommonTree root_2 = (CommonTree)adaptor.nil();
//            	        root_2 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(CALLED_OBJ, "CALLED_OBJ"), root_2);
//
//            	        adaptor.addChild(root_2, stream_object_property.nextTree());
//            	        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:486:53: ( ctor_arguments )?
//            	        if ( stream_ctor_arguments.hasNext() ) {
//            	            adaptor.addChild(root_2, stream_ctor_arguments.nextTree());
//
//            	        }
//            	        stream_ctor_arguments.reset();
//
//            	        adaptor.addChild(root_1, root_2);
//            	        }
//
//            	        adaptor.addChild(root_0, root_1);
//            	        }
//
//            	    }
//
//            	    retval.tree = root_0;}
//            	    }
//            	    break;
//
//            	default :
//            	    break loop118;
//                }
//            } while (true);
//
//
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "variable"
//
//    public static class base_variable_with_function_calls_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "base_variable_with_function_calls"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:489:1: base_variable_with_function_calls : ( STATIC '::' reference_variable -> ^( VAR_DECL ^( '::' STATIC reference_variable ) ) | ( fully_qualified_class_name )? '$' object_property ( ctor_arguments )? -> ^( VAR_DECL ( fully_qualified_class_name )? '$' object_property ( ctor_arguments )? ) | fully_qualified_class_name ctor_arguments -> ^( CALL fully_qualified_class_name ctor_arguments ) | fully_qualified_class_name );
//    public final CompilerAstParser.base_variable_with_function_calls_return base_variable_with_function_calls() throws RecognitionException {
//        CompilerAstParser.base_variable_with_function_calls_return retval = new CompilerAstParser.base_variable_with_function_calls_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token STATIC377=null;
//        Token string_literal378=null;
//        Token char_literal381=null;
//        CompilerAstParser.reference_variable_return reference_variable379 = null;
//
//        CompilerAstParser.fully_qualified_class_name_return fully_qualified_class_name380 = null;
//
//        CompilerAstParser.object_property_return object_property382 = null;
//
//        CompilerAstParser.ctor_arguments_return ctor_arguments383 = null;
//
//        CompilerAstParser.fully_qualified_class_name_return fully_qualified_class_name384 = null;
//
//        CompilerAstParser.ctor_arguments_return ctor_arguments385 = null;
//
//        CompilerAstParser.fully_qualified_class_name_return fully_qualified_class_name386 = null;
//
//
//        CommonTree STATIC377_tree=null;
//        CommonTree string_literal378_tree=null;
//        CommonTree char_literal381_tree=null;
//        RewriteRuleTokenStream stream_92=new RewriteRuleTokenStream(adaptor,"token 92");
//        RewriteRuleTokenStream stream_STATIC=new RewriteRuleTokenStream(adaptor,"token STATIC");
//        RewriteRuleTokenStream stream_168=new RewriteRuleTokenStream(adaptor,"token 168");
//        RewriteRuleSubtreeStream stream_ctor_arguments=new RewriteRuleSubtreeStream(adaptor,"rule ctor_arguments");
//        RewriteRuleSubtreeStream stream_fully_qualified_class_name=new RewriteRuleSubtreeStream(adaptor,"rule fully_qualified_class_name");
//        RewriteRuleSubtreeStream stream_object_property=new RewriteRuleSubtreeStream(adaptor,"rule object_property");
//        RewriteRuleSubtreeStream stream_reference_variable=new RewriteRuleSubtreeStream(adaptor,"rule reference_variable");
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:490:3: ( STATIC '::' reference_variable -> ^( VAR_DECL ^( '::' STATIC reference_variable ) ) | ( fully_qualified_class_name )? '$' object_property ( ctor_arguments )? -> ^( VAR_DECL ( fully_qualified_class_name )? '$' object_property ( ctor_arguments )? ) | fully_qualified_class_name ctor_arguments -> ^( CALL fully_qualified_class_name ctor_arguments ) | fully_qualified_class_name )
//            int alt121=4;
//            alt121 = dfa121.predict(input);
//            switch (alt121) {
//                case 1 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:490:5: STATIC '::' reference_variable
//                    {
//                    STATIC377=(Token)match(input,STATIC,FOLLOW_STATIC_in_base_variable_with_function_calls3683); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_STATIC.add(STATIC377);
//
//                    string_literal378=(Token)match(input,92,FOLLOW_92_in_base_variable_with_function_calls3685); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_92.add(string_literal378);
//
//                    pushFollow(FOLLOW_reference_variable_in_base_variable_with_function_calls3687);
//                    reference_variable379=reference_variable();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) stream_reference_variable.add(reference_variable379.getTree());
//
//
//                    // AST REWRITE
//                    // elements: STATIC, 92, reference_variable
//                    // token labels: 
//                    // rule labels: retval
//                    // token list labels: 
//                    // rule list labels: 
//                    // wildcard labels: 
//                    if ( state.backtracking==0 ) {
//                    retval.tree = root_0;
//                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//                    root_0 = (CommonTree)adaptor.nil();
//                    // 490:39: -> ^( VAR_DECL ^( '::' STATIC reference_variable ) )
//                    {
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:490:42: ^( VAR_DECL ^( '::' STATIC reference_variable ) )
//                        {
//                        CommonTree root_1 = (CommonTree)adaptor.nil();
//                        root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(VAR_DECL, "VAR_DECL"), root_1);
//
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:490:53: ^( '::' STATIC reference_variable )
//                        {
//                        CommonTree root_2 = (CommonTree)adaptor.nil();
//                        root_2 = (CommonTree)adaptor.becomeRoot(stream_92.nextNode(), root_2);
//
//                        adaptor.addChild(root_2, stream_STATIC.nextNode());
//                        adaptor.addChild(root_2, stream_reference_variable.nextTree());
//
//                        adaptor.addChild(root_1, root_2);
//                        }
//
//                        adaptor.addChild(root_0, root_1);
//                        }
//
//                    }
//
//                    retval.tree = root_0;}
//                    }
//                    break;
//                case 2 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:491:5: ( fully_qualified_class_name )? '$' object_property ( ctor_arguments )?
//                    {
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:491:5: ( fully_qualified_class_name )?
//                    int alt119=2;
//                    int LA119_0 = input.LA(1);
//
//                    if ( (LA119_0==IDENTIFIER) ) {
//                        alt119=1;
//                    }
//                    switch (alt119) {
//                        case 1 :
//                            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:491:5: fully_qualified_class_name
//                            {
//                            pushFollow(FOLLOW_fully_qualified_class_name_in_base_variable_with_function_calls3710);
//                            fully_qualified_class_name380=fully_qualified_class_name();
//
//                            state._fsp--;
//                            if (state.failed) return retval;
//                            if ( state.backtracking==0 ) stream_fully_qualified_class_name.add(fully_qualified_class_name380.getTree());
//
//                            }
//                            break;
//
//                    }
//
//                    char_literal381=(Token)match(input,168,FOLLOW_168_in_base_variable_with_function_calls3713); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_168.add(char_literal381);
//
//                    pushFollow(FOLLOW_object_property_in_base_variable_with_function_calls3715);
//                    object_property382=object_property();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) stream_object_property.add(object_property382.getTree());
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:491:53: ( ctor_arguments )?
//                    int alt120=2;
//                    int LA120_0 = input.LA(1);
//
//                    if ( (LA120_0==61) ) {
//                        alt120=1;
//                    }
//                    switch (alt120) {
//                        case 1 :
//                            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:491:53: ctor_arguments
//                            {
//                            pushFollow(FOLLOW_ctor_arguments_in_base_variable_with_function_calls3717);
//                            ctor_arguments383=ctor_arguments();
//
//                            state._fsp--;
//                            if (state.failed) return retval;
//                            if ( state.backtracking==0 ) stream_ctor_arguments.add(ctor_arguments383.getTree());
//
//                            }
//                            break;
//
//                    }
//
//
//
//                    // AST REWRITE
//                    // elements: fully_qualified_class_name, 168, ctor_arguments, object_property
//                    // token labels: 
//                    // rule labels: retval
//                    // token list labels: 
//                    // rule list labels: 
//                    // wildcard labels: 
//                    if ( state.backtracking==0 ) {
//                    retval.tree = root_0;
//                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//                    root_0 = (CommonTree)adaptor.nil();
//                    // 491:70: -> ^( VAR_DECL ( fully_qualified_class_name )? '$' object_property ( ctor_arguments )? )
//                    {
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:491:73: ^( VAR_DECL ( fully_qualified_class_name )? '$' object_property ( ctor_arguments )? )
//                        {
//                        CommonTree root_1 = (CommonTree)adaptor.nil();
//                        root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(VAR_DECL, "VAR_DECL"), root_1);
//
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:491:84: ( fully_qualified_class_name )?
//                        if ( stream_fully_qualified_class_name.hasNext() ) {
//                            adaptor.addChild(root_1, stream_fully_qualified_class_name.nextTree());
//
//                        }
//                        stream_fully_qualified_class_name.reset();
//                        adaptor.addChild(root_1, stream_168.nextNode());
//                        adaptor.addChild(root_1, stream_object_property.nextTree());
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:491:132: ( ctor_arguments )?
//                        if ( stream_ctor_arguments.hasNext() ) {
//                            adaptor.addChild(root_1, stream_ctor_arguments.nextTree());
//
//                        }
//                        stream_ctor_arguments.reset();
//
//                        adaptor.addChild(root_0, root_1);
//                        }
//
//                    }
//
//                    retval.tree = root_0;}
//                    }
//                    break;
//                case 3 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:492:5: fully_qualified_class_name ctor_arguments
//                    {
//                    pushFollow(FOLLOW_fully_qualified_class_name_in_base_variable_with_function_calls3741);
//                    fully_qualified_class_name384=fully_qualified_class_name();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) stream_fully_qualified_class_name.add(fully_qualified_class_name384.getTree());
//                    pushFollow(FOLLOW_ctor_arguments_in_base_variable_with_function_calls3743);
//                    ctor_arguments385=ctor_arguments();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) stream_ctor_arguments.add(ctor_arguments385.getTree());
//
//
//                    // AST REWRITE
//                    // elements: fully_qualified_class_name, ctor_arguments
//                    // token labels: 
//                    // rule labels: retval
//                    // token list labels: 
//                    // rule list labels: 
//                    // wildcard labels: 
//                    if ( state.backtracking==0 ) {
//                    retval.tree = root_0;
//                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//                    root_0 = (CommonTree)adaptor.nil();
//                    // 492:48: -> ^( CALL fully_qualified_class_name ctor_arguments )
//                    {
//                        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:492:51: ^( CALL fully_qualified_class_name ctor_arguments )
//                        {
//                        CommonTree root_1 = (CommonTree)adaptor.nil();
//                        root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(CALL, "CALL"), root_1);
//
//                        adaptor.addChild(root_1, stream_fully_qualified_class_name.nextTree());
//                        adaptor.addChild(root_1, stream_ctor_arguments.nextTree());
//
//                        adaptor.addChild(root_0, root_1);
//                        }
//
//                    }
//
//                    retval.tree = root_0;}
//                    }
//                    break;
//                case 4 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:493:5: fully_qualified_class_name
//                    {
//                    root_0 = (CommonTree)adaptor.nil();
//
//                    pushFollow(FOLLOW_fully_qualified_class_name_in_base_variable_with_function_calls3760);
//                    fully_qualified_class_name386=fully_qualified_class_name();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) adaptor.addChild(root_0, fully_qualified_class_name386.getTree());
//
//                    }
//                    break;
//
//            }
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "base_variable_with_function_calls"
//
//    public static class object_property_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "object_property"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:496:1: object_property : ( '$' )* reference_variable ;
//    public final CompilerAstParser.object_property_return object_property() throws RecognitionException {
//        CompilerAstParser.object_property_return retval = new CompilerAstParser.object_property_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token char_literal387=null;
//        CompilerAstParser.reference_variable_return reference_variable388 = null;
//
//
//        CommonTree char_literal387_tree=null;
//
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:497:3: ( ( '$' )* reference_variable )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:497:5: ( '$' )* reference_variable
//            {
//            root_0 = (CommonTree)adaptor.nil();
//
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:497:5: ( '$' )*
//            loop122:
//            do {
//                int alt122=2;
//                int LA122_0 = input.LA(1);
//
//                if ( (LA122_0==168) ) {
//                    alt122=1;
//                }
//
//
//                switch (alt122) {
//            	case 1 :
//            	    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:497:5: '$'
//            	    {
//            	    char_literal387=(Token)match(input,168,FOLLOW_168_in_object_property3775); if (state.failed) return retval;
//            	    if ( state.backtracking==0 ) {
//            	    char_literal387_tree = (CommonTree)adaptor.create(char_literal387);
//            	    adaptor.addChild(root_0, char_literal387_tree);
//            	    }
//
//            	    }
//            	    break;
//
//            	default :
//            	    break loop122;
//                }
//            } while (true);
//
//            pushFollow(FOLLOW_reference_variable_in_object_property3778);
//            reference_variable388=reference_variable();
//
//            state._fsp--;
//            if (state.failed) return retval;
//            if ( state.backtracking==0 ) adaptor.addChild(root_0, reference_variable388.getTree());
//
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "object_property"
//
//    public static class reference_variable_return extends ParserRuleReturnScope {
//        public Expression RESULT;
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "reference_variable"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:500:1: reference_variable returns [Expression RESULT] : ( compound_variable -> compound_variable ) ( '[' ( expression )? ']' -> ^( INDEX $reference_variable ( expression )? ) | '{' expression '}' -> ^( INDEX $reference_variable expression ) )* ;
//    public final CompilerAstParser.reference_variable_return reference_variable() throws RecognitionException {
//        CompilerAstParser.reference_variable_return retval = new CompilerAstParser.reference_variable_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token char_literal390=null;
//        Token char_literal392=null;
//        Token char_literal393=null;
//        Token char_literal395=null;
//        CompilerAstParser.compound_variable_return compound_variable389 = null;
//
//        CompilerAstParser.expression_return expression391 = null;
//
//        CompilerAstParser.expression_return expression394 = null;
//
//
//        CommonTree char_literal390_tree=null;
//        CommonTree char_literal392_tree=null;
//        CommonTree char_literal393_tree=null;
//        CommonTree char_literal395_tree=null;
//        RewriteRuleTokenStream stream_170=new RewriteRuleTokenStream(adaptor,"token 170");
//        RewriteRuleTokenStream stream_67=new RewriteRuleTokenStream(adaptor,"token 67");
//        RewriteRuleTokenStream stream_68=new RewriteRuleTokenStream(adaptor,"token 68");
//        RewriteRuleTokenStream stream_169=new RewriteRuleTokenStream(adaptor,"token 169");
//        RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");
//        RewriteRuleSubtreeStream stream_compound_variable=new RewriteRuleSubtreeStream(adaptor,"rule compound_variable");
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:501:3: ( ( compound_variable -> compound_variable ) ( '[' ( expression )? ']' -> ^( INDEX $reference_variable ( expression )? ) | '{' expression '}' -> ^( INDEX $reference_variable expression ) )* )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:501:5: ( compound_variable -> compound_variable ) ( '[' ( expression )? ']' -> ^( INDEX $reference_variable ( expression )? ) | '{' expression '}' -> ^( INDEX $reference_variable expression ) )*
//            {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:501:5: ( compound_variable -> compound_variable )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:501:6: compound_variable
//            {
//            pushFollow(FOLLOW_compound_variable_in_reference_variable3798);
//            compound_variable389=compound_variable();
//
//            state._fsp--;
//            if (state.failed) return retval;
//            if ( state.backtracking==0 ) stream_compound_variable.add(compound_variable389.getTree());
//
//
//            // AST REWRITE
//            // elements: compound_variable
//            // token labels: 
//            // rule labels: retval
//            // token list labels: 
//            // rule list labels: 
//            // wildcard labels: 
//            if ( state.backtracking==0 ) {
//            retval.tree = root_0;
//            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//            root_0 = (CommonTree)adaptor.nil();
//            // 502:4: -> compound_variable
//            {
//                adaptor.addChild(root_0, stream_compound_variable.nextTree());
//
//            }
//
//            retval.tree = root_0;}
//            }
//
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:503:3: ( '[' ( expression )? ']' -> ^( INDEX $reference_variable ( expression )? ) | '{' expression '}' -> ^( INDEX $reference_variable expression ) )*
//            loop124:
//            do {
//                int alt124=3;
//                int LA124_0 = input.LA(1);
//
//                if ( (LA124_0==169) ) {
//                    alt124=1;
//                }
//                else if ( (LA124_0==67) ) {
//                    alt124=2;
//                }
//
//
//                switch (alt124) {
//            	case 1 :
//            	    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:504:3: '[' ( expression )? ']'
//            	    {
//            	    char_literal390=(Token)match(input,169,FOLLOW_169_in_reference_variable3814); if (state.failed) return retval; 
//            	    if ( state.backtracking==0 ) stream_169.add(char_literal390);
//
//            	    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:504:7: ( expression )?
//            	    int alt123=2;
//            	    int LA123_0 = input.LA(1);
//
//            	    if ( ((LA123_0>=IDENTIFIER && LA123_0<=DOUBLELITERRAL)||LA123_0==61||(LA123_0>=72 && LA123_0<=73)||(LA123_0>=142 && LA123_0<=143)||(LA123_0>=154 && LA123_0<=155)||(LA123_0>=157 && LA123_0<=161)||(LA123_0>=163 && LA123_0<=166)||LA123_0==168||(LA123_0>=171 && LA123_0<=176)) ) {
//            	        alt123=1;
//            	    }
//            	    switch (alt123) {
//            	        case 1 :
//            	            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:504:7: expression
//            	            {
//            	            pushFollow(FOLLOW_expression_in_reference_variable3816);
//            	            expression391=expression();
//
//            	            state._fsp--;
//            	            if (state.failed) return retval;
//            	            if ( state.backtracking==0 ) stream_expression.add(expression391.getTree());
//
//            	            }
//            	            break;
//
//            	    }
//
//            	    char_literal392=(Token)match(input,170,FOLLOW_170_in_reference_variable3819); if (state.failed) return retval; 
//            	    if ( state.backtracking==0 ) stream_170.add(char_literal392);
//
//
//
//            	    // AST REWRITE
//            	    // elements: expression, reference_variable
//            	    // token labels: 
//            	    // rule labels: retval
//            	    // token list labels: 
//            	    // rule list labels: 
//            	    // wildcard labels: 
//            	    if ( state.backtracking==0 ) {
//            	    retval.tree = root_0;
//            	    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//            	    root_0 = (CommonTree)adaptor.nil();
//            	    // 504:24: -> ^( INDEX $reference_variable ( expression )? )
//            	    {
//            	        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:504:27: ^( INDEX $reference_variable ( expression )? )
//            	        {
//            	        CommonTree root_1 = (CommonTree)adaptor.nil();
//            	        root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(INDEX, "INDEX"), root_1);
//
//            	        adaptor.addChild(root_1, stream_retval.nextTree());
//            	        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:504:55: ( expression )?
//            	        if ( stream_expression.hasNext() ) {
//            	            adaptor.addChild(root_1, stream_expression.nextTree());
//
//            	        }
//            	        stream_expression.reset();
//
//            	        adaptor.addChild(root_0, root_1);
//            	        }
//
//            	    }
//
//            	    retval.tree = root_0;}
//            	    }
//            	    break;
//            	case 2 :
//            	    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:506:3: '{' expression '}'
//            	    {
//            	    char_literal393=(Token)match(input,67,FOLLOW_67_in_reference_variable3840); if (state.failed) return retval; 
//            	    if ( state.backtracking==0 ) stream_67.add(char_literal393);
//
//            	    pushFollow(FOLLOW_expression_in_reference_variable3842);
//            	    expression394=expression();
//
//            	    state._fsp--;
//            	    if (state.failed) return retval;
//            	    if ( state.backtracking==0 ) stream_expression.add(expression394.getTree());
//            	    char_literal395=(Token)match(input,68,FOLLOW_68_in_reference_variable3844); if (state.failed) return retval; 
//            	    if ( state.backtracking==0 ) stream_68.add(char_literal395);
//
//
//
//            	    // AST REWRITE
//            	    // elements: reference_variable, expression
//            	    // token labels: 
//            	    // rule labels: retval
//            	    // token list labels: 
//            	    // rule list labels: 
//            	    // wildcard labels: 
//            	    if ( state.backtracking==0 ) {
//            	    retval.tree = root_0;
//            	    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//            	    root_0 = (CommonTree)adaptor.nil();
//            	    // 506:23: -> ^( INDEX $reference_variable expression )
//            	    {
//            	        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:506:26: ^( INDEX $reference_variable expression )
//            	        {
//            	        CommonTree root_1 = (CommonTree)adaptor.nil();
//            	        root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(INDEX, "INDEX"), root_1);
//
//            	        adaptor.addChild(root_1, stream_retval.nextTree());
//            	        adaptor.addChild(root_1, stream_expression.nextTree());
//
//            	        adaptor.addChild(root_0, root_1);
//            	        }
//
//            	    }
//
//            	    retval.tree = root_0;}
//            	    }
//            	    break;
//
//            	default :
//            	    break loop124;
//                }
//            } while (true);
//
//
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "reference_variable"
//
//    public static class compound_variable_return extends ParserRuleReturnScope {
//        public VariableReference RESULT;
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "compound_variable"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:510:1: compound_variable returns [VariableReference RESULT] : ( IDENTIFIER | '{' expression '}' );
//    public final CompilerAstParser.compound_variable_return compound_variable() throws RecognitionException {
//        CompilerAstParser.compound_variable_return retval = new CompilerAstParser.compound_variable_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token IDENTIFIER396=null;
//        Token char_literal397=null;
//        Token char_literal399=null;
//        CompilerAstParser.expression_return expression398 = null;
//
//
//        CommonTree IDENTIFIER396_tree=null;
//        CommonTree char_literal397_tree=null;
//        CommonTree char_literal399_tree=null;
//
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:511:3: ( IDENTIFIER | '{' expression '}' )
//            int alt125=2;
//            int LA125_0 = input.LA(1);
//
//            if ( (LA125_0==IDENTIFIER) ) {
//                alt125=1;
//            }
//            else if ( (LA125_0==67) ) {
//                alt125=2;
//            }
//            else {
//                if (state.backtracking>0) {state.failed=true; return retval;}
//                NoViableAltException nvae =
//                    new NoViableAltException("", 125, 0, input);
//
//                throw nvae;
//            }
//            switch (alt125) {
//                case 1 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:511:5: IDENTIFIER
//                    {
//                    root_0 = (CommonTree)adaptor.nil();
//
//                    IDENTIFIER396=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_compound_variable3880); if (state.failed) return retval;
//                    if ( state.backtracking==0 ) {
//                    IDENTIFIER396_tree = (CommonTree)adaptor.create(IDENTIFIER396);
//                    adaptor.addChild(root_0, IDENTIFIER396_tree);
//                    }
//
//                    }
//                    break;
//                case 2 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:512:5: '{' expression '}'
//                    {
//                    root_0 = (CommonTree)adaptor.nil();
//
//                    char_literal397=(Token)match(input,67,FOLLOW_67_in_compound_variable3886); if (state.failed) return retval;
//                    pushFollow(FOLLOW_expression_in_compound_variable3889);
//                    expression398=expression();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) adaptor.addChild(root_0, expression398.getTree());
//                    char_literal399=(Token)match(input,68,FOLLOW_68_in_compound_variable3891); if (state.failed) return retval;
//
//                    }
//                    break;
//
//            }
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "compound_variable"
//
//    public static class ctor_arguments_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "ctor_arguments"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:515:1: ctor_arguments : '(' ( expr_list )? ')' -> ^( ARGU ( expr_list )? ) ;
//    public final CompilerAstParser.ctor_arguments_return ctor_arguments() throws RecognitionException {
//        CompilerAstParser.ctor_arguments_return retval = new CompilerAstParser.ctor_arguments_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token char_literal400=null;
//        Token char_literal402=null;
//        CompilerAstParser.expr_list_return expr_list401 = null;
//
//
//        CommonTree char_literal400_tree=null;
//        CommonTree char_literal402_tree=null;
//        RewriteRuleTokenStream stream_62=new RewriteRuleTokenStream(adaptor,"token 62");
//        RewriteRuleTokenStream stream_61=new RewriteRuleTokenStream(adaptor,"token 61");
//        RewriteRuleSubtreeStream stream_expr_list=new RewriteRuleSubtreeStream(adaptor,"rule expr_list");
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:516:3: ( '(' ( expr_list )? ')' -> ^( ARGU ( expr_list )? ) )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:516:6: '(' ( expr_list )? ')'
//            {
//            char_literal400=(Token)match(input,61,FOLLOW_61_in_ctor_arguments3909); if (state.failed) return retval; 
//            if ( state.backtracking==0 ) stream_61.add(char_literal400);
//
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:516:10: ( expr_list )?
//            int alt126=2;
//            int LA126_0 = input.LA(1);
//
//            if ( ((LA126_0>=IDENTIFIER && LA126_0<=DOUBLELITERRAL)||LA126_0==61||(LA126_0>=72 && LA126_0<=73)||(LA126_0>=142 && LA126_0<=143)||(LA126_0>=154 && LA126_0<=155)||(LA126_0>=157 && LA126_0<=161)||(LA126_0>=163 && LA126_0<=166)||LA126_0==168||(LA126_0>=171 && LA126_0<=176)) ) {
//                alt126=1;
//            }
//            switch (alt126) {
//                case 1 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:516:10: expr_list
//                    {
//                    pushFollow(FOLLOW_expr_list_in_ctor_arguments3911);
//                    expr_list401=expr_list();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) stream_expr_list.add(expr_list401.getTree());
//
//                    }
//                    break;
//
//            }
//
//            char_literal402=(Token)match(input,62,FOLLOW_62_in_ctor_arguments3914); if (state.failed) return retval; 
//            if ( state.backtracking==0 ) stream_62.add(char_literal402);
//
//
//
//            // AST REWRITE
//            // elements: expr_list
//            // token labels: 
//            // rule labels: retval
//            // token list labels: 
//            // rule list labels: 
//            // wildcard labels: 
//            if ( state.backtracking==0 ) {
//            retval.tree = root_0;
//            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//            root_0 = (CommonTree)adaptor.nil();
//            // 516:26: -> ^( ARGU ( expr_list )? )
//            {
//                // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:516:29: ^( ARGU ( expr_list )? )
//                {
//                CommonTree root_1 = (CommonTree)adaptor.nil();
//                root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(ARGU, "ARGU"), root_1);
//
//                // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:516:36: ( expr_list )?
//                if ( stream_expr_list.hasNext() ) {
//                    adaptor.addChild(root_1, stream_expr_list.nextTree());
//
//                }
//                stream_expr_list.reset();
//
//                adaptor.addChild(root_0, root_1);
//                }
//
//            }
//
//            retval.tree = root_0;}
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "ctor_arguments"
//
//    public static class pure_variable_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "pure_variable"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:519:1: pure_variable : ( '&' )? ( '$' )+ IDENTIFIER -> ^( VAR_DECL ( '&' )? ( '$' )+ IDENTIFIER ) ;
//    public final CompilerAstParser.pure_variable_return pure_variable() throws RecognitionException {
//        CompilerAstParser.pure_variable_return retval = new CompilerAstParser.pure_variable_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token char_literal403=null;
//        Token char_literal404=null;
//        Token IDENTIFIER405=null;
//
//        CommonTree char_literal403_tree=null;
//        CommonTree char_literal404_tree=null;
//        CommonTree IDENTIFIER405_tree=null;
//        RewriteRuleTokenStream stream_IDENTIFIER=new RewriteRuleTokenStream(adaptor,"token IDENTIFIER");
//        RewriteRuleTokenStream stream_73=new RewriteRuleTokenStream(adaptor,"token 73");
//        RewriteRuleTokenStream stream_168=new RewriteRuleTokenStream(adaptor,"token 168");
//
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:520:2: ( ( '&' )? ( '$' )+ IDENTIFIER -> ^( VAR_DECL ( '&' )? ( '$' )+ IDENTIFIER ) )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:520:4: ( '&' )? ( '$' )+ IDENTIFIER
//            {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:520:4: ( '&' )?
//            int alt127=2;
//            int LA127_0 = input.LA(1);
//
//            if ( (LA127_0==73) ) {
//                alt127=1;
//            }
//            switch (alt127) {
//                case 1 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:520:4: '&'
//                    {
//                    char_literal403=(Token)match(input,73,FOLLOW_73_in_pure_variable3938); if (state.failed) return retval; 
//                    if ( state.backtracking==0 ) stream_73.add(char_literal403);
//
//
//                    }
//                    break;
//
//            }
//
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:520:9: ( '$' )+
//            int cnt128=0;
//            loop128:
//            do {
//                int alt128=2;
//                int LA128_0 = input.LA(1);
//
//                if ( (LA128_0==168) ) {
//                    alt128=1;
//                }
//
//
//                switch (alt128) {
//            	case 1 :
//            	    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:520:9: '$'
//            	    {
//            	    char_literal404=(Token)match(input,168,FOLLOW_168_in_pure_variable3941); if (state.failed) return retval; 
//            	    if ( state.backtracking==0 ) stream_168.add(char_literal404);
//
//
//            	    }
//            	    break;
//
//            	default :
//            	    if ( cnt128 >= 1 ) break loop128;
//            	    if (state.backtracking>0) {state.failed=true; return retval;}
//                        EarlyExitException eee =
//                            new EarlyExitException(128, input);
//                        throw eee;
//                }
//                cnt128++;
//            } while (true);
//
//            IDENTIFIER405=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_pure_variable3944); if (state.failed) return retval; 
//            if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER405);
//
//
//
//            // AST REWRITE
//            // elements: 168, 73, IDENTIFIER
//            // token labels: 
//            // rule labels: retval
//            // token list labels: 
//            // rule list labels: 
//            // wildcard labels: 
//            if ( state.backtracking==0 ) {
//            retval.tree = root_0;
//            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
//
//            root_0 = (CommonTree)adaptor.nil();
//            // 520:26: -> ^( VAR_DECL ( '&' )? ( '$' )+ IDENTIFIER )
//            {
//                // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:520:29: ^( VAR_DECL ( '&' )? ( '$' )+ IDENTIFIER )
//                {
//                CommonTree root_1 = (CommonTree)adaptor.nil();
//                root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(VAR_DECL, "VAR_DECL"), root_1);
//
//                // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:520:40: ( '&' )?
//                if ( stream_73.hasNext() ) {
//                    adaptor.addChild(root_1, stream_73.nextNode());
//
//                }
//                stream_73.reset();
//                if ( !(stream_168.hasNext()) ) {
//                    throw new RewriteEarlyExitException();
//                }
//                while ( stream_168.hasNext() ) {
//                    adaptor.addChild(root_1, stream_168.nextNode());
//
//                }
//                stream_168.reset();
//                adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());
//
//                adaptor.addChild(root_0, root_1);
//                }
//
//            }
//
//            retval.tree = root_0;}
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "pure_variable"
//
//    public static class constant_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "constant"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:524:1: constant : ( INTLITERAL | FLOATLITERAL | STRINGLITERAL | DOUBLELITERRAL | common_scalar );
//    public final CompilerAstParser.constant_return constant() throws RecognitionException {
//        CompilerAstParser.constant_return retval = new CompilerAstParser.constant_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token INTLITERAL406=null;
//        Token FLOATLITERAL407=null;
//        Token STRINGLITERAL408=null;
//        Token DOUBLELITERRAL409=null;
//        CompilerAstParser.common_scalar_return common_scalar410 = null;
//
//
//        CommonTree INTLITERAL406_tree=null;
//        CommonTree FLOATLITERAL407_tree=null;
//        CommonTree STRINGLITERAL408_tree=null;
//        CommonTree DOUBLELITERRAL409_tree=null;
//
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:525:3: ( INTLITERAL | FLOATLITERAL | STRINGLITERAL | DOUBLELITERRAL | common_scalar )
//            int alt129=5;
//            switch ( input.LA(1) ) {
//            case INTLITERAL:
//                {
//                alt129=1;
//                }
//                break;
//            case FLOATLITERAL:
//                {
//                alt129=2;
//                }
//                break;
//            case STRINGLITERAL:
//                {
//                alt129=3;
//                }
//                break;
//            case DOUBLELITERRAL:
//                {
//                alt129=4;
//                }
//                break;
//            case 171:
//            case 172:
//            case 173:
//            case 174:
//            case 175:
//            case 176:
//                {
//                alt129=5;
//                }
//                break;
//            default:
//                if (state.backtracking>0) {state.failed=true; return retval;}
//                NoViableAltException nvae =
//                    new NoViableAltException("", 129, 0, input);
//
//                throw nvae;
//            }
//
//            switch (alt129) {
//                case 1 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:525:7: INTLITERAL
//                    {
//                    root_0 = (CommonTree)adaptor.nil();
//
//                    INTLITERAL406=(Token)match(input,INTLITERAL,FOLLOW_INTLITERAL_in_constant3978); if (state.failed) return retval;
//                    if ( state.backtracking==0 ) {
//                    INTLITERAL406_tree = (CommonTree)adaptor.create(INTLITERAL406);
//                    adaptor.addChild(root_0, INTLITERAL406_tree);
//                    }
//
//                    }
//                    break;
//                case 2 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:526:7: FLOATLITERAL
//                    {
//                    root_0 = (CommonTree)adaptor.nil();
//
//                    FLOATLITERAL407=(Token)match(input,FLOATLITERAL,FOLLOW_FLOATLITERAL_in_constant3986); if (state.failed) return retval;
//                    if ( state.backtracking==0 ) {
//                    FLOATLITERAL407_tree = (CommonTree)adaptor.create(FLOATLITERAL407);
//                    adaptor.addChild(root_0, FLOATLITERAL407_tree);
//                    }
//
//                    }
//                    break;
//                case 3 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:527:7: STRINGLITERAL
//                    {
//                    root_0 = (CommonTree)adaptor.nil();
//
//                    STRINGLITERAL408=(Token)match(input,STRINGLITERAL,FOLLOW_STRINGLITERAL_in_constant3994); if (state.failed) return retval;
//                    if ( state.backtracking==0 ) {
//                    STRINGLITERAL408_tree = (CommonTree)adaptor.create(STRINGLITERAL408);
//                    adaptor.addChild(root_0, STRINGLITERAL408_tree);
//                    }
//
//                    }
//                    break;
//                case 4 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:528:7: DOUBLELITERRAL
//                    {
//                    root_0 = (CommonTree)adaptor.nil();
//
//                    DOUBLELITERRAL409=(Token)match(input,DOUBLELITERRAL,FOLLOW_DOUBLELITERRAL_in_constant4002); if (state.failed) return retval;
//                    if ( state.backtracking==0 ) {
//                    DOUBLELITERRAL409_tree = (CommonTree)adaptor.create(DOUBLELITERRAL409);
//                    adaptor.addChild(root_0, DOUBLELITERRAL409_tree);
//                    }
//
//                    }
//                    break;
//                case 5 :
//                    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:529:7: common_scalar
//                    {
//                    root_0 = (CommonTree)adaptor.nil();
//
//                    pushFollow(FOLLOW_common_scalar_in_constant4010);
//                    common_scalar410=common_scalar();
//
//                    state._fsp--;
//                    if (state.failed) return retval;
//                    if ( state.backtracking==0 ) adaptor.addChild(root_0, common_scalar410.getTree());
//
//                    }
//                    break;
//
//            }
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "constant"
//
//    public static class common_scalar_return extends ParserRuleReturnScope {
//        CommonTree tree;
//        public Object getTree() { return tree; }
//    };
//
//    // $ANTLR start "common_scalar"
//    // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:532:1: common_scalar : ( '__CLASS__' | '__DIR__' | '__FILE__' | '__FUNCTION__' | '__METHOD__' | '__NAMESPACE__' );
//    public final CompilerAstParser.common_scalar_return common_scalar() throws RecognitionException {
//        CompilerAstParser.common_scalar_return retval = new CompilerAstParser.common_scalar_return();
//        retval.start = input.LT(1);
//
//        CommonTree root_0 = null;
//
//        Token set411=null;
//
//        CommonTree set411_tree=null;
//
//        try {
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:533:3: ( '__CLASS__' | '__DIR__' | '__FILE__' | '__FUNCTION__' | '__METHOD__' | '__NAMESPACE__' )
//            // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:
//            {
//            root_0 = (CommonTree)adaptor.nil();
//
//            set411=(Token)input.LT(1);
//            if ( (input.LA(1)>=171 && input.LA(1)<=176) ) {
//                input.consume();
//                if ( state.backtracking==0 ) adaptor.addChild(root_0, (CommonTree)adaptor.create(set411));
//                state.errorRecovery=false;state.failed=false;
//            }
//            else {
//                if (state.backtracking>0) {state.failed=true; return retval;}
//                MismatchedSetException mse = new MismatchedSetException(null,input);
//                throw mse;
//            }
//
//
//            }
//
//            retval.stop = input.LT(-1);
//
//            if ( state.backtracking==0 ) {
//
//            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
//            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
//            }
//        }
//        catch (RecognitionException re) {
//            reportError(re);
//            recover(input,re);
//    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
//
//        }
//        finally {
//        }
//        return retval;
//    }
//    // $ANTLR end "common_scalar"
//
//    // $ANTLR start synpred1_CompilerAst
//    public final void synpred1_CompilerAst_fragment() throws RecognitionException {   
//        CompilerAstParser.expression_return eElseCond = null;
//
//        CompilerAstParser.statement_return s2 = null;
//
//
//        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:230:53: ( 'elseif' '(' eElseCond= expression ')' s2= statement )
//        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:230:53: 'elseif' '(' eElseCond= expression ')' s2= statement
//        {
//        match(input,96,FOLLOW_96_in_synpred1_CompilerAst1641); if (state.failed) return ;
//        match(input,61,FOLLOW_61_in_synpred1_CompilerAst1643); if (state.failed) return ;
//        pushFollow(FOLLOW_expression_in_synpred1_CompilerAst1647);
//        eElseCond=expression();
//
//        state._fsp--;
//        if (state.failed) return ;
//        match(input,62,FOLLOW_62_in_synpred1_CompilerAst1649); if (state.failed) return ;
//        pushFollow(FOLLOW_statement_in_synpred1_CompilerAst1653);
//        s2=statement();
//
//        state._fsp--;
//        if (state.failed) return ;
//
//        }
//    }
//    // $ANTLR end synpred1_CompilerAst
//
//    // $ANTLR start synpred2_CompilerAst
//    public final void synpred2_CompilerAst_fragment() throws RecognitionException {   
//        CompilerAstParser.statement_return s3 = null;
//
//
//        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:231:41: ( 'else' s3= statement )
//        // /home/dustin/workspace/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:231:41: 'else' s3= statement
//        {
//        match(input,97,FOLLOW_97_in_synpred2_CompilerAst1678); if (state.failed) return ;
//        pushFollow(FOLLOW_statement_in_synpred2_CompilerAst1682);
//        s3=statement();
//
//        state._fsp--;
//        if (state.failed) return ;
//
//        }
//    }
//    // $ANTLR end synpred2_CompilerAst
//
//    // Delegated rules
//
//    public final boolean synpred2_CompilerAst() {
//        state.backtracking++;
//        int start = input.mark();
//        try {
//            synpred2_CompilerAst_fragment(); // can never throw exception
//        } catch (RecognitionException re) {
//            System.err.println("impossible: "+re);
//        }
//        boolean success = !state.failed;
//        input.rewind(start);
//        state.backtracking--;
//        state.failed=false;
//        return success;
//    }
//    public final boolean synpred1_CompilerAst() {
//        state.backtracking++;
//        int start = input.mark();
//        try {
//            synpred1_CompilerAst_fragment(); // can never throw exception
//        } catch (RecognitionException re) {
//            System.err.println("impossible: "+re);
//        }
//        boolean success = !state.failed;
//        input.rewind(start);
//        state.backtracking--;
//        state.failed=false;
//        return success;
//    }
//
//
//    protected DFA17 dfa17 = new DFA17(this);
//    protected DFA44 dfa44 = new DFA44(this);
//    protected DFA45 dfa45 = new DFA45(this);
//    protected DFA105 dfa105 = new DFA105(this);
//    protected DFA121 dfa121 = new DFA121(this);
//    static final String DFA17_eotS =
//        "\5\uffff";
//    static final String DFA17_eofS =
//        "\5\uffff";
//    static final String DFA17_minS =
//        "\1\106\1\uffff\1\106\2\uffff";
//    static final String DFA17_maxS =
//        "\1\157\1\uffff\1\u00a8\2\uffff";
//    static final String DFA17_acceptS =
//        "\1\uffff\1\1\1\uffff\1\2\1\3";
//    static final String DFA17_specialS =
//        "\5\uffff}>";
//    static final String[] DFA17_transitionS = {
//            "\2\2\1\3\11\uffff\1\2\10\uffff\1\4\20\uffff\1\1\3\2",
//            "",
//            "\2\2\1\3\1\1\10\uffff\1\2\32\uffff\3\2\70\uffff\1\1",
//            "",
//            ""
//    };
//
//    static final short[] DFA17_eot = DFA.unpackEncodedString(DFA17_eotS);
//    static final short[] DFA17_eof = DFA.unpackEncodedString(DFA17_eofS);
//    static final char[] DFA17_min = DFA.unpackEncodedStringToUnsignedChars(DFA17_minS);
//    static final char[] DFA17_max = DFA.unpackEncodedStringToUnsignedChars(DFA17_maxS);
//    static final short[] DFA17_accept = DFA.unpackEncodedString(DFA17_acceptS);
//    static final short[] DFA17_special = DFA.unpackEncodedString(DFA17_specialS);
//    static final short[][] DFA17_transition;
//
//    static {
//        int numStates = DFA17_transitionS.length;
//        DFA17_transition = new short[numStates][];
//        for (int i=0; i<numStates; i++) {
//            DFA17_transition[i] = DFA.unpackEncodedString(DFA17_transitionS[i]);
//        }
//    }
//
//    class DFA17 extends DFA {
//
//        public DFA17(BaseRecognizer recognizer) {
//            this.recognizer = recognizer;
//            this.decisionNumber = 17;
//            this.eot = DFA17_eot;
//            this.eof = DFA17_eof;
//            this.min = DFA17_min;
//            this.max = DFA17_max;
//            this.accept = DFA17_accept;
//            this.special = DFA17_special;
//            this.transition = DFA17_transition;
//        }
//        public String getDescription() {
//            return "129:1: class_statement : ( variable_modifiers static_var_list ';' -> ^( FIELD_DECL variable_modifiers static_var_list ) | ( modifier )? method_declaration -> ^( METHOD_DECL ( modifier )? method_declaration ) | class_constant_declaration ';' -> ^( FIELD_DECL class_constant_declaration ) );";
//        }
//    }
//    static final String DFA44_eotS =
//        "\71\uffff";
//    static final String DFA44_eofS =
//        "\1\1\70\uffff";
//    static final String DFA44_minS =
//        "\1\44\55\uffff\1\0\12\uffff";
//    static final String DFA44_maxS =
//        "\1\u00b0\55\uffff\1\0\12\uffff";
//    static final String DFA44_acceptS =
//        "\1\uffff\1\2\66\uffff\1\1";
//    static final String DFA44_specialS =
//        "\56\uffff\1\0\12\uffff}>";
//    static final String[] DFA44_transitionS = {
//            "\7\1\20\uffff\3\1\1\uffff\2\1\2\uffff\22\1\1\uffff\4\1\5\uffff"+
//            "\1\1\1\56\1\1\1\uffff\4\1\1\uffff\4\1\42\uffff\2\1\12\uffff"+
//            "\2\1\1\uffff\5\1\1\uffff\4\1\1\uffff\1\1\2\uffff\6\1",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "\1\uffff",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            ""
//    };
//
//    static final short[] DFA44_eot = DFA.unpackEncodedString(DFA44_eotS);
//    static final short[] DFA44_eof = DFA.unpackEncodedString(DFA44_eofS);
//    static final char[] DFA44_min = DFA.unpackEncodedStringToUnsignedChars(DFA44_minS);
//    static final char[] DFA44_max = DFA.unpackEncodedStringToUnsignedChars(DFA44_maxS);
//    static final short[] DFA44_accept = DFA.unpackEncodedString(DFA44_acceptS);
//    static final short[] DFA44_special = DFA.unpackEncodedString(DFA44_specialS);
//    static final short[][] DFA44_transition;
//
//    static {
//        int numStates = DFA44_transitionS.length;
//        DFA44_transition = new short[numStates][];
//        for (int i=0; i<numStates; i++) {
//            DFA44_transition[i] = DFA.unpackEncodedString(DFA44_transitionS[i]);
//        }
//    }
//
//    class DFA44 extends DFA {
//
//        public DFA44(BaseRecognizer recognizer) {
//            this.recognizer = recognizer;
//            this.decisionNumber = 44;
//            this.eot = DFA44_eot;
//            this.eof = DFA44_eof;
//            this.min = DFA44_min;
//            this.max = DFA44_max;
//            this.accept = DFA44_accept;
//            this.special = DFA44_special;
//            this.transition = DFA44_transition;
//        }
//        public String getDescription() {
//            return "()* loopback of 230:20: ( options {k=1; backtrack=true; } : 'elseif' '(' eElseCond= expression ')' s2= statement )*";
//        }
//        public int specialStateTransition(int s, IntStream _input) throws NoViableAltException {
//            TokenStream input = (TokenStream)_input;
//        	int _s = s;
//            switch ( s ) {
//                    case 0 : 
//                        int LA44_46 = input.LA(1);
//
//                         
//                        int index44_46 = input.index();
//                        input.rewind();
//                        s = -1;
//                        if ( (synpred1_CompilerAst()) ) {s = 56;}
//
//                        else if ( (true) ) {s = 1;}
//
//                         
//                        input.seek(index44_46);
//                        if ( s>=0 ) return s;
//                        break;
//            }
//            if (state.backtracking>0) {state.failed=true; return -1;}
//            NoViableAltException nvae =
//                new NoViableAltException(getDescription(), 44, _s, input);
//            error(nvae);
//            throw nvae;
//        }
//    }
//    static final String DFA45_eotS =
//        "\71\uffff";
//    static final String DFA45_eofS =
//        "\1\2\70\uffff";
//    static final String DFA45_minS =
//        "\1\44\1\0\67\uffff";
//    static final String DFA45_maxS =
//        "\1\u00b0\1\0\67\uffff";
//    static final String DFA45_acceptS =
//        "\2\uffff\1\2\65\uffff\1\1";
//    static final String DFA45_specialS =
//        "\1\uffff\1\0\67\uffff}>";
//    static final String[] DFA45_transitionS = {
//            "\7\2\20\uffff\3\2\1\uffff\2\2\2\uffff\22\2\1\uffff\4\2\5\uffff"+
//            "\2\2\1\1\1\uffff\4\2\1\uffff\4\2\42\uffff\2\2\12\uffff\2\2\1"+
//            "\uffff\5\2\1\uffff\4\2\1\uffff\1\2\2\uffff\6\2",
//            "\1\uffff",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            ""
//    };
//
//    static final short[] DFA45_eot = DFA.unpackEncodedString(DFA45_eotS);
//    static final short[] DFA45_eof = DFA.unpackEncodedString(DFA45_eofS);
//    static final char[] DFA45_min = DFA.unpackEncodedStringToUnsignedChars(DFA45_minS);
//    static final char[] DFA45_max = DFA.unpackEncodedStringToUnsignedChars(DFA45_maxS);
//    static final short[] DFA45_accept = DFA.unpackEncodedString(DFA45_acceptS);
//    static final short[] DFA45_special = DFA.unpackEncodedString(DFA45_specialS);
//    static final short[][] DFA45_transition;
//
//    static {
//        int numStates = DFA45_transitionS.length;
//        DFA45_transition = new short[numStates][];
//        for (int i=0; i<numStates; i++) {
//            DFA45_transition[i] = DFA.unpackEncodedString(DFA45_transitionS[i]);
//        }
//    }
//
//    class DFA45 extends DFA {
//
//        public DFA45(BaseRecognizer recognizer) {
//            this.recognizer = recognizer;
//            this.decisionNumber = 45;
//            this.eot = DFA45_eot;
//            this.eof = DFA45_eof;
//            this.min = DFA45_min;
//            this.max = DFA45_max;
//            this.accept = DFA45_accept;
//            this.special = DFA45_special;
//            this.transition = DFA45_transition;
//        }
//        public String getDescription() {
//            return "231:8: ( options {k=1; backtrack=true; } : 'else' s3= statement )?";
//        }
//        public int specialStateTransition(int s, IntStream _input) throws NoViableAltException {
//            TokenStream input = (TokenStream)_input;
//        	int _s = s;
//            switch ( s ) {
//                    case 0 : 
//                        int LA45_1 = input.LA(1);
//
//                         
//                        int index45_1 = input.index();
//                        input.rewind();
//                        s = -1;
//                        if ( (synpred2_CompilerAst()) ) {s = 56;}
//
//                        else if ( (true) ) {s = 2;}
//
//                         
//                        input.seek(index45_1);
//                        if ( s>=0 ) return s;
//                        break;
//            }
//            if (state.backtracking>0) {state.failed=true; return -1;}
//            NoViableAltException nvae =
//                new NoViableAltException(getDescription(), 45, _s, input);
//            error(nvae);
//            throw nvae;
//        }
//    }
//    static final String DFA105_eotS =
//        "\15\uffff";
//    static final String DFA105_eofS =
//        "\15\uffff";
//    static final String DFA105_minS =
//        "\2\44\13\uffff";
//    static final String DFA105_maxS =
//        "\2\u00b0\13\uffff";
//    static final String DFA105_acceptS =
//        "\2\uffff\1\1\1\2\1\3\1\4\1\5\1\6\1\7\1\10\1\11\1\12\1\13";
//    static final String DFA105_specialS =
//        "\15\uffff}>";
//    static final String[] DFA105_transitionS = {
//            "\1\2\1\3\1\14\1\2\3\3\22\uffff\1\4\12\uffff\1\13\121\uffff\1"+
//            "\12\1\10\1\uffff\1\6\5\uffff\1\1\1\5\1\7\1\11\1\uffff\1\2\2"+
//            "\uffff\6\3",
//            "\1\2\1\3\1\uffff\1\2\3\3\175\uffff\1\2\2\uffff\6\3",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            "",
//            ""
//    };
//
//    static final short[] DFA105_eot = DFA.unpackEncodedString(DFA105_eotS);
//    static final short[] DFA105_eof = DFA.unpackEncodedString(DFA105_eofS);
//    static final char[] DFA105_min = DFA.unpackEncodedStringToUnsignedChars(DFA105_minS);
//    static final char[] DFA105_max = DFA.unpackEncodedStringToUnsignedChars(DFA105_maxS);
//    static final short[] DFA105_accept = DFA.unpackEncodedString(DFA105_acceptS);
//    static final short[] DFA105_special = DFA.unpackEncodedString(DFA105_specialS);
//    static final short[][] DFA105_transition;
//
//    static {
//        int numStates = DFA105_transitionS.length;
//        DFA105_transition = new short[numStates][];
//        for (int i=0; i<numStates; i++) {
//            DFA105_transition[i] = DFA.unpackEncodedString(DFA105_transitionS[i]);
//        }
//    }
//
//    class DFA105 extends DFA {
//
//        public DFA105(BaseRecognizer recognizer) {
//            this.recognizer = recognizer;
//            this.decisionNumber = 105;
//            this.eot = DFA105_eot;
//            this.eof = DFA105_eof;
//            this.min = DFA105_min;
//            this.max = DFA105_max;
//            this.accept = DFA105_accept;
//            this.special = DFA105_special;
//            this.transition = DFA105_transition;
//        }
//        public String getDescription() {
//            return "436:1: atom_expr : ( ( '@' )? variable | ( '@' )? constant | '(' expression ')' | 'list' '(' assignment_list ')' -> ^( 'list' assignment_list ) | 'array' '(' ( array_pair_list )? ')' -> ^( 'array' ( array_pair_list )? ) | 'new' class_name_reference -> ^( 'new' class_name_reference ) | 'clone' variable -> ^( 'clone' variable ) | 'exit' ( '(' ( expression )? ')' )? -> ^( 'exit' ( expression )? ) | 'unset' '(' variable_list ')' -> ^( 'unset' variable_list ) | lambda_function_declaration | backtrick_expr );";
//        }
//    }
//    static final String DFA121_eotS =
//        "\10\uffff";
//    static final String DFA121_eofS =
//        "\10\uffff";
//    static final String DFA121_minS =
//        "\1\44\1\uffff\1\75\1\uffff\1\44\2\uffff\1\75";
//    static final String DFA121_maxS =
//        "\1\u00a8\1\uffff\1\u00aa\1\uffff\1\u00aa\2\uffff\1\u00aa";
//    static final String DFA121_acceptS =
//        "\1\uffff\1\1\1\uffff\1\2\1\uffff\1\3\1\4\1\uffff";
//    static final String DFA121_specialS =
//        "\10\uffff}>";
//    static final String[] DFA121_transitionS = {
//            "\1\2\2\uffff\1\1\u0080\uffff\1\3",
//            "",
//            "\1\5\2\6\4\uffff\1\6\4\uffff\1\6\13\uffff\1\6\4\uffff\1\6\1"+
//            "\uffff\1\4\2\6\3\uffff\1\6\15\uffff\43\6\15\uffff\3\6\4\uffff"+
//            "\1\6\1\3\1\uffff\1\6",
//            "",
//            "\1\7\30\uffff\1\5\2\6\4\uffff\1\6\4\uffff\1\6\13\uffff\1\6"+
//            "\4\uffff\1\6\2\uffff\2\6\3\uffff\1\6\15\uffff\43\6\15\uffff"+
//            "\3\6\4\uffff\1\6\1\3\1\uffff\1\6",
//            "",
//            "",
//            "\1\5\2\6\4\uffff\1\6\4\uffff\1\6\13\uffff\1\6\4\uffff\1\6\1"+
//            "\uffff\1\4\2\6\3\uffff\1\6\15\uffff\43\6\15\uffff\3\6\4\uffff"+
//            "\1\6\1\3\1\uffff\1\6"
//    };
//
//    static final short[] DFA121_eot = DFA.unpackEncodedString(DFA121_eotS);
//    static final short[] DFA121_eof = DFA.unpackEncodedString(DFA121_eofS);
//    static final char[] DFA121_min = DFA.unpackEncodedStringToUnsignedChars(DFA121_minS);
//    static final char[] DFA121_max = DFA.unpackEncodedStringToUnsignedChars(DFA121_maxS);
//    static final short[] DFA121_accept = DFA.unpackEncodedString(DFA121_acceptS);
//    static final short[] DFA121_special = DFA.unpackEncodedString(DFA121_specialS);
//    static final short[][] DFA121_transition;
//
//    static {
//        int numStates = DFA121_transitionS.length;
//        DFA121_transition = new short[numStates][];
//        for (int i=0; i<numStates; i++) {
//            DFA121_transition[i] = DFA.unpackEncodedString(DFA121_transitionS[i]);
//        }
//    }
//
//    class DFA121 extends DFA {
//
//        public DFA121(BaseRecognizer recognizer) {
//            this.recognizer = recognizer;
//            this.decisionNumber = 121;
//            this.eot = DFA121_eot;
//            this.eof = DFA121_eof;
//            this.min = DFA121_min;
//            this.max = DFA121_max;
//            this.accept = DFA121_accept;
//            this.special = DFA121_special;
//            this.transition = DFA121_transition;
//        }
//        public String getDescription() {
//            return "489:1: base_variable_with_function_calls : ( STATIC '::' reference_variable -> ^( VAR_DECL ^( '::' STATIC reference_variable ) ) | ( fully_qualified_class_name )? '$' object_property ( ctor_arguments )? -> ^( VAR_DECL ( fully_qualified_class_name )? '$' object_property ( ctor_arguments )? ) | fully_qualified_class_name ctor_arguments -> ^( CALL fully_qualified_class_name ctor_arguments ) | fully_qualified_class_name );";
//        }
//    }
// 
//
//    public static final BitSet FOLLOW_57_in_php_source211 = new BitSet(new long[]{0xBC0007F000000000L,0x0000000083DFFFE9L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_58_in_php_source213 = new BitSet(new long[]{0xB80007F000000000L,0x0000000083DFFFE9L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_top_statement_list_in_php_source216 = new BitSet(new long[]{0x0800000000000000L});
//    public static final BitSet FOLLOW_59_in_php_source219 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_top_statement_in_top_statement_list242 = new BitSet(new long[]{0xB00007F000000002L,0x0000000083DFFFE9L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_statement_in_top_statement256 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_function_declaration_statement_in_top_statement262 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_class_declaration_statement_in_top_statement268 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_halt_compiler_statement_in_top_statement274 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_inner_statement_in_inner_statement_list290 = new BitSet(new long[]{0xB00007F000000002L,0x0000000083DFFFE9L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_statement_in_inner_statement307 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_function_declaration_statement_in_inner_statement313 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_class_declaration_statement_in_inner_statement319 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_halt_compiler_statement_in_inner_statement325 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_60_in_halt_compiler_statement340 = new BitSet(new long[]{0x2000000000000000L});
//    public static final BitSet FOLLOW_61_in_halt_compiler_statement342 = new BitSet(new long[]{0x4000000000000000L});
//    public static final BitSet FOLLOW_62_in_halt_compiler_statement344 = new BitSet(new long[]{0x8000000000000000L});
//    public static final BitSet FOLLOW_63_in_halt_compiler_statement346 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_class_entr_type_in_class_declaration_statement368 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000001L});
//    public static final BitSet FOLLOW_64_in_class_declaration_statement371 = new BitSet(new long[]{0x0000001000000000L});
//    public static final BitSet FOLLOW_IDENTIFIER_in_class_declaration_statement373 = new BitSet(new long[]{0x0000000000000000L,0x000000000000000EL});
//    public static final BitSet FOLLOW_65_in_class_declaration_statement376 = new BitSet(new long[]{0x0000001000000000L});
//    public static final BitSet FOLLOW_fully_qualified_class_name_in_class_declaration_statement378 = new BitSet(new long[]{0x0000000000000000L,0x000000000000000CL});
//    public static final BitSet FOLLOW_66_in_class_declaration_statement383 = new BitSet(new long[]{0x0000001000000000L});
//    public static final BitSet FOLLOW_fully_qualified_class_name_list_in_class_declaration_statement385 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000008L});
//    public static final BitSet FOLLOW_67_in_class_declaration_statement395 = new BitSet(new long[]{0x0000000000000000L,0x0000F000080401D0L});
//    public static final BitSet FOLLOW_class_statement_list_in_class_declaration_statement397 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000010L});
//    public static final BitSet FOLLOW_68_in_class_declaration_statement400 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_69_in_class_declaration_statement452 = new BitSet(new long[]{0x0000001000000000L});
//    public static final BitSet FOLLOW_IDENTIFIER_in_class_declaration_statement454 = new BitSet(new long[]{0x0000000000000000L,0x000000000000000EL});
//    public static final BitSet FOLLOW_65_in_class_declaration_statement457 = new BitSet(new long[]{0x0000001000000000L});
//    public static final BitSet FOLLOW_fully_qualified_class_name_list_in_class_declaration_statement459 = new BitSet(new long[]{0x0000000000000000L,0x000000000000000CL});
//    public static final BitSet FOLLOW_66_in_class_declaration_statement464 = new BitSet(new long[]{0x0000001000000000L});
//    public static final BitSet FOLLOW_fully_qualified_class_name_list_in_class_declaration_statement466 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000008L});
//    public static final BitSet FOLLOW_67_in_class_declaration_statement476 = new BitSet(new long[]{0x0000000000000000L,0x0000F000080401D0L});
//    public static final BitSet FOLLOW_class_statement_list_in_class_declaration_statement478 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000010L});
//    public static final BitSet FOLLOW_68_in_class_declaration_statement481 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_set_in_class_entr_type0 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_class_statement_in_class_statement_list553 = new BitSet(new long[]{0x0000000000000002L,0x0000F000080401C0L});
//    public static final BitSet FOLLOW_variable_modifiers_in_class_statement576 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000200L,0x0000010000000000L});
//    public static final BitSet FOLLOW_static_var_list_in_class_statement578 = new BitSet(new long[]{0x8000000000000000L});
//    public static final BitSet FOLLOW_63_in_class_statement580 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_modifier_in_class_statement597 = new BitSet(new long[]{0x0000000000000000L,0x0000F000000401C0L});
//    public static final BitSet FOLLOW_method_declaration_in_class_statement600 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_class_constant_declaration_in_class_statement620 = new BitSet(new long[]{0x8000000000000000L});
//    public static final BitSet FOLLOW_63_in_class_statement622 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_72_in_function_declaration_statement649 = new BitSet(new long[]{0x0000001000000000L,0x0000000000000200L});
//    public static final BitSet FOLLOW_73_in_function_declaration_statement651 = new BitSet(new long[]{0x0000001000000000L});
//    public static final BitSet FOLLOW_IDENTIFIER_in_function_declaration_statement654 = new BitSet(new long[]{0x2000000000000000L});
//    public static final BitSet FOLLOW_61_in_function_declaration_statement656 = new BitSet(new long[]{0x4000001000000000L,0x0000000008000200L,0x000001003FF80000L});
//    public static final BitSet FOLLOW_parameter_list_in_function_declaration_statement658 = new BitSet(new long[]{0x4000000000000000L});
//    public static final BitSet FOLLOW_62_in_function_declaration_statement661 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000008L});
//    public static final BitSet FOLLOW_block_in_function_declaration_statement666 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_67_in_block696 = new BitSet(new long[]{0xB00007F000000000L,0x0000000083DFFFF9L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_inner_statement_list_in_block698 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000010L});
//    public static final BitSet FOLLOW_68_in_block701 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_block_in_statement725 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_if_stat_in_statement731 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_74_in_statement737 = new BitSet(new long[]{0x2000000000000000L});
//    public static final BitSet FOLLOW_61_in_statement739 = new BitSet(new long[]{0x200007F000000000L,0x0000000000000300L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_expression_in_statement741 = new BitSet(new long[]{0x4000000000000000L});
//    public static final BitSet FOLLOW_62_in_statement743 = new BitSet(new long[]{0xA00007F000000000L,0x0000000483DFFF08L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_while_statement_in_statement745 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_75_in_statement766 = new BitSet(new long[]{0xA00007F000000000L,0x0000000083DFFF08L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_statement_in_statement768 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000400L});
//    public static final BitSet FOLLOW_74_in_statement770 = new BitSet(new long[]{0x2000000000000000L});
//    public static final BitSet FOLLOW_61_in_statement772 = new BitSet(new long[]{0x200007F000000000L,0x0000000000000300L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_expression_in_statement774 = new BitSet(new long[]{0x4000000000000000L});
//    public static final BitSet FOLLOW_62_in_statement776 = new BitSet(new long[]{0x8000000000000000L});
//    public static final BitSet FOLLOW_63_in_statement778 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_76_in_statement798 = new BitSet(new long[]{0x2000000000000000L});
//    public static final BitSet FOLLOW_61_in_statement800 = new BitSet(new long[]{0xA00007F000000000L,0x0000000000000300L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_expr_list_in_statement804 = new BitSet(new long[]{0x8000000000000000L});
//    public static final BitSet FOLLOW_63_in_statement807 = new BitSet(new long[]{0xA00007F000000000L,0x0000000000000300L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_expr_list_in_statement811 = new BitSet(new long[]{0x8000000000000000L});
//    public static final BitSet FOLLOW_63_in_statement814 = new BitSet(new long[]{0x600007F000000000L,0x0000000000000300L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_expr_list_in_statement818 = new BitSet(new long[]{0x4000000000000000L});
//    public static final BitSet FOLLOW_62_in_statement821 = new BitSet(new long[]{0x0000000000000002L,0x0000000400000000L});
//    public static final BitSet FOLLOW_for_statement_in_statement823 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_77_in_statement860 = new BitSet(new long[]{0x2000000000000000L});
//    public static final BitSet FOLLOW_61_in_statement862 = new BitSet(new long[]{0x200007F000000000L,0x0000000000000300L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_expression_in_statement864 = new BitSet(new long[]{0x4000000000000000L});
//    public static final BitSet FOLLOW_62_in_statement866 = new BitSet(new long[]{0x0000000000000000L,0x0000000400000008L});
//    public static final BitSet FOLLOW_switch_case_list_in_statement868 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_78_in_statement888 = new BitSet(new long[]{0xA00007F000000000L,0x0000000000000300L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_expression_in_statement890 = new BitSet(new long[]{0x8000000000000000L});
//    public static final BitSet FOLLOW_63_in_statement893 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_79_in_statement914 = new BitSet(new long[]{0xA00007F000000000L,0x0000000000000300L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_expression_in_statement916 = new BitSet(new long[]{0x8000000000000000L});
//    public static final BitSet FOLLOW_63_in_statement919 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_80_in_statement939 = new BitSet(new long[]{0xA00007F000000000L,0x0000000000000300L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_expression_in_statement941 = new BitSet(new long[]{0x8000000000000000L});
//    public static final BitSet FOLLOW_63_in_statement944 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_81_in_statement964 = new BitSet(new long[]{0x0000009000000000L,0x0000000000000000L,0x0000010800000000L});
//    public static final BitSet FOLLOW_variable_list_in_statement966 = new BitSet(new long[]{0x8000000000000000L});
//    public static final BitSet FOLLOW_63_in_statement968 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_82_in_statement987 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000200L,0x0000010000000000L});
//    public static final BitSet FOLLOW_static_var_list_in_statement989 = new BitSet(new long[]{0x8000000000000000L});
//    public static final BitSet FOLLOW_63_in_statement991 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_83_in_statement1009 = new BitSet(new long[]{0x200007F000000000L,0x0000000000000300L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_expr_list_in_statement1011 = new BitSet(new long[]{0x8000000000000000L});
//    public static final BitSet FOLLOW_63_in_statement1013 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_expression_in_statement1033 = new BitSet(new long[]{0x8000000000000000L});
//    public static final BitSet FOLLOW_63_in_statement1035 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_84_in_statement1042 = new BitSet(new long[]{0x2000000000000000L});
//    public static final BitSet FOLLOW_61_in_statement1044 = new BitSet(new long[]{0x200007F000000000L,0x0000000000000300L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_expression_in_statement1046 = new BitSet(new long[]{0x0000000000000000L,0x0000000000200000L});
//    public static final BitSet FOLLOW_85_in_statement1048 = new BitSet(new long[]{0x0000009000000000L,0x0000000000000000L,0x0000010800000000L});
//    public static final BitSet FOLLOW_foreach_variable_in_statement1050 = new BitSet(new long[]{0x4000000000000000L});
//    public static final BitSet FOLLOW_62_in_statement1052 = new BitSet(new long[]{0xA00007F000000000L,0x0000000483DFFF08L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_foreach_statement_in_statement1062 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_86_in_statement1089 = new BitSet(new long[]{0x2000000000000000L});
//    public static final BitSet FOLLOW_61_in_statement1091 = new BitSet(new long[]{0x0000001000000000L});
//    public static final BitSet FOLLOW_directive_in_statement1093 = new BitSet(new long[]{0x4000000000000000L});
//    public static final BitSet FOLLOW_62_in_statement1095 = new BitSet(new long[]{0xA00007F000000000L,0x0000000483DFFF08L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_declare_statement_in_statement1097 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_63_in_statement1118 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_87_in_statement1141 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000008L});
//    public static final BitSet FOLLOW_67_in_statement1143 = new BitSet(new long[]{0xB00007F000000000L,0x0000000083DFFFE9L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_top_statement_in_statement1145 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000010L});
//    public static final BitSet FOLLOW_68_in_statement1147 = new BitSet(new long[]{0x0000000000000000L,0x0000008000000000L});
//    public static final BitSet FOLLOW_catch_branch_in_statement1149 = new BitSet(new long[]{0x0000000000000002L,0x0000008000000000L});
//    public static final BitSet FOLLOW_88_in_statement1172 = new BitSet(new long[]{0x200007F000000000L,0x0000000000000300L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_expression_in_statement1174 = new BitSet(new long[]{0x8000000000000000L});
//    public static final BitSet FOLLOW_63_in_statement1176 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_89_in_statement1196 = new BitSet(new long[]{0x2000002000000000L});
//    public static final BitSet FOLLOW_use_filename_in_statement1198 = new BitSet(new long[]{0x8000000000000000L});
//    public static final BitSet FOLLOW_63_in_statement1200 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_variable_in_foreach_variable1234 = new BitSet(new long[]{0x0000000000000002L,0x0000000004000000L});
//    public static final BitSet FOLLOW_90_in_foreach_variable1244 = new BitSet(new long[]{0x0000009000000000L,0x0000000000000000L,0x0000010800000000L});
//    public static final BitSet FOLLOW_variable_in_foreach_variable1248 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_STRINGLITERAL_in_use_filename1275 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_61_in_use_filename1280 = new BitSet(new long[]{0x0000002000000000L});
//    public static final BitSet FOLLOW_STRINGLITERAL_in_use_filename1283 = new BitSet(new long[]{0x4000000000000000L});
//    public static final BitSet FOLLOW_62_in_use_filename1285 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_72_in_method_declaration1300 = new BitSet(new long[]{0x0000001000000000L,0x0000000000000200L});
//    public static final BitSet FOLLOW_73_in_method_declaration1302 = new BitSet(new long[]{0x0000001000000000L});
//    public static final BitSet FOLLOW_IDENTIFIER_in_method_declaration1305 = new BitSet(new long[]{0x2000000000000000L});
//    public static final BitSet FOLLOW_61_in_method_declaration1307 = new BitSet(new long[]{0x4000001000000000L,0x0000000008000200L,0x000001003FF80000L});
//    public static final BitSet FOLLOW_parameter_list_in_method_declaration1309 = new BitSet(new long[]{0x4000000000000000L});
//    public static final BitSet FOLLOW_62_in_method_declaration1312 = new BitSet(new long[]{0x8000000000000000L,0x0000000000000008L});
//    public static final BitSet FOLLOW_63_in_method_declaration1323 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_block_in_method_declaration1350 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_91_in_class_constant_declaration1391 = new BitSet(new long[]{0x0000001000000000L});
//    public static final BitSet FOLLOW_directive_in_class_constant_declaration1393 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_constant_in_static_scalar1421 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_IDENTIFIER_in_static_scalar1427 = new BitSet(new long[]{0x0000000000000002L,0x0000000010000000L});
//    public static final BitSet FOLLOW_92_in_static_scalar1430 = new BitSet(new long[]{0x0000001000000000L});
//    public static final BitSet FOLLOW_IDENTIFIER_in_static_scalar1432 = new BitSet(new long[]{0x0000000000000002L,0x0000000010000000L});
//    public static final BitSet FOLLOW_fully_qualified_class_name_in_fully_qualified_class_name_list1451 = new BitSet(new long[]{0x0000000000000002L,0x0000000020000000L});
//    public static final BitSet FOLLOW_93_in_fully_qualified_class_name_list1454 = new BitSet(new long[]{0x0000001000000000L});
//    public static final BitSet FOLLOW_fully_qualified_class_name_in_fully_qualified_class_name_list1456 = new BitSet(new long[]{0x0000000000000002L,0x0000000020000000L});
//    public static final BitSet FOLLOW_IDENTIFIER_in_fully_qualified_class_name1475 = new BitSet(new long[]{0x0000000000000002L,0x0000000010000000L});
//    public static final BitSet FOLLOW_92_in_fully_qualified_class_name1478 = new BitSet(new long[]{0x0000001000000000L});
//    public static final BitSet FOLLOW_IDENTIFIER_in_fully_qualified_class_name1481 = new BitSet(new long[]{0x0000000000000002L,0x0000000010000000L});
//    public static final BitSet FOLLOW_92_in_fully_qualified_class_name1485 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_static_scalar_element_in_static_array_pair_list1500 = new BitSet(new long[]{0x0000000000000002L,0x0000000020000000L});
//    public static final BitSet FOLLOW_93_in_static_array_pair_list1503 = new BitSet(new long[]{0x0000073000000000L,0x0000000000000000L,0x0001F80800000000L});
//    public static final BitSet FOLLOW_static_scalar_element_in_static_array_pair_list1505 = new BitSet(new long[]{0x0000000000000002L,0x0000000020000000L});
//    public static final BitSet FOLLOW_static_scalar_in_static_scalar_element1530 = new BitSet(new long[]{0x0000000000000002L,0x0000000004000000L});
//    public static final BitSet FOLLOW_90_in_static_scalar_element1533 = new BitSet(new long[]{0x0000073000000000L,0x0000000000000000L,0x0001F80800000000L});
//    public static final BitSet FOLLOW_static_scalar_in_static_scalar_element1536 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_static_var_element_in_static_var_list1552 = new BitSet(new long[]{0x0000000000000002L,0x0000000020000000L});
//    public static final BitSet FOLLOW_93_in_static_var_list1555 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000200L,0x0000010000000000L});
//    public static final BitSet FOLLOW_static_var_element_in_static_var_list1557 = new BitSet(new long[]{0x0000000000000002L,0x0000000020000000L});
//    public static final BitSet FOLLOW_pure_variable_in_static_var_element1579 = new BitSet(new long[]{0x0000000000000002L,0x0000000040000000L});
//    public static final BitSet FOLLOW_94_in_static_var_element1582 = new BitSet(new long[]{0x0000073000000000L,0x0000000000000000L,0x0001F80800000000L});
//    public static final BitSet FOLLOW_static_scalar_in_static_var_element1585 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_95_in_if_stat1601 = new BitSet(new long[]{0x2000000000000000L});
//    public static final BitSet FOLLOW_61_in_if_stat1603 = new BitSet(new long[]{0x200007F000000000L,0x0000000000000300L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_expression_in_if_stat1607 = new BitSet(new long[]{0x4000000000000000L});
//    public static final BitSet FOLLOW_62_in_if_stat1609 = new BitSet(new long[]{0xA00007F000000000L,0x0000000483DFFF08L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_statement_in_if_stat1625 = new BitSet(new long[]{0x0000000000000002L,0x0000000300000000L});
//    public static final BitSet FOLLOW_96_in_if_stat1641 = new BitSet(new long[]{0x2000000000000000L});
//    public static final BitSet FOLLOW_61_in_if_stat1643 = new BitSet(new long[]{0x200007F000000000L,0x0000000000000300L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_expression_in_if_stat1647 = new BitSet(new long[]{0x4000000000000000L});
//    public static final BitSet FOLLOW_62_in_if_stat1649 = new BitSet(new long[]{0xA00007F000000000L,0x0000000083DFFF08L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_statement_in_if_stat1653 = new BitSet(new long[]{0x0000000000000002L,0x0000000300000000L});
//    public static final BitSet FOLLOW_97_in_if_stat1678 = new BitSet(new long[]{0xA00007F000000000L,0x0000000083DFFF08L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_statement_in_if_stat1682 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_98_in_if_stat1740 = new BitSet(new long[]{0xB00007F000000000L,0x0000000B83DFFFE9L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_inner_statement_list_in_if_stat1742 = new BitSet(new long[]{0x0000000000000000L,0x0000000B00000000L});
//    public static final BitSet FOLLOW_new_elseif_branch_in_if_stat1745 = new BitSet(new long[]{0x0000000000000000L,0x0000000B00000000L});
//    public static final BitSet FOLLOW_97_in_if_stat1762 = new BitSet(new long[]{0x0000000000000000L,0x0000000400000000L});
//    public static final BitSet FOLLOW_98_in_if_stat1764 = new BitSet(new long[]{0xA00007F000000000L,0x0000000083DFFF08L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_statement_in_if_stat1768 = new BitSet(new long[]{0x0000000000000000L,0x0000000800000000L});
//    public static final BitSet FOLLOW_99_in_if_stat1772 = new BitSet(new long[]{0x8000000000000000L});
//    public static final BitSet FOLLOW_63_in_if_stat1774 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_96_in_new_elseif_branch1827 = new BitSet(new long[]{0x2000000000000000L});
//    public static final BitSet FOLLOW_61_in_new_elseif_branch1829 = new BitSet(new long[]{0x200007F000000000L,0x0000000000000300L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_expression_in_new_elseif_branch1831 = new BitSet(new long[]{0x4000000000000000L});
//    public static final BitSet FOLLOW_62_in_new_elseif_branch1833 = new BitSet(new long[]{0x0000000000000000L,0x0000000400000000L});
//    public static final BitSet FOLLOW_98_in_new_elseif_branch1835 = new BitSet(new long[]{0xB00007F000000002L,0x0000000083DFFFE9L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_inner_statement_list_in_new_elseif_branch1837 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_67_in_switch_case_list1867 = new BitSet(new long[]{0x8000000000000000L,0x0000006000000000L});
//    public static final BitSet FOLLOW_63_in_switch_case_list1869 = new BitSet(new long[]{0x8000000000000000L,0x0000006000000000L});
//    public static final BitSet FOLLOW_case_list_in_switch_case_list1872 = new BitSet(new long[]{0x8000000000000000L,0x0000006000000010L});
//    public static final BitSet FOLLOW_68_in_switch_case_list1875 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_98_in_switch_case_list1891 = new BitSet(new long[]{0x8000000000000000L,0x0000006000000000L});
//    public static final BitSet FOLLOW_63_in_switch_case_list1893 = new BitSet(new long[]{0x8000000000000000L,0x0000006000000000L});
//    public static final BitSet FOLLOW_case_list_in_switch_case_list1896 = new BitSet(new long[]{0x8000000000000000L,0x0000007000000000L});
//    public static final BitSet FOLLOW_100_in_switch_case_list1899 = new BitSet(new long[]{0x8000000000000000L});
//    public static final BitSet FOLLOW_63_in_switch_case_list1901 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_101_in_case_list1921 = new BitSet(new long[]{0x200007F000000000L,0x0000000000000300L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_expression_in_case_list1923 = new BitSet(new long[]{0x8000000000000000L,0x0000000400000000L});
//    public static final BitSet FOLLOW_98_in_case_list1926 = new BitSet(new long[]{0xB00007F000000002L,0x0000000083DFFFE9L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_63_in_case_list1930 = new BitSet(new long[]{0xB00007F000000002L,0x0000000083DFFFE9L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_inner_statement_list_in_case_list1933 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_102_in_case_list1952 = new BitSet(new long[]{0x8000000000000000L,0x0000000400000000L});
//    public static final BitSet FOLLOW_98_in_case_list1955 = new BitSet(new long[]{0xB00007F000000002L,0x0000000083DFFFE9L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_63_in_case_list1959 = new BitSet(new long[]{0xB00007F000000002L,0x0000000083DFFFE9L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_inner_statement_list_in_case_list1962 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_103_in_catch_branch1989 = new BitSet(new long[]{0x2000000000000000L});
//    public static final BitSet FOLLOW_61_in_catch_branch1991 = new BitSet(new long[]{0x0000001000000000L});
//    public static final BitSet FOLLOW_IDENTIFIER_in_catch_branch1993 = new BitSet(new long[]{0x0000009000000000L,0x0000000000000000L,0x0000010800000000L});
//    public static final BitSet FOLLOW_variable_in_catch_branch1995 = new BitSet(new long[]{0x4000000000000000L});
//    public static final BitSet FOLLOW_62_in_catch_branch1997 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000008L});
//    public static final BitSet FOLLOW_block_in_catch_branch2003 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_98_in_for_statement2031 = new BitSet(new long[]{0xB00007F000000000L,0x0000010083DFFFE9L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_inner_statement_list_in_for_statement2033 = new BitSet(new long[]{0x0000000000000000L,0x0000010000000000L});
//    public static final BitSet FOLLOW_104_in_for_statement2036 = new BitSet(new long[]{0x8000000000000000L});
//    public static final BitSet FOLLOW_63_in_for_statement2038 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_statement_in_while_statement2056 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_98_in_while_statement2073 = new BitSet(new long[]{0xB00007F000000000L,0x0000020083DFFFE9L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_inner_statement_list_in_while_statement2075 = new BitSet(new long[]{0x0000000000000000L,0x0000020000000000L});
//    public static final BitSet FOLLOW_105_in_while_statement2078 = new BitSet(new long[]{0x8000000000000000L});
//    public static final BitSet FOLLOW_63_in_while_statement2080 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_statement_in_foreach_statement2099 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_98_in_foreach_statement2117 = new BitSet(new long[]{0xB00007F000000000L,0x0000040083DFFFE9L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_inner_statement_list_in_foreach_statement2119 = new BitSet(new long[]{0x0000000000000000L,0x0000040000000000L});
//    public static final BitSet FOLLOW_106_in_foreach_statement2122 = new BitSet(new long[]{0x8000000000000000L});
//    public static final BitSet FOLLOW_63_in_foreach_statement2124 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_statement_in_declare_statement2144 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_98_in_declare_statement2162 = new BitSet(new long[]{0xB00007F000000000L,0x0000080083DFFFE9L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_inner_statement_list_in_declare_statement2164 = new BitSet(new long[]{0x0000000000000000L,0x0000080000000000L});
//    public static final BitSet FOLLOW_107_in_declare_statement2167 = new BitSet(new long[]{0x8000000000000000L});
//    public static final BitSet FOLLOW_63_in_declare_statement2169 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_parameter_in_parameter_list2189 = new BitSet(new long[]{0x0000000000000002L,0x0000000020000000L});
//    public static final BitSet FOLLOW_93_in_parameter_list2192 = new BitSet(new long[]{0x0000001000000000L,0x0000000008000200L,0x000001003FF80000L});
//    public static final BitSet FOLLOW_parameter_in_parameter_list2194 = new BitSet(new long[]{0x0000000000000002L,0x0000000020000000L});
//    public static final BitSet FOLLOW_parameter_type_in_parameter2220 = new BitSet(new long[]{0x0000000000000000L,0x0000000008000200L,0x0000010000000000L});
//    public static final BitSet FOLLOW_91_in_parameter2223 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000200L,0x0000010000000000L});
//    public static final BitSet FOLLOW_pure_variable_in_parameter2226 = new BitSet(new long[]{0x0000000000000002L,0x0000000040000000L});
//    public static final BitSet FOLLOW_94_in_parameter2242 = new BitSet(new long[]{0x0000073000000000L,0x0000000000000000L,0x0001F80800000000L});
//    public static final BitSet FOLLOW_static_scalar_in_parameter2244 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_fully_qualified_class_name_in_parameter_type2283 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_cast_option_in_parameter_type2287 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_variable_in_variable_list2300 = new BitSet(new long[]{0x0000000000000002L,0x0000000020000000L});
//    public static final BitSet FOLLOW_93_in_variable_list2303 = new BitSet(new long[]{0x0000009000000000L,0x0000000000000000L,0x0000010800000000L});
//    public static final BitSet FOLLOW_variable_in_variable_list2305 = new BitSet(new long[]{0x0000000000000002L,0x0000000020000000L});
//    public static final BitSet FOLLOW_108_in_variable_modifiers2327 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_modifier_in_variable_modifiers2333 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_set_in_modifier2347 = new BitSet(new long[]{0x0000000000000002L,0x0000E000000400C0L});
//    public static final BitSet FOLLOW_IDENTIFIER_in_directive2398 = new BitSet(new long[]{0x0000000000000000L,0x0000000040000000L});
//    public static final BitSet FOLLOW_94_in_directive2400 = new BitSet(new long[]{0x200007F000000000L,0x0000000000000300L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_expression_in_directive2402 = new BitSet(new long[]{0x0000000000000002L,0x0000000020000000L});
//    public static final BitSet FOLLOW_93_in_directive2405 = new BitSet(new long[]{0x0000001000000000L});
//    public static final BitSet FOLLOW_IDENTIFIER_in_directive2407 = new BitSet(new long[]{0x0000000000000000L,0x0000000040000000L});
//    public static final BitSet FOLLOW_94_in_directive2409 = new BitSet(new long[]{0x200007F000000000L,0x0000000000000300L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_expression_in_directive2411 = new BitSet(new long[]{0x0000000000000002L,0x0000000020000000L});
//    public static final BitSet FOLLOW_expression_in_expr_list2437 = new BitSet(new long[]{0x0000000000000002L,0x0000000020000000L});
//    public static final BitSet FOLLOW_93_in_expr_list2440 = new BitSet(new long[]{0x200007F000000000L,0x0000000000000300L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_expression_in_expr_list2442 = new BitSet(new long[]{0x0000000000000002L,0x0000000020000000L});
//    public static final BitSet FOLLOW_logical_text_or_expr_in_expression2465 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_logical_text_xor_expr_in_logical_text_or_expr2487 = new BitSet(new long[]{0x0000000000000002L,0x0001000000000000L});
//    public static final BitSet FOLLOW_112_in_logical_text_or_expr2490 = new BitSet(new long[]{0x200007F000000000L,0x0000000000000300L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_logical_text_xor_expr_in_logical_text_or_expr2493 = new BitSet(new long[]{0x0000000000000002L,0x0001000000000000L});
//    public static final BitSet FOLLOW_logical_text_and_expr_in_logical_text_xor_expr2508 = new BitSet(new long[]{0x0000000000000002L,0x0002000000000000L});
//    public static final BitSet FOLLOW_113_in_logical_text_xor_expr2511 = new BitSet(new long[]{0x200007F000000000L,0x0000000000000300L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_logical_text_and_expr_in_logical_text_xor_expr2514 = new BitSet(new long[]{0x0000000000000002L,0x0002000000000000L});
//    public static final BitSet FOLLOW_assignment_expr_in_logical_text_and_expr2529 = new BitSet(new long[]{0x0000000000000002L,0x0004000000000000L});
//    public static final BitSet FOLLOW_114_in_logical_text_and_expr2532 = new BitSet(new long[]{0x200007F000000000L,0x0000000000000300L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_assignment_expr_in_logical_text_and_expr2535 = new BitSet(new long[]{0x0000000000000002L,0x0004000000000000L});
//    public static final BitSet FOLLOW_conditional_expr_in_assignment_expr2550 = new BitSet(new long[]{0x0000000000000002L,0x3FF8000040000000L});
//    public static final BitSet FOLLOW_assignment_operator_in_assignment_expr2553 = new BitSet(new long[]{0x200007F000000000L,0x0000000000000300L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_conditional_expr_in_assignment_expr2556 = new BitSet(new long[]{0x0000000000000002L,0x3FF8000040000000L});
//    public static final BitSet FOLLOW_set_in_assignment_operator0 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_logical_or_expr_in_conditional_expr2679 = new BitSet(new long[]{0x0000000000000002L,0x4000000000000000L});
//    public static final BitSet FOLLOW_126_in_conditional_expr2691 = new BitSet(new long[]{0x200007F000000000L,0x0000000400000300L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_expression_in_conditional_expr2693 = new BitSet(new long[]{0x0000000000000000L,0x0000000400000000L});
//    public static final BitSet FOLLOW_98_in_conditional_expr2696 = new BitSet(new long[]{0x200007F000000000L,0x0000000000000300L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_logical_or_expr_in_conditional_expr2700 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_logical_and_expr_in_logical_or_expr2734 = new BitSet(new long[]{0x0000000000000002L,0x8000000000000000L});
//    public static final BitSet FOLLOW_127_in_logical_or_expr2737 = new BitSet(new long[]{0x200007F000000000L,0x0000000000000300L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_logical_and_expr_in_logical_or_expr2740 = new BitSet(new long[]{0x0000000000000002L,0x8000000000000000L});
//    public static final BitSet FOLLOW_bitwise_or_expr_in_logical_and_expr2755 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000000001L});
//    public static final BitSet FOLLOW_128_in_logical_and_expr2758 = new BitSet(new long[]{0x200007F000000000L,0x0000000000000300L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_bitwise_or_expr_in_logical_and_expr2761 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000000001L});
//    public static final BitSet FOLLOW_bitwise_xor_expr_in_bitwise_or_expr2776 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000000002L});
//    public static final BitSet FOLLOW_129_in_bitwise_or_expr2779 = new BitSet(new long[]{0x200007F000000000L,0x0000000000000300L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_bitwise_xor_expr_in_bitwise_or_expr2782 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000000002L});
//    public static final BitSet FOLLOW_bitwise_and_expr_in_bitwise_xor_expr2797 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000000004L});
//    public static final BitSet FOLLOW_130_in_bitwise_xor_expr2800 = new BitSet(new long[]{0x200007F000000000L,0x0000000000000300L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_bitwise_and_expr_in_bitwise_xor_expr2803 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000000004L});
//    public static final BitSet FOLLOW_concat_expr_in_bitwise_and_expr2818 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000000008L});
//    public static final BitSet FOLLOW_131_in_bitwise_and_expr2821 = new BitSet(new long[]{0x200007F000000000L,0x0000000000000300L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_concat_expr_in_bitwise_and_expr2824 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000000008L});
//    public static final BitSet FOLLOW_equality_expr_in_concat_expr2839 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000200L});
//    public static final BitSet FOLLOW_73_in_concat_expr2842 = new BitSet(new long[]{0x200007F000000000L,0x0000000000000300L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_equality_expr_in_concat_expr2845 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000200L});
//    public static final BitSet FOLLOW_relational_expr_in_equality_expr2860 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x00000000000000F0L});
//    public static final BitSet FOLLOW_set_in_equality_expr2863 = new BitSet(new long[]{0x200007F000000000L,0x0000000000000300L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_relational_expr_in_equality_expr2880 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x00000000000000F0L});
//    public static final BitSet FOLLOW_shift_expr_in_relational_expr2895 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000000F00L});
//    public static final BitSet FOLLOW_set_in_relational_expr2898 = new BitSet(new long[]{0x200007F000000000L,0x0000000000000300L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_shift_expr_in_relational_expr2915 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000000F00L});
//    public static final BitSet FOLLOW_additive_expr_in_shift_expr2930 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000003000L});
//    public static final BitSet FOLLOW_set_in_shift_expr2933 = new BitSet(new long[]{0x200007F000000000L,0x0000000000000300L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_additive_expr_in_shift_expr2942 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000003000L});
//    public static final BitSet FOLLOW_multiplicative_expr_in_additive_expr2957 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x000000000000C000L});
//    public static final BitSet FOLLOW_set_in_additive_expr2960 = new BitSet(new long[]{0x200007F000000000L,0x0000000000000300L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_multiplicative_expr_in_additive_expr2969 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x000000000000C000L});
//    public static final BitSet FOLLOW_cast_expr_in_multiplicative_expr2984 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000070000L});
//    public static final BitSet FOLLOW_set_in_multiplicative_expr2987 = new BitSet(new long[]{0x200007F000000000L,0x0000000000000300L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_cast_expr_in_multiplicative_expr3000 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000070000L});
//    public static final BitSet FOLLOW_61_in_cast_expr3016 = new BitSet(new long[]{0x0000001000000000L,0x0000000000000000L,0x000000003FF80000L});
//    public static final BitSet FOLLOW_cast_option_in_cast_expr3019 = new BitSet(new long[]{0x4000000000000000L});
//    public static final BitSet FOLLOW_62_in_cast_expr3022 = new BitSet(new long[]{0x200007F000000000L,0x0000000000000300L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_unary_expr_in_cast_expr3027 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_set_in_cast_option3040 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_set_in_unary_expr3122 = new BitSet(new long[]{0x200007F000000000L,0x0000000000000300L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_prefix_inc_dec_expr_in_unary_expr3145 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_set_in_prefix_inc_dec_expr3160 = new BitSet(new long[]{0x200007F000000000L,0x0000000000000300L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_post_inc_dec_expr_in_prefix_inc_dec_expr3171 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_instance_expr_in_post_inc_dec_expr3186 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000300000000L});
//    public static final BitSet FOLLOW_set_in_post_inc_dec_expr3189 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000300000000L});
//    public static final BitSet FOLLOW_atom_expr_in_instance_expr3211 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000400000000L});
//    public static final BitSet FOLLOW_162_in_instance_expr3214 = new BitSet(new long[]{0x0000009000000000L,0x0000000000000000L,0x0000010800000000L});
//    public static final BitSet FOLLOW_class_name_reference_in_instance_expr3217 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_163_in_atom_expr3235 = new BitSet(new long[]{0x0000009000000000L,0x0000000000000000L,0x0000010800000000L});
//    public static final BitSet FOLLOW_variable_in_atom_expr3238 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_163_in_atom_expr3245 = new BitSet(new long[]{0x0000072000000000L,0x0000000000000000L,0x0001F80800000000L});
//    public static final BitSet FOLLOW_constant_in_atom_expr3248 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_61_in_atom_expr3255 = new BitSet(new long[]{0x200007F000000000L,0x0000000000000300L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_expression_in_atom_expr3257 = new BitSet(new long[]{0x4000000000000000L});
//    public static final BitSet FOLLOW_62_in_atom_expr3259 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_164_in_atom_expr3266 = new BitSet(new long[]{0x2000000000000000L});
//    public static final BitSet FOLLOW_61_in_atom_expr3268 = new BitSet(new long[]{0x4000009000000000L,0x0000000020000000L,0x0000011800000000L});
//    public static final BitSet FOLLOW_assignment_list_in_atom_expr3270 = new BitSet(new long[]{0x4000000000000000L});
//    public static final BitSet FOLLOW_62_in_atom_expr3272 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_157_in_atom_expr3289 = new BitSet(new long[]{0x2000000000000000L});
//    public static final BitSet FOLLOW_61_in_atom_expr3291 = new BitSet(new long[]{0x600007F000000000L,0x0000000000000300L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_array_pair_list_in_atom_expr3293 = new BitSet(new long[]{0x4000000000000000L});
//    public static final BitSet FOLLOW_62_in_atom_expr3296 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_165_in_atom_expr3313 = new BitSet(new long[]{0x0000009000000000L,0x0000000000000000L,0x0000010800000000L});
//    public static final BitSet FOLLOW_class_name_reference_in_atom_expr3315 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_155_in_atom_expr3330 = new BitSet(new long[]{0x0000009000000000L,0x0000000000000000L,0x0000010800000000L});
//    public static final BitSet FOLLOW_variable_in_atom_expr3332 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_166_in_atom_expr3350 = new BitSet(new long[]{0x2000000000000002L});
//    public static final BitSet FOLLOW_61_in_atom_expr3353 = new BitSet(new long[]{0x600007F000000000L,0x0000000000000300L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_expression_in_atom_expr3355 = new BitSet(new long[]{0x4000000000000000L});
//    public static final BitSet FOLLOW_62_in_atom_expr3358 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_154_in_atom_expr3376 = new BitSet(new long[]{0x2000000000000000L});
//    public static final BitSet FOLLOW_61_in_atom_expr3378 = new BitSet(new long[]{0x0000009000000000L,0x0000000000000000L,0x0000010800000000L});
//    public static final BitSet FOLLOW_variable_list_in_atom_expr3380 = new BitSet(new long[]{0x4000000000000000L});
//    public static final BitSet FOLLOW_62_in_atom_expr3382 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_lambda_function_declaration_in_atom_expr3397 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_backtrick_expr_in_atom_expr3404 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_72_in_lambda_function_declaration3418 = new BitSet(new long[]{0x2000000000000000L,0x0000000000000200L});
//    public static final BitSet FOLLOW_73_in_lambda_function_declaration3420 = new BitSet(new long[]{0x2000000000000000L});
//    public static final BitSet FOLLOW_61_in_lambda_function_declaration3423 = new BitSet(new long[]{0x4000001000000000L,0x0000000008000200L,0x000001003FF80000L});
//    public static final BitSet FOLLOW_parameter_list_in_lambda_function_declaration3425 = new BitSet(new long[]{0x4000000000000000L});
//    public static final BitSet FOLLOW_62_in_lambda_function_declaration3428 = new BitSet(new long[]{0x0000000000000000L,0x0000000002000008L});
//    public static final BitSet FOLLOW_89_in_lambda_function_declaration3431 = new BitSet(new long[]{0x2000000000000000L});
//    public static final BitSet FOLLOW_61_in_lambda_function_declaration3433 = new BitSet(new long[]{0x600007F000000000L,0x0000000000000300L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_expr_list_in_lambda_function_declaration3435 = new BitSet(new long[]{0x4000000000000000L});
//    public static final BitSet FOLLOW_62_in_lambda_function_declaration3438 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000008L});
//    public static final BitSet FOLLOW_block_in_lambda_function_declaration3444 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_BACKTRICKLITERAL_in_backtrick_expr3481 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_variable_in_class_name_reference3497 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_assignment_element_in_assignment_list3514 = new BitSet(new long[]{0x0000000000000002L,0x0000000020000000L});
//    public static final BitSet FOLLOW_93_in_assignment_list3518 = new BitSet(new long[]{0x0000009000000002L,0x0000000020000000L,0x0000011800000000L});
//    public static final BitSet FOLLOW_assignment_element_in_assignment_list3520 = new BitSet(new long[]{0x0000000000000002L,0x0000000020000000L});
//    public static final BitSet FOLLOW_variable_in_assignment_element3537 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_164_in_assignment_element3543 = new BitSet(new long[]{0x2000000000000000L});
//    public static final BitSet FOLLOW_61_in_assignment_element3545 = new BitSet(new long[]{0x4000009000000000L,0x0000000020000000L,0x0000011800000000L});
//    public static final BitSet FOLLOW_assignment_list_in_assignment_element3547 = new BitSet(new long[]{0x4000000000000000L});
//    public static final BitSet FOLLOW_62_in_assignment_element3549 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_array_pair_element_in_array_pair_list3572 = new BitSet(new long[]{0x0000000000000002L,0x0000000020000000L});
//    public static final BitSet FOLLOW_93_in_array_pair_list3575 = new BitSet(new long[]{0x200007F000000000L,0x0000000000000300L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_array_pair_element_in_array_pair_list3577 = new BitSet(new long[]{0x0000000000000002L,0x0000000020000000L});
//    public static final BitSet FOLLOW_93_in_array_pair_list3581 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_expression_in_array_pair_element3603 = new BitSet(new long[]{0x0000000000000002L,0x0000000004000000L});
//    public static final BitSet FOLLOW_90_in_array_pair_element3606 = new BitSet(new long[]{0x200007F000000000L,0x0000000000000300L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_expression_in_array_pair_element3609 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_base_variable_with_function_calls_in_variable3629 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000008000000000L});
//    public static final BitSet FOLLOW_167_in_variable3640 = new BitSet(new long[]{0x0000001000000000L,0x0000000000000008L,0x0000010000000000L});
//    public static final BitSet FOLLOW_object_property_in_variable3642 = new BitSet(new long[]{0x2000000000000002L,0x0000000000000000L,0x0000008000000000L});
//    public static final BitSet FOLLOW_ctor_arguments_in_variable3644 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000008000000000L});
//    public static final BitSet FOLLOW_STATIC_in_base_variable_with_function_calls3683 = new BitSet(new long[]{0x0000000000000000L,0x0000000010000000L});
//    public static final BitSet FOLLOW_92_in_base_variable_with_function_calls3685 = new BitSet(new long[]{0x0000001000000000L,0x0000000000000008L,0x0000010000000000L});
//    public static final BitSet FOLLOW_reference_variable_in_base_variable_with_function_calls3687 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_fully_qualified_class_name_in_base_variable_with_function_calls3710 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000010000000000L});
//    public static final BitSet FOLLOW_168_in_base_variable_with_function_calls3713 = new BitSet(new long[]{0x0000001000000000L,0x0000000000000008L,0x0000010000000000L});
//    public static final BitSet FOLLOW_object_property_in_base_variable_with_function_calls3715 = new BitSet(new long[]{0x2000000000000002L});
//    public static final BitSet FOLLOW_ctor_arguments_in_base_variable_with_function_calls3717 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_fully_qualified_class_name_in_base_variable_with_function_calls3741 = new BitSet(new long[]{0x2000000000000000L});
//    public static final BitSet FOLLOW_ctor_arguments_in_base_variable_with_function_calls3743 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_fully_qualified_class_name_in_base_variable_with_function_calls3760 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_168_in_object_property3775 = new BitSet(new long[]{0x0000001000000000L,0x0000000000000008L,0x0000010000000000L});
//    public static final BitSet FOLLOW_reference_variable_in_object_property3778 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_compound_variable_in_reference_variable3798 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000008L,0x0000020000000000L});
//    public static final BitSet FOLLOW_169_in_reference_variable3814 = new BitSet(new long[]{0x200007F000000000L,0x0000000000000300L,0x0001FD7BEC00C000L});
//    public static final BitSet FOLLOW_expression_in_reference_variable3816 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000040000000000L});
//    public static final BitSet FOLLOW_170_in_reference_variable3819 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000008L,0x0000020000000000L});
//    public static final BitSet FOLLOW_67_in_reference_variable3840 = new BitSet(new long[]{0x200007F000000000L,0x0000000000000300L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_expression_in_reference_variable3842 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000010L});
//    public static final BitSet FOLLOW_68_in_reference_variable3844 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000008L,0x0000020000000000L});
//    public static final BitSet FOLLOW_IDENTIFIER_in_compound_variable3880 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_67_in_compound_variable3886 = new BitSet(new long[]{0x200007F000000000L,0x0000000000000300L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_expression_in_compound_variable3889 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000010L});
//    public static final BitSet FOLLOW_68_in_compound_variable3891 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_61_in_ctor_arguments3909 = new BitSet(new long[]{0x600007F000000000L,0x0000000000000300L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_expr_list_in_ctor_arguments3911 = new BitSet(new long[]{0x4000000000000000L});
//    public static final BitSet FOLLOW_62_in_ctor_arguments3914 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_73_in_pure_variable3938 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000010000000000L});
//    public static final BitSet FOLLOW_168_in_pure_variable3941 = new BitSet(new long[]{0x0000001000000000L,0x0000000000000000L,0x0000010000000000L});
//    public static final BitSet FOLLOW_IDENTIFIER_in_pure_variable3944 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_INTLITERAL_in_constant3978 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_FLOATLITERAL_in_constant3986 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_STRINGLITERAL_in_constant3994 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_DOUBLELITERRAL_in_constant4002 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_common_scalar_in_constant4010 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_set_in_common_scalar0 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_96_in_synpred1_CompilerAst1641 = new BitSet(new long[]{0x2000000000000000L});
//    public static final BitSet FOLLOW_61_in_synpred1_CompilerAst1643 = new BitSet(new long[]{0x200007F000000000L,0x0000000000000300L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_expression_in_synpred1_CompilerAst1647 = new BitSet(new long[]{0x4000000000000000L});
//    public static final BitSet FOLLOW_62_in_synpred1_CompilerAst1649 = new BitSet(new long[]{0xA00007F000000000L,0x0000000083DFFF08L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_statement_in_synpred1_CompilerAst1653 = new BitSet(new long[]{0x0000000000000002L});
//    public static final BitSet FOLLOW_97_in_synpred2_CompilerAst1678 = new BitSet(new long[]{0xA00007F000000000L,0x0000000083DFFF08L,0x0001F97BEC00C000L});
//    public static final BitSet FOLLOW_statement_in_synpred2_CompilerAst1682 = new BitSet(new long[]{0x0000000000000002L});
//
//	@Override
//	protected String getTokenName(int token) {
//		// TODO Auto-generated method stub
//		return null;
//	}

}