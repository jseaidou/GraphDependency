// $ANTLR 3.1.3 Mar 17, 2009 19:23:44 /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g 2009-07-31 17:12:02

  package org.eclipse.php.internal.core.compiler.ast.parser.php5;
  
  import org.eclipse.dltk.ast.*;
import org.eclipse.dltk.ast.declarations.*;
import org.eclipse.dltk.ast.expressions.*;
import org.eclipse.dltk.ast.references.*;
import org.eclipse.dltk.ast.statements.*;
import org.eclipse.php.internal.core.compiler.ast.nodes.*;
import org.eclipse.php.internal.core.compiler.ast.parser.*;
import java.util.*;
import org.antlr.runtime.BitSet;


import org.antlr.runtime.*;
import org.antlr.runtime.tree.*;import java.util.Stack;
import java.util.List;
import java.util.ArrayList;


public class TreePHP extends TreeParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "ModuleDeclaration", "ClassDeclaration", "PROG", "CLASS_BODY", "FIELD_DECL", "METHOD_DECL", "TYPE", "PARAMETER", "BLOCK", "VAR_DECL", "STATEMENT", "CONDITION", "LIST", "INDEX", "MEMBERACCESS", "CALL", "ELIST", "EXPR", "ASSIGN", "LIST_DECL", "SCALAR_ELEMENT", "SCALAR_VAR", "CAST", "LABEL", "ITERATE", "USE_DECL", "ARGU", "CALLED_OBJ", "PREFIX", "POSTFIX", "NAMESPACE", "EMPTYSTATEMENT", "SCALAR", "ARRAY_DECL", "SOC_T", "SOC_PHP_T", "EOC_T", "LEFT_PARETHESIS", "RIGHT_PARETHESIS", "CLASS_T", "IDENTIFIER", "LEFT_BRACKET", "RIGHT_BRACKET", "STRINGLITERAL", "EQ", "PLUS_EQ", "MINUS_EQ", "MUL_EQ", "DIV_EQ", "DOT_EQ", "PERCENT_EQ", "BIT_AND_EQ", "BIT_OR_EQ", "POWER_EQ", "LMOVE_EQ", "RMOVE_EQ", "BIT_AND", "BACKTRICKLITERAL", "DOLLAR_T", "INTLITERAL", "FLOATLITERAL", "DOUBLELITERRAL", "IntegerNumber", "LongSuffix", "HexPrefix", "HexDigit", "STATIC", "NonIntegerNumber", "FloatSuffix", "DoubleSuffix", "Exponent", "EscapeSequence", "IdentifierStart", "IdentifierPart", "WS", "COMMENT", "LINE_COMMENT", "'__halt_compiler'", "';'", "'extends'", "'implements'", "'interface'", "'abstract'", "'final'", "'function'", "'while'", "'do'", "'for'", "'switch'", "'break'", "'continue'", "'return'", "'global'", "'static'", "'echo'", "'foreach'", "'as'", "'declare'", "'try'", "'throw'", "'use'", "'=>'", "'const'", "','", "'::'", "'if'", "'elseif'", "'else'", "':'", "'endif'", "'endswitch'", "'case'", "'default'", "'catch'", "'endfor'", "'endwhile'", "'endforeach'", "'enddeclare'", "'var'", "'public'", "'protected'", "'private'", "'OR'", "'XOR'", "'AND'", "'?'", "'||'", "'&&'", "'|'", "'^'", "'.'", "'=='", "'!='", "'==='", "'!=='", "'<'", "'>'", "'<='", "'>='", "'<<'", "'>>'", "'+'", "'-'", "'*'", "'/'", "'%'", "'bool'", "'boolean'", "'int'", "'float'", "'double'", "'real'", "'string'", "'unset'", "'clone'", "'object'", "'array'", "'~'", "'!'", "'++'", "'--'", "'instanceof'", "'@'", "'list'", "'new'", "'exit'", "'->'", "'['", "']'", "'__CLASS__'", "'__DIR__'", "'__FILE__'", "'__FUNCTION__'", "'__METHOD__'", "'__NAMESPACE__'"
    };
    public static final int CAST=26;
    public static final int PREFIX=32;
    public static final int T__159=159;
    public static final int POSTFIX=33;
    public static final int T__158=158;
    public static final int PERCENT_EQ=54;
    public static final int T__160=160;
    public static final int VAR_DECL=13;
    public static final int CONDITION=15;
    public static final int T__167=167;
    public static final int EOF=-1;
    public static final int T__168=168;
    public static final int T__165=165;
    public static final int T__166=166;
    public static final int STATEMENT=14;
    public static final int T__163=163;
    public static final int T__164=164;
    public static final int T__161=161;
    public static final int TYPE=10;
    public static final int T__162=162;
    public static final int T__93=93;
    public static final int T__94=94;
    public static final int T__91=91;
    public static final int CALLED_OBJ=31;
    public static final int T__92=92;
    public static final int EOC_T=40;
    public static final int T__148=148;
    public static final int T__147=147;
    public static final int T__90=90;
    public static final int T__149=149;
    public static final int DIV_EQ=52;
    public static final int ELIST=20;
    public static final int NonIntegerNumber=71;
    public static final int FloatSuffix=72;
    public static final int PARAMETER=11;
    public static final int SCALAR=36;
    public static final int RIGHT_BRACKET=46;
    public static final int ARGU=30;
    public static final int EQ=48;
    public static final int T__154=154;
    public static final int COMMENT=79;
    public static final int T__155=155;
    public static final int T__156=156;
    public static final int T__99=99;
    public static final int T__157=157;
    public static final int T__98=98;
    public static final int T__150=150;
    public static final int T__97=97;
    public static final int T__151=151;
    public static final int T__96=96;
    public static final int T__152=152;
    public static final int HexPrefix=68;
    public static final int T__95=95;
    public static final int T__153=153;
    public static final int T__139=139;
    public static final int T__138=138;
    public static final int T__137=137;
    public static final int T__136=136;
    public static final int T__81=81;
    public static final int T__82=82;
    public static final int RMOVE_EQ=59;
    public static final int T__83=83;
    public static final int LINE_COMMENT=80;
    public static final int STATIC=70;
    public static final int ARRAY_DECL=37;
    public static final int MUL_EQ=51;
    public static final int IdentifierStart=76;
    public static final int INTLITERAL=63;
    public static final int T__85=85;
    public static final int T__141=141;
    public static final int PLUS_EQ=49;
    public static final int LIST=16;
    public static final int T__84=84;
    public static final int T__142=142;
    public static final int T__87=87;
    public static final int T__86=86;
    public static final int T__140=140;
    public static final int T__89=89;
    public static final int T__145=145;
    public static final int NAMESPACE=34;
    public static final int T__88=88;
    public static final int T__146=146;
    public static final int MINUS_EQ=50;
    public static final int T__143=143;
    public static final int LongSuffix=67;
    public static final int T__144=144;
    public static final int T__126=126;
    public static final int T__125=125;
    public static final int T__128=128;
    public static final int T__127=127;
    public static final int EMPTYSTATEMENT=35;
    public static final int WS=78;
    public static final int T__129=129;
    public static final int SOC_PHP_T=39;
    public static final int MEMBERACCESS=18;
    public static final int CALL=19;
    public static final int SCALAR_ELEMENT=24;
    public static final int POWER_EQ=57;
    public static final int T__130=130;
    public static final int T__131=131;
    public static final int BIT_AND_EQ=55;
    public static final int EscapeSequence=75;
    public static final int T__132=132;
    public static final int T__133=133;
    public static final int T__134=134;
    public static final int T__135=135;
    public static final int BIT_AND=60;
    public static final int CLASS_T=43;
    public static final int IntegerNumber=66;
    public static final int T__118=118;
    public static final int T__119=119;
    public static final int T__116=116;
    public static final int T__117=117;
    public static final int LEFT_BRACKET=45;
    public static final int DOLLAR_T=62;
    public static final int T__114=114;
    public static final int T__115=115;
    public static final int DOUBLELITERRAL=65;
    public static final int T__124=124;
    public static final int T__123=123;
    public static final int T__122=122;
    public static final int METHOD_DECL=9;
    public static final int SOC_T=38;
    public static final int Exponent=74;
    public static final int T__121=121;
    public static final int T__120=120;
    public static final int HexDigit=69;
    public static final int INDEX=17;
    public static final int PROG=6;
    public static final int EXPR=21;
    public static final int USE_DECL=29;
    public static final int T__107=107;
    public static final int T__108=108;
    public static final int T__109=109;
    public static final int IDENTIFIER=44;
    public static final int T__103=103;
    public static final int T__104=104;
    public static final int T__105=105;
    public static final int T__106=106;
    public static final int T__111=111;
    public static final int T__110=110;
    public static final int T__113=113;
    public static final int T__112=112;
    public static final int LMOVE_EQ=58;
    public static final int SCALAR_VAR=25;
    public static final int IdentifierPart=77;
    public static final int BIT_OR_EQ=56;
    public static final int FIELD_DECL=8;
    public static final int T__102=102;
    public static final int T__101=101;
    public static final int T__100=100;
    public static final int CLASS_BODY=7;
    public static final int ModuleDeclaration=4;
    public static final int LIST_DECL=23;
    public static final int T__175=175;
    public static final int BACKTRICKLITERAL=61;
    public static final int T__174=174;
    public static final int T__173=173;
    public static final int ITERATE=28;
    public static final int T__172=172;
    public static final int LEFT_PARETHESIS=41;
    public static final int T__178=178;
    public static final int T__177=177;
    public static final int T__176=176;
    public static final int DoubleSuffix=73;
    public static final int LABEL=27;
    public static final int STRINGLITERAL=47;
    public static final int T__171=171;
    public static final int T__170=170;
    public static final int BLOCK=12;
    public static final int ASSIGN=22;
    public static final int RIGHT_PARETHESIS=42;
    public static final int DOT_EQ=53;
    public static final int T__169=169;
    public static final int ClassDeclaration=5;
    public static final int FLOATLITERAL=64;

    // delegates
    // delegators


        public TreePHP(TreeNodeStream input) {
            this(input, new RecognizerSharedState());
        }
        public TreePHP(TreeNodeStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        
    protected TreeAdaptor adaptor = new CommonTreeAdaptor();

    public void setTreeAdaptor(TreeAdaptor adaptor) {
        this.adaptor = adaptor;
    }
    public TreeAdaptor getTreeAdaptor() {
        return adaptor;
    }

    public String[] getTokenNames() { return TreePHP.tokenNames; }
    public String getGrammarFileName() { return "/home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g"; }


      ModuleDeclaration program;
      
      AbstractASTParser parser;
        
      public TreePHP(TreeNodeStream input, AbstractASTParser parser) {
         this(input, new RecognizerSharedState());
         this.parser = parser;
      }
       
      public ModuleDeclaration getModuleDeclaration() {
        return program;
      }
      
      class ModifierDocPair {
        public int modifier;
        public PHPDocBlock doc;
        
        public ModifierDocPair(int modifier, PHPDocBlock doc) {
          this.modifier = modifier;
          this.doc = doc;
        }
      }
      
      public Expression createDispatch(Expression dispatcher, Expression property) {

        if (property.getKind() == ASTNodeKinds.REFLECTION_CALL_EXPRESSION) {
          ((ReflectionCallExpression) property).setReceiver (dispatcher);
          dispatcher = property;
        } else if (property.getKind() == ASTNodeKinds.METHOD_INVOCATION) {
          PHPCallExpression callExpression = (PHPCallExpression) property;
          dispatcher = new PHPCallExpression(dispatcher.sourceStart(), callExpression.sourceEnd(), dispatcher, callExpression.getCallName(), callExpression.getArgs());
        } else {
          dispatcher =  new FieldAccess(dispatcher.sourceStart(), property.sourceEnd(), dispatcher, property);
        }

        return dispatcher;
      }


    public static class php_source_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "php_source"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:67:1: php_source : ^( ModuleDeclaration ( top_statement_list )? ) ;
    public final TreePHP.php_source_return php_source() throws RecognitionException {
        TreePHP.php_source_return retval = new TreePHP.php_source_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST ModuleDeclaration1=null;
        TreePHP.top_statement_list_return top_statement_list2 = null;


        SLAST ModuleDeclaration1_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:68:3: ( ^( ModuleDeclaration ( top_statement_list )? ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:68:6: ^( ModuleDeclaration ( top_statement_list )? )
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_1 = _last;
            SLAST _first_1 = null;
            SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            ModuleDeclaration1=(SLAST)match(input,ModuleDeclaration,FOLLOW_ModuleDeclaration_in_php_source58); 
            ModuleDeclaration1_tree = (SLAST)adaptor.dupNode(ModuleDeclaration1);

            root_1 = (SLAST)adaptor.becomeRoot(ModuleDeclaration1_tree, root_1);



            if ( input.LA(1)==Token.DOWN ) {
                match(input, Token.DOWN, null); 
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:68:26: ( top_statement_list )?
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( (LA1_0==STATEMENT||LA1_0==CLASS_T||LA1_0==81||LA1_0==85||LA1_0==88) ) {
                    alt1=1;
                }
                switch (alt1) {
                    case 1 :
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:68:26: top_statement_list
                        {
                        _last = (SLAST)input.LT(1);
                        pushFollow(FOLLOW_top_statement_list_in_php_source60);
                        top_statement_list2=top_statement_list();

                        state._fsp--;

                        adaptor.addChild(root_1, top_statement_list2.getTree());

                        }
                        break;

                }


                match(input, Token.UP, null); 
            }adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


                ModuleDeclaration RESULT = null;
                int startIndex = ModuleDeclaration1.startIndex;
                int endIndex = ModuleDeclaration1.endIndex;
             
                PHPModuleDeclaration program = parser.getModuleDeclaration();
            	  program.setStart(startIndex);
            	  program.setEnd(endIndex);
            	  RESULT = program;
            	  
            	  System.out.println("module: \n" + RESULT);
              

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "php_source"

    public static class top_statement_list_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "top_statement_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:83:1: top_statement_list : ( top_statement )+ ;
    public final TreePHP.top_statement_list_return top_statement_list() throws RecognitionException {
        TreePHP.top_statement_list_return retval = new TreePHP.top_statement_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.top_statement_return top_statement3 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:84:3: ( ( top_statement )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:84:5: ( top_statement )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:84:5: ( top_statement )+
            int cnt2=0;
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( (LA2_0==STATEMENT||LA2_0==CLASS_T||LA2_0==81||LA2_0==85||LA2_0==88) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:84:5: top_statement
            	    {
            	    _last = (SLAST)input.LT(1);
            	    pushFollow(FOLLOW_top_statement_in_top_statement_list79);
            	    top_statement3=top_statement();

            	    state._fsp--;

            	    adaptor.addChild(root_0, top_statement3.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt2 >= 1 ) break loop2;
                        EarlyExitException eee =
                            new EarlyExitException(2, input);
                        throw eee;
                }
                cnt2++;
            } while (true);


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "top_statement_list"

    public static class top_statement_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "top_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:87:1: top_statement : ( statement | function_declaration_statement | class_declaration_statement | halt_compiler_statement );
    public final TreePHP.top_statement_return top_statement() throws RecognitionException {
        TreePHP.top_statement_return retval = new TreePHP.top_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.statement_return statement4 = null;

        TreePHP.function_declaration_statement_return function_declaration_statement5 = null;

        TreePHP.class_declaration_statement_return class_declaration_statement6 = null;

        TreePHP.halt_compiler_statement_return halt_compiler_statement7 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:88:3: ( statement | function_declaration_statement | class_declaration_statement | halt_compiler_statement )
            int alt3=4;
            switch ( input.LA(1) ) {
            case STATEMENT:
                {
                alt3=1;
                }
                break;
            case 88:
                {
                alt3=2;
                }
                break;
            case CLASS_T:
            case 85:
                {
                alt3=3;
                }
                break;
            case 81:
                {
                alt3=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 3, 0, input);

                throw nvae;
            }

            switch (alt3) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:88:5: statement
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_statement_in_top_statement93);
                    statement4=statement();

                    state._fsp--;

                    adaptor.addChild(root_0, statement4.getTree());

                        Statement stat = (statement4!=null?statement4.exprStat:null);
                        System.out.println("statement:" + stat);
                        parser.addStatement(stat);
                      

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:94:5: function_declaration_statement
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_function_declaration_statement_in_top_statement103);
                    function_declaration_statement5=function_declaration_statement();

                    state._fsp--;

                    adaptor.addChild(root_0, function_declaration_statement5.getTree());

                    }
                    break;
                case 3 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:95:5: class_declaration_statement
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_class_declaration_statement_in_top_statement109);
                    class_declaration_statement6=class_declaration_statement();

                    state._fsp--;

                    adaptor.addChild(root_0, class_declaration_statement6.getTree());

                        ClassDeclaration classDeclaration = (class_declaration_statement6!=null?class_declaration_statement6.classDeclaration:null);
                        System.out.println("decl: " + classDeclaration);
                        parser.addDeclarationStatement(classDeclaration);
                        parser.declarations.push(classDeclaration);
                        parser.addStatement(classDeclaration);
                      

                    }
                    break;
                case 4 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:103:5: halt_compiler_statement
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_halt_compiler_statement_in_top_statement119);
                    halt_compiler_statement7=halt_compiler_statement();

                    state._fsp--;

                    adaptor.addChild(root_0, halt_compiler_statement7.getTree());

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "top_statement"

    public static class inner_statement_list_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "inner_statement_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:106:1: inner_statement_list : ( inner_statement )+ ;
    public final TreePHP.inner_statement_list_return inner_statement_list() throws RecognitionException {
        TreePHP.inner_statement_list_return retval = new TreePHP.inner_statement_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.inner_statement_return inner_statement8 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:107:3: ( ( inner_statement )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:107:5: ( inner_statement )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:107:5: ( inner_statement )+
            int cnt4=0;
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( (LA4_0==STATEMENT||LA4_0==CLASS_T||LA4_0==81||LA4_0==85||LA4_0==88) ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:107:6: inner_statement
            	    {
            	    _last = (SLAST)input.LT(1);
            	    pushFollow(FOLLOW_inner_statement_in_inner_statement_list133);
            	    inner_statement8=inner_statement();

            	    state._fsp--;

            	    adaptor.addChild(root_0, inner_statement8.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt4 >= 1 ) break loop4;
                        EarlyExitException eee =
                            new EarlyExitException(4, input);
                        throw eee;
                }
                cnt4++;
            } while (true);


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "inner_statement_list"

    public static class inner_statement_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "inner_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:110:1: inner_statement : ( statement | function_declaration_statement | class_declaration_statement | halt_compiler_statement );
    public final TreePHP.inner_statement_return inner_statement() throws RecognitionException {
        TreePHP.inner_statement_return retval = new TreePHP.inner_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.statement_return statement9 = null;

        TreePHP.function_declaration_statement_return function_declaration_statement10 = null;

        TreePHP.class_declaration_statement_return class_declaration_statement11 = null;

        TreePHP.halt_compiler_statement_return halt_compiler_statement12 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:111:3: ( statement | function_declaration_statement | class_declaration_statement | halt_compiler_statement )
            int alt5=4;
            switch ( input.LA(1) ) {
            case STATEMENT:
                {
                alt5=1;
                }
                break;
            case 88:
                {
                alt5=2;
                }
                break;
            case CLASS_T:
            case 85:
                {
                alt5=3;
                }
                break;
            case 81:
                {
                alt5=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 5, 0, input);

                throw nvae;
            }

            switch (alt5) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:111:5: statement
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_statement_in_inner_statement150);
                    statement9=statement();

                    state._fsp--;

                    adaptor.addChild(root_0, statement9.getTree());

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:112:5: function_declaration_statement
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_function_declaration_statement_in_inner_statement157);
                    function_declaration_statement10=function_declaration_statement();

                    state._fsp--;

                    adaptor.addChild(root_0, function_declaration_statement10.getTree());

                    }
                    break;
                case 3 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:113:5: class_declaration_statement
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_class_declaration_statement_in_inner_statement163);
                    class_declaration_statement11=class_declaration_statement();

                    state._fsp--;

                    adaptor.addChild(root_0, class_declaration_statement11.getTree());

                    }
                    break;
                case 4 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:114:5: halt_compiler_statement
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_halt_compiler_statement_in_inner_statement169);
                    halt_compiler_statement12=halt_compiler_statement();

                    state._fsp--;

                    adaptor.addChild(root_0, halt_compiler_statement12.getTree());

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "inner_statement"

    public static class halt_compiler_statement_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "halt_compiler_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:117:1: halt_compiler_statement : '__halt_compiler' ;
    public final TreePHP.halt_compiler_statement_return halt_compiler_statement() throws RecognitionException {
        TreePHP.halt_compiler_statement_return retval = new TreePHP.halt_compiler_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST string_literal13=null;

        SLAST string_literal13_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:118:3: ( '__halt_compiler' )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:118:5: '__halt_compiler'
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            string_literal13=(SLAST)match(input,81,FOLLOW_81_in_halt_compiler_statement184); 
            string_literal13_tree = (SLAST)adaptor.dupNode(string_literal13);

            adaptor.addChild(root_0, string_literal13_tree);


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "halt_compiler_statement"

    public static class class_declaration_statement_return extends TreeRuleReturnScope {
        public ClassDeclaration classDeclaration;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "class_declaration_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:121:1: class_declaration_statement returns [ClassDeclaration classDeclaration] : ( ^( CLASS_T ( class_entr_type )? IDENTIFIER ( ^( 'extends' fully_qualified_class_name ) )? ( ^( 'implements' fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? ) | ^( 'interface' IDENTIFIER ( ^( 'extends' fully_qualified_class_name_list ) )? ( ^( 'implements' fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? ) );
    public final TreePHP.class_declaration_statement_return class_declaration_statement() throws RecognitionException {
        TreePHP.class_declaration_statement_return retval = new TreePHP.class_declaration_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST CLASS_T14=null;
        SLAST IDENTIFIER16=null;
        SLAST string_literal17=null;
        SLAST string_literal19=null;
        SLAST CLASS_BODY21=null;
        SLAST string_literal23=null;
        SLAST IDENTIFIER24=null;
        SLAST string_literal25=null;
        SLAST string_literal27=null;
        SLAST CLASS_BODY29=null;
        TreePHP.class_entr_type_return class_entr_type15 = null;

        TreePHP.fully_qualified_class_name_return fully_qualified_class_name18 = null;

        TreePHP.fully_qualified_class_name_list_return fully_qualified_class_name_list20 = null;

        TreePHP.class_statement_list_return class_statement_list22 = null;

        TreePHP.fully_qualified_class_name_list_return fully_qualified_class_name_list26 = null;

        TreePHP.fully_qualified_class_name_list_return fully_qualified_class_name_list28 = null;

        TreePHP.class_statement_list_return class_statement_list30 = null;


        SLAST CLASS_T14_tree=null;
        SLAST IDENTIFIER16_tree=null;
        SLAST string_literal17_tree=null;
        SLAST string_literal19_tree=null;
        SLAST CLASS_BODY21_tree=null;
        SLAST string_literal23_tree=null;
        SLAST IDENTIFIER24_tree=null;
        SLAST string_literal25_tree=null;
        SLAST string_literal27_tree=null;
        SLAST CLASS_BODY29_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:122:3: ( ^( CLASS_T ( class_entr_type )? IDENTIFIER ( ^( 'extends' fully_qualified_class_name ) )? ( ^( 'implements' fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? ) | ^( 'interface' IDENTIFIER ( ^( 'extends' fully_qualified_class_name_list ) )? ( ^( 'implements' fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? ) )
            int alt13=2;
            int LA13_0 = input.LA(1);

            if ( (LA13_0==CLASS_T) ) {
                alt13=1;
            }
            else if ( (LA13_0==85) ) {
                alt13=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 13, 0, input);

                throw nvae;
            }
            switch (alt13) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:122:5: ^( CLASS_T ( class_entr_type )? IDENTIFIER ( ^( 'extends' fully_qualified_class_name ) )? ( ^( 'implements' fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    CLASS_T14=(SLAST)match(input,CLASS_T,FOLLOW_CLASS_T_in_class_declaration_statement204); 
                    CLASS_T14_tree = (SLAST)adaptor.dupNode(CLASS_T14);

                    root_1 = (SLAST)adaptor.becomeRoot(CLASS_T14_tree, root_1);



                    match(input, Token.DOWN, null); 
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:122:15: ( class_entr_type )?
                    int alt6=2;
                    int LA6_0 = input.LA(1);

                    if ( ((LA6_0>=86 && LA6_0<=87)) ) {
                        alt6=1;
                    }
                    switch (alt6) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:122:15: class_entr_type
                            {
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_class_entr_type_in_class_declaration_statement206);
                            class_entr_type15=class_entr_type();

                            state._fsp--;

                            adaptor.addChild(root_1, class_entr_type15.getTree());

                            }
                            break;

                    }

                    _last = (SLAST)input.LT(1);
                    IDENTIFIER16=(SLAST)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_class_declaration_statement209); 
                    IDENTIFIER16_tree = (SLAST)adaptor.dupNode(IDENTIFIER16);

                    adaptor.addChild(root_1, IDENTIFIER16_tree);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:122:43: ( ^( 'extends' fully_qualified_class_name ) )?
                    int alt7=2;
                    int LA7_0 = input.LA(1);

                    if ( (LA7_0==83) ) {
                        alt7=1;
                    }
                    switch (alt7) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:122:44: ^( 'extends' fully_qualified_class_name )
                            {
                            _last = (SLAST)input.LT(1);
                            {
                            SLAST _save_last_2 = _last;
                            SLAST _first_2 = null;
                            SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                            string_literal17=(SLAST)match(input,83,FOLLOW_83_in_class_declaration_statement213); 
                            string_literal17_tree = (SLAST)adaptor.dupNode(string_literal17);

                            root_2 = (SLAST)adaptor.becomeRoot(string_literal17_tree, root_2);



                            match(input, Token.DOWN, null); 
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_fully_qualified_class_name_in_class_declaration_statement215);
                            fully_qualified_class_name18=fully_qualified_class_name();

                            state._fsp--;

                            adaptor.addChild(root_2, fully_qualified_class_name18.getTree());

                            match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
                            }


                            }
                            break;

                    }

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:122:86: ( ^( 'implements' fully_qualified_class_name_list ) )?
                    int alt8=2;
                    int LA8_0 = input.LA(1);

                    if ( (LA8_0==84) ) {
                        alt8=1;
                    }
                    switch (alt8) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:122:87: ^( 'implements' fully_qualified_class_name_list )
                            {
                            _last = (SLAST)input.LT(1);
                            {
                            SLAST _save_last_2 = _last;
                            SLAST _first_2 = null;
                            SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                            string_literal19=(SLAST)match(input,84,FOLLOW_84_in_class_declaration_statement222); 
                            string_literal19_tree = (SLAST)adaptor.dupNode(string_literal19);

                            root_2 = (SLAST)adaptor.becomeRoot(string_literal19_tree, root_2);



                            match(input, Token.DOWN, null); 
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_fully_qualified_class_name_list_in_class_declaration_statement224);
                            fully_qualified_class_name_list20=fully_qualified_class_name_list();

                            state._fsp--;

                            adaptor.addChild(root_2, fully_qualified_class_name_list20.getTree());

                            match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
                            }


                            }
                            break;

                    }

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:123:7: ( ^( CLASS_BODY class_statement_list ) )?
                    int alt9=2;
                    int LA9_0 = input.LA(1);

                    if ( (LA9_0==CLASS_BODY) ) {
                        alt9=1;
                    }
                    switch (alt9) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:123:8: ^( CLASS_BODY class_statement_list )
                            {
                            _last = (SLAST)input.LT(1);
                            {
                            SLAST _save_last_2 = _last;
                            SLAST _first_2 = null;
                            SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                            CLASS_BODY21=(SLAST)match(input,CLASS_BODY,FOLLOW_CLASS_BODY_in_class_declaration_statement237); 
                            CLASS_BODY21_tree = (SLAST)adaptor.dupNode(CLASS_BODY21);

                            root_2 = (SLAST)adaptor.becomeRoot(CLASS_BODY21_tree, root_2);



                            match(input, Token.DOWN, null); 
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_class_statement_list_in_class_declaration_statement239);
                            class_statement_list22=class_statement_list();

                            state._fsp--;

                            adaptor.addChild(root_2, class_statement_list22.getTree());

                            match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
                            }


                            }
                            break;

                    }


                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                          
                          TreePHP.ModifierDocPair modifier = new ModifierDocPair(Modifiers.AccAbstract, null);
                          int startIndex = CLASS_T14.startIndex;
                          int endIndex = CLASS_T14.endIndex;
                          if ((class_entr_type15!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(class_entr_type15.start),
                      input.getTreeAdaptor().getTokenStopIndex(class_entr_type15.start))):null) != null) {
                    //          modifier = new ModifierDocPair(Modifiers.AccAbstract, null);
                          }
                          
                          CommonToken token = (CommonToken)IDENTIFIER16.token;
                          int classNameLeft = token.getStartIndex();
                          int classNameRight = token.getStopIndex();
                          String className = (IDENTIFIER16!=null?IDENTIFIER16.getText():null);
                          
                          retval.classDeclaration = new ClassDeclaration(startIndex ,endIndex, classNameLeft, classNameRight, modifier.modifier, className, null, null, new Block(classNameRight,classNameRight,null), null);
                          parser.addDeclarationStatement(retval.classDeclaration);
                    //      parser.declarations.push(retval.classDeclaration);
                          
                          TypeReference superClass = null;
                          int superClassLeft = 0;
                          int superClassRight = 0;
                          if ((fully_qualified_class_name18!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(fully_qualified_class_name18.start),
                      input.getTreeAdaptor().getTokenStopIndex(fully_qualified_class_name18.start))):null) != null) {
                              superClassLeft = ((CommonToken)(fully_qualified_class_name18!=null?((SLAST)fully_qualified_class_name18.tree):null).token).getStartIndex();
                              superClassRight = ((CommonToken)(fully_qualified_class_name18!=null?((SLAST)fully_qualified_class_name18.tree):null).token).getStopIndex();
                              superClass = (fully_qualified_class_name18!=null?fully_qualified_class_name18.name:null);
                          }
                          
                          List interfaces = null;
                          int interfacesLeft = 0;
                          int interfacesRight = 0;
                          if ((fully_qualified_class_name_list20!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(fully_qualified_class_name_list20.start),
                      input.getTreeAdaptor().getTokenStopIndex(fully_qualified_class_name_list20.start))):null) != null) {
                              interfacesLeft = ((CommonToken)(fully_qualified_class_name_list20!=null?((SLAST)fully_qualified_class_name_list20.tree):null).token).getStartIndex();
                              interfacesRight = ((CommonToken)(fully_qualified_class_name_list20!=null?((SLAST)fully_qualified_class_name_list20.tree):null).token).getStopIndex();
                          }
                          
                    //      retval.classDeclaration = (ClassDeclaration)parser.declarations.peek();
                    		  if (superClass != null) {
                    		    retval.classDeclaration.setSuperClass(superClass);
                    		  }
                    		  if (interfaces != null) {
                    		    retval.classDeclaration.setInterfaceList(interfaces);
                    		  }
                        
                          int blockEndLeft = 0;
                          int blockEndRight = 1;
                        
                    //      retval.classDeclaration = (ClassDeclaration)parser.declarations.pop();
                          if ((class_statement_list22!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(class_statement_list22.start),
                      input.getTreeAdaptor().getTokenStopIndex(class_statement_list22.start))):null) != null) {
                    		      retval.classDeclaration.getBody().setStart(blockEndLeft);
                    		      retval.classDeclaration.getBody().setEnd(blockEndRight);
                    		  }
                        

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:176:5: ^( 'interface' IDENTIFIER ( ^( 'extends' fully_qualified_class_name_list ) )? ( ^( 'implements' fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    string_literal23=(SLAST)match(input,85,FOLLOW_85_in_class_declaration_statement256); 
                    string_literal23_tree = (SLAST)adaptor.dupNode(string_literal23);

                    root_1 = (SLAST)adaptor.becomeRoot(string_literal23_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    IDENTIFIER24=(SLAST)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_class_declaration_statement258); 
                    IDENTIFIER24_tree = (SLAST)adaptor.dupNode(IDENTIFIER24);

                    adaptor.addChild(root_1, IDENTIFIER24_tree);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:176:30: ( ^( 'extends' fully_qualified_class_name_list ) )?
                    int alt10=2;
                    int LA10_0 = input.LA(1);

                    if ( (LA10_0==83) ) {
                        alt10=1;
                    }
                    switch (alt10) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:176:31: ^( 'extends' fully_qualified_class_name_list )
                            {
                            _last = (SLAST)input.LT(1);
                            {
                            SLAST _save_last_2 = _last;
                            SLAST _first_2 = null;
                            SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                            string_literal25=(SLAST)match(input,83,FOLLOW_83_in_class_declaration_statement262); 
                            string_literal25_tree = (SLAST)adaptor.dupNode(string_literal25);

                            root_2 = (SLAST)adaptor.becomeRoot(string_literal25_tree, root_2);



                            match(input, Token.DOWN, null); 
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_fully_qualified_class_name_list_in_class_declaration_statement264);
                            fully_qualified_class_name_list26=fully_qualified_class_name_list();

                            state._fsp--;

                            adaptor.addChild(root_2, fully_qualified_class_name_list26.getTree());

                            match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
                            }


                            }
                            break;

                    }

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:176:78: ( ^( 'implements' fully_qualified_class_name_list ) )?
                    int alt11=2;
                    int LA11_0 = input.LA(1);

                    if ( (LA11_0==84) ) {
                        alt11=1;
                    }
                    switch (alt11) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:176:79: ^( 'implements' fully_qualified_class_name_list )
                            {
                            _last = (SLAST)input.LT(1);
                            {
                            SLAST _save_last_2 = _last;
                            SLAST _first_2 = null;
                            SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                            string_literal27=(SLAST)match(input,84,FOLLOW_84_in_class_declaration_statement271); 
                            string_literal27_tree = (SLAST)adaptor.dupNode(string_literal27);

                            root_2 = (SLAST)adaptor.becomeRoot(string_literal27_tree, root_2);



                            match(input, Token.DOWN, null); 
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_fully_qualified_class_name_list_in_class_declaration_statement273);
                            fully_qualified_class_name_list28=fully_qualified_class_name_list();

                            state._fsp--;

                            adaptor.addChild(root_2, fully_qualified_class_name_list28.getTree());

                            match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
                            }


                            }
                            break;

                    }

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:177:7: ( ^( CLASS_BODY class_statement_list ) )?
                    int alt12=2;
                    int LA12_0 = input.LA(1);

                    if ( (LA12_0==CLASS_BODY) ) {
                        alt12=1;
                    }
                    switch (alt12) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:177:8: ^( CLASS_BODY class_statement_list )
                            {
                            _last = (SLAST)input.LT(1);
                            {
                            SLAST _save_last_2 = _last;
                            SLAST _first_2 = null;
                            SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                            CLASS_BODY29=(SLAST)match(input,CLASS_BODY,FOLLOW_CLASS_BODY_in_class_declaration_statement286); 
                            CLASS_BODY29_tree = (SLAST)adaptor.dupNode(CLASS_BODY29);

                            root_2 = (SLAST)adaptor.becomeRoot(CLASS_BODY29_tree, root_2);



                            match(input, Token.DOWN, null); 
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_class_statement_list_in_class_declaration_statement288);
                            class_statement_list30=class_statement_list();

                            state._fsp--;

                            adaptor.addChild(root_2, class_statement_list30.getTree());

                            match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
                            }


                            }
                            break;

                    }


                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "class_declaration_statement"

    public static class class_entr_type_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "class_entr_type"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:180:1: class_entr_type : ( 'abstract' | 'final' );
    public final TreePHP.class_entr_type_return class_entr_type() throws RecognitionException {
        TreePHP.class_entr_type_return retval = new TreePHP.class_entr_type_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST set31=null;

        SLAST set31_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:181:3: ( 'abstract' | 'final' )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            set31=(SLAST)input.LT(1);
            if ( (input.LA(1)>=86 && input.LA(1)<=87) ) {
                input.consume();

                set31_tree = (SLAST)adaptor.dupNode(set31);

                adaptor.addChild(root_0, set31_tree);

                state.errorRecovery=false;
            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                throw mse;
            }

             

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "class_entr_type"

    public static class class_statement_list_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "class_statement_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:185:1: class_statement_list : ( class_statement )+ ;
    public final TreePHP.class_statement_list_return class_statement_list() throws RecognitionException {
        TreePHP.class_statement_list_return retval = new TreePHP.class_statement_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.class_statement_return class_statement32 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:186:3: ( ( class_statement )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:186:5: ( class_statement )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:186:5: ( class_statement )+
            int cnt14=0;
            loop14:
            do {
                int alt14=2;
                int LA14_0 = input.LA(1);

                if ( ((LA14_0>=FIELD_DECL && LA14_0<=METHOD_DECL)) ) {
                    alt14=1;
                }


                switch (alt14) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:186:5: class_statement
            	    {
            	    _last = (SLAST)input.LT(1);
            	    pushFollow(FOLLOW_class_statement_in_class_statement_list328);
            	    class_statement32=class_statement();

            	    state._fsp--;

            	    adaptor.addChild(root_0, class_statement32.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt14 >= 1 ) break loop14;
                        EarlyExitException eee =
                            new EarlyExitException(14, input);
                        throw eee;
                }
                cnt14++;
            } while (true);


                int listleft = ((CommonToken)((SLAST)retval.tree).token).getStartIndex(); 
                int listright = ((CommonToken)((SLAST)retval.tree).token).getStopIndex(); 
                Object list = null;
                 
            	  if(!(parser.declarations.peek() instanceof TypeDeclaration)) {
            	    parser.declarations.pop();
            	  }  
              

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "class_statement_list"

    public static class class_statement_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "class_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:198:1: class_statement : ( ^( FIELD_DECL variable_modifiers static_var_list ) | ^( METHOD_DECL modifier method_declaration ) | ^( FIELD_DECL class_constant_declaration ) );
    public final TreePHP.class_statement_return class_statement() throws RecognitionException {
        TreePHP.class_statement_return retval = new TreePHP.class_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST FIELD_DECL33=null;
        SLAST METHOD_DECL36=null;
        SLAST FIELD_DECL39=null;
        TreePHP.variable_modifiers_return variable_modifiers34 = null;

        TreePHP.static_var_list_return static_var_list35 = null;

        TreePHP.modifier_return modifier37 = null;

        TreePHP.method_declaration_return method_declaration38 = null;

        TreePHP.class_constant_declaration_return class_constant_declaration40 = null;


        SLAST FIELD_DECL33_tree=null;
        SLAST METHOD_DECL36_tree=null;
        SLAST FIELD_DECL39_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:199:3: ( ^( FIELD_DECL variable_modifiers static_var_list ) | ^( METHOD_DECL modifier method_declaration ) | ^( FIELD_DECL class_constant_declaration ) )
            int alt15=3;
            int LA15_0 = input.LA(1);

            if ( (LA15_0==FIELD_DECL) ) {
                int LA15_1 = input.LA(2);

                if ( (LA15_1==DOWN) ) {
                    int LA15_3 = input.LA(3);

                    if ( (LA15_3==VAR_DECL) ) {
                        alt15=3;
                    }
                    else if ( (LA15_3==SCALAR_VAR||(LA15_3>=86 && LA15_3<=87)||LA15_3==97||(LA15_3>=122 && LA15_3<=125)) ) {
                        alt15=1;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 15, 3, input);

                        throw nvae;
                    }
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 15, 1, input);

                    throw nvae;
                }
            }
            else if ( (LA15_0==METHOD_DECL) ) {
                alt15=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 15, 0, input);

                throw nvae;
            }
            switch (alt15) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:199:5: ^( FIELD_DECL variable_modifiers static_var_list )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    FIELD_DECL33=(SLAST)match(input,FIELD_DECL,FOLLOW_FIELD_DECL_in_class_statement348); 
                    FIELD_DECL33_tree = (SLAST)adaptor.dupNode(FIELD_DECL33);

                    root_1 = (SLAST)adaptor.becomeRoot(FIELD_DECL33_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_variable_modifiers_in_class_statement350);
                    variable_modifiers34=variable_modifiers();

                    state._fsp--;

                    adaptor.addChild(root_1, variable_modifiers34.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_static_var_list_in_class_statement352);
                    static_var_list35=static_var_list();

                    state._fsp--;

                    adaptor.addChild(root_1, static_var_list35.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:200:5: ^( METHOD_DECL modifier method_declaration )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    METHOD_DECL36=(SLAST)match(input,METHOD_DECL,FOLLOW_METHOD_DECL_in_class_statement360); 
                    METHOD_DECL36_tree = (SLAST)adaptor.dupNode(METHOD_DECL36);

                    root_1 = (SLAST)adaptor.becomeRoot(METHOD_DECL36_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_modifier_in_class_statement362);
                    modifier37=modifier();

                    state._fsp--;

                    adaptor.addChild(root_1, modifier37.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_method_declaration_in_class_statement364);
                    method_declaration38=method_declaration();

                    state._fsp--;

                    adaptor.addChild(root_1, method_declaration38.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 3 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:201:5: ^( FIELD_DECL class_constant_declaration )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    FIELD_DECL39=(SLAST)match(input,FIELD_DECL,FOLLOW_FIELD_DECL_in_class_statement372); 
                    FIELD_DECL39_tree = (SLAST)adaptor.dupNode(FIELD_DECL39);

                    root_1 = (SLAST)adaptor.becomeRoot(FIELD_DECL39_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_class_constant_declaration_in_class_statement374);
                    class_constant_declaration40=class_constant_declaration();

                    state._fsp--;

                    adaptor.addChild(root_1, class_constant_declaration40.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "class_statement"

    public static class class_constant_declaration_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "class_constant_declaration"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:204:1: class_constant_declaration : ^( VAR_DECL 'const' directive ) ;
    public final TreePHP.class_constant_declaration_return class_constant_declaration() throws RecognitionException {
        TreePHP.class_constant_declaration_return retval = new TreePHP.class_constant_declaration_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST VAR_DECL41=null;
        SLAST string_literal42=null;
        TreePHP.directive_return directive43 = null;


        SLAST VAR_DECL41_tree=null;
        SLAST string_literal42_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:205:3: ( ^( VAR_DECL 'const' directive ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:205:5: ^( VAR_DECL 'const' directive )
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_1 = _last;
            SLAST _first_1 = null;
            SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            VAR_DECL41=(SLAST)match(input,VAR_DECL,FOLLOW_VAR_DECL_in_class_constant_declaration389); 
            VAR_DECL41_tree = (SLAST)adaptor.dupNode(VAR_DECL41);

            root_1 = (SLAST)adaptor.becomeRoot(VAR_DECL41_tree, root_1);



            match(input, Token.DOWN, null); 
            _last = (SLAST)input.LT(1);
            string_literal42=(SLAST)match(input,106,FOLLOW_106_in_class_constant_declaration391); 
            string_literal42_tree = (SLAST)adaptor.dupNode(string_literal42);

            adaptor.addChild(root_1, string_literal42_tree);

            _last = (SLAST)input.LT(1);
            pushFollow(FOLLOW_directive_in_class_constant_declaration393);
            directive43=directive();

            state._fsp--;

            adaptor.addChild(root_1, directive43.getTree());

            match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "class_constant_declaration"

    public static class function_declaration_statement_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "function_declaration_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:208:1: function_declaration_statement : ^( 'function' ( '&' )? IDENTIFIER ( parameter_list )? block ) ;
    public final TreePHP.function_declaration_statement_return function_declaration_statement() throws RecognitionException {
        TreePHP.function_declaration_statement_return retval = new TreePHP.function_declaration_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST string_literal44=null;
        SLAST char_literal45=null;
        SLAST IDENTIFIER46=null;
        TreePHP.parameter_list_return parameter_list47 = null;

        TreePHP.block_return block48 = null;


        SLAST string_literal44_tree=null;
        SLAST char_literal45_tree=null;
        SLAST IDENTIFIER46_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:209:3: ( ^( 'function' ( '&' )? IDENTIFIER ( parameter_list )? block ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:209:5: ^( 'function' ( '&' )? IDENTIFIER ( parameter_list )? block )
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_1 = _last;
            SLAST _first_1 = null;
            SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            string_literal44=(SLAST)match(input,88,FOLLOW_88_in_function_declaration_statement412); 
            string_literal44_tree = (SLAST)adaptor.dupNode(string_literal44);

            root_1 = (SLAST)adaptor.becomeRoot(string_literal44_tree, root_1);



            match(input, Token.DOWN, null); 
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:209:18: ( '&' )?
            int alt16=2;
            int LA16_0 = input.LA(1);

            if ( (LA16_0==BIT_AND) ) {
                alt16=1;
            }
            switch (alt16) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:209:18: '&'
                    {
                    _last = (SLAST)input.LT(1);
                    char_literal45=(SLAST)match(input,BIT_AND,FOLLOW_BIT_AND_in_function_declaration_statement414); 
                    char_literal45_tree = (SLAST)adaptor.dupNode(char_literal45);

                    adaptor.addChild(root_1, char_literal45_tree);


                    }
                    break;

            }

            _last = (SLAST)input.LT(1);
            IDENTIFIER46=(SLAST)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_function_declaration_statement417); 
            IDENTIFIER46_tree = (SLAST)adaptor.dupNode(IDENTIFIER46);

            adaptor.addChild(root_1, IDENTIFIER46_tree);

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:209:34: ( parameter_list )?
            int alt17=2;
            int LA17_0 = input.LA(1);

            if ( (LA17_0==PARAMETER) ) {
                alt17=1;
            }
            switch (alt17) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:209:34: parameter_list
                    {
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_parameter_list_in_function_declaration_statement419);
                    parameter_list47=parameter_list();

                    state._fsp--;

                    adaptor.addChild(root_1, parameter_list47.getTree());

                    }
                    break;

            }

            _last = (SLAST)input.LT(1);
            pushFollow(FOLLOW_block_in_function_declaration_statement422);
            block48=block();

            state._fsp--;

            adaptor.addChild(root_1, block48.getTree());

            match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "function_declaration_statement"

    public static class block_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "block"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:212:1: block : ^( BLOCK ( inner_statement_list )? ) ;
    public final TreePHP.block_return block() throws RecognitionException {
        TreePHP.block_return retval = new TreePHP.block_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST BLOCK49=null;
        TreePHP.inner_statement_list_return inner_statement_list50 = null;


        SLAST BLOCK49_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:213:3: ( ^( BLOCK ( inner_statement_list )? ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:213:5: ^( BLOCK ( inner_statement_list )? )
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_1 = _last;
            SLAST _first_1 = null;
            SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            BLOCK49=(SLAST)match(input,BLOCK,FOLLOW_BLOCK_in_block438); 
            BLOCK49_tree = (SLAST)adaptor.dupNode(BLOCK49);

            root_1 = (SLAST)adaptor.becomeRoot(BLOCK49_tree, root_1);



            if ( input.LA(1)==Token.DOWN ) {
                match(input, Token.DOWN, null); 
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:213:13: ( inner_statement_list )?
                int alt18=2;
                int LA18_0 = input.LA(1);

                if ( (LA18_0==STATEMENT||LA18_0==CLASS_T||LA18_0==81||LA18_0==85||LA18_0==88) ) {
                    alt18=1;
                }
                switch (alt18) {
                    case 1 :
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:213:13: inner_statement_list
                        {
                        _last = (SLAST)input.LT(1);
                        pushFollow(FOLLOW_inner_statement_list_in_block440);
                        inner_statement_list50=inner_statement_list();

                        state._fsp--;

                        adaptor.addChild(root_1, inner_statement_list50.getTree());

                        }
                        break;

                }


                match(input, Token.UP, null); 
            }adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "block"

    public static class statement_return extends TreeRuleReturnScope {
        public ExpressionStatement exprStat;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:216:1: statement returns [ExpressionStatement exprStat] : ^( STATEMENT topStatement ) ;
    public final TreePHP.statement_return statement() throws RecognitionException {
        TreePHP.statement_return retval = new TreePHP.statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST STATEMENT51=null;
        TreePHP.topStatement_return topStatement52 = null;


        SLAST STATEMENT51_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:217:3: ( ^( STATEMENT topStatement ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:217:5: ^( STATEMENT topStatement )
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_1 = _last;
            SLAST _first_1 = null;
            SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            STATEMENT51=(SLAST)match(input,STATEMENT,FOLLOW_STATEMENT_in_statement462); 
            STATEMENT51_tree = (SLAST)adaptor.dupNode(STATEMENT51);

            root_1 = (SLAST)adaptor.becomeRoot(STATEMENT51_tree, root_1);



            match(input, Token.DOWN, null); 
            _last = (SLAST)input.LT(1);
            pushFollow(FOLLOW_topStatement_in_statement464);
            topStatement52=topStatement();

            state._fsp--;

            adaptor.addChild(root_1, topStatement52.getTree());

            match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


                int startIndex = STATEMENT51.startIndex;
                int endIndex = STATEMENT51.endIndex;

                retval.exprStat = new ExpressionStatement(startIndex, endIndex, (topStatement52!=null?topStatement52.expr:null));
                
                System.out.println("exprStat: " + retval.exprStat);
              

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "statement"

    public static class topStatement_return extends TreeRuleReturnScope {
        public Expression expr;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "topStatement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:228:1: topStatement returns [Expression expr] : ( block | if_stat | ^( 'while' ^( CONDITION expression ) while_statement ) | ^( 'do' ^( CONDITION expression ) statement ) | ^( 'for' ( expr_list )? ^( CONDITION ( expr_list )? ) ^( ITERATE ( expr_list )? ) for_statement ) | ^( 'switch' ^( CONDITION expression ) switch_case_list ) | ^( 'break' ( expression )? ) | ^( 'continue' ( expression )? ) | ^( 'return' ( expression )? ) | ^( 'global' variable ) | ^( 'static' static_var_list ) | ^( 'echo' expr_list ) | expression | ^( 'foreach' ^( 'as' expression foreach_variable ) foreach_statement ) | ^( 'declare' ^( CONDITION directive ) declare_statement ) | ^( 'try' ^( BLOCK top_statement ) ( catch_branch )+ ) | ^( 'throw' expression ) | ^( 'use' use_filename ) );
    public final TreePHP.topStatement_return topStatement() throws RecognitionException {
        TreePHP.topStatement_return retval = new TreePHP.topStatement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST string_literal55=null;
        SLAST CONDITION56=null;
        SLAST string_literal59=null;
        SLAST CONDITION60=null;
        SLAST string_literal63=null;
        SLAST CONDITION65=null;
        SLAST ITERATE67=null;
        SLAST string_literal70=null;
        SLAST CONDITION71=null;
        SLAST string_literal74=null;
        SLAST string_literal76=null;
        SLAST string_literal78=null;
        SLAST string_literal80=null;
        SLAST string_literal82=null;
        SLAST string_literal84=null;
        SLAST string_literal87=null;
        SLAST string_literal88=null;
        SLAST string_literal92=null;
        SLAST CONDITION93=null;
        SLAST string_literal96=null;
        SLAST BLOCK97=null;
        SLAST string_literal100=null;
        SLAST string_literal102=null;
        TreePHP.block_return block53 = null;

        TreePHP.if_stat_return if_stat54 = null;

        TreePHP.expression_return expression57 = null;

        TreePHP.while_statement_return while_statement58 = null;

        TreePHP.expression_return expression61 = null;

        TreePHP.statement_return statement62 = null;

        TreePHP.expr_list_return expr_list64 = null;

        TreePHP.expr_list_return expr_list66 = null;

        TreePHP.expr_list_return expr_list68 = null;

        TreePHP.for_statement_return for_statement69 = null;

        TreePHP.expression_return expression72 = null;

        TreePHP.switch_case_list_return switch_case_list73 = null;

        TreePHP.expression_return expression75 = null;

        TreePHP.expression_return expression77 = null;

        TreePHP.expression_return expression79 = null;

        TreePHP.variable_return variable81 = null;

        TreePHP.static_var_list_return static_var_list83 = null;

        TreePHP.expr_list_return expr_list85 = null;

        TreePHP.expression_return expression86 = null;

        TreePHP.expression_return expression89 = null;

        TreePHP.foreach_variable_return foreach_variable90 = null;

        TreePHP.foreach_statement_return foreach_statement91 = null;

        TreePHP.directive_return directive94 = null;

        TreePHP.declare_statement_return declare_statement95 = null;

        TreePHP.top_statement_return top_statement98 = null;

        TreePHP.catch_branch_return catch_branch99 = null;

        TreePHP.expression_return expression101 = null;

        TreePHP.use_filename_return use_filename103 = null;


        SLAST string_literal55_tree=null;
        SLAST CONDITION56_tree=null;
        SLAST string_literal59_tree=null;
        SLAST CONDITION60_tree=null;
        SLAST string_literal63_tree=null;
        SLAST CONDITION65_tree=null;
        SLAST ITERATE67_tree=null;
        SLAST string_literal70_tree=null;
        SLAST CONDITION71_tree=null;
        SLAST string_literal74_tree=null;
        SLAST string_literal76_tree=null;
        SLAST string_literal78_tree=null;
        SLAST string_literal80_tree=null;
        SLAST string_literal82_tree=null;
        SLAST string_literal84_tree=null;
        SLAST string_literal87_tree=null;
        SLAST string_literal88_tree=null;
        SLAST string_literal92_tree=null;
        SLAST CONDITION93_tree=null;
        SLAST string_literal96_tree=null;
        SLAST BLOCK97_tree=null;
        SLAST string_literal100_tree=null;
        SLAST string_literal102_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:229:3: ( block | if_stat | ^( 'while' ^( CONDITION expression ) while_statement ) | ^( 'do' ^( CONDITION expression ) statement ) | ^( 'for' ( expr_list )? ^( CONDITION ( expr_list )? ) ^( ITERATE ( expr_list )? ) for_statement ) | ^( 'switch' ^( CONDITION expression ) switch_case_list ) | ^( 'break' ( expression )? ) | ^( 'continue' ( expression )? ) | ^( 'return' ( expression )? ) | ^( 'global' variable ) | ^( 'static' static_var_list ) | ^( 'echo' expr_list ) | expression | ^( 'foreach' ^( 'as' expression foreach_variable ) foreach_statement ) | ^( 'declare' ^( CONDITION directive ) declare_statement ) | ^( 'try' ^( BLOCK top_statement ) ( catch_branch )+ ) | ^( 'throw' expression ) | ^( 'use' use_filename ) )
            int alt26=18;
            switch ( input.LA(1) ) {
            case BLOCK:
                {
                alt26=1;
                }
                break;
            case 109:
                {
                alt26=2;
                }
                break;
            case 89:
                {
                alt26=3;
                }
                break;
            case 90:
                {
                alt26=4;
                }
                break;
            case 91:
                {
                alt26=5;
                }
                break;
            case 92:
                {
                alt26=6;
                }
                break;
            case 93:
                {
                alt26=7;
                }
                break;
            case 94:
                {
                alt26=8;
                }
                break;
            case 95:
                {
                alt26=9;
                }
                break;
            case 96:
                {
                alt26=10;
                }
                break;
            case 97:
                {
                alt26=11;
                }
                break;
            case 98:
                {
                alt26=12;
                }
                break;
            case METHOD_DECL:
            case VAR_DECL:
            case CALL:
            case EXPR:
            case SCALAR:
            case ARRAY_DECL:
            case EQ:
            case PLUS_EQ:
            case MINUS_EQ:
            case MUL_EQ:
            case DIV_EQ:
            case DOT_EQ:
            case PERCENT_EQ:
            case BIT_AND_EQ:
            case BIT_OR_EQ:
            case POWER_EQ:
            case LMOVE_EQ:
            case RMOVE_EQ:
            case BIT_AND:
            case BACKTRICKLITERAL:
            case 126:
            case 127:
            case 128:
            case 129:
            case 130:
            case 131:
            case 132:
            case 133:
            case 134:
            case 135:
            case 136:
            case 137:
            case 138:
            case 139:
            case 140:
            case 141:
            case 142:
            case 143:
            case 144:
            case 145:
            case 146:
            case 147:
            case 148:
            case 149:
            case 150:
            case 151:
            case 152:
            case 153:
            case 154:
            case 155:
            case 156:
            case 157:
            case 158:
            case 159:
            case 160:
            case 161:
            case 162:
            case 163:
            case 164:
            case 165:
            case 166:
            case 167:
            case 168:
            case 169:
                {
                alt26=13;
                }
                break;
            case 99:
                {
                alt26=14;
                }
                break;
            case 101:
                {
                alt26=15;
                }
                break;
            case 102:
                {
                alt26=16;
                }
                break;
            case 103:
                {
                alt26=17;
                }
                break;
            case 104:
                {
                alt26=18;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 26, 0, input);

                throw nvae;
            }

            switch (alt26) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:229:5: block
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_block_in_topStatement486);
                    block53=block();

                    state._fsp--;

                    adaptor.addChild(root_0, block53.getTree());

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:230:5: if_stat
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_if_stat_in_topStatement493);
                    if_stat54=if_stat();

                    state._fsp--;

                    adaptor.addChild(root_0, if_stat54.getTree());

                    }
                    break;
                case 3 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:231:5: ^( 'while' ^( CONDITION expression ) while_statement )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    string_literal55=(SLAST)match(input,89,FOLLOW_89_in_topStatement500); 
                    string_literal55_tree = (SLAST)adaptor.dupNode(string_literal55);

                    root_1 = (SLAST)adaptor.becomeRoot(string_literal55_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_2 = _last;
                    SLAST _first_2 = null;
                    SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    CONDITION56=(SLAST)match(input,CONDITION,FOLLOW_CONDITION_in_topStatement503); 
                    CONDITION56_tree = (SLAST)adaptor.dupNode(CONDITION56);

                    root_2 = (SLAST)adaptor.becomeRoot(CONDITION56_tree, root_2);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_topStatement505);
                    expression57=expression();

                    state._fsp--;

                    adaptor.addChild(root_2, expression57.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
                    }

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_while_statement_in_topStatement508);
                    while_statement58=while_statement();

                    state._fsp--;

                    adaptor.addChild(root_1, while_statement58.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 4 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:232:5: ^( 'do' ^( CONDITION expression ) statement )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    string_literal59=(SLAST)match(input,90,FOLLOW_90_in_topStatement516); 
                    string_literal59_tree = (SLAST)adaptor.dupNode(string_literal59);

                    root_1 = (SLAST)adaptor.becomeRoot(string_literal59_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_2 = _last;
                    SLAST _first_2 = null;
                    SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    CONDITION60=(SLAST)match(input,CONDITION,FOLLOW_CONDITION_in_topStatement519); 
                    CONDITION60_tree = (SLAST)adaptor.dupNode(CONDITION60);

                    root_2 = (SLAST)adaptor.becomeRoot(CONDITION60_tree, root_2);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_topStatement521);
                    expression61=expression();

                    state._fsp--;

                    adaptor.addChild(root_2, expression61.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
                    }

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_statement_in_topStatement524);
                    statement62=statement();

                    state._fsp--;

                    adaptor.addChild(root_1, statement62.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 5 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:233:5: ^( 'for' ( expr_list )? ^( CONDITION ( expr_list )? ) ^( ITERATE ( expr_list )? ) for_statement )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    string_literal63=(SLAST)match(input,91,FOLLOW_91_in_topStatement532); 
                    string_literal63_tree = (SLAST)adaptor.dupNode(string_literal63);

                    root_1 = (SLAST)adaptor.becomeRoot(string_literal63_tree, root_1);



                    match(input, Token.DOWN, null); 
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:233:13: ( expr_list )?
                    int alt19=2;
                    int LA19_0 = input.LA(1);

                    if ( (LA19_0==METHOD_DECL||LA19_0==VAR_DECL||LA19_0==CALL||LA19_0==EXPR||(LA19_0>=SCALAR && LA19_0<=ARRAY_DECL)||(LA19_0>=EQ && LA19_0<=BACKTRICKLITERAL)||(LA19_0>=126 && LA19_0<=169)) ) {
                        alt19=1;
                    }
                    switch (alt19) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:233:13: expr_list
                            {
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_expr_list_in_topStatement534);
                            expr_list64=expr_list();

                            state._fsp--;

                            adaptor.addChild(root_1, expr_list64.getTree());

                            }
                            break;

                    }

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_2 = _last;
                    SLAST _first_2 = null;
                    SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    CONDITION65=(SLAST)match(input,CONDITION,FOLLOW_CONDITION_in_topStatement538); 
                    CONDITION65_tree = (SLAST)adaptor.dupNode(CONDITION65);

                    root_2 = (SLAST)adaptor.becomeRoot(CONDITION65_tree, root_2);



                    if ( input.LA(1)==Token.DOWN ) {
                        match(input, Token.DOWN, null); 
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:233:36: ( expr_list )?
                        int alt20=2;
                        int LA20_0 = input.LA(1);

                        if ( (LA20_0==METHOD_DECL||LA20_0==VAR_DECL||LA20_0==CALL||LA20_0==EXPR||(LA20_0>=SCALAR && LA20_0<=ARRAY_DECL)||(LA20_0>=EQ && LA20_0<=BACKTRICKLITERAL)||(LA20_0>=126 && LA20_0<=169)) ) {
                            alt20=1;
                        }
                        switch (alt20) {
                            case 1 :
                                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:233:36: expr_list
                                {
                                _last = (SLAST)input.LT(1);
                                pushFollow(FOLLOW_expr_list_in_topStatement540);
                                expr_list66=expr_list();

                                state._fsp--;

                                adaptor.addChild(root_2, expr_list66.getTree());

                                }
                                break;

                        }


                        match(input, Token.UP, null); 
                    }adaptor.addChild(root_1, root_2);_last = _save_last_2;
                    }

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_2 = _last;
                    SLAST _first_2 = null;
                    SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    ITERATE67=(SLAST)match(input,ITERATE,FOLLOW_ITERATE_in_topStatement545); 
                    ITERATE67_tree = (SLAST)adaptor.dupNode(ITERATE67);

                    root_2 = (SLAST)adaptor.becomeRoot(ITERATE67_tree, root_2);



                    if ( input.LA(1)==Token.DOWN ) {
                        match(input, Token.DOWN, null); 
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:233:58: ( expr_list )?
                        int alt21=2;
                        int LA21_0 = input.LA(1);

                        if ( (LA21_0==METHOD_DECL||LA21_0==VAR_DECL||LA21_0==CALL||LA21_0==EXPR||(LA21_0>=SCALAR && LA21_0<=ARRAY_DECL)||(LA21_0>=EQ && LA21_0<=BACKTRICKLITERAL)||(LA21_0>=126 && LA21_0<=169)) ) {
                            alt21=1;
                        }
                        switch (alt21) {
                            case 1 :
                                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:233:58: expr_list
                                {
                                _last = (SLAST)input.LT(1);
                                pushFollow(FOLLOW_expr_list_in_topStatement547);
                                expr_list68=expr_list();

                                state._fsp--;

                                adaptor.addChild(root_2, expr_list68.getTree());

                                }
                                break;

                        }


                        match(input, Token.UP, null); 
                    }adaptor.addChild(root_1, root_2);_last = _save_last_2;
                    }

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_for_statement_in_topStatement551);
                    for_statement69=for_statement();

                    state._fsp--;

                    adaptor.addChild(root_1, for_statement69.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 6 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:234:5: ^( 'switch' ^( CONDITION expression ) switch_case_list )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    string_literal70=(SLAST)match(input,92,FOLLOW_92_in_topStatement559); 
                    string_literal70_tree = (SLAST)adaptor.dupNode(string_literal70);

                    root_1 = (SLAST)adaptor.becomeRoot(string_literal70_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_2 = _last;
                    SLAST _first_2 = null;
                    SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    CONDITION71=(SLAST)match(input,CONDITION,FOLLOW_CONDITION_in_topStatement562); 
                    CONDITION71_tree = (SLAST)adaptor.dupNode(CONDITION71);

                    root_2 = (SLAST)adaptor.becomeRoot(CONDITION71_tree, root_2);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_topStatement564);
                    expression72=expression();

                    state._fsp--;

                    adaptor.addChild(root_2, expression72.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
                    }

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_switch_case_list_in_topStatement567);
                    switch_case_list73=switch_case_list();

                    state._fsp--;

                    adaptor.addChild(root_1, switch_case_list73.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 7 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:235:5: ^( 'break' ( expression )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    string_literal74=(SLAST)match(input,93,FOLLOW_93_in_topStatement575); 
                    string_literal74_tree = (SLAST)adaptor.dupNode(string_literal74);

                    root_1 = (SLAST)adaptor.becomeRoot(string_literal74_tree, root_1);



                    if ( input.LA(1)==Token.DOWN ) {
                        match(input, Token.DOWN, null); 
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:235:15: ( expression )?
                        int alt22=2;
                        int LA22_0 = input.LA(1);

                        if ( (LA22_0==METHOD_DECL||LA22_0==VAR_DECL||LA22_0==CALL||LA22_0==EXPR||(LA22_0>=SCALAR && LA22_0<=ARRAY_DECL)||(LA22_0>=EQ && LA22_0<=BACKTRICKLITERAL)||(LA22_0>=126 && LA22_0<=169)) ) {
                            alt22=1;
                        }
                        switch (alt22) {
                            case 1 :
                                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:235:15: expression
                                {
                                _last = (SLAST)input.LT(1);
                                pushFollow(FOLLOW_expression_in_topStatement577);
                                expression75=expression();

                                state._fsp--;

                                adaptor.addChild(root_1, expression75.getTree());

                                }
                                break;

                        }


                        match(input, Token.UP, null); 
                    }adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 8 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:236:5: ^( 'continue' ( expression )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    string_literal76=(SLAST)match(input,94,FOLLOW_94_in_topStatement586); 
                    string_literal76_tree = (SLAST)adaptor.dupNode(string_literal76);

                    root_1 = (SLAST)adaptor.becomeRoot(string_literal76_tree, root_1);



                    if ( input.LA(1)==Token.DOWN ) {
                        match(input, Token.DOWN, null); 
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:236:18: ( expression )?
                        int alt23=2;
                        int LA23_0 = input.LA(1);

                        if ( (LA23_0==METHOD_DECL||LA23_0==VAR_DECL||LA23_0==CALL||LA23_0==EXPR||(LA23_0>=SCALAR && LA23_0<=ARRAY_DECL)||(LA23_0>=EQ && LA23_0<=BACKTRICKLITERAL)||(LA23_0>=126 && LA23_0<=169)) ) {
                            alt23=1;
                        }
                        switch (alt23) {
                            case 1 :
                                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:236:18: expression
                                {
                                _last = (SLAST)input.LT(1);
                                pushFollow(FOLLOW_expression_in_topStatement588);
                                expression77=expression();

                                state._fsp--;

                                adaptor.addChild(root_1, expression77.getTree());

                                }
                                break;

                        }


                        match(input, Token.UP, null); 
                    }adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 9 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:237:5: ^( 'return' ( expression )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    string_literal78=(SLAST)match(input,95,FOLLOW_95_in_topStatement597); 
                    string_literal78_tree = (SLAST)adaptor.dupNode(string_literal78);

                    root_1 = (SLAST)adaptor.becomeRoot(string_literal78_tree, root_1);



                    if ( input.LA(1)==Token.DOWN ) {
                        match(input, Token.DOWN, null); 
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:237:16: ( expression )?
                        int alt24=2;
                        int LA24_0 = input.LA(1);

                        if ( (LA24_0==METHOD_DECL||LA24_0==VAR_DECL||LA24_0==CALL||LA24_0==EXPR||(LA24_0>=SCALAR && LA24_0<=ARRAY_DECL)||(LA24_0>=EQ && LA24_0<=BACKTRICKLITERAL)||(LA24_0>=126 && LA24_0<=169)) ) {
                            alt24=1;
                        }
                        switch (alt24) {
                            case 1 :
                                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:237:16: expression
                                {
                                _last = (SLAST)input.LT(1);
                                pushFollow(FOLLOW_expression_in_topStatement599);
                                expression79=expression();

                                state._fsp--;

                                adaptor.addChild(root_1, expression79.getTree());

                                }
                                break;

                        }


                        match(input, Token.UP, null); 
                    }adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 10 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:238:5: ^( 'global' variable )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    string_literal80=(SLAST)match(input,96,FOLLOW_96_in_topStatement608); 
                    string_literal80_tree = (SLAST)adaptor.dupNode(string_literal80);

                    root_1 = (SLAST)adaptor.becomeRoot(string_literal80_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_variable_in_topStatement610);
                    variable81=variable();

                    state._fsp--;

                    adaptor.addChild(root_1, variable81.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 11 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:239:5: ^( 'static' static_var_list )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    string_literal82=(SLAST)match(input,97,FOLLOW_97_in_topStatement618); 
                    string_literal82_tree = (SLAST)adaptor.dupNode(string_literal82);

                    root_1 = (SLAST)adaptor.becomeRoot(string_literal82_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_static_var_list_in_topStatement620);
                    static_var_list83=static_var_list();

                    state._fsp--;

                    adaptor.addChild(root_1, static_var_list83.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 12 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:240:5: ^( 'echo' expr_list )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    string_literal84=(SLAST)match(input,98,FOLLOW_98_in_topStatement628); 
                    string_literal84_tree = (SLAST)adaptor.dupNode(string_literal84);

                    root_1 = (SLAST)adaptor.becomeRoot(string_literal84_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expr_list_in_topStatement630);
                    expr_list85=expr_list();

                    state._fsp--;

                    adaptor.addChild(root_1, expr_list85.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 13 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:241:5: expression
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_topStatement637);
                    expression86=expression();

                    state._fsp--;

                    adaptor.addChild(root_0, expression86.getTree());

                         retval.expr = (expression86!=null?expression86.expr:null);
                         System.out.println("expr: " + retval.expr);
                      

                    }
                    break;
                case 14 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:246:5: ^( 'foreach' ^( 'as' expression foreach_variable ) foreach_statement )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    string_literal87=(SLAST)match(input,99,FOLLOW_99_in_topStatement648); 
                    string_literal87_tree = (SLAST)adaptor.dupNode(string_literal87);

                    root_1 = (SLAST)adaptor.becomeRoot(string_literal87_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_2 = _last;
                    SLAST _first_2 = null;
                    SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    string_literal88=(SLAST)match(input,100,FOLLOW_100_in_topStatement651); 
                    string_literal88_tree = (SLAST)adaptor.dupNode(string_literal88);

                    root_2 = (SLAST)adaptor.becomeRoot(string_literal88_tree, root_2);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_topStatement653);
                    expression89=expression();

                    state._fsp--;

                    adaptor.addChild(root_2, expression89.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_foreach_variable_in_topStatement655);
                    foreach_variable90=foreach_variable();

                    state._fsp--;

                    adaptor.addChild(root_2, foreach_variable90.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
                    }

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_foreach_statement_in_topStatement658);
                    foreach_statement91=foreach_statement();

                    state._fsp--;

                    adaptor.addChild(root_1, foreach_statement91.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 15 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:247:5: ^( 'declare' ^( CONDITION directive ) declare_statement )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    string_literal92=(SLAST)match(input,101,FOLLOW_101_in_topStatement666); 
                    string_literal92_tree = (SLAST)adaptor.dupNode(string_literal92);

                    root_1 = (SLAST)adaptor.becomeRoot(string_literal92_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_2 = _last;
                    SLAST _first_2 = null;
                    SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    CONDITION93=(SLAST)match(input,CONDITION,FOLLOW_CONDITION_in_topStatement669); 
                    CONDITION93_tree = (SLAST)adaptor.dupNode(CONDITION93);

                    root_2 = (SLAST)adaptor.becomeRoot(CONDITION93_tree, root_2);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_directive_in_topStatement671);
                    directive94=directive();

                    state._fsp--;

                    adaptor.addChild(root_2, directive94.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
                    }

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_declare_statement_in_topStatement674);
                    declare_statement95=declare_statement();

                    state._fsp--;

                    adaptor.addChild(root_1, declare_statement95.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 16 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:248:5: ^( 'try' ^( BLOCK top_statement ) ( catch_branch )+ )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    string_literal96=(SLAST)match(input,102,FOLLOW_102_in_topStatement682); 
                    string_literal96_tree = (SLAST)adaptor.dupNode(string_literal96);

                    root_1 = (SLAST)adaptor.becomeRoot(string_literal96_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_2 = _last;
                    SLAST _first_2 = null;
                    SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    BLOCK97=(SLAST)match(input,BLOCK,FOLLOW_BLOCK_in_topStatement685); 
                    BLOCK97_tree = (SLAST)adaptor.dupNode(BLOCK97);

                    root_2 = (SLAST)adaptor.becomeRoot(BLOCK97_tree, root_2);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_top_statement_in_topStatement687);
                    top_statement98=top_statement();

                    state._fsp--;

                    adaptor.addChild(root_2, top_statement98.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
                    }

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:248:36: ( catch_branch )+
                    int cnt25=0;
                    loop25:
                    do {
                        int alt25=2;
                        int LA25_0 = input.LA(1);

                        if ( (LA25_0==117) ) {
                            alt25=1;
                        }


                        switch (alt25) {
                    	case 1 :
                    	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:248:36: catch_branch
                    	    {
                    	    _last = (SLAST)input.LT(1);
                    	    pushFollow(FOLLOW_catch_branch_in_topStatement690);
                    	    catch_branch99=catch_branch();

                    	    state._fsp--;

                    	    adaptor.addChild(root_1, catch_branch99.getTree());

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt25 >= 1 ) break loop25;
                                EarlyExitException eee =
                                    new EarlyExitException(25, input);
                                throw eee;
                        }
                        cnt25++;
                    } while (true);


                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 17 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:249:5: ^( 'throw' expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    string_literal100=(SLAST)match(input,103,FOLLOW_103_in_topStatement699); 
                    string_literal100_tree = (SLAST)adaptor.dupNode(string_literal100);

                    root_1 = (SLAST)adaptor.becomeRoot(string_literal100_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_topStatement701);
                    expression101=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression101.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 18 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:250:5: ^( 'use' use_filename )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    string_literal102=(SLAST)match(input,104,FOLLOW_104_in_topStatement709); 
                    string_literal102_tree = (SLAST)adaptor.dupNode(string_literal102);

                    root_1 = (SLAST)adaptor.becomeRoot(string_literal102_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_use_filename_in_topStatement711);
                    use_filename103=use_filename();

                    state._fsp--;

                    adaptor.addChild(root_1, use_filename103.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "topStatement"

    public static class foreach_variable_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "foreach_variable"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:256:1: foreach_variable : ( ^( '=>' variable variable ) | variable );
    public final TreePHP.foreach_variable_return foreach_variable() throws RecognitionException {
        TreePHP.foreach_variable_return retval = new TreePHP.foreach_variable_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST string_literal104=null;
        TreePHP.variable_return variable105 = null;

        TreePHP.variable_return variable106 = null;

        TreePHP.variable_return variable107 = null;


        SLAST string_literal104_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:257:3: ( ^( '=>' variable variable ) | variable )
            int alt27=2;
            int LA27_0 = input.LA(1);

            if ( (LA27_0==105) ) {
                alt27=1;
            }
            else if ( (LA27_0==VAR_DECL||LA27_0==CALL) ) {
                alt27=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 27, 0, input);

                throw nvae;
            }
            switch (alt27) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:257:5: ^( '=>' variable variable )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    string_literal104=(SLAST)match(input,105,FOLLOW_105_in_foreach_variable731); 
                    string_literal104_tree = (SLAST)adaptor.dupNode(string_literal104);

                    root_1 = (SLAST)adaptor.becomeRoot(string_literal104_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_variable_in_foreach_variable733);
                    variable105=variable();

                    state._fsp--;

                    adaptor.addChild(root_1, variable105.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_variable_in_foreach_variable735);
                    variable106=variable();

                    state._fsp--;

                    adaptor.addChild(root_1, variable106.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:258:5: variable
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_variable_in_foreach_variable742);
                    variable107=variable();

                    state._fsp--;

                    adaptor.addChild(root_0, variable107.getTree());

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "foreach_variable"

    public static class use_filename_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "use_filename"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:261:1: use_filename : STRINGLITERAL ;
    public final TreePHP.use_filename_return use_filename() throws RecognitionException {
        TreePHP.use_filename_return retval = new TreePHP.use_filename_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST STRINGLITERAL108=null;

        SLAST STRINGLITERAL108_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:262:3: ( STRINGLITERAL )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:262:5: STRINGLITERAL
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            STRINGLITERAL108=(SLAST)match(input,STRINGLITERAL,FOLLOW_STRINGLITERAL_in_use_filename757); 
            STRINGLITERAL108_tree = (SLAST)adaptor.dupNode(STRINGLITERAL108);

            adaptor.addChild(root_0, STRINGLITERAL108_tree);


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "use_filename"

    public static class method_declaration_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "method_declaration"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:265:1: method_declaration : ^( METHOD_DECL ( '&' )? IDENTIFIER ( parameter_list )? ( block | EMPTYSTATEMENT ) ) ;
    public final TreePHP.method_declaration_return method_declaration() throws RecognitionException {
        TreePHP.method_declaration_return retval = new TreePHP.method_declaration_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST METHOD_DECL109=null;
        SLAST char_literal110=null;
        SLAST IDENTIFIER111=null;
        SLAST EMPTYSTATEMENT114=null;
        TreePHP.parameter_list_return parameter_list112 = null;

        TreePHP.block_return block113 = null;


        SLAST METHOD_DECL109_tree=null;
        SLAST char_literal110_tree=null;
        SLAST IDENTIFIER111_tree=null;
        SLAST EMPTYSTATEMENT114_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:266:3: ( ^( METHOD_DECL ( '&' )? IDENTIFIER ( parameter_list )? ( block | EMPTYSTATEMENT ) ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:266:5: ^( METHOD_DECL ( '&' )? IDENTIFIER ( parameter_list )? ( block | EMPTYSTATEMENT ) )
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_1 = _last;
            SLAST _first_1 = null;
            SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            METHOD_DECL109=(SLAST)match(input,METHOD_DECL,FOLLOW_METHOD_DECL_in_method_declaration773); 
            METHOD_DECL109_tree = (SLAST)adaptor.dupNode(METHOD_DECL109);

            root_1 = (SLAST)adaptor.becomeRoot(METHOD_DECL109_tree, root_1);



            match(input, Token.DOWN, null); 
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:266:19: ( '&' )?
            int alt28=2;
            int LA28_0 = input.LA(1);

            if ( (LA28_0==BIT_AND) ) {
                alt28=1;
            }
            switch (alt28) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:266:19: '&'
                    {
                    _last = (SLAST)input.LT(1);
                    char_literal110=(SLAST)match(input,BIT_AND,FOLLOW_BIT_AND_in_method_declaration775); 
                    char_literal110_tree = (SLAST)adaptor.dupNode(char_literal110);

                    adaptor.addChild(root_1, char_literal110_tree);


                    }
                    break;

            }

            _last = (SLAST)input.LT(1);
            IDENTIFIER111=(SLAST)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_method_declaration778); 
            IDENTIFIER111_tree = (SLAST)adaptor.dupNode(IDENTIFIER111);

            adaptor.addChild(root_1, IDENTIFIER111_tree);

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:266:35: ( parameter_list )?
            int alt29=2;
            int LA29_0 = input.LA(1);

            if ( (LA29_0==PARAMETER) ) {
                alt29=1;
            }
            switch (alt29) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:266:35: parameter_list
                    {
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_parameter_list_in_method_declaration780);
                    parameter_list112=parameter_list();

                    state._fsp--;

                    adaptor.addChild(root_1, parameter_list112.getTree());

                    }
                    break;

            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:266:51: ( block | EMPTYSTATEMENT )
            int alt30=2;
            int LA30_0 = input.LA(1);

            if ( (LA30_0==BLOCK) ) {
                alt30=1;
            }
            else if ( (LA30_0==EMPTYSTATEMENT) ) {
                alt30=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 30, 0, input);

                throw nvae;
            }
            switch (alt30) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:266:52: block
                    {
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_block_in_method_declaration784);
                    block113=block();

                    state._fsp--;

                    adaptor.addChild(root_1, block113.getTree());

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:266:59: EMPTYSTATEMENT
                    {
                    _last = (SLAST)input.LT(1);
                    EMPTYSTATEMENT114=(SLAST)match(input,EMPTYSTATEMENT,FOLLOW_EMPTYSTATEMENT_in_method_declaration787); 
                    EMPTYSTATEMENT114_tree = (SLAST)adaptor.dupNode(EMPTYSTATEMENT114);

                    adaptor.addChild(root_1, EMPTYSTATEMENT114_tree);


                    }
                    break;

            }


            match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "method_declaration"

    public static class fully_qualified_class_name_list_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "fully_qualified_class_name_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:279:1: fully_qualified_class_name_list : ( fully_qualified_class_name )+ ;
    public final TreePHP.fully_qualified_class_name_list_return fully_qualified_class_name_list() throws RecognitionException {
        TreePHP.fully_qualified_class_name_list_return retval = new TreePHP.fully_qualified_class_name_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.fully_qualified_class_name_return fully_qualified_class_name115 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:280:3: ( ( fully_qualified_class_name )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:280:5: ( fully_qualified_class_name )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:280:5: ( fully_qualified_class_name )+
            int cnt31=0;
            loop31:
            do {
                int alt31=2;
                int LA31_0 = input.LA(1);

                if ( (LA31_0==IDENTIFIER) ) {
                    alt31=1;
                }


                switch (alt31) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:280:5: fully_qualified_class_name
            	    {
            	    _last = (SLAST)input.LT(1);
            	    pushFollow(FOLLOW_fully_qualified_class_name_in_fully_qualified_class_name_list816);
            	    fully_qualified_class_name115=fully_qualified_class_name();

            	    state._fsp--;

            	    adaptor.addChild(root_0, fully_qualified_class_name115.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt31 >= 1 ) break loop31;
                        EarlyExitException eee =
                            new EarlyExitException(31, input);
                        throw eee;
                }
                cnt31++;
            } while (true);


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "fully_qualified_class_name_list"

    public static class fully_qualified_class_name_return extends TreeRuleReturnScope {
        public TypeReference name;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "fully_qualified_class_name"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:283:1: fully_qualified_class_name returns [TypeReference name] : IDENTIFIER ( '::' IDENTIFIER )* ( '::' )? ;
    public final TreePHP.fully_qualified_class_name_return fully_qualified_class_name() throws RecognitionException {
        TreePHP.fully_qualified_class_name_return retval = new TreePHP.fully_qualified_class_name_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST IDENTIFIER116=null;
        SLAST string_literal117=null;
        SLAST IDENTIFIER118=null;
        SLAST string_literal119=null;

        SLAST IDENTIFIER116_tree=null;
        SLAST string_literal117_tree=null;
        SLAST IDENTIFIER118_tree=null;
        SLAST string_literal119_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:284:3: ( IDENTIFIER ( '::' IDENTIFIER )* ( '::' )? )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:284:5: IDENTIFIER ( '::' IDENTIFIER )* ( '::' )?
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            IDENTIFIER116=(SLAST)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_fully_qualified_class_name836); 
            IDENTIFIER116_tree = (SLAST)adaptor.dupNode(IDENTIFIER116);

            adaptor.addChild(root_0, IDENTIFIER116_tree);

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:284:16: ( '::' IDENTIFIER )*
            loop32:
            do {
                int alt32=2;
                int LA32_0 = input.LA(1);

                if ( (LA32_0==108) ) {
                    int LA32_1 = input.LA(2);

                    if ( (LA32_1==IDENTIFIER) ) {
                        alt32=1;
                    }


                }


                switch (alt32) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:284:17: '::' IDENTIFIER
            	    {
            	    _last = (SLAST)input.LT(1);
            	    string_literal117=(SLAST)match(input,108,FOLLOW_108_in_fully_qualified_class_name839); 
            	    string_literal117_tree = (SLAST)adaptor.dupNode(string_literal117);

            	    root_0 = (SLAST)adaptor.becomeRoot(string_literal117_tree, root_0);

            	    _last = (SLAST)input.LT(1);
            	    IDENTIFIER118=(SLAST)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_fully_qualified_class_name842); 
            	    IDENTIFIER118_tree = (SLAST)adaptor.dupNode(IDENTIFIER118);

            	    adaptor.addChild(root_0, IDENTIFIER118_tree);


            	    }
            	    break;

            	default :
            	    break loop32;
                }
            } while (true);

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:284:36: ( '::' )?
            int alt33=2;
            int LA33_0 = input.LA(1);

            if ( (LA33_0==108) ) {
                alt33=1;
            }
            switch (alt33) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:284:36: '::'
                    {
                    _last = (SLAST)input.LT(1);
                    string_literal119=(SLAST)match(input,108,FOLLOW_108_in_fully_qualified_class_name846); 
                    string_literal119_tree = (SLAST)adaptor.dupNode(string_literal119);

                    adaptor.addChild(root_0, string_literal119_tree);


                    }
                    break;

            }


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "fully_qualified_class_name"

    public static class static_array_pair_list_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "static_array_pair_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:291:1: static_array_pair_list : ( ^( SCALAR_ELEMENT static_scalar_element ) )+ ;
    public final TreePHP.static_array_pair_list_return static_array_pair_list() throws RecognitionException {
        TreePHP.static_array_pair_list_return retval = new TreePHP.static_array_pair_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST SCALAR_ELEMENT120=null;
        TreePHP.static_scalar_element_return static_scalar_element121 = null;


        SLAST SCALAR_ELEMENT120_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:292:3: ( ( ^( SCALAR_ELEMENT static_scalar_element ) )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:292:5: ( ^( SCALAR_ELEMENT static_scalar_element ) )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:292:5: ( ^( SCALAR_ELEMENT static_scalar_element ) )+
            int cnt34=0;
            loop34:
            do {
                int alt34=2;
                int LA34_0 = input.LA(1);

                if ( (LA34_0==SCALAR_ELEMENT) ) {
                    alt34=1;
                }


                switch (alt34) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:292:6: ^( SCALAR_ELEMENT static_scalar_element )
            	    {
            	    _last = (SLAST)input.LT(1);
            	    {
            	    SLAST _save_last_1 = _last;
            	    SLAST _first_1 = null;
            	    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            	    SCALAR_ELEMENT120=(SLAST)match(input,SCALAR_ELEMENT,FOLLOW_SCALAR_ELEMENT_in_static_array_pair_list870); 
            	    SCALAR_ELEMENT120_tree = (SLAST)adaptor.dupNode(SCALAR_ELEMENT120);

            	    root_1 = (SLAST)adaptor.becomeRoot(SCALAR_ELEMENT120_tree, root_1);



            	    match(input, Token.DOWN, null); 
            	    _last = (SLAST)input.LT(1);
            	    pushFollow(FOLLOW_static_scalar_element_in_static_array_pair_list872);
            	    static_scalar_element121=static_scalar_element();

            	    state._fsp--;

            	    adaptor.addChild(root_1, static_scalar_element121.getTree());

            	    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt34 >= 1 ) break loop34;
                        EarlyExitException eee =
                            new EarlyExitException(34, input);
                        throw eee;
                }
                cnt34++;
            } while (true);


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "static_array_pair_list"

    public static class static_scalar_element_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "static_scalar_element"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:295:1: static_scalar_element : scalar ( '=>' scalar )? ;
    public final TreePHP.static_scalar_element_return static_scalar_element() throws RecognitionException {
        TreePHP.static_scalar_element_return retval = new TreePHP.static_scalar_element_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST string_literal123=null;
        TreePHP.scalar_return scalar122 = null;

        TreePHP.scalar_return scalar124 = null;


        SLAST string_literal123_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:296:3: ( scalar ( '=>' scalar )? )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:296:5: scalar ( '=>' scalar )?
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            pushFollow(FOLLOW_scalar_in_static_scalar_element889);
            scalar122=scalar();

            state._fsp--;

            adaptor.addChild(root_0, scalar122.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:296:12: ( '=>' scalar )?
            int alt35=2;
            int LA35_0 = input.LA(1);

            if ( (LA35_0==105) ) {
                alt35=1;
            }
            switch (alt35) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:296:13: '=>' scalar
                    {
                    _last = (SLAST)input.LT(1);
                    string_literal123=(SLAST)match(input,105,FOLLOW_105_in_static_scalar_element892); 
                    string_literal123_tree = (SLAST)adaptor.dupNode(string_literal123);

                    root_0 = (SLAST)adaptor.becomeRoot(string_literal123_tree, root_0);

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_scalar_in_static_scalar_element895);
                    scalar124=scalar();

                    state._fsp--;

                    adaptor.addChild(root_0, scalar124.getTree());

                    }
                    break;

            }


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "static_scalar_element"

    public static class static_var_list_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "static_var_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:299:1: static_var_list : ( ^( SCALAR_VAR static_var_element ) )+ ;
    public final TreePHP.static_var_list_return static_var_list() throws RecognitionException {
        TreePHP.static_var_list_return retval = new TreePHP.static_var_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST SCALAR_VAR125=null;
        TreePHP.static_var_element_return static_var_element126 = null;


        SLAST SCALAR_VAR125_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:300:3: ( ( ^( SCALAR_VAR static_var_element ) )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:300:5: ( ^( SCALAR_VAR static_var_element ) )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:300:5: ( ^( SCALAR_VAR static_var_element ) )+
            int cnt36=0;
            loop36:
            do {
                int alt36=2;
                int LA36_0 = input.LA(1);

                if ( (LA36_0==SCALAR_VAR) ) {
                    alt36=1;
                }


                switch (alt36) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:300:6: ^( SCALAR_VAR static_var_element )
            	    {
            	    _last = (SLAST)input.LT(1);
            	    {
            	    SLAST _save_last_1 = _last;
            	    SLAST _first_1 = null;
            	    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            	    SCALAR_VAR125=(SLAST)match(input,SCALAR_VAR,FOLLOW_SCALAR_VAR_in_static_var_list914); 
            	    SCALAR_VAR125_tree = (SLAST)adaptor.dupNode(SCALAR_VAR125);

            	    root_1 = (SLAST)adaptor.becomeRoot(SCALAR_VAR125_tree, root_1);



            	    match(input, Token.DOWN, null); 
            	    _last = (SLAST)input.LT(1);
            	    pushFollow(FOLLOW_static_var_element_in_static_var_list916);
            	    static_var_element126=static_var_element();

            	    state._fsp--;

            	    adaptor.addChild(root_1, static_var_element126.getTree());

            	    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt36 >= 1 ) break loop36;
                        EarlyExitException eee =
                            new EarlyExitException(36, input);
                        throw eee;
                }
                cnt36++;
            } while (true);


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "static_var_list"

    public static class static_var_element_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "static_var_element"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:303:1: static_var_element : pure_variable ( '=' scalar )? ;
    public final TreePHP.static_var_element_return static_var_element() throws RecognitionException {
        TreePHP.static_var_element_return retval = new TreePHP.static_var_element_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST char_literal128=null;
        TreePHP.pure_variable_return pure_variable127 = null;

        TreePHP.scalar_return scalar129 = null;


        SLAST char_literal128_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:304:3: ( pure_variable ( '=' scalar )? )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:304:5: pure_variable ( '=' scalar )?
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            pushFollow(FOLLOW_pure_variable_in_static_var_element932);
            pure_variable127=pure_variable();

            state._fsp--;

            adaptor.addChild(root_0, pure_variable127.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:304:19: ( '=' scalar )?
            int alt37=2;
            int LA37_0 = input.LA(1);

            if ( (LA37_0==EQ) ) {
                alt37=1;
            }
            switch (alt37) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:304:20: '=' scalar
                    {
                    _last = (SLAST)input.LT(1);
                    char_literal128=(SLAST)match(input,EQ,FOLLOW_EQ_in_static_var_element935); 
                    char_literal128_tree = (SLAST)adaptor.dupNode(char_literal128);

                    root_0 = (SLAST)adaptor.becomeRoot(char_literal128_tree, root_0);

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_scalar_in_static_var_element938);
                    scalar129=scalar();

                    state._fsp--;

                    adaptor.addChild(root_0, scalar129.getTree());

                    }
                    break;

            }


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "static_var_element"

    public static class if_stat_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "if_stat"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:307:1: if_stat : ^( 'if' ^( CONDITION expression ) ( ( inner_statement_list )? ( ^( 'elseif' ^( CONDITION expression ) ( inner_statement_list )? ) )* ( ^( 'else' statement ) )? ) ) ;
    public final TreePHP.if_stat_return if_stat() throws RecognitionException {
        TreePHP.if_stat_return retval = new TreePHP.if_stat_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST string_literal130=null;
        SLAST CONDITION131=null;
        SLAST string_literal134=null;
        SLAST CONDITION135=null;
        SLAST string_literal138=null;
        TreePHP.expression_return expression132 = null;

        TreePHP.inner_statement_list_return inner_statement_list133 = null;

        TreePHP.expression_return expression136 = null;

        TreePHP.inner_statement_list_return inner_statement_list137 = null;

        TreePHP.statement_return statement139 = null;


        SLAST string_literal130_tree=null;
        SLAST CONDITION131_tree=null;
        SLAST string_literal134_tree=null;
        SLAST CONDITION135_tree=null;
        SLAST string_literal138_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:308:3: ( ^( 'if' ^( CONDITION expression ) ( ( inner_statement_list )? ( ^( 'elseif' ^( CONDITION expression ) ( inner_statement_list )? ) )* ( ^( 'else' statement ) )? ) ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:308:5: ^( 'if' ^( CONDITION expression ) ( ( inner_statement_list )? ( ^( 'elseif' ^( CONDITION expression ) ( inner_statement_list )? ) )* ( ^( 'else' statement ) )? ) )
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_1 = _last;
            SLAST _first_1 = null;
            SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            string_literal130=(SLAST)match(input,109,FOLLOW_109_in_if_stat956); 
            string_literal130_tree = (SLAST)adaptor.dupNode(string_literal130);

            root_1 = (SLAST)adaptor.becomeRoot(string_literal130_tree, root_1);



            match(input, Token.DOWN, null); 
            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_2 = _last;
            SLAST _first_2 = null;
            SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            CONDITION131=(SLAST)match(input,CONDITION,FOLLOW_CONDITION_in_if_stat959); 
            CONDITION131_tree = (SLAST)adaptor.dupNode(CONDITION131);

            root_2 = (SLAST)adaptor.becomeRoot(CONDITION131_tree, root_2);



            match(input, Token.DOWN, null); 
            _last = (SLAST)input.LT(1);
            pushFollow(FOLLOW_expression_in_if_stat961);
            expression132=expression();

            state._fsp--;

            adaptor.addChild(root_2, expression132.getTree());

            match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:309:5: ( ( inner_statement_list )? ( ^( 'elseif' ^( CONDITION expression ) ( inner_statement_list )? ) )* ( ^( 'else' statement ) )? )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:310:7: ( inner_statement_list )? ( ^( 'elseif' ^( CONDITION expression ) ( inner_statement_list )? ) )* ( ^( 'else' statement ) )?
            {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:310:7: ( inner_statement_list )?
            int alt38=2;
            int LA38_0 = input.LA(1);

            if ( (LA38_0==STATEMENT||LA38_0==CLASS_T||LA38_0==81||LA38_0==85||LA38_0==88) ) {
                alt38=1;
            }
            switch (alt38) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:310:7: inner_statement_list
                    {
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_inner_statement_list_in_if_stat977);
                    inner_statement_list133=inner_statement_list();

                    state._fsp--;

                    adaptor.addChild(root_1, inner_statement_list133.getTree());

                    }
                    break;

            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:311:7: ( ^( 'elseif' ^( CONDITION expression ) ( inner_statement_list )? ) )*
            loop40:
            do {
                int alt40=2;
                int LA40_0 = input.LA(1);

                if ( (LA40_0==110) ) {
                    alt40=1;
                }


                switch (alt40) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:311:8: ^( 'elseif' ^( CONDITION expression ) ( inner_statement_list )? )
            	    {
            	    _last = (SLAST)input.LT(1);
            	    {
            	    SLAST _save_last_2 = _last;
            	    SLAST _first_2 = null;
            	    SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            	    string_literal134=(SLAST)match(input,110,FOLLOW_110_in_if_stat988); 
            	    string_literal134_tree = (SLAST)adaptor.dupNode(string_literal134);

            	    root_2 = (SLAST)adaptor.becomeRoot(string_literal134_tree, root_2);



            	    match(input, Token.DOWN, null); 
            	    _last = (SLAST)input.LT(1);
            	    {
            	    SLAST _save_last_3 = _last;
            	    SLAST _first_3 = null;
            	    SLAST root_3 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            	    CONDITION135=(SLAST)match(input,CONDITION,FOLLOW_CONDITION_in_if_stat991); 
            	    CONDITION135_tree = (SLAST)adaptor.dupNode(CONDITION135);

            	    root_3 = (SLAST)adaptor.becomeRoot(CONDITION135_tree, root_3);



            	    match(input, Token.DOWN, null); 
            	    _last = (SLAST)input.LT(1);
            	    pushFollow(FOLLOW_expression_in_if_stat993);
            	    expression136=expression();

            	    state._fsp--;

            	    adaptor.addChild(root_3, expression136.getTree());

            	    match(input, Token.UP, null); adaptor.addChild(root_2, root_3);_last = _save_last_3;
            	    }

            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:311:43: ( inner_statement_list )?
            	    int alt39=2;
            	    int LA39_0 = input.LA(1);

            	    if ( (LA39_0==STATEMENT||LA39_0==CLASS_T||LA39_0==81||LA39_0==85||LA39_0==88) ) {
            	        alt39=1;
            	    }
            	    switch (alt39) {
            	        case 1 :
            	            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:311:43: inner_statement_list
            	            {
            	            _last = (SLAST)input.LT(1);
            	            pushFollow(FOLLOW_inner_statement_list_in_if_stat996);
            	            inner_statement_list137=inner_statement_list();

            	            state._fsp--;

            	            adaptor.addChild(root_2, inner_statement_list137.getTree());

            	            }
            	            break;

            	    }


            	    match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
            	    }


            	    }
            	    break;

            	default :
            	    break loop40;
                }
            } while (true);

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:311:68: ( ^( 'else' statement ) )?
            int alt41=2;
            int LA41_0 = input.LA(1);

            if ( (LA41_0==111) ) {
                alt41=1;
            }
            switch (alt41) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:311:69: ^( 'else' statement )
                    {
                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_2 = _last;
                    SLAST _first_2 = null;
                    SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    string_literal138=(SLAST)match(input,111,FOLLOW_111_in_if_stat1004); 
                    string_literal138_tree = (SLAST)adaptor.dupNode(string_literal138);

                    root_2 = (SLAST)adaptor.becomeRoot(string_literal138_tree, root_2);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_statement_in_if_stat1006);
                    statement139=statement();

                    state._fsp--;

                    adaptor.addChild(root_2, statement139.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
                    }


                    }
                    break;

            }


            }


            match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "if_stat"

    public static class switch_case_list_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "switch_case_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:316:1: switch_case_list : ( case_list )+ ;
    public final TreePHP.switch_case_list_return switch_case_list() throws RecognitionException {
        TreePHP.switch_case_list_return retval = new TreePHP.switch_case_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.case_list_return case_list140 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:317:3: ( ( case_list )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:317:5: ( case_list )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:317:5: ( case_list )+
            int cnt42=0;
            loop42:
            do {
                int alt42=2;
                int LA42_0 = input.LA(1);

                if ( ((LA42_0>=115 && LA42_0<=116)) ) {
                    alt42=1;
                }


                switch (alt42) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:317:5: case_list
            	    {
            	    _last = (SLAST)input.LT(1);
            	    pushFollow(FOLLOW_case_list_in_switch_case_list1031);
            	    case_list140=case_list();

            	    state._fsp--;

            	    adaptor.addChild(root_0, case_list140.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt42 >= 1 ) break loop42;
                        EarlyExitException eee =
                            new EarlyExitException(42, input);
                        throw eee;
                }
                cnt42++;
            } while (true);


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "switch_case_list"

    public static class case_list_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "case_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:320:1: case_list : ( ^( 'case' expression ( inner_statement_list )? ) | ^( 'default' ( inner_statement_list )? ) );
    public final TreePHP.case_list_return case_list() throws RecognitionException {
        TreePHP.case_list_return retval = new TreePHP.case_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST string_literal141=null;
        SLAST string_literal144=null;
        TreePHP.expression_return expression142 = null;

        TreePHP.inner_statement_list_return inner_statement_list143 = null;

        TreePHP.inner_statement_list_return inner_statement_list145 = null;


        SLAST string_literal141_tree=null;
        SLAST string_literal144_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:321:3: ( ^( 'case' expression ( inner_statement_list )? ) | ^( 'default' ( inner_statement_list )? ) )
            int alt45=2;
            int LA45_0 = input.LA(1);

            if ( (LA45_0==115) ) {
                alt45=1;
            }
            else if ( (LA45_0==116) ) {
                alt45=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 45, 0, input);

                throw nvae;
            }
            switch (alt45) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:321:5: ^( 'case' expression ( inner_statement_list )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    string_literal141=(SLAST)match(input,115,FOLLOW_115_in_case_list1046); 
                    string_literal141_tree = (SLAST)adaptor.dupNode(string_literal141);

                    root_1 = (SLAST)adaptor.becomeRoot(string_literal141_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_case_list1048);
                    expression142=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression142.getTree());
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:321:25: ( inner_statement_list )?
                    int alt43=2;
                    int LA43_0 = input.LA(1);

                    if ( (LA43_0==STATEMENT||LA43_0==CLASS_T||LA43_0==81||LA43_0==85||LA43_0==88) ) {
                        alt43=1;
                    }
                    switch (alt43) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:321:25: inner_statement_list
                            {
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_inner_statement_list_in_case_list1050);
                            inner_statement_list143=inner_statement_list();

                            state._fsp--;

                            adaptor.addChild(root_1, inner_statement_list143.getTree());

                            }
                            break;

                    }


                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:322:5: ^( 'default' ( inner_statement_list )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    string_literal144=(SLAST)match(input,116,FOLLOW_116_in_case_list1059); 
                    string_literal144_tree = (SLAST)adaptor.dupNode(string_literal144);

                    root_1 = (SLAST)adaptor.becomeRoot(string_literal144_tree, root_1);



                    if ( input.LA(1)==Token.DOWN ) {
                        match(input, Token.DOWN, null); 
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:322:17: ( inner_statement_list )?
                        int alt44=2;
                        int LA44_0 = input.LA(1);

                        if ( (LA44_0==STATEMENT||LA44_0==CLASS_T||LA44_0==81||LA44_0==85||LA44_0==88) ) {
                            alt44=1;
                        }
                        switch (alt44) {
                            case 1 :
                                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:322:17: inner_statement_list
                                {
                                _last = (SLAST)input.LT(1);
                                pushFollow(FOLLOW_inner_statement_list_in_case_list1061);
                                inner_statement_list145=inner_statement_list();

                                state._fsp--;

                                adaptor.addChild(root_1, inner_statement_list145.getTree());

                                }
                                break;

                        }


                        match(input, Token.UP, null); 
                    }adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "case_list"

    public static class catch_branch_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "catch_branch"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:325:1: catch_branch : ^( 'catch' IDENTIFIER variable block ) ;
    public final TreePHP.catch_branch_return catch_branch() throws RecognitionException {
        TreePHP.catch_branch_return retval = new TreePHP.catch_branch_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST string_literal146=null;
        SLAST IDENTIFIER147=null;
        TreePHP.variable_return variable148 = null;

        TreePHP.block_return block149 = null;


        SLAST string_literal146_tree=null;
        SLAST IDENTIFIER147_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:326:3: ( ^( 'catch' IDENTIFIER variable block ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:326:5: ^( 'catch' IDENTIFIER variable block )
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_1 = _last;
            SLAST _first_1 = null;
            SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            string_literal146=(SLAST)match(input,117,FOLLOW_117_in_catch_branch1078); 
            string_literal146_tree = (SLAST)adaptor.dupNode(string_literal146);

            root_1 = (SLAST)adaptor.becomeRoot(string_literal146_tree, root_1);



            match(input, Token.DOWN, null); 
            _last = (SLAST)input.LT(1);
            IDENTIFIER147=(SLAST)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_catch_branch1080); 
            IDENTIFIER147_tree = (SLAST)adaptor.dupNode(IDENTIFIER147);

            adaptor.addChild(root_1, IDENTIFIER147_tree);

            _last = (SLAST)input.LT(1);
            pushFollow(FOLLOW_variable_in_catch_branch1082);
            variable148=variable();

            state._fsp--;

            adaptor.addChild(root_1, variable148.getTree());
            _last = (SLAST)input.LT(1);
            pushFollow(FOLLOW_block_in_catch_branch1084);
            block149=block();

            state._fsp--;

            adaptor.addChild(root_1, block149.getTree());

            match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "catch_branch"

    public static class for_statement_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "for_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:329:1: for_statement : ( inner_statement_list )? ;
    public final TreePHP.for_statement_return for_statement() throws RecognitionException {
        TreePHP.for_statement_return retval = new TreePHP.for_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.inner_statement_list_return inner_statement_list150 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:330:2: ( ( inner_statement_list )? )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:330:4: ( inner_statement_list )?
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:330:4: ( inner_statement_list )?
            int alt46=2;
            int LA46_0 = input.LA(1);

            if ( (LA46_0==STATEMENT||LA46_0==CLASS_T||LA46_0==81||LA46_0==85||LA46_0==88) ) {
                alt46=1;
            }
            switch (alt46) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:330:4: inner_statement_list
                    {
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_inner_statement_list_in_for_statement1097);
                    inner_statement_list150=inner_statement_list();

                    state._fsp--;

                    adaptor.addChild(root_0, inner_statement_list150.getTree());

                    }
                    break;

            }


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "for_statement"

    public static class while_statement_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "while_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:333:1: while_statement : ( inner_statement_list )? ;
    public final TreePHP.while_statement_return while_statement() throws RecognitionException {
        TreePHP.while_statement_return retval = new TreePHP.while_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.inner_statement_list_return inner_statement_list151 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:334:2: ( ( inner_statement_list )? )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:334:4: ( inner_statement_list )?
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:334:4: ( inner_statement_list )?
            int alt47=2;
            int LA47_0 = input.LA(1);

            if ( (LA47_0==STATEMENT||LA47_0==CLASS_T||LA47_0==81||LA47_0==85||LA47_0==88) ) {
                alt47=1;
            }
            switch (alt47) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:334:4: inner_statement_list
                    {
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_inner_statement_list_in_while_statement1110);
                    inner_statement_list151=inner_statement_list();

                    state._fsp--;

                    adaptor.addChild(root_0, inner_statement_list151.getTree());

                    }
                    break;

            }


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "while_statement"

    public static class foreach_statement_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "foreach_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:337:1: foreach_statement : ( inner_statement_list )? ;
    public final TreePHP.foreach_statement_return foreach_statement() throws RecognitionException {
        TreePHP.foreach_statement_return retval = new TreePHP.foreach_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.inner_statement_list_return inner_statement_list152 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:338:3: ( ( inner_statement_list )? )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:338:5: ( inner_statement_list )?
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:338:5: ( inner_statement_list )?
            int alt48=2;
            int LA48_0 = input.LA(1);

            if ( (LA48_0==STATEMENT||LA48_0==CLASS_T||LA48_0==81||LA48_0==85||LA48_0==88) ) {
                alt48=1;
            }
            switch (alt48) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:338:5: inner_statement_list
                    {
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_inner_statement_list_in_foreach_statement1124);
                    inner_statement_list152=inner_statement_list();

                    state._fsp--;

                    adaptor.addChild(root_0, inner_statement_list152.getTree());

                    }
                    break;

            }


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "foreach_statement"

    public static class declare_statement_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "declare_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:341:1: declare_statement : ( inner_statement_list )? ;
    public final TreePHP.declare_statement_return declare_statement() throws RecognitionException {
        TreePHP.declare_statement_return retval = new TreePHP.declare_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.inner_statement_list_return inner_statement_list153 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:342:3: ( ( inner_statement_list )? )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:342:5: ( inner_statement_list )?
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:342:5: ( inner_statement_list )?
            int alt49=2;
            int LA49_0 = input.LA(1);

            if ( (LA49_0==STATEMENT||LA49_0==CLASS_T||LA49_0==81||LA49_0==85||LA49_0==88) ) {
                alt49=1;
            }
            switch (alt49) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:342:5: inner_statement_list
                    {
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_inner_statement_list_in_declare_statement1140);
                    inner_statement_list153=inner_statement_list();

                    state._fsp--;

                    adaptor.addChild(root_0, inner_statement_list153.getTree());

                    }
                    break;

            }


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "declare_statement"

    public static class parameter_list_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "parameter_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:345:1: parameter_list : ( parameter )+ ;
    public final TreePHP.parameter_list_return parameter_list() throws RecognitionException {
        TreePHP.parameter_list_return retval = new TreePHP.parameter_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.parameter_return parameter154 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:346:3: ( ( parameter )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:346:5: ( parameter )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:346:5: ( parameter )+
            int cnt50=0;
            loop50:
            do {
                int alt50=2;
                int LA50_0 = input.LA(1);

                if ( (LA50_0==PARAMETER) ) {
                    alt50=1;
                }


                switch (alt50) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:346:5: parameter
            	    {
            	    _last = (SLAST)input.LT(1);
            	    pushFollow(FOLLOW_parameter_in_parameter_list1156);
            	    parameter154=parameter();

            	    state._fsp--;

            	    adaptor.addChild(root_0, parameter154.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt50 >= 1 ) break loop50;
                        EarlyExitException eee =
                            new EarlyExitException(50, input);
                        throw eee;
                }
                cnt50++;
            } while (true);


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "parameter_list"

    public static class parameter_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "parameter"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:349:1: parameter : ^( PARAMETER ( ^( TYPE parameter_type ) )? ( 'const' )? pure_variable ( scalar )? ) ;
    public final TreePHP.parameter_return parameter() throws RecognitionException {
        TreePHP.parameter_return retval = new TreePHP.parameter_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST PARAMETER155=null;
        SLAST TYPE156=null;
        SLAST string_literal158=null;
        TreePHP.parameter_type_return parameter_type157 = null;

        TreePHP.pure_variable_return pure_variable159 = null;

        TreePHP.scalar_return scalar160 = null;


        SLAST PARAMETER155_tree=null;
        SLAST TYPE156_tree=null;
        SLAST string_literal158_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:350:3: ( ^( PARAMETER ( ^( TYPE parameter_type ) )? ( 'const' )? pure_variable ( scalar )? ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:350:5: ^( PARAMETER ( ^( TYPE parameter_type ) )? ( 'const' )? pure_variable ( scalar )? )
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_1 = _last;
            SLAST _first_1 = null;
            SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            PARAMETER155=(SLAST)match(input,PARAMETER,FOLLOW_PARAMETER_in_parameter1173); 
            PARAMETER155_tree = (SLAST)adaptor.dupNode(PARAMETER155);

            root_1 = (SLAST)adaptor.becomeRoot(PARAMETER155_tree, root_1);



            match(input, Token.DOWN, null); 
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:350:17: ( ^( TYPE parameter_type ) )?
            int alt51=2;
            int LA51_0 = input.LA(1);

            if ( (LA51_0==TYPE) ) {
                alt51=1;
            }
            switch (alt51) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:350:18: ^( TYPE parameter_type )
                    {
                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_2 = _last;
                    SLAST _first_2 = null;
                    SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    TYPE156=(SLAST)match(input,TYPE,FOLLOW_TYPE_in_parameter1177); 
                    TYPE156_tree = (SLAST)adaptor.dupNode(TYPE156);

                    root_2 = (SLAST)adaptor.becomeRoot(TYPE156_tree, root_2);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_parameter_type_in_parameter1179);
                    parameter_type157=parameter_type();

                    state._fsp--;

                    adaptor.addChild(root_2, parameter_type157.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
                    }


                    }
                    break;

            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:350:43: ( 'const' )?
            int alt52=2;
            int LA52_0 = input.LA(1);

            if ( (LA52_0==106) ) {
                alt52=1;
            }
            switch (alt52) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:350:43: 'const'
                    {
                    _last = (SLAST)input.LT(1);
                    string_literal158=(SLAST)match(input,106,FOLLOW_106_in_parameter1184); 
                    string_literal158_tree = (SLAST)adaptor.dupNode(string_literal158);

                    adaptor.addChild(root_1, string_literal158_tree);


                    }
                    break;

            }

            _last = (SLAST)input.LT(1);
            pushFollow(FOLLOW_pure_variable_in_parameter1187);
            pure_variable159=pure_variable();

            state._fsp--;

            adaptor.addChild(root_1, pure_variable159.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:350:66: ( scalar )?
            int alt53=2;
            int LA53_0 = input.LA(1);

            if ( (LA53_0==SCALAR) ) {
                alt53=1;
            }
            switch (alt53) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:350:66: scalar
                    {
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_scalar_in_parameter1189);
                    scalar160=scalar();

                    state._fsp--;

                    adaptor.addChild(root_1, scalar160.getTree());

                    }
                    break;

            }


            match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "parameter"

    public static class parameter_type_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "parameter_type"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:353:1: parameter_type : ( fully_qualified_class_name | cast_option );
    public final TreePHP.parameter_type_return parameter_type() throws RecognitionException {
        TreePHP.parameter_type_return retval = new TreePHP.parameter_type_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.fully_qualified_class_name_return fully_qualified_class_name161 = null;

        TreePHP.cast_option_return cast_option162 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:354:3: ( fully_qualified_class_name | cast_option )
            int alt54=2;
            int LA54_0 = input.LA(1);

            if ( (LA54_0==IDENTIFIER) ) {
                alt54=1;
            }
            else if ( ((LA54_0>=150 && LA54_0<=160)) ) {
                alt54=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 54, 0, input);

                throw nvae;
            }
            switch (alt54) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:354:5: fully_qualified_class_name
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_fully_qualified_class_name_in_parameter_type1206);
                    fully_qualified_class_name161=fully_qualified_class_name();

                    state._fsp--;

                    adaptor.addChild(root_0, fully_qualified_class_name161.getTree());

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:354:34: cast_option
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_cast_option_in_parameter_type1210);
                    cast_option162=cast_option();

                    state._fsp--;

                    adaptor.addChild(root_0, cast_option162.getTree());

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "parameter_type"

    public static class variable_modifiers_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "variable_modifiers"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:363:1: variable_modifiers : ( 'var' | modifier );
    public final TreePHP.variable_modifiers_return variable_modifiers() throws RecognitionException {
        TreePHP.variable_modifiers_return retval = new TreePHP.variable_modifiers_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST string_literal163=null;
        TreePHP.modifier_return modifier164 = null;


        SLAST string_literal163_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:364:3: ( 'var' | modifier )
            int alt55=2;
            int LA55_0 = input.LA(1);

            if ( (LA55_0==122) ) {
                alt55=1;
            }
            else if ( (LA55_0==METHOD_DECL||LA55_0==SCALAR_VAR||(LA55_0>=86 && LA55_0<=87)||LA55_0==97||(LA55_0>=123 && LA55_0<=125)) ) {
                alt55=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 55, 0, input);

                throw nvae;
            }
            switch (alt55) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:364:5: 'var'
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    string_literal163=(SLAST)match(input,122,FOLLOW_122_in_variable_modifiers1229); 
                    string_literal163_tree = (SLAST)adaptor.dupNode(string_literal163);

                    adaptor.addChild(root_0, string_literal163_tree);


                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:365:5: modifier
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_modifier_in_variable_modifiers1235);
                    modifier164=modifier();

                    state._fsp--;

                    adaptor.addChild(root_0, modifier164.getTree());

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "variable_modifiers"

    public static class modifier_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "modifier"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:368:1: modifier : ( 'public' | 'protected' | 'private' | 'static' | 'abstract' | 'final' )* ;
    public final TreePHP.modifier_return modifier() throws RecognitionException {
        TreePHP.modifier_return retval = new TreePHP.modifier_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST set165=null;

        SLAST set165_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:369:3: ( ( 'public' | 'protected' | 'private' | 'static' | 'abstract' | 'final' )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:369:5: ( 'public' | 'protected' | 'private' | 'static' | 'abstract' | 'final' )*
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:369:5: ( 'public' | 'protected' | 'private' | 'static' | 'abstract' | 'final' )*
            loop56:
            do {
                int alt56=2;
                int LA56_0 = input.LA(1);

                if ( ((LA56_0>=86 && LA56_0<=87)||LA56_0==97||(LA56_0>=123 && LA56_0<=125)) ) {
                    alt56=1;
                }


                switch (alt56) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:
            	    {
            	    _last = (SLAST)input.LT(1);
            	    set165=(SLAST)input.LT(1);
            	    if ( (input.LA(1)>=86 && input.LA(1)<=87)||input.LA(1)==97||(input.LA(1)>=123 && input.LA(1)<=125) ) {
            	        input.consume();

            	        set165_tree = (SLAST)adaptor.dupNode(set165);

            	        adaptor.addChild(root_0, set165_tree);

            	        state.errorRecovery=false;
            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        throw mse;
            	    }


            	    }
            	    break;

            	default :
            	    break loop56;
                }
            } while (true);


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "modifier"

    public static class directive_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "directive"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:377:1: directive : ( ^( '=' IDENTIFIER expression ) )+ ;
    public final TreePHP.directive_return directive() throws RecognitionException {
        TreePHP.directive_return retval = new TreePHP.directive_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST char_literal166=null;
        SLAST IDENTIFIER167=null;
        TreePHP.expression_return expression168 = null;


        SLAST char_literal166_tree=null;
        SLAST IDENTIFIER167_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:378:3: ( ( ^( '=' IDENTIFIER expression ) )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:378:5: ( ^( '=' IDENTIFIER expression ) )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:378:5: ( ^( '=' IDENTIFIER expression ) )+
            int cnt57=0;
            loop57:
            do {
                int alt57=2;
                int LA57_0 = input.LA(1);

                if ( (LA57_0==EQ) ) {
                    alt57=1;
                }


                switch (alt57) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:378:6: ^( '=' IDENTIFIER expression )
            	    {
            	    _last = (SLAST)input.LT(1);
            	    {
            	    SLAST _save_last_1 = _last;
            	    SLAST _first_1 = null;
            	    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            	    char_literal166=(SLAST)match(input,EQ,FOLLOW_EQ_in_directive1302); 
            	    char_literal166_tree = (SLAST)adaptor.dupNode(char_literal166);

            	    root_1 = (SLAST)adaptor.becomeRoot(char_literal166_tree, root_1);



            	    match(input, Token.DOWN, null); 
            	    _last = (SLAST)input.LT(1);
            	    IDENTIFIER167=(SLAST)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_directive1304); 
            	    IDENTIFIER167_tree = (SLAST)adaptor.dupNode(IDENTIFIER167);

            	    adaptor.addChild(root_1, IDENTIFIER167_tree);

            	    _last = (SLAST)input.LT(1);
            	    pushFollow(FOLLOW_expression_in_directive1306);
            	    expression168=expression();

            	    state._fsp--;

            	    adaptor.addChild(root_1, expression168.getTree());

            	    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt57 >= 1 ) break loop57;
                        EarlyExitException eee =
                            new EarlyExitException(57, input);
                        throw eee;
                }
                cnt57++;
            } while (true);


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "directive"

    public static class expr_list_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "expr_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:381:1: expr_list : ( expression )+ ;
    public final TreePHP.expr_list_return expr_list() throws RecognitionException {
        TreePHP.expr_list_return retval = new TreePHP.expr_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.expression_return expression169 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:382:2: ( ( expression )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:382:4: ( expression )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:382:4: ( expression )+
            int cnt58=0;
            loop58:
            do {
                int alt58=2;
                int LA58_0 = input.LA(1);

                if ( (LA58_0==METHOD_DECL||LA58_0==VAR_DECL||LA58_0==CALL||LA58_0==EXPR||(LA58_0>=SCALAR && LA58_0<=ARRAY_DECL)||(LA58_0>=EQ && LA58_0<=BACKTRICKLITERAL)||(LA58_0>=126 && LA58_0<=169)) ) {
                    alt58=1;
                }


                switch (alt58) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:382:4: expression
            	    {
            	    _last = (SLAST)input.LT(1);
            	    pushFollow(FOLLOW_expression_in_expr_list1323);
            	    expression169=expression();

            	    state._fsp--;

            	    adaptor.addChild(root_0, expression169.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt58 >= 1 ) break loop58;
                        EarlyExitException eee =
                            new EarlyExitException(58, input);
                        throw eee;
                }
                cnt58++;
            } while (true);


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "expr_list"

    public static class expression_return extends TreeRuleReturnScope {
        public Expression expr;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "expression"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:385:1: expression returns [Expression expr] : ( ^( EXPR etop= expression ) | ^( 'OR' expression expression ) | ^( 'XOR' expression expression ) | ^( 'AND' expression expression ) | ^( EQ e1= expression e2= expression ) | ^( assignment_operator expression expression ) | ^( '?' expression ^( ':' expression expression ) ) | ^( '||' expression expression ) | ^( '&&' expression expression ) | ^( '|' expression expression ) | ^( '^' expression expression ) | ^( BIT_AND e1= expression e2= expression ) | ^( '.' expression expression ) | ^( '==' expression expression ) | ^( '!=' expression expression ) | ^( '===' expression expression ) | ^( '!==' expression expression ) | ^( '<' expression expression ) | ^( '>' expression expression ) | ^( '<=' expression expression ) | ^( '>=' expression expression ) | ^( '<<' expression expression ) | ^( '>>' expression expression ) | ^( '+' expression expression ) | ^( '-' expression expression ) | ^( '*' expression expression ) | ^( '/' expression expression ) | ^( '%' expression expression ) | cast_option expression | ^( ( '~' | '!' ) expression ) | ^( ( '++' | '--' ) expression ) | ^( 'instanceof' expression class_name_reference ) | ( '@' )? variable | ( '@' )? scalar | ^( 'list' ( assignment_list )? ) | ^( ARRAY_DECL ( array_pair_list )? ) | ^( 'new' class_name_reference ) | ^( 'clone' variable ) | ^( 'exit' ( expression )? ) | ^( 'unset' variable ) | lambda_function_declaration | BACKTRICKLITERAL );
    public final TreePHP.expression_return expression() throws RecognitionException {
        TreePHP.expression_return retval = new TreePHP.expression_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST EXPR170=null;
        SLAST string_literal171=null;
        SLAST string_literal174=null;
        SLAST string_literal177=null;
        SLAST EQ180=null;
        SLAST char_literal184=null;
        SLAST char_literal186=null;
        SLAST string_literal189=null;
        SLAST string_literal192=null;
        SLAST char_literal195=null;
        SLAST char_literal198=null;
        SLAST BIT_AND201=null;
        SLAST char_literal202=null;
        SLAST string_literal205=null;
        SLAST string_literal208=null;
        SLAST string_literal211=null;
        SLAST string_literal214=null;
        SLAST char_literal217=null;
        SLAST char_literal220=null;
        SLAST string_literal223=null;
        SLAST string_literal226=null;
        SLAST string_literal229=null;
        SLAST string_literal232=null;
        SLAST char_literal235=null;
        SLAST char_literal238=null;
        SLAST char_literal241=null;
        SLAST char_literal244=null;
        SLAST char_literal247=null;
        SLAST set252=null;
        SLAST set254=null;
        SLAST string_literal256=null;
        SLAST char_literal259=null;
        SLAST char_literal261=null;
        SLAST string_literal263=null;
        SLAST ARRAY_DECL265=null;
        SLAST string_literal267=null;
        SLAST string_literal269=null;
        SLAST string_literal271=null;
        SLAST string_literal273=null;
        SLAST BACKTRICKLITERAL276=null;
        TreePHP.expression_return etop = null;

        TreePHP.expression_return e1 = null;

        TreePHP.expression_return e2 = null;

        TreePHP.expression_return expression172 = null;

        TreePHP.expression_return expression173 = null;

        TreePHP.expression_return expression175 = null;

        TreePHP.expression_return expression176 = null;

        TreePHP.expression_return expression178 = null;

        TreePHP.expression_return expression179 = null;

        TreePHP.assignment_operator_return assignment_operator181 = null;

        TreePHP.expression_return expression182 = null;

        TreePHP.expression_return expression183 = null;

        TreePHP.expression_return expression185 = null;

        TreePHP.expression_return expression187 = null;

        TreePHP.expression_return expression188 = null;

        TreePHP.expression_return expression190 = null;

        TreePHP.expression_return expression191 = null;

        TreePHP.expression_return expression193 = null;

        TreePHP.expression_return expression194 = null;

        TreePHP.expression_return expression196 = null;

        TreePHP.expression_return expression197 = null;

        TreePHP.expression_return expression199 = null;

        TreePHP.expression_return expression200 = null;

        TreePHP.expression_return expression203 = null;

        TreePHP.expression_return expression204 = null;

        TreePHP.expression_return expression206 = null;

        TreePHP.expression_return expression207 = null;

        TreePHP.expression_return expression209 = null;

        TreePHP.expression_return expression210 = null;

        TreePHP.expression_return expression212 = null;

        TreePHP.expression_return expression213 = null;

        TreePHP.expression_return expression215 = null;

        TreePHP.expression_return expression216 = null;

        TreePHP.expression_return expression218 = null;

        TreePHP.expression_return expression219 = null;

        TreePHP.expression_return expression221 = null;

        TreePHP.expression_return expression222 = null;

        TreePHP.expression_return expression224 = null;

        TreePHP.expression_return expression225 = null;

        TreePHP.expression_return expression227 = null;

        TreePHP.expression_return expression228 = null;

        TreePHP.expression_return expression230 = null;

        TreePHP.expression_return expression231 = null;

        TreePHP.expression_return expression233 = null;

        TreePHP.expression_return expression234 = null;

        TreePHP.expression_return expression236 = null;

        TreePHP.expression_return expression237 = null;

        TreePHP.expression_return expression239 = null;

        TreePHP.expression_return expression240 = null;

        TreePHP.expression_return expression242 = null;

        TreePHP.expression_return expression243 = null;

        TreePHP.expression_return expression245 = null;

        TreePHP.expression_return expression246 = null;

        TreePHP.expression_return expression248 = null;

        TreePHP.expression_return expression249 = null;

        TreePHP.cast_option_return cast_option250 = null;

        TreePHP.expression_return expression251 = null;

        TreePHP.expression_return expression253 = null;

        TreePHP.expression_return expression255 = null;

        TreePHP.expression_return expression257 = null;

        TreePHP.class_name_reference_return class_name_reference258 = null;

        TreePHP.variable_return variable260 = null;

        TreePHP.scalar_return scalar262 = null;

        TreePHP.assignment_list_return assignment_list264 = null;

        TreePHP.array_pair_list_return array_pair_list266 = null;

        TreePHP.class_name_reference_return class_name_reference268 = null;

        TreePHP.variable_return variable270 = null;

        TreePHP.expression_return expression272 = null;

        TreePHP.variable_return variable274 = null;

        TreePHP.lambda_function_declaration_return lambda_function_declaration275 = null;


        SLAST EXPR170_tree=null;
        SLAST string_literal171_tree=null;
        SLAST string_literal174_tree=null;
        SLAST string_literal177_tree=null;
        SLAST EQ180_tree=null;
        SLAST char_literal184_tree=null;
        SLAST char_literal186_tree=null;
        SLAST string_literal189_tree=null;
        SLAST string_literal192_tree=null;
        SLAST char_literal195_tree=null;
        SLAST char_literal198_tree=null;
        SLAST BIT_AND201_tree=null;
        SLAST char_literal202_tree=null;
        SLAST string_literal205_tree=null;
        SLAST string_literal208_tree=null;
        SLAST string_literal211_tree=null;
        SLAST string_literal214_tree=null;
        SLAST char_literal217_tree=null;
        SLAST char_literal220_tree=null;
        SLAST string_literal223_tree=null;
        SLAST string_literal226_tree=null;
        SLAST string_literal229_tree=null;
        SLAST string_literal232_tree=null;
        SLAST char_literal235_tree=null;
        SLAST char_literal238_tree=null;
        SLAST char_literal241_tree=null;
        SLAST char_literal244_tree=null;
        SLAST char_literal247_tree=null;
        SLAST set252_tree=null;
        SLAST set254_tree=null;
        SLAST string_literal256_tree=null;
        SLAST char_literal259_tree=null;
        SLAST char_literal261_tree=null;
        SLAST string_literal263_tree=null;
        SLAST ARRAY_DECL265_tree=null;
        SLAST string_literal267_tree=null;
        SLAST string_literal269_tree=null;
        SLAST string_literal271_tree=null;
        SLAST string_literal273_tree=null;
        SLAST BACKTRICKLITERAL276_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:386:3: ( ^( EXPR etop= expression ) | ^( 'OR' expression expression ) | ^( 'XOR' expression expression ) | ^( 'AND' expression expression ) | ^( EQ e1= expression e2= expression ) | ^( assignment_operator expression expression ) | ^( '?' expression ^( ':' expression expression ) ) | ^( '||' expression expression ) | ^( '&&' expression expression ) | ^( '|' expression expression ) | ^( '^' expression expression ) | ^( BIT_AND e1= expression e2= expression ) | ^( '.' expression expression ) | ^( '==' expression expression ) | ^( '!=' expression expression ) | ^( '===' expression expression ) | ^( '!==' expression expression ) | ^( '<' expression expression ) | ^( '>' expression expression ) | ^( '<=' expression expression ) | ^( '>=' expression expression ) | ^( '<<' expression expression ) | ^( '>>' expression expression ) | ^( '+' expression expression ) | ^( '-' expression expression ) | ^( '*' expression expression ) | ^( '/' expression expression ) | ^( '%' expression expression ) | cast_option expression | ^( ( '~' | '!' ) expression ) | ^( ( '++' | '--' ) expression ) | ^( 'instanceof' expression class_name_reference ) | ( '@' )? variable | ( '@' )? scalar | ^( 'list' ( assignment_list )? ) | ^( ARRAY_DECL ( array_pair_list )? ) | ^( 'new' class_name_reference ) | ^( 'clone' variable ) | ^( 'exit' ( expression )? ) | ^( 'unset' variable ) | lambda_function_declaration | BACKTRICKLITERAL )
            int alt64=42;
            alt64 = dfa64.predict(input);
            switch (alt64) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:386:5: ^( EXPR etop= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    EXPR170=(SLAST)match(input,EXPR,FOLLOW_EXPR_in_expression1344); 
                    EXPR170_tree = (SLAST)adaptor.dupNode(EXPR170);

                    root_1 = (SLAST)adaptor.becomeRoot(EXPR170_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1348);
                    etop=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, etop.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        retval.expr = (etop!=null?etop.expr:null);
                      

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:390:5: ^( 'OR' expression expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    string_literal171=(SLAST)match(input,126,FOLLOW_126_in_expression1360); 
                    string_literal171_tree = (SLAST)adaptor.dupNode(string_literal171);

                    root_1 = (SLAST)adaptor.becomeRoot(string_literal171_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1362);
                    expression172=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression172.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1364);
                    expression173=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression173.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 3 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:391:5: ^( 'XOR' expression expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    string_literal174=(SLAST)match(input,127,FOLLOW_127_in_expression1372); 
                    string_literal174_tree = (SLAST)adaptor.dupNode(string_literal174);

                    root_1 = (SLAST)adaptor.becomeRoot(string_literal174_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1374);
                    expression175=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression175.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1376);
                    expression176=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression176.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 4 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:392:5: ^( 'AND' expression expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    string_literal177=(SLAST)match(input,128,FOLLOW_128_in_expression1384); 
                    string_literal177_tree = (SLAST)adaptor.dupNode(string_literal177);

                    root_1 = (SLAST)adaptor.becomeRoot(string_literal177_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1386);
                    expression178=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression178.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1388);
                    expression179=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression179.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 5 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:393:5: ^( EQ e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    EQ180=(SLAST)match(input,EQ,FOLLOW_EQ_in_expression1396); 
                    EQ180_tree = (SLAST)adaptor.dupNode(EQ180);

                    root_1 = (SLAST)adaptor.becomeRoot(EQ180_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1400);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1404);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = EQ180.startIndex;
                        int endIndex = EQ180.endIndex;
                        Expression var = (e1!=null?e1.expr:null);
                        Expression expr = (e2!=null?e2.expr:null);
                        retval.expr = new Assignment(startIndex, endIndex, var, Assignment.OP_EQUAL, expr);
                      

                    }
                    break;
                case 6 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:401:5: ^( assignment_operator expression expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_assignment_operator_in_expression1417);
                    assignment_operator181=assignment_operator();

                    state._fsp--;

                    root_1 = (SLAST)adaptor.becomeRoot(assignment_operator181.getTree(), root_1);


                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1419);
                    expression182=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression182.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1421);
                    expression183=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression183.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 7 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:402:5: ^( '?' expression ^( ':' expression expression ) )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    char_literal184=(SLAST)match(input,129,FOLLOW_129_in_expression1429); 
                    char_literal184_tree = (SLAST)adaptor.dupNode(char_literal184);

                    root_1 = (SLAST)adaptor.becomeRoot(char_literal184_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1431);
                    expression185=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression185.getTree());
                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_2 = _last;
                    SLAST _first_2 = null;
                    SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    char_literal186=(SLAST)match(input,112,FOLLOW_112_in_expression1434); 
                    char_literal186_tree = (SLAST)adaptor.dupNode(char_literal186);

                    root_2 = (SLAST)adaptor.becomeRoot(char_literal186_tree, root_2);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1436);
                    expression187=expression();

                    state._fsp--;

                    adaptor.addChild(root_2, expression187.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1438);
                    expression188=expression();

                    state._fsp--;

                    adaptor.addChild(root_2, expression188.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
                    }


                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 8 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:403:5: ^( '||' expression expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    string_literal189=(SLAST)match(input,130,FOLLOW_130_in_expression1447); 
                    string_literal189_tree = (SLAST)adaptor.dupNode(string_literal189);

                    root_1 = (SLAST)adaptor.becomeRoot(string_literal189_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1449);
                    expression190=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression190.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1451);
                    expression191=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression191.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 9 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:404:5: ^( '&&' expression expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    string_literal192=(SLAST)match(input,131,FOLLOW_131_in_expression1459); 
                    string_literal192_tree = (SLAST)adaptor.dupNode(string_literal192);

                    root_1 = (SLAST)adaptor.becomeRoot(string_literal192_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1461);
                    expression193=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression193.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1463);
                    expression194=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression194.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 10 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:405:5: ^( '|' expression expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    char_literal195=(SLAST)match(input,132,FOLLOW_132_in_expression1471); 
                    char_literal195_tree = (SLAST)adaptor.dupNode(char_literal195);

                    root_1 = (SLAST)adaptor.becomeRoot(char_literal195_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1473);
                    expression196=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression196.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1475);
                    expression197=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression197.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 11 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:406:5: ^( '^' expression expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    char_literal198=(SLAST)match(input,133,FOLLOW_133_in_expression1483); 
                    char_literal198_tree = (SLAST)adaptor.dupNode(char_literal198);

                    root_1 = (SLAST)adaptor.becomeRoot(char_literal198_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1485);
                    expression199=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression199.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1487);
                    expression200=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression200.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 12 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:407:5: ^( BIT_AND e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    BIT_AND201=(SLAST)match(input,BIT_AND,FOLLOW_BIT_AND_in_expression1495); 
                    BIT_AND201_tree = (SLAST)adaptor.dupNode(BIT_AND201);

                    root_1 = (SLAST)adaptor.becomeRoot(BIT_AND201_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1499);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1503);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = BIT_AND201.startIndex;
                        int endIndex = BIT_AND201.endIndex;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1 , InfixExpression.OP_AND, expr2); 
                      

                    }
                    break;
                case 13 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:415:5: ^( '.' expression expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    char_literal202=(SLAST)match(input,134,FOLLOW_134_in_expression1515); 
                    char_literal202_tree = (SLAST)adaptor.dupNode(char_literal202);

                    root_1 = (SLAST)adaptor.becomeRoot(char_literal202_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1517);
                    expression203=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression203.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1519);
                    expression204=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression204.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 14 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:416:5: ^( '==' expression expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    string_literal205=(SLAST)match(input,135,FOLLOW_135_in_expression1527); 
                    string_literal205_tree = (SLAST)adaptor.dupNode(string_literal205);

                    root_1 = (SLAST)adaptor.becomeRoot(string_literal205_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1529);
                    expression206=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression206.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1531);
                    expression207=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression207.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 15 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:417:5: ^( '!=' expression expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    string_literal208=(SLAST)match(input,136,FOLLOW_136_in_expression1539); 
                    string_literal208_tree = (SLAST)adaptor.dupNode(string_literal208);

                    root_1 = (SLAST)adaptor.becomeRoot(string_literal208_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1541);
                    expression209=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression209.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1543);
                    expression210=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression210.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 16 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:418:5: ^( '===' expression expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    string_literal211=(SLAST)match(input,137,FOLLOW_137_in_expression1551); 
                    string_literal211_tree = (SLAST)adaptor.dupNode(string_literal211);

                    root_1 = (SLAST)adaptor.becomeRoot(string_literal211_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1553);
                    expression212=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression212.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1555);
                    expression213=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression213.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 17 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:419:5: ^( '!==' expression expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    string_literal214=(SLAST)match(input,138,FOLLOW_138_in_expression1563); 
                    string_literal214_tree = (SLAST)adaptor.dupNode(string_literal214);

                    root_1 = (SLAST)adaptor.becomeRoot(string_literal214_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1565);
                    expression215=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression215.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1567);
                    expression216=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression216.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 18 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:420:5: ^( '<' expression expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    char_literal217=(SLAST)match(input,139,FOLLOW_139_in_expression1575); 
                    char_literal217_tree = (SLAST)adaptor.dupNode(char_literal217);

                    root_1 = (SLAST)adaptor.becomeRoot(char_literal217_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1577);
                    expression218=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression218.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1579);
                    expression219=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression219.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 19 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:421:5: ^( '>' expression expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    char_literal220=(SLAST)match(input,140,FOLLOW_140_in_expression1587); 
                    char_literal220_tree = (SLAST)adaptor.dupNode(char_literal220);

                    root_1 = (SLAST)adaptor.becomeRoot(char_literal220_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1589);
                    expression221=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression221.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1591);
                    expression222=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression222.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 20 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:422:5: ^( '<=' expression expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    string_literal223=(SLAST)match(input,141,FOLLOW_141_in_expression1599); 
                    string_literal223_tree = (SLAST)adaptor.dupNode(string_literal223);

                    root_1 = (SLAST)adaptor.becomeRoot(string_literal223_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1601);
                    expression224=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression224.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1603);
                    expression225=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression225.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 21 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:423:5: ^( '>=' expression expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    string_literal226=(SLAST)match(input,142,FOLLOW_142_in_expression1611); 
                    string_literal226_tree = (SLAST)adaptor.dupNode(string_literal226);

                    root_1 = (SLAST)adaptor.becomeRoot(string_literal226_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1613);
                    expression227=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression227.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1615);
                    expression228=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression228.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 22 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:424:5: ^( '<<' expression expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    string_literal229=(SLAST)match(input,143,FOLLOW_143_in_expression1623); 
                    string_literal229_tree = (SLAST)adaptor.dupNode(string_literal229);

                    root_1 = (SLAST)adaptor.becomeRoot(string_literal229_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1625);
                    expression230=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression230.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1627);
                    expression231=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression231.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 23 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:425:5: ^( '>>' expression expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    string_literal232=(SLAST)match(input,144,FOLLOW_144_in_expression1635); 
                    string_literal232_tree = (SLAST)adaptor.dupNode(string_literal232);

                    root_1 = (SLAST)adaptor.becomeRoot(string_literal232_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1637);
                    expression233=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression233.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1639);
                    expression234=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression234.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 24 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:426:5: ^( '+' expression expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    char_literal235=(SLAST)match(input,145,FOLLOW_145_in_expression1647); 
                    char_literal235_tree = (SLAST)adaptor.dupNode(char_literal235);

                    root_1 = (SLAST)adaptor.becomeRoot(char_literal235_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1649);
                    expression236=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression236.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1651);
                    expression237=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression237.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 25 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:427:5: ^( '-' expression expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    char_literal238=(SLAST)match(input,146,FOLLOW_146_in_expression1659); 
                    char_literal238_tree = (SLAST)adaptor.dupNode(char_literal238);

                    root_1 = (SLAST)adaptor.becomeRoot(char_literal238_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1661);
                    expression239=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression239.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1663);
                    expression240=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression240.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 26 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:428:5: ^( '*' expression expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    char_literal241=(SLAST)match(input,147,FOLLOW_147_in_expression1671); 
                    char_literal241_tree = (SLAST)adaptor.dupNode(char_literal241);

                    root_1 = (SLAST)adaptor.becomeRoot(char_literal241_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1673);
                    expression242=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression242.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1675);
                    expression243=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression243.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 27 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:429:5: ^( '/' expression expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    char_literal244=(SLAST)match(input,148,FOLLOW_148_in_expression1683); 
                    char_literal244_tree = (SLAST)adaptor.dupNode(char_literal244);

                    root_1 = (SLAST)adaptor.becomeRoot(char_literal244_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1685);
                    expression245=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression245.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1687);
                    expression246=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression246.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 28 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:430:5: ^( '%' expression expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    char_literal247=(SLAST)match(input,149,FOLLOW_149_in_expression1695); 
                    char_literal247_tree = (SLAST)adaptor.dupNode(char_literal247);

                    root_1 = (SLAST)adaptor.becomeRoot(char_literal247_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1697);
                    expression248=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression248.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1699);
                    expression249=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression249.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 29 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:431:5: cast_option expression
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_cast_option_in_expression1706);
                    cast_option250=cast_option();

                    state._fsp--;

                    adaptor.addChild(root_0, cast_option250.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1708);
                    expression251=expression();

                    state._fsp--;

                    adaptor.addChild(root_0, expression251.getTree());

                    }
                    break;
                case 30 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:432:5: ^( ( '~' | '!' ) expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();set252=(SLAST)input.LT(1);
                    if ( (input.LA(1)>=161 && input.LA(1)<=162) ) {
                        input.consume();

                        set252_tree = (SLAST)adaptor.dupNode(set252);

                        root_1 = (SLAST)adaptor.becomeRoot(set252_tree, root_1);

                        state.errorRecovery=false;
                    }
                    else {
                        MismatchedSetException mse = new MismatchedSetException(null,input);
                        throw mse;
                    }



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1723);
                    expression253=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression253.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 31 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:433:5: ^( ( '++' | '--' ) expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();set254=(SLAST)input.LT(1);
                    if ( (input.LA(1)>=163 && input.LA(1)<=164) ) {
                        input.consume();

                        set254_tree = (SLAST)adaptor.dupNode(set254);

                        root_1 = (SLAST)adaptor.becomeRoot(set254_tree, root_1);

                        state.errorRecovery=false;
                    }
                    else {
                        MismatchedSetException mse = new MismatchedSetException(null,input);
                        throw mse;
                    }



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1739);
                    expression255=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression255.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 32 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:434:5: ^( 'instanceof' expression class_name_reference )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    string_literal256=(SLAST)match(input,165,FOLLOW_165_in_expression1747); 
                    string_literal256_tree = (SLAST)adaptor.dupNode(string_literal256);

                    root_1 = (SLAST)adaptor.becomeRoot(string_literal256_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1749);
                    expression257=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression257.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_class_name_reference_in_expression1751);
                    class_name_reference258=class_name_reference();

                    state._fsp--;

                    adaptor.addChild(root_1, class_name_reference258.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 33 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:435:5: ( '@' )? variable
                    {
                    root_0 = (SLAST)adaptor.nil();

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:435:5: ( '@' )?
                    int alt59=2;
                    int LA59_0 = input.LA(1);

                    if ( (LA59_0==166) ) {
                        alt59=1;
                    }
                    switch (alt59) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:435:5: '@'
                            {
                            _last = (SLAST)input.LT(1);
                            char_literal259=(SLAST)match(input,166,FOLLOW_166_in_expression1758); 
                            char_literal259_tree = (SLAST)adaptor.dupNode(char_literal259);

                            adaptor.addChild(root_0, char_literal259_tree);


                            }
                            break;

                    }

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_variable_in_expression1761);
                    variable260=variable();

                    state._fsp--;

                    adaptor.addChild(root_0, variable260.getTree());

                        retval.expr = (variable260!=null?variable260.expr:null);
                      

                    }
                    break;
                case 34 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:439:5: ( '@' )? scalar
                    {
                    root_0 = (SLAST)adaptor.nil();

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:439:5: ( '@' )?
                    int alt60=2;
                    int LA60_0 = input.LA(1);

                    if ( (LA60_0==166) ) {
                        alt60=1;
                    }
                    switch (alt60) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:439:5: '@'
                            {
                            _last = (SLAST)input.LT(1);
                            char_literal261=(SLAST)match(input,166,FOLLOW_166_in_expression1771); 
                            char_literal261_tree = (SLAST)adaptor.dupNode(char_literal261);

                            adaptor.addChild(root_0, char_literal261_tree);


                            }
                            break;

                    }

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_scalar_in_expression1774);
                    scalar262=scalar();

                    state._fsp--;

                    adaptor.addChild(root_0, scalar262.getTree());

                        retval.expr = (scalar262!=null?scalar262.expr:null);
                      

                    }
                    break;
                case 35 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:443:5: ^( 'list' ( assignment_list )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    string_literal263=(SLAST)match(input,167,FOLLOW_167_in_expression1785); 
                    string_literal263_tree = (SLAST)adaptor.dupNode(string_literal263);

                    root_1 = (SLAST)adaptor.becomeRoot(string_literal263_tree, root_1);



                    if ( input.LA(1)==Token.DOWN ) {
                        match(input, Token.DOWN, null); 
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:443:14: ( assignment_list )?
                        int alt61=2;
                        int LA61_0 = input.LA(1);

                        if ( (LA61_0==VAR_DECL||LA61_0==CALL||LA61_0==167) ) {
                            alt61=1;
                        }
                        switch (alt61) {
                            case 1 :
                                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:443:14: assignment_list
                                {
                                _last = (SLAST)input.LT(1);
                                pushFollow(FOLLOW_assignment_list_in_expression1787);
                                assignment_list264=assignment_list();

                                state._fsp--;

                                adaptor.addChild(root_1, assignment_list264.getTree());

                                }
                                break;

                        }


                        match(input, Token.UP, null); 
                    }adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 36 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:444:5: ^( ARRAY_DECL ( array_pair_list )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    ARRAY_DECL265=(SLAST)match(input,ARRAY_DECL,FOLLOW_ARRAY_DECL_in_expression1796); 
                    ARRAY_DECL265_tree = (SLAST)adaptor.dupNode(ARRAY_DECL265);

                    root_1 = (SLAST)adaptor.becomeRoot(ARRAY_DECL265_tree, root_1);



                    if ( input.LA(1)==Token.DOWN ) {
                        match(input, Token.DOWN, null); 
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:444:18: ( array_pair_list )?
                        int alt62=2;
                        int LA62_0 = input.LA(1);

                        if ( (LA62_0==METHOD_DECL||LA62_0==VAR_DECL||LA62_0==CALL||LA62_0==EXPR||(LA62_0>=SCALAR && LA62_0<=ARRAY_DECL)||(LA62_0>=EQ && LA62_0<=BACKTRICKLITERAL)||LA62_0==105||(LA62_0>=126 && LA62_0<=169)) ) {
                            alt62=1;
                        }
                        switch (alt62) {
                            case 1 :
                                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:444:18: array_pair_list
                                {
                                _last = (SLAST)input.LT(1);
                                pushFollow(FOLLOW_array_pair_list_in_expression1798);
                                array_pair_list266=array_pair_list();

                                state._fsp--;

                                adaptor.addChild(root_1, array_pair_list266.getTree());

                                }
                                break;

                        }


                        match(input, Token.UP, null); 
                    }adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = ARRAY_DECL265.startIndex;
                        int endIndex = ARRAY_DECL265.endIndex;
                        if ((array_pair_list266!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(array_pair_list266.start),
                      input.getTreeAdaptor().getTokenStopIndex(array_pair_list266.start))):null) != null) {
                           retval.expr = new ArrayCreation(startIndex, endIndex, (array_pair_list266!=null?array_pair_list266.arrayList:null));
                        }
                        else {
                           retval.expr = new ArrayCreation(startIndex, endIndex, new LinkedList());
                        }
                      

                    }
                    break;
                case 37 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:455:5: ^( 'new' class_name_reference )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    string_literal267=(SLAST)match(input,168,FOLLOW_168_in_expression1811); 
                    string_literal267_tree = (SLAST)adaptor.dupNode(string_literal267);

                    root_1 = (SLAST)adaptor.becomeRoot(string_literal267_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_class_name_reference_in_expression1813);
                    class_name_reference268=class_name_reference();

                    state._fsp--;

                    adaptor.addChild(root_1, class_name_reference268.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 38 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:456:5: ^( 'clone' variable )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    string_literal269=(SLAST)match(input,158,FOLLOW_158_in_expression1821); 
                    string_literal269_tree = (SLAST)adaptor.dupNode(string_literal269);

                    root_1 = (SLAST)adaptor.becomeRoot(string_literal269_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_variable_in_expression1823);
                    variable270=variable();

                    state._fsp--;

                    adaptor.addChild(root_1, variable270.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 39 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:457:5: ^( 'exit' ( expression )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    string_literal271=(SLAST)match(input,169,FOLLOW_169_in_expression1831); 
                    string_literal271_tree = (SLAST)adaptor.dupNode(string_literal271);

                    root_1 = (SLAST)adaptor.becomeRoot(string_literal271_tree, root_1);



                    if ( input.LA(1)==Token.DOWN ) {
                        match(input, Token.DOWN, null); 
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:457:14: ( expression )?
                        int alt63=2;
                        int LA63_0 = input.LA(1);

                        if ( (LA63_0==METHOD_DECL||LA63_0==VAR_DECL||LA63_0==CALL||LA63_0==EXPR||(LA63_0>=SCALAR && LA63_0<=ARRAY_DECL)||(LA63_0>=EQ && LA63_0<=BACKTRICKLITERAL)||(LA63_0>=126 && LA63_0<=169)) ) {
                            alt63=1;
                        }
                        switch (alt63) {
                            case 1 :
                                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:457:14: expression
                                {
                                _last = (SLAST)input.LT(1);
                                pushFollow(FOLLOW_expression_in_expression1833);
                                expression272=expression();

                                state._fsp--;

                                adaptor.addChild(root_1, expression272.getTree());

                                }
                                break;

                        }


                        match(input, Token.UP, null); 
                    }adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 40 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:458:5: ^( 'unset' variable )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    string_literal273=(SLAST)match(input,157,FOLLOW_157_in_expression1842); 
                    string_literal273_tree = (SLAST)adaptor.dupNode(string_literal273);

                    root_1 = (SLAST)adaptor.becomeRoot(string_literal273_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_variable_in_expression1844);
                    variable274=variable();

                    state._fsp--;

                    adaptor.addChild(root_1, variable274.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 41 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:459:5: lambda_function_declaration
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_lambda_function_declaration_in_expression1851);
                    lambda_function_declaration275=lambda_function_declaration();

                    state._fsp--;

                    adaptor.addChild(root_0, lambda_function_declaration275.getTree());

                    }
                    break;
                case 42 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:460:5: BACKTRICKLITERAL
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    BACKTRICKLITERAL276=(SLAST)match(input,BACKTRICKLITERAL,FOLLOW_BACKTRICKLITERAL_in_expression1857); 
                    BACKTRICKLITERAL276_tree = (SLAST)adaptor.dupNode(BACKTRICKLITERAL276);

                    adaptor.addChild(root_0, BACKTRICKLITERAL276_tree);


                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "expression"

    public static class assignment_operator_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "assignment_operator"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:464:1: assignment_operator : ( PLUS_EQ | MINUS_EQ | MUL_EQ | DIV_EQ | DOT_EQ | PERCENT_EQ | BIT_AND_EQ | BIT_OR_EQ | POWER_EQ | LMOVE_EQ | RMOVE_EQ );
    public final TreePHP.assignment_operator_return assignment_operator() throws RecognitionException {
        TreePHP.assignment_operator_return retval = new TreePHP.assignment_operator_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST set277=null;

        SLAST set277_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:465:3: ( PLUS_EQ | MINUS_EQ | MUL_EQ | DIV_EQ | DOT_EQ | PERCENT_EQ | BIT_AND_EQ | BIT_OR_EQ | POWER_EQ | LMOVE_EQ | RMOVE_EQ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            set277=(SLAST)input.LT(1);
            if ( (input.LA(1)>=PLUS_EQ && input.LA(1)<=RMOVE_EQ) ) {
                input.consume();

                set277_tree = (SLAST)adaptor.dupNode(set277);

                adaptor.addChild(root_0, set277_tree);

                state.errorRecovery=false;
            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                throw mse;
            }

             

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "assignment_operator"

    public static class cast_option_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "cast_option"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:478:1: cast_option : ( 'bool' | 'boolean' | 'int' | 'float' | 'double' | 'array' | 'object' | 'real' | 'string' | 'unset' | 'clone' ) ;
    public final TreePHP.cast_option_return cast_option() throws RecognitionException {
        TreePHP.cast_option_return retval = new TreePHP.cast_option_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST set278=null;

        SLAST set278_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:479:1: ( ( 'bool' | 'boolean' | 'int' | 'float' | 'double' | 'array' | 'object' | 'real' | 'string' | 'unset' | 'clone' ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:479:3: ( 'bool' | 'boolean' | 'int' | 'float' | 'double' | 'array' | 'object' | 'real' | 'string' | 'unset' | 'clone' )
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            set278=(SLAST)input.LT(1);
            if ( (input.LA(1)>=150 && input.LA(1)<=160) ) {
                input.consume();

                set278_tree = (SLAST)adaptor.dupNode(set278);

                adaptor.addChild(root_0, set278_tree);

                state.errorRecovery=false;
            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                throw mse;
            }


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "cast_option"

    public static class lambda_function_declaration_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "lambda_function_declaration"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:493:1: lambda_function_declaration : ^( METHOD_DECL ( '&' )? ( parameter_list )? ( ^( 'use' ( expr_list )? ) )? block ) ;
    public final TreePHP.lambda_function_declaration_return lambda_function_declaration() throws RecognitionException {
        TreePHP.lambda_function_declaration_return retval = new TreePHP.lambda_function_declaration_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST METHOD_DECL279=null;
        SLAST char_literal280=null;
        SLAST string_literal282=null;
        TreePHP.parameter_list_return parameter_list281 = null;

        TreePHP.expr_list_return expr_list283 = null;

        TreePHP.block_return block284 = null;


        SLAST METHOD_DECL279_tree=null;
        SLAST char_literal280_tree=null;
        SLAST string_literal282_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:494:3: ( ^( METHOD_DECL ( '&' )? ( parameter_list )? ( ^( 'use' ( expr_list )? ) )? block ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:494:5: ^( METHOD_DECL ( '&' )? ( parameter_list )? ( ^( 'use' ( expr_list )? ) )? block )
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_1 = _last;
            SLAST _first_1 = null;
            SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            METHOD_DECL279=(SLAST)match(input,METHOD_DECL,FOLLOW_METHOD_DECL_in_lambda_function_declaration2036); 
            METHOD_DECL279_tree = (SLAST)adaptor.dupNode(METHOD_DECL279);

            root_1 = (SLAST)adaptor.becomeRoot(METHOD_DECL279_tree, root_1);



            match(input, Token.DOWN, null); 
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:494:19: ( '&' )?
            int alt65=2;
            int LA65_0 = input.LA(1);

            if ( (LA65_0==BIT_AND) ) {
                alt65=1;
            }
            switch (alt65) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:494:19: '&'
                    {
                    _last = (SLAST)input.LT(1);
                    char_literal280=(SLAST)match(input,BIT_AND,FOLLOW_BIT_AND_in_lambda_function_declaration2038); 
                    char_literal280_tree = (SLAST)adaptor.dupNode(char_literal280);

                    adaptor.addChild(root_1, char_literal280_tree);


                    }
                    break;

            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:494:24: ( parameter_list )?
            int alt66=2;
            int LA66_0 = input.LA(1);

            if ( (LA66_0==PARAMETER) ) {
                alt66=1;
            }
            switch (alt66) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:494:24: parameter_list
                    {
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_parameter_list_in_lambda_function_declaration2041);
                    parameter_list281=parameter_list();

                    state._fsp--;

                    adaptor.addChild(root_1, parameter_list281.getTree());

                    }
                    break;

            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:494:40: ( ^( 'use' ( expr_list )? ) )?
            int alt68=2;
            int LA68_0 = input.LA(1);

            if ( (LA68_0==104) ) {
                alt68=1;
            }
            switch (alt68) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:494:41: ^( 'use' ( expr_list )? )
                    {
                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_2 = _last;
                    SLAST _first_2 = null;
                    SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    string_literal282=(SLAST)match(input,104,FOLLOW_104_in_lambda_function_declaration2046); 
                    string_literal282_tree = (SLAST)adaptor.dupNode(string_literal282);

                    root_2 = (SLAST)adaptor.becomeRoot(string_literal282_tree, root_2);



                    if ( input.LA(1)==Token.DOWN ) {
                        match(input, Token.DOWN, null); 
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:494:49: ( expr_list )?
                        int alt67=2;
                        int LA67_0 = input.LA(1);

                        if ( (LA67_0==METHOD_DECL||LA67_0==VAR_DECL||LA67_0==CALL||LA67_0==EXPR||(LA67_0>=SCALAR && LA67_0<=ARRAY_DECL)||(LA67_0>=EQ && LA67_0<=BACKTRICKLITERAL)||(LA67_0>=126 && LA67_0<=169)) ) {
                            alt67=1;
                        }
                        switch (alt67) {
                            case 1 :
                                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:494:49: expr_list
                                {
                                _last = (SLAST)input.LT(1);
                                pushFollow(FOLLOW_expr_list_in_lambda_function_declaration2048);
                                expr_list283=expr_list();

                                state._fsp--;

                                adaptor.addChild(root_2, expr_list283.getTree());

                                }
                                break;

                        }


                        match(input, Token.UP, null); 
                    }adaptor.addChild(root_1, root_2);_last = _save_last_2;
                    }


                    }
                    break;

            }

            _last = (SLAST)input.LT(1);
            pushFollow(FOLLOW_block_in_lambda_function_declaration2058);
            block284=block();

            state._fsp--;

            adaptor.addChild(root_1, block284.getTree());

            match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "lambda_function_declaration"

    public static class class_name_reference_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "class_name_reference"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:498:1: class_name_reference : ( variable | fully_qualified_class_name );
    public final TreePHP.class_name_reference_return class_name_reference() throws RecognitionException {
        TreePHP.class_name_reference_return retval = new TreePHP.class_name_reference_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.variable_return variable285 = null;

        TreePHP.fully_qualified_class_name_return fully_qualified_class_name286 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:499:3: ( variable | fully_qualified_class_name )
            int alt69=2;
            int LA69_0 = input.LA(1);

            if ( (LA69_0==VAR_DECL||LA69_0==CALL) ) {
                alt69=1;
            }
            else if ( (LA69_0==IDENTIFIER) ) {
                alt69=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 69, 0, input);

                throw nvae;
            }
            switch (alt69) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:499:5: variable
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_variable_in_class_name_reference2078);
                    variable285=variable();

                    state._fsp--;

                    adaptor.addChild(root_0, variable285.getTree());

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:500:5: fully_qualified_class_name
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_fully_qualified_class_name_in_class_name_reference2084);
                    fully_qualified_class_name286=fully_qualified_class_name();

                    state._fsp--;

                    adaptor.addChild(root_0, fully_qualified_class_name286.getTree());

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "class_name_reference"

    public static class assignment_list_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "assignment_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:503:1: assignment_list : ( assignment_element )+ ;
    public final TreePHP.assignment_list_return assignment_list() throws RecognitionException {
        TreePHP.assignment_list_return retval = new TreePHP.assignment_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.assignment_element_return assignment_element287 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:504:3: ( ( assignment_element )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:504:5: ( assignment_element )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:504:5: ( assignment_element )+
            int cnt70=0;
            loop70:
            do {
                int alt70=2;
                int LA70_0 = input.LA(1);

                if ( (LA70_0==VAR_DECL||LA70_0==CALL||LA70_0==167) ) {
                    alt70=1;
                }


                switch (alt70) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:504:5: assignment_element
            	    {
            	    _last = (SLAST)input.LT(1);
            	    pushFollow(FOLLOW_assignment_element_in_assignment_list2101);
            	    assignment_element287=assignment_element();

            	    state._fsp--;

            	    adaptor.addChild(root_0, assignment_element287.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt70 >= 1 ) break loop70;
                        EarlyExitException eee =
                            new EarlyExitException(70, input);
                        throw eee;
                }
                cnt70++;
            } while (true);


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "assignment_list"

    public static class assignment_element_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "assignment_element"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:507:1: assignment_element : ( variable | ^( 'list' ( assignment_list )? ) );
    public final TreePHP.assignment_element_return assignment_element() throws RecognitionException {
        TreePHP.assignment_element_return retval = new TreePHP.assignment_element_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST string_literal289=null;
        TreePHP.variable_return variable288 = null;

        TreePHP.assignment_list_return assignment_list290 = null;


        SLAST string_literal289_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:508:3: ( variable | ^( 'list' ( assignment_list )? ) )
            int alt72=2;
            int LA72_0 = input.LA(1);

            if ( (LA72_0==VAR_DECL||LA72_0==CALL) ) {
                alt72=1;
            }
            else if ( (LA72_0==167) ) {
                alt72=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 72, 0, input);

                throw nvae;
            }
            switch (alt72) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:508:5: variable
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_variable_in_assignment_element2117);
                    variable288=variable();

                    state._fsp--;

                    adaptor.addChild(root_0, variable288.getTree());

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:509:5: ^( 'list' ( assignment_list )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    string_literal289=(SLAST)match(input,167,FOLLOW_167_in_assignment_element2124); 
                    string_literal289_tree = (SLAST)adaptor.dupNode(string_literal289);

                    root_1 = (SLAST)adaptor.becomeRoot(string_literal289_tree, root_1);



                    if ( input.LA(1)==Token.DOWN ) {
                        match(input, Token.DOWN, null); 
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:509:14: ( assignment_list )?
                        int alt71=2;
                        int LA71_0 = input.LA(1);

                        if ( (LA71_0==VAR_DECL||LA71_0==CALL||LA71_0==167) ) {
                            alt71=1;
                        }
                        switch (alt71) {
                            case 1 :
                                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:509:14: assignment_list
                                {
                                _last = (SLAST)input.LT(1);
                                pushFollow(FOLLOW_assignment_list_in_assignment_element2126);
                                assignment_list290=assignment_list();

                                state._fsp--;

                                adaptor.addChild(root_1, assignment_list290.getTree());

                                }
                                break;

                        }


                        match(input, Token.UP, null); 
                    }adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "assignment_element"

    protected static class array_pair_list_scope {
        List list;
    }
    protected Stack array_pair_list_stack = new Stack();

    public static class array_pair_list_return extends TreeRuleReturnScope {
        public List arrayList;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "array_pair_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:512:1: array_pair_list returns [List arrayList] : ( array_pair_element )+ ;
    public final TreePHP.array_pair_list_return array_pair_list() throws RecognitionException {
        array_pair_list_stack.push(new array_pair_list_scope());
        TreePHP.array_pair_list_return retval = new TreePHP.array_pair_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.array_pair_element_return array_pair_element291 = null;




          ((array_pair_list_scope)array_pair_list_stack.peek()).list = new LinkedList();

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:519:3: ( ( array_pair_element )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:519:5: ( array_pair_element )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:519:5: ( array_pair_element )+
            int cnt73=0;
            loop73:
            do {
                int alt73=2;
                int LA73_0 = input.LA(1);

                if ( (LA73_0==METHOD_DECL||LA73_0==VAR_DECL||LA73_0==CALL||LA73_0==EXPR||(LA73_0>=SCALAR && LA73_0<=ARRAY_DECL)||(LA73_0>=EQ && LA73_0<=BACKTRICKLITERAL)||LA73_0==105||(LA73_0>=126 && LA73_0<=169)) ) {
                    alt73=1;
                }


                switch (alt73) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:519:5: array_pair_element
            	    {
            	    _last = (SLAST)input.LT(1);
            	    pushFollow(FOLLOW_array_pair_element_in_array_pair_list2156);
            	    array_pair_element291=array_pair_element();

            	    state._fsp--;

            	    adaptor.addChild(root_0, array_pair_element291.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt73 >= 1 ) break loop73;
                        EarlyExitException eee =
                            new EarlyExitException(73, input);
                        throw eee;
                }
                cnt73++;
            } while (true);


                retval.arrayList = ((array_pair_list_scope)array_pair_list_stack.peek()).list;
              

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
            array_pair_list_stack.pop();
        }
        return retval;
    }
    // $ANTLR end "array_pair_list"

    public static class array_pair_element_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "array_pair_element"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:525:1: array_pair_element : ( ^( '=>' e1= expression e2= expression ) | expression );
    public final TreePHP.array_pair_element_return array_pair_element() throws RecognitionException {
        TreePHP.array_pair_element_return retval = new TreePHP.array_pair_element_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST string_literal292=null;
        TreePHP.expression_return e1 = null;

        TreePHP.expression_return e2 = null;

        TreePHP.expression_return expression293 = null;


        SLAST string_literal292_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:526:3: ( ^( '=>' e1= expression e2= expression ) | expression )
            int alt74=2;
            int LA74_0 = input.LA(1);

            if ( (LA74_0==105) ) {
                alt74=1;
            }
            else if ( (LA74_0==METHOD_DECL||LA74_0==VAR_DECL||LA74_0==CALL||LA74_0==EXPR||(LA74_0>=SCALAR && LA74_0<=ARRAY_DECL)||(LA74_0>=EQ && LA74_0<=BACKTRICKLITERAL)||(LA74_0>=126 && LA74_0<=169)) ) {
                alt74=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 74, 0, input);

                throw nvae;
            }
            switch (alt74) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:526:5: ^( '=>' e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    string_literal292=(SLAST)match(input,105,FOLLOW_105_in_array_pair_element2177); 
                    string_literal292_tree = (SLAST)adaptor.dupNode(string_literal292);

                    root_1 = (SLAST)adaptor.becomeRoot(string_literal292_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_array_pair_element2182);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_array_pair_element2186);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = ((CommonToken)(e1!=null?((SLAST)e1.tree):null).token).getStartIndex();
                        int endIndex = ((CommonToken)(e2!=null?((SLAST)e2.tree):null).token).getStopIndex();
                        Expression key = (e1!=null?e1.expr:null);
                        Expression value = (e2!=null?e2.expr:null); 
                        ArrayElement element = new ArrayElement(startIndex, endIndex, key, value);
                        ((array_pair_list_scope)array_pair_list_stack.peek()).list.add(element);
                      

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:535:5: expression
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_array_pair_element2197);
                    expression293=expression();

                    state._fsp--;

                    adaptor.addChild(root_0, expression293.getTree());

                        int startIndex = ((CommonToken)(expression293!=null?((SLAST)expression293.tree):null).token).getStartIndex();
                        int endIndex = ((CommonToken)(expression293!=null?((SLAST)expression293.tree):null).token).getStopIndex();
                        Expression expr = (expression293!=null?expression293.expr:null);
                      
                        System.out.println("expression in array: " + expr);
                        ArrayElement element = new ArrayElement(startIndex, endIndex, expr);
                        ((array_pair_list_scope)array_pair_list_stack.peek()).list.add(element);
                      

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "array_pair_element"

    public static class variable_return extends TreeRuleReturnScope {
        public Expression expr;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "variable"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:549:1: variable returns [Expression expr] : ( base_variable_with_function_calls | ^( CALL v1= variable object_property ( ctor_arguments )? ) );
    public final TreePHP.variable_return variable() throws RecognitionException {
        TreePHP.variable_return retval = new TreePHP.variable_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST CALL295=null;
        TreePHP.variable_return v1 = null;

        TreePHP.base_variable_with_function_calls_return base_variable_with_function_calls294 = null;

        TreePHP.object_property_return object_property296 = null;

        TreePHP.ctor_arguments_return ctor_arguments297 = null;


        SLAST CALL295_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:550:3: ( base_variable_with_function_calls | ^( CALL v1= variable object_property ( ctor_arguments )? ) )
            int alt76=2;
            int LA76_0 = input.LA(1);

            if ( (LA76_0==VAR_DECL) ) {
                alt76=1;
            }
            else if ( (LA76_0==CALL) ) {
                int LA76_2 = input.LA(2);

                if ( (LA76_2==DOWN) ) {
                    int LA76_3 = input.LA(3);

                    if ( (LA76_3==IDENTIFIER) ) {
                        alt76=1;
                    }
                    else if ( (LA76_3==VAR_DECL||LA76_3==CALL) ) {
                        alt76=2;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 76, 3, input);

                        throw nvae;
                    }
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 76, 2, input);

                    throw nvae;
                }
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 76, 0, input);

                throw nvae;
            }
            switch (alt76) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:550:5: base_variable_with_function_calls
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_base_variable_with_function_calls_in_variable2228);
                    base_variable_with_function_calls294=base_variable_with_function_calls();

                    state._fsp--;

                    adaptor.addChild(root_0, base_variable_with_function_calls294.getTree());

                         retval.expr = (base_variable_with_function_calls294!=null?base_variable_with_function_calls294.var:null);
                      

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:554:5: ^( CALL v1= variable object_property ( ctor_arguments )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    CALL295=(SLAST)match(input,CALL,FOLLOW_CALL_in_variable2240); 
                    CALL295_tree = (SLAST)adaptor.dupNode(CALL295);

                    root_1 = (SLAST)adaptor.becomeRoot(CALL295_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_variable_in_variable2244);
                    v1=variable();

                    state._fsp--;

                    adaptor.addChild(root_1, v1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_object_property_in_variable2246);
                    object_property296=object_property();

                    state._fsp--;

                    adaptor.addChild(root_1, object_property296.getTree());
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:554:40: ( ctor_arguments )?
                    int alt75=2;
                    int LA75_0 = input.LA(1);

                    if ( (LA75_0==ARGU) ) {
                        alt75=1;
                    }
                    switch (alt75) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:554:40: ctor_arguments
                            {
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_ctor_arguments_in_variable2248);
                            ctor_arguments297=ctor_arguments();

                            state._fsp--;

                            adaptor.addChild(root_1, ctor_arguments297.getTree());

                            }
                            break;

                    }


                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                         System.out.println("not here not here not here...");
                      
                         int startIndex = ((CommonToken)(object_property296!=null?((SLAST)object_property296.tree):null).token).getStartIndex();
                         int endIndex = ((CommonToken)(object_property296!=null?((SLAST)object_property296.tree):null).token).getStopIndex();
                         SimpleReference ref = new SimpleReference(startIndex, endIndex, (object_property296!=null?object_property296.str:null));
                         
                         Expression RESULT = null;
                         int varleft = ((CommonToken)(v1!=null?((SLAST)v1.tree):null).token).getStartIndex();
                         int varright = ((CommonToken)(v1!=null?((SLAST)v1.tree):null).token).getStopIndex();
                         Expression var = (v1!=null?v1.expr:null);
                         int memberPropertyleft = ((CommonToken)(object_property296!=null?((SLAST)object_property296.tree):null).token).getStartIndex();
                         int memberPropertyright = ((CommonToken)(object_property296!=null?((SLAST)object_property296.tree):null).token).getStopIndex();
                         Expression memberProperty = (Expression)ref;
                        
                         PHPCallArgumentsList paramsList = null;
                         if ((ctor_arguments297!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(ctor_arguments297.start),
                      input.getTreeAdaptor().getTokenStopIndex(ctor_arguments297.start))):null) != null) {
                            paramsList = (ctor_arguments297!=null?ctor_arguments297.argumentList:null);
                         }
                        
                         Expression firstVarProperty = null;
                         if (paramsList == null) {
                            firstVarProperty = memberProperty;
                         } else {
                    	     if (memberProperty.getClass().equals(SimpleReference.class)) {
                    	        firstVarProperty = new PHPCallExpression(memberPropertyleft, ((CommonToken)(ctor_arguments297!=null?((SLAST)ctor_arguments297.tree):null).token).getStopIndex(), null, (SimpleReference)memberProperty, paramsList);
                    	     } else {
                    	        firstVarProperty = new ReflectionCallExpression(memberPropertyleft, ((CommonToken)(ctor_arguments297!=null?((SLAST)ctor_arguments297.tree):null).token).getStopIndex(), null, memberProperty, paramsList);
                    	     }
                    	   }
                    	   // then get the aggregated list of properties (->...->...->...)
                    	   LinkedList list = new LinkedList();
                    	   list.addFirst(firstVarProperty);
                    	  
                    	   // now create the dispatch(es) nodes 
                    	   Expression dispatcher = var;
                    	  
                    	   Iterator listIt = list.iterator();
                    	   while (listIt.hasNext()) {
                    	     Expression property = (Expression)listIt.next();
                    	     dispatcher = createDispatch(dispatcher, property);
                    	   }
                    	   retval.expr = dispatcher;     
                      

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "variable"

    public static class base_variable_with_function_calls_return extends TreeRuleReturnScope {
        public Expression var;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "base_variable_with_function_calls"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:601:1: base_variable_with_function_calls returns [Expression var] : ( ^( VAR_DECL ( fully_qualified_class_name )? object_property ( ctor_arguments )? ) | ^( CALL fully_qualified_class_name ctor_arguments ) );
    public final TreePHP.base_variable_with_function_calls_return base_variable_with_function_calls() throws RecognitionException {
        TreePHP.base_variable_with_function_calls_return retval = new TreePHP.base_variable_with_function_calls_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST VAR_DECL298=null;
        SLAST CALL302=null;
        TreePHP.fully_qualified_class_name_return fully_qualified_class_name299 = null;

        TreePHP.object_property_return object_property300 = null;

        TreePHP.ctor_arguments_return ctor_arguments301 = null;

        TreePHP.fully_qualified_class_name_return fully_qualified_class_name303 = null;

        TreePHP.ctor_arguments_return ctor_arguments304 = null;


        SLAST VAR_DECL298_tree=null;
        SLAST CALL302_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:602:3: ( ^( VAR_DECL ( fully_qualified_class_name )? object_property ( ctor_arguments )? ) | ^( CALL fully_qualified_class_name ctor_arguments ) )
            int alt79=2;
            int LA79_0 = input.LA(1);

            if ( (LA79_0==VAR_DECL) ) {
                alt79=1;
            }
            else if ( (LA79_0==CALL) ) {
                alt79=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 79, 0, input);

                throw nvae;
            }
            switch (alt79) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:602:5: ^( VAR_DECL ( fully_qualified_class_name )? object_property ( ctor_arguments )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    VAR_DECL298=(SLAST)match(input,VAR_DECL,FOLLOW_VAR_DECL_in_base_variable_with_function_calls2272); 
                    VAR_DECL298_tree = (SLAST)adaptor.dupNode(VAR_DECL298);

                    root_1 = (SLAST)adaptor.becomeRoot(VAR_DECL298_tree, root_1);



                    match(input, Token.DOWN, null); 
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:602:16: ( fully_qualified_class_name )?
                    int alt77=2;
                    int LA77_0 = input.LA(1);

                    if ( (LA77_0==IDENTIFIER) ) {
                        int LA77_1 = input.LA(2);

                        if ( (LA77_1==METHOD_DECL||LA77_1==VAR_DECL||LA77_1==INDEX||LA77_1==CALL||LA77_1==EXPR||(LA77_1>=SCALAR && LA77_1<=ARRAY_DECL)||LA77_1==IDENTIFIER||(LA77_1>=EQ && LA77_1<=DOLLAR_T)||LA77_1==108||(LA77_1>=126 && LA77_1<=169)) ) {
                            alt77=1;
                        }
                    }
                    switch (alt77) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:602:16: fully_qualified_class_name
                            {
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_fully_qualified_class_name_in_base_variable_with_function_calls2274);
                            fully_qualified_class_name299=fully_qualified_class_name();

                            state._fsp--;

                            adaptor.addChild(root_1, fully_qualified_class_name299.getTree());

                            }
                            break;

                    }

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_object_property_in_base_variable_with_function_calls2277);
                    object_property300=object_property();

                    state._fsp--;

                    adaptor.addChild(root_1, object_property300.getTree());

                         int startIndex = VAR_DECL298.startIndex;
                         int endIndex = VAR_DECL298.endIndex;
                         VariableReference variableRef = new VariableReference(startIndex, endIndex, (object_property300!=null?object_property300.str:null), PHPVariableKind.LOCAL);
                         retval.var = variableRef;        
                      
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:609:4: ( ctor_arguments )?
                    int alt78=2;
                    int LA78_0 = input.LA(1);

                    if ( (LA78_0==ARGU) ) {
                        alt78=1;
                    }
                    switch (alt78) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:609:4: ctor_arguments
                            {
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_ctor_arguments_in_base_variable_with_function_calls2286);
                            ctor_arguments301=ctor_arguments();

                            state._fsp--;

                            adaptor.addChild(root_1, ctor_arguments301.getTree());

                            }
                            break;

                    }


                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:611:5: ^( CALL fully_qualified_class_name ctor_arguments )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    CALL302=(SLAST)match(input,CALL,FOLLOW_CALL_in_base_variable_with_function_calls2298); 
                    CALL302_tree = (SLAST)adaptor.dupNode(CALL302);

                    root_1 = (SLAST)adaptor.becomeRoot(CALL302_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_fully_qualified_class_name_in_base_variable_with_function_calls2300);
                    fully_qualified_class_name303=fully_qualified_class_name();

                    state._fsp--;

                    adaptor.addChild(root_1, fully_qualified_class_name303.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_ctor_arguments_in_base_variable_with_function_calls2302);
                    ctor_arguments304=ctor_arguments();

                    state._fsp--;

                    adaptor.addChild(root_1, ctor_arguments304.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = CALL302.startIndex;
                        int endIndex = CALL302.endIndex;
                        int functionNameLeft= ((CommonToken)(fully_qualified_class_name303!=null?((SLAST)fully_qualified_class_name303.tree):null).token).getStartIndex();
                        int functionNameRight= ((CommonToken)(fully_qualified_class_name303!=null?((SLAST)fully_qualified_class_name303.tree):null).token).getStopIndex();
                        String functionName = (fully_qualified_class_name303!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(fully_qualified_class_name303.start),
                      input.getTreeAdaptor().getTokenStopIndex(fully_qualified_class_name303.start))):null);
                        PHPCallArgumentsList parameters = (ctor_arguments304!=null?ctor_arguments304.argumentList:null);
                        SimpleReference name = new SimpleReference(functionNameLeft, functionNameRight, functionName);
                        retval.var = new PHPCallExpression(startIndex, endIndex, null, name, parameters); 
                      

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "base_variable_with_function_calls"

    public static class object_property_return extends TreeRuleReturnScope {
        public String str;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "object_property"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:626:1: object_property returns [String str] : ( ( DOLLAR_T )* IDENTIFIER | ( DOLLAR_T )* expression | ^( INDEX object_property expression ) );
    public final TreePHP.object_property_return object_property() throws RecognitionException {
        TreePHP.object_property_return retval = new TreePHP.object_property_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST DOLLAR_T305=null;
        SLAST IDENTIFIER306=null;
        SLAST DOLLAR_T307=null;
        SLAST INDEX309=null;
        TreePHP.expression_return expression308 = null;

        TreePHP.object_property_return object_property310 = null;

        TreePHP.expression_return expression311 = null;


        SLAST DOLLAR_T305_tree=null;
        SLAST IDENTIFIER306_tree=null;
        SLAST DOLLAR_T307_tree=null;
        SLAST INDEX309_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:627:3: ( ( DOLLAR_T )* IDENTIFIER | ( DOLLAR_T )* expression | ^( INDEX object_property expression ) )
            int alt82=3;
            alt82 = dfa82.predict(input);
            switch (alt82) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:627:5: ( DOLLAR_T )* IDENTIFIER
                    {
                    root_0 = (SLAST)adaptor.nil();

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:627:5: ( DOLLAR_T )*
                    loop80:
                    do {
                        int alt80=2;
                        int LA80_0 = input.LA(1);

                        if ( (LA80_0==DOLLAR_T) ) {
                            alt80=1;
                        }


                        switch (alt80) {
                    	case 1 :
                    	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:627:5: DOLLAR_T
                    	    {
                    	    _last = (SLAST)input.LT(1);
                    	    DOLLAR_T305=(SLAST)match(input,DOLLAR_T,FOLLOW_DOLLAR_T_in_object_property2330); 
                    	    DOLLAR_T305_tree = (SLAST)adaptor.dupNode(DOLLAR_T305);

                    	    adaptor.addChild(root_0, DOLLAR_T305_tree);


                    	    }
                    	    break;

                    	default :
                    	    break loop80;
                        }
                    } while (true);

                    _last = (SLAST)input.LT(1);
                    IDENTIFIER306=(SLAST)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_object_property2333); 
                    IDENTIFIER306_tree = (SLAST)adaptor.dupNode(IDENTIFIER306);

                    adaptor.addChild(root_0, IDENTIFIER306_tree);


                            retval.str = (IDENTIFIER306!=null?IDENTIFIER306.getText():null);
                            if ((DOLLAR_T305!=null?DOLLAR_T305.getText():null) != null) {
                                retval.str = (DOLLAR_T305!=null?DOLLAR_T305.getText():null) + (IDENTIFIER306!=null?IDENTIFIER306.getText():null);
                            } 
                        

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:634:5: ( DOLLAR_T )* expression
                    {
                    root_0 = (SLAST)adaptor.nil();

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:634:5: ( DOLLAR_T )*
                    loop81:
                    do {
                        int alt81=2;
                        int LA81_0 = input.LA(1);

                        if ( (LA81_0==DOLLAR_T) ) {
                            alt81=1;
                        }


                        switch (alt81) {
                    	case 1 :
                    	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:634:5: DOLLAR_T
                    	    {
                    	    _last = (SLAST)input.LT(1);
                    	    DOLLAR_T307=(SLAST)match(input,DOLLAR_T,FOLLOW_DOLLAR_T_in_object_property2345); 
                    	    DOLLAR_T307_tree = (SLAST)adaptor.dupNode(DOLLAR_T307);

                    	    adaptor.addChild(root_0, DOLLAR_T307_tree);


                    	    }
                    	    break;

                    	default :
                    	    break loop81;
                        }
                    } while (true);

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_object_property2348);
                    expression308=expression();

                    state._fsp--;

                    adaptor.addChild(root_0, expression308.getTree());

                    }
                    break;
                case 3 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:635:5: ^( INDEX object_property expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    INDEX309=(SLAST)match(input,INDEX,FOLLOW_INDEX_in_object_property2355); 
                    INDEX309_tree = (SLAST)adaptor.dupNode(INDEX309);

                    root_1 = (SLAST)adaptor.becomeRoot(INDEX309_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_object_property_in_object_property2357);
                    object_property310=object_property();

                    state._fsp--;

                    adaptor.addChild(root_1, object_property310.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_object_property2359);
                    expression311=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression311.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "object_property"

    public static class ctor_arguments_return extends TreeRuleReturnScope {
        public PHPCallArgumentsList argumentList;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "ctor_arguments"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:638:1: ctor_arguments returns [PHPCallArgumentsList argumentList] : ^( ARGU ( expr_list )? ) ;
    public final TreePHP.ctor_arguments_return ctor_arguments() throws RecognitionException {
        TreePHP.ctor_arguments_return retval = new TreePHP.ctor_arguments_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST ARGU312=null;
        TreePHP.expr_list_return expr_list313 = null;


        SLAST ARGU312_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:639:3: ( ^( ARGU ( expr_list )? ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:639:6: ^( ARGU ( expr_list )? )
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_1 = _last;
            SLAST _first_1 = null;
            SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            ARGU312=(SLAST)match(input,ARGU,FOLLOW_ARGU_in_ctor_arguments2383); 
            ARGU312_tree = (SLAST)adaptor.dupNode(ARGU312);

            root_1 = (SLAST)adaptor.becomeRoot(ARGU312_tree, root_1);



            if ( input.LA(1)==Token.DOWN ) {
                match(input, Token.DOWN, null); 
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:639:13: ( expr_list )?
                int alt83=2;
                int LA83_0 = input.LA(1);

                if ( (LA83_0==METHOD_DECL||LA83_0==VAR_DECL||LA83_0==CALL||LA83_0==EXPR||(LA83_0>=SCALAR && LA83_0<=ARRAY_DECL)||(LA83_0>=EQ && LA83_0<=BACKTRICKLITERAL)||(LA83_0>=126 && LA83_0<=169)) ) {
                    alt83=1;
                }
                switch (alt83) {
                    case 1 :
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:639:13: expr_list
                        {
                        _last = (SLAST)input.LT(1);
                        pushFollow(FOLLOW_expr_list_in_ctor_arguments2385);
                        expr_list313=expr_list();

                        state._fsp--;

                        adaptor.addChild(root_1, expr_list313.getTree());

                        }
                        break;

                }


                match(input, Token.UP, null); 
            }adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


                int startIndex = ARGU312.startIndex;
                int endIndex = ARGU312.endIndex;

            	  retval.argumentList = new PHPCallArgumentsList();
            	  retval.argumentList.setStart(startIndex);
            	  retval.argumentList.setEnd(endIndex);
            //	  retval.argumentList.addNode(var);  
            	  
            	  System.out.println("parameter: " + retval.argumentList);
              

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "ctor_arguments"

    public static class pure_variable_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "pure_variable"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:653:1: pure_variable : ^( VAR_DECL ( '&' )? ( DOLLAR_T )+ IDENTIFIER ) ;
    public final TreePHP.pure_variable_return pure_variable() throws RecognitionException {
        TreePHP.pure_variable_return retval = new TreePHP.pure_variable_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST VAR_DECL314=null;
        SLAST char_literal315=null;
        SLAST DOLLAR_T316=null;
        SLAST IDENTIFIER317=null;

        SLAST VAR_DECL314_tree=null;
        SLAST char_literal315_tree=null;
        SLAST DOLLAR_T316_tree=null;
        SLAST IDENTIFIER317_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:654:3: ( ^( VAR_DECL ( '&' )? ( DOLLAR_T )+ IDENTIFIER ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:654:5: ^( VAR_DECL ( '&' )? ( DOLLAR_T )+ IDENTIFIER )
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_1 = _last;
            SLAST _first_1 = null;
            SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            VAR_DECL314=(SLAST)match(input,VAR_DECL,FOLLOW_VAR_DECL_in_pure_variable2407); 
            VAR_DECL314_tree = (SLAST)adaptor.dupNode(VAR_DECL314);

            root_1 = (SLAST)adaptor.becomeRoot(VAR_DECL314_tree, root_1);



            match(input, Token.DOWN, null); 
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:655:4: ( '&' )?
            int alt84=2;
            int LA84_0 = input.LA(1);

            if ( (LA84_0==BIT_AND) ) {
                alt84=1;
            }
            switch (alt84) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:655:4: '&'
                    {
                    _last = (SLAST)input.LT(1);
                    char_literal315=(SLAST)match(input,BIT_AND,FOLLOW_BIT_AND_in_pure_variable2412); 
                    char_literal315_tree = (SLAST)adaptor.dupNode(char_literal315);

                    adaptor.addChild(root_1, char_literal315_tree);


                    }
                    break;

            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:655:9: ( DOLLAR_T )+
            int cnt85=0;
            loop85:
            do {
                int alt85=2;
                int LA85_0 = input.LA(1);

                if ( (LA85_0==DOLLAR_T) ) {
                    alt85=1;
                }


                switch (alt85) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:655:9: DOLLAR_T
            	    {
            	    _last = (SLAST)input.LT(1);
            	    DOLLAR_T316=(SLAST)match(input,DOLLAR_T,FOLLOW_DOLLAR_T_in_pure_variable2415); 
            	    DOLLAR_T316_tree = (SLAST)adaptor.dupNode(DOLLAR_T316);

            	    adaptor.addChild(root_1, DOLLAR_T316_tree);


            	    }
            	    break;

            	default :
            	    if ( cnt85 >= 1 ) break loop85;
                        EarlyExitException eee =
                            new EarlyExitException(85, input);
                        throw eee;
                }
                cnt85++;
            } while (true);

            _last = (SLAST)input.LT(1);
            IDENTIFIER317=(SLAST)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_pure_variable2418); 
            IDENTIFIER317_tree = (SLAST)adaptor.dupNode(IDENTIFIER317);

            adaptor.addChild(root_1, IDENTIFIER317_tree);


            match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "pure_variable"

    public static class scalar_return extends TreeRuleReturnScope {
        public Expression expr;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "scalar"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:658:1: scalar returns [Expression expr] : ^( SCALAR constant ) ;
    public final TreePHP.scalar_return scalar() throws RecognitionException {
        TreePHP.scalar_return retval = new TreePHP.scalar_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST SCALAR318=null;
        TreePHP.constant_return constant319 = null;


        SLAST SCALAR318_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:659:3: ( ^( SCALAR constant ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:659:5: ^( SCALAR constant )
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_1 = _last;
            SLAST _first_1 = null;
            SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            SCALAR318=(SLAST)match(input,SCALAR,FOLLOW_SCALAR_in_scalar2439); 
            SCALAR318_tree = (SLAST)adaptor.dupNode(SCALAR318);

            root_1 = (SLAST)adaptor.becomeRoot(SCALAR318_tree, root_1);



            match(input, Token.DOWN, null); 
            _last = (SLAST)input.LT(1);
            pushFollow(FOLLOW_constant_in_scalar2441);
            constant319=constant();

            state._fsp--;

            adaptor.addChild(root_1, constant319.getTree());

            match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


                retval.expr = (constant319!=null?constant319.scalar:null);
              

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "scalar"

    public static class constant_return extends TreeRuleReturnScope {
        public Scalar scalar;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "constant"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:665:1: constant returns [Scalar scalar] : ( INTLITERAL | FLOATLITERAL | STRINGLITERAL | DOUBLELITERRAL | common_scalar | fully_qualified_class_name );
    public final TreePHP.constant_return constant() throws RecognitionException {
        TreePHP.constant_return retval = new TreePHP.constant_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST INTLITERAL320=null;
        SLAST FLOATLITERAL321=null;
        SLAST STRINGLITERAL322=null;
        SLAST DOUBLELITERRAL323=null;
        TreePHP.common_scalar_return common_scalar324 = null;

        TreePHP.fully_qualified_class_name_return fully_qualified_class_name325 = null;


        SLAST INTLITERAL320_tree=null;
        SLAST FLOATLITERAL321_tree=null;
        SLAST STRINGLITERAL322_tree=null;
        SLAST DOUBLELITERRAL323_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:666:3: ( INTLITERAL | FLOATLITERAL | STRINGLITERAL | DOUBLELITERRAL | common_scalar | fully_qualified_class_name )
            int alt86=6;
            switch ( input.LA(1) ) {
            case INTLITERAL:
                {
                alt86=1;
                }
                break;
            case FLOATLITERAL:
                {
                alt86=2;
                }
                break;
            case STRINGLITERAL:
                {
                alt86=3;
                }
                break;
            case DOUBLELITERRAL:
                {
                alt86=4;
                }
                break;
            case 173:
            case 174:
            case 175:
            case 176:
            case 177:
            case 178:
                {
                alt86=5;
                }
                break;
            case IDENTIFIER:
                {
                alt86=6;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 86, 0, input);

                throw nvae;
            }

            switch (alt86) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:666:7: INTLITERAL
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    INTLITERAL320=(SLAST)match(input,INTLITERAL,FOLLOW_INTLITERAL_in_constant2467); 
                    INTLITERAL320_tree = (SLAST)adaptor.dupNode(INTLITERAL320);

                    adaptor.addChild(root_0, INTLITERAL320_tree);


                        CommonToken token = (CommonToken)INTLITERAL320.token;
                        int startIndex = token.getStartIndex();
                        int endIndex = token.getStopIndex() + 1;
                        retval.scalar = new Scalar(startIndex, endIndex, (INTLITERAL320!=null?INTLITERAL320.getText():null), Scalar.TYPE_INT);
                      

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:673:7: FLOATLITERAL
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    FLOATLITERAL321=(SLAST)match(input,FLOATLITERAL,FOLLOW_FLOATLITERAL_in_constant2479); 
                    FLOATLITERAL321_tree = (SLAST)adaptor.dupNode(FLOATLITERAL321);

                    adaptor.addChild(root_0, FLOATLITERAL321_tree);


                    }
                    break;
                case 3 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:674:7: STRINGLITERAL
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    STRINGLITERAL322=(SLAST)match(input,STRINGLITERAL,FOLLOW_STRINGLITERAL_in_constant2487); 
                    STRINGLITERAL322_tree = (SLAST)adaptor.dupNode(STRINGLITERAL322);

                    adaptor.addChild(root_0, STRINGLITERAL322_tree);


                        CommonToken token = (CommonToken)STRINGLITERAL322.token;
                        int startIndex = token.getStartIndex();
                        int endIndex = token.getStopIndex() + 1;
                        retval.scalar = new Scalar(startIndex, endIndex, (STRINGLITERAL322!=null?STRINGLITERAL322.getText():null), Scalar.TYPE_STRING);
                      

                    }
                    break;
                case 4 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:681:7: DOUBLELITERRAL
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    DOUBLELITERRAL323=(SLAST)match(input,DOUBLELITERRAL,FOLLOW_DOUBLELITERRAL_in_constant2499); 
                    DOUBLELITERRAL323_tree = (SLAST)adaptor.dupNode(DOUBLELITERRAL323);

                    adaptor.addChild(root_0, DOUBLELITERRAL323_tree);


                    }
                    break;
                case 5 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:682:7: common_scalar
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_common_scalar_in_constant2507);
                    common_scalar324=common_scalar();

                    state._fsp--;

                    adaptor.addChild(root_0, common_scalar324.getTree());

                    }
                    break;
                case 6 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:683:7: fully_qualified_class_name
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_fully_qualified_class_name_in_constant2515);
                    fully_qualified_class_name325=fully_qualified_class_name();

                    state._fsp--;

                    adaptor.addChild(root_0, fully_qualified_class_name325.getTree());

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "constant"

    public static class common_scalar_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "common_scalar"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:686:1: common_scalar : ( '__CLASS__' | '__DIR__' | '__FILE__' | '__FUNCTION__' | '__METHOD__' | '__NAMESPACE__' );
    public final TreePHP.common_scalar_return common_scalar() throws RecognitionException {
        TreePHP.common_scalar_return retval = new TreePHP.common_scalar_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST set326=null;

        SLAST set326_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:687:3: ( '__CLASS__' | '__DIR__' | '__FILE__' | '__FUNCTION__' | '__METHOD__' | '__NAMESPACE__' )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            set326=(SLAST)input.LT(1);
            if ( (input.LA(1)>=173 && input.LA(1)<=178) ) {
                input.consume();

                set326_tree = (SLAST)adaptor.dupNode(set326);

                adaptor.addChild(root_0, set326_tree);

                state.errorRecovery=false;
            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                throw mse;
            }

             

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "common_scalar"

    // Delegated rules


    protected DFA64 dfa64 = new DFA64(this);
    protected DFA82 dfa82 = new DFA82(this);
    static final String DFA64_eotS =
        "\56\uffff";
    static final String DFA64_eofS =
        "\56\uffff";
    static final String DFA64_minS =
        "\1\11\34\uffff\1\2\3\uffff\1\15\5\uffff\1\2\6\uffff";
    static final String DFA64_maxS =
        "\1\u00a9\34\uffff\1\u00a9\3\uffff\1\44\5\uffff\1\u00a9\6\uffff";
    static final String DFA64_acceptS =
        "\1\uffff\1\1\1\2\1\3\1\4\1\5\1\6\1\7\1\10\1\11\1\12\1\13\1\14\1"+
        "\15\1\16\1\17\1\20\1\21\1\22\1\23\1\24\1\25\1\26\1\27\1\30\1\31"+
        "\1\32\1\33\1\34\1\uffff\1\36\1\37\1\40\1\uffff\1\41\1\42\1\43\1"+
        "\44\1\45\1\uffff\1\47\1\35\1\51\1\52\1\46\1\50";
    static final String DFA64_specialS =
        "\56\uffff}>";
    static final String[] DFA64_transitionS = {
            "\1\52\3\uffff\1\42\5\uffff\1\42\1\uffff\1\1\16\uffff\1\43\1"+
            "\45\12\uffff\1\5\13\6\1\14\1\53\100\uffff\1\2\1\3\1\4\1\7\1"+
            "\10\1\11\1\12\1\13\1\15\1\16\1\17\1\20\1\21\1\22\1\23\1\24\1"+
            "\25\1\26\1\27\1\30\1\31\1\32\1\33\1\34\7\51\1\47\1\35\2\51\2"+
            "\36\2\37\1\40\1\41\1\44\1\46\1\50",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\1\54\6\uffff\1\51\3\uffff\1\51\5\uffff\1\51\1\uffff\1\51\16"+
            "\uffff\2\51\12\uffff\16\51\100\uffff\54\51",
            "",
            "",
            "",
            "\1\42\5\uffff\1\42\20\uffff\1\43",
            "",
            "",
            "",
            "",
            "",
            "\1\55\6\uffff\1\51\3\uffff\1\51\5\uffff\1\51\1\uffff\1\51\16"+
            "\uffff\2\51\12\uffff\16\51\100\uffff\54\51",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA64_eot = DFA.unpackEncodedString(DFA64_eotS);
    static final short[] DFA64_eof = DFA.unpackEncodedString(DFA64_eofS);
    static final char[] DFA64_min = DFA.unpackEncodedStringToUnsignedChars(DFA64_minS);
    static final char[] DFA64_max = DFA.unpackEncodedStringToUnsignedChars(DFA64_maxS);
    static final short[] DFA64_accept = DFA.unpackEncodedString(DFA64_acceptS);
    static final short[] DFA64_special = DFA.unpackEncodedString(DFA64_specialS);
    static final short[][] DFA64_transition;

    static {
        int numStates = DFA64_transitionS.length;
        DFA64_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA64_transition[i] = DFA.unpackEncodedString(DFA64_transitionS[i]);
        }
    }

    class DFA64 extends DFA {

        public DFA64(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 64;
            this.eot = DFA64_eot;
            this.eof = DFA64_eof;
            this.min = DFA64_min;
            this.max = DFA64_max;
            this.accept = DFA64_accept;
            this.special = DFA64_special;
            this.transition = DFA64_transition;
        }
        public String getDescription() {
            return "385:1: expression returns [Expression expr] : ( ^( EXPR etop= expression ) | ^( 'OR' expression expression ) | ^( 'XOR' expression expression ) | ^( 'AND' expression expression ) | ^( EQ e1= expression e2= expression ) | ^( assignment_operator expression expression ) | ^( '?' expression ^( ':' expression expression ) ) | ^( '||' expression expression ) | ^( '&&' expression expression ) | ^( '|' expression expression ) | ^( '^' expression expression ) | ^( BIT_AND e1= expression e2= expression ) | ^( '.' expression expression ) | ^( '==' expression expression ) | ^( '!=' expression expression ) | ^( '===' expression expression ) | ^( '!==' expression expression ) | ^( '<' expression expression ) | ^( '>' expression expression ) | ^( '<=' expression expression ) | ^( '>=' expression expression ) | ^( '<<' expression expression ) | ^( '>>' expression expression ) | ^( '+' expression expression ) | ^( '-' expression expression ) | ^( '*' expression expression ) | ^( '/' expression expression ) | ^( '%' expression expression ) | cast_option expression | ^( ( '~' | '!' ) expression ) | ^( ( '++' | '--' ) expression ) | ^( 'instanceof' expression class_name_reference ) | ( '@' )? variable | ( '@' )? scalar | ^( 'list' ( assignment_list )? ) | ^( ARRAY_DECL ( array_pair_list )? ) | ^( 'new' class_name_reference ) | ^( 'clone' variable ) | ^( 'exit' ( expression )? ) | ^( 'unset' variable ) | lambda_function_declaration | BACKTRICKLITERAL );";
        }
    }
    static final String DFA82_eotS =
        "\5\uffff";
    static final String DFA82_eofS =
        "\5\uffff";
    static final String DFA82_minS =
        "\2\11\3\uffff";
    static final String DFA82_maxS =
        "\2\u00a9\3\uffff";
    static final String DFA82_acceptS =
        "\2\uffff\1\1\1\2\1\3";
    static final String DFA82_specialS =
        "\5\uffff}>";
    static final String[] DFA82_transitionS = {
            "\1\3\3\uffff\1\3\3\uffff\1\4\1\uffff\1\3\1\uffff\1\3\16\uffff"+
            "\2\3\6\uffff\1\2\3\uffff\16\3\1\1\77\uffff\54\3",
            "\1\3\3\uffff\1\3\5\uffff\1\3\1\uffff\1\3\16\uffff\2\3\6\uffff"+
            "\1\2\3\uffff\16\3\1\1\77\uffff\54\3",
            "",
            "",
            ""
    };

    static final short[] DFA82_eot = DFA.unpackEncodedString(DFA82_eotS);
    static final short[] DFA82_eof = DFA.unpackEncodedString(DFA82_eofS);
    static final char[] DFA82_min = DFA.unpackEncodedStringToUnsignedChars(DFA82_minS);
    static final char[] DFA82_max = DFA.unpackEncodedStringToUnsignedChars(DFA82_maxS);
    static final short[] DFA82_accept = DFA.unpackEncodedString(DFA82_acceptS);
    static final short[] DFA82_special = DFA.unpackEncodedString(DFA82_specialS);
    static final short[][] DFA82_transition;

    static {
        int numStates = DFA82_transitionS.length;
        DFA82_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA82_transition[i] = DFA.unpackEncodedString(DFA82_transitionS[i]);
        }
    }

    class DFA82 extends DFA {

        public DFA82(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 82;
            this.eot = DFA82_eot;
            this.eof = DFA82_eof;
            this.min = DFA82_min;
            this.max = DFA82_max;
            this.accept = DFA82_accept;
            this.special = DFA82_special;
            this.transition = DFA82_transition;
        }
        public String getDescription() {
            return "626:1: object_property returns [String str] : ( ( DOLLAR_T )* IDENTIFIER | ( DOLLAR_T )* expression | ^( INDEX object_property expression ) );";
        }
    }
 

    public static final BitSet FOLLOW_ModuleDeclaration_in_php_source58 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_top_statement_list_in_php_source60 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_top_statement_in_top_statement_list79 = new BitSet(new long[]{0x0000080000004002L,0x0000000001220000L});
    public static final BitSet FOLLOW_statement_in_top_statement93 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_function_declaration_statement_in_top_statement103 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_class_declaration_statement_in_top_statement109 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_halt_compiler_statement_in_top_statement119 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_inner_statement_in_inner_statement_list133 = new BitSet(new long[]{0x0000080000004002L,0x0000000001220000L});
    public static final BitSet FOLLOW_statement_in_inner_statement150 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_function_declaration_statement_in_inner_statement157 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_class_declaration_statement_in_inner_statement163 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_halt_compiler_statement_in_inner_statement169 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_81_in_halt_compiler_statement184 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_CLASS_T_in_class_declaration_statement204 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_class_entr_type_in_class_declaration_statement206 = new BitSet(new long[]{0x0000100000000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_class_declaration_statement209 = new BitSet(new long[]{0x0000000000000088L,0x0000000000180000L});
    public static final BitSet FOLLOW_83_in_class_declaration_statement213 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_fully_qualified_class_name_in_class_declaration_statement215 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_84_in_class_declaration_statement222 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_fully_qualified_class_name_list_in_class_declaration_statement224 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_CLASS_BODY_in_class_declaration_statement237 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_class_statement_list_in_class_declaration_statement239 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_85_in_class_declaration_statement256 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_IDENTIFIER_in_class_declaration_statement258 = new BitSet(new long[]{0x0000000000000088L,0x0000000000180000L});
    public static final BitSet FOLLOW_83_in_class_declaration_statement262 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_fully_qualified_class_name_list_in_class_declaration_statement264 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_84_in_class_declaration_statement271 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_fully_qualified_class_name_list_in_class_declaration_statement273 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_CLASS_BODY_in_class_declaration_statement286 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_class_statement_list_in_class_declaration_statement288 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_set_in_class_entr_type0 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_class_statement_in_class_statement_list328 = new BitSet(new long[]{0x0000000000000302L});
    public static final BitSet FOLLOW_FIELD_DECL_in_class_statement348 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_variable_modifiers_in_class_statement350 = new BitSet(new long[]{0x0000000002000000L});
    public static final BitSet FOLLOW_static_var_list_in_class_statement352 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_METHOD_DECL_in_class_statement360 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_modifier_in_class_statement362 = new BitSet(new long[]{0x0000000000000200L});
    public static final BitSet FOLLOW_method_declaration_in_class_statement364 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_FIELD_DECL_in_class_statement372 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_class_constant_declaration_in_class_statement374 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_VAR_DECL_in_class_constant_declaration389 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_106_in_class_constant_declaration391 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_directive_in_class_constant_declaration393 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_88_in_function_declaration_statement412 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_BIT_AND_in_function_declaration_statement414 = new BitSet(new long[]{0x0000100000000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_function_declaration_statement417 = new BitSet(new long[]{0x0000000000001800L});
    public static final BitSet FOLLOW_parameter_list_in_function_declaration_statement419 = new BitSet(new long[]{0x0000000000001800L});
    public static final BitSet FOLLOW_block_in_function_declaration_statement422 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_BLOCK_in_block438 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_inner_statement_list_in_block440 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_STATEMENT_in_statement462 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_topStatement_in_statement464 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_block_in_topStatement486 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_if_stat_in_topStatement493 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_89_in_topStatement500 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_CONDITION_in_topStatement503 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_topStatement505 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_while_statement_in_topStatement508 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_90_in_topStatement516 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_CONDITION_in_topStatement519 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_topStatement521 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_statement_in_topStatement524 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_91_in_topStatement532 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_list_in_topStatement534 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_CONDITION_in_topStatement538 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_list_in_topStatement540 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_ITERATE_in_topStatement545 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_list_in_topStatement547 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_for_statement_in_topStatement551 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_92_in_topStatement559 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_CONDITION_in_topStatement562 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_topStatement564 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_switch_case_list_in_topStatement567 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_93_in_topStatement575 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_topStatement577 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_94_in_topStatement586 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_topStatement588 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_95_in_topStatement597 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_topStatement599 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_96_in_topStatement608 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_variable_in_topStatement610 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_97_in_topStatement618 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_static_var_list_in_topStatement620 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_98_in_topStatement628 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_list_in_topStatement630 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_expression_in_topStatement637 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_99_in_topStatement648 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_100_in_topStatement651 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_topStatement653 = new BitSet(new long[]{0x0000000000082000L,0x0000020000000000L});
    public static final BitSet FOLLOW_foreach_variable_in_topStatement655 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_foreach_statement_in_topStatement658 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_101_in_topStatement666 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_CONDITION_in_topStatement669 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_directive_in_topStatement671 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_declare_statement_in_topStatement674 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_102_in_topStatement682 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_BLOCK_in_topStatement685 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_top_statement_in_topStatement687 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_catch_branch_in_topStatement690 = new BitSet(new long[]{0x0000000000000008L,0x0020000000000000L});
    public static final BitSet FOLLOW_103_in_topStatement699 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_topStatement701 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_104_in_topStatement709 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_use_filename_in_topStatement711 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_105_in_foreach_variable731 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_variable_in_foreach_variable733 = new BitSet(new long[]{0x0000000000082000L,0x0000020000000000L});
    public static final BitSet FOLLOW_variable_in_foreach_variable735 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_variable_in_foreach_variable742 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_STRINGLITERAL_in_use_filename757 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_METHOD_DECL_in_method_declaration773 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_BIT_AND_in_method_declaration775 = new BitSet(new long[]{0x0000100000000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_method_declaration778 = new BitSet(new long[]{0x0000000800001800L});
    public static final BitSet FOLLOW_parameter_list_in_method_declaration780 = new BitSet(new long[]{0x0000000800001800L});
    public static final BitSet FOLLOW_block_in_method_declaration784 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_EMPTYSTATEMENT_in_method_declaration787 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_fully_qualified_class_name_in_fully_qualified_class_name_list816 = new BitSet(new long[]{0x0000100000000002L});
    public static final BitSet FOLLOW_IDENTIFIER_in_fully_qualified_class_name836 = new BitSet(new long[]{0x0000000000000002L,0x0000100000000000L});
    public static final BitSet FOLLOW_108_in_fully_qualified_class_name839 = new BitSet(new long[]{0x0000100000000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_fully_qualified_class_name842 = new BitSet(new long[]{0x0000000000000002L,0x0000100000000000L});
    public static final BitSet FOLLOW_108_in_fully_qualified_class_name846 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_SCALAR_ELEMENT_in_static_array_pair_list870 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_static_scalar_element_in_static_array_pair_list872 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_scalar_in_static_scalar_element889 = new BitSet(new long[]{0x0000000000000002L,0x0000020000000000L});
    public static final BitSet FOLLOW_105_in_static_scalar_element892 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_scalar_in_static_scalar_element895 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_SCALAR_VAR_in_static_var_list914 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_static_var_element_in_static_var_list916 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_pure_variable_in_static_var_element932 = new BitSet(new long[]{0x0001000000000002L});
    public static final BitSet FOLLOW_EQ_in_static_var_element935 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_scalar_in_static_var_element938 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_109_in_if_stat956 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_CONDITION_in_if_stat959 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_if_stat961 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_inner_statement_list_in_if_stat977 = new BitSet(new long[]{0x0000000000000008L,0x0000C00000000000L});
    public static final BitSet FOLLOW_110_in_if_stat988 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_CONDITION_in_if_stat991 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_if_stat993 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_inner_statement_list_in_if_stat996 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_111_in_if_stat1004 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_statement_in_if_stat1006 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_case_list_in_switch_case_list1031 = new BitSet(new long[]{0x0000000000000002L,0x0018000000000000L});
    public static final BitSet FOLLOW_115_in_case_list1046 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_case_list1048 = new BitSet(new long[]{0x0000080000004008L,0x0000000001220000L});
    public static final BitSet FOLLOW_inner_statement_list_in_case_list1050 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_116_in_case_list1059 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_inner_statement_list_in_case_list1061 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_117_in_catch_branch1078 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_IDENTIFIER_in_catch_branch1080 = new BitSet(new long[]{0x0000000000082000L,0x0000020000000000L});
    public static final BitSet FOLLOW_variable_in_catch_branch1082 = new BitSet(new long[]{0x0000000000001800L});
    public static final BitSet FOLLOW_block_in_catch_branch1084 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_inner_statement_list_in_for_statement1097 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_inner_statement_list_in_while_statement1110 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_inner_statement_list_in_foreach_statement1124 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_inner_statement_list_in_declare_statement1140 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_parameter_in_parameter_list1156 = new BitSet(new long[]{0x0000000000000802L});
    public static final BitSet FOLLOW_PARAMETER_in_parameter1173 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_TYPE_in_parameter1177 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_parameter_type_in_parameter1179 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_106_in_parameter1184 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_pure_variable_in_parameter1187 = new BitSet(new long[]{0x0000001000000008L});
    public static final BitSet FOLLOW_scalar_in_parameter1189 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_fully_qualified_class_name_in_parameter_type1206 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_cast_option_in_parameter_type1210 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_122_in_variable_modifiers1229 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_modifier_in_variable_modifiers1235 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_modifier1249 = new BitSet(new long[]{0x0000000000000002L,0x3800000200C00000L});
    public static final BitSet FOLLOW_EQ_in_directive1302 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_IDENTIFIER_in_directive1304 = new BitSet(new long[]{0x3FFF003000282200L,0xC000020000000000L,0x000003FFFFFFFFFFL});
    public static final BitSet FOLLOW_expression_in_directive1306 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_expression_in_expr_list1323 = new BitSet(new long[]{0x3FFF003000282202L,0xC000020000000000L,0x000003FFFFFFFFFFL});
    public static final BitSet FOLLOW_EXPR_in_expression1344 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1348 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_126_in_expression1360 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1362 = new BitSet(new long[]{0x3FFF003000282200L,0xC000020000000000L,0x000003FFFFFFFFFFL});
    public static final BitSet FOLLOW_expression_in_expression1364 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_127_in_expression1372 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1374 = new BitSet(new long[]{0x3FFF003000282200L,0xC000020000000000L,0x000003FFFFFFFFFFL});
    public static final BitSet FOLLOW_expression_in_expression1376 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_128_in_expression1384 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1386 = new BitSet(new long[]{0x3FFF003000282200L,0xC000020000000000L,0x000003FFFFFFFFFFL});
    public static final BitSet FOLLOW_expression_in_expression1388 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_EQ_in_expression1396 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1400 = new BitSet(new long[]{0x3FFF003000282200L,0xC000020000000000L,0x000003FFFFFFFFFFL});
    public static final BitSet FOLLOW_expression_in_expression1404 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_assignment_operator_in_expression1417 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1419 = new BitSet(new long[]{0x3FFF003000282200L,0xC000020000000000L,0x000003FFFFFFFFFFL});
    public static final BitSet FOLLOW_expression_in_expression1421 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_129_in_expression1429 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1431 = new BitSet(new long[]{0x0000000000000000L,0x0001000000000000L});
    public static final BitSet FOLLOW_112_in_expression1434 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1436 = new BitSet(new long[]{0x3FFF003000282200L,0xC000020000000000L,0x000003FFFFFFFFFFL});
    public static final BitSet FOLLOW_expression_in_expression1438 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_130_in_expression1447 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1449 = new BitSet(new long[]{0x3FFF003000282200L,0xC000020000000000L,0x000003FFFFFFFFFFL});
    public static final BitSet FOLLOW_expression_in_expression1451 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_131_in_expression1459 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1461 = new BitSet(new long[]{0x3FFF003000282200L,0xC000020000000000L,0x000003FFFFFFFFFFL});
    public static final BitSet FOLLOW_expression_in_expression1463 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_132_in_expression1471 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1473 = new BitSet(new long[]{0x3FFF003000282200L,0xC000020000000000L,0x000003FFFFFFFFFFL});
    public static final BitSet FOLLOW_expression_in_expression1475 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_133_in_expression1483 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1485 = new BitSet(new long[]{0x3FFF003000282200L,0xC000020000000000L,0x000003FFFFFFFFFFL});
    public static final BitSet FOLLOW_expression_in_expression1487 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_BIT_AND_in_expression1495 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1499 = new BitSet(new long[]{0x3FFF003000282200L,0xC000020000000000L,0x000003FFFFFFFFFFL});
    public static final BitSet FOLLOW_expression_in_expression1503 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_134_in_expression1515 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1517 = new BitSet(new long[]{0x3FFF003000282200L,0xC000020000000000L,0x000003FFFFFFFFFFL});
    public static final BitSet FOLLOW_expression_in_expression1519 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_135_in_expression1527 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1529 = new BitSet(new long[]{0x3FFF003000282200L,0xC000020000000000L,0x000003FFFFFFFFFFL});
    public static final BitSet FOLLOW_expression_in_expression1531 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_136_in_expression1539 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1541 = new BitSet(new long[]{0x3FFF003000282200L,0xC000020000000000L,0x000003FFFFFFFFFFL});
    public static final BitSet FOLLOW_expression_in_expression1543 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_137_in_expression1551 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1553 = new BitSet(new long[]{0x3FFF003000282200L,0xC000020000000000L,0x000003FFFFFFFFFFL});
    public static final BitSet FOLLOW_expression_in_expression1555 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_138_in_expression1563 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1565 = new BitSet(new long[]{0x3FFF003000282200L,0xC000020000000000L,0x000003FFFFFFFFFFL});
    public static final BitSet FOLLOW_expression_in_expression1567 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_139_in_expression1575 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1577 = new BitSet(new long[]{0x3FFF003000282200L,0xC000020000000000L,0x000003FFFFFFFFFFL});
    public static final BitSet FOLLOW_expression_in_expression1579 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_140_in_expression1587 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1589 = new BitSet(new long[]{0x3FFF003000282200L,0xC000020000000000L,0x000003FFFFFFFFFFL});
    public static final BitSet FOLLOW_expression_in_expression1591 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_141_in_expression1599 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1601 = new BitSet(new long[]{0x3FFF003000282200L,0xC000020000000000L,0x000003FFFFFFFFFFL});
    public static final BitSet FOLLOW_expression_in_expression1603 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_142_in_expression1611 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1613 = new BitSet(new long[]{0x3FFF003000282200L,0xC000020000000000L,0x000003FFFFFFFFFFL});
    public static final BitSet FOLLOW_expression_in_expression1615 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_143_in_expression1623 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1625 = new BitSet(new long[]{0x3FFF003000282200L,0xC000020000000000L,0x000003FFFFFFFFFFL});
    public static final BitSet FOLLOW_expression_in_expression1627 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_144_in_expression1635 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1637 = new BitSet(new long[]{0x3FFF003000282200L,0xC000020000000000L,0x000003FFFFFFFFFFL});
    public static final BitSet FOLLOW_expression_in_expression1639 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_145_in_expression1647 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1649 = new BitSet(new long[]{0x3FFF003000282200L,0xC000020000000000L,0x000003FFFFFFFFFFL});
    public static final BitSet FOLLOW_expression_in_expression1651 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_146_in_expression1659 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1661 = new BitSet(new long[]{0x3FFF003000282200L,0xC000020000000000L,0x000003FFFFFFFFFFL});
    public static final BitSet FOLLOW_expression_in_expression1663 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_147_in_expression1671 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1673 = new BitSet(new long[]{0x3FFF003000282200L,0xC000020000000000L,0x000003FFFFFFFFFFL});
    public static final BitSet FOLLOW_expression_in_expression1675 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_148_in_expression1683 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1685 = new BitSet(new long[]{0x3FFF003000282200L,0xC000020000000000L,0x000003FFFFFFFFFFL});
    public static final BitSet FOLLOW_expression_in_expression1687 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_149_in_expression1695 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1697 = new BitSet(new long[]{0x3FFF003000282200L,0xC000020000000000L,0x000003FFFFFFFFFFL});
    public static final BitSet FOLLOW_expression_in_expression1699 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_cast_option_in_expression1706 = new BitSet(new long[]{0x3FFF003000282200L,0xC000020000000000L,0x000003FFFFFFFFFFL});
    public static final BitSet FOLLOW_expression_in_expression1708 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_expression1715 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1723 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_set_in_expression1731 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1739 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_165_in_expression1747 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1749 = new BitSet(new long[]{0x0000100000082000L,0x0000020000000000L});
    public static final BitSet FOLLOW_class_name_reference_in_expression1751 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_166_in_expression1758 = new BitSet(new long[]{0x0000000000082000L,0x0000020000000000L});
    public static final BitSet FOLLOW_variable_in_expression1761 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_166_in_expression1771 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_scalar_in_expression1774 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_167_in_expression1785 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_assignment_list_in_expression1787 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_ARRAY_DECL_in_expression1796 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_array_pair_list_in_expression1798 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_168_in_expression1811 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_class_name_reference_in_expression1813 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_158_in_expression1821 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_variable_in_expression1823 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_169_in_expression1831 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1833 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_157_in_expression1842 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_variable_in_expression1844 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_lambda_function_declaration_in_expression1851 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_BACKTRICKLITERAL_in_expression1857 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_assignment_operator0 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_cast_option1955 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_METHOD_DECL_in_lambda_function_declaration2036 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_BIT_AND_in_lambda_function_declaration2038 = new BitSet(new long[]{0x0000000000001800L,0x0000010000000000L});
    public static final BitSet FOLLOW_parameter_list_in_lambda_function_declaration2041 = new BitSet(new long[]{0x0000000000001800L,0x0000010000000000L});
    public static final BitSet FOLLOW_104_in_lambda_function_declaration2046 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_list_in_lambda_function_declaration2048 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_block_in_lambda_function_declaration2058 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_variable_in_class_name_reference2078 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_fully_qualified_class_name_in_class_name_reference2084 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_assignment_element_in_assignment_list2101 = new BitSet(new long[]{0x0000000000082002L,0x0000020000000000L,0x0000008000000000L});
    public static final BitSet FOLLOW_variable_in_assignment_element2117 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_167_in_assignment_element2124 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_assignment_list_in_assignment_element2126 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_array_pair_element_in_array_pair_list2156 = new BitSet(new long[]{0x3FFF003000282202L,0xC000020000000000L,0x000003FFFFFFFFFFL});
    public static final BitSet FOLLOW_105_in_array_pair_element2177 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_array_pair_element2182 = new BitSet(new long[]{0x3FFF003000282200L,0xC000020000000000L,0x000003FFFFFFFFFFL});
    public static final BitSet FOLLOW_expression_in_array_pair_element2186 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_expression_in_array_pair_element2197 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_base_variable_with_function_calls_in_variable2228 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_CALL_in_variable2240 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_variable_in_variable2244 = new BitSet(new long[]{0x7FFF1030002A2200L,0xC000020000000000L,0x000003FFFFFFFFFFL});
    public static final BitSet FOLLOW_object_property_in_variable2246 = new BitSet(new long[]{0x0000000040000008L});
    public static final BitSet FOLLOW_ctor_arguments_in_variable2248 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_VAR_DECL_in_base_variable_with_function_calls2272 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_fully_qualified_class_name_in_base_variable_with_function_calls2274 = new BitSet(new long[]{0x7FFF1030002A2200L,0xC000020000000000L,0x000003FFFFFFFFFFL});
    public static final BitSet FOLLOW_object_property_in_base_variable_with_function_calls2277 = new BitSet(new long[]{0x0000000040000008L});
    public static final BitSet FOLLOW_ctor_arguments_in_base_variable_with_function_calls2286 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_CALL_in_base_variable_with_function_calls2298 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_fully_qualified_class_name_in_base_variable_with_function_calls2300 = new BitSet(new long[]{0x0000000040000000L});
    public static final BitSet FOLLOW_ctor_arguments_in_base_variable_with_function_calls2302 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_DOLLAR_T_in_object_property2330 = new BitSet(new long[]{0x4000100000000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_object_property2333 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_DOLLAR_T_in_object_property2345 = new BitSet(new long[]{0x7FFF003000282200L,0xC000020000000000L,0x000003FFFFFFFFFFL});
    public static final BitSet FOLLOW_expression_in_object_property2348 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_INDEX_in_object_property2355 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_object_property_in_object_property2357 = new BitSet(new long[]{0x3FFF003000282200L,0xC000020000000000L,0x000003FFFFFFFFFFL});
    public static final BitSet FOLLOW_expression_in_object_property2359 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_ARGU_in_ctor_arguments2383 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_list_in_ctor_arguments2385 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_VAR_DECL_in_pure_variable2407 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_BIT_AND_in_pure_variable2412 = new BitSet(new long[]{0x4000000000000000L});
    public static final BitSet FOLLOW_DOLLAR_T_in_pure_variable2415 = new BitSet(new long[]{0x4000100000000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_pure_variable2418 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_SCALAR_in_scalar2439 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_constant_in_scalar2441 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_INTLITERAL_in_constant2467 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_FLOATLITERAL_in_constant2479 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_STRINGLITERAL_in_constant2487 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_DOUBLELITERRAL_in_constant2499 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_common_scalar_in_constant2507 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_fully_qualified_class_name_in_constant2515 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_common_scalar0 = new BitSet(new long[]{0x0000000000000002L});

}