<?php

// Start of PDO_OCI v.1.0.1
// End of PDO_OCI v.1.0.1
?>
