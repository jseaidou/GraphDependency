<?php

// Start of Zend Page Cache v.

function page_cache_disable_caching () {}

function page_cache_disable_compression () {}

function page_cache_remove_cached_contents () {}

function page_cache_remove_all_cached_contents () {}

// End of Zend Page Cache v.
?>
