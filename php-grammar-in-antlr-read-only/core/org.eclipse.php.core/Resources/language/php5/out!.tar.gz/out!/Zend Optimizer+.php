<?php

// Start of Zend Optimizer+ v.4.0

function accelerator_reset () {}

function accelerator_get_configuration () {}

function accelerator_get_status () {}

function accelerator_get_server_start_time () {}

// End of Zend Optimizer+ v.4.0
?>
