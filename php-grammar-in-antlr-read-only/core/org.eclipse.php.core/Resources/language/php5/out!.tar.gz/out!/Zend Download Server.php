<?php

// Start of Zend Download Server v.0.1

function zend_send_file () {}

function zend_send_buffer () {}

function zds_get_pid () {}

define ('ZDS_VERSION', 1.5);

// End of Zend Download Server v.0.1
?>
