// $ANTLR 3.1.3 Mar 17, 2009 19:23:44 /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g 2009-08-01 22:43:26

  package org.eclipse.php.internal.core.compiler.ast.parser.php5;
  
  import org.antlr.runtime.*;
  import org.antlr.runtime.tree.*;
  import org.antlr.runtime.BitSet;
  
  import java.util.*;
	import org.eclipse.dltk.ast.*;
	import org.eclipse.dltk.ast.declarations.*;
	import org.eclipse.dltk.ast.expressions.*;
	import org.eclipse.dltk.ast.references.*;
	import org.eclipse.dltk.ast.statements.*;
	import org.eclipse.php.internal.core.compiler.ast.nodes.*;
	import org.eclipse.php.internal.core.compiler.ast.parser.*;
	import org.eclipse.php.internal.core.ast.scanner.php5.*;


import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;

import org.antlr.runtime.tree.*;

public class CompilerAstParser extends AbstractASTParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "ModuleDeclaration", "ClassDeclaration", "PROG", "CLASS_BODY", "FIELD_DECL", "METHOD_DECL", "TYPE", "PARAMETER", "BLOCK", "VAR_DECL", "STATEMENT", "CONDITION", "LIST", "INDEX", "MEMBERACCESS", "CALL", "ELIST", "EXPR", "ASSIGN", "LIST_DECL", "SCALAR_ELEMENT", "SCALAR_VAR", "CAST", "LABEL", "ITERATE", "USE_DECL", "ARGU", "CALLED_OBJ", "PREFIX", "POSTFIX", "NAMESPACE", "EMPTYSTATEMENT", "SCALAR", "ARRAY_DECL", "SOC_T", "SOC_PHP_T", "EOC_T", "LEFT_PARETHESIS", "RIGHT_PARETHESIS", "CLASS_T", "IDENTIFIER", "LEFT_BRACKET", "RIGHT_BRACKET", "STRINGLITERAL", "EQ", "PLUS_EQ", "MINUS_EQ", "MUL_EQ", "DIV_EQ", "DOT_EQ", "PERCENT_EQ", "BIT_AND_EQ", "BIT_OR_EQ", "POWER_EQ", "LMOVE_EQ", "RMOVE_EQ", "BIT_AND", "PLUS_T", "MINUS_T", "MUL_T", "DIV_T", "TILDA_T", "BACKTRICKLITERAL", "LEFT_OPEN_RECT", "RIGHT_OPEN_RECT", "DOLLAR_T", "INTLITERAL", "FLOATLITERAL", "DOUBLELITERRAL", "IntegerNumber", "LongSuffix", "HexPrefix", "HexDigit", "STATIC", "NonIntegerNumber", "FloatSuffix", "DoubleSuffix", "Exponent", "EscapeSequence", "IdentifierStart", "IdentifierPart", "WS", "COMMENT", "LINE_COMMENT", "'__halt_compiler'", "';'", "'extends'", "'implements'", "'interface'", "'abstract'", "'final'", "'function'", "'while'", "'do'", "'for'", "'switch'", "'break'", "'continue'", "'return'", "'global'", "'static'", "'echo'", "'foreach'", "'as'", "'declare'", "'try'", "'throw'", "'use'", "'=>'", "'const'", "','", "'::'", "'if'", "'elseif'", "'else'", "':'", "'endif'", "'endswitch'", "'case'", "'default'", "'catch'", "'endfor'", "'endwhile'", "'endforeach'", "'enddeclare'", "'var'", "'public'", "'protected'", "'private'", "'OR'", "'XOR'", "'AND'", "'?'", "'||'", "'&&'", "'|'", "'^'", "'.'", "'=='", "'!='", "'==='", "'!=='", "'<'", "'>'", "'<='", "'>='", "'<<'", "'>>'", "'%'", "'bool'", "'boolean'", "'int'", "'float'", "'double'", "'real'", "'string'", "'unset'", "'clone'", "'object'", "'array'", "'!'", "'++'", "'--'", "'instanceof'", "'@'", "'list'", "'new'", "'exit'", "'->'", "'__CLASS__'", "'__DIR__'", "'__FILE__'", "'__FUNCTION__'", "'__METHOD__'", "'__NAMESPACE__'"
    };
    public static final int CAST=26;
    public static final int PREFIX=32;
    public static final int RIGHT_OPEN_RECT=68;
    public static final int POSTFIX=33;
    public static final int T__159=159;
    public static final int T__158=158;
    public static final int PERCENT_EQ=54;
    public static final int T__160=160;
    public static final int VAR_DECL=13;
    public static final int CONDITION=15;
    public static final int DIV_T=64;
    public static final int T__167=167;
    public static final int EOF=-1;
    public static final int T__168=168;
    public static final int T__165=165;
    public static final int T__166=166;
    public static final int STATEMENT=14;
    public static final int T__163=163;
    public static final int T__164=164;
    public static final int TYPE=10;
    public static final int T__161=161;
    public static final int T__162=162;
    public static final int T__93=93;
    public static final int T__94=94;
    public static final int CALLED_OBJ=31;
    public static final int T__91=91;
    public static final int EOC_T=40;
    public static final int T__92=92;
    public static final int T__148=148;
    public static final int T__90=90;
    public static final int T__147=147;
    public static final int DIV_EQ=52;
    public static final int T__149=149;
    public static final int ELIST=20;
    public static final int FloatSuffix=79;
    public static final int NonIntegerNumber=78;
    public static final int PARAMETER=11;
    public static final int RIGHT_BRACKET=46;
    public static final int SCALAR=36;
    public static final int ARGU=30;
    public static final int EQ=48;
    public static final int COMMENT=86;
    public static final int T__154=154;
    public static final int T__155=155;
    public static final int T__156=156;
    public static final int T__99=99;
    public static final int T__157=157;
    public static final int T__98=98;
    public static final int T__150=150;
    public static final int T__97=97;
    public static final int T__151=151;
    public static final int T__96=96;
    public static final int T__152=152;
    public static final int HexPrefix=75;
    public static final int T__95=95;
    public static final int T__153=153;
    public static final int T__139=139;
    public static final int T__138=138;
    public static final int T__137=137;
    public static final int T__136=136;
    public static final int RMOVE_EQ=59;
    public static final int LINE_COMMENT=87;
    public static final int STATIC=77;
    public static final int ARRAY_DECL=37;
    public static final int MUL_EQ=51;
    public static final int IdentifierStart=83;
    public static final int INTLITERAL=70;
    public static final int T__141=141;
    public static final int PLUS_EQ=49;
    public static final int LIST=16;
    public static final int T__142=142;
    public static final int T__140=140;
    public static final int PLUS_T=61;
    public static final int T__89=89;
    public static final int T__145=145;
    public static final int NAMESPACE=34;
    public static final int T__88=88;
    public static final int T__146=146;
    public static final int MINUS_EQ=50;
    public static final int T__143=143;
    public static final int LongSuffix=74;
    public static final int T__144=144;
    public static final int T__126=126;
    public static final int T__125=125;
    public static final int T__128=128;
    public static final int EMPTYSTATEMENT=35;
    public static final int T__127=127;
    public static final int WS=85;
    public static final int T__129=129;
    public static final int SOC_PHP_T=39;
    public static final int MINUS_T=62;
    public static final int MEMBERACCESS=18;
    public static final int CALL=19;
    public static final int SCALAR_ELEMENT=24;
    public static final int POWER_EQ=57;
    public static final int T__130=130;
    public static final int EscapeSequence=82;
    public static final int BIT_AND_EQ=55;
    public static final int T__131=131;
    public static final int T__132=132;
    public static final int T__133=133;
    public static final int T__134=134;
    public static final int T__135=135;
    public static final int BIT_AND=60;
    public static final int IntegerNumber=73;
    public static final int CLASS_T=43;
    public static final int T__118=118;
    public static final int T__119=119;
    public static final int T__116=116;
    public static final int DOLLAR_T=69;
    public static final int LEFT_BRACKET=45;
    public static final int T__117=117;
    public static final int T__114=114;
    public static final int DOUBLELITERRAL=72;
    public static final int T__115=115;
    public static final int T__124=124;
    public static final int T__123=123;
    public static final int Exponent=81;
    public static final int SOC_T=38;
    public static final int METHOD_DECL=9;
    public static final int T__122=122;
    public static final int T__121=121;
    public static final int T__120=120;
    public static final int HexDigit=76;
    public static final int INDEX=17;
    public static final int PROG=6;
    public static final int EXPR=21;
    public static final int USE_DECL=29;
    public static final int T__107=107;
    public static final int T__108=108;
    public static final int T__109=109;
    public static final int IDENTIFIER=44;
    public static final int T__103=103;
    public static final int T__104=104;
    public static final int LEFT_OPEN_RECT=67;
    public static final int T__105=105;
    public static final int T__106=106;
    public static final int T__111=111;
    public static final int T__110=110;
    public static final int T__113=113;
    public static final int T__112=112;
    public static final int LMOVE_EQ=58;
    public static final int SCALAR_VAR=25;
    public static final int IdentifierPart=84;
    public static final int TILDA_T=65;
    public static final int MUL_T=63;
    public static final int BIT_OR_EQ=56;
    public static final int FIELD_DECL=8;
    public static final int T__102=102;
    public static final int T__101=101;
    public static final int T__100=100;
    public static final int CLASS_BODY=7;
    public static final int LIST_DECL=23;
    public static final int ModuleDeclaration=4;
    public static final int BACKTRICKLITERAL=66;
    public static final int T__175=175;
    public static final int T__174=174;
    public static final int ITERATE=28;
    public static final int T__173=173;
    public static final int T__172=172;
    public static final int LEFT_PARETHESIS=41;
    public static final int T__178=178;
    public static final int T__177=177;
    public static final int DoubleSuffix=80;
    public static final int T__176=176;
    public static final int LABEL=27;
    public static final int STRINGLITERAL=47;
    public static final int T__171=171;
    public static final int BLOCK=12;
    public static final int T__170=170;
    public static final int RIGHT_PARETHESIS=42;
    public static final int ASSIGN=22;
    public static final int DOT_EQ=53;
    public static final int FLOATLITERAL=71;
    public static final int ClassDeclaration=5;
    public static final int T__169=169;

    // delegates
    // delegators


        public CompilerAstParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public CompilerAstParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        
    protected TreeAdaptor adaptor = new CommonTreeAdaptor();

    public void setTreeAdaptor(TreeAdaptor adaptor) {
        this.adaptor = adaptor;
    }
    public TreeAdaptor getTreeAdaptor() {
        return adaptor;
    }

    public String[] getTokenNames() { return CompilerAstParser.tokenNames; }
    public String getGrammarFileName() { return "/home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g"; }


    public static class php_source_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "php_source"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:86:1: php_source : ( SOC_T | SOC_PHP_T ) ( top_statement_list )? EOC_T -> ^( ModuleDeclaration ( top_statement_list )? ) ;
    public final CompilerAstParser.php_source_return php_source() throws RecognitionException {
        CompilerAstParser.php_source_return retval = new CompilerAstParser.php_source_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token SOC_T1=null;
        Token SOC_PHP_T2=null;
        Token EOC_T4=null;
        CompilerAstParser.top_statement_list_return top_statement_list3 = null;


        SLAST SOC_T1_tree=null;
        SLAST SOC_PHP_T2_tree=null;
        SLAST EOC_T4_tree=null;
        RewriteRuleTokenStream stream_SOC_T=new RewriteRuleTokenStream(adaptor,"token SOC_T");
        RewriteRuleTokenStream stream_EOC_T=new RewriteRuleTokenStream(adaptor,"token EOC_T");
        RewriteRuleTokenStream stream_SOC_PHP_T=new RewriteRuleTokenStream(adaptor,"token SOC_PHP_T");
        RewriteRuleSubtreeStream stream_top_statement_list=new RewriteRuleSubtreeStream(adaptor,"rule top_statement_list");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:96:3: ( ( SOC_T | SOC_PHP_T ) ( top_statement_list )? EOC_T -> ^( ModuleDeclaration ( top_statement_list )? ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:96:5: ( SOC_T | SOC_PHP_T ) ( top_statement_list )? EOC_T
            {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:96:5: ( SOC_T | SOC_PHP_T )
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0==SOC_T) ) {
                alt1=1;
            }
            else if ( (LA1_0==SOC_PHP_T) ) {
                alt1=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 1, 0, input);

                throw nvae;
            }
            switch (alt1) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:96:6: SOC_T
                    {
                    SOC_T1=(Token)match(input,SOC_T,FOLLOW_SOC_T_in_php_source241); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SOC_T.add(SOC_T1);

                    if ( state.backtracking==0 ) {

                          token = (CommonToken)SOC_T1;
                          startIndex = token.getStartIndex();
                        
                    }

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:101:5: SOC_PHP_T
                    {
                    SOC_PHP_T2=(Token)match(input,SOC_PHP_T,FOLLOW_SOC_PHP_T_in_php_source253); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SOC_PHP_T.add(SOC_PHP_T2);

                    if ( state.backtracking==0 ) {

                          token = (CommonToken)SOC_PHP_T2;
                          startIndex = token.getStartIndex();
                        
                    }

                    }
                    break;

            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:106:9: ( top_statement_list )?
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==LEFT_PARETHESIS||(LA2_0>=CLASS_T && LA2_0<=LEFT_BRACKET)||LA2_0==STRINGLITERAL||(LA2_0>=BIT_AND && LA2_0<=MINUS_T)||(LA2_0>=TILDA_T && LA2_0<=BACKTRICKLITERAL)||(LA2_0>=DOLLAR_T && LA2_0<=DOUBLELITERRAL)||(LA2_0>=88 && LA2_0<=89)||(LA2_0>=92 && LA2_0<=106)||(LA2_0>=108 && LA2_0<=111)||LA2_0==116||(LA2_0>=160 && LA2_0<=161)||(LA2_0>=163 && LA2_0<=166)||(LA2_0>=168 && LA2_0<=171)||(LA2_0>=173 && LA2_0<=178)) ) {
                alt2=1;
            }
            switch (alt2) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:106:9: top_statement_list
                    {
                    pushFollow(FOLLOW_top_statement_list_in_php_source268);
                    top_statement_list3=top_statement_list();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_top_statement_list.add(top_statement_list3.getTree());

                    }
                    break;

            }

            EOC_T4=(Token)match(input,EOC_T,FOLLOW_EOC_T_in_php_source277); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_EOC_T.add(EOC_T4);

            if ( state.backtracking==0 ) {

                  token = (CommonToken)EOC_T4;
                  endIndex = token.getStopIndex();
                
            }


            // AST REWRITE
            // elements: top_statement_list
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 113:5: -> ^( ModuleDeclaration ( top_statement_list )? )
            {
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:113:9: ^( ModuleDeclaration ( top_statement_list )? )
                {
                SLAST root_1 = (SLAST)adaptor.nil();
                root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(ModuleDeclaration, "ModuleDeclaration"), root_1);

                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:113:29: ( top_statement_list )?
                if ( stream_top_statement_list.hasNext() ) {
                    adaptor.addChild(root_1, stream_top_statement_list.nextTree());

                }
                stream_top_statement_list.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST phpSourceToken = retval.tree;
                phpSourceToken.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "php_source"

    public static class top_statement_list_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "top_statement_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:116:1: top_statement_list : ( top_statement )+ ;
    public final CompilerAstParser.top_statement_list_return top_statement_list() throws RecognitionException {
        CompilerAstParser.top_statement_list_return retval = new CompilerAstParser.top_statement_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        CompilerAstParser.top_statement_return top_statement5 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:117:3: ( ( top_statement )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:117:5: ( top_statement )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:117:5: ( top_statement )+
            int cnt3=0;
            loop3:
            do {
                int alt3=2;
                int LA3_0 = input.LA(1);

                if ( (LA3_0==LEFT_PARETHESIS||(LA3_0>=CLASS_T && LA3_0<=LEFT_BRACKET)||LA3_0==STRINGLITERAL||(LA3_0>=BIT_AND && LA3_0<=MINUS_T)||(LA3_0>=TILDA_T && LA3_0<=BACKTRICKLITERAL)||(LA3_0>=DOLLAR_T && LA3_0<=DOUBLELITERRAL)||(LA3_0>=88 && LA3_0<=89)||(LA3_0>=92 && LA3_0<=106)||(LA3_0>=108 && LA3_0<=111)||LA3_0==116||(LA3_0>=160 && LA3_0<=161)||(LA3_0>=163 && LA3_0<=166)||(LA3_0>=168 && LA3_0<=171)||(LA3_0>=173 && LA3_0<=178)) ) {
                    alt3=1;
                }


                switch (alt3) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:117:5: top_statement
            	    {
            	    pushFollow(FOLLOW_top_statement_in_top_statement_list315);
            	    top_statement5=top_statement();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, top_statement5.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt3 >= 1 ) break loop3;
            	    if (state.backtracking>0) {state.failed=true; return retval;}
                        EarlyExitException eee =
                            new EarlyExitException(3, input);
                        throw eee;
                }
                cnt3++;
            } while (true);


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "top_statement_list"

    public static class top_statement_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "top_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:120:1: top_statement : ( statement | function_declaration_statement | class_declaration_statement | halt_compiler_statement );
    public final CompilerAstParser.top_statement_return top_statement() throws RecognitionException {
        CompilerAstParser.top_statement_return retval = new CompilerAstParser.top_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        CompilerAstParser.statement_return statement6 = null;

        CompilerAstParser.function_declaration_statement_return function_declaration_statement7 = null;

        CompilerAstParser.class_declaration_statement_return class_declaration_statement8 = null;

        CompilerAstParser.halt_compiler_statement_return halt_compiler_statement9 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:121:3: ( statement | function_declaration_statement | class_declaration_statement | halt_compiler_statement )
            int alt4=4;
            switch ( input.LA(1) ) {
            case LEFT_PARETHESIS:
            case IDENTIFIER:
            case LEFT_BRACKET:
            case STRINGLITERAL:
            case BIT_AND:
            case PLUS_T:
            case MINUS_T:
            case TILDA_T:
            case BACKTRICKLITERAL:
            case DOLLAR_T:
            case INTLITERAL:
            case FLOATLITERAL:
            case DOUBLELITERRAL:
            case 89:
            case 96:
            case 97:
            case 98:
            case 99:
            case 100:
            case 101:
            case 102:
            case 103:
            case 104:
            case 105:
            case 106:
            case 108:
            case 109:
            case 110:
            case 111:
            case 116:
            case 160:
            case 161:
            case 163:
            case 164:
            case 165:
            case 166:
            case 168:
            case 169:
            case 170:
            case 171:
            case 173:
            case 174:
            case 175:
            case 176:
            case 177:
            case 178:
                {
                alt4=1;
                }
                break;
            case 95:
                {
                switch ( input.LA(2) ) {
                case BIT_AND:
                    {
                    int LA4_5 = input.LA(3);

                    if ( (LA4_5==LEFT_PARETHESIS) ) {
                        alt4=1;
                    }
                    else if ( (LA4_5==IDENTIFIER) ) {
                        alt4=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return retval;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 4, 5, input);

                        throw nvae;
                    }
                    }
                    break;
                case LEFT_PARETHESIS:
                    {
                    alt4=1;
                    }
                    break;
                case IDENTIFIER:
                    {
                    alt4=2;
                    }
                    break;
                default:
                    if (state.backtracking>0) {state.failed=true; return retval;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 4, 2, input);

                    throw nvae;
                }

                }
                break;
            case CLASS_T:
            case 92:
            case 93:
            case 94:
                {
                alt4=3;
                }
                break;
            case 88:
                {
                alt4=4;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 4, 0, input);

                throw nvae;
            }

            switch (alt4) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:121:5: statement
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_statement_in_top_statement329);
                    statement6=statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, statement6.getTree());

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:122:5: function_declaration_statement
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_function_declaration_statement_in_top_statement335);
                    function_declaration_statement7=function_declaration_statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, function_declaration_statement7.getTree());

                    }
                    break;
                case 3 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:123:5: class_declaration_statement
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_class_declaration_statement_in_top_statement341);
                    class_declaration_statement8=class_declaration_statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, class_declaration_statement8.getTree());

                    }
                    break;
                case 4 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:124:5: halt_compiler_statement
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_halt_compiler_statement_in_top_statement347);
                    halt_compiler_statement9=halt_compiler_statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, halt_compiler_statement9.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "top_statement"

    public static class inner_statement_list_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "inner_statement_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:127:1: inner_statement_list : ( inner_statement )+ ;
    public final CompilerAstParser.inner_statement_list_return inner_statement_list() throws RecognitionException {
        CompilerAstParser.inner_statement_list_return retval = new CompilerAstParser.inner_statement_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        CompilerAstParser.inner_statement_return inner_statement10 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:128:3: ( ( inner_statement )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:128:5: ( inner_statement )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:128:5: ( inner_statement )+
            int cnt5=0;
            loop5:
            do {
                int alt5=2;
                int LA5_0 = input.LA(1);

                if ( (LA5_0==LEFT_PARETHESIS||(LA5_0>=CLASS_T && LA5_0<=LEFT_BRACKET)||LA5_0==STRINGLITERAL||(LA5_0>=BIT_AND && LA5_0<=MINUS_T)||(LA5_0>=TILDA_T && LA5_0<=BACKTRICKLITERAL)||(LA5_0>=DOLLAR_T && LA5_0<=DOUBLELITERRAL)||(LA5_0>=88 && LA5_0<=89)||(LA5_0>=92 && LA5_0<=106)||(LA5_0>=108 && LA5_0<=111)||LA5_0==116||(LA5_0>=160 && LA5_0<=161)||(LA5_0>=163 && LA5_0<=166)||(LA5_0>=168 && LA5_0<=171)||(LA5_0>=173 && LA5_0<=178)) ) {
                    alt5=1;
                }


                switch (alt5) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:128:6: inner_statement
            	    {
            	    pushFollow(FOLLOW_inner_statement_in_inner_statement_list363);
            	    inner_statement10=inner_statement();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, inner_statement10.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt5 >= 1 ) break loop5;
            	    if (state.backtracking>0) {state.failed=true; return retval;}
                        EarlyExitException eee =
                            new EarlyExitException(5, input);
                        throw eee;
                }
                cnt5++;
            } while (true);


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "inner_statement_list"

    public static class inner_statement_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "inner_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:131:1: inner_statement : ( statement | function_declaration_statement | class_declaration_statement | halt_compiler_statement );
    public final CompilerAstParser.inner_statement_return inner_statement() throws RecognitionException {
        CompilerAstParser.inner_statement_return retval = new CompilerAstParser.inner_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        CompilerAstParser.statement_return statement11 = null;

        CompilerAstParser.function_declaration_statement_return function_declaration_statement12 = null;

        CompilerAstParser.class_declaration_statement_return class_declaration_statement13 = null;

        CompilerAstParser.halt_compiler_statement_return halt_compiler_statement14 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:132:3: ( statement | function_declaration_statement | class_declaration_statement | halt_compiler_statement )
            int alt6=4;
            switch ( input.LA(1) ) {
            case LEFT_PARETHESIS:
            case IDENTIFIER:
            case LEFT_BRACKET:
            case STRINGLITERAL:
            case BIT_AND:
            case PLUS_T:
            case MINUS_T:
            case TILDA_T:
            case BACKTRICKLITERAL:
            case DOLLAR_T:
            case INTLITERAL:
            case FLOATLITERAL:
            case DOUBLELITERRAL:
            case 89:
            case 96:
            case 97:
            case 98:
            case 99:
            case 100:
            case 101:
            case 102:
            case 103:
            case 104:
            case 105:
            case 106:
            case 108:
            case 109:
            case 110:
            case 111:
            case 116:
            case 160:
            case 161:
            case 163:
            case 164:
            case 165:
            case 166:
            case 168:
            case 169:
            case 170:
            case 171:
            case 173:
            case 174:
            case 175:
            case 176:
            case 177:
            case 178:
                {
                alt6=1;
                }
                break;
            case 95:
                {
                switch ( input.LA(2) ) {
                case BIT_AND:
                    {
                    int LA6_5 = input.LA(3);

                    if ( (LA6_5==IDENTIFIER) ) {
                        alt6=2;
                    }
                    else if ( (LA6_5==LEFT_PARETHESIS) ) {
                        alt6=1;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return retval;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 6, 5, input);

                        throw nvae;
                    }
                    }
                    break;
                case LEFT_PARETHESIS:
                    {
                    alt6=1;
                    }
                    break;
                case IDENTIFIER:
                    {
                    alt6=2;
                    }
                    break;
                default:
                    if (state.backtracking>0) {state.failed=true; return retval;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 6, 2, input);

                    throw nvae;
                }

                }
                break;
            case CLASS_T:
            case 92:
            case 93:
            case 94:
                {
                alt6=3;
                }
                break;
            case 88:
                {
                alt6=4;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 6, 0, input);

                throw nvae;
            }

            switch (alt6) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:132:5: statement
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_statement_in_inner_statement380);
                    statement11=statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, statement11.getTree());

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:133:5: function_declaration_statement
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_function_declaration_statement_in_inner_statement386);
                    function_declaration_statement12=function_declaration_statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, function_declaration_statement12.getTree());

                    }
                    break;
                case 3 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:134:5: class_declaration_statement
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_class_declaration_statement_in_inner_statement392);
                    class_declaration_statement13=class_declaration_statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, class_declaration_statement13.getTree());

                    }
                    break;
                case 4 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:135:5: halt_compiler_statement
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_halt_compiler_statement_in_inner_statement398);
                    halt_compiler_statement14=halt_compiler_statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, halt_compiler_statement14.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "inner_statement"

    public static class halt_compiler_statement_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "halt_compiler_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:138:1: halt_compiler_statement : '__halt_compiler' LEFT_PARETHESIS RIGHT_PARETHESIS ';' -> '__halt_compiler' ;
    public final CompilerAstParser.halt_compiler_statement_return halt_compiler_statement() throws RecognitionException {
        CompilerAstParser.halt_compiler_statement_return retval = new CompilerAstParser.halt_compiler_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token string_literal15=null;
        Token LEFT_PARETHESIS16=null;
        Token RIGHT_PARETHESIS17=null;
        Token char_literal18=null;

        SLAST string_literal15_tree=null;
        SLAST LEFT_PARETHESIS16_tree=null;
        SLAST RIGHT_PARETHESIS17_tree=null;
        SLAST char_literal18_tree=null;
        RewriteRuleTokenStream stream_LEFT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token LEFT_PARETHESIS");
        RewriteRuleTokenStream stream_88=new RewriteRuleTokenStream(adaptor,"token 88");
        RewriteRuleTokenStream stream_RIGHT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token RIGHT_PARETHESIS");
        RewriteRuleTokenStream stream_89=new RewriteRuleTokenStream(adaptor,"token 89");

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:139:3: ( '__halt_compiler' LEFT_PARETHESIS RIGHT_PARETHESIS ';' -> '__halt_compiler' )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:139:5: '__halt_compiler' LEFT_PARETHESIS RIGHT_PARETHESIS ';'
            {
            string_literal15=(Token)match(input,88,FOLLOW_88_in_halt_compiler_statement413); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_88.add(string_literal15);

            LEFT_PARETHESIS16=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_halt_compiler_statement415); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS16);

            RIGHT_PARETHESIS17=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_halt_compiler_statement417); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS17);

            char_literal18=(Token)match(input,89,FOLLOW_89_in_halt_compiler_statement419); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_89.add(char_literal18);



            // AST REWRITE
            // elements: 88
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 139:62: -> '__halt_compiler'
            {
                adaptor.addChild(root_0, stream_88.nextNode());

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "halt_compiler_statement"

    public static class class_declaration_statement_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "class_declaration_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:142:1: class_declaration_statement : ( ( ( class_entr_type )? CLASS_T IDENTIFIER ( 'extends' fully_qualified_class_name )? ( 'implements' fully_qualified_class_name_list )? LEFT_BRACKET ( class_statement_list )? RIGHT_BRACKET -> ^( CLASS_T ( class_entr_type )? IDENTIFIER ( ^( 'extends' fully_qualified_class_name ) )? ( ^( 'implements' fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? ) ) | ( 'interface' IDENTIFIER ( 'extends' fully_qualified_class_name_list )? ( 'implements' fully_qualified_class_name_list )? LEFT_BRACKET ( class_statement_list )? RIGHT_BRACKET -> ^( 'interface' IDENTIFIER ( ^( 'extends' fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? ) ) );
    public final CompilerAstParser.class_declaration_statement_return class_declaration_statement() throws RecognitionException {
        CompilerAstParser.class_declaration_statement_return retval = new CompilerAstParser.class_declaration_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token CLASS_T20=null;
        Token IDENTIFIER21=null;
        Token string_literal22=null;
        Token string_literal24=null;
        Token LEFT_BRACKET26=null;
        Token RIGHT_BRACKET28=null;
        Token string_literal29=null;
        Token IDENTIFIER30=null;
        Token string_literal31=null;
        Token string_literal33=null;
        Token LEFT_BRACKET35=null;
        Token RIGHT_BRACKET37=null;
        CompilerAstParser.class_entr_type_return class_entr_type19 = null;

        CompilerAstParser.fully_qualified_class_name_return fully_qualified_class_name23 = null;

        CompilerAstParser.fully_qualified_class_name_list_return fully_qualified_class_name_list25 = null;

        CompilerAstParser.class_statement_list_return class_statement_list27 = null;

        CompilerAstParser.fully_qualified_class_name_list_return fully_qualified_class_name_list32 = null;

        CompilerAstParser.fully_qualified_class_name_list_return fully_qualified_class_name_list34 = null;

        CompilerAstParser.class_statement_list_return class_statement_list36 = null;


        SLAST CLASS_T20_tree=null;
        SLAST IDENTIFIER21_tree=null;
        SLAST string_literal22_tree=null;
        SLAST string_literal24_tree=null;
        SLAST LEFT_BRACKET26_tree=null;
        SLAST RIGHT_BRACKET28_tree=null;
        SLAST string_literal29_tree=null;
        SLAST IDENTIFIER30_tree=null;
        SLAST string_literal31_tree=null;
        SLAST string_literal33_tree=null;
        SLAST LEFT_BRACKET35_tree=null;
        SLAST RIGHT_BRACKET37_tree=null;
        RewriteRuleTokenStream stream_92=new RewriteRuleTokenStream(adaptor,"token 92");
        RewriteRuleTokenStream stream_91=new RewriteRuleTokenStream(adaptor,"token 91");
        RewriteRuleTokenStream stream_CLASS_T=new RewriteRuleTokenStream(adaptor,"token CLASS_T");
        RewriteRuleTokenStream stream_90=new RewriteRuleTokenStream(adaptor,"token 90");
        RewriteRuleTokenStream stream_IDENTIFIER=new RewriteRuleTokenStream(adaptor,"token IDENTIFIER");
        RewriteRuleTokenStream stream_LEFT_BRACKET=new RewriteRuleTokenStream(adaptor,"token LEFT_BRACKET");
        RewriteRuleTokenStream stream_RIGHT_BRACKET=new RewriteRuleTokenStream(adaptor,"token RIGHT_BRACKET");
        RewriteRuleSubtreeStream stream_fully_qualified_class_name=new RewriteRuleSubtreeStream(adaptor,"rule fully_qualified_class_name");
        RewriteRuleSubtreeStream stream_fully_qualified_class_name_list=new RewriteRuleSubtreeStream(adaptor,"rule fully_qualified_class_name_list");
        RewriteRuleSubtreeStream stream_class_entr_type=new RewriteRuleSubtreeStream(adaptor,"rule class_entr_type");
        RewriteRuleSubtreeStream stream_class_statement_list=new RewriteRuleSubtreeStream(adaptor,"rule class_statement_list");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:152:3: ( ( ( class_entr_type )? CLASS_T IDENTIFIER ( 'extends' fully_qualified_class_name )? ( 'implements' fully_qualified_class_name_list )? LEFT_BRACKET ( class_statement_list )? RIGHT_BRACKET -> ^( CLASS_T ( class_entr_type )? IDENTIFIER ( ^( 'extends' fully_qualified_class_name ) )? ( ^( 'implements' fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? ) ) | ( 'interface' IDENTIFIER ( 'extends' fully_qualified_class_name_list )? ( 'implements' fully_qualified_class_name_list )? LEFT_BRACKET ( class_statement_list )? RIGHT_BRACKET -> ^( 'interface' IDENTIFIER ( ^( 'extends' fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? ) ) )
            int alt14=2;
            int LA14_0 = input.LA(1);

            if ( (LA14_0==CLASS_T||(LA14_0>=93 && LA14_0<=94)) ) {
                alt14=1;
            }
            else if ( (LA14_0==92) ) {
                alt14=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 14, 0, input);

                throw nvae;
            }
            switch (alt14) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:152:5: ( ( class_entr_type )? CLASS_T IDENTIFIER ( 'extends' fully_qualified_class_name )? ( 'implements' fully_qualified_class_name_list )? LEFT_BRACKET ( class_statement_list )? RIGHT_BRACKET -> ^( CLASS_T ( class_entr_type )? IDENTIFIER ( ^( 'extends' fully_qualified_class_name ) )? ( ^( 'implements' fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? ) )
                    {
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:152:5: ( ( class_entr_type )? CLASS_T IDENTIFIER ( 'extends' fully_qualified_class_name )? ( 'implements' fully_qualified_class_name_list )? LEFT_BRACKET ( class_statement_list )? RIGHT_BRACKET -> ^( CLASS_T ( class_entr_type )? IDENTIFIER ( ^( 'extends' fully_qualified_class_name ) )? ( ^( 'implements' fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? ) )
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:152:7: ( class_entr_type )? CLASS_T IDENTIFIER ( 'extends' fully_qualified_class_name )? ( 'implements' fully_qualified_class_name_list )? LEFT_BRACKET ( class_statement_list )? RIGHT_BRACKET
                    {
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:152:7: ( class_entr_type )?
                    int alt7=2;
                    int LA7_0 = input.LA(1);

                    if ( ((LA7_0>=93 && LA7_0<=94)) ) {
                        alt7=1;
                    }
                    switch (alt7) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:152:7: class_entr_type
                            {
                            pushFollow(FOLLOW_class_entr_type_in_class_declaration_statement454);
                            class_entr_type19=class_entr_type();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_class_entr_type.add(class_entr_type19.getTree());

                            }
                            break;

                    }

                    CLASS_T20=(Token)match(input,CLASS_T,FOLLOW_CLASS_T_in_class_declaration_statement457); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_CLASS_T.add(CLASS_T20);

                    IDENTIFIER21=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_class_declaration_statement459); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER21);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:152:43: ( 'extends' fully_qualified_class_name )?
                    int alt8=2;
                    int LA8_0 = input.LA(1);

                    if ( (LA8_0==90) ) {
                        alt8=1;
                    }
                    switch (alt8) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:152:44: 'extends' fully_qualified_class_name
                            {
                            string_literal22=(Token)match(input,90,FOLLOW_90_in_class_declaration_statement462); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_90.add(string_literal22);

                            pushFollow(FOLLOW_fully_qualified_class_name_in_class_declaration_statement464);
                            fully_qualified_class_name23=fully_qualified_class_name();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_fully_qualified_class_name.add(fully_qualified_class_name23.getTree());

                            }
                            break;

                    }

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:152:83: ( 'implements' fully_qualified_class_name_list )?
                    int alt9=2;
                    int LA9_0 = input.LA(1);

                    if ( (LA9_0==91) ) {
                        alt9=1;
                    }
                    switch (alt9) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:152:84: 'implements' fully_qualified_class_name_list
                            {
                            string_literal24=(Token)match(input,91,FOLLOW_91_in_class_declaration_statement469); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_91.add(string_literal24);

                            pushFollow(FOLLOW_fully_qualified_class_name_list_in_class_declaration_statement471);
                            fully_qualified_class_name_list25=fully_qualified_class_name_list();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_fully_qualified_class_name_list.add(fully_qualified_class_name_list25.getTree());

                            }
                            break;

                    }

                    LEFT_BRACKET26=(Token)match(input,LEFT_BRACKET,FOLLOW_LEFT_BRACKET_in_class_declaration_statement481); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LEFT_BRACKET.add(LEFT_BRACKET26);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:153:20: ( class_statement_list )?
                    int alt10=2;
                    int LA10_0 = input.LA(1);

                    if ( ((LA10_0>=93 && LA10_0<=95)||LA10_0==104||LA10_0==113||(LA10_0>=129 && LA10_0<=132)) ) {
                        alt10=1;
                    }
                    switch (alt10) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:153:20: class_statement_list
                            {
                            pushFollow(FOLLOW_class_statement_list_in_class_declaration_statement483);
                            class_statement_list27=class_statement_list();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_class_statement_list.add(class_statement_list27.getTree());

                            }
                            break;

                    }

                    RIGHT_BRACKET28=(Token)match(input,RIGHT_BRACKET,FOLLOW_RIGHT_BRACKET_in_class_declaration_statement486); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RIGHT_BRACKET.add(RIGHT_BRACKET28);

                    if ( state.backtracking==0 ) {

                            startIndex = ((CommonToken)CLASS_T20).getStartIndex();
                            if ((class_entr_type19!=null?input.toString(class_entr_type19.start,class_entr_type19.stop):null) != null) {
                                token = (CommonToken)(class_entr_type19!=null?((Token)class_entr_type19.start):null);
                                startIndex = token.getStartIndex();
                            } 
                            token = (CommonToken)RIGHT_BRACKET28;
                            endIndex = token.getStopIndex(); 
                          
                    }


                    // AST REWRITE
                    // elements: IDENTIFIER, class_statement_list, class_entr_type, 90, CLASS_T, 91, fully_qualified_class_name, fully_qualified_class_name_list
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 163:5: -> ^( CLASS_T ( class_entr_type )? IDENTIFIER ( ^( 'extends' fully_qualified_class_name ) )? ( ^( 'implements' fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:163:9: ^( CLASS_T ( class_entr_type )? IDENTIFIER ( ^( 'extends' fully_qualified_class_name ) )? ( ^( 'implements' fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_CLASS_T.nextNode(), root_1);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:163:19: ( class_entr_type )?
                        if ( stream_class_entr_type.hasNext() ) {
                            adaptor.addChild(root_1, stream_class_entr_type.nextTree());

                        }
                        stream_class_entr_type.reset();
                        adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:163:47: ( ^( 'extends' fully_qualified_class_name ) )?
                        if ( stream_90.hasNext()||stream_fully_qualified_class_name.hasNext() ) {
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:163:47: ^( 'extends' fully_qualified_class_name )
                            {
                            SLAST root_2 = (SLAST)adaptor.nil();
                            root_2 = (SLAST)adaptor.becomeRoot(stream_90.nextNode(), root_2);

                            adaptor.addChild(root_2, stream_fully_qualified_class_name.nextTree());

                            adaptor.addChild(root_1, root_2);
                            }

                        }
                        stream_90.reset();
                        stream_fully_qualified_class_name.reset();
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:163:88: ( ^( 'implements' fully_qualified_class_name_list ) )?
                        if ( stream_91.hasNext()||stream_fully_qualified_class_name_list.hasNext() ) {
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:163:88: ^( 'implements' fully_qualified_class_name_list )
                            {
                            SLAST root_2 = (SLAST)adaptor.nil();
                            root_2 = (SLAST)adaptor.becomeRoot(stream_91.nextNode(), root_2);

                            adaptor.addChild(root_2, stream_fully_qualified_class_name_list.nextTree());

                            adaptor.addChild(root_1, root_2);
                            }

                        }
                        stream_91.reset();
                        stream_fully_qualified_class_name_list.reset();
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:164:7: ( ^( CLASS_BODY class_statement_list ) )?
                        if ( stream_class_statement_list.hasNext() ) {
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:164:7: ^( CLASS_BODY class_statement_list )
                            {
                            SLAST root_2 = (SLAST)adaptor.nil();
                            root_2 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(CLASS_BODY, "CLASS_BODY"), root_2);

                            adaptor.addChild(root_2, stream_class_statement_list.nextTree());

                            adaptor.addChild(root_1, root_2);
                            }

                        }
                        stream_class_statement_list.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }


                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:166:6: ( 'interface' IDENTIFIER ( 'extends' fully_qualified_class_name_list )? ( 'implements' fully_qualified_class_name_list )? LEFT_BRACKET ( class_statement_list )? RIGHT_BRACKET -> ^( 'interface' IDENTIFIER ( ^( 'extends' fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? ) )
                    {
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:166:6: ( 'interface' IDENTIFIER ( 'extends' fully_qualified_class_name_list )? ( 'implements' fully_qualified_class_name_list )? LEFT_BRACKET ( class_statement_list )? RIGHT_BRACKET -> ^( 'interface' IDENTIFIER ( ^( 'extends' fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? ) )
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:166:7: 'interface' IDENTIFIER ( 'extends' fully_qualified_class_name_list )? ( 'implements' fully_qualified_class_name_list )? LEFT_BRACKET ( class_statement_list )? RIGHT_BRACKET
                    {
                    string_literal29=(Token)match(input,92,FOLLOW_92_in_class_declaration_statement547); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_92.add(string_literal29);

                    IDENTIFIER30=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_class_declaration_statement549); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER30);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:166:30: ( 'extends' fully_qualified_class_name_list )?
                    int alt11=2;
                    int LA11_0 = input.LA(1);

                    if ( (LA11_0==90) ) {
                        alt11=1;
                    }
                    switch (alt11) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:166:31: 'extends' fully_qualified_class_name_list
                            {
                            string_literal31=(Token)match(input,90,FOLLOW_90_in_class_declaration_statement552); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_90.add(string_literal31);

                            pushFollow(FOLLOW_fully_qualified_class_name_list_in_class_declaration_statement554);
                            fully_qualified_class_name_list32=fully_qualified_class_name_list();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_fully_qualified_class_name_list.add(fully_qualified_class_name_list32.getTree());

                            }
                            break;

                    }

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:166:75: ( 'implements' fully_qualified_class_name_list )?
                    int alt12=2;
                    int LA12_0 = input.LA(1);

                    if ( (LA12_0==91) ) {
                        alt12=1;
                    }
                    switch (alt12) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:166:76: 'implements' fully_qualified_class_name_list
                            {
                            string_literal33=(Token)match(input,91,FOLLOW_91_in_class_declaration_statement559); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_91.add(string_literal33);

                            pushFollow(FOLLOW_fully_qualified_class_name_list_in_class_declaration_statement561);
                            fully_qualified_class_name_list34=fully_qualified_class_name_list();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_fully_qualified_class_name_list.add(fully_qualified_class_name_list34.getTree());

                            }
                            break;

                    }

                    LEFT_BRACKET35=(Token)match(input,LEFT_BRACKET,FOLLOW_LEFT_BRACKET_in_class_declaration_statement571); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LEFT_BRACKET.add(LEFT_BRACKET35);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:167:20: ( class_statement_list )?
                    int alt13=2;
                    int LA13_0 = input.LA(1);

                    if ( ((LA13_0>=93 && LA13_0<=95)||LA13_0==104||LA13_0==113||(LA13_0>=129 && LA13_0<=132)) ) {
                        alt13=1;
                    }
                    switch (alt13) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:167:20: class_statement_list
                            {
                            pushFollow(FOLLOW_class_statement_list_in_class_declaration_statement573);
                            class_statement_list36=class_statement_list();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_class_statement_list.add(class_statement_list36.getTree());

                            }
                            break;

                    }

                    RIGHT_BRACKET37=(Token)match(input,RIGHT_BRACKET,FOLLOW_RIGHT_BRACKET_in_class_declaration_statement576); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RIGHT_BRACKET.add(RIGHT_BRACKET37);



                    // AST REWRITE
                    // elements: class_statement_list, 90, fully_qualified_class_name_list, IDENTIFIER, 92
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 168:5: -> ^( 'interface' IDENTIFIER ( ^( 'extends' fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:168:9: ^( 'interface' IDENTIFIER ( ^( 'extends' fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_92.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:168:34: ( ^( 'extends' fully_qualified_class_name_list ) )?
                        if ( stream_90.hasNext()||stream_fully_qualified_class_name_list.hasNext() ) {
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:168:34: ^( 'extends' fully_qualified_class_name_list )
                            {
                            SLAST root_2 = (SLAST)adaptor.nil();
                            root_2 = (SLAST)adaptor.becomeRoot(stream_90.nextNode(), root_2);

                            adaptor.addChild(root_2, stream_fully_qualified_class_name_list.nextTree());

                            adaptor.addChild(root_1, root_2);
                            }

                        }
                        stream_90.reset();
                        stream_fully_qualified_class_name_list.reset();
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:169:7: ( ^( CLASS_BODY class_statement_list ) )?
                        if ( stream_class_statement_list.hasNext() ) {
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:169:7: ^( CLASS_BODY class_statement_list )
                            {
                            SLAST root_2 = (SLAST)adaptor.nil();
                            root_2 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(CLASS_BODY, "CLASS_BODY"), root_2);

                            adaptor.addChild(root_2, stream_class_statement_list.nextTree());

                            adaptor.addChild(root_1, root_2);
                            }

                        }
                        stream_class_statement_list.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }


                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "class_declaration_statement"

    public static class class_entr_type_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "class_entr_type"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:173:1: class_entr_type : ( 'abstract' | 'final' );
    public final CompilerAstParser.class_entr_type_return class_entr_type() throws RecognitionException {
        CompilerAstParser.class_entr_type_return retval = new CompilerAstParser.class_entr_type_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token set38=null;

        SLAST set38_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:174:3: ( 'abstract' | 'final' )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:
            {
            root_0 = (SLAST)adaptor.nil();

            set38=(Token)input.LT(1);
            if ( (input.LA(1)>=93 && input.LA(1)<=94) ) {
                input.consume();
                if ( state.backtracking==0 ) adaptor.addChild(root_0, (SLAST)adaptor.create(set38));
                state.errorRecovery=false;state.failed=false;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                MismatchedSetException mse = new MismatchedSetException(null,input);
                throw mse;
            }


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "class_entr_type"

    public static class class_statement_list_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "class_statement_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:178:1: class_statement_list : ( class_statement )+ -> ( class_statement )+ ;
    public final CompilerAstParser.class_statement_list_return class_statement_list() throws RecognitionException {
        CompilerAstParser.class_statement_list_return retval = new CompilerAstParser.class_statement_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        CompilerAstParser.class_statement_return class_statement39 = null;


        RewriteRuleSubtreeStream stream_class_statement=new RewriteRuleSubtreeStream(adaptor,"rule class_statement");
        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:179:3: ( ( class_statement )+ -> ( class_statement )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:179:5: ( class_statement )+
            {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:179:5: ( class_statement )+
            int cnt15=0;
            loop15:
            do {
                int alt15=2;
                int LA15_0 = input.LA(1);

                if ( ((LA15_0>=93 && LA15_0<=95)||LA15_0==104||LA15_0==113||(LA15_0>=129 && LA15_0<=132)) ) {
                    alt15=1;
                }


                switch (alt15) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:179:6: class_statement
            	    {
            	    pushFollow(FOLLOW_class_statement_in_class_statement_list651);
            	    class_statement39=class_statement();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_class_statement.add(class_statement39.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt15 >= 1 ) break loop15;
            	    if (state.backtracking>0) {state.failed=true; return retval;}
                        EarlyExitException eee =
                            new EarlyExitException(15, input);
                        throw eee;
                }
                cnt15++;
            } while (true);



            // AST REWRITE
            // elements: class_statement
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 179:29: -> ( class_statement )+
            {
                if ( !(stream_class_statement.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_class_statement.hasNext() ) {
                    adaptor.addChild(root_0, stream_class_statement.nextTree());

                }
                stream_class_statement.reset();

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "class_statement_list"

    public static class class_statement_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "class_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:182:1: class_statement : ( variable_modifiers static_var_list ';' -> ^( FIELD_DECL variable_modifiers static_var_list ) | ( modifier )? method_declaration -> ^( METHOD_DECL ( modifier )? method_declaration ) | class_constant_declaration ';' -> ^( FIELD_DECL class_constant_declaration ) );
    public final CompilerAstParser.class_statement_return class_statement() throws RecognitionException {
        CompilerAstParser.class_statement_return retval = new CompilerAstParser.class_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token char_literal42=null;
        Token char_literal46=null;
        CompilerAstParser.variable_modifiers_return variable_modifiers40 = null;

        CompilerAstParser.static_var_list_return static_var_list41 = null;

        CompilerAstParser.modifier_return modifier43 = null;

        CompilerAstParser.method_declaration_return method_declaration44 = null;

        CompilerAstParser.class_constant_declaration_return class_constant_declaration45 = null;


        SLAST char_literal42_tree=null;
        SLAST char_literal46_tree=null;
        RewriteRuleTokenStream stream_89=new RewriteRuleTokenStream(adaptor,"token 89");
        RewriteRuleSubtreeStream stream_modifier=new RewriteRuleSubtreeStream(adaptor,"rule modifier");
        RewriteRuleSubtreeStream stream_class_constant_declaration=new RewriteRuleSubtreeStream(adaptor,"rule class_constant_declaration");
        RewriteRuleSubtreeStream stream_method_declaration=new RewriteRuleSubtreeStream(adaptor,"rule method_declaration");
        RewriteRuleSubtreeStream stream_static_var_list=new RewriteRuleSubtreeStream(adaptor,"rule static_var_list");
        RewriteRuleSubtreeStream stream_variable_modifiers=new RewriteRuleSubtreeStream(adaptor,"rule variable_modifiers");
        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:183:3: ( variable_modifiers static_var_list ';' -> ^( FIELD_DECL variable_modifiers static_var_list ) | ( modifier )? method_declaration -> ^( METHOD_DECL ( modifier )? method_declaration ) | class_constant_declaration ';' -> ^( FIELD_DECL class_constant_declaration ) )
            int alt17=3;
            alt17 = dfa17.predict(input);
            switch (alt17) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:183:5: variable_modifiers static_var_list ';'
                    {
                    pushFollow(FOLLOW_variable_modifiers_in_class_statement678);
                    variable_modifiers40=variable_modifiers();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_variable_modifiers.add(variable_modifiers40.getTree());
                    pushFollow(FOLLOW_static_var_list_in_class_statement680);
                    static_var_list41=static_var_list();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_static_var_list.add(static_var_list41.getTree());
                    char_literal42=(Token)match(input,89,FOLLOW_89_in_class_statement682); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_89.add(char_literal42);



                    // AST REWRITE
                    // elements: static_var_list, variable_modifiers
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 183:47: -> ^( FIELD_DECL variable_modifiers static_var_list )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:183:51: ^( FIELD_DECL variable_modifiers static_var_list )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(FIELD_DECL, "FIELD_DECL"), root_1);

                        adaptor.addChild(root_1, stream_variable_modifiers.nextTree());
                        adaptor.addChild(root_1, stream_static_var_list.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:184:5: ( modifier )? method_declaration
                    {
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:184:5: ( modifier )?
                    int alt16=2;
                    int LA16_0 = input.LA(1);

                    if ( ((LA16_0>=93 && LA16_0<=94)||LA16_0==104||(LA16_0>=130 && LA16_0<=132)) ) {
                        alt16=1;
                    }
                    switch (alt16) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:184:5: modifier
                            {
                            pushFollow(FOLLOW_modifier_in_class_statement702);
                            modifier43=modifier();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_modifier.add(modifier43.getTree());

                            }
                            break;

                    }

                    pushFollow(FOLLOW_method_declaration_in_class_statement705);
                    method_declaration44=method_declaration();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_method_declaration.add(method_declaration44.getTree());


                    // AST REWRITE
                    // elements: modifier, method_declaration
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 184:41: -> ^( METHOD_DECL ( modifier )? method_declaration )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:184:45: ^( METHOD_DECL ( modifier )? method_declaration )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(METHOD_DECL, "METHOD_DECL"), root_1);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:184:59: ( modifier )?
                        if ( stream_modifier.hasNext() ) {
                            adaptor.addChild(root_1, stream_modifier.nextTree());

                        }
                        stream_modifier.reset();
                        adaptor.addChild(root_1, stream_method_declaration.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 3 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:185:5: class_constant_declaration ';'
                    {
                    pushFollow(FOLLOW_class_constant_declaration_in_class_statement730);
                    class_constant_declaration45=class_constant_declaration();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_class_constant_declaration.add(class_constant_declaration45.getTree());
                    char_literal46=(Token)match(input,89,FOLLOW_89_in_class_statement732); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_89.add(char_literal46);



                    // AST REWRITE
                    // elements: class_constant_declaration
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 185:45: -> ^( FIELD_DECL class_constant_declaration )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:185:49: ^( FIELD_DECL class_constant_declaration )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(FIELD_DECL, "FIELD_DECL"), root_1);

                        adaptor.addChild(root_1, stream_class_constant_declaration.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "class_statement"

    public static class function_declaration_statement_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "function_declaration_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:188:1: function_declaration_statement : 'function' ( '&' )? IDENTIFIER LEFT_PARETHESIS ( parameter_list )? RIGHT_PARETHESIS block -> ^( 'function' ( '&' )? IDENTIFIER ( parameter_list )? block ) ;
    public final CompilerAstParser.function_declaration_statement_return function_declaration_statement() throws RecognitionException {
        CompilerAstParser.function_declaration_statement_return retval = new CompilerAstParser.function_declaration_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token string_literal47=null;
        Token char_literal48=null;
        Token IDENTIFIER49=null;
        Token LEFT_PARETHESIS50=null;
        Token RIGHT_PARETHESIS52=null;
        CompilerAstParser.parameter_list_return parameter_list51 = null;

        CompilerAstParser.block_return block53 = null;


        SLAST string_literal47_tree=null;
        SLAST char_literal48_tree=null;
        SLAST IDENTIFIER49_tree=null;
        SLAST LEFT_PARETHESIS50_tree=null;
        SLAST RIGHT_PARETHESIS52_tree=null;
        RewriteRuleTokenStream stream_95=new RewriteRuleTokenStream(adaptor,"token 95");
        RewriteRuleTokenStream stream_LEFT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token LEFT_PARETHESIS");
        RewriteRuleTokenStream stream_BIT_AND=new RewriteRuleTokenStream(adaptor,"token BIT_AND");
        RewriteRuleTokenStream stream_IDENTIFIER=new RewriteRuleTokenStream(adaptor,"token IDENTIFIER");
        RewriteRuleTokenStream stream_RIGHT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token RIGHT_PARETHESIS");
        RewriteRuleSubtreeStream stream_block=new RewriteRuleSubtreeStream(adaptor,"rule block");
        RewriteRuleSubtreeStream stream_parameter_list=new RewriteRuleSubtreeStream(adaptor,"rule parameter_list");
        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:189:3: ( 'function' ( '&' )? IDENTIFIER LEFT_PARETHESIS ( parameter_list )? RIGHT_PARETHESIS block -> ^( 'function' ( '&' )? IDENTIFIER ( parameter_list )? block ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:189:5: 'function' ( '&' )? IDENTIFIER LEFT_PARETHESIS ( parameter_list )? RIGHT_PARETHESIS block
            {
            string_literal47=(Token)match(input,95,FOLLOW_95_in_function_declaration_statement765); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_95.add(string_literal47);

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:189:16: ( '&' )?
            int alt18=2;
            int LA18_0 = input.LA(1);

            if ( (LA18_0==BIT_AND) ) {
                alt18=1;
            }
            switch (alt18) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:189:16: '&'
                    {
                    char_literal48=(Token)match(input,BIT_AND,FOLLOW_BIT_AND_in_function_declaration_statement767); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_BIT_AND.add(char_literal48);


                    }
                    break;

            }

            IDENTIFIER49=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_function_declaration_statement770); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER49);

            LEFT_PARETHESIS50=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_function_declaration_statement772); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS50);

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:189:48: ( parameter_list )?
            int alt19=2;
            int LA19_0 = input.LA(1);

            if ( (LA19_0==IDENTIFIER||LA19_0==BIT_AND||LA19_0==DOLLAR_T||LA19_0==113||(LA19_0>=153 && LA19_0<=163)) ) {
                alt19=1;
            }
            switch (alt19) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:189:48: parameter_list
                    {
                    pushFollow(FOLLOW_parameter_list_in_function_declaration_statement774);
                    parameter_list51=parameter_list();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_parameter_list.add(parameter_list51.getTree());

                    }
                    break;

            }

            RIGHT_PARETHESIS52=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_function_declaration_statement777); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS52);

            pushFollow(FOLLOW_block_in_function_declaration_statement784);
            block53=block();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_block.add(block53.getTree());


            // AST REWRITE
            // elements: IDENTIFIER, BIT_AND, block, parameter_list, 95
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 191:3: -> ^( 'function' ( '&' )? IDENTIFIER ( parameter_list )? block )
            {
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:191:6: ^( 'function' ( '&' )? IDENTIFIER ( parameter_list )? block )
                {
                SLAST root_1 = (SLAST)adaptor.nil();
                root_1 = (SLAST)adaptor.becomeRoot(stream_95.nextNode(), root_1);

                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:191:19: ( '&' )?
                if ( stream_BIT_AND.hasNext() ) {
                    adaptor.addChild(root_1, stream_BIT_AND.nextNode());

                }
                stream_BIT_AND.reset();
                adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:191:35: ( parameter_list )?
                if ( stream_parameter_list.hasNext() ) {
                    adaptor.addChild(root_1, stream_parameter_list.nextTree());

                }
                stream_parameter_list.reset();
                adaptor.addChild(root_1, stream_block.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "function_declaration_statement"

    public static class block_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "block"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:194:1: block : LEFT_BRACKET ( inner_statement_list )? RIGHT_BRACKET -> ^( BLOCK ( inner_statement_list )? ) ;
    public final CompilerAstParser.block_return block() throws RecognitionException {
        CompilerAstParser.block_return retval = new CompilerAstParser.block_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token LEFT_BRACKET54=null;
        Token RIGHT_BRACKET56=null;
        CompilerAstParser.inner_statement_list_return inner_statement_list55 = null;


        SLAST LEFT_BRACKET54_tree=null;
        SLAST RIGHT_BRACKET56_tree=null;
        RewriteRuleTokenStream stream_LEFT_BRACKET=new RewriteRuleTokenStream(adaptor,"token LEFT_BRACKET");
        RewriteRuleTokenStream stream_RIGHT_BRACKET=new RewriteRuleTokenStream(adaptor,"token RIGHT_BRACKET");
        RewriteRuleSubtreeStream stream_inner_statement_list=new RewriteRuleSubtreeStream(adaptor,"rule inner_statement_list");
        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:195:3: ( LEFT_BRACKET ( inner_statement_list )? RIGHT_BRACKET -> ^( BLOCK ( inner_statement_list )? ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:195:5: LEFT_BRACKET ( inner_statement_list )? RIGHT_BRACKET
            {
            LEFT_BRACKET54=(Token)match(input,LEFT_BRACKET,FOLLOW_LEFT_BRACKET_in_block816); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_LEFT_BRACKET.add(LEFT_BRACKET54);

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:195:18: ( inner_statement_list )?
            int alt20=2;
            int LA20_0 = input.LA(1);

            if ( (LA20_0==LEFT_PARETHESIS||(LA20_0>=CLASS_T && LA20_0<=LEFT_BRACKET)||LA20_0==STRINGLITERAL||(LA20_0>=BIT_AND && LA20_0<=MINUS_T)||(LA20_0>=TILDA_T && LA20_0<=BACKTRICKLITERAL)||(LA20_0>=DOLLAR_T && LA20_0<=DOUBLELITERRAL)||(LA20_0>=88 && LA20_0<=89)||(LA20_0>=92 && LA20_0<=106)||(LA20_0>=108 && LA20_0<=111)||LA20_0==116||(LA20_0>=160 && LA20_0<=161)||(LA20_0>=163 && LA20_0<=166)||(LA20_0>=168 && LA20_0<=171)||(LA20_0>=173 && LA20_0<=178)) ) {
                alt20=1;
            }
            switch (alt20) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:195:18: inner_statement_list
                    {
                    pushFollow(FOLLOW_inner_statement_list_in_block818);
                    inner_statement_list55=inner_statement_list();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_inner_statement_list.add(inner_statement_list55.getTree());

                    }
                    break;

            }

            RIGHT_BRACKET56=(Token)match(input,RIGHT_BRACKET,FOLLOW_RIGHT_BRACKET_in_block821); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_RIGHT_BRACKET.add(RIGHT_BRACKET56);



            // AST REWRITE
            // elements: inner_statement_list
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 195:56: -> ^( BLOCK ( inner_statement_list )? )
            {
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:195:60: ^( BLOCK ( inner_statement_list )? )
                {
                SLAST root_1 = (SLAST)adaptor.nil();
                root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(BLOCK, "BLOCK"), root_1);

                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:195:68: ( inner_statement_list )?
                if ( stream_inner_statement_list.hasNext() ) {
                    adaptor.addChild(root_1, stream_inner_statement_list.nextTree());

                }
                stream_inner_statement_list.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "block"

    public static class statement_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:198:1: statement : topStatement -> ^( STATEMENT topStatement ) ;
    public final CompilerAstParser.statement_return statement() throws RecognitionException {
        CompilerAstParser.statement_return retval = new CompilerAstParser.statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        CompilerAstParser.topStatement_return topStatement57 = null;


        RewriteRuleSubtreeStream stream_topStatement=new RewriteRuleSubtreeStream(adaptor,"rule topStatement");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:208:3: ( topStatement -> ^( STATEMENT topStatement ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:208:5: topStatement
            {
            pushFollow(FOLLOW_topStatement_in_statement858);
            topStatement57=topStatement();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_topStatement.add(topStatement57.getTree());
            if ( state.backtracking==0 ) {

                  token = (CommonToken)(topStatement57!=null?((Token)topStatement57.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(topStatement57!=null?((Token)topStatement57.stop):null);
                  endIndex = token.getStopIndex();
                
            }


            // AST REWRITE
            // elements: topStatement
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 215:5: -> ^( STATEMENT topStatement )
            {
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:215:8: ^( STATEMENT topStatement )
                {
                SLAST root_1 = (SLAST)adaptor.nil();
                root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(STATEMENT, "STATEMENT"), root_1);

                adaptor.addChild(root_1, stream_topStatement.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST exprToken = retval.tree;
                exprToken.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "statement"

    public static class topStatement_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "topStatement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:218:1: topStatement : ( block | if_stat | 'while' LEFT_PARETHESIS expression RIGHT_PARETHESIS while_statement -> ^( 'while' ^( CONDITION expression ) while_statement ) | 'do' statement 'while' LEFT_PARETHESIS expression RIGHT_PARETHESIS ';' -> ^( 'do' ^( CONDITION expression ) statement ) | 'for' LEFT_PARETHESIS (e1= expr_list )? ';' (e2= expr_list )? ';' (e3= expr_list )? RIGHT_PARETHESIS ( for_statement )? -> ^( 'for' ( $e1)? ^( CONDITION ( $e2)? ) ^( ITERATE ( $e3)? ) ( for_statement )? ) | 'switch' LEFT_PARETHESIS expression RIGHT_PARETHESIS switch_case_list -> ^( 'switch' ^( CONDITION expression ) switch_case_list ) | 'break' ( expression )? ';' -> ^( 'break' ( expression )? ) | 'continue' ( expression )? ';' -> ^( 'continue' ( expression )? ) | 'return' ( expression )? ';' -> ^( 'return' ( expression )? ) | 'global' variable_list ';' -> ^( 'global' variable_list ) | 'static' static_var_list ';' -> ^( 'static' static_var_list ) | 'echo' expr_list ';' -> ^( 'echo' expr_list ) | expression ';' | 'foreach' LEFT_PARETHESIS expression 'as' foreach_variable RIGHT_PARETHESIS foreach_statement -> ^( 'foreach' ^( 'as' expression foreach_variable ) foreach_statement ) | 'declare' LEFT_PARETHESIS directive RIGHT_PARETHESIS declare_statement -> ^( 'declare' ^( CONDITION directive ) ( declare_statement )? ) | ';' -> ^( EMPTYSTATEMENT ) | 'try' LEFT_BRACKET top_statement RIGHT_BRACKET ( catch_branch )+ -> ^( 'try' ^( BLOCK top_statement ) ( catch_branch )+ ) | 'throw' expression ';' -> ^( 'throw' expression ) | 'use' use_filename ';' -> ^( 'use' use_filename ) );
    public final CompilerAstParser.topStatement_return topStatement() throws RecognitionException {
        CompilerAstParser.topStatement_return retval = new CompilerAstParser.topStatement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token string_literal60=null;
        Token LEFT_PARETHESIS61=null;
        Token RIGHT_PARETHESIS63=null;
        Token string_literal65=null;
        Token string_literal67=null;
        Token LEFT_PARETHESIS68=null;
        Token RIGHT_PARETHESIS70=null;
        Token char_literal71=null;
        Token string_literal72=null;
        Token LEFT_PARETHESIS73=null;
        Token char_literal74=null;
        Token char_literal75=null;
        Token RIGHT_PARETHESIS76=null;
        Token string_literal78=null;
        Token LEFT_PARETHESIS79=null;
        Token RIGHT_PARETHESIS81=null;
        Token string_literal83=null;
        Token char_literal85=null;
        Token string_literal86=null;
        Token char_literal88=null;
        Token string_literal89=null;
        Token char_literal91=null;
        Token string_literal92=null;
        Token char_literal94=null;
        Token string_literal95=null;
        Token char_literal97=null;
        Token string_literal98=null;
        Token char_literal100=null;
        Token char_literal102=null;
        Token string_literal103=null;
        Token LEFT_PARETHESIS104=null;
        Token string_literal106=null;
        Token RIGHT_PARETHESIS108=null;
        Token string_literal110=null;
        Token LEFT_PARETHESIS111=null;
        Token RIGHT_PARETHESIS113=null;
        Token char_literal115=null;
        Token string_literal116=null;
        Token LEFT_BRACKET117=null;
        Token RIGHT_BRACKET119=null;
        Token string_literal121=null;
        Token char_literal123=null;
        Token string_literal124=null;
        Token char_literal126=null;
        CompilerAstParser.expr_list_return e1 = null;

        CompilerAstParser.expr_list_return e2 = null;

        CompilerAstParser.expr_list_return e3 = null;

        CompilerAstParser.block_return block58 = null;

        CompilerAstParser.if_stat_return if_stat59 = null;

        CompilerAstParser.expression_return expression62 = null;

        CompilerAstParser.while_statement_return while_statement64 = null;

        CompilerAstParser.statement_return statement66 = null;

        CompilerAstParser.expression_return expression69 = null;

        CompilerAstParser.for_statement_return for_statement77 = null;

        CompilerAstParser.expression_return expression80 = null;

        CompilerAstParser.switch_case_list_return switch_case_list82 = null;

        CompilerAstParser.expression_return expression84 = null;

        CompilerAstParser.expression_return expression87 = null;

        CompilerAstParser.expression_return expression90 = null;

        CompilerAstParser.variable_list_return variable_list93 = null;

        CompilerAstParser.static_var_list_return static_var_list96 = null;

        CompilerAstParser.expr_list_return expr_list99 = null;

        CompilerAstParser.expression_return expression101 = null;

        CompilerAstParser.expression_return expression105 = null;

        CompilerAstParser.foreach_variable_return foreach_variable107 = null;

        CompilerAstParser.foreach_statement_return foreach_statement109 = null;

        CompilerAstParser.directive_return directive112 = null;

        CompilerAstParser.declare_statement_return declare_statement114 = null;

        CompilerAstParser.top_statement_return top_statement118 = null;

        CompilerAstParser.catch_branch_return catch_branch120 = null;

        CompilerAstParser.expression_return expression122 = null;

        CompilerAstParser.use_filename_return use_filename125 = null;


        SLAST string_literal60_tree=null;
        SLAST LEFT_PARETHESIS61_tree=null;
        SLAST RIGHT_PARETHESIS63_tree=null;
        SLAST string_literal65_tree=null;
        SLAST string_literal67_tree=null;
        SLAST LEFT_PARETHESIS68_tree=null;
        SLAST RIGHT_PARETHESIS70_tree=null;
        SLAST char_literal71_tree=null;
        SLAST string_literal72_tree=null;
        SLAST LEFT_PARETHESIS73_tree=null;
        SLAST char_literal74_tree=null;
        SLAST char_literal75_tree=null;
        SLAST RIGHT_PARETHESIS76_tree=null;
        SLAST string_literal78_tree=null;
        SLAST LEFT_PARETHESIS79_tree=null;
        SLAST RIGHT_PARETHESIS81_tree=null;
        SLAST string_literal83_tree=null;
        SLAST char_literal85_tree=null;
        SLAST string_literal86_tree=null;
        SLAST char_literal88_tree=null;
        SLAST string_literal89_tree=null;
        SLAST char_literal91_tree=null;
        SLAST string_literal92_tree=null;
        SLAST char_literal94_tree=null;
        SLAST string_literal95_tree=null;
        SLAST char_literal97_tree=null;
        SLAST string_literal98_tree=null;
        SLAST char_literal100_tree=null;
        SLAST char_literal102_tree=null;
        SLAST string_literal103_tree=null;
        SLAST LEFT_PARETHESIS104_tree=null;
        SLAST string_literal106_tree=null;
        SLAST RIGHT_PARETHESIS108_tree=null;
        SLAST string_literal110_tree=null;
        SLAST LEFT_PARETHESIS111_tree=null;
        SLAST RIGHT_PARETHESIS113_tree=null;
        SLAST char_literal115_tree=null;
        SLAST string_literal116_tree=null;
        SLAST LEFT_BRACKET117_tree=null;
        SLAST RIGHT_BRACKET119_tree=null;
        SLAST string_literal121_tree=null;
        SLAST char_literal123_tree=null;
        SLAST string_literal124_tree=null;
        SLAST char_literal126_tree=null;
        RewriteRuleTokenStream stream_98=new RewriteRuleTokenStream(adaptor,"token 98");
        RewriteRuleTokenStream stream_97=new RewriteRuleTokenStream(adaptor,"token 97");
        RewriteRuleTokenStream stream_96=new RewriteRuleTokenStream(adaptor,"token 96");
        RewriteRuleTokenStream stream_LEFT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token LEFT_PARETHESIS");
        RewriteRuleTokenStream stream_110=new RewriteRuleTokenStream(adaptor,"token 110");
        RewriteRuleTokenStream stream_111=new RewriteRuleTokenStream(adaptor,"token 111");
        RewriteRuleTokenStream stream_LEFT_BRACKET=new RewriteRuleTokenStream(adaptor,"token LEFT_BRACKET");
        RewriteRuleTokenStream stream_RIGHT_BRACKET=new RewriteRuleTokenStream(adaptor,"token RIGHT_BRACKET");
        RewriteRuleTokenStream stream_RIGHT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token RIGHT_PARETHESIS");
        RewriteRuleTokenStream stream_109=new RewriteRuleTokenStream(adaptor,"token 109");
        RewriteRuleTokenStream stream_108=new RewriteRuleTokenStream(adaptor,"token 108");
        RewriteRuleTokenStream stream_107=new RewriteRuleTokenStream(adaptor,"token 107");
        RewriteRuleTokenStream stream_106=new RewriteRuleTokenStream(adaptor,"token 106");
        RewriteRuleTokenStream stream_105=new RewriteRuleTokenStream(adaptor,"token 105");
        RewriteRuleTokenStream stream_104=new RewriteRuleTokenStream(adaptor,"token 104");
        RewriteRuleTokenStream stream_103=new RewriteRuleTokenStream(adaptor,"token 103");
        RewriteRuleTokenStream stream_99=new RewriteRuleTokenStream(adaptor,"token 99");
        RewriteRuleTokenStream stream_102=new RewriteRuleTokenStream(adaptor,"token 102");
        RewriteRuleTokenStream stream_101=new RewriteRuleTokenStream(adaptor,"token 101");
        RewriteRuleTokenStream stream_100=new RewriteRuleTokenStream(adaptor,"token 100");
        RewriteRuleTokenStream stream_89=new RewriteRuleTokenStream(adaptor,"token 89");
        RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");
        RewriteRuleSubtreeStream stream_while_statement=new RewriteRuleSubtreeStream(adaptor,"rule while_statement");
        RewriteRuleSubtreeStream stream_static_var_list=new RewriteRuleSubtreeStream(adaptor,"rule static_var_list");
        RewriteRuleSubtreeStream stream_declare_statement=new RewriteRuleSubtreeStream(adaptor,"rule declare_statement");
        RewriteRuleSubtreeStream stream_statement=new RewriteRuleSubtreeStream(adaptor,"rule statement");
        RewriteRuleSubtreeStream stream_use_filename=new RewriteRuleSubtreeStream(adaptor,"rule use_filename");
        RewriteRuleSubtreeStream stream_variable_list=new RewriteRuleSubtreeStream(adaptor,"rule variable_list");
        RewriteRuleSubtreeStream stream_catch_branch=new RewriteRuleSubtreeStream(adaptor,"rule catch_branch");
        RewriteRuleSubtreeStream stream_foreach_statement=new RewriteRuleSubtreeStream(adaptor,"rule foreach_statement");
        RewriteRuleSubtreeStream stream_top_statement=new RewriteRuleSubtreeStream(adaptor,"rule top_statement");
        RewriteRuleSubtreeStream stream_for_statement=new RewriteRuleSubtreeStream(adaptor,"rule for_statement");
        RewriteRuleSubtreeStream stream_directive=new RewriteRuleSubtreeStream(adaptor,"rule directive");
        RewriteRuleSubtreeStream stream_foreach_variable=new RewriteRuleSubtreeStream(adaptor,"rule foreach_variable");
        RewriteRuleSubtreeStream stream_expr_list=new RewriteRuleSubtreeStream(adaptor,"rule expr_list");
        RewriteRuleSubtreeStream stream_switch_case_list=new RewriteRuleSubtreeStream(adaptor,"rule switch_case_list");
        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:219:3: ( block | if_stat | 'while' LEFT_PARETHESIS expression RIGHT_PARETHESIS while_statement -> ^( 'while' ^( CONDITION expression ) while_statement ) | 'do' statement 'while' LEFT_PARETHESIS expression RIGHT_PARETHESIS ';' -> ^( 'do' ^( CONDITION expression ) statement ) | 'for' LEFT_PARETHESIS (e1= expr_list )? ';' (e2= expr_list )? ';' (e3= expr_list )? RIGHT_PARETHESIS ( for_statement )? -> ^( 'for' ( $e1)? ^( CONDITION ( $e2)? ) ^( ITERATE ( $e3)? ) ( for_statement )? ) | 'switch' LEFT_PARETHESIS expression RIGHT_PARETHESIS switch_case_list -> ^( 'switch' ^( CONDITION expression ) switch_case_list ) | 'break' ( expression )? ';' -> ^( 'break' ( expression )? ) | 'continue' ( expression )? ';' -> ^( 'continue' ( expression )? ) | 'return' ( expression )? ';' -> ^( 'return' ( expression )? ) | 'global' variable_list ';' -> ^( 'global' variable_list ) | 'static' static_var_list ';' -> ^( 'static' static_var_list ) | 'echo' expr_list ';' -> ^( 'echo' expr_list ) | expression ';' | 'foreach' LEFT_PARETHESIS expression 'as' foreach_variable RIGHT_PARETHESIS foreach_statement -> ^( 'foreach' ^( 'as' expression foreach_variable ) foreach_statement ) | 'declare' LEFT_PARETHESIS directive RIGHT_PARETHESIS declare_statement -> ^( 'declare' ^( CONDITION directive ) ( declare_statement )? ) | ';' -> ^( EMPTYSTATEMENT ) | 'try' LEFT_BRACKET top_statement RIGHT_BRACKET ( catch_branch )+ -> ^( 'try' ^( BLOCK top_statement ) ( catch_branch )+ ) | 'throw' expression ';' -> ^( 'throw' expression ) | 'use' use_filename ';' -> ^( 'use' use_filename ) )
            int alt29=19;
            switch ( input.LA(1) ) {
            case LEFT_BRACKET:
                {
                alt29=1;
                }
                break;
            case 116:
                {
                alt29=2;
                }
                break;
            case 96:
                {
                alt29=3;
                }
                break;
            case 97:
                {
                alt29=4;
                }
                break;
            case 98:
                {
                alt29=5;
                }
                break;
            case 99:
                {
                alt29=6;
                }
                break;
            case 100:
                {
                alt29=7;
                }
                break;
            case 101:
                {
                alt29=8;
                }
                break;
            case 102:
                {
                alt29=9;
                }
                break;
            case 103:
                {
                alt29=10;
                }
                break;
            case 104:
                {
                alt29=11;
                }
                break;
            case 105:
                {
                alt29=12;
                }
                break;
            case LEFT_PARETHESIS:
            case IDENTIFIER:
            case STRINGLITERAL:
            case BIT_AND:
            case PLUS_T:
            case MINUS_T:
            case TILDA_T:
            case BACKTRICKLITERAL:
            case DOLLAR_T:
            case INTLITERAL:
            case FLOATLITERAL:
            case DOUBLELITERRAL:
            case 95:
            case 160:
            case 161:
            case 163:
            case 164:
            case 165:
            case 166:
            case 168:
            case 169:
            case 170:
            case 171:
            case 173:
            case 174:
            case 175:
            case 176:
            case 177:
            case 178:
                {
                alt29=13;
                }
                break;
            case 106:
                {
                alt29=14;
                }
                break;
            case 108:
                {
                alt29=15;
                }
                break;
            case 89:
                {
                alt29=16;
                }
                break;
            case 109:
                {
                alt29=17;
                }
                break;
            case 110:
                {
                alt29=18;
                }
                break;
            case 111:
                {
                alt29=19;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 29, 0, input);

                throw nvae;
            }

            switch (alt29) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:219:5: block
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_block_in_topStatement890);
                    block58=block();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, block58.getTree());

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:220:5: if_stat
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_if_stat_in_topStatement896);
                    if_stat59=if_stat();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, if_stat59.getTree());

                    }
                    break;
                case 3 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:221:5: 'while' LEFT_PARETHESIS expression RIGHT_PARETHESIS while_statement
                    {
                    string_literal60=(Token)match(input,96,FOLLOW_96_in_topStatement902); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_96.add(string_literal60);

                    LEFT_PARETHESIS61=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_topStatement904); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS61);

                    pushFollow(FOLLOW_expression_in_topStatement906);
                    expression62=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_expression.add(expression62.getTree());
                    RIGHT_PARETHESIS63=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_topStatement908); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS63);

                    pushFollow(FOLLOW_while_statement_in_topStatement910);
                    while_statement64=while_statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_while_statement.add(while_statement64.getTree());


                    // AST REWRITE
                    // elements: 96, while_statement, expression
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 221:76: -> ^( 'while' ^( CONDITION expression ) while_statement )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:221:80: ^( 'while' ^( CONDITION expression ) while_statement )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_96.nextNode(), root_1);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:221:90: ^( CONDITION expression )
                        {
                        SLAST root_2 = (SLAST)adaptor.nil();
                        root_2 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(CONDITION, "CONDITION"), root_2);

                        adaptor.addChild(root_2, stream_expression.nextTree());

                        adaptor.addChild(root_1, root_2);
                        }
                        adaptor.addChild(root_1, stream_while_statement.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 4 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:222:5: 'do' statement 'while' LEFT_PARETHESIS expression RIGHT_PARETHESIS ';'
                    {
                    string_literal65=(Token)match(input,97,FOLLOW_97_in_topStatement934); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_97.add(string_literal65);

                    pushFollow(FOLLOW_statement_in_topStatement936);
                    statement66=statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_statement.add(statement66.getTree());
                    string_literal67=(Token)match(input,96,FOLLOW_96_in_topStatement938); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_96.add(string_literal67);

                    LEFT_PARETHESIS68=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_topStatement940); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS68);

                    pushFollow(FOLLOW_expression_in_topStatement942);
                    expression69=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_expression.add(expression69.getTree());
                    RIGHT_PARETHESIS70=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_topStatement944); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS70);

                    char_literal71=(Token)match(input,89,FOLLOW_89_in_topStatement946); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_89.add(char_literal71);



                    // AST REWRITE
                    // elements: 97, expression, statement
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 222:76: -> ^( 'do' ^( CONDITION expression ) statement )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:222:80: ^( 'do' ^( CONDITION expression ) statement )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_97.nextNode(), root_1);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:222:87: ^( CONDITION expression )
                        {
                        SLAST root_2 = (SLAST)adaptor.nil();
                        root_2 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(CONDITION, "CONDITION"), root_2);

                        adaptor.addChild(root_2, stream_expression.nextTree());

                        adaptor.addChild(root_1, root_2);
                        }
                        adaptor.addChild(root_1, stream_statement.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 5 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:223:5: 'for' LEFT_PARETHESIS (e1= expr_list )? ';' (e2= expr_list )? ';' (e3= expr_list )? RIGHT_PARETHESIS ( for_statement )?
                    {
                    string_literal72=(Token)match(input,98,FOLLOW_98_in_topStatement967); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_98.add(string_literal72);

                    LEFT_PARETHESIS73=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_topStatement969); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS73);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:223:29: (e1= expr_list )?
                    int alt21=2;
                    int LA21_0 = input.LA(1);

                    if ( (LA21_0==LEFT_PARETHESIS||LA21_0==IDENTIFIER||LA21_0==STRINGLITERAL||(LA21_0>=BIT_AND && LA21_0<=MINUS_T)||(LA21_0>=TILDA_T && LA21_0<=BACKTRICKLITERAL)||(LA21_0>=DOLLAR_T && LA21_0<=DOUBLELITERRAL)||LA21_0==95||(LA21_0>=160 && LA21_0<=161)||(LA21_0>=163 && LA21_0<=166)||(LA21_0>=168 && LA21_0<=171)||(LA21_0>=173 && LA21_0<=178)) ) {
                        alt21=1;
                    }
                    switch (alt21) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:223:29: e1= expr_list
                            {
                            pushFollow(FOLLOW_expr_list_in_topStatement973);
                            e1=expr_list();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_expr_list.add(e1.getTree());

                            }
                            break;

                    }

                    char_literal74=(Token)match(input,89,FOLLOW_89_in_topStatement976); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_89.add(char_literal74);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:223:47: (e2= expr_list )?
                    int alt22=2;
                    int LA22_0 = input.LA(1);

                    if ( (LA22_0==LEFT_PARETHESIS||LA22_0==IDENTIFIER||LA22_0==STRINGLITERAL||(LA22_0>=BIT_AND && LA22_0<=MINUS_T)||(LA22_0>=TILDA_T && LA22_0<=BACKTRICKLITERAL)||(LA22_0>=DOLLAR_T && LA22_0<=DOUBLELITERRAL)||LA22_0==95||(LA22_0>=160 && LA22_0<=161)||(LA22_0>=163 && LA22_0<=166)||(LA22_0>=168 && LA22_0<=171)||(LA22_0>=173 && LA22_0<=178)) ) {
                        alt22=1;
                    }
                    switch (alt22) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:223:47: e2= expr_list
                            {
                            pushFollow(FOLLOW_expr_list_in_topStatement980);
                            e2=expr_list();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_expr_list.add(e2.getTree());

                            }
                            break;

                    }

                    char_literal75=(Token)match(input,89,FOLLOW_89_in_topStatement983); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_89.add(char_literal75);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:223:65: (e3= expr_list )?
                    int alt23=2;
                    int LA23_0 = input.LA(1);

                    if ( (LA23_0==LEFT_PARETHESIS||LA23_0==IDENTIFIER||LA23_0==STRINGLITERAL||(LA23_0>=BIT_AND && LA23_0<=MINUS_T)||(LA23_0>=TILDA_T && LA23_0<=BACKTRICKLITERAL)||(LA23_0>=DOLLAR_T && LA23_0<=DOUBLELITERRAL)||LA23_0==95||(LA23_0>=160 && LA23_0<=161)||(LA23_0>=163 && LA23_0<=166)||(LA23_0>=168 && LA23_0<=171)||(LA23_0>=173 && LA23_0<=178)) ) {
                        alt23=1;
                    }
                    switch (alt23) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:223:65: e3= expr_list
                            {
                            pushFollow(FOLLOW_expr_list_in_topStatement987);
                            e3=expr_list();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_expr_list.add(e3.getTree());

                            }
                            break;

                    }

                    RIGHT_PARETHESIS76=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_topStatement990); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS76);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:223:94: ( for_statement )?
                    int alt24=2;
                    int LA24_0 = input.LA(1);

                    if ( (LA24_0==119) ) {
                        alt24=1;
                    }
                    switch (alt24) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:223:94: for_statement
                            {
                            pushFollow(FOLLOW_for_statement_in_topStatement992);
                            for_statement77=for_statement();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_for_statement.add(for_statement77.getTree());

                            }
                            break;

                    }



                    // AST REWRITE
                    // elements: for_statement, e1, e3, 98, e2
                    // token labels: 
                    // rule labels: e3, retval, e1, e2
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_e3=new RewriteRuleSubtreeStream(adaptor,"rule e3",e3!=null?e3.tree:null);
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
                    RewriteRuleSubtreeStream stream_e1=new RewriteRuleSubtreeStream(adaptor,"rule e1",e1!=null?e1.tree:null);
                    RewriteRuleSubtreeStream stream_e2=new RewriteRuleSubtreeStream(adaptor,"rule e2",e2!=null?e2.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 223:112: -> ^( 'for' ( $e1)? ^( CONDITION ( $e2)? ) ^( ITERATE ( $e3)? ) ( for_statement )? )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:223:116: ^( 'for' ( $e1)? ^( CONDITION ( $e2)? ) ^( ITERATE ( $e3)? ) ( for_statement )? )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_98.nextNode(), root_1);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:223:124: ( $e1)?
                        if ( stream_e1.hasNext() ) {
                            adaptor.addChild(root_1, stream_e1.nextTree());

                        }
                        stream_e1.reset();
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:223:129: ^( CONDITION ( $e2)? )
                        {
                        SLAST root_2 = (SLAST)adaptor.nil();
                        root_2 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(CONDITION, "CONDITION"), root_2);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:223:141: ( $e2)?
                        if ( stream_e2.hasNext() ) {
                            adaptor.addChild(root_2, stream_e2.nextTree());

                        }
                        stream_e2.reset();

                        adaptor.addChild(root_1, root_2);
                        }
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:223:147: ^( ITERATE ( $e3)? )
                        {
                        SLAST root_2 = (SLAST)adaptor.nil();
                        root_2 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(ITERATE, "ITERATE"), root_2);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:223:157: ( $e3)?
                        if ( stream_e3.hasNext() ) {
                            adaptor.addChild(root_2, stream_e3.nextTree());

                        }
                        stream_e3.reset();

                        adaptor.addChild(root_1, root_2);
                        }
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:223:163: ( for_statement )?
                        if ( stream_for_statement.hasNext() ) {
                            adaptor.addChild(root_1, stream_for_statement.nextTree());

                        }
                        stream_for_statement.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 6 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:224:5: 'switch' LEFT_PARETHESIS expression RIGHT_PARETHESIS switch_case_list
                    {
                    string_literal78=(Token)match(input,99,FOLLOW_99_in_topStatement1032); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_99.add(string_literal78);

                    LEFT_PARETHESIS79=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_topStatement1034); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS79);

                    pushFollow(FOLLOW_expression_in_topStatement1036);
                    expression80=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_expression.add(expression80.getTree());
                    RIGHT_PARETHESIS81=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_topStatement1038); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS81);

                    pushFollow(FOLLOW_switch_case_list_in_topStatement1040);
                    switch_case_list82=switch_case_list();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_switch_case_list.add(switch_case_list82.getTree());


                    // AST REWRITE
                    // elements: 99, switch_case_list, expression
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 224:76: -> ^( 'switch' ^( CONDITION expression ) switch_case_list )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:224:80: ^( 'switch' ^( CONDITION expression ) switch_case_list )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_99.nextNode(), root_1);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:224:91: ^( CONDITION expression )
                        {
                        SLAST root_2 = (SLAST)adaptor.nil();
                        root_2 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(CONDITION, "CONDITION"), root_2);

                        adaptor.addChild(root_2, stream_expression.nextTree());

                        adaptor.addChild(root_1, root_2);
                        }
                        adaptor.addChild(root_1, stream_switch_case_list.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 7 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:225:5: 'break' ( expression )? ';'
                    {
                    string_literal83=(Token)match(input,100,FOLLOW_100_in_topStatement1062); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_100.add(string_literal83);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:225:13: ( expression )?
                    int alt25=2;
                    int LA25_0 = input.LA(1);

                    if ( (LA25_0==LEFT_PARETHESIS||LA25_0==IDENTIFIER||LA25_0==STRINGLITERAL||(LA25_0>=BIT_AND && LA25_0<=MINUS_T)||(LA25_0>=TILDA_T && LA25_0<=BACKTRICKLITERAL)||(LA25_0>=DOLLAR_T && LA25_0<=DOUBLELITERRAL)||LA25_0==95||(LA25_0>=160 && LA25_0<=161)||(LA25_0>=163 && LA25_0<=166)||(LA25_0>=168 && LA25_0<=171)||(LA25_0>=173 && LA25_0<=178)) ) {
                        alt25=1;
                    }
                    switch (alt25) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:225:13: expression
                            {
                            pushFollow(FOLLOW_expression_in_topStatement1064);
                            expression84=expression();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_expression.add(expression84.getTree());

                            }
                            break;

                    }

                    char_literal85=(Token)match(input,89,FOLLOW_89_in_topStatement1067); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_89.add(char_literal85);



                    // AST REWRITE
                    // elements: expression, 100
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 225:41: -> ^( 'break' ( expression )? )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:225:45: ^( 'break' ( expression )? )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_100.nextNode(), root_1);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:225:55: ( expression )?
                        if ( stream_expression.hasNext() ) {
                            adaptor.addChild(root_1, stream_expression.nextTree());

                        }
                        stream_expression.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 8 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:226:5: 'continue' ( expression )? ';'
                    {
                    string_literal86=(Token)match(input,101,FOLLOW_101_in_topStatement1095); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_101.add(string_literal86);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:226:16: ( expression )?
                    int alt26=2;
                    int LA26_0 = input.LA(1);

                    if ( (LA26_0==LEFT_PARETHESIS||LA26_0==IDENTIFIER||LA26_0==STRINGLITERAL||(LA26_0>=BIT_AND && LA26_0<=MINUS_T)||(LA26_0>=TILDA_T && LA26_0<=BACKTRICKLITERAL)||(LA26_0>=DOLLAR_T && LA26_0<=DOUBLELITERRAL)||LA26_0==95||(LA26_0>=160 && LA26_0<=161)||(LA26_0>=163 && LA26_0<=166)||(LA26_0>=168 && LA26_0<=171)||(LA26_0>=173 && LA26_0<=178)) ) {
                        alt26=1;
                    }
                    switch (alt26) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:226:16: expression
                            {
                            pushFollow(FOLLOW_expression_in_topStatement1097);
                            expression87=expression();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_expression.add(expression87.getTree());

                            }
                            break;

                    }

                    char_literal88=(Token)match(input,89,FOLLOW_89_in_topStatement1100); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_89.add(char_literal88);



                    // AST REWRITE
                    // elements: expression, 101
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 226:43: -> ^( 'continue' ( expression )? )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:226:47: ^( 'continue' ( expression )? )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_101.nextNode(), root_1);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:226:60: ( expression )?
                        if ( stream_expression.hasNext() ) {
                            adaptor.addChild(root_1, stream_expression.nextTree());

                        }
                        stream_expression.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 9 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:227:5: 'return' ( expression )? ';'
                    {
                    string_literal89=(Token)match(input,102,FOLLOW_102_in_topStatement1127); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_102.add(string_literal89);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:227:14: ( expression )?
                    int alt27=2;
                    int LA27_0 = input.LA(1);

                    if ( (LA27_0==LEFT_PARETHESIS||LA27_0==IDENTIFIER||LA27_0==STRINGLITERAL||(LA27_0>=BIT_AND && LA27_0<=MINUS_T)||(LA27_0>=TILDA_T && LA27_0<=BACKTRICKLITERAL)||(LA27_0>=DOLLAR_T && LA27_0<=DOUBLELITERRAL)||LA27_0==95||(LA27_0>=160 && LA27_0<=161)||(LA27_0>=163 && LA27_0<=166)||(LA27_0>=168 && LA27_0<=171)||(LA27_0>=173 && LA27_0<=178)) ) {
                        alt27=1;
                    }
                    switch (alt27) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:227:14: expression
                            {
                            pushFollow(FOLLOW_expression_in_topStatement1129);
                            expression90=expression();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_expression.add(expression90.getTree());

                            }
                            break;

                    }

                    char_literal91=(Token)match(input,89,FOLLOW_89_in_topStatement1132); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_89.add(char_literal91);



                    // AST REWRITE
                    // elements: expression, 102
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 227:41: -> ^( 'return' ( expression )? )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:227:45: ^( 'return' ( expression )? )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_102.nextNode(), root_1);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:227:56: ( expression )?
                        if ( stream_expression.hasNext() ) {
                            adaptor.addChild(root_1, stream_expression.nextTree());

                        }
                        stream_expression.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 10 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:228:5: 'global' variable_list ';'
                    {
                    string_literal92=(Token)match(input,103,FOLLOW_103_in_topStatement1159); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_103.add(string_literal92);

                    pushFollow(FOLLOW_variable_list_in_topStatement1161);
                    variable_list93=variable_list();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_variable_list.add(variable_list93.getTree());
                    char_literal94=(Token)match(input,89,FOLLOW_89_in_topStatement1163); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_89.add(char_literal94);



                    // AST REWRITE
                    // elements: 103, variable_list
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 228:43: -> ^( 'global' variable_list )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:228:47: ^( 'global' variable_list )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_103.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_variable_list.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 11 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:229:5: 'static' static_var_list ';'
                    {
                    string_literal95=(Token)match(input,104,FOLLOW_104_in_topStatement1189); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_104.add(string_literal95);

                    pushFollow(FOLLOW_static_var_list_in_topStatement1191);
                    static_var_list96=static_var_list();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_static_var_list.add(static_var_list96.getTree());
                    char_literal97=(Token)match(input,89,FOLLOW_89_in_topStatement1193); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_89.add(char_literal97);



                    // AST REWRITE
                    // elements: 104, static_var_list
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 229:43: -> ^( 'static' static_var_list )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:229:47: ^( 'static' static_var_list )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_104.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_static_var_list.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 12 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:230:5: 'echo' expr_list ';'
                    {
                    string_literal98=(Token)match(input,105,FOLLOW_105_in_topStatement1217); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_105.add(string_literal98);

                    pushFollow(FOLLOW_expr_list_in_topStatement1219);
                    expr_list99=expr_list();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_expr_list.add(expr_list99.getTree());
                    char_literal100=(Token)match(input,89,FOLLOW_89_in_topStatement1221); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_89.add(char_literal100);



                    // AST REWRITE
                    // elements: 105, expr_list
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 230:39: -> ^( 'echo' expr_list )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:230:43: ^( 'echo' expr_list )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_105.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_expr_list.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 13 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:231:5: expression ';'
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_expression_in_topStatement1249);
                    expression101=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, expression101.getTree());
                    char_literal102=(Token)match(input,89,FOLLOW_89_in_topStatement1251); if (state.failed) return retval;

                    }
                    break;
                case 14 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:232:5: 'foreach' LEFT_PARETHESIS expression 'as' foreach_variable RIGHT_PARETHESIS foreach_statement
                    {
                    string_literal103=(Token)match(input,106,FOLLOW_106_in_topStatement1258); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_106.add(string_literal103);

                    LEFT_PARETHESIS104=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_topStatement1260); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS104);

                    pushFollow(FOLLOW_expression_in_topStatement1262);
                    expression105=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_expression.add(expression105.getTree());
                    string_literal106=(Token)match(input,107,FOLLOW_107_in_topStatement1264); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_107.add(string_literal106);

                    pushFollow(FOLLOW_foreach_variable_in_topStatement1266);
                    foreach_variable107=foreach_variable();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_foreach_variable.add(foreach_variable107.getTree());
                    RIGHT_PARETHESIS108=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_topStatement1268); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS108);

                    pushFollow(FOLLOW_foreach_statement_in_topStatement1278);
                    foreach_statement109=foreach_statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_foreach_statement.add(foreach_statement109.getTree());


                    // AST REWRITE
                    // elements: expression, foreach_variable, foreach_statement, 106, 107
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 234:6: -> ^( 'foreach' ^( 'as' expression foreach_variable ) foreach_statement )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:234:9: ^( 'foreach' ^( 'as' expression foreach_variable ) foreach_statement )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_106.nextNode(), root_1);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:234:21: ^( 'as' expression foreach_variable )
                        {
                        SLAST root_2 = (SLAST)adaptor.nil();
                        root_2 = (SLAST)adaptor.becomeRoot(stream_107.nextNode(), root_2);

                        adaptor.addChild(root_2, stream_expression.nextTree());
                        adaptor.addChild(root_2, stream_foreach_variable.nextTree());

                        adaptor.addChild(root_1, root_2);
                        }
                        adaptor.addChild(root_1, stream_foreach_statement.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 15 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:235:5: 'declare' LEFT_PARETHESIS directive RIGHT_PARETHESIS declare_statement
                    {
                    string_literal110=(Token)match(input,108,FOLLOW_108_in_topStatement1305); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_108.add(string_literal110);

                    LEFT_PARETHESIS111=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_topStatement1307); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS111);

                    pushFollow(FOLLOW_directive_in_topStatement1309);
                    directive112=directive();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_directive.add(directive112.getTree());
                    RIGHT_PARETHESIS113=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_topStatement1311); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS113);

                    pushFollow(FOLLOW_declare_statement_in_topStatement1313);
                    declare_statement114=declare_statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_declare_statement.add(declare_statement114.getTree());


                    // AST REWRITE
                    // elements: directive, 108, declare_statement
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 235:76: -> ^( 'declare' ^( CONDITION directive ) ( declare_statement )? )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:235:80: ^( 'declare' ^( CONDITION directive ) ( declare_statement )? )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_108.nextNode(), root_1);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:235:92: ^( CONDITION directive )
                        {
                        SLAST root_2 = (SLAST)adaptor.nil();
                        root_2 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(CONDITION, "CONDITION"), root_2);

                        adaptor.addChild(root_2, stream_directive.nextTree());

                        adaptor.addChild(root_1, root_2);
                        }
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:235:115: ( declare_statement )?
                        if ( stream_declare_statement.hasNext() ) {
                            adaptor.addChild(root_1, stream_declare_statement.nextTree());

                        }
                        stream_declare_statement.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 16 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:236:5: ';'
                    {
                    char_literal115=(Token)match(input,89,FOLLOW_89_in_topStatement1335); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_89.add(char_literal115);



                    // AST REWRITE
                    // elements: 
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 236:31: -> ^( EMPTYSTATEMENT )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:236:35: ^( EMPTYSTATEMENT )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(EMPTYSTATEMENT, "EMPTYSTATEMENT"), root_1);

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 17 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:237:5: 'try' LEFT_BRACKET top_statement RIGHT_BRACKET ( catch_branch )+
                    {
                    string_literal116=(Token)match(input,109,FOLLOW_109_in_topStatement1370); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_109.add(string_literal116);

                    LEFT_BRACKET117=(Token)match(input,LEFT_BRACKET,FOLLOW_LEFT_BRACKET_in_topStatement1372); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LEFT_BRACKET.add(LEFT_BRACKET117);

                    pushFollow(FOLLOW_top_statement_in_topStatement1374);
                    top_statement118=top_statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_top_statement.add(top_statement118.getTree());
                    RIGHT_BRACKET119=(Token)match(input,RIGHT_BRACKET,FOLLOW_RIGHT_BRACKET_in_topStatement1376); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RIGHT_BRACKET.add(RIGHT_BRACKET119);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:237:52: ( catch_branch )+
                    int cnt28=0;
                    loop28:
                    do {
                        int alt28=2;
                        int LA28_0 = input.LA(1);

                        if ( (LA28_0==124) ) {
                            alt28=1;
                        }


                        switch (alt28) {
                    	case 1 :
                    	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:237:52: catch_branch
                    	    {
                    	    pushFollow(FOLLOW_catch_branch_in_topStatement1378);
                    	    catch_branch120=catch_branch();

                    	    state._fsp--;
                    	    if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) stream_catch_branch.add(catch_branch120.getTree());

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt28 >= 1 ) break loop28;
                    	    if (state.backtracking>0) {state.failed=true; return retval;}
                                EarlyExitException eee =
                                    new EarlyExitException(28, input);
                                throw eee;
                        }
                        cnt28++;
                    } while (true);



                    // AST REWRITE
                    // elements: catch_branch, top_statement, 109
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 237:68: -> ^( 'try' ^( BLOCK top_statement ) ( catch_branch )+ )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:237:72: ^( 'try' ^( BLOCK top_statement ) ( catch_branch )+ )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_109.nextNode(), root_1);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:237:80: ^( BLOCK top_statement )
                        {
                        SLAST root_2 = (SLAST)adaptor.nil();
                        root_2 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(BLOCK, "BLOCK"), root_2);

                        adaptor.addChild(root_2, stream_top_statement.nextTree());

                        adaptor.addChild(root_1, root_2);
                        }
                        if ( !(stream_catch_branch.hasNext()) ) {
                            throw new RewriteEarlyExitException();
                        }
                        while ( stream_catch_branch.hasNext() ) {
                            adaptor.addChild(root_1, stream_catch_branch.nextTree());

                        }
                        stream_catch_branch.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 18 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:238:5: 'throw' expression ';'
                    {
                    string_literal121=(Token)match(input,110,FOLLOW_110_in_topStatement1403); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_110.add(string_literal121);

                    pushFollow(FOLLOW_expression_in_topStatement1405);
                    expression122=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_expression.add(expression122.getTree());
                    char_literal123=(Token)match(input,89,FOLLOW_89_in_topStatement1407); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_89.add(char_literal123);



                    // AST REWRITE
                    // elements: 110, expression
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 238:41: -> ^( 'throw' expression )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:238:45: ^( 'throw' expression )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_110.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_expression.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 19 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:239:5: 'use' use_filename ';'
                    {
                    string_literal124=(Token)match(input,111,FOLLOW_111_in_topStatement1435); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_111.add(string_literal124);

                    pushFollow(FOLLOW_use_filename_in_topStatement1437);
                    use_filename125=use_filename();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_use_filename.add(use_filename125.getTree());
                    char_literal126=(Token)match(input,89,FOLLOW_89_in_topStatement1439); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_89.add(char_literal126);



                    // AST REWRITE
                    // elements: use_filename, 111
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 239:41: -> ^( 'use' use_filename )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:239:45: ^( 'use' use_filename )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_111.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_use_filename.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "topStatement"

    public static class foreach_variable_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "foreach_variable"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:245:1: foreach_variable : (v1= variable -> variable ) ( '=>' v2= variable -> ^( '=>' $foreach_variable $v2) )? ;
    public final CompilerAstParser.foreach_variable_return foreach_variable() throws RecognitionException {
        CompilerAstParser.foreach_variable_return retval = new CompilerAstParser.foreach_variable_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token string_literal127=null;
        CompilerAstParser.variable_return v1 = null;

        CompilerAstParser.variable_return v2 = null;


        SLAST string_literal127_tree=null;
        RewriteRuleTokenStream stream_112=new RewriteRuleTokenStream(adaptor,"token 112");
        RewriteRuleSubtreeStream stream_variable=new RewriteRuleSubtreeStream(adaptor,"rule variable");
        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:246:3: ( (v1= variable -> variable ) ( '=>' v2= variable -> ^( '=>' $foreach_variable $v2) )? )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:246:5: (v1= variable -> variable ) ( '=>' v2= variable -> ^( '=>' $foreach_variable $v2) )?
            {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:246:5: (v1= variable -> variable )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:246:6: v1= variable
            {
            pushFollow(FOLLOW_variable_in_foreach_variable1482);
            v1=variable();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_variable.add(v1.getTree());


            // AST REWRITE
            // elements: variable
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 246:18: -> variable
            {
                adaptor.addChild(root_0, stream_variable.nextTree());

            }

            retval.tree = root_0;}
            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:247:5: ( '=>' v2= variable -> ^( '=>' $foreach_variable $v2) )?
            int alt30=2;
            int LA30_0 = input.LA(1);

            if ( (LA30_0==112) ) {
                alt30=1;
            }
            switch (alt30) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:247:6: '=>' v2= variable
                    {
                    string_literal127=(Token)match(input,112,FOLLOW_112_in_foreach_variable1494); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_112.add(string_literal127);

                    pushFollow(FOLLOW_variable_in_foreach_variable1498);
                    v2=variable();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_variable.add(v2.getTree());


                    // AST REWRITE
                    // elements: 112, v2, foreach_variable
                    // token labels: 
                    // rule labels: retval, v2
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
                    RewriteRuleSubtreeStream stream_v2=new RewriteRuleSubtreeStream(adaptor,"rule v2",v2!=null?v2.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 247:23: -> ^( '=>' $foreach_variable $v2)
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:247:26: ^( '=>' $foreach_variable $v2)
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_112.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_retval.nextTree());
                        adaptor.addChild(root_1, stream_v2.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "foreach_variable"

    public static class use_filename_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "use_filename"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:250:1: use_filename : ( STRINGLITERAL | LEFT_PARETHESIS STRINGLITERAL RIGHT_PARETHESIS );
    public final CompilerAstParser.use_filename_return use_filename() throws RecognitionException {
        CompilerAstParser.use_filename_return retval = new CompilerAstParser.use_filename_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token STRINGLITERAL128=null;
        Token LEFT_PARETHESIS129=null;
        Token STRINGLITERAL130=null;
        Token RIGHT_PARETHESIS131=null;

        SLAST STRINGLITERAL128_tree=null;
        SLAST LEFT_PARETHESIS129_tree=null;
        SLAST STRINGLITERAL130_tree=null;
        SLAST RIGHT_PARETHESIS131_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:251:3: ( STRINGLITERAL | LEFT_PARETHESIS STRINGLITERAL RIGHT_PARETHESIS )
            int alt31=2;
            int LA31_0 = input.LA(1);

            if ( (LA31_0==STRINGLITERAL) ) {
                alt31=1;
            }
            else if ( (LA31_0==LEFT_PARETHESIS) ) {
                alt31=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 31, 0, input);

                throw nvae;
            }
            switch (alt31) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:251:5: STRINGLITERAL
                    {
                    root_0 = (SLAST)adaptor.nil();

                    STRINGLITERAL128=(Token)match(input,STRINGLITERAL,FOLLOW_STRINGLITERAL_in_use_filename1527); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    STRINGLITERAL128_tree = (SLAST)adaptor.create(STRINGLITERAL128);
                    adaptor.addChild(root_0, STRINGLITERAL128_tree);
                    }

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:252:5: LEFT_PARETHESIS STRINGLITERAL RIGHT_PARETHESIS
                    {
                    root_0 = (SLAST)adaptor.nil();

                    LEFT_PARETHESIS129=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_use_filename1533); if (state.failed) return retval;
                    STRINGLITERAL130=(Token)match(input,STRINGLITERAL,FOLLOW_STRINGLITERAL_in_use_filename1536); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    STRINGLITERAL130_tree = (SLAST)adaptor.create(STRINGLITERAL130);
                    adaptor.addChild(root_0, STRINGLITERAL130_tree);
                    }
                    RIGHT_PARETHESIS131=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_use_filename1538); if (state.failed) return retval;

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "use_filename"

    public static class method_declaration_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "method_declaration"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:255:1: method_declaration : 'function' ( '&' )? IDENTIFIER LEFT_PARETHESIS ( parameter_list )? RIGHT_PARETHESIS ( ';' -> ^( 'function' ( '&' )? IDENTIFIER ( parameter_list )? EMPTYSTATEMENT ) | block -> ^( 'function' ( '&' )? IDENTIFIER ( parameter_list )? block ) ) ;
    public final CompilerAstParser.method_declaration_return method_declaration() throws RecognitionException {
        CompilerAstParser.method_declaration_return retval = new CompilerAstParser.method_declaration_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token string_literal132=null;
        Token char_literal133=null;
        Token IDENTIFIER134=null;
        Token LEFT_PARETHESIS135=null;
        Token RIGHT_PARETHESIS137=null;
        Token char_literal138=null;
        CompilerAstParser.parameter_list_return parameter_list136 = null;

        CompilerAstParser.block_return block139 = null;


        SLAST string_literal132_tree=null;
        SLAST char_literal133_tree=null;
        SLAST IDENTIFIER134_tree=null;
        SLAST LEFT_PARETHESIS135_tree=null;
        SLAST RIGHT_PARETHESIS137_tree=null;
        SLAST char_literal138_tree=null;
        RewriteRuleTokenStream stream_95=new RewriteRuleTokenStream(adaptor,"token 95");
        RewriteRuleTokenStream stream_LEFT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token LEFT_PARETHESIS");
        RewriteRuleTokenStream stream_BIT_AND=new RewriteRuleTokenStream(adaptor,"token BIT_AND");
        RewriteRuleTokenStream stream_IDENTIFIER=new RewriteRuleTokenStream(adaptor,"token IDENTIFIER");
        RewriteRuleTokenStream stream_RIGHT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token RIGHT_PARETHESIS");
        RewriteRuleTokenStream stream_89=new RewriteRuleTokenStream(adaptor,"token 89");
        RewriteRuleSubtreeStream stream_block=new RewriteRuleSubtreeStream(adaptor,"rule block");
        RewriteRuleSubtreeStream stream_parameter_list=new RewriteRuleSubtreeStream(adaptor,"rule parameter_list");
        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:256:3: ( 'function' ( '&' )? IDENTIFIER LEFT_PARETHESIS ( parameter_list )? RIGHT_PARETHESIS ( ';' -> ^( 'function' ( '&' )? IDENTIFIER ( parameter_list )? EMPTYSTATEMENT ) | block -> ^( 'function' ( '&' )? IDENTIFIER ( parameter_list )? block ) ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:256:5: 'function' ( '&' )? IDENTIFIER LEFT_PARETHESIS ( parameter_list )? RIGHT_PARETHESIS ( ';' -> ^( 'function' ( '&' )? IDENTIFIER ( parameter_list )? EMPTYSTATEMENT ) | block -> ^( 'function' ( '&' )? IDENTIFIER ( parameter_list )? block ) )
            {
            string_literal132=(Token)match(input,95,FOLLOW_95_in_method_declaration1554); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_95.add(string_literal132);

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:256:16: ( '&' )?
            int alt32=2;
            int LA32_0 = input.LA(1);

            if ( (LA32_0==BIT_AND) ) {
                alt32=1;
            }
            switch (alt32) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:256:16: '&'
                    {
                    char_literal133=(Token)match(input,BIT_AND,FOLLOW_BIT_AND_in_method_declaration1556); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_BIT_AND.add(char_literal133);


                    }
                    break;

            }

            IDENTIFIER134=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_method_declaration1559); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER134);

            LEFT_PARETHESIS135=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_method_declaration1561); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS135);

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:256:48: ( parameter_list )?
            int alt33=2;
            int LA33_0 = input.LA(1);

            if ( (LA33_0==IDENTIFIER||LA33_0==BIT_AND||LA33_0==DOLLAR_T||LA33_0==113||(LA33_0>=153 && LA33_0<=163)) ) {
                alt33=1;
            }
            switch (alt33) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:256:48: parameter_list
                    {
                    pushFollow(FOLLOW_parameter_list_in_method_declaration1563);
                    parameter_list136=parameter_list();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_parameter_list.add(parameter_list136.getTree());

                    }
                    break;

            }

            RIGHT_PARETHESIS137=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_method_declaration1566); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS137);

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:257:5: ( ';' -> ^( 'function' ( '&' )? IDENTIFIER ( parameter_list )? EMPTYSTATEMENT ) | block -> ^( 'function' ( '&' )? IDENTIFIER ( parameter_list )? block ) )
            int alt34=2;
            int LA34_0 = input.LA(1);

            if ( (LA34_0==89) ) {
                alt34=1;
            }
            else if ( (LA34_0==LEFT_BRACKET) ) {
                alt34=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 34, 0, input);

                throw nvae;
            }
            switch (alt34) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:258:5: ';'
                    {
                    char_literal138=(Token)match(input,89,FOLLOW_89_in_method_declaration1579); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_89.add(char_literal138);



                    // AST REWRITE
                    // elements: BIT_AND, parameter_list, IDENTIFIER, 95
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 258:11: -> ^( 'function' ( '&' )? IDENTIFIER ( parameter_list )? EMPTYSTATEMENT )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:258:15: ^( 'function' ( '&' )? IDENTIFIER ( parameter_list )? EMPTYSTATEMENT )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_95.nextNode(), root_1);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:258:28: ( '&' )?
                        if ( stream_BIT_AND.hasNext() ) {
                            adaptor.addChild(root_1, stream_BIT_AND.nextNode());

                        }
                        stream_BIT_AND.reset();
                        adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:258:44: ( parameter_list )?
                        if ( stream_parameter_list.hasNext() ) {
                            adaptor.addChild(root_1, stream_parameter_list.nextTree());

                        }
                        stream_parameter_list.reset();
                        adaptor.addChild(root_1, (SLAST)adaptor.create(EMPTYSTATEMENT, "EMPTYSTATEMENT"));

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:260:5: block
                    {
                    pushFollow(FOLLOW_block_in_method_declaration1610);
                    block139=block();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_block.add(block139.getTree());


                    // AST REWRITE
                    // elements: parameter_list, IDENTIFIER, block, 95, BIT_AND
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 260:11: -> ^( 'function' ( '&' )? IDENTIFIER ( parameter_list )? block )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:260:15: ^( 'function' ( '&' )? IDENTIFIER ( parameter_list )? block )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_95.nextNode(), root_1);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:260:28: ( '&' )?
                        if ( stream_BIT_AND.hasNext() ) {
                            adaptor.addChild(root_1, stream_BIT_AND.nextNode());

                        }
                        stream_BIT_AND.reset();
                        adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:260:44: ( parameter_list )?
                        if ( stream_parameter_list.hasNext() ) {
                            adaptor.addChild(root_1, stream_parameter_list.nextTree());

                        }
                        stream_parameter_list.reset();
                        adaptor.addChild(root_1, stream_block.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "method_declaration"

    public static class class_constant_declaration_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "class_constant_declaration"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:265:1: class_constant_declaration : 'const' directive -> ^( VAR_DECL 'const' directive ) ;
    public final CompilerAstParser.class_constant_declaration_return class_constant_declaration() throws RecognitionException {
        CompilerAstParser.class_constant_declaration_return retval = new CompilerAstParser.class_constant_declaration_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token string_literal140=null;
        CompilerAstParser.directive_return directive141 = null;


        SLAST string_literal140_tree=null;
        RewriteRuleTokenStream stream_113=new RewriteRuleTokenStream(adaptor,"token 113");
        RewriteRuleSubtreeStream stream_directive=new RewriteRuleSubtreeStream(adaptor,"rule directive");
        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:266:3: ( 'const' directive -> ^( VAR_DECL 'const' directive ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:266:5: 'const' directive
            {
            string_literal140=(Token)match(input,113,FOLLOW_113_in_class_constant_declaration1654); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_113.add(string_literal140);

            pushFollow(FOLLOW_directive_in_class_constant_declaration1656);
            directive141=directive();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_directive.add(directive141.getTree());


            // AST REWRITE
            // elements: directive, 113
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 267:5: -> ^( VAR_DECL 'const' directive )
            {
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:267:9: ^( VAR_DECL 'const' directive )
                {
                SLAST root_1 = (SLAST)adaptor.nil();
                root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(VAR_DECL, "VAR_DECL"), root_1);

                adaptor.addChild(root_1, stream_113.nextNode());
                adaptor.addChild(root_1, stream_directive.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "class_constant_declaration"

    public static class fully_qualified_class_name_list_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "fully_qualified_class_name_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:270:1: fully_qualified_class_name_list : fully_qualified_class_name ( ',' fully_qualified_class_name )* -> ( fully_qualified_class_name )+ ;
    public final CompilerAstParser.fully_qualified_class_name_list_return fully_qualified_class_name_list() throws RecognitionException {
        CompilerAstParser.fully_qualified_class_name_list_return retval = new CompilerAstParser.fully_qualified_class_name_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token char_literal143=null;
        CompilerAstParser.fully_qualified_class_name_return fully_qualified_class_name142 = null;

        CompilerAstParser.fully_qualified_class_name_return fully_qualified_class_name144 = null;


        SLAST char_literal143_tree=null;
        RewriteRuleTokenStream stream_114=new RewriteRuleTokenStream(adaptor,"token 114");
        RewriteRuleSubtreeStream stream_fully_qualified_class_name=new RewriteRuleSubtreeStream(adaptor,"rule fully_qualified_class_name");
        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:271:3: ( fully_qualified_class_name ( ',' fully_qualified_class_name )* -> ( fully_qualified_class_name )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:271:5: fully_qualified_class_name ( ',' fully_qualified_class_name )*
            {
            pushFollow(FOLLOW_fully_qualified_class_name_in_fully_qualified_class_name_list1684);
            fully_qualified_class_name142=fully_qualified_class_name();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_fully_qualified_class_name.add(fully_qualified_class_name142.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:271:32: ( ',' fully_qualified_class_name )*
            loop35:
            do {
                int alt35=2;
                int LA35_0 = input.LA(1);

                if ( (LA35_0==114) ) {
                    alt35=1;
                }


                switch (alt35) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:271:33: ',' fully_qualified_class_name
            	    {
            	    char_literal143=(Token)match(input,114,FOLLOW_114_in_fully_qualified_class_name_list1687); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_114.add(char_literal143);

            	    pushFollow(FOLLOW_fully_qualified_class_name_in_fully_qualified_class_name_list1689);
            	    fully_qualified_class_name144=fully_qualified_class_name();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_fully_qualified_class_name.add(fully_qualified_class_name144.getTree());

            	    }
            	    break;

            	default :
            	    break loop35;
                }
            } while (true);



            // AST REWRITE
            // elements: fully_qualified_class_name
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 271:69: -> ( fully_qualified_class_name )+
            {
                if ( !(stream_fully_qualified_class_name.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_fully_qualified_class_name.hasNext() ) {
                    adaptor.addChild(root_0, stream_fully_qualified_class_name.nextTree());

                }
                stream_fully_qualified_class_name.reset();

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "fully_qualified_class_name_list"

    public static class fully_qualified_class_name_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "fully_qualified_class_name"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:274:1: fully_qualified_class_name : IDENTIFIER ( '::' IDENTIFIER )* ( '::' )? ;
    public final CompilerAstParser.fully_qualified_class_name_return fully_qualified_class_name() throws RecognitionException {
        CompilerAstParser.fully_qualified_class_name_return retval = new CompilerAstParser.fully_qualified_class_name_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token IDENTIFIER145=null;
        Token string_literal146=null;
        Token IDENTIFIER147=null;
        Token string_literal148=null;

        SLAST IDENTIFIER145_tree=null;
        SLAST string_literal146_tree=null;
        SLAST IDENTIFIER147_tree=null;
        SLAST string_literal148_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:275:3: ( IDENTIFIER ( '::' IDENTIFIER )* ( '::' )? )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:275:5: IDENTIFIER ( '::' IDENTIFIER )* ( '::' )?
            {
            root_0 = (SLAST)adaptor.nil();

            IDENTIFIER145=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_fully_qualified_class_name1713); if (state.failed) return retval;
            if ( state.backtracking==0 ) {
            IDENTIFIER145_tree = (SLAST)adaptor.create(IDENTIFIER145);
            adaptor.addChild(root_0, IDENTIFIER145_tree);
            }
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:275:16: ( '::' IDENTIFIER )*
            loop36:
            do {
                int alt36=2;
                int LA36_0 = input.LA(1);

                if ( (LA36_0==115) ) {
                    int LA36_1 = input.LA(2);

                    if ( (LA36_1==IDENTIFIER) ) {
                        alt36=1;
                    }


                }


                switch (alt36) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:275:17: '::' IDENTIFIER
            	    {
            	    string_literal146=(Token)match(input,115,FOLLOW_115_in_fully_qualified_class_name1716); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    string_literal146_tree = (SLAST)adaptor.create(string_literal146);
            	    root_0 = (SLAST)adaptor.becomeRoot(string_literal146_tree, root_0);
            	    }
            	    IDENTIFIER147=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_fully_qualified_class_name1719); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    IDENTIFIER147_tree = (SLAST)adaptor.create(IDENTIFIER147);
            	    adaptor.addChild(root_0, IDENTIFIER147_tree);
            	    }

            	    }
            	    break;

            	default :
            	    break loop36;
                }
            } while (true);

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:275:36: ( '::' )?
            int alt37=2;
            int LA37_0 = input.LA(1);

            if ( (LA37_0==115) ) {
                alt37=1;
            }
            switch (alt37) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:275:36: '::'
                    {
                    string_literal148=(Token)match(input,115,FOLLOW_115_in_fully_qualified_class_name1723); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    string_literal148_tree = (SLAST)adaptor.create(string_literal148);
                    adaptor.addChild(root_0, string_literal148_tree);
                    }

                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "fully_qualified_class_name"

    public static class static_array_pair_list_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "static_array_pair_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:278:1: static_array_pair_list : static_scalar_element ( ',' static_scalar_element )* -> ( ^( SCALAR_ELEMENT static_scalar_element ) )+ ;
    public final CompilerAstParser.static_array_pair_list_return static_array_pair_list() throws RecognitionException {
        CompilerAstParser.static_array_pair_list_return retval = new CompilerAstParser.static_array_pair_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token char_literal150=null;
        CompilerAstParser.static_scalar_element_return static_scalar_element149 = null;

        CompilerAstParser.static_scalar_element_return static_scalar_element151 = null;


        SLAST char_literal150_tree=null;
        RewriteRuleTokenStream stream_114=new RewriteRuleTokenStream(adaptor,"token 114");
        RewriteRuleSubtreeStream stream_static_scalar_element=new RewriteRuleSubtreeStream(adaptor,"rule static_scalar_element");
        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:279:3: ( static_scalar_element ( ',' static_scalar_element )* -> ( ^( SCALAR_ELEMENT static_scalar_element ) )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:279:5: static_scalar_element ( ',' static_scalar_element )*
            {
            pushFollow(FOLLOW_static_scalar_element_in_static_array_pair_list1740);
            static_scalar_element149=static_scalar_element();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_static_scalar_element.add(static_scalar_element149.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:279:27: ( ',' static_scalar_element )*
            loop38:
            do {
                int alt38=2;
                int LA38_0 = input.LA(1);

                if ( (LA38_0==114) ) {
                    alt38=1;
                }


                switch (alt38) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:279:28: ',' static_scalar_element
            	    {
            	    char_literal150=(Token)match(input,114,FOLLOW_114_in_static_array_pair_list1743); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_114.add(char_literal150);

            	    pushFollow(FOLLOW_static_scalar_element_in_static_array_pair_list1745);
            	    static_scalar_element151=static_scalar_element();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_static_scalar_element.add(static_scalar_element151.getTree());

            	    }
            	    break;

            	default :
            	    break loop38;
                }
            } while (true);



            // AST REWRITE
            // elements: static_scalar_element
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 279:57: -> ( ^( SCALAR_ELEMENT static_scalar_element ) )+
            {
                if ( !(stream_static_scalar_element.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_static_scalar_element.hasNext() ) {
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:279:61: ^( SCALAR_ELEMENT static_scalar_element )
                    {
                    SLAST root_1 = (SLAST)adaptor.nil();
                    root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(SCALAR_ELEMENT, "SCALAR_ELEMENT"), root_1);

                    adaptor.addChild(root_1, stream_static_scalar_element.nextTree());

                    adaptor.addChild(root_0, root_1);
                    }

                }
                stream_static_scalar_element.reset();

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "static_array_pair_list"

    public static class static_scalar_element_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "static_scalar_element"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:282:1: static_scalar_element : scalar ( '=>' scalar )? ;
    public final CompilerAstParser.static_scalar_element_return static_scalar_element() throws RecognitionException {
        CompilerAstParser.static_scalar_element_return retval = new CompilerAstParser.static_scalar_element_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token string_literal153=null;
        CompilerAstParser.scalar_return scalar152 = null;

        CompilerAstParser.scalar_return scalar154 = null;


        SLAST string_literal153_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:283:3: ( scalar ( '=>' scalar )? )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:283:5: scalar ( '=>' scalar )?
            {
            root_0 = (SLAST)adaptor.nil();

            pushFollow(FOLLOW_scalar_in_static_scalar_element1772);
            scalar152=scalar();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, scalar152.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:283:12: ( '=>' scalar )?
            int alt39=2;
            int LA39_0 = input.LA(1);

            if ( (LA39_0==112) ) {
                alt39=1;
            }
            switch (alt39) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:283:13: '=>' scalar
                    {
                    string_literal153=(Token)match(input,112,FOLLOW_112_in_static_scalar_element1775); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    string_literal153_tree = (SLAST)adaptor.create(string_literal153);
                    root_0 = (SLAST)adaptor.becomeRoot(string_literal153_tree, root_0);
                    }
                    pushFollow(FOLLOW_scalar_in_static_scalar_element1778);
                    scalar154=scalar();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, scalar154.getTree());

                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "static_scalar_element"

    public static class static_var_list_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "static_var_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:286:1: static_var_list : static_var_element ( ',' static_var_element )* -> ( ^( SCALAR_VAR static_var_element ) )+ ;
    public final CompilerAstParser.static_var_list_return static_var_list() throws RecognitionException {
        CompilerAstParser.static_var_list_return retval = new CompilerAstParser.static_var_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token char_literal156=null;
        CompilerAstParser.static_var_element_return static_var_element155 = null;

        CompilerAstParser.static_var_element_return static_var_element157 = null;


        SLAST char_literal156_tree=null;
        RewriteRuleTokenStream stream_114=new RewriteRuleTokenStream(adaptor,"token 114");
        RewriteRuleSubtreeStream stream_static_var_element=new RewriteRuleSubtreeStream(adaptor,"rule static_var_element");
        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:287:3: ( static_var_element ( ',' static_var_element )* -> ( ^( SCALAR_VAR static_var_element ) )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:287:5: static_var_element ( ',' static_var_element )*
            {
            pushFollow(FOLLOW_static_var_element_in_static_var_list1795);
            static_var_element155=static_var_element();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_static_var_element.add(static_var_element155.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:287:24: ( ',' static_var_element )*
            loop40:
            do {
                int alt40=2;
                int LA40_0 = input.LA(1);

                if ( (LA40_0==114) ) {
                    alt40=1;
                }


                switch (alt40) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:287:25: ',' static_var_element
            	    {
            	    char_literal156=(Token)match(input,114,FOLLOW_114_in_static_var_list1798); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_114.add(char_literal156);

            	    pushFollow(FOLLOW_static_var_element_in_static_var_list1800);
            	    static_var_element157=static_var_element();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_static_var_element.add(static_var_element157.getTree());

            	    }
            	    break;

            	default :
            	    break loop40;
                }
            } while (true);



            // AST REWRITE
            // elements: static_var_element
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 287:51: -> ( ^( SCALAR_VAR static_var_element ) )+
            {
                if ( !(stream_static_var_element.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_static_var_element.hasNext() ) {
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:287:55: ^( SCALAR_VAR static_var_element )
                    {
                    SLAST root_1 = (SLAST)adaptor.nil();
                    root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(SCALAR_VAR, "SCALAR_VAR"), root_1);

                    adaptor.addChild(root_1, stream_static_var_element.nextTree());

                    adaptor.addChild(root_0, root_1);
                    }

                }
                stream_static_var_element.reset();

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "static_var_list"

    public static class static_var_element_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "static_var_element"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:290:1: static_var_element : pure_variable ( '=' scalar )? ;
    public final CompilerAstParser.static_var_element_return static_var_element() throws RecognitionException {
        CompilerAstParser.static_var_element_return retval = new CompilerAstParser.static_var_element_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token char_literal159=null;
        CompilerAstParser.pure_variable_return pure_variable158 = null;

        CompilerAstParser.scalar_return scalar160 = null;


        SLAST char_literal159_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:291:3: ( pure_variable ( '=' scalar )? )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:291:5: pure_variable ( '=' scalar )?
            {
            root_0 = (SLAST)adaptor.nil();

            pushFollow(FOLLOW_pure_variable_in_static_var_element1826);
            pure_variable158=pure_variable();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, pure_variable158.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:291:19: ( '=' scalar )?
            int alt41=2;
            int LA41_0 = input.LA(1);

            if ( (LA41_0==EQ) ) {
                alt41=1;
            }
            switch (alt41) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:291:20: '=' scalar
                    {
                    char_literal159=(Token)match(input,EQ,FOLLOW_EQ_in_static_var_element1829); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    char_literal159_tree = (SLAST)adaptor.create(char_literal159);
                    root_0 = (SLAST)adaptor.becomeRoot(char_literal159_tree, root_0);
                    }
                    pushFollow(FOLLOW_scalar_in_static_var_element1832);
                    scalar160=scalar();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, scalar160.getTree());

                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "static_var_element"

    public static class if_stat_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "if_stat"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:294:1: if_stat : 'if' LEFT_PARETHESIS eIfCond= expression RIGHT_PARETHESIS (s1= statement ( options {k=1; backtrack=true; } : 'elseif' LEFT_PARETHESIS eElseCond= expression RIGHT_PARETHESIS s2= statement )* ( options {k=1; backtrack=true; } : 'else' s3= statement )? -> ^( 'if' ^( CONDITION $eIfCond) $s1 ( ^( 'elseif' ^( CONDITION $eElseCond) $s2) )* ( ^( 'else' $s3) )? ) | ':' ( inner_statement_list )? ( new_elseif_branch )* ( options {k=1; backtrack=true; } : 'else' ':' s4= statement )? 'endif' ';' -> ^( 'if' ^( CONDITION $eIfCond) ( inner_statement_list )? ( new_elseif_branch )* ( ^( 'else' $s4) )? ) ) ;
    public final CompilerAstParser.if_stat_return if_stat() throws RecognitionException {
        CompilerAstParser.if_stat_return retval = new CompilerAstParser.if_stat_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token string_literal161=null;
        Token LEFT_PARETHESIS162=null;
        Token RIGHT_PARETHESIS163=null;
        Token string_literal164=null;
        Token LEFT_PARETHESIS165=null;
        Token RIGHT_PARETHESIS166=null;
        Token string_literal167=null;
        Token char_literal168=null;
        Token string_literal171=null;
        Token char_literal172=null;
        Token string_literal173=null;
        Token char_literal174=null;
        CompilerAstParser.expression_return eIfCond = null;

        CompilerAstParser.statement_return s1 = null;

        CompilerAstParser.expression_return eElseCond = null;

        CompilerAstParser.statement_return s2 = null;

        CompilerAstParser.statement_return s3 = null;

        CompilerAstParser.statement_return s4 = null;

        CompilerAstParser.inner_statement_list_return inner_statement_list169 = null;

        CompilerAstParser.new_elseif_branch_return new_elseif_branch170 = null;


        SLAST string_literal161_tree=null;
        SLAST LEFT_PARETHESIS162_tree=null;
        SLAST RIGHT_PARETHESIS163_tree=null;
        SLAST string_literal164_tree=null;
        SLAST LEFT_PARETHESIS165_tree=null;
        SLAST RIGHT_PARETHESIS166_tree=null;
        SLAST string_literal167_tree=null;
        SLAST char_literal168_tree=null;
        SLAST string_literal171_tree=null;
        SLAST char_literal172_tree=null;
        SLAST string_literal173_tree=null;
        SLAST char_literal174_tree=null;
        RewriteRuleTokenStream stream_116=new RewriteRuleTokenStream(adaptor,"token 116");
        RewriteRuleTokenStream stream_117=new RewriteRuleTokenStream(adaptor,"token 117");
        RewriteRuleTokenStream stream_LEFT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token LEFT_PARETHESIS");
        RewriteRuleTokenStream stream_120=new RewriteRuleTokenStream(adaptor,"token 120");
        RewriteRuleTokenStream stream_118=new RewriteRuleTokenStream(adaptor,"token 118");
        RewriteRuleTokenStream stream_RIGHT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token RIGHT_PARETHESIS");
        RewriteRuleTokenStream stream_119=new RewriteRuleTokenStream(adaptor,"token 119");
        RewriteRuleTokenStream stream_89=new RewriteRuleTokenStream(adaptor,"token 89");
        RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");
        RewriteRuleSubtreeStream stream_statement=new RewriteRuleSubtreeStream(adaptor,"rule statement");
        RewriteRuleSubtreeStream stream_inner_statement_list=new RewriteRuleSubtreeStream(adaptor,"rule inner_statement_list");
        RewriteRuleSubtreeStream stream_new_elseif_branch=new RewriteRuleSubtreeStream(adaptor,"rule new_elseif_branch");
        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:295:3: ( 'if' LEFT_PARETHESIS eIfCond= expression RIGHT_PARETHESIS (s1= statement ( options {k=1; backtrack=true; } : 'elseif' LEFT_PARETHESIS eElseCond= expression RIGHT_PARETHESIS s2= statement )* ( options {k=1; backtrack=true; } : 'else' s3= statement )? -> ^( 'if' ^( CONDITION $eIfCond) $s1 ( ^( 'elseif' ^( CONDITION $eElseCond) $s2) )* ( ^( 'else' $s3) )? ) | ':' ( inner_statement_list )? ( new_elseif_branch )* ( options {k=1; backtrack=true; } : 'else' ':' s4= statement )? 'endif' ';' -> ^( 'if' ^( CONDITION $eIfCond) ( inner_statement_list )? ( new_elseif_branch )* ( ^( 'else' $s4) )? ) ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:295:5: 'if' LEFT_PARETHESIS eIfCond= expression RIGHT_PARETHESIS (s1= statement ( options {k=1; backtrack=true; } : 'elseif' LEFT_PARETHESIS eElseCond= expression RIGHT_PARETHESIS s2= statement )* ( options {k=1; backtrack=true; } : 'else' s3= statement )? -> ^( 'if' ^( CONDITION $eIfCond) $s1 ( ^( 'elseif' ^( CONDITION $eElseCond) $s2) )* ( ^( 'else' $s3) )? ) | ':' ( inner_statement_list )? ( new_elseif_branch )* ( options {k=1; backtrack=true; } : 'else' ':' s4= statement )? 'endif' ';' -> ^( 'if' ^( CONDITION $eIfCond) ( inner_statement_list )? ( new_elseif_branch )* ( ^( 'else' $s4) )? ) )
            {
            string_literal161=(Token)match(input,116,FOLLOW_116_in_if_stat1849); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_116.add(string_literal161);

            LEFT_PARETHESIS162=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_if_stat1851); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS162);

            pushFollow(FOLLOW_expression_in_if_stat1855);
            eIfCond=expression();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_expression.add(eIfCond.getTree());
            RIGHT_PARETHESIS163=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_if_stat1857); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS163);

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:296:5: (s1= statement ( options {k=1; backtrack=true; } : 'elseif' LEFT_PARETHESIS eElseCond= expression RIGHT_PARETHESIS s2= statement )* ( options {k=1; backtrack=true; } : 'else' s3= statement )? -> ^( 'if' ^( CONDITION $eIfCond) $s1 ( ^( 'elseif' ^( CONDITION $eElseCond) $s2) )* ( ^( 'else' $s3) )? ) | ':' ( inner_statement_list )? ( new_elseif_branch )* ( options {k=1; backtrack=true; } : 'else' ':' s4= statement )? 'endif' ';' -> ^( 'if' ^( CONDITION $eIfCond) ( inner_statement_list )? ( new_elseif_branch )* ( ^( 'else' $s4) )? ) )
            int alt47=2;
            int LA47_0 = input.LA(1);

            if ( (LA47_0==LEFT_PARETHESIS||(LA47_0>=IDENTIFIER && LA47_0<=LEFT_BRACKET)||LA47_0==STRINGLITERAL||(LA47_0>=BIT_AND && LA47_0<=MINUS_T)||(LA47_0>=TILDA_T && LA47_0<=BACKTRICKLITERAL)||(LA47_0>=DOLLAR_T && LA47_0<=DOUBLELITERRAL)||LA47_0==89||(LA47_0>=95 && LA47_0<=106)||(LA47_0>=108 && LA47_0<=111)||LA47_0==116||(LA47_0>=160 && LA47_0<=161)||(LA47_0>=163 && LA47_0<=166)||(LA47_0>=168 && LA47_0<=171)||(LA47_0>=173 && LA47_0<=178)) ) {
                alt47=1;
            }
            else if ( (LA47_0==119) ) {
                alt47=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 47, 0, input);

                throw nvae;
            }
            switch (alt47) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:297:7: s1= statement ( options {k=1; backtrack=true; } : 'elseif' LEFT_PARETHESIS eElseCond= expression RIGHT_PARETHESIS s2= statement )* ( options {k=1; backtrack=true; } : 'else' s3= statement )?
                    {
                    pushFollow(FOLLOW_statement_in_if_stat1873);
                    s1=statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_statement.add(s1.getTree());
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:297:20: ( options {k=1; backtrack=true; } : 'elseif' LEFT_PARETHESIS eElseCond= expression RIGHT_PARETHESIS s2= statement )*
                    loop42:
                    do {
                        int alt42=2;
                        alt42 = dfa42.predict(input);
                        switch (alt42) {
                    	case 1 :
                    	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:297:53: 'elseif' LEFT_PARETHESIS eElseCond= expression RIGHT_PARETHESIS s2= statement
                    	    {
                    	    string_literal164=(Token)match(input,117,FOLLOW_117_in_if_stat1889); if (state.failed) return retval; 
                    	    if ( state.backtracking==0 ) stream_117.add(string_literal164);

                    	    LEFT_PARETHESIS165=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_if_stat1891); if (state.failed) return retval; 
                    	    if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS165);

                    	    pushFollow(FOLLOW_expression_in_if_stat1895);
                    	    eElseCond=expression();

                    	    state._fsp--;
                    	    if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) stream_expression.add(eElseCond.getTree());
                    	    RIGHT_PARETHESIS166=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_if_stat1897); if (state.failed) return retval; 
                    	    if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS166);

                    	    pushFollow(FOLLOW_statement_in_if_stat1901);
                    	    s2=statement();

                    	    state._fsp--;
                    	    if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) stream_statement.add(s2.getTree());

                    	    }
                    	    break;

                    	default :
                    	    break loop42;
                        }
                    } while (true);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:298:9: ( options {k=1; backtrack=true; } : 'else' s3= statement )?
                    int alt43=2;
                    alt43 = dfa43.predict(input);
                    switch (alt43) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:298:42: 'else' s3= statement
                            {
                            string_literal167=(Token)match(input,118,FOLLOW_118_in_if_stat1927); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_118.add(string_literal167);

                            pushFollow(FOLLOW_statement_in_if_stat1931);
                            s3=statement();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_statement.add(s3.getTree());

                            }
                            break;

                    }



                    // AST REWRITE
                    // elements: 117, s1, s3, 118, s2, eIfCond, eElseCond, 116
                    // token labels: 
                    // rule labels: retval, s2, s1, eIfCond, eElseCond, s3
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
                    RewriteRuleSubtreeStream stream_s2=new RewriteRuleSubtreeStream(adaptor,"rule s2",s2!=null?s2.tree:null);
                    RewriteRuleSubtreeStream stream_s1=new RewriteRuleSubtreeStream(adaptor,"rule s1",s1!=null?s1.tree:null);
                    RewriteRuleSubtreeStream stream_eIfCond=new RewriteRuleSubtreeStream(adaptor,"rule eIfCond",eIfCond!=null?eIfCond.tree:null);
                    RewriteRuleSubtreeStream stream_eElseCond=new RewriteRuleSubtreeStream(adaptor,"rule eElseCond",eElseCond!=null?eElseCond.tree:null);
                    RewriteRuleSubtreeStream stream_s3=new RewriteRuleSubtreeStream(adaptor,"rule s3",s3!=null?s3.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 299:7: -> ^( 'if' ^( CONDITION $eIfCond) $s1 ( ^( 'elseif' ^( CONDITION $eElseCond) $s2) )* ( ^( 'else' $s3) )? )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:299:11: ^( 'if' ^( CONDITION $eIfCond) $s1 ( ^( 'elseif' ^( CONDITION $eElseCond) $s2) )* ( ^( 'else' $s3) )? )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_116.nextNode(), root_1);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:299:18: ^( CONDITION $eIfCond)
                        {
                        SLAST root_2 = (SLAST)adaptor.nil();
                        root_2 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(CONDITION, "CONDITION"), root_2);

                        adaptor.addChild(root_2, stream_eIfCond.nextTree());

                        adaptor.addChild(root_1, root_2);
                        }
                        adaptor.addChild(root_1, stream_s1.nextTree());
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:299:45: ( ^( 'elseif' ^( CONDITION $eElseCond) $s2) )*
                        while ( stream_117.hasNext()||stream_s2.hasNext()||stream_eElseCond.hasNext() ) {
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:299:45: ^( 'elseif' ^( CONDITION $eElseCond) $s2)
                            {
                            SLAST root_2 = (SLAST)adaptor.nil();
                            root_2 = (SLAST)adaptor.becomeRoot(stream_117.nextNode(), root_2);

                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:299:56: ^( CONDITION $eElseCond)
                            {
                            SLAST root_3 = (SLAST)adaptor.nil();
                            root_3 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(CONDITION, "CONDITION"), root_3);

                            adaptor.addChild(root_3, stream_eElseCond.nextTree());

                            adaptor.addChild(root_2, root_3);
                            }
                            adaptor.addChild(root_2, stream_s2.nextTree());

                            adaptor.addChild(root_1, root_2);
                            }

                        }
                        stream_117.reset();
                        stream_s2.reset();
                        stream_eElseCond.reset();
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:299:86: ( ^( 'else' $s3) )?
                        if ( stream_s3.hasNext()||stream_118.hasNext() ) {
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:299:86: ^( 'else' $s3)
                            {
                            SLAST root_2 = (SLAST)adaptor.nil();
                            root_2 = (SLAST)adaptor.becomeRoot(stream_118.nextNode(), root_2);

                            adaptor.addChild(root_2, stream_s3.nextTree());

                            adaptor.addChild(root_1, root_2);
                            }

                        }
                        stream_s3.reset();
                        stream_118.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:300:9: ':' ( inner_statement_list )? ( new_elseif_branch )* ( options {k=1; backtrack=true; } : 'else' ':' s4= statement )? 'endif' ';'
                    {
                    char_literal168=(Token)match(input,119,FOLLOW_119_in_if_stat1990); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_119.add(char_literal168);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:300:13: ( inner_statement_list )?
                    int alt44=2;
                    int LA44_0 = input.LA(1);

                    if ( (LA44_0==LEFT_PARETHESIS||(LA44_0>=CLASS_T && LA44_0<=LEFT_BRACKET)||LA44_0==STRINGLITERAL||(LA44_0>=BIT_AND && LA44_0<=MINUS_T)||(LA44_0>=TILDA_T && LA44_0<=BACKTRICKLITERAL)||(LA44_0>=DOLLAR_T && LA44_0<=DOUBLELITERRAL)||(LA44_0>=88 && LA44_0<=89)||(LA44_0>=92 && LA44_0<=106)||(LA44_0>=108 && LA44_0<=111)||LA44_0==116||(LA44_0>=160 && LA44_0<=161)||(LA44_0>=163 && LA44_0<=166)||(LA44_0>=168 && LA44_0<=171)||(LA44_0>=173 && LA44_0<=178)) ) {
                        alt44=1;
                    }
                    switch (alt44) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:300:13: inner_statement_list
                            {
                            pushFollow(FOLLOW_inner_statement_list_in_if_stat1992);
                            inner_statement_list169=inner_statement_list();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_inner_statement_list.add(inner_statement_list169.getTree());

                            }
                            break;

                    }

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:300:35: ( new_elseif_branch )*
                    loop45:
                    do {
                        int alt45=2;
                        int LA45_0 = input.LA(1);

                        if ( (LA45_0==117) ) {
                            alt45=1;
                        }


                        switch (alt45) {
                    	case 1 :
                    	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:300:35: new_elseif_branch
                    	    {
                    	    pushFollow(FOLLOW_new_elseif_branch_in_if_stat1995);
                    	    new_elseif_branch170=new_elseif_branch();

                    	    state._fsp--;
                    	    if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) stream_new_elseif_branch.add(new_elseif_branch170.getTree());

                    	    }
                    	    break;

                    	default :
                    	    break loop45;
                        }
                    } while (true);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:300:54: ( options {k=1; backtrack=true; } : 'else' ':' s4= statement )?
                    int alt46=2;
                    int LA46_0 = input.LA(1);

                    if ( (LA46_0==118) ) {
                        alt46=1;
                    }
                    switch (alt46) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:300:87: 'else' ':' s4= statement
                            {
                            string_literal171=(Token)match(input,118,FOLLOW_118_in_if_stat2012); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_118.add(string_literal171);

                            char_literal172=(Token)match(input,119,FOLLOW_119_in_if_stat2014); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_119.add(char_literal172);

                            pushFollow(FOLLOW_statement_in_if_stat2018);
                            s4=statement();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_statement.add(s4.getTree());

                            }
                            break;

                    }

                    string_literal173=(Token)match(input,120,FOLLOW_120_in_if_stat2022); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_120.add(string_literal173);

                    char_literal174=(Token)match(input,89,FOLLOW_89_in_if_stat2024); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_89.add(char_literal174);



                    // AST REWRITE
                    // elements: s4, new_elseif_branch, inner_statement_list, 118, 116, eIfCond
                    // token labels: 
                    // rule labels: retval, eIfCond, s4
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
                    RewriteRuleSubtreeStream stream_eIfCond=new RewriteRuleSubtreeStream(adaptor,"rule eIfCond",eIfCond!=null?eIfCond.tree:null);
                    RewriteRuleSubtreeStream stream_s4=new RewriteRuleSubtreeStream(adaptor,"rule s4",s4!=null?s4.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 301:7: -> ^( 'if' ^( CONDITION $eIfCond) ( inner_statement_list )? ( new_elseif_branch )* ( ^( 'else' $s4) )? )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:301:11: ^( 'if' ^( CONDITION $eIfCond) ( inner_statement_list )? ( new_elseif_branch )* ( ^( 'else' $s4) )? )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_116.nextNode(), root_1);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:301:18: ^( CONDITION $eIfCond)
                        {
                        SLAST root_2 = (SLAST)adaptor.nil();
                        root_2 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(CONDITION, "CONDITION"), root_2);

                        adaptor.addChild(root_2, stream_eIfCond.nextTree());

                        adaptor.addChild(root_1, root_2);
                        }
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:301:40: ( inner_statement_list )?
                        if ( stream_inner_statement_list.hasNext() ) {
                            adaptor.addChild(root_1, stream_inner_statement_list.nextTree());

                        }
                        stream_inner_statement_list.reset();
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:301:62: ( new_elseif_branch )*
                        while ( stream_new_elseif_branch.hasNext() ) {
                            adaptor.addChild(root_1, stream_new_elseif_branch.nextTree());

                        }
                        stream_new_elseif_branch.reset();
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:301:81: ( ^( 'else' $s4) )?
                        if ( stream_s4.hasNext()||stream_118.hasNext() ) {
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:301:81: ^( 'else' $s4)
                            {
                            SLAST root_2 = (SLAST)adaptor.nil();
                            root_2 = (SLAST)adaptor.becomeRoot(stream_118.nextNode(), root_2);

                            adaptor.addChild(root_2, stream_s4.nextTree());

                            adaptor.addChild(root_1, root_2);
                            }

                        }
                        stream_s4.reset();
                        stream_118.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "if_stat"

    public static class new_elseif_branch_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "new_elseif_branch"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:305:1: new_elseif_branch : 'elseif' LEFT_PARETHESIS expression RIGHT_PARETHESIS ':' ( inner_statement_list )? -> ^( 'elseif' ^( CONDITION expression ) ( inner_statement_list )? ) ;
    public final CompilerAstParser.new_elseif_branch_return new_elseif_branch() throws RecognitionException {
        CompilerAstParser.new_elseif_branch_return retval = new CompilerAstParser.new_elseif_branch_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token string_literal175=null;
        Token LEFT_PARETHESIS176=null;
        Token RIGHT_PARETHESIS178=null;
        Token char_literal179=null;
        CompilerAstParser.expression_return expression177 = null;

        CompilerAstParser.inner_statement_list_return inner_statement_list180 = null;


        SLAST string_literal175_tree=null;
        SLAST LEFT_PARETHESIS176_tree=null;
        SLAST RIGHT_PARETHESIS178_tree=null;
        SLAST char_literal179_tree=null;
        RewriteRuleTokenStream stream_117=new RewriteRuleTokenStream(adaptor,"token 117");
        RewriteRuleTokenStream stream_LEFT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token LEFT_PARETHESIS");
        RewriteRuleTokenStream stream_RIGHT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token RIGHT_PARETHESIS");
        RewriteRuleTokenStream stream_119=new RewriteRuleTokenStream(adaptor,"token 119");
        RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");
        RewriteRuleSubtreeStream stream_inner_statement_list=new RewriteRuleSubtreeStream(adaptor,"rule inner_statement_list");
        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:306:2: ( 'elseif' LEFT_PARETHESIS expression RIGHT_PARETHESIS ':' ( inner_statement_list )? -> ^( 'elseif' ^( CONDITION expression ) ( inner_statement_list )? ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:306:4: 'elseif' LEFT_PARETHESIS expression RIGHT_PARETHESIS ':' ( inner_statement_list )?
            {
            string_literal175=(Token)match(input,117,FOLLOW_117_in_new_elseif_branch2078); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_117.add(string_literal175);

            LEFT_PARETHESIS176=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_new_elseif_branch2080); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS176);

            pushFollow(FOLLOW_expression_in_new_elseif_branch2082);
            expression177=expression();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_expression.add(expression177.getTree());
            RIGHT_PARETHESIS178=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_new_elseif_branch2084); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS178);

            char_literal179=(Token)match(input,119,FOLLOW_119_in_new_elseif_branch2086); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_119.add(char_literal179);

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:306:61: ( inner_statement_list )?
            int alt48=2;
            int LA48_0 = input.LA(1);

            if ( (LA48_0==LEFT_PARETHESIS||(LA48_0>=CLASS_T && LA48_0<=LEFT_BRACKET)||LA48_0==STRINGLITERAL||(LA48_0>=BIT_AND && LA48_0<=MINUS_T)||(LA48_0>=TILDA_T && LA48_0<=BACKTRICKLITERAL)||(LA48_0>=DOLLAR_T && LA48_0<=DOUBLELITERRAL)||(LA48_0>=88 && LA48_0<=89)||(LA48_0>=92 && LA48_0<=106)||(LA48_0>=108 && LA48_0<=111)||LA48_0==116||(LA48_0>=160 && LA48_0<=161)||(LA48_0>=163 && LA48_0<=166)||(LA48_0>=168 && LA48_0<=171)||(LA48_0>=173 && LA48_0<=178)) ) {
                alt48=1;
            }
            switch (alt48) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:306:61: inner_statement_list
                    {
                    pushFollow(FOLLOW_inner_statement_list_in_new_elseif_branch2088);
                    inner_statement_list180=inner_statement_list();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_inner_statement_list.add(inner_statement_list180.getTree());

                    }
                    break;

            }



            // AST REWRITE
            // elements: inner_statement_list, 117, expression
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 306:86: -> ^( 'elseif' ^( CONDITION expression ) ( inner_statement_list )? )
            {
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:306:90: ^( 'elseif' ^( CONDITION expression ) ( inner_statement_list )? )
                {
                SLAST root_1 = (SLAST)adaptor.nil();
                root_1 = (SLAST)adaptor.becomeRoot(stream_117.nextNode(), root_1);

                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:306:101: ^( CONDITION expression )
                {
                SLAST root_2 = (SLAST)adaptor.nil();
                root_2 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(CONDITION, "CONDITION"), root_2);

                adaptor.addChild(root_2, stream_expression.nextTree());

                adaptor.addChild(root_1, root_2);
                }
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:306:125: ( inner_statement_list )?
                if ( stream_inner_statement_list.hasNext() ) {
                    adaptor.addChild(root_1, stream_inner_statement_list.nextTree());

                }
                stream_inner_statement_list.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "new_elseif_branch"

    public static class switch_case_list_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "switch_case_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:309:1: switch_case_list : ( LEFT_BRACKET ( ';' )? ( case_list )+ RIGHT_BRACKET -> ( case_list )+ | ':' ( ';' )? ( case_list )+ 'endswitch' ';' -> ( case_list )+ );
    public final CompilerAstParser.switch_case_list_return switch_case_list() throws RecognitionException {
        CompilerAstParser.switch_case_list_return retval = new CompilerAstParser.switch_case_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token LEFT_BRACKET181=null;
        Token char_literal182=null;
        Token RIGHT_BRACKET184=null;
        Token char_literal185=null;
        Token char_literal186=null;
        Token string_literal188=null;
        Token char_literal189=null;
        CompilerAstParser.case_list_return case_list183 = null;

        CompilerAstParser.case_list_return case_list187 = null;


        SLAST LEFT_BRACKET181_tree=null;
        SLAST char_literal182_tree=null;
        SLAST RIGHT_BRACKET184_tree=null;
        SLAST char_literal185_tree=null;
        SLAST char_literal186_tree=null;
        SLAST string_literal188_tree=null;
        SLAST char_literal189_tree=null;
        RewriteRuleTokenStream stream_121=new RewriteRuleTokenStream(adaptor,"token 121");
        RewriteRuleTokenStream stream_LEFT_BRACKET=new RewriteRuleTokenStream(adaptor,"token LEFT_BRACKET");
        RewriteRuleTokenStream stream_119=new RewriteRuleTokenStream(adaptor,"token 119");
        RewriteRuleTokenStream stream_RIGHT_BRACKET=new RewriteRuleTokenStream(adaptor,"token RIGHT_BRACKET");
        RewriteRuleTokenStream stream_89=new RewriteRuleTokenStream(adaptor,"token 89");
        RewriteRuleSubtreeStream stream_case_list=new RewriteRuleSubtreeStream(adaptor,"rule case_list");
        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:310:3: ( LEFT_BRACKET ( ';' )? ( case_list )+ RIGHT_BRACKET -> ( case_list )+ | ':' ( ';' )? ( case_list )+ 'endswitch' ';' -> ( case_list )+ )
            int alt53=2;
            int LA53_0 = input.LA(1);

            if ( (LA53_0==LEFT_BRACKET) ) {
                alt53=1;
            }
            else if ( (LA53_0==119) ) {
                alt53=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 53, 0, input);

                throw nvae;
            }
            switch (alt53) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:310:5: LEFT_BRACKET ( ';' )? ( case_list )+ RIGHT_BRACKET
                    {
                    LEFT_BRACKET181=(Token)match(input,LEFT_BRACKET,FOLLOW_LEFT_BRACKET_in_switch_case_list2121); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LEFT_BRACKET.add(LEFT_BRACKET181);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:310:18: ( ';' )?
                    int alt49=2;
                    int LA49_0 = input.LA(1);

                    if ( (LA49_0==89) ) {
                        alt49=1;
                    }
                    switch (alt49) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:310:18: ';'
                            {
                            char_literal182=(Token)match(input,89,FOLLOW_89_in_switch_case_list2123); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_89.add(char_literal182);


                            }
                            break;

                    }

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:310:23: ( case_list )+
                    int cnt50=0;
                    loop50:
                    do {
                        int alt50=2;
                        int LA50_0 = input.LA(1);

                        if ( ((LA50_0>=122 && LA50_0<=123)) ) {
                            alt50=1;
                        }


                        switch (alt50) {
                    	case 1 :
                    	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:310:23: case_list
                    	    {
                    	    pushFollow(FOLLOW_case_list_in_switch_case_list2126);
                    	    case_list183=case_list();

                    	    state._fsp--;
                    	    if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) stream_case_list.add(case_list183.getTree());

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt50 >= 1 ) break loop50;
                    	    if (state.backtracking>0) {state.failed=true; return retval;}
                                EarlyExitException eee =
                                    new EarlyExitException(50, input);
                                throw eee;
                        }
                        cnt50++;
                    } while (true);

                    RIGHT_BRACKET184=(Token)match(input,RIGHT_BRACKET,FOLLOW_RIGHT_BRACKET_in_switch_case_list2129); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RIGHT_BRACKET.add(RIGHT_BRACKET184);



                    // AST REWRITE
                    // elements: case_list
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 310:58: -> ( case_list )+
                    {
                        if ( !(stream_case_list.hasNext()) ) {
                            throw new RewriteEarlyExitException();
                        }
                        while ( stream_case_list.hasNext() ) {
                            adaptor.addChild(root_0, stream_case_list.nextTree());

                        }
                        stream_case_list.reset();

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:311:5: ':' ( ';' )? ( case_list )+ 'endswitch' ';'
                    {
                    char_literal185=(Token)match(input,119,FOLLOW_119_in_switch_case_list2151); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_119.add(char_literal185);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:311:9: ( ';' )?
                    int alt51=2;
                    int LA51_0 = input.LA(1);

                    if ( (LA51_0==89) ) {
                        alt51=1;
                    }
                    switch (alt51) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:311:9: ';'
                            {
                            char_literal186=(Token)match(input,89,FOLLOW_89_in_switch_case_list2153); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_89.add(char_literal186);


                            }
                            break;

                    }

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:311:14: ( case_list )+
                    int cnt52=0;
                    loop52:
                    do {
                        int alt52=2;
                        int LA52_0 = input.LA(1);

                        if ( ((LA52_0>=122 && LA52_0<=123)) ) {
                            alt52=1;
                        }


                        switch (alt52) {
                    	case 1 :
                    	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:311:14: case_list
                    	    {
                    	    pushFollow(FOLLOW_case_list_in_switch_case_list2156);
                    	    case_list187=case_list();

                    	    state._fsp--;
                    	    if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) stream_case_list.add(case_list187.getTree());

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt52 >= 1 ) break loop52;
                    	    if (state.backtracking>0) {state.failed=true; return retval;}
                                EarlyExitException eee =
                                    new EarlyExitException(52, input);
                                throw eee;
                        }
                        cnt52++;
                    } while (true);

                    string_literal188=(Token)match(input,121,FOLLOW_121_in_switch_case_list2159); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_121.add(string_literal188);

                    char_literal189=(Token)match(input,89,FOLLOW_89_in_switch_case_list2161); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_89.add(char_literal189);



                    // AST REWRITE
                    // elements: case_list
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 311:45: -> ( case_list )+
                    {
                        if ( !(stream_case_list.hasNext()) ) {
                            throw new RewriteEarlyExitException();
                        }
                        while ( stream_case_list.hasNext() ) {
                            adaptor.addChild(root_0, stream_case_list.nextTree());

                        }
                        stream_case_list.reset();

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "switch_case_list"

    public static class case_list_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "case_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:314:1: case_list : ( 'case' expression ( ':' | ';' ) ( inner_statement_list )? -> ^( 'case' expression ( inner_statement_list )? ) | 'default' ( ':' | ';' ) ( inner_statement_list )? -> ^( 'default' ( inner_statement_list )? ) );
    public final CompilerAstParser.case_list_return case_list() throws RecognitionException {
        CompilerAstParser.case_list_return retval = new CompilerAstParser.case_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token string_literal190=null;
        Token char_literal192=null;
        Token char_literal193=null;
        Token string_literal195=null;
        Token char_literal196=null;
        Token char_literal197=null;
        CompilerAstParser.expression_return expression191 = null;

        CompilerAstParser.inner_statement_list_return inner_statement_list194 = null;

        CompilerAstParser.inner_statement_list_return inner_statement_list198 = null;


        SLAST string_literal190_tree=null;
        SLAST char_literal192_tree=null;
        SLAST char_literal193_tree=null;
        SLAST string_literal195_tree=null;
        SLAST char_literal196_tree=null;
        SLAST char_literal197_tree=null;
        RewriteRuleTokenStream stream_122=new RewriteRuleTokenStream(adaptor,"token 122");
        RewriteRuleTokenStream stream_123=new RewriteRuleTokenStream(adaptor,"token 123");
        RewriteRuleTokenStream stream_119=new RewriteRuleTokenStream(adaptor,"token 119");
        RewriteRuleTokenStream stream_89=new RewriteRuleTokenStream(adaptor,"token 89");
        RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");
        RewriteRuleSubtreeStream stream_inner_statement_list=new RewriteRuleSubtreeStream(adaptor,"rule inner_statement_list");
        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:315:3: ( 'case' expression ( ':' | ';' ) ( inner_statement_list )? -> ^( 'case' expression ( inner_statement_list )? ) | 'default' ( ':' | ';' ) ( inner_statement_list )? -> ^( 'default' ( inner_statement_list )? ) )
            int alt58=2;
            int LA58_0 = input.LA(1);

            if ( (LA58_0==122) ) {
                alt58=1;
            }
            else if ( (LA58_0==123) ) {
                alt58=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 58, 0, input);

                throw nvae;
            }
            switch (alt58) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:315:5: 'case' expression ( ':' | ';' ) ( inner_statement_list )?
                    {
                    string_literal190=(Token)match(input,122,FOLLOW_122_in_case_list2184); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_122.add(string_literal190);

                    pushFollow(FOLLOW_expression_in_case_list2186);
                    expression191=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_expression.add(expression191.getTree());
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:315:23: ( ':' | ';' )
                    int alt54=2;
                    int LA54_0 = input.LA(1);

                    if ( (LA54_0==119) ) {
                        alt54=1;
                    }
                    else if ( (LA54_0==89) ) {
                        alt54=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return retval;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 54, 0, input);

                        throw nvae;
                    }
                    switch (alt54) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:315:24: ':'
                            {
                            char_literal192=(Token)match(input,119,FOLLOW_119_in_case_list2189); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_119.add(char_literal192);


                            }
                            break;
                        case 2 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:315:30: ';'
                            {
                            char_literal193=(Token)match(input,89,FOLLOW_89_in_case_list2193); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_89.add(char_literal193);


                            }
                            break;

                    }

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:315:35: ( inner_statement_list )?
                    int alt55=2;
                    int LA55_0 = input.LA(1);

                    if ( (LA55_0==LEFT_PARETHESIS||(LA55_0>=CLASS_T && LA55_0<=LEFT_BRACKET)||LA55_0==STRINGLITERAL||(LA55_0>=BIT_AND && LA55_0<=MINUS_T)||(LA55_0>=TILDA_T && LA55_0<=BACKTRICKLITERAL)||(LA55_0>=DOLLAR_T && LA55_0<=DOUBLELITERRAL)||(LA55_0>=88 && LA55_0<=89)||(LA55_0>=92 && LA55_0<=106)||(LA55_0>=108 && LA55_0<=111)||LA55_0==116||(LA55_0>=160 && LA55_0<=161)||(LA55_0>=163 && LA55_0<=166)||(LA55_0>=168 && LA55_0<=171)||(LA55_0>=173 && LA55_0<=178)) ) {
                        alt55=1;
                    }
                    switch (alt55) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:315:35: inner_statement_list
                            {
                            pushFollow(FOLLOW_inner_statement_list_in_case_list2196);
                            inner_statement_list194=inner_statement_list();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_inner_statement_list.add(inner_statement_list194.getTree());

                            }
                            break;

                    }



                    // AST REWRITE
                    // elements: 122, expression, inner_statement_list
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 315:59: -> ^( 'case' expression ( inner_statement_list )? )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:315:63: ^( 'case' expression ( inner_statement_list )? )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_122.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_expression.nextTree());
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:315:83: ( inner_statement_list )?
                        if ( stream_inner_statement_list.hasNext() ) {
                            adaptor.addChild(root_1, stream_inner_statement_list.nextTree());

                        }
                        stream_inner_statement_list.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:316:5: 'default' ( ':' | ';' ) ( inner_statement_list )?
                    {
                    string_literal195=(Token)match(input,123,FOLLOW_123_in_case_list2217); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_123.add(string_literal195);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:316:15: ( ':' | ';' )
                    int alt56=2;
                    int LA56_0 = input.LA(1);

                    if ( (LA56_0==119) ) {
                        alt56=1;
                    }
                    else if ( (LA56_0==89) ) {
                        alt56=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return retval;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 56, 0, input);

                        throw nvae;
                    }
                    switch (alt56) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:316:16: ':'
                            {
                            char_literal196=(Token)match(input,119,FOLLOW_119_in_case_list2220); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_119.add(char_literal196);


                            }
                            break;
                        case 2 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:316:22: ';'
                            {
                            char_literal197=(Token)match(input,89,FOLLOW_89_in_case_list2224); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_89.add(char_literal197);


                            }
                            break;

                    }

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:316:27: ( inner_statement_list )?
                    int alt57=2;
                    int LA57_0 = input.LA(1);

                    if ( (LA57_0==LEFT_PARETHESIS||(LA57_0>=CLASS_T && LA57_0<=LEFT_BRACKET)||LA57_0==STRINGLITERAL||(LA57_0>=BIT_AND && LA57_0<=MINUS_T)||(LA57_0>=TILDA_T && LA57_0<=BACKTRICKLITERAL)||(LA57_0>=DOLLAR_T && LA57_0<=DOUBLELITERRAL)||(LA57_0>=88 && LA57_0<=89)||(LA57_0>=92 && LA57_0<=106)||(LA57_0>=108 && LA57_0<=111)||LA57_0==116||(LA57_0>=160 && LA57_0<=161)||(LA57_0>=163 && LA57_0<=166)||(LA57_0>=168 && LA57_0<=171)||(LA57_0>=173 && LA57_0<=178)) ) {
                        alt57=1;
                    }
                    switch (alt57) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:316:27: inner_statement_list
                            {
                            pushFollow(FOLLOW_inner_statement_list_in_case_list2227);
                            inner_statement_list198=inner_statement_list();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_inner_statement_list.add(inner_statement_list198.getTree());

                            }
                            break;

                    }



                    // AST REWRITE
                    // elements: inner_statement_list, 123
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 316:55: -> ^( 'default' ( inner_statement_list )? )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:316:59: ^( 'default' ( inner_statement_list )? )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_123.nextNode(), root_1);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:316:71: ( inner_statement_list )?
                        if ( stream_inner_statement_list.hasNext() ) {
                            adaptor.addChild(root_1, stream_inner_statement_list.nextTree());

                        }
                        stream_inner_statement_list.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "case_list"

    public static class catch_branch_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "catch_branch"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:319:1: catch_branch : 'catch' LEFT_PARETHESIS IDENTIFIER variable RIGHT_PARETHESIS block -> ^( 'catch' IDENTIFIER variable block ) ;
    public final CompilerAstParser.catch_branch_return catch_branch() throws RecognitionException {
        CompilerAstParser.catch_branch_return retval = new CompilerAstParser.catch_branch_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token string_literal199=null;
        Token LEFT_PARETHESIS200=null;
        Token IDENTIFIER201=null;
        Token RIGHT_PARETHESIS203=null;
        CompilerAstParser.variable_return variable202 = null;

        CompilerAstParser.block_return block204 = null;


        SLAST string_literal199_tree=null;
        SLAST LEFT_PARETHESIS200_tree=null;
        SLAST IDENTIFIER201_tree=null;
        SLAST RIGHT_PARETHESIS203_tree=null;
        RewriteRuleTokenStream stream_LEFT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token LEFT_PARETHESIS");
        RewriteRuleTokenStream stream_124=new RewriteRuleTokenStream(adaptor,"token 124");
        RewriteRuleTokenStream stream_IDENTIFIER=new RewriteRuleTokenStream(adaptor,"token IDENTIFIER");
        RewriteRuleTokenStream stream_RIGHT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token RIGHT_PARETHESIS");
        RewriteRuleSubtreeStream stream_block=new RewriteRuleSubtreeStream(adaptor,"rule block");
        RewriteRuleSubtreeStream stream_variable=new RewriteRuleSubtreeStream(adaptor,"rule variable");
        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:320:3: ( 'catch' LEFT_PARETHESIS IDENTIFIER variable RIGHT_PARETHESIS block -> ^( 'catch' IDENTIFIER variable block ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:320:5: 'catch' LEFT_PARETHESIS IDENTIFIER variable RIGHT_PARETHESIS block
            {
            string_literal199=(Token)match(input,124,FOLLOW_124_in_catch_branch2258); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_124.add(string_literal199);

            LEFT_PARETHESIS200=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_catch_branch2260); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS200);

            IDENTIFIER201=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_catch_branch2262); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER201);

            pushFollow(FOLLOW_variable_in_catch_branch2264);
            variable202=variable();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_variable.add(variable202.getTree());
            RIGHT_PARETHESIS203=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_catch_branch2266); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS203);

            pushFollow(FOLLOW_block_in_catch_branch2274);
            block204=block();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_block.add(block204.getTree());


            // AST REWRITE
            // elements: 124, IDENTIFIER, block, variable
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 322:5: -> ^( 'catch' IDENTIFIER variable block )
            {
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:322:9: ^( 'catch' IDENTIFIER variable block )
                {
                SLAST root_1 = (SLAST)adaptor.nil();
                root_1 = (SLAST)adaptor.becomeRoot(stream_124.nextNode(), root_1);

                adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());
                adaptor.addChild(root_1, stream_variable.nextTree());
                adaptor.addChild(root_1, stream_block.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "catch_branch"

    public static class for_statement_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "for_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:325:1: for_statement : ':' ( inner_statement_list )? 'endfor' ';' -> ( inner_statement_list )? ;
    public final CompilerAstParser.for_statement_return for_statement() throws RecognitionException {
        CompilerAstParser.for_statement_return retval = new CompilerAstParser.for_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token char_literal205=null;
        Token string_literal207=null;
        Token char_literal208=null;
        CompilerAstParser.inner_statement_list_return inner_statement_list206 = null;


        SLAST char_literal205_tree=null;
        SLAST string_literal207_tree=null;
        SLAST char_literal208_tree=null;
        RewriteRuleTokenStream stream_125=new RewriteRuleTokenStream(adaptor,"token 125");
        RewriteRuleTokenStream stream_119=new RewriteRuleTokenStream(adaptor,"token 119");
        RewriteRuleTokenStream stream_89=new RewriteRuleTokenStream(adaptor,"token 89");
        RewriteRuleSubtreeStream stream_inner_statement_list=new RewriteRuleSubtreeStream(adaptor,"rule inner_statement_list");
        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:326:2: ( ':' ( inner_statement_list )? 'endfor' ';' -> ( inner_statement_list )? )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:326:4: ':' ( inner_statement_list )? 'endfor' ';'
            {
            char_literal205=(Token)match(input,119,FOLLOW_119_in_for_statement2303); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_119.add(char_literal205);

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:326:8: ( inner_statement_list )?
            int alt59=2;
            int LA59_0 = input.LA(1);

            if ( (LA59_0==LEFT_PARETHESIS||(LA59_0>=CLASS_T && LA59_0<=LEFT_BRACKET)||LA59_0==STRINGLITERAL||(LA59_0>=BIT_AND && LA59_0<=MINUS_T)||(LA59_0>=TILDA_T && LA59_0<=BACKTRICKLITERAL)||(LA59_0>=DOLLAR_T && LA59_0<=DOUBLELITERRAL)||(LA59_0>=88 && LA59_0<=89)||(LA59_0>=92 && LA59_0<=106)||(LA59_0>=108 && LA59_0<=111)||LA59_0==116||(LA59_0>=160 && LA59_0<=161)||(LA59_0>=163 && LA59_0<=166)||(LA59_0>=168 && LA59_0<=171)||(LA59_0>=173 && LA59_0<=178)) ) {
                alt59=1;
            }
            switch (alt59) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:326:8: inner_statement_list
                    {
                    pushFollow(FOLLOW_inner_statement_list_in_for_statement2305);
                    inner_statement_list206=inner_statement_list();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_inner_statement_list.add(inner_statement_list206.getTree());

                    }
                    break;

            }

            string_literal207=(Token)match(input,125,FOLLOW_125_in_for_statement2308); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_125.add(string_literal207);

            char_literal208=(Token)match(input,89,FOLLOW_89_in_for_statement2310); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_89.add(char_literal208);



            // AST REWRITE
            // elements: inner_statement_list
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 326:45: -> ( inner_statement_list )?
            {
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:326:49: ( inner_statement_list )?
                if ( stream_inner_statement_list.hasNext() ) {
                    adaptor.addChild(root_0, stream_inner_statement_list.nextTree());

                }
                stream_inner_statement_list.reset();

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "for_statement"

    public static class while_statement_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "while_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:329:1: while_statement : ( statement -> statement | ':' ( inner_statement_list )? 'endwhile' ';' -> ( inner_statement_list )? );
    public final CompilerAstParser.while_statement_return while_statement() throws RecognitionException {
        CompilerAstParser.while_statement_return retval = new CompilerAstParser.while_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token char_literal210=null;
        Token string_literal212=null;
        Token char_literal213=null;
        CompilerAstParser.statement_return statement209 = null;

        CompilerAstParser.inner_statement_list_return inner_statement_list211 = null;


        SLAST char_literal210_tree=null;
        SLAST string_literal212_tree=null;
        SLAST char_literal213_tree=null;
        RewriteRuleTokenStream stream_126=new RewriteRuleTokenStream(adaptor,"token 126");
        RewriteRuleTokenStream stream_119=new RewriteRuleTokenStream(adaptor,"token 119");
        RewriteRuleTokenStream stream_89=new RewriteRuleTokenStream(adaptor,"token 89");
        RewriteRuleSubtreeStream stream_statement=new RewriteRuleSubtreeStream(adaptor,"rule statement");
        RewriteRuleSubtreeStream stream_inner_statement_list=new RewriteRuleSubtreeStream(adaptor,"rule inner_statement_list");
        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:330:2: ( statement -> statement | ':' ( inner_statement_list )? 'endwhile' ';' -> ( inner_statement_list )? )
            int alt61=2;
            int LA61_0 = input.LA(1);

            if ( (LA61_0==LEFT_PARETHESIS||(LA61_0>=IDENTIFIER && LA61_0<=LEFT_BRACKET)||LA61_0==STRINGLITERAL||(LA61_0>=BIT_AND && LA61_0<=MINUS_T)||(LA61_0>=TILDA_T && LA61_0<=BACKTRICKLITERAL)||(LA61_0>=DOLLAR_T && LA61_0<=DOUBLELITERRAL)||LA61_0==89||(LA61_0>=95 && LA61_0<=106)||(LA61_0>=108 && LA61_0<=111)||LA61_0==116||(LA61_0>=160 && LA61_0<=161)||(LA61_0>=163 && LA61_0<=166)||(LA61_0>=168 && LA61_0<=171)||(LA61_0>=173 && LA61_0<=178)) ) {
                alt61=1;
            }
            else if ( (LA61_0==119) ) {
                alt61=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 61, 0, input);

                throw nvae;
            }
            switch (alt61) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:330:4: statement
                    {
                    pushFollow(FOLLOW_statement_in_while_statement2330);
                    statement209=statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_statement.add(statement209.getTree());


                    // AST REWRITE
                    // elements: statement
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 330:31: -> statement
                    {
                        adaptor.addChild(root_0, stream_statement.nextTree());

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:331:4: ':' ( inner_statement_list )? 'endwhile' ';'
                    {
                    char_literal210=(Token)match(input,119,FOLLOW_119_in_while_statement2357); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_119.add(char_literal210);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:331:8: ( inner_statement_list )?
                    int alt60=2;
                    int LA60_0 = input.LA(1);

                    if ( (LA60_0==LEFT_PARETHESIS||(LA60_0>=CLASS_T && LA60_0<=LEFT_BRACKET)||LA60_0==STRINGLITERAL||(LA60_0>=BIT_AND && LA60_0<=MINUS_T)||(LA60_0>=TILDA_T && LA60_0<=BACKTRICKLITERAL)||(LA60_0>=DOLLAR_T && LA60_0<=DOUBLELITERRAL)||(LA60_0>=88 && LA60_0<=89)||(LA60_0>=92 && LA60_0<=106)||(LA60_0>=108 && LA60_0<=111)||LA60_0==116||(LA60_0>=160 && LA60_0<=161)||(LA60_0>=163 && LA60_0<=166)||(LA60_0>=168 && LA60_0<=171)||(LA60_0>=173 && LA60_0<=178)) ) {
                        alt60=1;
                    }
                    switch (alt60) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:331:8: inner_statement_list
                            {
                            pushFollow(FOLLOW_inner_statement_list_in_while_statement2359);
                            inner_statement_list211=inner_statement_list();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_inner_statement_list.add(inner_statement_list211.getTree());

                            }
                            break;

                    }

                    string_literal212=(Token)match(input,126,FOLLOW_126_in_while_statement2362); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_126.add(string_literal212);

                    char_literal213=(Token)match(input,89,FOLLOW_89_in_while_statement2364); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_89.add(char_literal213);



                    // AST REWRITE
                    // elements: inner_statement_list
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 331:47: -> ( inner_statement_list )?
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:331:51: ( inner_statement_list )?
                        if ( stream_inner_statement_list.hasNext() ) {
                            adaptor.addChild(root_0, stream_inner_statement_list.nextTree());

                        }
                        stream_inner_statement_list.reset();

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "while_statement"

    public static class foreach_statement_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "foreach_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:334:1: foreach_statement : ( statement -> statement | ':' ( inner_statement_list )? 'endforeach' ';' -> ( inner_statement_list )? );
    public final CompilerAstParser.foreach_statement_return foreach_statement() throws RecognitionException {
        CompilerAstParser.foreach_statement_return retval = new CompilerAstParser.foreach_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token char_literal215=null;
        Token string_literal217=null;
        Token char_literal218=null;
        CompilerAstParser.statement_return statement214 = null;

        CompilerAstParser.inner_statement_list_return inner_statement_list216 = null;


        SLAST char_literal215_tree=null;
        SLAST string_literal217_tree=null;
        SLAST char_literal218_tree=null;
        RewriteRuleTokenStream stream_127=new RewriteRuleTokenStream(adaptor,"token 127");
        RewriteRuleTokenStream stream_119=new RewriteRuleTokenStream(adaptor,"token 119");
        RewriteRuleTokenStream stream_89=new RewriteRuleTokenStream(adaptor,"token 89");
        RewriteRuleSubtreeStream stream_statement=new RewriteRuleSubtreeStream(adaptor,"rule statement");
        RewriteRuleSubtreeStream stream_inner_statement_list=new RewriteRuleSubtreeStream(adaptor,"rule inner_statement_list");
        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:335:3: ( statement -> statement | ':' ( inner_statement_list )? 'endforeach' ';' -> ( inner_statement_list )? )
            int alt63=2;
            int LA63_0 = input.LA(1);

            if ( (LA63_0==LEFT_PARETHESIS||(LA63_0>=IDENTIFIER && LA63_0<=LEFT_BRACKET)||LA63_0==STRINGLITERAL||(LA63_0>=BIT_AND && LA63_0<=MINUS_T)||(LA63_0>=TILDA_T && LA63_0<=BACKTRICKLITERAL)||(LA63_0>=DOLLAR_T && LA63_0<=DOUBLELITERRAL)||LA63_0==89||(LA63_0>=95 && LA63_0<=106)||(LA63_0>=108 && LA63_0<=111)||LA63_0==116||(LA63_0>=160 && LA63_0<=161)||(LA63_0>=163 && LA63_0<=166)||(LA63_0>=168 && LA63_0<=171)||(LA63_0>=173 && LA63_0<=178)) ) {
                alt63=1;
            }
            else if ( (LA63_0==119) ) {
                alt63=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 63, 0, input);

                throw nvae;
            }
            switch (alt63) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:335:5: statement
                    {
                    pushFollow(FOLLOW_statement_in_foreach_statement2385);
                    statement214=statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_statement.add(statement214.getTree());


                    // AST REWRITE
                    // elements: statement
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 335:31: -> statement
                    {
                        adaptor.addChild(root_0, stream_statement.nextTree());

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:336:5: ':' ( inner_statement_list )? 'endforeach' ';'
                    {
                    char_literal215=(Token)match(input,119,FOLLOW_119_in_foreach_statement2412); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_119.add(char_literal215);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:336:9: ( inner_statement_list )?
                    int alt62=2;
                    int LA62_0 = input.LA(1);

                    if ( (LA62_0==LEFT_PARETHESIS||(LA62_0>=CLASS_T && LA62_0<=LEFT_BRACKET)||LA62_0==STRINGLITERAL||(LA62_0>=BIT_AND && LA62_0<=MINUS_T)||(LA62_0>=TILDA_T && LA62_0<=BACKTRICKLITERAL)||(LA62_0>=DOLLAR_T && LA62_0<=DOUBLELITERRAL)||(LA62_0>=88 && LA62_0<=89)||(LA62_0>=92 && LA62_0<=106)||(LA62_0>=108 && LA62_0<=111)||LA62_0==116||(LA62_0>=160 && LA62_0<=161)||(LA62_0>=163 && LA62_0<=166)||(LA62_0>=168 && LA62_0<=171)||(LA62_0>=173 && LA62_0<=178)) ) {
                        alt62=1;
                    }
                    switch (alt62) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:336:9: inner_statement_list
                            {
                            pushFollow(FOLLOW_inner_statement_list_in_foreach_statement2414);
                            inner_statement_list216=inner_statement_list();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_inner_statement_list.add(inner_statement_list216.getTree());

                            }
                            break;

                    }

                    string_literal217=(Token)match(input,127,FOLLOW_127_in_foreach_statement2417); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_127.add(string_literal217);

                    char_literal218=(Token)match(input,89,FOLLOW_89_in_foreach_statement2419); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_89.add(char_literal218);



                    // AST REWRITE
                    // elements: inner_statement_list
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 336:49: -> ( inner_statement_list )?
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:336:53: ( inner_statement_list )?
                        if ( stream_inner_statement_list.hasNext() ) {
                            adaptor.addChild(root_0, stream_inner_statement_list.nextTree());

                        }
                        stream_inner_statement_list.reset();

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "foreach_statement"

    public static class declare_statement_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "declare_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:339:1: declare_statement : ( statement -> statement | ':' ( inner_statement_list )? 'enddeclare' ';' -> ( inner_statement_list )? );
    public final CompilerAstParser.declare_statement_return declare_statement() throws RecognitionException {
        CompilerAstParser.declare_statement_return retval = new CompilerAstParser.declare_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token char_literal220=null;
        Token string_literal222=null;
        Token char_literal223=null;
        CompilerAstParser.statement_return statement219 = null;

        CompilerAstParser.inner_statement_list_return inner_statement_list221 = null;


        SLAST char_literal220_tree=null;
        SLAST string_literal222_tree=null;
        SLAST char_literal223_tree=null;
        RewriteRuleTokenStream stream_128=new RewriteRuleTokenStream(adaptor,"token 128");
        RewriteRuleTokenStream stream_119=new RewriteRuleTokenStream(adaptor,"token 119");
        RewriteRuleTokenStream stream_89=new RewriteRuleTokenStream(adaptor,"token 89");
        RewriteRuleSubtreeStream stream_statement=new RewriteRuleSubtreeStream(adaptor,"rule statement");
        RewriteRuleSubtreeStream stream_inner_statement_list=new RewriteRuleSubtreeStream(adaptor,"rule inner_statement_list");
        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:340:3: ( statement -> statement | ':' ( inner_statement_list )? 'enddeclare' ';' -> ( inner_statement_list )? )
            int alt65=2;
            int LA65_0 = input.LA(1);

            if ( (LA65_0==LEFT_PARETHESIS||(LA65_0>=IDENTIFIER && LA65_0<=LEFT_BRACKET)||LA65_0==STRINGLITERAL||(LA65_0>=BIT_AND && LA65_0<=MINUS_T)||(LA65_0>=TILDA_T && LA65_0<=BACKTRICKLITERAL)||(LA65_0>=DOLLAR_T && LA65_0<=DOUBLELITERRAL)||LA65_0==89||(LA65_0>=95 && LA65_0<=106)||(LA65_0>=108 && LA65_0<=111)||LA65_0==116||(LA65_0>=160 && LA65_0<=161)||(LA65_0>=163 && LA65_0<=166)||(LA65_0>=168 && LA65_0<=171)||(LA65_0>=173 && LA65_0<=178)) ) {
                alt65=1;
            }
            else if ( (LA65_0==119) ) {
                alt65=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 65, 0, input);

                throw nvae;
            }
            switch (alt65) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:340:5: statement
                    {
                    pushFollow(FOLLOW_statement_in_declare_statement2441);
                    statement219=statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_statement.add(statement219.getTree());


                    // AST REWRITE
                    // elements: statement
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 340:31: -> statement
                    {
                        adaptor.addChild(root_0, stream_statement.nextTree());

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:341:5: ':' ( inner_statement_list )? 'enddeclare' ';'
                    {
                    char_literal220=(Token)match(input,119,FOLLOW_119_in_declare_statement2468); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_119.add(char_literal220);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:341:9: ( inner_statement_list )?
                    int alt64=2;
                    int LA64_0 = input.LA(1);

                    if ( (LA64_0==LEFT_PARETHESIS||(LA64_0>=CLASS_T && LA64_0<=LEFT_BRACKET)||LA64_0==STRINGLITERAL||(LA64_0>=BIT_AND && LA64_0<=MINUS_T)||(LA64_0>=TILDA_T && LA64_0<=BACKTRICKLITERAL)||(LA64_0>=DOLLAR_T && LA64_0<=DOUBLELITERRAL)||(LA64_0>=88 && LA64_0<=89)||(LA64_0>=92 && LA64_0<=106)||(LA64_0>=108 && LA64_0<=111)||LA64_0==116||(LA64_0>=160 && LA64_0<=161)||(LA64_0>=163 && LA64_0<=166)||(LA64_0>=168 && LA64_0<=171)||(LA64_0>=173 && LA64_0<=178)) ) {
                        alt64=1;
                    }
                    switch (alt64) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:341:9: inner_statement_list
                            {
                            pushFollow(FOLLOW_inner_statement_list_in_declare_statement2470);
                            inner_statement_list221=inner_statement_list();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_inner_statement_list.add(inner_statement_list221.getTree());

                            }
                            break;

                    }

                    string_literal222=(Token)match(input,128,FOLLOW_128_in_declare_statement2473); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_128.add(string_literal222);

                    char_literal223=(Token)match(input,89,FOLLOW_89_in_declare_statement2475); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_89.add(char_literal223);



                    // AST REWRITE
                    // elements: inner_statement_list
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 341:49: -> ( inner_statement_list )?
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:341:53: ( inner_statement_list )?
                        if ( stream_inner_statement_list.hasNext() ) {
                            adaptor.addChild(root_0, stream_inner_statement_list.nextTree());

                        }
                        stream_inner_statement_list.reset();

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "declare_statement"

    public static class parameter_list_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "parameter_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:344:1: parameter_list : parameter ( ',' parameter )* -> ( parameter )+ ;
    public final CompilerAstParser.parameter_list_return parameter_list() throws RecognitionException {
        CompilerAstParser.parameter_list_return retval = new CompilerAstParser.parameter_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token char_literal225=null;
        CompilerAstParser.parameter_return parameter224 = null;

        CompilerAstParser.parameter_return parameter226 = null;


        SLAST char_literal225_tree=null;
        RewriteRuleTokenStream stream_114=new RewriteRuleTokenStream(adaptor,"token 114");
        RewriteRuleSubtreeStream stream_parameter=new RewriteRuleSubtreeStream(adaptor,"rule parameter");
        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:345:3: ( parameter ( ',' parameter )* -> ( parameter )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:345:5: parameter ( ',' parameter )*
            {
            pushFollow(FOLLOW_parameter_in_parameter_list2497);
            parameter224=parameter();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_parameter.add(parameter224.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:345:15: ( ',' parameter )*
            loop66:
            do {
                int alt66=2;
                int LA66_0 = input.LA(1);

                if ( (LA66_0==114) ) {
                    alt66=1;
                }


                switch (alt66) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:345:16: ',' parameter
            	    {
            	    char_literal225=(Token)match(input,114,FOLLOW_114_in_parameter_list2500); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_114.add(char_literal225);

            	    pushFollow(FOLLOW_parameter_in_parameter_list2502);
            	    parameter226=parameter();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_parameter.add(parameter226.getTree());

            	    }
            	    break;

            	default :
            	    break loop66;
                }
            } while (true);



            // AST REWRITE
            // elements: parameter
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 345:41: -> ( parameter )+
            {
                if ( !(stream_parameter.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_parameter.hasNext() ) {
                    adaptor.addChild(root_0, stream_parameter.nextTree());

                }
                stream_parameter.reset();

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "parameter_list"

    public static class parameter_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "parameter"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:348:1: parameter : ( parameter_type )? ( 'const' )? pure_variable ( options {k=1; backtrack=true; } : '=' scalar )? -> ^( PARAMETER ( ^( TYPE parameter_type ) )? ( 'const' )? pure_variable ( scalar )? ) ;
    public final CompilerAstParser.parameter_return parameter() throws RecognitionException {
        CompilerAstParser.parameter_return retval = new CompilerAstParser.parameter_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token string_literal228=null;
        Token char_literal230=null;
        CompilerAstParser.parameter_type_return parameter_type227 = null;

        CompilerAstParser.pure_variable_return pure_variable229 = null;

        CompilerAstParser.scalar_return scalar231 = null;


        SLAST string_literal228_tree=null;
        SLAST char_literal230_tree=null;
        RewriteRuleTokenStream stream_113=new RewriteRuleTokenStream(adaptor,"token 113");
        RewriteRuleTokenStream stream_EQ=new RewriteRuleTokenStream(adaptor,"token EQ");
        RewriteRuleSubtreeStream stream_scalar=new RewriteRuleSubtreeStream(adaptor,"rule scalar");
        RewriteRuleSubtreeStream stream_parameter_type=new RewriteRuleSubtreeStream(adaptor,"rule parameter_type");
        RewriteRuleSubtreeStream stream_pure_variable=new RewriteRuleSubtreeStream(adaptor,"rule pure_variable");
        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:349:3: ( ( parameter_type )? ( 'const' )? pure_variable ( options {k=1; backtrack=true; } : '=' scalar )? -> ^( PARAMETER ( ^( TYPE parameter_type ) )? ( 'const' )? pure_variable ( scalar )? ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:349:5: ( parameter_type )? ( 'const' )? pure_variable ( options {k=1; backtrack=true; } : '=' scalar )?
            {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:349:5: ( parameter_type )?
            int alt67=2;
            int LA67_0 = input.LA(1);

            if ( (LA67_0==IDENTIFIER||(LA67_0>=153 && LA67_0<=163)) ) {
                alt67=1;
            }
            switch (alt67) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:349:5: parameter_type
                    {
                    pushFollow(FOLLOW_parameter_type_in_parameter2533);
                    parameter_type227=parameter_type();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_parameter_type.add(parameter_type227.getTree());

                    }
                    break;

            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:349:21: ( 'const' )?
            int alt68=2;
            int LA68_0 = input.LA(1);

            if ( (LA68_0==113) ) {
                alt68=1;
            }
            switch (alt68) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:349:21: 'const'
                    {
                    string_literal228=(Token)match(input,113,FOLLOW_113_in_parameter2536); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_113.add(string_literal228);


                    }
                    break;

            }

            pushFollow(FOLLOW_pure_variable_in_parameter2539);
            pure_variable229=pure_variable();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_pure_variable.add(pure_variable229.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:349:44: ( options {k=1; backtrack=true; } : '=' scalar )?
            int alt69=2;
            int LA69_0 = input.LA(1);

            if ( (LA69_0==EQ) ) {
                alt69=1;
            }
            switch (alt69) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:349:76: '=' scalar
                    {
                    char_literal230=(Token)match(input,EQ,FOLLOW_EQ_in_parameter2555); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_EQ.add(char_literal230);

                    pushFollow(FOLLOW_scalar_in_parameter2557);
                    scalar231=scalar();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_scalar.add(scalar231.getTree());

                    }
                    break;

            }



            // AST REWRITE
            // elements: scalar, parameter_type, pure_variable, 113
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 350:3: -> ^( PARAMETER ( ^( TYPE parameter_type ) )? ( 'const' )? pure_variable ( scalar )? )
            {
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:350:6: ^( PARAMETER ( ^( TYPE parameter_type ) )? ( 'const' )? pure_variable ( scalar )? )
                {
                SLAST root_1 = (SLAST)adaptor.nil();
                root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(PARAMETER, "PARAMETER"), root_1);

                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:350:18: ( ^( TYPE parameter_type ) )?
                if ( stream_parameter_type.hasNext() ) {
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:350:18: ^( TYPE parameter_type )
                    {
                    SLAST root_2 = (SLAST)adaptor.nil();
                    root_2 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(TYPE, "TYPE"), root_2);

                    adaptor.addChild(root_2, stream_parameter_type.nextTree());

                    adaptor.addChild(root_1, root_2);
                    }

                }
                stream_parameter_type.reset();
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:350:42: ( 'const' )?
                if ( stream_113.hasNext() ) {
                    adaptor.addChild(root_1, stream_113.nextNode());

                }
                stream_113.reset();
                adaptor.addChild(root_1, stream_pure_variable.nextTree());
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:350:65: ( scalar )?
                if ( stream_scalar.hasNext() ) {
                    adaptor.addChild(root_1, stream_scalar.nextTree());

                }
                stream_scalar.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "parameter"

    public static class parameter_type_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "parameter_type"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:353:1: parameter_type : ( fully_qualified_class_name | cast_option );
    public final CompilerAstParser.parameter_type_return parameter_type() throws RecognitionException {
        CompilerAstParser.parameter_type_return retval = new CompilerAstParser.parameter_type_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        CompilerAstParser.fully_qualified_class_name_return fully_qualified_class_name232 = null;

        CompilerAstParser.cast_option_return cast_option233 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:354:3: ( fully_qualified_class_name | cast_option )
            int alt70=2;
            int LA70_0 = input.LA(1);

            if ( (LA70_0==IDENTIFIER) ) {
                alt70=1;
            }
            else if ( ((LA70_0>=153 && LA70_0<=163)) ) {
                alt70=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 70, 0, input);

                throw nvae;
            }
            switch (alt70) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:354:5: fully_qualified_class_name
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_fully_qualified_class_name_in_parameter_type2597);
                    fully_qualified_class_name232=fully_qualified_class_name();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, fully_qualified_class_name232.getTree());

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:355:5: cast_option
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_cast_option_in_parameter_type2603);
                    cast_option233=cast_option();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, cast_option233.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "parameter_type"

    public static class variable_list_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "variable_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:358:1: variable_list : variable ( ',' variable )* -> ( variable )+ ;
    public final CompilerAstParser.variable_list_return variable_list() throws RecognitionException {
        CompilerAstParser.variable_list_return retval = new CompilerAstParser.variable_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token char_literal235=null;
        CompilerAstParser.variable_return variable234 = null;

        CompilerAstParser.variable_return variable236 = null;


        SLAST char_literal235_tree=null;
        RewriteRuleTokenStream stream_114=new RewriteRuleTokenStream(adaptor,"token 114");
        RewriteRuleSubtreeStream stream_variable=new RewriteRuleSubtreeStream(adaptor,"rule variable");
        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:359:3: ( variable ( ',' variable )* -> ( variable )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:359:5: variable ( ',' variable )*
            {
            pushFollow(FOLLOW_variable_in_variable_list2618);
            variable234=variable();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_variable.add(variable234.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:359:14: ( ',' variable )*
            loop71:
            do {
                int alt71=2;
                int LA71_0 = input.LA(1);

                if ( (LA71_0==114) ) {
                    alt71=1;
                }


                switch (alt71) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:359:15: ',' variable
            	    {
            	    char_literal235=(Token)match(input,114,FOLLOW_114_in_variable_list2621); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_114.add(char_literal235);

            	    pushFollow(FOLLOW_variable_in_variable_list2623);
            	    variable236=variable();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_variable.add(variable236.getTree());

            	    }
            	    break;

            	default :
            	    break loop71;
                }
            } while (true);



            // AST REWRITE
            // elements: variable
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 359:33: -> ( variable )+
            {
                if ( !(stream_variable.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_variable.hasNext() ) {
                    adaptor.addChild(root_0, stream_variable.nextTree());

                }
                stream_variable.reset();

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "variable_list"

    public static class variable_modifiers_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "variable_modifiers"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:362:1: variable_modifiers : ( 'var' | modifier );
    public final CompilerAstParser.variable_modifiers_return variable_modifiers() throws RecognitionException {
        CompilerAstParser.variable_modifiers_return retval = new CompilerAstParser.variable_modifiers_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token string_literal237=null;
        CompilerAstParser.modifier_return modifier238 = null;


        SLAST string_literal237_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:363:3: ( 'var' | modifier )
            int alt72=2;
            int LA72_0 = input.LA(1);

            if ( (LA72_0==129) ) {
                alt72=1;
            }
            else if ( ((LA72_0>=93 && LA72_0<=94)||LA72_0==104||(LA72_0>=130 && LA72_0<=132)) ) {
                alt72=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 72, 0, input);

                throw nvae;
            }
            switch (alt72) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:363:5: 'var'
                    {
                    root_0 = (SLAST)adaptor.nil();

                    string_literal237=(Token)match(input,129,FOLLOW_129_in_variable_modifiers2649); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    string_literal237_tree = (SLAST)adaptor.create(string_literal237);
                    adaptor.addChild(root_0, string_literal237_tree);
                    }

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:364:5: modifier
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_modifier_in_variable_modifiers2655);
                    modifier238=modifier();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, modifier238.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "variable_modifiers"

    public static class modifier_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "modifier"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:367:1: modifier : ( 'public' | 'protected' | 'private' | 'static' | 'abstract' | 'final' )+ ;
    public final CompilerAstParser.modifier_return modifier() throws RecognitionException {
        CompilerAstParser.modifier_return retval = new CompilerAstParser.modifier_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token set239=null;

        SLAST set239_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:368:3: ( ( 'public' | 'protected' | 'private' | 'static' | 'abstract' | 'final' )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:368:5: ( 'public' | 'protected' | 'private' | 'static' | 'abstract' | 'final' )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:368:5: ( 'public' | 'protected' | 'private' | 'static' | 'abstract' | 'final' )+
            int cnt73=0;
            loop73:
            do {
                int alt73=2;
                int LA73_0 = input.LA(1);

                if ( ((LA73_0>=93 && LA73_0<=94)||LA73_0==104||(LA73_0>=130 && LA73_0<=132)) ) {
                    alt73=1;
                }


                switch (alt73) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:
            	    {
            	    set239=(Token)input.LT(1);
            	    if ( (input.LA(1)>=93 && input.LA(1)<=94)||input.LA(1)==104||(input.LA(1)>=130 && input.LA(1)<=132) ) {
            	        input.consume();
            	        if ( state.backtracking==0 ) adaptor.addChild(root_0, (SLAST)adaptor.create(set239));
            	        state.errorRecovery=false;state.failed=false;
            	    }
            	    else {
            	        if (state.backtracking>0) {state.failed=true; return retval;}
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        throw mse;
            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt73 >= 1 ) break loop73;
            	    if (state.backtracking>0) {state.failed=true; return retval;}
                        EarlyExitException eee =
                            new EarlyExitException(73, input);
                        throw eee;
                }
                cnt73++;
            } while (true);


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "modifier"

    public static class directive_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "directive"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:376:1: directive : IDENTIFIER '=' expression ( ',' IDENTIFIER '=' expression )* -> ^( '=' IDENTIFIER expression ) ;
    public final CompilerAstParser.directive_return directive() throws RecognitionException {
        CompilerAstParser.directive_return retval = new CompilerAstParser.directive_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token IDENTIFIER240=null;
        Token char_literal241=null;
        Token char_literal243=null;
        Token IDENTIFIER244=null;
        Token char_literal245=null;
        CompilerAstParser.expression_return expression242 = null;

        CompilerAstParser.expression_return expression246 = null;


        SLAST IDENTIFIER240_tree=null;
        SLAST char_literal241_tree=null;
        SLAST char_literal243_tree=null;
        SLAST IDENTIFIER244_tree=null;
        SLAST char_literal245_tree=null;
        RewriteRuleTokenStream stream_114=new RewriteRuleTokenStream(adaptor,"token 114");
        RewriteRuleTokenStream stream_EQ=new RewriteRuleTokenStream(adaptor,"token EQ");
        RewriteRuleTokenStream stream_IDENTIFIER=new RewriteRuleTokenStream(adaptor,"token IDENTIFIER");
        RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");
        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:377:3: ( IDENTIFIER '=' expression ( ',' IDENTIFIER '=' expression )* -> ^( '=' IDENTIFIER expression ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:377:5: IDENTIFIER '=' expression ( ',' IDENTIFIER '=' expression )*
            {
            IDENTIFIER240=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_directive2720); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER240);

            char_literal241=(Token)match(input,EQ,FOLLOW_EQ_in_directive2722); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_EQ.add(char_literal241);

            pushFollow(FOLLOW_expression_in_directive2724);
            expression242=expression();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_expression.add(expression242.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:377:31: ( ',' IDENTIFIER '=' expression )*
            loop74:
            do {
                int alt74=2;
                int LA74_0 = input.LA(1);

                if ( (LA74_0==114) ) {
                    alt74=1;
                }


                switch (alt74) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:377:32: ',' IDENTIFIER '=' expression
            	    {
            	    char_literal243=(Token)match(input,114,FOLLOW_114_in_directive2727); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_114.add(char_literal243);

            	    IDENTIFIER244=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_directive2729); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER244);

            	    char_literal245=(Token)match(input,EQ,FOLLOW_EQ_in_directive2731); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_EQ.add(char_literal245);

            	    pushFollow(FOLLOW_expression_in_directive2733);
            	    expression246=expression();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_expression.add(expression246.getTree());

            	    }
            	    break;

            	default :
            	    break loop74;
                }
            } while (true);



            // AST REWRITE
            // elements: EQ, expression, IDENTIFIER
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 377:65: -> ^( '=' IDENTIFIER expression )
            {
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:377:69: ^( '=' IDENTIFIER expression )
                {
                SLAST root_1 = (SLAST)adaptor.nil();
                root_1 = (SLAST)adaptor.becomeRoot(stream_EQ.nextNode(), root_1);

                adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());
                adaptor.addChild(root_1, stream_expression.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "directive"

    public static class expr_list_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "expr_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:380:1: expr_list : expression ( ',' expression )* -> ( expression )+ ;
    public final CompilerAstParser.expr_list_return expr_list() throws RecognitionException {
        CompilerAstParser.expr_list_return retval = new CompilerAstParser.expr_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token char_literal248=null;
        CompilerAstParser.expression_return expression247 = null;

        CompilerAstParser.expression_return expression249 = null;


        SLAST char_literal248_tree=null;
        RewriteRuleTokenStream stream_114=new RewriteRuleTokenStream(adaptor,"token 114");
        RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");
        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:381:2: ( expression ( ',' expression )* -> ( expression )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:381:4: expression ( ',' expression )*
            {
            pushFollow(FOLLOW_expression_in_expr_list2761);
            expression247=expression();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_expression.add(expression247.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:381:15: ( ',' expression )*
            loop75:
            do {
                int alt75=2;
                int LA75_0 = input.LA(1);

                if ( (LA75_0==114) ) {
                    alt75=1;
                }


                switch (alt75) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:381:16: ',' expression
            	    {
            	    char_literal248=(Token)match(input,114,FOLLOW_114_in_expr_list2764); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_114.add(char_literal248);

            	    pushFollow(FOLLOW_expression_in_expr_list2766);
            	    expression249=expression();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_expression.add(expression249.getTree());

            	    }
            	    break;

            	default :
            	    break loop75;
                }
            } while (true);



            // AST REWRITE
            // elements: expression
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 381:35: -> ( expression )+
            {
                if ( !(stream_expression.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_expression.hasNext() ) {
                    adaptor.addChild(root_0, stream_expression.nextTree());

                }
                stream_expression.reset();

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "expr_list"

    public static class expression_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "expression"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:384:1: expression : logical_text_or_expr -> ^( EXPR logical_text_or_expr ) ;
    public final CompilerAstParser.expression_return expression() throws RecognitionException {
        CompilerAstParser.expression_return retval = new CompilerAstParser.expression_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        CompilerAstParser.logical_text_or_expr_return logical_text_or_expr250 = null;


        RewriteRuleSubtreeStream stream_logical_text_or_expr=new RewriteRuleSubtreeStream(adaptor,"rule logical_text_or_expr");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:394:3: ( logical_text_or_expr -> ^( EXPR logical_text_or_expr ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:394:5: logical_text_or_expr
            {
            pushFollow(FOLLOW_logical_text_or_expr_in_expression2801);
            logical_text_or_expr250=logical_text_or_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_logical_text_or_expr.add(logical_text_or_expr250.getTree());
            if ( state.backtracking==0 ) {

                  token = (CommonToken)(logical_text_or_expr250!=null?((Token)logical_text_or_expr250.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(logical_text_or_expr250!=null?((Token)logical_text_or_expr250.stop):null);
                  endIndex = token.getStopIndex();
                
            }


            // AST REWRITE
            // elements: logical_text_or_expr
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 401:5: -> ^( EXPR logical_text_or_expr )
            {
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:401:9: ^( EXPR logical_text_or_expr )
                {
                SLAST root_1 = (SLAST)adaptor.nil();
                root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(EXPR, "EXPR"), root_1);

                adaptor.addChild(root_1, stream_logical_text_or_expr.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "expression"

    public static class logical_text_or_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "logical_text_or_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:404:1: logical_text_or_expr : e1= logical_text_xor_expr ( 'OR' e2= logical_text_xor_expr )* ;
    public final CompilerAstParser.logical_text_or_expr_return logical_text_or_expr() throws RecognitionException {
        CompilerAstParser.logical_text_or_expr_return retval = new CompilerAstParser.logical_text_or_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token string_literal251=null;
        CompilerAstParser.logical_text_xor_expr_return e1 = null;

        CompilerAstParser.logical_text_xor_expr_return e2 = null;


        SLAST string_literal251_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:414:3: (e1= logical_text_xor_expr ( 'OR' e2= logical_text_xor_expr )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:414:5: e1= logical_text_xor_expr ( 'OR' e2= logical_text_xor_expr )*
            {
            root_0 = (SLAST)adaptor.nil();

            pushFollow(FOLLOW_logical_text_xor_expr_in_logical_text_or_expr2844);
            e1=logical_text_xor_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, e1.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:414:30: ( 'OR' e2= logical_text_xor_expr )*
            loop76:
            do {
                int alt76=2;
                int LA76_0 = input.LA(1);

                if ( (LA76_0==133) ) {
                    alt76=1;
                }


                switch (alt76) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:414:31: 'OR' e2= logical_text_xor_expr
            	    {
            	    string_literal251=(Token)match(input,133,FOLLOW_133_in_logical_text_or_expr2847); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    string_literal251_tree = (SLAST)adaptor.create(string_literal251);
            	    root_0 = (SLAST)adaptor.becomeRoot(string_literal251_tree, root_0);
            	    }
            	    pushFollow(FOLLOW_logical_text_xor_expr_in_logical_text_or_expr2852);
            	    e2=logical_text_xor_expr();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, e2.getTree());

            	    }
            	    break;

            	default :
            	    break loop76;
                }
            } while (true);

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(e1!=null?((Token)e1.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(e1!=null?((Token)e1.stop):null);
                  if ((e2!=null?input.toString(e2.start,e2.stop):null) != null) {
                    token = (CommonToken)(e2!=null?((Token)e2.stop):null);
                  }
                  endIndex = token.getStopIndex();
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "logical_text_or_expr"

    public static class logical_text_xor_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "logical_text_xor_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:426:1: logical_text_xor_expr : e1= logical_text_and_expr ( 'XOR' e2= logical_text_and_expr )* ;
    public final CompilerAstParser.logical_text_xor_expr_return logical_text_xor_expr() throws RecognitionException {
        CompilerAstParser.logical_text_xor_expr_return retval = new CompilerAstParser.logical_text_xor_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token string_literal252=null;
        CompilerAstParser.logical_text_and_expr_return e1 = null;

        CompilerAstParser.logical_text_and_expr_return e2 = null;


        SLAST string_literal252_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:436:3: (e1= logical_text_and_expr ( 'XOR' e2= logical_text_and_expr )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:436:5: e1= logical_text_and_expr ( 'XOR' e2= logical_text_and_expr )*
            {
            root_0 = (SLAST)adaptor.nil();

            pushFollow(FOLLOW_logical_text_and_expr_in_logical_text_xor_expr2883);
            e1=logical_text_and_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, e1.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:436:30: ( 'XOR' e2= logical_text_and_expr )*
            loop77:
            do {
                int alt77=2;
                int LA77_0 = input.LA(1);

                if ( (LA77_0==134) ) {
                    alt77=1;
                }


                switch (alt77) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:436:31: 'XOR' e2= logical_text_and_expr
            	    {
            	    string_literal252=(Token)match(input,134,FOLLOW_134_in_logical_text_xor_expr2886); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    string_literal252_tree = (SLAST)adaptor.create(string_literal252);
            	    root_0 = (SLAST)adaptor.becomeRoot(string_literal252_tree, root_0);
            	    }
            	    pushFollow(FOLLOW_logical_text_and_expr_in_logical_text_xor_expr2891);
            	    e2=logical_text_and_expr();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, e2.getTree());

            	    }
            	    break;

            	default :
            	    break loop77;
                }
            } while (true);

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(e1!=null?((Token)e1.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(e1!=null?((Token)e1.stop):null);
                  if ((e2!=null?input.toString(e2.start,e2.stop):null) != null) {
                    token = (CommonToken)(e2!=null?((Token)e2.stop):null);
                  }
                  endIndex = token.getStopIndex();
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "logical_text_xor_expr"

    public static class logical_text_and_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "logical_text_and_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:448:1: logical_text_and_expr : e1= assignment_expr ( 'AND' e2= assignment_expr )* ;
    public final CompilerAstParser.logical_text_and_expr_return logical_text_and_expr() throws RecognitionException {
        CompilerAstParser.logical_text_and_expr_return retval = new CompilerAstParser.logical_text_and_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token string_literal253=null;
        CompilerAstParser.assignment_expr_return e1 = null;

        CompilerAstParser.assignment_expr_return e2 = null;


        SLAST string_literal253_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:458:3: (e1= assignment_expr ( 'AND' e2= assignment_expr )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:458:5: e1= assignment_expr ( 'AND' e2= assignment_expr )*
            {
            root_0 = (SLAST)adaptor.nil();

            pushFollow(FOLLOW_assignment_expr_in_logical_text_and_expr2922);
            e1=assignment_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, e1.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:458:24: ( 'AND' e2= assignment_expr )*
            loop78:
            do {
                int alt78=2;
                int LA78_0 = input.LA(1);

                if ( (LA78_0==135) ) {
                    alt78=1;
                }


                switch (alt78) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:458:25: 'AND' e2= assignment_expr
            	    {
            	    string_literal253=(Token)match(input,135,FOLLOW_135_in_logical_text_and_expr2925); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    string_literal253_tree = (SLAST)adaptor.create(string_literal253);
            	    root_0 = (SLAST)adaptor.becomeRoot(string_literal253_tree, root_0);
            	    }
            	    pushFollow(FOLLOW_assignment_expr_in_logical_text_and_expr2930);
            	    e2=assignment_expr();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, e2.getTree());

            	    }
            	    break;

            	default :
            	    break loop78;
                }
            } while (true);

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(e1!=null?((Token)e1.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(e1!=null?((Token)e1.stop):null);
                  if ((e2!=null?input.toString(e2.start,e2.stop):null) != null) {
                    token = (CommonToken)(e2!=null?((Token)e2.stop):null);
                  }
                  endIndex = token.getStopIndex();
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "logical_text_and_expr"

    public static class assignment_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "assignment_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:470:1: assignment_expr : e1= conditional_expr ( assignment_operator e2= conditional_expr )* ;
    public final CompilerAstParser.assignment_expr_return assignment_expr() throws RecognitionException {
        CompilerAstParser.assignment_expr_return retval = new CompilerAstParser.assignment_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        CompilerAstParser.conditional_expr_return e1 = null;

        CompilerAstParser.conditional_expr_return e2 = null;

        CompilerAstParser.assignment_operator_return assignment_operator254 = null;




          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:480:3: (e1= conditional_expr ( assignment_operator e2= conditional_expr )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:480:5: e1= conditional_expr ( assignment_operator e2= conditional_expr )*
            {
            root_0 = (SLAST)adaptor.nil();

            pushFollow(FOLLOW_conditional_expr_in_assignment_expr2961);
            e1=conditional_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, e1.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:480:25: ( assignment_operator e2= conditional_expr )*
            loop79:
            do {
                int alt79=2;
                int LA79_0 = input.LA(1);

                if ( ((LA79_0>=EQ && LA79_0<=RMOVE_EQ)) ) {
                    alt79=1;
                }


                switch (alt79) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:480:26: assignment_operator e2= conditional_expr
            	    {
            	    pushFollow(FOLLOW_assignment_operator_in_assignment_expr2964);
            	    assignment_operator254=assignment_operator();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) root_0 = (SLAST)adaptor.becomeRoot(assignment_operator254.getTree(), root_0);
            	    pushFollow(FOLLOW_conditional_expr_in_assignment_expr2969);
            	    e2=conditional_expr();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, e2.getTree());

            	    }
            	    break;

            	default :
            	    break loop79;
                }
            } while (true);

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(e1!=null?((Token)e1.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(e1!=null?((Token)e1.stop):null);
                  if ((e2!=null?input.toString(e2.start,e2.stop):null) != null) {
                    token = (CommonToken)(e2!=null?((Token)e2.stop):null);
                  }
                  endIndex = token.getStopIndex();
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "assignment_expr"

    public static class assignment_operator_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "assignment_operator"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:492:1: assignment_operator : ( EQ | PLUS_EQ | MINUS_EQ | MUL_EQ | DIV_EQ | DOT_EQ | PERCENT_EQ | BIT_AND_EQ | BIT_OR_EQ | POWER_EQ | LMOVE_EQ | RMOVE_EQ );
    public final CompilerAstParser.assignment_operator_return assignment_operator() throws RecognitionException {
        CompilerAstParser.assignment_operator_return retval = new CompilerAstParser.assignment_operator_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token set255=null;

        SLAST set255_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:493:3: ( EQ | PLUS_EQ | MINUS_EQ | MUL_EQ | DIV_EQ | DOT_EQ | PERCENT_EQ | BIT_AND_EQ | BIT_OR_EQ | POWER_EQ | LMOVE_EQ | RMOVE_EQ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:
            {
            root_0 = (SLAST)adaptor.nil();

            set255=(Token)input.LT(1);
            if ( (input.LA(1)>=EQ && input.LA(1)<=RMOVE_EQ) ) {
                input.consume();
                if ( state.backtracking==0 ) adaptor.addChild(root_0, (SLAST)adaptor.create(set255));
                state.errorRecovery=false;state.failed=false;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                MismatchedSetException mse = new MismatchedSetException(null,input);
                throw mse;
            }


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "assignment_operator"

    public static class conditional_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "conditional_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:507:1: conditional_expr : (ll= logical_or_expr -> $ll) ( '?' ( expression )? ':' lr= logical_or_expr -> ^( '?' $ll ^( ':' ( expression )? $lr) ) )? ;
    public final CompilerAstParser.conditional_expr_return conditional_expr() throws RecognitionException {
        CompilerAstParser.conditional_expr_return retval = new CompilerAstParser.conditional_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token char_literal256=null;
        Token char_literal258=null;
        CompilerAstParser.logical_or_expr_return ll = null;

        CompilerAstParser.logical_or_expr_return lr = null;

        CompilerAstParser.expression_return expression257 = null;


        SLAST char_literal256_tree=null;
        SLAST char_literal258_tree=null;
        RewriteRuleTokenStream stream_136=new RewriteRuleTokenStream(adaptor,"token 136");
        RewriteRuleTokenStream stream_119=new RewriteRuleTokenStream(adaptor,"token 119");
        RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");
        RewriteRuleSubtreeStream stream_logical_or_expr=new RewriteRuleSubtreeStream(adaptor,"rule logical_or_expr");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:517:3: ( (ll= logical_or_expr -> $ll) ( '?' ( expression )? ':' lr= logical_or_expr -> ^( '?' $ll ^( ':' ( expression )? $lr) ) )? )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:517:5: (ll= logical_or_expr -> $ll) ( '?' ( expression )? ':' lr= logical_or_expr -> ^( '?' $ll ^( ':' ( expression )? $lr) ) )?
            {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:517:5: (ll= logical_or_expr -> $ll)
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:517:6: ll= logical_or_expr
            {
            pushFollow(FOLLOW_logical_or_expr_in_conditional_expr3107);
            ll=logical_or_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_logical_or_expr.add(ll.getTree());
            if ( state.backtracking==0 ) {

                  token = (CommonToken)(ll!=null?((Token)ll.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(ll!=null?((Token)ll.stop):null);
                  endIndex = token.getStopIndex();
                
            }


            // AST REWRITE
            // elements: ll
            // token labels: 
            // rule labels: retval, ll
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
            RewriteRuleSubtreeStream stream_ll=new RewriteRuleSubtreeStream(adaptor,"rule ll",ll!=null?ll.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 524:4: -> $ll
            {
                adaptor.addChild(root_0, stream_ll.nextTree());

            }

            retval.tree = root_0;}
            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:525:4: ( '?' ( expression )? ':' lr= logical_or_expr -> ^( '?' $ll ^( ':' ( expression )? $lr) ) )?
            int alt81=2;
            int LA81_0 = input.LA(1);

            if ( (LA81_0==136) ) {
                alt81=1;
            }
            switch (alt81) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:525:5: '?' ( expression )? ':' lr= logical_or_expr
                    {
                    char_literal256=(Token)match(input,136,FOLLOW_136_in_conditional_expr3126); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_136.add(char_literal256);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:525:9: ( expression )?
                    int alt80=2;
                    int LA80_0 = input.LA(1);

                    if ( (LA80_0==LEFT_PARETHESIS||LA80_0==IDENTIFIER||LA80_0==STRINGLITERAL||(LA80_0>=BIT_AND && LA80_0<=MINUS_T)||(LA80_0>=TILDA_T && LA80_0<=BACKTRICKLITERAL)||(LA80_0>=DOLLAR_T && LA80_0<=DOUBLELITERRAL)||LA80_0==95||(LA80_0>=160 && LA80_0<=161)||(LA80_0>=163 && LA80_0<=166)||(LA80_0>=168 && LA80_0<=171)||(LA80_0>=173 && LA80_0<=178)) ) {
                        alt80=1;
                    }
                    switch (alt80) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:525:9: expression
                            {
                            pushFollow(FOLLOW_expression_in_conditional_expr3128);
                            expression257=expression();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_expression.add(expression257.getTree());

                            }
                            break;

                    }

                    char_literal258=(Token)match(input,119,FOLLOW_119_in_conditional_expr3131); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_119.add(char_literal258);

                    pushFollow(FOLLOW_logical_or_expr_in_conditional_expr3135);
                    lr=logical_or_expr();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_logical_or_expr.add(lr.getTree());
                    if ( state.backtracking==0 ) {

                          token = (CommonToken)(lr!=null?((Token)lr.stop):null);
                          endIndex = token.getStopIndex();
                        
                    }


                    // AST REWRITE
                    // elements: expression, lr, 136, ll, 119
                    // token labels: 
                    // rule labels: retval, ll, lr
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
                    RewriteRuleSubtreeStream stream_ll=new RewriteRuleSubtreeStream(adaptor,"rule ll",ll!=null?ll.tree:null);
                    RewriteRuleSubtreeStream stream_lr=new RewriteRuleSubtreeStream(adaptor,"rule lr",lr!=null?lr.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 529:5: -> ^( '?' $ll ^( ':' ( expression )? $lr) )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:529:8: ^( '?' $ll ^( ':' ( expression )? $lr) )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_136.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_ll.nextTree());
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:529:18: ^( ':' ( expression )? $lr)
                        {
                        SLAST root_2 = (SLAST)adaptor.nil();
                        root_2 = (SLAST)adaptor.becomeRoot(stream_119.nextNode(), root_2);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:529:24: ( expression )?
                        if ( stream_expression.hasNext() ) {
                            adaptor.addChild(root_2, stream_expression.nextTree());

                        }
                        stream_expression.reset();
                        adaptor.addChild(root_2, stream_lr.nextTree());

                        adaptor.addChild(root_1, root_2);
                        }

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "conditional_expr"

    public static class logical_or_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "logical_or_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:532:1: logical_or_expr : e1= logical_and_expr ( '||' e2= logical_and_expr )* ;
    public final CompilerAstParser.logical_or_expr_return logical_or_expr() throws RecognitionException {
        CompilerAstParser.logical_or_expr_return retval = new CompilerAstParser.logical_or_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token string_literal259=null;
        CompilerAstParser.logical_and_expr_return e1 = null;

        CompilerAstParser.logical_and_expr_return e2 = null;


        SLAST string_literal259_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:542:3: (e1= logical_and_expr ( '||' e2= logical_and_expr )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:542:5: e1= logical_and_expr ( '||' e2= logical_and_expr )*
            {
            root_0 = (SLAST)adaptor.nil();

            pushFollow(FOLLOW_logical_and_expr_in_logical_or_expr3185);
            e1=logical_and_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, e1.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:542:25: ( '||' e2= logical_and_expr )*
            loop82:
            do {
                int alt82=2;
                int LA82_0 = input.LA(1);

                if ( (LA82_0==137) ) {
                    alt82=1;
                }


                switch (alt82) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:542:26: '||' e2= logical_and_expr
            	    {
            	    string_literal259=(Token)match(input,137,FOLLOW_137_in_logical_or_expr3188); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    string_literal259_tree = (SLAST)adaptor.create(string_literal259);
            	    root_0 = (SLAST)adaptor.becomeRoot(string_literal259_tree, root_0);
            	    }
            	    pushFollow(FOLLOW_logical_and_expr_in_logical_or_expr3193);
            	    e2=logical_and_expr();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, e2.getTree());

            	    }
            	    break;

            	default :
            	    break loop82;
                }
            } while (true);

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(e1!=null?((Token)e1.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(e1!=null?((Token)e1.stop):null);
                  if ((e2!=null?input.toString(e2.start,e2.stop):null) != null) {
                    token = (CommonToken)(e2!=null?((Token)e2.stop):null);
                  }
                  endIndex = token.getStopIndex();
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "logical_or_expr"

    public static class logical_and_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "logical_and_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:554:1: logical_and_expr : e1= bitwise_or_expr ( '&&' e2= bitwise_or_expr )* ;
    public final CompilerAstParser.logical_and_expr_return logical_and_expr() throws RecognitionException {
        CompilerAstParser.logical_and_expr_return retval = new CompilerAstParser.logical_and_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token string_literal260=null;
        CompilerAstParser.bitwise_or_expr_return e1 = null;

        CompilerAstParser.bitwise_or_expr_return e2 = null;


        SLAST string_literal260_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:564:3: (e1= bitwise_or_expr ( '&&' e2= bitwise_or_expr )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:564:5: e1= bitwise_or_expr ( '&&' e2= bitwise_or_expr )*
            {
            root_0 = (SLAST)adaptor.nil();

            pushFollow(FOLLOW_bitwise_or_expr_in_logical_and_expr3224);
            e1=bitwise_or_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, e1.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:564:24: ( '&&' e2= bitwise_or_expr )*
            loop83:
            do {
                int alt83=2;
                int LA83_0 = input.LA(1);

                if ( (LA83_0==138) ) {
                    alt83=1;
                }


                switch (alt83) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:564:25: '&&' e2= bitwise_or_expr
            	    {
            	    string_literal260=(Token)match(input,138,FOLLOW_138_in_logical_and_expr3227); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    string_literal260_tree = (SLAST)adaptor.create(string_literal260);
            	    root_0 = (SLAST)adaptor.becomeRoot(string_literal260_tree, root_0);
            	    }
            	    pushFollow(FOLLOW_bitwise_or_expr_in_logical_and_expr3232);
            	    e2=bitwise_or_expr();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, e2.getTree());

            	    }
            	    break;

            	default :
            	    break loop83;
                }
            } while (true);

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(e1!=null?((Token)e1.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(e1!=null?((Token)e1.stop):null);
                  if ((e2!=null?input.toString(e2.start,e2.stop):null) != null) {
                    token = (CommonToken)(e2!=null?((Token)e2.stop):null);
                  }
                  endIndex = token.getStopIndex();
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "logical_and_expr"

    public static class bitwise_or_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "bitwise_or_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:576:1: bitwise_or_expr : e1= bitwise_xor_expr ( '|' e2= bitwise_xor_expr )* ;
    public final CompilerAstParser.bitwise_or_expr_return bitwise_or_expr() throws RecognitionException {
        CompilerAstParser.bitwise_or_expr_return retval = new CompilerAstParser.bitwise_or_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token char_literal261=null;
        CompilerAstParser.bitwise_xor_expr_return e1 = null;

        CompilerAstParser.bitwise_xor_expr_return e2 = null;


        SLAST char_literal261_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:586:3: (e1= bitwise_xor_expr ( '|' e2= bitwise_xor_expr )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:586:5: e1= bitwise_xor_expr ( '|' e2= bitwise_xor_expr )*
            {
            root_0 = (SLAST)adaptor.nil();

            pushFollow(FOLLOW_bitwise_xor_expr_in_bitwise_or_expr3263);
            e1=bitwise_xor_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, e1.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:586:25: ( '|' e2= bitwise_xor_expr )*
            loop84:
            do {
                int alt84=2;
                int LA84_0 = input.LA(1);

                if ( (LA84_0==139) ) {
                    alt84=1;
                }


                switch (alt84) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:586:26: '|' e2= bitwise_xor_expr
            	    {
            	    char_literal261=(Token)match(input,139,FOLLOW_139_in_bitwise_or_expr3266); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    char_literal261_tree = (SLAST)adaptor.create(char_literal261);
            	    root_0 = (SLAST)adaptor.becomeRoot(char_literal261_tree, root_0);
            	    }
            	    pushFollow(FOLLOW_bitwise_xor_expr_in_bitwise_or_expr3271);
            	    e2=bitwise_xor_expr();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, e2.getTree());

            	    }
            	    break;

            	default :
            	    break loop84;
                }
            } while (true);

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(e1!=null?((Token)e1.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(e1!=null?((Token)e1.stop):null);
                  if ((e2!=null?input.toString(e2.start,e2.stop):null) != null) {
                    token = (CommonToken)(e2!=null?((Token)e2.stop):null);
                  }
                  endIndex = token.getStopIndex();
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "bitwise_or_expr"

    public static class bitwise_xor_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "bitwise_xor_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:598:1: bitwise_xor_expr : e1= bitwise_and_expr ( '^' e2= bitwise_and_expr )* ;
    public final CompilerAstParser.bitwise_xor_expr_return bitwise_xor_expr() throws RecognitionException {
        CompilerAstParser.bitwise_xor_expr_return retval = new CompilerAstParser.bitwise_xor_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token char_literal262=null;
        CompilerAstParser.bitwise_and_expr_return e1 = null;

        CompilerAstParser.bitwise_and_expr_return e2 = null;


        SLAST char_literal262_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:608:3: (e1= bitwise_and_expr ( '^' e2= bitwise_and_expr )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:608:5: e1= bitwise_and_expr ( '^' e2= bitwise_and_expr )*
            {
            root_0 = (SLAST)adaptor.nil();

            pushFollow(FOLLOW_bitwise_and_expr_in_bitwise_xor_expr3302);
            e1=bitwise_and_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, e1.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:608:25: ( '^' e2= bitwise_and_expr )*
            loop85:
            do {
                int alt85=2;
                int LA85_0 = input.LA(1);

                if ( (LA85_0==140) ) {
                    alt85=1;
                }


                switch (alt85) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:608:26: '^' e2= bitwise_and_expr
            	    {
            	    char_literal262=(Token)match(input,140,FOLLOW_140_in_bitwise_xor_expr3305); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    char_literal262_tree = (SLAST)adaptor.create(char_literal262);
            	    root_0 = (SLAST)adaptor.becomeRoot(char_literal262_tree, root_0);
            	    }
            	    pushFollow(FOLLOW_bitwise_and_expr_in_bitwise_xor_expr3310);
            	    e2=bitwise_and_expr();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, e2.getTree());

            	    }
            	    break;

            	default :
            	    break loop85;
                }
            } while (true);

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(e1!=null?((Token)e1.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(e1!=null?((Token)e1.stop):null);
                  if ((e2!=null?input.toString(e2.start,e2.stop):null) != null) {
                    token = (CommonToken)(e2!=null?((Token)e2.stop):null);
                  }
                  endIndex = token.getStopIndex();
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "bitwise_xor_expr"

    public static class bitwise_and_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "bitwise_and_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:620:1: bitwise_and_expr : e1= concat_expr ( '.' e2= concat_expr )* ;
    public final CompilerAstParser.bitwise_and_expr_return bitwise_and_expr() throws RecognitionException {
        CompilerAstParser.bitwise_and_expr_return retval = new CompilerAstParser.bitwise_and_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token char_literal263=null;
        CompilerAstParser.concat_expr_return e1 = null;

        CompilerAstParser.concat_expr_return e2 = null;


        SLAST char_literal263_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:630:3: (e1= concat_expr ( '.' e2= concat_expr )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:630:5: e1= concat_expr ( '.' e2= concat_expr )*
            {
            root_0 = (SLAST)adaptor.nil();

            pushFollow(FOLLOW_concat_expr_in_bitwise_and_expr3341);
            e1=concat_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, e1.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:630:20: ( '.' e2= concat_expr )*
            loop86:
            do {
                int alt86=2;
                int LA86_0 = input.LA(1);

                if ( (LA86_0==141) ) {
                    alt86=1;
                }


                switch (alt86) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:630:21: '.' e2= concat_expr
            	    {
            	    char_literal263=(Token)match(input,141,FOLLOW_141_in_bitwise_and_expr3344); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    char_literal263_tree = (SLAST)adaptor.create(char_literal263);
            	    root_0 = (SLAST)adaptor.becomeRoot(char_literal263_tree, root_0);
            	    }
            	    pushFollow(FOLLOW_concat_expr_in_bitwise_and_expr3349);
            	    e2=concat_expr();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, e2.getTree());

            	    }
            	    break;

            	default :
            	    break loop86;
                }
            } while (true);

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(e1!=null?((Token)e1.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(e1!=null?((Token)e1.stop):null);
                  if ((e2!=null?input.toString(e2.start,e2.stop):null) != null) {
                    token = (CommonToken)(e2!=null?((Token)e2.stop):null);
                  }
                  endIndex = token.getStopIndex();
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "bitwise_and_expr"

    public static class concat_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "concat_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:642:1: concat_expr : e1= equality_expr ( BIT_AND e2= equality_expr )* ;
    public final CompilerAstParser.concat_expr_return concat_expr() throws RecognitionException {
        CompilerAstParser.concat_expr_return retval = new CompilerAstParser.concat_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token BIT_AND264=null;
        CompilerAstParser.equality_expr_return e1 = null;

        CompilerAstParser.equality_expr_return e2 = null;


        SLAST BIT_AND264_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:652:3: (e1= equality_expr ( BIT_AND e2= equality_expr )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:652:5: e1= equality_expr ( BIT_AND e2= equality_expr )*
            {
            root_0 = (SLAST)adaptor.nil();

            pushFollow(FOLLOW_equality_expr_in_concat_expr3380);
            e1=equality_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, e1.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:652:22: ( BIT_AND e2= equality_expr )*
            loop87:
            do {
                int alt87=2;
                int LA87_0 = input.LA(1);

                if ( (LA87_0==BIT_AND) ) {
                    alt87=1;
                }


                switch (alt87) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:652:23: BIT_AND e2= equality_expr
            	    {
            	    BIT_AND264=(Token)match(input,BIT_AND,FOLLOW_BIT_AND_in_concat_expr3383); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    BIT_AND264_tree = (SLAST)adaptor.create(BIT_AND264);
            	    root_0 = (SLAST)adaptor.becomeRoot(BIT_AND264_tree, root_0);
            	    }
            	    pushFollow(FOLLOW_equality_expr_in_concat_expr3388);
            	    e2=equality_expr();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, e2.getTree());

            	    }
            	    break;

            	default :
            	    break loop87;
                }
            } while (true);

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(e1!=null?((Token)e1.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(e1!=null?((Token)e1.stop):null);
                  if ((e2!=null?input.toString(e2.start,e2.stop):null) != null) {
                    token = (CommonToken)(e2!=null?((Token)e2.stop):null);
                  }
                  endIndex = token.getStopIndex();
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "concat_expr"

    public static class equality_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "equality_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:664:1: equality_expr : e1= relational_expr ( ( '==' | '!=' | '===' | '!==' ) e2= relational_expr )* ;
    public final CompilerAstParser.equality_expr_return equality_expr() throws RecognitionException {
        CompilerAstParser.equality_expr_return retval = new CompilerAstParser.equality_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token set265=null;
        CompilerAstParser.relational_expr_return e1 = null;

        CompilerAstParser.relational_expr_return e2 = null;


        SLAST set265_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:674:3: (e1= relational_expr ( ( '==' | '!=' | '===' | '!==' ) e2= relational_expr )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:674:5: e1= relational_expr ( ( '==' | '!=' | '===' | '!==' ) e2= relational_expr )*
            {
            root_0 = (SLAST)adaptor.nil();

            pushFollow(FOLLOW_relational_expr_in_equality_expr3419);
            e1=relational_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, e1.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:674:24: ( ( '==' | '!=' | '===' | '!==' ) e2= relational_expr )*
            loop88:
            do {
                int alt88=2;
                int LA88_0 = input.LA(1);

                if ( ((LA88_0>=142 && LA88_0<=145)) ) {
                    alt88=1;
                }


                switch (alt88) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:674:25: ( '==' | '!=' | '===' | '!==' ) e2= relational_expr
            	    {
            	    set265=(Token)input.LT(1);
            	    set265=(Token)input.LT(1);
            	    if ( (input.LA(1)>=142 && input.LA(1)<=145) ) {
            	        input.consume();
            	        if ( state.backtracking==0 ) root_0 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(set265), root_0);
            	        state.errorRecovery=false;state.failed=false;
            	    }
            	    else {
            	        if (state.backtracking>0) {state.failed=true; return retval;}
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        throw mse;
            	    }

            	    pushFollow(FOLLOW_relational_expr_in_equality_expr3441);
            	    e2=relational_expr();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, e2.getTree());

            	    }
            	    break;

            	default :
            	    break loop88;
                }
            } while (true);

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(e1!=null?((Token)e1.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(e1!=null?((Token)e1.stop):null);
                  if ((e2!=null?input.toString(e2.start,e2.stop):null) != null) {
                    token = (CommonToken)(e2!=null?((Token)e2.stop):null);
                  }
                  endIndex = token.getStopIndex();
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "equality_expr"

    public static class relational_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "relational_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:686:1: relational_expr : e1= shift_expr ( ( '<' | '>' | '<=' | '>=' ) e2= shift_expr )* ;
    public final CompilerAstParser.relational_expr_return relational_expr() throws RecognitionException {
        CompilerAstParser.relational_expr_return retval = new CompilerAstParser.relational_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token set266=null;
        CompilerAstParser.shift_expr_return e1 = null;

        CompilerAstParser.shift_expr_return e2 = null;


        SLAST set266_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:696:3: (e1= shift_expr ( ( '<' | '>' | '<=' | '>=' ) e2= shift_expr )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:696:5: e1= shift_expr ( ( '<' | '>' | '<=' | '>=' ) e2= shift_expr )*
            {
            root_0 = (SLAST)adaptor.nil();

            pushFollow(FOLLOW_shift_expr_in_relational_expr3472);
            e1=shift_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, e1.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:696:19: ( ( '<' | '>' | '<=' | '>=' ) e2= shift_expr )*
            loop89:
            do {
                int alt89=2;
                int LA89_0 = input.LA(1);

                if ( ((LA89_0>=146 && LA89_0<=149)) ) {
                    alt89=1;
                }


                switch (alt89) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:696:20: ( '<' | '>' | '<=' | '>=' ) e2= shift_expr
            	    {
            	    set266=(Token)input.LT(1);
            	    set266=(Token)input.LT(1);
            	    if ( (input.LA(1)>=146 && input.LA(1)<=149) ) {
            	        input.consume();
            	        if ( state.backtracking==0 ) root_0 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(set266), root_0);
            	        state.errorRecovery=false;state.failed=false;
            	    }
            	    else {
            	        if (state.backtracking>0) {state.failed=true; return retval;}
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        throw mse;
            	    }

            	    pushFollow(FOLLOW_shift_expr_in_relational_expr3494);
            	    e2=shift_expr();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, e2.getTree());

            	    }
            	    break;

            	default :
            	    break loop89;
                }
            } while (true);

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(e1!=null?((Token)e1.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(e1!=null?((Token)e1.stop):null);
                  if ((e2!=null?input.toString(e2.start,e2.stop):null) != null) {
                    token = (CommonToken)(e2!=null?((Token)e2.stop):null);
                  }
                  endIndex = token.getStopIndex();
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "relational_expr"

    public static class shift_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "shift_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:708:1: shift_expr : e1= additive_expr ( ( '<<' | '>>' ) e2= additive_expr )* ;
    public final CompilerAstParser.shift_expr_return shift_expr() throws RecognitionException {
        CompilerAstParser.shift_expr_return retval = new CompilerAstParser.shift_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token set267=null;
        CompilerAstParser.additive_expr_return e1 = null;

        CompilerAstParser.additive_expr_return e2 = null;


        SLAST set267_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:718:3: (e1= additive_expr ( ( '<<' | '>>' ) e2= additive_expr )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:718:5: e1= additive_expr ( ( '<<' | '>>' ) e2= additive_expr )*
            {
            root_0 = (SLAST)adaptor.nil();

            pushFollow(FOLLOW_additive_expr_in_shift_expr3525);
            e1=additive_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, e1.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:718:22: ( ( '<<' | '>>' ) e2= additive_expr )*
            loop90:
            do {
                int alt90=2;
                int LA90_0 = input.LA(1);

                if ( ((LA90_0>=150 && LA90_0<=151)) ) {
                    alt90=1;
                }


                switch (alt90) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:718:23: ( '<<' | '>>' ) e2= additive_expr
            	    {
            	    set267=(Token)input.LT(1);
            	    set267=(Token)input.LT(1);
            	    if ( (input.LA(1)>=150 && input.LA(1)<=151) ) {
            	        input.consume();
            	        if ( state.backtracking==0 ) root_0 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(set267), root_0);
            	        state.errorRecovery=false;state.failed=false;
            	    }
            	    else {
            	        if (state.backtracking>0) {state.failed=true; return retval;}
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        throw mse;
            	    }

            	    pushFollow(FOLLOW_additive_expr_in_shift_expr3539);
            	    e2=additive_expr();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, e2.getTree());

            	    }
            	    break;

            	default :
            	    break loop90;
                }
            } while (true);

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(e1!=null?((Token)e1.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(e1!=null?((Token)e1.stop):null);
                  if ((e2!=null?input.toString(e2.start,e2.stop):null) != null) {
                    token = (CommonToken)(e2!=null?((Token)e2.stop):null);
                  }
                  endIndex = token.getStopIndex();
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "shift_expr"

    public static class additive_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "additive_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:730:1: additive_expr : e1= multiplicative_expr ( ( PLUS_T | MINUS_T ) e2= multiplicative_expr )* ;
    public final CompilerAstParser.additive_expr_return additive_expr() throws RecognitionException {
        CompilerAstParser.additive_expr_return retval = new CompilerAstParser.additive_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token set268=null;
        CompilerAstParser.multiplicative_expr_return e1 = null;

        CompilerAstParser.multiplicative_expr_return e2 = null;


        SLAST set268_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:740:3: (e1= multiplicative_expr ( ( PLUS_T | MINUS_T ) e2= multiplicative_expr )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:740:5: e1= multiplicative_expr ( ( PLUS_T | MINUS_T ) e2= multiplicative_expr )*
            {
            root_0 = (SLAST)adaptor.nil();

            pushFollow(FOLLOW_multiplicative_expr_in_additive_expr3570);
            e1=multiplicative_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, e1.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:740:28: ( ( PLUS_T | MINUS_T ) e2= multiplicative_expr )*
            loop91:
            do {
                int alt91=2;
                int LA91_0 = input.LA(1);

                if ( ((LA91_0>=PLUS_T && LA91_0<=MINUS_T)) ) {
                    alt91=1;
                }


                switch (alt91) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:740:29: ( PLUS_T | MINUS_T ) e2= multiplicative_expr
            	    {
            	    set268=(Token)input.LT(1);
            	    set268=(Token)input.LT(1);
            	    if ( (input.LA(1)>=PLUS_T && input.LA(1)<=MINUS_T) ) {
            	        input.consume();
            	        if ( state.backtracking==0 ) root_0 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(set268), root_0);
            	        state.errorRecovery=false;state.failed=false;
            	    }
            	    else {
            	        if (state.backtracking>0) {state.failed=true; return retval;}
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        throw mse;
            	    }

            	    pushFollow(FOLLOW_multiplicative_expr_in_additive_expr3584);
            	    e2=multiplicative_expr();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, e2.getTree());

            	    }
            	    break;

            	default :
            	    break loop91;
                }
            } while (true);

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(e1!=null?((Token)e1.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(e1!=null?((Token)e1.stop):null);
                  if ((e2!=null?input.toString(e2.start,e2.stop):null) != null) {
                    token = (CommonToken)(e2!=null?((Token)e2.stop):null);
                  }
                  endIndex = token.getStopIndex();
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "additive_expr"

    public static class multiplicative_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "multiplicative_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:752:1: multiplicative_expr : e1= cast_expr ( ( MUL_T | DIV_T | '%' ) e2= cast_expr )* ;
    public final CompilerAstParser.multiplicative_expr_return multiplicative_expr() throws RecognitionException {
        CompilerAstParser.multiplicative_expr_return retval = new CompilerAstParser.multiplicative_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token set269=null;
        CompilerAstParser.cast_expr_return e1 = null;

        CompilerAstParser.cast_expr_return e2 = null;


        SLAST set269_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:762:3: (e1= cast_expr ( ( MUL_T | DIV_T | '%' ) e2= cast_expr )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:762:5: e1= cast_expr ( ( MUL_T | DIV_T | '%' ) e2= cast_expr )*
            {
            root_0 = (SLAST)adaptor.nil();

            pushFollow(FOLLOW_cast_expr_in_multiplicative_expr3615);
            e1=cast_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, e1.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:762:18: ( ( MUL_T | DIV_T | '%' ) e2= cast_expr )*
            loop92:
            do {
                int alt92=2;
                int LA92_0 = input.LA(1);

                if ( ((LA92_0>=MUL_T && LA92_0<=DIV_T)||LA92_0==152) ) {
                    alt92=1;
                }


                switch (alt92) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:762:19: ( MUL_T | DIV_T | '%' ) e2= cast_expr
            	    {
            	    set269=(Token)input.LT(1);
            	    set269=(Token)input.LT(1);
            	    if ( (input.LA(1)>=MUL_T && input.LA(1)<=DIV_T)||input.LA(1)==152 ) {
            	        input.consume();
            	        if ( state.backtracking==0 ) root_0 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(set269), root_0);
            	        state.errorRecovery=false;state.failed=false;
            	    }
            	    else {
            	        if (state.backtracking>0) {state.failed=true; return retval;}
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        throw mse;
            	    }

            	    pushFollow(FOLLOW_cast_expr_in_multiplicative_expr3633);
            	    e2=cast_expr();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, e2.getTree());

            	    }
            	    break;

            	default :
            	    break loop92;
                }
            } while (true);

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(e1!=null?((Token)e1.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(e1!=null?((Token)e1.stop):null);
                  if ((e2!=null?input.toString(e2.start,e2.stop):null) != null) {
                    token = (CommonToken)(e2!=null?((Token)e2.stop):null);
                  }
                  endIndex = token.getStopIndex();
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "multiplicative_expr"

    public static class cast_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "cast_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:774:1: cast_expr : ( LEFT_PARETHESIS cast_option RIGHT_PARETHESIS )* unary_expr ;
    public final CompilerAstParser.cast_expr_return cast_expr() throws RecognitionException {
        CompilerAstParser.cast_expr_return retval = new CompilerAstParser.cast_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token LEFT_PARETHESIS270=null;
        Token RIGHT_PARETHESIS272=null;
        CompilerAstParser.cast_option_return cast_option271 = null;

        CompilerAstParser.unary_expr_return unary_expr273 = null;


        SLAST LEFT_PARETHESIS270_tree=null;
        SLAST RIGHT_PARETHESIS272_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:784:3: ( ( LEFT_PARETHESIS cast_option RIGHT_PARETHESIS )* unary_expr )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:784:5: ( LEFT_PARETHESIS cast_option RIGHT_PARETHESIS )* unary_expr
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:784:5: ( LEFT_PARETHESIS cast_option RIGHT_PARETHESIS )*
            loop93:
            do {
                int alt93=2;
                int LA93_0 = input.LA(1);

                if ( (LA93_0==LEFT_PARETHESIS) ) {
                    switch ( input.LA(2) ) {
                    case 163:
                        {
                        int LA93_3 = input.LA(3);

                        if ( (LA93_3==RIGHT_PARETHESIS) ) {
                            alt93=1;
                        }


                        }
                        break;
                    case 161:
                        {
                        int LA93_4 = input.LA(3);

                        if ( (LA93_4==RIGHT_PARETHESIS) ) {
                            alt93=1;
                        }


                        }
                        break;
                    case 160:
                        {
                        int LA93_5 = input.LA(3);

                        if ( (LA93_5==RIGHT_PARETHESIS) ) {
                            alt93=1;
                        }


                        }
                        break;
                    case 153:
                    case 154:
                    case 155:
                    case 156:
                    case 157:
                    case 158:
                    case 159:
                    case 162:
                        {
                        alt93=1;
                        }
                        break;

                    }

                }


                switch (alt93) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:784:6: LEFT_PARETHESIS cast_option RIGHT_PARETHESIS
            	    {
            	    LEFT_PARETHESIS270=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_cast_expr3663); if (state.failed) return retval;
            	    pushFollow(FOLLOW_cast_option_in_cast_expr3666);
            	    cast_option271=cast_option();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) root_0 = (SLAST)adaptor.becomeRoot(cast_option271.getTree(), root_0);
            	    RIGHT_PARETHESIS272=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_cast_expr3669); if (state.failed) return retval;

            	    }
            	    break;

            	default :
            	    break loop93;
                }
            } while (true);

            pushFollow(FOLLOW_unary_expr_in_cast_expr3674);
            unary_expr273=unary_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, unary_expr273.getTree());
            if ( state.backtracking==0 ) {

                  token = (CommonToken)(unary_expr273!=null?((Token)unary_expr273.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(unary_expr273!=null?((Token)unary_expr273.stop):null);
                  endIndex = token.getStopIndex();
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "cast_expr"

    public static class cast_option_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "cast_option"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:793:1: cast_option : ( 'bool' | 'boolean' | 'int' | 'float' | 'double' | 'real' | 'string' | 'unset' | 'clone' | 'object' | 'array' );
    public final CompilerAstParser.cast_option_return cast_option() throws RecognitionException {
        CompilerAstParser.cast_option_return retval = new CompilerAstParser.cast_option_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token set274=null;

        SLAST set274_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:794:1: ( 'bool' | 'boolean' | 'int' | 'float' | 'double' | 'real' | 'string' | 'unset' | 'clone' | 'object' | 'array' )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:
            {
            root_0 = (SLAST)adaptor.nil();

            set274=(Token)input.LT(1);
            if ( (input.LA(1)>=153 && input.LA(1)<=163) ) {
                input.consume();
                if ( state.backtracking==0 ) adaptor.addChild(root_0, (SLAST)adaptor.create(set274));
                state.errorRecovery=false;state.failed=false;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                MismatchedSetException mse = new MismatchedSetException(null,input);
                throw mse;
            }


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "cast_option"

    public static class unary_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "unary_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:807:1: unary_expr : ( ( '&' | PLUS_T | MINUS_T | TILDA_T | '!' ) )* prefix_inc_dec_expr ;
    public final CompilerAstParser.unary_expr_return unary_expr() throws RecognitionException {
        CompilerAstParser.unary_expr_return retval = new CompilerAstParser.unary_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token set275=null;
        CompilerAstParser.prefix_inc_dec_expr_return prefix_inc_dec_expr276 = null;


        SLAST set275_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:817:3: ( ( ( '&' | PLUS_T | MINUS_T | TILDA_T | '!' ) )* prefix_inc_dec_expr )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:817:5: ( ( '&' | PLUS_T | MINUS_T | TILDA_T | '!' ) )* prefix_inc_dec_expr
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:817:5: ( ( '&' | PLUS_T | MINUS_T | TILDA_T | '!' ) )*
            loop94:
            do {
                int alt94=2;
                int LA94_0 = input.LA(1);

                if ( ((LA94_0>=BIT_AND && LA94_0<=MINUS_T)||LA94_0==TILDA_T||LA94_0==164) ) {
                    alt94=1;
                }


                switch (alt94) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:817:6: ( '&' | PLUS_T | MINUS_T | TILDA_T | '!' )
            	    {
            	    set275=(Token)input.LT(1);
            	    set275=(Token)input.LT(1);
            	    if ( (input.LA(1)>=BIT_AND && input.LA(1)<=MINUS_T)||input.LA(1)==TILDA_T||input.LA(1)==164 ) {
            	        input.consume();
            	        if ( state.backtracking==0 ) root_0 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(set275), root_0);
            	        state.errorRecovery=false;state.failed=false;
            	    }
            	    else {
            	        if (state.backtracking>0) {state.failed=true; return retval;}
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        throw mse;
            	    }


            	    }
            	    break;

            	default :
            	    break loop94;
                }
            } while (true);

            pushFollow(FOLLOW_prefix_inc_dec_expr_in_unary_expr3802);
            prefix_inc_dec_expr276=prefix_inc_dec_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, prefix_inc_dec_expr276.getTree());
            if ( state.backtracking==0 ) {

                  token = (CommonToken)(prefix_inc_dec_expr276!=null?((Token)prefix_inc_dec_expr276.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(prefix_inc_dec_expr276!=null?((Token)prefix_inc_dec_expr276.stop):null);
                  endIndex = token.getStopIndex();
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "unary_expr"

    public static class prefix_inc_dec_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "prefix_inc_dec_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:827:1: prefix_inc_dec_expr : ( ( '++' | '--' )* ) post_inc_dec_expr ;
    public final CompilerAstParser.prefix_inc_dec_expr_return prefix_inc_dec_expr() throws RecognitionException {
        CompilerAstParser.prefix_inc_dec_expr_return retval = new CompilerAstParser.prefix_inc_dec_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token set277=null;
        CompilerAstParser.post_inc_dec_expr_return post_inc_dec_expr278 = null;


        SLAST set277_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:837:3: ( ( ( '++' | '--' )* ) post_inc_dec_expr )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:837:5: ( ( '++' | '--' )* ) post_inc_dec_expr
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:837:5: ( ( '++' | '--' )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:837:6: ( '++' | '--' )*
            {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:837:6: ( '++' | '--' )*
            loop95:
            do {
                int alt95=2;
                int LA95_0 = input.LA(1);

                if ( ((LA95_0>=165 && LA95_0<=166)) ) {
                    alt95=1;
                }


                switch (alt95) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:
            	    {
            	    set277=(Token)input.LT(1);
            	    if ( (input.LA(1)>=165 && input.LA(1)<=166) ) {
            	        input.consume();
            	        if ( state.backtracking==0 ) adaptor.addChild(root_0, (SLAST)adaptor.create(set277));
            	        state.errorRecovery=false;state.failed=false;
            	    }
            	    else {
            	        if (state.backtracking>0) {state.failed=true; return retval;}
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        throw mse;
            	    }


            	    }
            	    break;

            	default :
            	    break loop95;
                }
            } while (true);


            }

            pushFollow(FOLLOW_post_inc_dec_expr_in_prefix_inc_dec_expr3842);
            post_inc_dec_expr278=post_inc_dec_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, post_inc_dec_expr278.getTree());
            if ( state.backtracking==0 ) {

                  token = (CommonToken)(post_inc_dec_expr278!=null?((Token)post_inc_dec_expr278.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(post_inc_dec_expr278!=null?((Token)post_inc_dec_expr278.stop):null);
                  endIndex = token.getStopIndex();
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "prefix_inc_dec_expr"

    public static class post_inc_dec_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "post_inc_dec_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:846:1: post_inc_dec_expr : instance_expr ( ( '++' | '--' )* ) ;
    public final CompilerAstParser.post_inc_dec_expr_return post_inc_dec_expr() throws RecognitionException {
        CompilerAstParser.post_inc_dec_expr_return retval = new CompilerAstParser.post_inc_dec_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token set280=null;
        CompilerAstParser.instance_expr_return instance_expr279 = null;


        SLAST set280_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:856:3: ( instance_expr ( ( '++' | '--' )* ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:856:5: instance_expr ( ( '++' | '--' )* )
            {
            root_0 = (SLAST)adaptor.nil();

            pushFollow(FOLLOW_instance_expr_in_post_inc_dec_expr3871);
            instance_expr279=instance_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, instance_expr279.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:856:19: ( ( '++' | '--' )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:856:20: ( '++' | '--' )*
            {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:856:20: ( '++' | '--' )*
            loop96:
            do {
                int alt96=2;
                int LA96_0 = input.LA(1);

                if ( ((LA96_0>=165 && LA96_0<=166)) ) {
                    alt96=1;
                }


                switch (alt96) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:
            	    {
            	    set280=(Token)input.LT(1);
            	    if ( (input.LA(1)>=165 && input.LA(1)<=166) ) {
            	        input.consume();
            	        if ( state.backtracking==0 ) adaptor.addChild(root_0, (SLAST)adaptor.create(set280));
            	        state.errorRecovery=false;state.failed=false;
            	    }
            	    else {
            	        if (state.backtracking>0) {state.failed=true; return retval;}
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        throw mse;
            	    }


            	    }
            	    break;

            	default :
            	    break loop96;
                }
            } while (true);


            }

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(instance_expr279!=null?((Token)instance_expr279.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(instance_expr279!=null?((Token)instance_expr279.stop):null);
                  endIndex = token.getStopIndex();
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "post_inc_dec_expr"

    public static class instance_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "instance_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:865:1: instance_expr : atom_expr ( 'instanceof' class_name_reference )? ;
    public final CompilerAstParser.instance_expr_return instance_expr() throws RecognitionException {
        CompilerAstParser.instance_expr_return retval = new CompilerAstParser.instance_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token string_literal282=null;
        CompilerAstParser.atom_expr_return atom_expr281 = null;

        CompilerAstParser.class_name_reference_return class_name_reference283 = null;


        SLAST string_literal282_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:875:3: ( atom_expr ( 'instanceof' class_name_reference )? )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:875:5: atom_expr ( 'instanceof' class_name_reference )?
            {
            root_0 = (SLAST)adaptor.nil();

            pushFollow(FOLLOW_atom_expr_in_instance_expr3910);
            atom_expr281=atom_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, atom_expr281.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:875:15: ( 'instanceof' class_name_reference )?
            int alt97=2;
            int LA97_0 = input.LA(1);

            if ( (LA97_0==167) ) {
                alt97=1;
            }
            switch (alt97) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:875:16: 'instanceof' class_name_reference
                    {
                    string_literal282=(Token)match(input,167,FOLLOW_167_in_instance_expr3913); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    string_literal282_tree = (SLAST)adaptor.create(string_literal282);
                    root_0 = (SLAST)adaptor.becomeRoot(string_literal282_tree, root_0);
                    }
                    pushFollow(FOLLOW_class_name_reference_in_instance_expr3916);
                    class_name_reference283=class_name_reference();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, class_name_reference283.getTree());

                    }
                    break;

            }

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(atom_expr281!=null?((Token)atom_expr281.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(atom_expr281!=null?((Token)atom_expr281.stop):null);
                  endIndex = token.getStopIndex();
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "instance_expr"

    public static class atom_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "atom_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:884:1: atom_expr : ( ( '@' )? variable | ( '@' )? scalar | LEFT_PARETHESIS expression RIGHT_PARETHESIS | 'list' LEFT_PARETHESIS assignment_list RIGHT_PARETHESIS -> ^( 'list' assignment_list ) | 'array' LEFT_PARETHESIS ( array_pair_list )? RIGHT_PARETHESIS -> ^( ARRAY_DECL ( array_pair_list )? ) | 'new' class_name_reference -> ^( 'new' class_name_reference ) | 'clone' variable -> ^( 'clone' variable ) | 'exit' ( LEFT_PARETHESIS ( expression )? RIGHT_PARETHESIS )? -> ^( 'exit' ( expression )? ) | 'unset' LEFT_PARETHESIS variable_list RIGHT_PARETHESIS -> ^( 'unset' variable_list ) | lambda_function_declaration | BACKTRICKLITERAL );
    public final CompilerAstParser.atom_expr_return atom_expr() throws RecognitionException {
        CompilerAstParser.atom_expr_return retval = new CompilerAstParser.atom_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token char_literal284=null;
        Token char_literal286=null;
        Token LEFT_PARETHESIS288=null;
        Token RIGHT_PARETHESIS290=null;
        Token string_literal291=null;
        Token LEFT_PARETHESIS292=null;
        Token RIGHT_PARETHESIS294=null;
        Token string_literal295=null;
        Token LEFT_PARETHESIS296=null;
        Token RIGHT_PARETHESIS298=null;
        Token string_literal299=null;
        Token string_literal301=null;
        Token string_literal303=null;
        Token LEFT_PARETHESIS304=null;
        Token RIGHT_PARETHESIS306=null;
        Token string_literal307=null;
        Token LEFT_PARETHESIS308=null;
        Token RIGHT_PARETHESIS310=null;
        Token BACKTRICKLITERAL312=null;
        CompilerAstParser.variable_return variable285 = null;

        CompilerAstParser.scalar_return scalar287 = null;

        CompilerAstParser.expression_return expression289 = null;

        CompilerAstParser.assignment_list_return assignment_list293 = null;

        CompilerAstParser.array_pair_list_return array_pair_list297 = null;

        CompilerAstParser.class_name_reference_return class_name_reference300 = null;

        CompilerAstParser.variable_return variable302 = null;

        CompilerAstParser.expression_return expression305 = null;

        CompilerAstParser.variable_list_return variable_list309 = null;

        CompilerAstParser.lambda_function_declaration_return lambda_function_declaration311 = null;


        SLAST char_literal284_tree=null;
        SLAST char_literal286_tree=null;
        SLAST LEFT_PARETHESIS288_tree=null;
        SLAST RIGHT_PARETHESIS290_tree=null;
        SLAST string_literal291_tree=null;
        SLAST LEFT_PARETHESIS292_tree=null;
        SLAST RIGHT_PARETHESIS294_tree=null;
        SLAST string_literal295_tree=null;
        SLAST LEFT_PARETHESIS296_tree=null;
        SLAST RIGHT_PARETHESIS298_tree=null;
        SLAST string_literal299_tree=null;
        SLAST string_literal301_tree=null;
        SLAST string_literal303_tree=null;
        SLAST LEFT_PARETHESIS304_tree=null;
        SLAST RIGHT_PARETHESIS306_tree=null;
        SLAST string_literal307_tree=null;
        SLAST LEFT_PARETHESIS308_tree=null;
        SLAST RIGHT_PARETHESIS310_tree=null;
        SLAST BACKTRICKLITERAL312_tree=null;
        RewriteRuleTokenStream stream_161=new RewriteRuleTokenStream(adaptor,"token 161");
        RewriteRuleTokenStream stream_170=new RewriteRuleTokenStream(adaptor,"token 170");
        RewriteRuleTokenStream stream_171=new RewriteRuleTokenStream(adaptor,"token 171");
        RewriteRuleTokenStream stream_163=new RewriteRuleTokenStream(adaptor,"token 163");
        RewriteRuleTokenStream stream_LEFT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token LEFT_PARETHESIS");
        RewriteRuleTokenStream stream_160=new RewriteRuleTokenStream(adaptor,"token 160");
        RewriteRuleTokenStream stream_169=new RewriteRuleTokenStream(adaptor,"token 169");
        RewriteRuleTokenStream stream_RIGHT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token RIGHT_PARETHESIS");
        RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");
        RewriteRuleSubtreeStream stream_variable_list=new RewriteRuleSubtreeStream(adaptor,"rule variable_list");
        RewriteRuleSubtreeStream stream_array_pair_list=new RewriteRuleSubtreeStream(adaptor,"rule array_pair_list");
        RewriteRuleSubtreeStream stream_class_name_reference=new RewriteRuleSubtreeStream(adaptor,"rule class_name_reference");
        RewriteRuleSubtreeStream stream_assignment_list=new RewriteRuleSubtreeStream(adaptor,"rule assignment_list");
        RewriteRuleSubtreeStream stream_variable=new RewriteRuleSubtreeStream(adaptor,"rule variable");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:894:3: ( ( '@' )? variable | ( '@' )? scalar | LEFT_PARETHESIS expression RIGHT_PARETHESIS | 'list' LEFT_PARETHESIS assignment_list RIGHT_PARETHESIS -> ^( 'list' assignment_list ) | 'array' LEFT_PARETHESIS ( array_pair_list )? RIGHT_PARETHESIS -> ^( ARRAY_DECL ( array_pair_list )? ) | 'new' class_name_reference -> ^( 'new' class_name_reference ) | 'clone' variable -> ^( 'clone' variable ) | 'exit' ( LEFT_PARETHESIS ( expression )? RIGHT_PARETHESIS )? -> ^( 'exit' ( expression )? ) | 'unset' LEFT_PARETHESIS variable_list RIGHT_PARETHESIS -> ^( 'unset' variable_list ) | lambda_function_declaration | BACKTRICKLITERAL )
            int alt103=11;
            alt103 = dfa103.predict(input);
            switch (alt103) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:894:6: ( '@' )? variable
                    {
                    root_0 = (SLAST)adaptor.nil();

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:894:6: ( '@' )?
                    int alt98=2;
                    int LA98_0 = input.LA(1);

                    if ( (LA98_0==168) ) {
                        alt98=1;
                    }
                    switch (alt98) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:894:6: '@'
                            {
                            char_literal284=(Token)match(input,168,FOLLOW_168_in_atom_expr3948); if (state.failed) return retval;
                            if ( state.backtracking==0 ) {
                            char_literal284_tree = (SLAST)adaptor.create(char_literal284);
                            adaptor.addChild(root_0, char_literal284_tree);
                            }

                            }
                            break;

                    }

                    pushFollow(FOLLOW_variable_in_atom_expr3951);
                    variable285=variable();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, variable285.getTree());

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:895:6: ( '@' )? scalar
                    {
                    root_0 = (SLAST)adaptor.nil();

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:895:6: ( '@' )?
                    int alt99=2;
                    int LA99_0 = input.LA(1);

                    if ( (LA99_0==168) ) {
                        alt99=1;
                    }
                    switch (alt99) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:895:6: '@'
                            {
                            char_literal286=(Token)match(input,168,FOLLOW_168_in_atom_expr3958); if (state.failed) return retval;
                            if ( state.backtracking==0 ) {
                            char_literal286_tree = (SLAST)adaptor.create(char_literal286);
                            adaptor.addChild(root_0, char_literal286_tree);
                            }

                            }
                            break;

                    }

                    pushFollow(FOLLOW_scalar_in_atom_expr3961);
                    scalar287=scalar();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, scalar287.getTree());

                    }
                    break;
                case 3 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:896:6: LEFT_PARETHESIS expression RIGHT_PARETHESIS
                    {
                    root_0 = (SLAST)adaptor.nil();

                    LEFT_PARETHESIS288=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_atom_expr3968); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    LEFT_PARETHESIS288_tree = (SLAST)adaptor.create(LEFT_PARETHESIS288);
                    adaptor.addChild(root_0, LEFT_PARETHESIS288_tree);
                    }
                    pushFollow(FOLLOW_expression_in_atom_expr3970);
                    expression289=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, expression289.getTree());
                    RIGHT_PARETHESIS290=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_atom_expr3972); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    RIGHT_PARETHESIS290_tree = (SLAST)adaptor.create(RIGHT_PARETHESIS290);
                    adaptor.addChild(root_0, RIGHT_PARETHESIS290_tree);
                    }

                    }
                    break;
                case 4 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:897:6: 'list' LEFT_PARETHESIS assignment_list RIGHT_PARETHESIS
                    {
                    string_literal291=(Token)match(input,169,FOLLOW_169_in_atom_expr3979); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_169.add(string_literal291);

                    LEFT_PARETHESIS292=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_atom_expr3981); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS292);

                    pushFollow(FOLLOW_assignment_list_in_atom_expr3983);
                    assignment_list293=assignment_list();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_assignment_list.add(assignment_list293.getTree());
                    RIGHT_PARETHESIS294=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_atom_expr3985); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS294);



                    // AST REWRITE
                    // elements: 169, assignment_list
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 897:66: -> ^( 'list' assignment_list )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:897:70: ^( 'list' assignment_list )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_169.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_assignment_list.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 5 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:898:6: 'array' LEFT_PARETHESIS ( array_pair_list )? RIGHT_PARETHESIS
                    {
                    string_literal295=(Token)match(input,163,FOLLOW_163_in_atom_expr4005); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_163.add(string_literal295);

                    LEFT_PARETHESIS296=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_atom_expr4007); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS296);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:898:30: ( array_pair_list )?
                    int alt100=2;
                    int LA100_0 = input.LA(1);

                    if ( (LA100_0==LEFT_PARETHESIS||LA100_0==IDENTIFIER||LA100_0==STRINGLITERAL||(LA100_0>=BIT_AND && LA100_0<=MINUS_T)||(LA100_0>=TILDA_T && LA100_0<=BACKTRICKLITERAL)||(LA100_0>=DOLLAR_T && LA100_0<=DOUBLELITERRAL)||LA100_0==95||(LA100_0>=160 && LA100_0<=161)||(LA100_0>=163 && LA100_0<=166)||(LA100_0>=168 && LA100_0<=171)||(LA100_0>=173 && LA100_0<=178)) ) {
                        alt100=1;
                    }
                    switch (alt100) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:898:30: array_pair_list
                            {
                            pushFollow(FOLLOW_array_pair_list_in_atom_expr4009);
                            array_pair_list297=array_pair_list();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_array_pair_list.add(array_pair_list297.getTree());

                            }
                            break;

                    }

                    RIGHT_PARETHESIS298=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_atom_expr4012); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS298);

                    if ( state.backtracking==0 ) {

                            token = (CommonToken)LEFT_PARETHESIS296;
                      	    startIndex = token.getStartIndex();
                      	    token = (CommonToken)RIGHT_PARETHESIS298;
                      	    endIndex = token.getStopIndex();
                          
                    }


                    // AST REWRITE
                    // elements: array_pair_list
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 905:7: -> ^( ARRAY_DECL ( array_pair_list )? )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:905:11: ^( ARRAY_DECL ( array_pair_list )? )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(ARRAY_DECL, "ARRAY_DECL"), root_1);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:905:24: ( array_pair_list )?
                        if ( stream_array_pair_list.hasNext() ) {
                            adaptor.addChild(root_1, stream_array_pair_list.nextTree());

                        }
                        stream_array_pair_list.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 6 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:906:6: 'new' class_name_reference
                    {
                    string_literal299=(Token)match(input,170,FOLLOW_170_in_atom_expr4041); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_170.add(string_literal299);

                    pushFollow(FOLLOW_class_name_reference_in_atom_expr4043);
                    class_name_reference300=class_name_reference();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_class_name_reference.add(class_name_reference300.getTree());


                    // AST REWRITE
                    // elements: class_name_reference, 170
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 906:33: -> ^( 'new' class_name_reference )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:906:37: ^( 'new' class_name_reference )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_170.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_class_name_reference.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 7 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:908:6: 'clone' variable
                    {
                    string_literal301=(Token)match(input,161,FOLLOW_161_in_atom_expr4060); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_161.add(string_literal301);

                    pushFollow(FOLLOW_variable_in_atom_expr4062);
                    variable302=variable();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_variable.add(variable302.getTree());


                    // AST REWRITE
                    // elements: variable, 161
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 908:29: -> ^( 'clone' variable )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:908:33: ^( 'clone' variable )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_161.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_variable.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 8 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:909:6: 'exit' ( LEFT_PARETHESIS ( expression )? RIGHT_PARETHESIS )?
                    {
                    string_literal303=(Token)match(input,171,FOLLOW_171_in_atom_expr4084); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_171.add(string_literal303);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:909:13: ( LEFT_PARETHESIS ( expression )? RIGHT_PARETHESIS )?
                    int alt102=2;
                    int LA102_0 = input.LA(1);

                    if ( (LA102_0==LEFT_PARETHESIS) ) {
                        alt102=1;
                    }
                    switch (alt102) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:909:14: LEFT_PARETHESIS ( expression )? RIGHT_PARETHESIS
                            {
                            LEFT_PARETHESIS304=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_atom_expr4087); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS304);

                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:909:30: ( expression )?
                            int alt101=2;
                            int LA101_0 = input.LA(1);

                            if ( (LA101_0==LEFT_PARETHESIS||LA101_0==IDENTIFIER||LA101_0==STRINGLITERAL||(LA101_0>=BIT_AND && LA101_0<=MINUS_T)||(LA101_0>=TILDA_T && LA101_0<=BACKTRICKLITERAL)||(LA101_0>=DOLLAR_T && LA101_0<=DOUBLELITERRAL)||LA101_0==95||(LA101_0>=160 && LA101_0<=161)||(LA101_0>=163 && LA101_0<=166)||(LA101_0>=168 && LA101_0<=171)||(LA101_0>=173 && LA101_0<=178)) ) {
                                alt101=1;
                            }
                            switch (alt101) {
                                case 1 :
                                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:909:30: expression
                                    {
                                    pushFollow(FOLLOW_expression_in_atom_expr4089);
                                    expression305=expression();

                                    state._fsp--;
                                    if (state.failed) return retval;
                                    if ( state.backtracking==0 ) stream_expression.add(expression305.getTree());

                                    }
                                    break;

                            }

                            RIGHT_PARETHESIS306=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_atom_expr4092); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS306);


                            }
                            break;

                    }



                    // AST REWRITE
                    // elements: 171, expression
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 909:62: -> ^( 'exit' ( expression )? )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:909:66: ^( 'exit' ( expression )? )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_171.nextNode(), root_1);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:909:75: ( expression )?
                        if ( stream_expression.hasNext() ) {
                            adaptor.addChild(root_1, stream_expression.nextTree());

                        }
                        stream_expression.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 9 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:910:6: 'unset' LEFT_PARETHESIS variable_list RIGHT_PARETHESIS
                    {
                    string_literal307=(Token)match(input,160,FOLLOW_160_in_atom_expr4112); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_160.add(string_literal307);

                    LEFT_PARETHESIS308=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_atom_expr4114); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS308);

                    pushFollow(FOLLOW_variable_list_in_atom_expr4116);
                    variable_list309=variable_list();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_variable_list.add(variable_list309.getTree());
                    RIGHT_PARETHESIS310=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_atom_expr4118); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS310);



                    // AST REWRITE
                    // elements: variable_list, 160
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 910:62: -> ^( 'unset' variable_list )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:910:66: ^( 'unset' variable_list )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_160.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_variable_list.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 10 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:911:6: lambda_function_declaration
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_lambda_function_declaration_in_atom_expr4135);
                    lambda_function_declaration311=lambda_function_declaration();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, lambda_function_declaration311.getTree());

                    }
                    break;
                case 11 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:912:6: BACKTRICKLITERAL
                    {
                    root_0 = (SLAST)adaptor.nil();

                    BACKTRICKLITERAL312=(Token)match(input,BACKTRICKLITERAL,FOLLOW_BACKTRICKLITERAL_in_atom_expr4142); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    BACKTRICKLITERAL312_tree = (SLAST)adaptor.create(BACKTRICKLITERAL312);
                    adaptor.addChild(root_0, BACKTRICKLITERAL312_tree);
                    }

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "atom_expr"

    public static class lambda_function_declaration_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "lambda_function_declaration"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:916:1: lambda_function_declaration : 'function' ( '&' )? LEFT_PARETHESIS ( parameter_list )? RIGHT_PARETHESIS ( 'use' LEFT_PARETHESIS ( expr_list )? RIGHT_PARETHESIS )? block -> ^( METHOD_DECL ( '&' )? ( parameter_list )? ( ^( 'use' ( expr_list )? ) )? block ) ;
    public final CompilerAstParser.lambda_function_declaration_return lambda_function_declaration() throws RecognitionException {
        CompilerAstParser.lambda_function_declaration_return retval = new CompilerAstParser.lambda_function_declaration_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token string_literal313=null;
        Token char_literal314=null;
        Token LEFT_PARETHESIS315=null;
        Token RIGHT_PARETHESIS317=null;
        Token string_literal318=null;
        Token LEFT_PARETHESIS319=null;
        Token RIGHT_PARETHESIS321=null;
        CompilerAstParser.parameter_list_return parameter_list316 = null;

        CompilerAstParser.expr_list_return expr_list320 = null;

        CompilerAstParser.block_return block322 = null;


        SLAST string_literal313_tree=null;
        SLAST char_literal314_tree=null;
        SLAST LEFT_PARETHESIS315_tree=null;
        SLAST RIGHT_PARETHESIS317_tree=null;
        SLAST string_literal318_tree=null;
        SLAST LEFT_PARETHESIS319_tree=null;
        SLAST RIGHT_PARETHESIS321_tree=null;
        RewriteRuleTokenStream stream_95=new RewriteRuleTokenStream(adaptor,"token 95");
        RewriteRuleTokenStream stream_LEFT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token LEFT_PARETHESIS");
        RewriteRuleTokenStream stream_BIT_AND=new RewriteRuleTokenStream(adaptor,"token BIT_AND");
        RewriteRuleTokenStream stream_111=new RewriteRuleTokenStream(adaptor,"token 111");
        RewriteRuleTokenStream stream_RIGHT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token RIGHT_PARETHESIS");
        RewriteRuleSubtreeStream stream_block=new RewriteRuleSubtreeStream(adaptor,"rule block");
        RewriteRuleSubtreeStream stream_parameter_list=new RewriteRuleSubtreeStream(adaptor,"rule parameter_list");
        RewriteRuleSubtreeStream stream_expr_list=new RewriteRuleSubtreeStream(adaptor,"rule expr_list");
        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:917:3: ( 'function' ( '&' )? LEFT_PARETHESIS ( parameter_list )? RIGHT_PARETHESIS ( 'use' LEFT_PARETHESIS ( expr_list )? RIGHT_PARETHESIS )? block -> ^( METHOD_DECL ( '&' )? ( parameter_list )? ( ^( 'use' ( expr_list )? ) )? block ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:917:5: 'function' ( '&' )? LEFT_PARETHESIS ( parameter_list )? RIGHT_PARETHESIS ( 'use' LEFT_PARETHESIS ( expr_list )? RIGHT_PARETHESIS )? block
            {
            string_literal313=(Token)match(input,95,FOLLOW_95_in_lambda_function_declaration4157); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_95.add(string_literal313);

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:917:16: ( '&' )?
            int alt104=2;
            int LA104_0 = input.LA(1);

            if ( (LA104_0==BIT_AND) ) {
                alt104=1;
            }
            switch (alt104) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:917:16: '&'
                    {
                    char_literal314=(Token)match(input,BIT_AND,FOLLOW_BIT_AND_in_lambda_function_declaration4159); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_BIT_AND.add(char_literal314);


                    }
                    break;

            }

            LEFT_PARETHESIS315=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_lambda_function_declaration4162); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS315);

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:917:37: ( parameter_list )?
            int alt105=2;
            int LA105_0 = input.LA(1);

            if ( (LA105_0==IDENTIFIER||LA105_0==BIT_AND||LA105_0==DOLLAR_T||LA105_0==113||(LA105_0>=153 && LA105_0<=163)) ) {
                alt105=1;
            }
            switch (alt105) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:917:37: parameter_list
                    {
                    pushFollow(FOLLOW_parameter_list_in_lambda_function_declaration4164);
                    parameter_list316=parameter_list();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_parameter_list.add(parameter_list316.getTree());

                    }
                    break;

            }

            RIGHT_PARETHESIS317=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_lambda_function_declaration4167); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS317);

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:917:70: ( 'use' LEFT_PARETHESIS ( expr_list )? RIGHT_PARETHESIS )?
            int alt107=2;
            int LA107_0 = input.LA(1);

            if ( (LA107_0==111) ) {
                alt107=1;
            }
            switch (alt107) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:917:71: 'use' LEFT_PARETHESIS ( expr_list )? RIGHT_PARETHESIS
                    {
                    string_literal318=(Token)match(input,111,FOLLOW_111_in_lambda_function_declaration4170); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_111.add(string_literal318);

                    LEFT_PARETHESIS319=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_lambda_function_declaration4172); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS319);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:917:93: ( expr_list )?
                    int alt106=2;
                    int LA106_0 = input.LA(1);

                    if ( (LA106_0==LEFT_PARETHESIS||LA106_0==IDENTIFIER||LA106_0==STRINGLITERAL||(LA106_0>=BIT_AND && LA106_0<=MINUS_T)||(LA106_0>=TILDA_T && LA106_0<=BACKTRICKLITERAL)||(LA106_0>=DOLLAR_T && LA106_0<=DOUBLELITERRAL)||LA106_0==95||(LA106_0>=160 && LA106_0<=161)||(LA106_0>=163 && LA106_0<=166)||(LA106_0>=168 && LA106_0<=171)||(LA106_0>=173 && LA106_0<=178)) ) {
                        alt106=1;
                    }
                    switch (alt106) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:917:93: expr_list
                            {
                            pushFollow(FOLLOW_expr_list_in_lambda_function_declaration4174);
                            expr_list320=expr_list();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_expr_list.add(expr_list320.getTree());

                            }
                            break;

                    }

                    RIGHT_PARETHESIS321=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_lambda_function_declaration4177); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS321);


                    }
                    break;

            }

            pushFollow(FOLLOW_block_in_lambda_function_declaration4185);
            block322=block();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_block.add(block322.getTree());


            // AST REWRITE
            // elements: BIT_AND, 111, parameter_list, block, expr_list
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 919:3: -> ^( METHOD_DECL ( '&' )? ( parameter_list )? ( ^( 'use' ( expr_list )? ) )? block )
            {
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:919:7: ^( METHOD_DECL ( '&' )? ( parameter_list )? ( ^( 'use' ( expr_list )? ) )? block )
                {
                SLAST root_1 = (SLAST)adaptor.nil();
                root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(METHOD_DECL, "METHOD_DECL"), root_1);

                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:919:21: ( '&' )?
                if ( stream_BIT_AND.hasNext() ) {
                    adaptor.addChild(root_1, stream_BIT_AND.nextNode());

                }
                stream_BIT_AND.reset();
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:919:26: ( parameter_list )?
                if ( stream_parameter_list.hasNext() ) {
                    adaptor.addChild(root_1, stream_parameter_list.nextTree());

                }
                stream_parameter_list.reset();
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:919:42: ( ^( 'use' ( expr_list )? ) )?
                if ( stream_111.hasNext()||stream_expr_list.hasNext() ) {
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:919:42: ^( 'use' ( expr_list )? )
                    {
                    SLAST root_2 = (SLAST)adaptor.nil();
                    root_2 = (SLAST)adaptor.becomeRoot(stream_111.nextNode(), root_2);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:919:50: ( expr_list )?
                    if ( stream_expr_list.hasNext() ) {
                        adaptor.addChild(root_2, stream_expr_list.nextTree());

                    }
                    stream_expr_list.reset();

                    adaptor.addChild(root_1, root_2);
                    }

                }
                stream_111.reset();
                stream_expr_list.reset();
                adaptor.addChild(root_1, stream_block.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "lambda_function_declaration"

    public static class class_name_reference_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "class_name_reference"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:923:1: class_name_reference : ( variable | fully_qualified_class_name );
    public final CompilerAstParser.class_name_reference_return class_name_reference() throws RecognitionException {
        CompilerAstParser.class_name_reference_return retval = new CompilerAstParser.class_name_reference_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        CompilerAstParser.variable_return variable323 = null;

        CompilerAstParser.fully_qualified_class_name_return fully_qualified_class_name324 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:924:3: ( variable | fully_qualified_class_name )
            int alt108=2;
            alt108 = dfa108.predict(input);
            switch (alt108) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:924:5: variable
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_variable_in_class_name_reference4232);
                    variable323=variable();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, variable323.getTree());

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:925:5: fully_qualified_class_name
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_fully_qualified_class_name_in_class_name_reference4238);
                    fully_qualified_class_name324=fully_qualified_class_name();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, fully_qualified_class_name324.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "class_name_reference"

    public static class assignment_list_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "assignment_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:928:1: assignment_list : ( assignment_element )? ( ',' ( assignment_element )? )* ;
    public final CompilerAstParser.assignment_list_return assignment_list() throws RecognitionException {
        CompilerAstParser.assignment_list_return retval = new CompilerAstParser.assignment_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token char_literal326=null;
        CompilerAstParser.assignment_element_return assignment_element325 = null;

        CompilerAstParser.assignment_element_return assignment_element327 = null;


        SLAST char_literal326_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:929:3: ( ( assignment_element )? ( ',' ( assignment_element )? )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:929:5: ( assignment_element )? ( ',' ( assignment_element )? )*
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:929:5: ( assignment_element )?
            int alt109=2;
            int LA109_0 = input.LA(1);

            if ( (LA109_0==IDENTIFIER||LA109_0==DOLLAR_T||LA109_0==169) ) {
                alt109=1;
            }
            switch (alt109) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:929:5: assignment_element
                    {
                    pushFollow(FOLLOW_assignment_element_in_assignment_list4255);
                    assignment_element325=assignment_element();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, assignment_element325.getTree());

                    }
                    break;

            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:929:25: ( ',' ( assignment_element )? )*
            loop111:
            do {
                int alt111=2;
                int LA111_0 = input.LA(1);

                if ( (LA111_0==114) ) {
                    alt111=1;
                }


                switch (alt111) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:929:26: ',' ( assignment_element )?
            	    {
            	    char_literal326=(Token)match(input,114,FOLLOW_114_in_assignment_list4259); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    char_literal326_tree = (SLAST)adaptor.create(char_literal326);
            	    adaptor.addChild(root_0, char_literal326_tree);
            	    }
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:929:30: ( assignment_element )?
            	    int alt110=2;
            	    int LA110_0 = input.LA(1);

            	    if ( (LA110_0==IDENTIFIER||LA110_0==DOLLAR_T||LA110_0==169) ) {
            	        alt110=1;
            	    }
            	    switch (alt110) {
            	        case 1 :
            	            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:929:30: assignment_element
            	            {
            	            pushFollow(FOLLOW_assignment_element_in_assignment_list4261);
            	            assignment_element327=assignment_element();

            	            state._fsp--;
            	            if (state.failed) return retval;
            	            if ( state.backtracking==0 ) adaptor.addChild(root_0, assignment_element327.getTree());

            	            }
            	            break;

            	    }


            	    }
            	    break;

            	default :
            	    break loop111;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "assignment_list"

    public static class assignment_element_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "assignment_element"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:932:1: assignment_element : ( variable | 'list' LEFT_PARETHESIS assignment_list RIGHT_PARETHESIS -> ^( 'list' assignment_list ) );
    public final CompilerAstParser.assignment_element_return assignment_element() throws RecognitionException {
        CompilerAstParser.assignment_element_return retval = new CompilerAstParser.assignment_element_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token string_literal329=null;
        Token LEFT_PARETHESIS330=null;
        Token RIGHT_PARETHESIS332=null;
        CompilerAstParser.variable_return variable328 = null;

        CompilerAstParser.assignment_list_return assignment_list331 = null;


        SLAST string_literal329_tree=null;
        SLAST LEFT_PARETHESIS330_tree=null;
        SLAST RIGHT_PARETHESIS332_tree=null;
        RewriteRuleTokenStream stream_LEFT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token LEFT_PARETHESIS");
        RewriteRuleTokenStream stream_169=new RewriteRuleTokenStream(adaptor,"token 169");
        RewriteRuleTokenStream stream_RIGHT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token RIGHT_PARETHESIS");
        RewriteRuleSubtreeStream stream_assignment_list=new RewriteRuleSubtreeStream(adaptor,"rule assignment_list");
        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:933:3: ( variable | 'list' LEFT_PARETHESIS assignment_list RIGHT_PARETHESIS -> ^( 'list' assignment_list ) )
            int alt112=2;
            int LA112_0 = input.LA(1);

            if ( (LA112_0==IDENTIFIER||LA112_0==DOLLAR_T) ) {
                alt112=1;
            }
            else if ( (LA112_0==169) ) {
                alt112=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 112, 0, input);

                throw nvae;
            }
            switch (alt112) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:933:5: variable
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_variable_in_assignment_element4278);
                    variable328=variable();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, variable328.getTree());

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:934:5: 'list' LEFT_PARETHESIS assignment_list RIGHT_PARETHESIS
                    {
                    string_literal329=(Token)match(input,169,FOLLOW_169_in_assignment_element4284); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_169.add(string_literal329);

                    LEFT_PARETHESIS330=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_assignment_element4286); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS330);

                    pushFollow(FOLLOW_assignment_list_in_assignment_element4288);
                    assignment_list331=assignment_list();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_assignment_list.add(assignment_list331.getTree());
                    RIGHT_PARETHESIS332=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_assignment_element4290); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS332);



                    // AST REWRITE
                    // elements: assignment_list, 169
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 934:62: -> ^( 'list' assignment_list )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:934:66: ^( 'list' assignment_list )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_169.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_assignment_list.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "assignment_element"

    public static class array_pair_list_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "array_pair_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:937:1: array_pair_list : e1= array_pair_element ( ',' e2= array_pair_element )* ( ',' )? -> ( array_pair_element )+ ;
    public final CompilerAstParser.array_pair_list_return array_pair_list() throws RecognitionException {
        CompilerAstParser.array_pair_list_return retval = new CompilerAstParser.array_pair_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token char_literal333=null;
        Token char_literal334=null;
        CompilerAstParser.array_pair_element_return e1 = null;

        CompilerAstParser.array_pair_element_return e2 = null;


        SLAST char_literal333_tree=null;
        SLAST char_literal334_tree=null;
        RewriteRuleTokenStream stream_114=new RewriteRuleTokenStream(adaptor,"token 114");
        RewriteRuleSubtreeStream stream_array_pair_element=new RewriteRuleSubtreeStream(adaptor,"rule array_pair_element");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:947:3: (e1= array_pair_element ( ',' e2= array_pair_element )* ( ',' )? -> ( array_pair_element )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:947:5: e1= array_pair_element ( ',' e2= array_pair_element )* ( ',' )?
            {
            pushFollow(FOLLOW_array_pair_element_in_array_pair_list4327);
            e1=array_pair_element();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_array_pair_element.add(e1.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:947:27: ( ',' e2= array_pair_element )*
            loop113:
            do {
                int alt113=2;
                int LA113_0 = input.LA(1);

                if ( (LA113_0==114) ) {
                    int LA113_1 = input.LA(2);

                    if ( (LA113_1==LEFT_PARETHESIS||LA113_1==IDENTIFIER||LA113_1==STRINGLITERAL||(LA113_1>=BIT_AND && LA113_1<=MINUS_T)||(LA113_1>=TILDA_T && LA113_1<=BACKTRICKLITERAL)||(LA113_1>=DOLLAR_T && LA113_1<=DOUBLELITERRAL)||LA113_1==95||(LA113_1>=160 && LA113_1<=161)||(LA113_1>=163 && LA113_1<=166)||(LA113_1>=168 && LA113_1<=171)||(LA113_1>=173 && LA113_1<=178)) ) {
                        alt113=1;
                    }


                }


                switch (alt113) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:947:28: ',' e2= array_pair_element
            	    {
            	    char_literal333=(Token)match(input,114,FOLLOW_114_in_array_pair_list4330); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_114.add(char_literal333);

            	    pushFollow(FOLLOW_array_pair_element_in_array_pair_list4334);
            	    e2=array_pair_element();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_array_pair_element.add(e2.getTree());

            	    }
            	    break;

            	default :
            	    break loop113;
                }
            } while (true);

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:947:56: ( ',' )?
            int alt114=2;
            int LA114_0 = input.LA(1);

            if ( (LA114_0==114) ) {
                alt114=1;
            }
            switch (alt114) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:947:56: ','
                    {
                    char_literal334=(Token)match(input,114,FOLLOW_114_in_array_pair_list4338); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_114.add(char_literal334);


                    }
                    break;

            }

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(e1!=null?((Token)e1.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(e1!=null?((Token)e1.stop):null);
                  if ((e2!=null?input.toString(e2.start,e2.stop):null) != null) {
                    token = (CommonToken)(e2!=null?((Token)e2.stop):null);
                  }
                  endIndex = token.getStopIndex();
                
            }


            // AST REWRITE
            // elements: array_pair_element
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 957:6: -> ( array_pair_element )+
            {
                if ( !(stream_array_pair_element.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_array_pair_element.hasNext() ) {
                    adaptor.addChild(root_0, stream_array_pair_element.nextTree());

                }
                stream_array_pair_element.reset();

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "array_pair_list"

    public static class array_pair_element_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "array_pair_element"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:960:1: array_pair_element : e1= expression ( '=>' e2= expression )? ;
    public final CompilerAstParser.array_pair_element_return array_pair_element() throws RecognitionException {
        CompilerAstParser.array_pair_element_return retval = new CompilerAstParser.array_pair_element_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token string_literal335=null;
        CompilerAstParser.expression_return e1 = null;

        CompilerAstParser.expression_return e2 = null;


        SLAST string_literal335_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:970:3: (e1= expression ( '=>' e2= expression )? )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:970:5: e1= expression ( '=>' e2= expression )?
            {
            root_0 = (SLAST)adaptor.nil();

            pushFollow(FOLLOW_expression_in_array_pair_element4383);
            e1=expression();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, e1.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:970:19: ( '=>' e2= expression )?
            int alt115=2;
            int LA115_0 = input.LA(1);

            if ( (LA115_0==112) ) {
                alt115=1;
            }
            switch (alt115) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:970:20: '=>' e2= expression
                    {
                    string_literal335=(Token)match(input,112,FOLLOW_112_in_array_pair_element4386); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    string_literal335_tree = (SLAST)adaptor.create(string_literal335);
                    root_0 = (SLAST)adaptor.becomeRoot(string_literal335_tree, root_0);
                    }
                    pushFollow(FOLLOW_expression_in_array_pair_element4391);
                    e2=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, e2.getTree());

                    }
                    break;

            }

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(e1!=null?((Token)e1.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(e1!=null?((Token)e1.stop):null);
                  if ((e2!=null?input.toString(e2.start,e2.stop):null) != null) {
                    token = (CommonToken)(e2!=null?((Token)e2.stop):null);
                  }
                  endIndex = token.getStopIndex();
                  
                  System.out.println("array:" + startIndex + " " + endIndex);
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "array_pair_element"

    public static class variable_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "variable"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:984:1: variable : ( base_variable_with_function_calls -> base_variable_with_function_calls ) ( '->' object_property ( ctor_arguments )? -> ^( CALL $variable object_property ( ctor_arguments )? ) )* ;
    public final CompilerAstParser.variable_return variable() throws RecognitionException {
        CompilerAstParser.variable_return retval = new CompilerAstParser.variable_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token string_literal337=null;
        CompilerAstParser.base_variable_with_function_calls_return base_variable_with_function_calls336 = null;

        CompilerAstParser.object_property_return object_property338 = null;

        CompilerAstParser.ctor_arguments_return ctor_arguments339 = null;


        SLAST string_literal337_tree=null;
        RewriteRuleTokenStream stream_172=new RewriteRuleTokenStream(adaptor,"token 172");
        RewriteRuleSubtreeStream stream_ctor_arguments=new RewriteRuleSubtreeStream(adaptor,"rule ctor_arguments");
        RewriteRuleSubtreeStream stream_object_property=new RewriteRuleSubtreeStream(adaptor,"rule object_property");
        RewriteRuleSubtreeStream stream_base_variable_with_function_calls=new RewriteRuleSubtreeStream(adaptor,"rule base_variable_with_function_calls");
        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:985:3: ( ( base_variable_with_function_calls -> base_variable_with_function_calls ) ( '->' object_property ( ctor_arguments )? -> ^( CALL $variable object_property ( ctor_arguments )? ) )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:985:5: ( base_variable_with_function_calls -> base_variable_with_function_calls ) ( '->' object_property ( ctor_arguments )? -> ^( CALL $variable object_property ( ctor_arguments )? ) )*
            {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:985:5: ( base_variable_with_function_calls -> base_variable_with_function_calls )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:985:6: base_variable_with_function_calls
            {
            pushFollow(FOLLOW_base_variable_with_function_calls_in_variable4415);
            base_variable_with_function_calls336=base_variable_with_function_calls();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_base_variable_with_function_calls.add(base_variable_with_function_calls336.getTree());


            // AST REWRITE
            // elements: base_variable_with_function_calls
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 985:40: -> base_variable_with_function_calls
            {
                adaptor.addChild(root_0, stream_base_variable_with_function_calls.nextTree());

            }

            retval.tree = root_0;}
            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:986:5: ( '->' object_property ( ctor_arguments )? -> ^( CALL $variable object_property ( ctor_arguments )? ) )*
            loop117:
            do {
                int alt117=2;
                int LA117_0 = input.LA(1);

                if ( (LA117_0==172) ) {
                    alt117=1;
                }


                switch (alt117) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:986:6: '->' object_property ( ctor_arguments )?
            	    {
            	    string_literal337=(Token)match(input,172,FOLLOW_172_in_variable4427); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_172.add(string_literal337);

            	    pushFollow(FOLLOW_object_property_in_variable4429);
            	    object_property338=object_property();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_object_property.add(object_property338.getTree());
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:986:27: ( ctor_arguments )?
            	    int alt116=2;
            	    int LA116_0 = input.LA(1);

            	    if ( (LA116_0==LEFT_PARETHESIS) ) {
            	        alt116=1;
            	    }
            	    switch (alt116) {
            	        case 1 :
            	            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:986:27: ctor_arguments
            	            {
            	            pushFollow(FOLLOW_ctor_arguments_in_variable4431);
            	            ctor_arguments339=ctor_arguments();

            	            state._fsp--;
            	            if (state.failed) return retval;
            	            if ( state.backtracking==0 ) stream_ctor_arguments.add(ctor_arguments339.getTree());

            	            }
            	            break;

            	    }



            	    // AST REWRITE
            	    // elements: object_property, ctor_arguments, variable
            	    // token labels: 
            	    // rule labels: retval
            	    // token list labels: 
            	    // rule list labels: 
            	    // wildcard labels: 
            	    if ( state.backtracking==0 ) {
            	    retval.tree = root_0;
            	    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            	    root_0 = (SLAST)adaptor.nil();
            	    // 987:5: -> ^( CALL $variable object_property ( ctor_arguments )? )
            	    {
            	        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:987:9: ^( CALL $variable object_property ( ctor_arguments )? )
            	        {
            	        SLAST root_1 = (SLAST)adaptor.nil();
            	        root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(CALL, "CALL"), root_1);

            	        adaptor.addChild(root_1, stream_retval.nextTree());
            	        adaptor.addChild(root_1, stream_object_property.nextTree());
            	        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:987:42: ( ctor_arguments )?
            	        if ( stream_ctor_arguments.hasNext() ) {
            	            adaptor.addChild(root_1, stream_ctor_arguments.nextTree());

            	        }
            	        stream_ctor_arguments.reset();

            	        adaptor.addChild(root_0, root_1);
            	        }

            	    }

            	    retval.tree = root_0;}
            	    }
            	    break;

            	default :
            	    break loop117;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "variable"

    public static class base_variable_with_function_calls_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "base_variable_with_function_calls"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:990:1: base_variable_with_function_calls : ( ( fully_qualified_class_name )? reference_variable ( ctor_arguments )? -> ^( VAR_DECL ( fully_qualified_class_name )? reference_variable ( ctor_arguments )? ) | fully_qualified_class_name ctor_arguments -> ^( CALL fully_qualified_class_name ctor_arguments ) );
    public final CompilerAstParser.base_variable_with_function_calls_return base_variable_with_function_calls() throws RecognitionException {
        CompilerAstParser.base_variable_with_function_calls_return retval = new CompilerAstParser.base_variable_with_function_calls_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        CompilerAstParser.fully_qualified_class_name_return fully_qualified_class_name340 = null;

        CompilerAstParser.reference_variable_return reference_variable341 = null;

        CompilerAstParser.ctor_arguments_return ctor_arguments342 = null;

        CompilerAstParser.fully_qualified_class_name_return fully_qualified_class_name343 = null;

        CompilerAstParser.ctor_arguments_return ctor_arguments344 = null;


        RewriteRuleSubtreeStream stream_ctor_arguments=new RewriteRuleSubtreeStream(adaptor,"rule ctor_arguments");
        RewriteRuleSubtreeStream stream_fully_qualified_class_name=new RewriteRuleSubtreeStream(adaptor,"rule fully_qualified_class_name");
        RewriteRuleSubtreeStream stream_reference_variable=new RewriteRuleSubtreeStream(adaptor,"rule reference_variable");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1000:3: ( ( fully_qualified_class_name )? reference_variable ( ctor_arguments )? -> ^( VAR_DECL ( fully_qualified_class_name )? reference_variable ( ctor_arguments )? ) | fully_qualified_class_name ctor_arguments -> ^( CALL fully_qualified_class_name ctor_arguments ) )
            int alt120=2;
            alt120 = dfa120.predict(input);
            switch (alt120) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1000:5: ( fully_qualified_class_name )? reference_variable ( ctor_arguments )?
                    {
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1000:5: ( fully_qualified_class_name )?
                    int alt118=2;
                    int LA118_0 = input.LA(1);

                    if ( (LA118_0==IDENTIFIER) ) {
                        alt118=1;
                    }
                    switch (alt118) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1000:5: fully_qualified_class_name
                            {
                            pushFollow(FOLLOW_fully_qualified_class_name_in_base_variable_with_function_calls4478);
                            fully_qualified_class_name340=fully_qualified_class_name();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_fully_qualified_class_name.add(fully_qualified_class_name340.getTree());

                            }
                            break;

                    }

                    pushFollow(FOLLOW_reference_variable_in_base_variable_with_function_calls4481);
                    reference_variable341=reference_variable();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_reference_variable.add(reference_variable341.getTree());
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1000:52: ( ctor_arguments )?
                    int alt119=2;
                    int LA119_0 = input.LA(1);

                    if ( (LA119_0==LEFT_PARETHESIS) ) {
                        alt119=1;
                    }
                    switch (alt119) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1000:52: ctor_arguments
                            {
                            pushFollow(FOLLOW_ctor_arguments_in_base_variable_with_function_calls4483);
                            ctor_arguments342=ctor_arguments();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_ctor_arguments.add(ctor_arguments342.getTree());

                            }
                            break;

                    }

                    if ( state.backtracking==0 ) {

                            token = (CommonToken)(reference_variable341!=null?((Token)reference_variable341.start):null);
                            startIndex = token.getStartIndex();
                            token = (CommonToken)(reference_variable341!=null?((Token)reference_variable341.stop):null);
                            endIndex = token.getStopIndex();
                          
                    }


                    // AST REWRITE
                    // elements: fully_qualified_class_name, ctor_arguments, reference_variable
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 1007:7: -> ^( VAR_DECL ( fully_qualified_class_name )? reference_variable ( ctor_arguments )? )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1007:11: ^( VAR_DECL ( fully_qualified_class_name )? reference_variable ( ctor_arguments )? )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(VAR_DECL, "VAR_DECL"), root_1);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1007:22: ( fully_qualified_class_name )?
                        if ( stream_fully_qualified_class_name.hasNext() ) {
                            adaptor.addChild(root_1, stream_fully_qualified_class_name.nextTree());

                        }
                        stream_fully_qualified_class_name.reset();
                        adaptor.addChild(root_1, stream_reference_variable.nextTree());
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1007:69: ( ctor_arguments )?
                        if ( stream_ctor_arguments.hasNext() ) {
                            adaptor.addChild(root_1, stream_ctor_arguments.nextTree());

                        }
                        stream_ctor_arguments.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1008:5: fully_qualified_class_name ctor_arguments
                    {
                    pushFollow(FOLLOW_fully_qualified_class_name_in_base_variable_with_function_calls4517);
                    fully_qualified_class_name343=fully_qualified_class_name();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_fully_qualified_class_name.add(fully_qualified_class_name343.getTree());
                    pushFollow(FOLLOW_ctor_arguments_in_base_variable_with_function_calls4519);
                    ctor_arguments344=ctor_arguments();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_ctor_arguments.add(ctor_arguments344.getTree());
                    if ( state.backtracking==0 ) {

                            token = (CommonToken)(fully_qualified_class_name343!=null?((Token)fully_qualified_class_name343.start):null);
                            startIndex = token.getStartIndex();
                            token = (CommonToken)(ctor_arguments344!=null?((Token)ctor_arguments344.stop):null);
                            endIndex = token.getStopIndex();
                          
                    }


                    // AST REWRITE
                    // elements: ctor_arguments, fully_qualified_class_name
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 1015:7: -> ^( CALL fully_qualified_class_name ctor_arguments )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1015:11: ^( CALL fully_qualified_class_name ctor_arguments )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(CALL, "CALL"), root_1);

                        adaptor.addChild(root_1, stream_fully_qualified_class_name.nextTree());
                        adaptor.addChild(root_1, stream_ctor_arguments.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "base_variable_with_function_calls"

    public static class object_property_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "object_property"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1020:1: object_property : ( reference_variable | reference_variable_without_dollar );
    public final CompilerAstParser.object_property_return object_property() throws RecognitionException {
        CompilerAstParser.object_property_return retval = new CompilerAstParser.object_property_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        CompilerAstParser.reference_variable_return reference_variable345 = null;

        CompilerAstParser.reference_variable_without_dollar_return reference_variable_without_dollar346 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1021:3: ( reference_variable | reference_variable_without_dollar )
            int alt121=2;
            int LA121_0 = input.LA(1);

            if ( (LA121_0==DOLLAR_T) ) {
                alt121=1;
            }
            else if ( ((LA121_0>=IDENTIFIER && LA121_0<=LEFT_BRACKET)) ) {
                alt121=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 121, 0, input);

                throw nvae;
            }
            switch (alt121) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1021:5: reference_variable
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_reference_variable_in_object_property4562);
                    reference_variable345=reference_variable();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, reference_variable345.getTree());

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1022:5: reference_variable_without_dollar
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_reference_variable_without_dollar_in_object_property4568);
                    reference_variable_without_dollar346=reference_variable_without_dollar();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, reference_variable_without_dollar346.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "object_property"

    public static class reference_variable_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "reference_variable"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1025:1: reference_variable : ( compound_variable -> compound_variable ) ( LEFT_OPEN_RECT (e= expression )? RIGHT_OPEN_RECT -> ^( INDEX $reference_variable ( $e)? ) | LEFT_BRACKET e= expression RIGHT_BRACKET -> ^( INDEX $reference_variable $e) )* ;
    public final CompilerAstParser.reference_variable_return reference_variable() throws RecognitionException {
        CompilerAstParser.reference_variable_return retval = new CompilerAstParser.reference_variable_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token LEFT_OPEN_RECT348=null;
        Token RIGHT_OPEN_RECT349=null;
        Token LEFT_BRACKET350=null;
        Token RIGHT_BRACKET351=null;
        CompilerAstParser.expression_return e = null;

        CompilerAstParser.compound_variable_return compound_variable347 = null;


        SLAST LEFT_OPEN_RECT348_tree=null;
        SLAST RIGHT_OPEN_RECT349_tree=null;
        SLAST LEFT_BRACKET350_tree=null;
        SLAST RIGHT_BRACKET351_tree=null;
        RewriteRuleTokenStream stream_RIGHT_OPEN_RECT=new RewriteRuleTokenStream(adaptor,"token RIGHT_OPEN_RECT");
        RewriteRuleTokenStream stream_LEFT_BRACKET=new RewriteRuleTokenStream(adaptor,"token LEFT_BRACKET");
        RewriteRuleTokenStream stream_LEFT_OPEN_RECT=new RewriteRuleTokenStream(adaptor,"token LEFT_OPEN_RECT");
        RewriteRuleTokenStream stream_RIGHT_BRACKET=new RewriteRuleTokenStream(adaptor,"token RIGHT_BRACKET");
        RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");
        RewriteRuleSubtreeStream stream_compound_variable=new RewriteRuleSubtreeStream(adaptor,"rule compound_variable");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;  

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1036:3: ( ( compound_variable -> compound_variable ) ( LEFT_OPEN_RECT (e= expression )? RIGHT_OPEN_RECT -> ^( INDEX $reference_variable ( $e)? ) | LEFT_BRACKET e= expression RIGHT_BRACKET -> ^( INDEX $reference_variable $e) )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1036:5: ( compound_variable -> compound_variable ) ( LEFT_OPEN_RECT (e= expression )? RIGHT_OPEN_RECT -> ^( INDEX $reference_variable ( $e)? ) | LEFT_BRACKET e= expression RIGHT_BRACKET -> ^( INDEX $reference_variable $e) )*
            {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1036:5: ( compound_variable -> compound_variable )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1036:6: compound_variable
            {
            pushFollow(FOLLOW_compound_variable_in_reference_variable4594);
            compound_variable347=compound_variable();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_compound_variable.add(compound_variable347.getTree());
            if ( state.backtracking==0 ) {

                  token = (CommonToken)(compound_variable347!=null?((Token)compound_variable347.start):null);
                  startIndex = token.getStartIndex();
                  endIndex = token.getStopIndex();
                
            }


            // AST REWRITE
            // elements: compound_variable
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 1042:5: -> compound_variable
            {
                adaptor.addChild(root_0, stream_compound_variable.nextTree());

            }

            retval.tree = root_0;}
            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1043:3: ( LEFT_OPEN_RECT (e= expression )? RIGHT_OPEN_RECT -> ^( INDEX $reference_variable ( $e)? ) | LEFT_BRACKET e= expression RIGHT_BRACKET -> ^( INDEX $reference_variable $e) )*
            loop123:
            do {
                int alt123=3;
                int LA123_0 = input.LA(1);

                if ( (LA123_0==LEFT_OPEN_RECT) ) {
                    alt123=1;
                }
                else if ( (LA123_0==LEFT_BRACKET) ) {
                    alt123=2;
                }


                switch (alt123) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1044:3: LEFT_OPEN_RECT (e= expression )? RIGHT_OPEN_RECT
            	    {
            	    LEFT_OPEN_RECT348=(Token)match(input,LEFT_OPEN_RECT,FOLLOW_LEFT_OPEN_RECT_in_reference_variable4615); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_LEFT_OPEN_RECT.add(LEFT_OPEN_RECT348);

            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1044:19: (e= expression )?
            	    int alt122=2;
            	    int LA122_0 = input.LA(1);

            	    if ( (LA122_0==LEFT_PARETHESIS||LA122_0==IDENTIFIER||LA122_0==STRINGLITERAL||(LA122_0>=BIT_AND && LA122_0<=MINUS_T)||(LA122_0>=TILDA_T && LA122_0<=BACKTRICKLITERAL)||(LA122_0>=DOLLAR_T && LA122_0<=DOUBLELITERRAL)||LA122_0==95||(LA122_0>=160 && LA122_0<=161)||(LA122_0>=163 && LA122_0<=166)||(LA122_0>=168 && LA122_0<=171)||(LA122_0>=173 && LA122_0<=178)) ) {
            	        alt122=1;
            	    }
            	    switch (alt122) {
            	        case 1 :
            	            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1044:19: e= expression
            	            {
            	            pushFollow(FOLLOW_expression_in_reference_variable4619);
            	            e=expression();

            	            state._fsp--;
            	            if (state.failed) return retval;
            	            if ( state.backtracking==0 ) stream_expression.add(e.getTree());

            	            }
            	            break;

            	    }

            	    RIGHT_OPEN_RECT349=(Token)match(input,RIGHT_OPEN_RECT,FOLLOW_RIGHT_OPEN_RECT_in_reference_variable4622); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_RIGHT_OPEN_RECT.add(RIGHT_OPEN_RECT349);

            	    if ( state.backtracking==0 ) {

            	          endIndex = ((CommonToken)RIGHT_OPEN_RECT349).getStopIndex();
            	        
            	    }


            	    // AST REWRITE
            	    // elements: reference_variable, e
            	    // token labels: 
            	    // rule labels: retval, e
            	    // token list labels: 
            	    // rule list labels: 
            	    // wildcard labels: 
            	    if ( state.backtracking==0 ) {
            	    retval.tree = root_0;
            	    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
            	    RewriteRuleSubtreeStream stream_e=new RewriteRuleSubtreeStream(adaptor,"rule e",e!=null?e.tree:null);

            	    root_0 = (SLAST)adaptor.nil();
            	    // 1048:5: -> ^( INDEX $reference_variable ( $e)? )
            	    {
            	        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1048:9: ^( INDEX $reference_variable ( $e)? )
            	        {
            	        SLAST root_1 = (SLAST)adaptor.nil();
            	        root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(INDEX, "INDEX"), root_1);

            	        adaptor.addChild(root_1, stream_retval.nextTree());
            	        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1048:37: ( $e)?
            	        if ( stream_e.hasNext() ) {
            	            adaptor.addChild(root_1, stream_e.nextTree());

            	        }
            	        stream_e.reset();

            	        adaptor.addChild(root_0, root_1);
            	        }

            	    }

            	    retval.tree = root_0;}
            	    }
            	    break;
            	case 2 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1050:3: LEFT_BRACKET e= expression RIGHT_BRACKET
            	    {
            	    LEFT_BRACKET350=(Token)match(input,LEFT_BRACKET,FOLLOW_LEFT_BRACKET_in_reference_variable4652); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_LEFT_BRACKET.add(LEFT_BRACKET350);

            	    pushFollow(FOLLOW_expression_in_reference_variable4656);
            	    e=expression();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_expression.add(e.getTree());
            	    RIGHT_BRACKET351=(Token)match(input,RIGHT_BRACKET,FOLLOW_RIGHT_BRACKET_in_reference_variable4658); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_RIGHT_BRACKET.add(RIGHT_BRACKET351);

            	    if ( state.backtracking==0 ) {

            	          endIndex = ((CommonToken)RIGHT_OPEN_RECT349).getStopIndex();
            	        
            	    }


            	    // AST REWRITE
            	    // elements: e, reference_variable
            	    // token labels: 
            	    // rule labels: retval, e
            	    // token list labels: 
            	    // rule list labels: 
            	    // wildcard labels: 
            	    if ( state.backtracking==0 ) {
            	    retval.tree = root_0;
            	    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
            	    RewriteRuleSubtreeStream stream_e=new RewriteRuleSubtreeStream(adaptor,"rule e",e!=null?e.tree:null);

            	    root_0 = (SLAST)adaptor.nil();
            	    // 1054:5: -> ^( INDEX $reference_variable $e)
            	    {
            	        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1054:9: ^( INDEX $reference_variable $e)
            	        {
            	        SLAST root_1 = (SLAST)adaptor.nil();
            	        root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(INDEX, "INDEX"), root_1);

            	        adaptor.addChild(root_1, stream_retval.nextTree());
            	        adaptor.addChild(root_1, stream_e.nextTree());

            	        adaptor.addChild(root_0, root_1);
            	        }

            	    }

            	    retval.tree = root_0;}
            	    }
            	    break;

            	default :
            	    break loop123;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);
                System.out.println("slat : " + startIndex + " " + endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "reference_variable"

    public static class compound_variable_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "compound_variable"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1058:1: compound_variable : ( ( DOLLAR_T )+ IDENTIFIER | ( DOLLAR_T )+ LEFT_BRACKET expression RIGHT_BRACKET );
    public final CompilerAstParser.compound_variable_return compound_variable() throws RecognitionException {
        CompilerAstParser.compound_variable_return retval = new CompilerAstParser.compound_variable_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token DOLLAR_T352=null;
        Token IDENTIFIER353=null;
        Token DOLLAR_T354=null;
        Token LEFT_BRACKET355=null;
        Token RIGHT_BRACKET357=null;
        CompilerAstParser.expression_return expression356 = null;


        SLAST DOLLAR_T352_tree=null;
        SLAST IDENTIFIER353_tree=null;
        SLAST DOLLAR_T354_tree=null;
        SLAST LEFT_BRACKET355_tree=null;
        SLAST RIGHT_BRACKET357_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1059:3: ( ( DOLLAR_T )+ IDENTIFIER | ( DOLLAR_T )+ LEFT_BRACKET expression RIGHT_BRACKET )
            int alt126=2;
            alt126 = dfa126.predict(input);
            switch (alt126) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1059:5: ( DOLLAR_T )+ IDENTIFIER
                    {
                    root_0 = (SLAST)adaptor.nil();

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1059:5: ( DOLLAR_T )+
                    int cnt124=0;
                    loop124:
                    do {
                        int alt124=2;
                        int LA124_0 = input.LA(1);

                        if ( (LA124_0==DOLLAR_T) ) {
                            alt124=1;
                        }


                        switch (alt124) {
                    	case 1 :
                    	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1059:5: DOLLAR_T
                    	    {
                    	    DOLLAR_T352=(Token)match(input,DOLLAR_T,FOLLOW_DOLLAR_T_in_compound_variable4699); if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) {
                    	    DOLLAR_T352_tree = (SLAST)adaptor.create(DOLLAR_T352);
                    	    adaptor.addChild(root_0, DOLLAR_T352_tree);
                    	    }

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt124 >= 1 ) break loop124;
                    	    if (state.backtracking>0) {state.failed=true; return retval;}
                                EarlyExitException eee =
                                    new EarlyExitException(124, input);
                                throw eee;
                        }
                        cnt124++;
                    } while (true);

                    IDENTIFIER353=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_compound_variable4702); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    IDENTIFIER353_tree = (SLAST)adaptor.create(IDENTIFIER353);
                    adaptor.addChild(root_0, IDENTIFIER353_tree);
                    }

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1060:5: ( DOLLAR_T )+ LEFT_BRACKET expression RIGHT_BRACKET
                    {
                    root_0 = (SLAST)adaptor.nil();

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1060:5: ( DOLLAR_T )+
                    int cnt125=0;
                    loop125:
                    do {
                        int alt125=2;
                        int LA125_0 = input.LA(1);

                        if ( (LA125_0==DOLLAR_T) ) {
                            alt125=1;
                        }


                        switch (alt125) {
                    	case 1 :
                    	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1060:5: DOLLAR_T
                    	    {
                    	    DOLLAR_T354=(Token)match(input,DOLLAR_T,FOLLOW_DOLLAR_T_in_compound_variable4709); if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) {
                    	    DOLLAR_T354_tree = (SLAST)adaptor.create(DOLLAR_T354);
                    	    adaptor.addChild(root_0, DOLLAR_T354_tree);
                    	    }

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt125 >= 1 ) break loop125;
                    	    if (state.backtracking>0) {state.failed=true; return retval;}
                                EarlyExitException eee =
                                    new EarlyExitException(125, input);
                                throw eee;
                        }
                        cnt125++;
                    } while (true);

                    LEFT_BRACKET355=(Token)match(input,LEFT_BRACKET,FOLLOW_LEFT_BRACKET_in_compound_variable4712); if (state.failed) return retval;
                    pushFollow(FOLLOW_expression_in_compound_variable4715);
                    expression356=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, expression356.getTree());
                    RIGHT_BRACKET357=(Token)match(input,RIGHT_BRACKET,FOLLOW_RIGHT_BRACKET_in_compound_variable4717); if (state.failed) return retval;

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "compound_variable"

    public static class reference_variable_without_dollar_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "reference_variable_without_dollar"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1063:1: reference_variable_without_dollar : ( compound_variable_without_dollar -> compound_variable_without_dollar ) ( LEFT_OPEN_RECT ( expression )? RIGHT_OPEN_RECT -> ^( INDEX $reference_variable_without_dollar ( expression )? ) | LEFT_BRACKET expression RIGHT_BRACKET -> ^( INDEX $reference_variable_without_dollar expression ) )* ;
    public final CompilerAstParser.reference_variable_without_dollar_return reference_variable_without_dollar() throws RecognitionException {
        CompilerAstParser.reference_variable_without_dollar_return retval = new CompilerAstParser.reference_variable_without_dollar_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token LEFT_OPEN_RECT359=null;
        Token RIGHT_OPEN_RECT361=null;
        Token LEFT_BRACKET362=null;
        Token RIGHT_BRACKET364=null;
        CompilerAstParser.compound_variable_without_dollar_return compound_variable_without_dollar358 = null;

        CompilerAstParser.expression_return expression360 = null;

        CompilerAstParser.expression_return expression363 = null;


        SLAST LEFT_OPEN_RECT359_tree=null;
        SLAST RIGHT_OPEN_RECT361_tree=null;
        SLAST LEFT_BRACKET362_tree=null;
        SLAST RIGHT_BRACKET364_tree=null;
        RewriteRuleTokenStream stream_RIGHT_OPEN_RECT=new RewriteRuleTokenStream(adaptor,"token RIGHT_OPEN_RECT");
        RewriteRuleTokenStream stream_LEFT_BRACKET=new RewriteRuleTokenStream(adaptor,"token LEFT_BRACKET");
        RewriteRuleTokenStream stream_LEFT_OPEN_RECT=new RewriteRuleTokenStream(adaptor,"token LEFT_OPEN_RECT");
        RewriteRuleTokenStream stream_RIGHT_BRACKET=new RewriteRuleTokenStream(adaptor,"token RIGHT_BRACKET");
        RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");
        RewriteRuleSubtreeStream stream_compound_variable_without_dollar=new RewriteRuleSubtreeStream(adaptor,"rule compound_variable_without_dollar");

          int startIndex = -1;
          int endIndex = -1;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1072:3: ( ( compound_variable_without_dollar -> compound_variable_without_dollar ) ( LEFT_OPEN_RECT ( expression )? RIGHT_OPEN_RECT -> ^( INDEX $reference_variable_without_dollar ( expression )? ) | LEFT_BRACKET expression RIGHT_BRACKET -> ^( INDEX $reference_variable_without_dollar expression ) )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1072:5: ( compound_variable_without_dollar -> compound_variable_without_dollar ) ( LEFT_OPEN_RECT ( expression )? RIGHT_OPEN_RECT -> ^( INDEX $reference_variable_without_dollar ( expression )? ) | LEFT_BRACKET expression RIGHT_BRACKET -> ^( INDEX $reference_variable_without_dollar expression ) )*
            {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1072:5: ( compound_variable_without_dollar -> compound_variable_without_dollar )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1072:6: compound_variable_without_dollar
            {
            pushFollow(FOLLOW_compound_variable_without_dollar_in_reference_variable_without_dollar4744);
            compound_variable_without_dollar358=compound_variable_without_dollar();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_compound_variable_without_dollar.add(compound_variable_without_dollar358.getTree());


            // AST REWRITE
            // elements: compound_variable_without_dollar
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 1072:39: -> compound_variable_without_dollar
            {
                adaptor.addChild(root_0, stream_compound_variable_without_dollar.nextTree());

            }

            retval.tree = root_0;}
            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1073:3: ( LEFT_OPEN_RECT ( expression )? RIGHT_OPEN_RECT -> ^( INDEX $reference_variable_without_dollar ( expression )? ) | LEFT_BRACKET expression RIGHT_BRACKET -> ^( INDEX $reference_variable_without_dollar expression ) )*
            loop128:
            do {
                int alt128=3;
                int LA128_0 = input.LA(1);

                if ( (LA128_0==LEFT_OPEN_RECT) ) {
                    alt128=1;
                }
                else if ( (LA128_0==LEFT_BRACKET) ) {
                    alt128=2;
                }


                switch (alt128) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1074:3: LEFT_OPEN_RECT ( expression )? RIGHT_OPEN_RECT
            	    {
            	    LEFT_OPEN_RECT359=(Token)match(input,LEFT_OPEN_RECT,FOLLOW_LEFT_OPEN_RECT_in_reference_variable_without_dollar4758); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_LEFT_OPEN_RECT.add(LEFT_OPEN_RECT359);

            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1074:18: ( expression )?
            	    int alt127=2;
            	    int LA127_0 = input.LA(1);

            	    if ( (LA127_0==LEFT_PARETHESIS||LA127_0==IDENTIFIER||LA127_0==STRINGLITERAL||(LA127_0>=BIT_AND && LA127_0<=MINUS_T)||(LA127_0>=TILDA_T && LA127_0<=BACKTRICKLITERAL)||(LA127_0>=DOLLAR_T && LA127_0<=DOUBLELITERRAL)||LA127_0==95||(LA127_0>=160 && LA127_0<=161)||(LA127_0>=163 && LA127_0<=166)||(LA127_0>=168 && LA127_0<=171)||(LA127_0>=173 && LA127_0<=178)) ) {
            	        alt127=1;
            	    }
            	    switch (alt127) {
            	        case 1 :
            	            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1074:18: expression
            	            {
            	            pushFollow(FOLLOW_expression_in_reference_variable_without_dollar4760);
            	            expression360=expression();

            	            state._fsp--;
            	            if (state.failed) return retval;
            	            if ( state.backtracking==0 ) stream_expression.add(expression360.getTree());

            	            }
            	            break;

            	    }

            	    RIGHT_OPEN_RECT361=(Token)match(input,RIGHT_OPEN_RECT,FOLLOW_RIGHT_OPEN_RECT_in_reference_variable_without_dollar4763); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_RIGHT_OPEN_RECT.add(RIGHT_OPEN_RECT361);



            	    // AST REWRITE
            	    // elements: reference_variable_without_dollar, expression
            	    // token labels: 
            	    // rule labels: retval
            	    // token list labels: 
            	    // rule list labels: 
            	    // wildcard labels: 
            	    if ( state.backtracking==0 ) {
            	    retval.tree = root_0;
            	    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            	    root_0 = (SLAST)adaptor.nil();
            	    // 1074:48: -> ^( INDEX $reference_variable_without_dollar ( expression )? )
            	    {
            	        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1074:52: ^( INDEX $reference_variable_without_dollar ( expression )? )
            	        {
            	        SLAST root_1 = (SLAST)adaptor.nil();
            	        root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(INDEX, "INDEX"), root_1);

            	        adaptor.addChild(root_1, stream_retval.nextTree());
            	        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1074:95: ( expression )?
            	        if ( stream_expression.hasNext() ) {
            	            adaptor.addChild(root_1, stream_expression.nextTree());

            	        }
            	        stream_expression.reset();

            	        adaptor.addChild(root_0, root_1);
            	        }

            	    }

            	    retval.tree = root_0;}
            	    }
            	    break;
            	case 2 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1076:3: LEFT_BRACKET expression RIGHT_BRACKET
            	    {
            	    LEFT_BRACKET362=(Token)match(input,LEFT_BRACKET,FOLLOW_LEFT_BRACKET_in_reference_variable_without_dollar4786); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_LEFT_BRACKET.add(LEFT_BRACKET362);

            	    pushFollow(FOLLOW_expression_in_reference_variable_without_dollar4788);
            	    expression363=expression();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_expression.add(expression363.getTree());
            	    RIGHT_BRACKET364=(Token)match(input,RIGHT_BRACKET,FOLLOW_RIGHT_BRACKET_in_reference_variable_without_dollar4790); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_RIGHT_BRACKET.add(RIGHT_BRACKET364);



            	    // AST REWRITE
            	    // elements: expression, reference_variable_without_dollar
            	    // token labels: 
            	    // rule labels: retval
            	    // token list labels: 
            	    // rule list labels: 
            	    // wildcard labels: 
            	    if ( state.backtracking==0 ) {
            	    retval.tree = root_0;
            	    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            	    root_0 = (SLAST)adaptor.nil();
            	    // 1076:44: -> ^( INDEX $reference_variable_without_dollar expression )
            	    {
            	        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1076:48: ^( INDEX $reference_variable_without_dollar expression )
            	        {
            	        SLAST root_1 = (SLAST)adaptor.nil();
            	        root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(INDEX, "INDEX"), root_1);

            	        adaptor.addChild(root_1, stream_retval.nextTree());
            	        adaptor.addChild(root_1, stream_expression.nextTree());

            	        adaptor.addChild(root_0, root_1);
            	        }

            	    }

            	    retval.tree = root_0;}
            	    }
            	    break;

            	default :
            	    break loop128;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "reference_variable_without_dollar"

    public static class compound_variable_without_dollar_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "compound_variable_without_dollar"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1080:1: compound_variable_without_dollar : ( IDENTIFIER | LEFT_BRACKET expression RIGHT_BRACKET );
    public final CompilerAstParser.compound_variable_without_dollar_return compound_variable_without_dollar() throws RecognitionException {
        CompilerAstParser.compound_variable_without_dollar_return retval = new CompilerAstParser.compound_variable_without_dollar_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token IDENTIFIER365=null;
        Token LEFT_BRACKET366=null;
        Token RIGHT_BRACKET368=null;
        CompilerAstParser.expression_return expression367 = null;


        SLAST IDENTIFIER365_tree=null;
        SLAST LEFT_BRACKET366_tree=null;
        SLAST RIGHT_BRACKET368_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1081:3: ( IDENTIFIER | LEFT_BRACKET expression RIGHT_BRACKET )
            int alt129=2;
            int LA129_0 = input.LA(1);

            if ( (LA129_0==IDENTIFIER) ) {
                alt129=1;
            }
            else if ( (LA129_0==LEFT_BRACKET) ) {
                alt129=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 129, 0, input);

                throw nvae;
            }
            switch (alt129) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1081:5: IDENTIFIER
                    {
                    root_0 = (SLAST)adaptor.nil();

                    IDENTIFIER365=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_compound_variable_without_dollar4823); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    IDENTIFIER365_tree = (SLAST)adaptor.create(IDENTIFIER365);
                    adaptor.addChild(root_0, IDENTIFIER365_tree);
                    }

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1082:5: LEFT_BRACKET expression RIGHT_BRACKET
                    {
                    root_0 = (SLAST)adaptor.nil();

                    LEFT_BRACKET366=(Token)match(input,LEFT_BRACKET,FOLLOW_LEFT_BRACKET_in_compound_variable_without_dollar4829); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    LEFT_BRACKET366_tree = (SLAST)adaptor.create(LEFT_BRACKET366);
                    adaptor.addChild(root_0, LEFT_BRACKET366_tree);
                    }
                    pushFollow(FOLLOW_expression_in_compound_variable_without_dollar4831);
                    expression367=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, expression367.getTree());
                    RIGHT_BRACKET368=(Token)match(input,RIGHT_BRACKET,FOLLOW_RIGHT_BRACKET_in_compound_variable_without_dollar4833); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    RIGHT_BRACKET368_tree = (SLAST)adaptor.create(RIGHT_BRACKET368);
                    adaptor.addChild(root_0, RIGHT_BRACKET368_tree);
                    }

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "compound_variable_without_dollar"

    public static class ctor_arguments_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "ctor_arguments"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1085:1: ctor_arguments : LEFT_PARETHESIS ( expr_list )? RIGHT_PARETHESIS -> ^( ARGU ( expr_list )? ) ;
    public final CompilerAstParser.ctor_arguments_return ctor_arguments() throws RecognitionException {
        CompilerAstParser.ctor_arguments_return retval = new CompilerAstParser.ctor_arguments_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token LEFT_PARETHESIS369=null;
        Token RIGHT_PARETHESIS371=null;
        CompilerAstParser.expr_list_return expr_list370 = null;


        SLAST LEFT_PARETHESIS369_tree=null;
        SLAST RIGHT_PARETHESIS371_tree=null;
        RewriteRuleTokenStream stream_LEFT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token LEFT_PARETHESIS");
        RewriteRuleTokenStream stream_RIGHT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token RIGHT_PARETHESIS");
        RewriteRuleSubtreeStream stream_expr_list=new RewriteRuleSubtreeStream(adaptor,"rule expr_list");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1095:3: ( LEFT_PARETHESIS ( expr_list )? RIGHT_PARETHESIS -> ^( ARGU ( expr_list )? ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1095:6: LEFT_PARETHESIS ( expr_list )? RIGHT_PARETHESIS
            {
            LEFT_PARETHESIS369=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_ctor_arguments4859); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS369);

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1095:22: ( expr_list )?
            int alt130=2;
            int LA130_0 = input.LA(1);

            if ( (LA130_0==LEFT_PARETHESIS||LA130_0==IDENTIFIER||LA130_0==STRINGLITERAL||(LA130_0>=BIT_AND && LA130_0<=MINUS_T)||(LA130_0>=TILDA_T && LA130_0<=BACKTRICKLITERAL)||(LA130_0>=DOLLAR_T && LA130_0<=DOUBLELITERRAL)||LA130_0==95||(LA130_0>=160 && LA130_0<=161)||(LA130_0>=163 && LA130_0<=166)||(LA130_0>=168 && LA130_0<=171)||(LA130_0>=173 && LA130_0<=178)) ) {
                alt130=1;
            }
            switch (alt130) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1095:22: expr_list
                    {
                    pushFollow(FOLLOW_expr_list_in_ctor_arguments4861);
                    expr_list370=expr_list();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_expr_list.add(expr_list370.getTree());

                    }
                    break;

            }

            RIGHT_PARETHESIS371=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_ctor_arguments4864); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS371);

            if ( state.backtracking==0 ) {

                    token = (CommonToken)LEFT_PARETHESIS369;
                    startIndex = token.getStartIndex();
                    token = (CommonToken)RIGHT_PARETHESIS371;
                    endIndex = token.getStopIndex();
                    System.out.println("ctor: s:" + startIndex + " e: " + endIndex); 
                  
            }


            // AST REWRITE
            // elements: expr_list
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 1103:6: -> ^( ARGU ( expr_list )? )
            {
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1103:10: ^( ARGU ( expr_list )? )
                {
                SLAST root_1 = (SLAST)adaptor.nil();
                root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(ARGU, "ARGU"), root_1);

                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1103:17: ( expr_list )?
                if ( stream_expr_list.hasNext() ) {
                    adaptor.addChild(root_1, stream_expr_list.nextTree());

                }
                stream_expr_list.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "ctor_arguments"

    public static class pure_variable_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "pure_variable"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1106:1: pure_variable : ( '&' )? ( DOLLAR_T )+ IDENTIFIER -> ^( VAR_DECL ( '&' )? ( DOLLAR_T )+ IDENTIFIER ) ;
    public final CompilerAstParser.pure_variable_return pure_variable() throws RecognitionException {
        CompilerAstParser.pure_variable_return retval = new CompilerAstParser.pure_variable_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token char_literal372=null;
        Token DOLLAR_T373=null;
        Token IDENTIFIER374=null;

        SLAST char_literal372_tree=null;
        SLAST DOLLAR_T373_tree=null;
        SLAST IDENTIFIER374_tree=null;
        RewriteRuleTokenStream stream_BIT_AND=new RewriteRuleTokenStream(adaptor,"token BIT_AND");
        RewriteRuleTokenStream stream_IDENTIFIER=new RewriteRuleTokenStream(adaptor,"token IDENTIFIER");
        RewriteRuleTokenStream stream_DOLLAR_T=new RewriteRuleTokenStream(adaptor,"token DOLLAR_T");

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1107:3: ( ( '&' )? ( DOLLAR_T )+ IDENTIFIER -> ^( VAR_DECL ( '&' )? ( DOLLAR_T )+ IDENTIFIER ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1107:5: ( '&' )? ( DOLLAR_T )+ IDENTIFIER
            {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1107:5: ( '&' )?
            int alt131=2;
            int LA131_0 = input.LA(1);

            if ( (LA131_0==BIT_AND) ) {
                alt131=1;
            }
            switch (alt131) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1107:5: '&'
                    {
                    char_literal372=(Token)match(input,BIT_AND,FOLLOW_BIT_AND_in_pure_variable4900); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_BIT_AND.add(char_literal372);


                    }
                    break;

            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1107:10: ( DOLLAR_T )+
            int cnt132=0;
            loop132:
            do {
                int alt132=2;
                int LA132_0 = input.LA(1);

                if ( (LA132_0==DOLLAR_T) ) {
                    alt132=1;
                }


                switch (alt132) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1107:10: DOLLAR_T
            	    {
            	    DOLLAR_T373=(Token)match(input,DOLLAR_T,FOLLOW_DOLLAR_T_in_pure_variable4903); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_DOLLAR_T.add(DOLLAR_T373);


            	    }
            	    break;

            	default :
            	    if ( cnt132 >= 1 ) break loop132;
            	    if (state.backtracking>0) {state.failed=true; return retval;}
                        EarlyExitException eee =
                            new EarlyExitException(132, input);
                        throw eee;
                }
                cnt132++;
            } while (true);

            IDENTIFIER374=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_pure_variable4906); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER374);



            // AST REWRITE
            // elements: BIT_AND, IDENTIFIER, DOLLAR_T
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 1107:34: -> ^( VAR_DECL ( '&' )? ( DOLLAR_T )+ IDENTIFIER )
            {
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1107:38: ^( VAR_DECL ( '&' )? ( DOLLAR_T )+ IDENTIFIER )
                {
                SLAST root_1 = (SLAST)adaptor.nil();
                root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(VAR_DECL, "VAR_DECL"), root_1);

                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1107:49: ( '&' )?
                if ( stream_BIT_AND.hasNext() ) {
                    adaptor.addChild(root_1, stream_BIT_AND.nextNode());

                }
                stream_BIT_AND.reset();
                if ( !(stream_DOLLAR_T.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_DOLLAR_T.hasNext() ) {
                    adaptor.addChild(root_1, stream_DOLLAR_T.nextNode());

                }
                stream_DOLLAR_T.reset();
                adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "pure_variable"

    public static class scalar_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "scalar"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1110:1: scalar : constant -> ^( SCALAR constant ) ;
    public final CompilerAstParser.scalar_return scalar() throws RecognitionException {
        CompilerAstParser.scalar_return retval = new CompilerAstParser.scalar_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        CompilerAstParser.constant_return constant375 = null;


        RewriteRuleSubtreeStream stream_constant=new RewriteRuleSubtreeStream(adaptor,"rule constant");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1120:3: ( constant -> ^( SCALAR constant ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1120:5: constant
            {
            pushFollow(FOLLOW_constant_in_scalar4947);
            constant375=constant();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_constant.add(constant375.getTree());
            if ( state.backtracking==0 ) {

                  token = (CommonToken)(constant375!=null?((Token)constant375.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(constant375!=null?((Token)constant375.stop):null);
                  endIndex = token.getStopIndex();
                
            }


            // AST REWRITE
            // elements: constant
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 1127:5: -> ^( SCALAR constant )
            {
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1127:9: ^( SCALAR constant )
                {
                SLAST root_1 = (SLAST)adaptor.nil();
                root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(SCALAR, "SCALAR"), root_1);

                adaptor.addChild(root_1, stream_constant.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST exprToken = retval.tree;
                exprToken.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "scalar"

    public static class constant_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "constant"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1130:1: constant : ( INTLITERAL | FLOATLITERAL | STRINGLITERAL | DOUBLELITERRAL | common_scalar | fully_qualified_class_name );
    public final CompilerAstParser.constant_return constant() throws RecognitionException {
        CompilerAstParser.constant_return retval = new CompilerAstParser.constant_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token INTLITERAL376=null;
        Token FLOATLITERAL377=null;
        Token STRINGLITERAL378=null;
        Token DOUBLELITERRAL379=null;
        CompilerAstParser.common_scalar_return common_scalar380 = null;

        CompilerAstParser.fully_qualified_class_name_return fully_qualified_class_name381 = null;


        SLAST INTLITERAL376_tree=null;
        SLAST FLOATLITERAL377_tree=null;
        SLAST STRINGLITERAL378_tree=null;
        SLAST DOUBLELITERRAL379_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1131:3: ( INTLITERAL | FLOATLITERAL | STRINGLITERAL | DOUBLELITERRAL | common_scalar | fully_qualified_class_name )
            int alt133=6;
            switch ( input.LA(1) ) {
            case INTLITERAL:
                {
                alt133=1;
                }
                break;
            case FLOATLITERAL:
                {
                alt133=2;
                }
                break;
            case STRINGLITERAL:
                {
                alt133=3;
                }
                break;
            case DOUBLELITERRAL:
                {
                alt133=4;
                }
                break;
            case 173:
            case 174:
            case 175:
            case 176:
            case 177:
            case 178:
                {
                alt133=5;
                }
                break;
            case IDENTIFIER:
                {
                alt133=6;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 133, 0, input);

                throw nvae;
            }

            switch (alt133) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1131:5: INTLITERAL
                    {
                    root_0 = (SLAST)adaptor.nil();

                    INTLITERAL376=(Token)match(input,INTLITERAL,FOLLOW_INTLITERAL_in_constant4982); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    INTLITERAL376_tree = (SLAST)adaptor.create(INTLITERAL376);
                    adaptor.addChild(root_0, INTLITERAL376_tree);
                    }

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1132:5: FLOATLITERAL
                    {
                    root_0 = (SLAST)adaptor.nil();

                    FLOATLITERAL377=(Token)match(input,FLOATLITERAL,FOLLOW_FLOATLITERAL_in_constant4991); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    FLOATLITERAL377_tree = (SLAST)adaptor.create(FLOATLITERAL377);
                    adaptor.addChild(root_0, FLOATLITERAL377_tree);
                    }

                    }
                    break;
                case 3 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1133:5: STRINGLITERAL
                    {
                    root_0 = (SLAST)adaptor.nil();

                    STRINGLITERAL378=(Token)match(input,STRINGLITERAL,FOLLOW_STRINGLITERAL_in_constant4999); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    STRINGLITERAL378_tree = (SLAST)adaptor.create(STRINGLITERAL378);
                    adaptor.addChild(root_0, STRINGLITERAL378_tree);
                    }

                    }
                    break;
                case 4 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1134:5: DOUBLELITERRAL
                    {
                    root_0 = (SLAST)adaptor.nil();

                    DOUBLELITERRAL379=(Token)match(input,DOUBLELITERRAL,FOLLOW_DOUBLELITERRAL_in_constant5008); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    DOUBLELITERRAL379_tree = (SLAST)adaptor.create(DOUBLELITERRAL379);
                    adaptor.addChild(root_0, DOUBLELITERRAL379_tree);
                    }

                    }
                    break;
                case 5 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1135:5: common_scalar
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_common_scalar_in_constant5015);
                    common_scalar380=common_scalar();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, common_scalar380.getTree());

                    }
                    break;
                case 6 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1136:5: fully_qualified_class_name
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_fully_qualified_class_name_in_constant5023);
                    fully_qualified_class_name381=fully_qualified_class_name();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, fully_qualified_class_name381.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "constant"

    public static class common_scalar_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "common_scalar"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1139:1: common_scalar : ( '__CLASS__' | '__DIR__' | '__FILE__' | '__FUNCTION__' | '__METHOD__' | '__NAMESPACE__' );
    public final CompilerAstParser.common_scalar_return common_scalar() throws RecognitionException {
        CompilerAstParser.common_scalar_return retval = new CompilerAstParser.common_scalar_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token set382=null;

        SLAST set382_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1140:3: ( '__CLASS__' | '__DIR__' | '__FILE__' | '__FUNCTION__' | '__METHOD__' | '__NAMESPACE__' )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:
            {
            root_0 = (SLAST)adaptor.nil();

            set382=(Token)input.LT(1);
            if ( (input.LA(1)>=173 && input.LA(1)<=178) ) {
                input.consume();
                if ( state.backtracking==0 ) adaptor.addChild(root_0, (SLAST)adaptor.create(set382));
                state.errorRecovery=false;state.failed=false;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                MismatchedSetException mse = new MismatchedSetException(null,input);
                throw mse;
            }


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "common_scalar"

    // $ANTLR start synpred1_CompilerAst
    public final void synpred1_CompilerAst_fragment() throws RecognitionException {   
        CompilerAstParser.expression_return eElseCond = null;

        CompilerAstParser.statement_return s2 = null;


        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:297:53: ( 'elseif' LEFT_PARETHESIS eElseCond= expression RIGHT_PARETHESIS s2= statement )
        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:297:53: 'elseif' LEFT_PARETHESIS eElseCond= expression RIGHT_PARETHESIS s2= statement
        {
        match(input,117,FOLLOW_117_in_synpred1_CompilerAst1889); if (state.failed) return ;
        match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_synpred1_CompilerAst1891); if (state.failed) return ;
        pushFollow(FOLLOW_expression_in_synpred1_CompilerAst1895);
        eElseCond=expression();

        state._fsp--;
        if (state.failed) return ;
        match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_synpred1_CompilerAst1897); if (state.failed) return ;
        pushFollow(FOLLOW_statement_in_synpred1_CompilerAst1901);
        s2=statement();

        state._fsp--;
        if (state.failed) return ;

        }
    }
    // $ANTLR end synpred1_CompilerAst

    // $ANTLR start synpred2_CompilerAst
    public final void synpred2_CompilerAst_fragment() throws RecognitionException {   
        CompilerAstParser.statement_return s3 = null;


        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:298:42: ( 'else' s3= statement )
        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:298:42: 'else' s3= statement
        {
        match(input,118,FOLLOW_118_in_synpred2_CompilerAst1927); if (state.failed) return ;
        pushFollow(FOLLOW_statement_in_synpred2_CompilerAst1931);
        s3=statement();

        state._fsp--;
        if (state.failed) return ;

        }
    }
    // $ANTLR end synpred2_CompilerAst

    // Delegated rules

    public final boolean synpred2_CompilerAst() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred2_CompilerAst_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }
    public final boolean synpred1_CompilerAst() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred1_CompilerAst_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }


    protected DFA17 dfa17 = new DFA17(this);
    protected DFA42 dfa42 = new DFA42(this);
    protected DFA43 dfa43 = new DFA43(this);
    protected DFA103 dfa103 = new DFA103(this);
    protected DFA108 dfa108 = new DFA108(this);
    protected DFA120 dfa120 = new DFA120(this);
    protected DFA126 dfa126 = new DFA126(this);
    static final String DFA17_eotS =
        "\5\uffff";
    static final String DFA17_eofS =
        "\5\uffff";
    static final String DFA17_minS =
        "\1\135\1\uffff\1\74\2\uffff";
    static final String DFA17_maxS =
        "\1\u0084\1\uffff\1\u0084\2\uffff";
    static final String DFA17_acceptS =
        "\1\uffff\1\1\1\uffff\1\2\1\3";
    static final String DFA17_specialS =
        "\5\uffff}>";
    static final String[] DFA17_transitionS = {
            "\2\2\1\3\10\uffff\1\2\10\uffff\1\4\17\uffff\1\1\3\2",
            "",
            "\1\1\10\uffff\1\1\27\uffff\2\2\1\3\10\uffff\1\2\31\uffff\3"+
            "\2",
            "",
            ""
    };

    static final short[] DFA17_eot = DFA.unpackEncodedString(DFA17_eotS);
    static final short[] DFA17_eof = DFA.unpackEncodedString(DFA17_eofS);
    static final char[] DFA17_min = DFA.unpackEncodedStringToUnsignedChars(DFA17_minS);
    static final char[] DFA17_max = DFA.unpackEncodedStringToUnsignedChars(DFA17_maxS);
    static final short[] DFA17_accept = DFA.unpackEncodedString(DFA17_acceptS);
    static final short[] DFA17_special = DFA.unpackEncodedString(DFA17_specialS);
    static final short[][] DFA17_transition;

    static {
        int numStates = DFA17_transitionS.length;
        DFA17_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA17_transition[i] = DFA.unpackEncodedString(DFA17_transitionS[i]);
        }
    }

    class DFA17 extends DFA {

        public DFA17(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 17;
            this.eot = DFA17_eot;
            this.eof = DFA17_eof;
            this.min = DFA17_min;
            this.max = DFA17_max;
            this.accept = DFA17_accept;
            this.special = DFA17_special;
            this.transition = DFA17_transition;
        }
        public String getDescription() {
            return "182:1: class_statement : ( variable_modifiers static_var_list ';' -> ^( FIELD_DECL variable_modifiers static_var_list ) | ( modifier )? method_declaration -> ^( METHOD_DECL ( modifier )? method_declaration ) | class_constant_declaration ';' -> ^( FIELD_DECL class_constant_declaration ) );";
        }
    }
    static final String DFA42_eotS =
        "\70\uffff";
    static final String DFA42_eofS =
        "\1\1\67\uffff";
    static final String DFA42_minS =
        "\1\50\54\uffff\1\0\12\uffff";
    static final String DFA42_maxS =
        "\1\u00b2\54\uffff\1\0\12\uffff";
    static final String DFA42_acceptS =
        "\1\uffff\1\2\65\uffff\1\1";
    static final String DFA42_specialS =
        "\55\uffff\1\0\12\uffff}>";
    static final String[] DFA42_transitionS = {
            "\2\1\1\uffff\5\1\14\uffff\3\1\2\uffff\2\1\2\uffff\4\1\17\uffff"+
            "\2\1\2\uffff\17\1\1\uffff\4\1\4\uffff\1\1\1\55\1\1\1\uffff\4"+
            "\1\1\uffff\4\1\37\uffff\2\1\1\uffff\4\1\1\uffff\4\1\1\uffff"+
            "\6\1",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\1\uffff",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA42_eot = DFA.unpackEncodedString(DFA42_eotS);
    static final short[] DFA42_eof = DFA.unpackEncodedString(DFA42_eofS);
    static final char[] DFA42_min = DFA.unpackEncodedStringToUnsignedChars(DFA42_minS);
    static final char[] DFA42_max = DFA.unpackEncodedStringToUnsignedChars(DFA42_maxS);
    static final short[] DFA42_accept = DFA.unpackEncodedString(DFA42_acceptS);
    static final short[] DFA42_special = DFA.unpackEncodedString(DFA42_specialS);
    static final short[][] DFA42_transition;

    static {
        int numStates = DFA42_transitionS.length;
        DFA42_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA42_transition[i] = DFA.unpackEncodedString(DFA42_transitionS[i]);
        }
    }

    class DFA42 extends DFA {

        public DFA42(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 42;
            this.eot = DFA42_eot;
            this.eof = DFA42_eof;
            this.min = DFA42_min;
            this.max = DFA42_max;
            this.accept = DFA42_accept;
            this.special = DFA42_special;
            this.transition = DFA42_transition;
        }
        public String getDescription() {
            return "()* loopback of 297:20: ( options {k=1; backtrack=true; } : 'elseif' LEFT_PARETHESIS eElseCond= expression RIGHT_PARETHESIS s2= statement )*";
        }
        public int specialStateTransition(int s, IntStream _input) throws NoViableAltException {
            TokenStream input = (TokenStream)_input;
        	int _s = s;
            switch ( s ) {
                    case 0 : 
                        int LA42_45 = input.LA(1);

                         
                        int index42_45 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred1_CompilerAst()) ) {s = 55;}

                        else if ( (true) ) {s = 1;}

                         
                        input.seek(index42_45);
                        if ( s>=0 ) return s;
                        break;
            }
            if (state.backtracking>0) {state.failed=true; return -1;}
            NoViableAltException nvae =
                new NoViableAltException(getDescription(), 42, _s, input);
            error(nvae);
            throw nvae;
        }
    }
    static final String DFA43_eotS =
        "\70\uffff";
    static final String DFA43_eofS =
        "\1\2\67\uffff";
    static final String DFA43_minS =
        "\1\50\1\0\66\uffff";
    static final String DFA43_maxS =
        "\1\u00b2\1\0\66\uffff";
    static final String DFA43_acceptS =
        "\2\uffff\1\2\64\uffff\1\1";
    static final String DFA43_specialS =
        "\1\uffff\1\0\66\uffff}>";
    static final String[] DFA43_transitionS = {
            "\2\2\1\uffff\5\2\14\uffff\3\2\2\uffff\2\2\2\uffff\4\2\17\uffff"+
            "\2\2\2\uffff\17\2\1\uffff\4\2\4\uffff\2\2\1\1\1\uffff\4\2\1"+
            "\uffff\4\2\37\uffff\2\2\1\uffff\4\2\1\uffff\4\2\1\uffff\6\2",
            "\1\uffff",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA43_eot = DFA.unpackEncodedString(DFA43_eotS);
    static final short[] DFA43_eof = DFA.unpackEncodedString(DFA43_eofS);
    static final char[] DFA43_min = DFA.unpackEncodedStringToUnsignedChars(DFA43_minS);
    static final char[] DFA43_max = DFA.unpackEncodedStringToUnsignedChars(DFA43_maxS);
    static final short[] DFA43_accept = DFA.unpackEncodedString(DFA43_acceptS);
    static final short[] DFA43_special = DFA.unpackEncodedString(DFA43_specialS);
    static final short[][] DFA43_transition;

    static {
        int numStates = DFA43_transitionS.length;
        DFA43_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA43_transition[i] = DFA.unpackEncodedString(DFA43_transitionS[i]);
        }
    }

    class DFA43 extends DFA {

        public DFA43(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 43;
            this.eot = DFA43_eot;
            this.eof = DFA43_eof;
            this.min = DFA43_min;
            this.max = DFA43_max;
            this.accept = DFA43_accept;
            this.special = DFA43_special;
            this.transition = DFA43_transition;
        }
        public String getDescription() {
            return "298:9: ( options {k=1; backtrack=true; } : 'else' s3= statement )?";
        }
        public int specialStateTransition(int s, IntStream _input) throws NoViableAltException {
            TokenStream input = (TokenStream)_input;
        	int _s = s;
            switch ( s ) {
                    case 0 : 
                        int LA43_1 = input.LA(1);

                         
                        int index43_1 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred2_CompilerAst()) ) {s = 55;}

                        else if ( (true) ) {s = 2;}

                         
                        input.seek(index43_1);
                        if ( s>=0 ) return s;
                        break;
            }
            if (state.backtracking>0) {state.failed=true; return -1;}
            NoViableAltException nvae =
                new NoViableAltException(getDescription(), 43, _s, input);
            error(nvae);
            throw nvae;
        }
    }
    static final String DFA103_eotS =
        "\20\uffff";
    static final String DFA103_eofS =
        "\20\uffff";
    static final String DFA103_minS =
        "\1\51\1\54\1\51\13\uffff\2\51";
    static final String DFA103_maxS =
        "\2\u00b2\1\u00a7\13\uffff\2\u00a7";
    static final String DFA103_acceptS =
        "\3\uffff\1\1\1\2\1\3\1\4\1\5\1\6\1\7\1\10\1\11\1\12\1\13\2\uffff";
    static final String DFA103_specialS =
        "\20\uffff}>";
    static final String[] DFA103_transitionS = {
            "\1\5\2\uffff\1\2\2\uffff\1\4\22\uffff\1\15\2\uffff\1\3\3\4\26"+
            "\uffff\1\14\100\uffff\1\13\1\11\1\uffff\1\7\4\uffff\1\1\1\6"+
            "\1\10\1\12\1\uffff\6\4",
            "\1\2\2\uffff\1\4\25\uffff\1\3\3\4\144\uffff\6\4",
            "\1\3\1\4\3\uffff\1\4\1\uffff\21\4\3\uffff\1\4\1\3\23\uffff"+
            "\1\4\21\uffff\1\4\4\uffff\1\4\1\uffff\1\4\1\16\3\uffff\1\4\15"+
            "\uffff\24\4\14\uffff\3\4",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\1\3\1\4\1\uffff\1\17\1\uffff\1\4\1\uffff\21\4\3\uffff\1\4"+
            "\1\3\23\uffff\1\4\21\uffff\1\4\4\uffff\1\4\1\uffff\1\4\4\uffff"+
            "\1\4\15\uffff\24\4\14\uffff\3\4",
            "\1\3\1\4\3\uffff\1\4\1\uffff\21\4\3\uffff\1\4\1\3\23\uffff"+
            "\1\4\21\uffff\1\4\4\uffff\1\4\1\uffff\1\4\1\16\3\uffff\1\4\15"+
            "\uffff\24\4\14\uffff\3\4"
    };

    static final short[] DFA103_eot = DFA.unpackEncodedString(DFA103_eotS);
    static final short[] DFA103_eof = DFA.unpackEncodedString(DFA103_eofS);
    static final char[] DFA103_min = DFA.unpackEncodedStringToUnsignedChars(DFA103_minS);
    static final char[] DFA103_max = DFA.unpackEncodedStringToUnsignedChars(DFA103_maxS);
    static final short[] DFA103_accept = DFA.unpackEncodedString(DFA103_acceptS);
    static final short[] DFA103_special = DFA.unpackEncodedString(DFA103_specialS);
    static final short[][] DFA103_transition;

    static {
        int numStates = DFA103_transitionS.length;
        DFA103_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA103_transition[i] = DFA.unpackEncodedString(DFA103_transitionS[i]);
        }
    }

    class DFA103 extends DFA {

        public DFA103(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 103;
            this.eot = DFA103_eot;
            this.eof = DFA103_eof;
            this.min = DFA103_min;
            this.max = DFA103_max;
            this.accept = DFA103_accept;
            this.special = DFA103_special;
            this.transition = DFA103_transition;
        }
        public String getDescription() {
            return "884:1: atom_expr : ( ( '@' )? variable | ( '@' )? scalar | LEFT_PARETHESIS expression RIGHT_PARETHESIS | 'list' LEFT_PARETHESIS assignment_list RIGHT_PARETHESIS -> ^( 'list' assignment_list ) | 'array' LEFT_PARETHESIS ( array_pair_list )? RIGHT_PARETHESIS -> ^( ARRAY_DECL ( array_pair_list )? ) | 'new' class_name_reference -> ^( 'new' class_name_reference ) | 'clone' variable -> ^( 'clone' variable ) | 'exit' ( LEFT_PARETHESIS ( expression )? RIGHT_PARETHESIS )? -> ^( 'exit' ( expression )? ) | 'unset' LEFT_PARETHESIS variable_list RIGHT_PARETHESIS -> ^( 'unset' variable_list ) | lambda_function_declaration | BACKTRICKLITERAL );";
        }
    }
    static final String DFA108_eotS =
        "\6\uffff";
    static final String DFA108_eofS =
        "\6\uffff";
    static final String DFA108_minS =
        "\1\54\1\51\1\uffff\1\51\1\uffff\1\51";
    static final String DFA108_maxS =
        "\1\105\1\u00a7\1\uffff\1\u00a7\1\uffff\1\u00a7";
    static final String DFA108_acceptS =
        "\2\uffff\1\1\1\uffff\1\2\1\uffff";
    static final String DFA108_specialS =
        "\6\uffff}>";
    static final String[] DFA108_transitionS = {
            "\1\1\30\uffff\1\2",
            "\1\2\1\4\3\uffff\1\4\1\uffff\21\4\3\uffff\1\4\1\2\23\uffff"+
            "\1\4\21\uffff\1\4\4\uffff\1\4\1\uffff\1\4\1\3\3\uffff\1\4\15"+
            "\uffff\24\4\14\uffff\3\4",
            "",
            "\1\2\1\4\1\uffff\1\5\1\uffff\1\4\1\uffff\21\4\3\uffff\1\4\1"+
            "\2\23\uffff\1\4\21\uffff\1\4\4\uffff\1\4\1\uffff\1\4\4\uffff"+
            "\1\4\15\uffff\24\4\14\uffff\3\4",
            "",
            "\1\2\1\4\3\uffff\1\4\1\uffff\21\4\3\uffff\1\4\1\2\23\uffff"+
            "\1\4\21\uffff\1\4\4\uffff\1\4\1\uffff\1\4\1\3\3\uffff\1\4\15"+
            "\uffff\24\4\14\uffff\3\4"
    };

    static final short[] DFA108_eot = DFA.unpackEncodedString(DFA108_eotS);
    static final short[] DFA108_eof = DFA.unpackEncodedString(DFA108_eofS);
    static final char[] DFA108_min = DFA.unpackEncodedStringToUnsignedChars(DFA108_minS);
    static final char[] DFA108_max = DFA.unpackEncodedStringToUnsignedChars(DFA108_maxS);
    static final short[] DFA108_accept = DFA.unpackEncodedString(DFA108_acceptS);
    static final short[] DFA108_special = DFA.unpackEncodedString(DFA108_specialS);
    static final short[][] DFA108_transition;

    static {
        int numStates = DFA108_transitionS.length;
        DFA108_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA108_transition[i] = DFA.unpackEncodedString(DFA108_transitionS[i]);
        }
    }

    class DFA108 extends DFA {

        public DFA108(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 108;
            this.eot = DFA108_eot;
            this.eof = DFA108_eof;
            this.min = DFA108_min;
            this.max = DFA108_max;
            this.accept = DFA108_accept;
            this.special = DFA108_special;
            this.transition = DFA108_transition;
        }
        public String getDescription() {
            return "923:1: class_name_reference : ( variable | fully_qualified_class_name );";
        }
    }
    static final String DFA120_eotS =
        "\6\uffff";
    static final String DFA120_eofS =
        "\6\uffff";
    static final String DFA120_minS =
        "\1\54\1\51\1\uffff\1\51\1\uffff\1\51";
    static final String DFA120_maxS =
        "\1\105\1\163\1\uffff\1\105\1\uffff\1\163";
    static final String DFA120_acceptS =
        "\2\uffff\1\1\1\uffff\1\2\1\uffff";
    static final String DFA120_specialS =
        "\6\uffff}>";
    static final String[] DFA120_transitionS = {
            "\1\1\30\uffff\1\2",
            "\1\4\33\uffff\1\2\55\uffff\1\3",
            "",
            "\1\4\2\uffff\1\5\30\uffff\1\2",
            "",
            "\1\4\33\uffff\1\2\55\uffff\1\3"
    };

    static final short[] DFA120_eot = DFA.unpackEncodedString(DFA120_eotS);
    static final short[] DFA120_eof = DFA.unpackEncodedString(DFA120_eofS);
    static final char[] DFA120_min = DFA.unpackEncodedStringToUnsignedChars(DFA120_minS);
    static final char[] DFA120_max = DFA.unpackEncodedStringToUnsignedChars(DFA120_maxS);
    static final short[] DFA120_accept = DFA.unpackEncodedString(DFA120_acceptS);
    static final short[] DFA120_special = DFA.unpackEncodedString(DFA120_specialS);
    static final short[][] DFA120_transition;

    static {
        int numStates = DFA120_transitionS.length;
        DFA120_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA120_transition[i] = DFA.unpackEncodedString(DFA120_transitionS[i]);
        }
    }

    class DFA120 extends DFA {

        public DFA120(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 120;
            this.eot = DFA120_eot;
            this.eof = DFA120_eof;
            this.min = DFA120_min;
            this.max = DFA120_max;
            this.accept = DFA120_accept;
            this.special = DFA120_special;
            this.transition = DFA120_transition;
        }
        public String getDescription() {
            return "990:1: base_variable_with_function_calls : ( ( fully_qualified_class_name )? reference_variable ( ctor_arguments )? -> ^( VAR_DECL ( fully_qualified_class_name )? reference_variable ( ctor_arguments )? ) | fully_qualified_class_name ctor_arguments -> ^( CALL fully_qualified_class_name ctor_arguments ) );";
        }
    }
    static final String DFA126_eotS =
        "\4\uffff";
    static final String DFA126_eofS =
        "\4\uffff";
    static final String DFA126_minS =
        "\1\105\1\54\2\uffff";
    static final String DFA126_maxS =
        "\2\105\2\uffff";
    static final String DFA126_acceptS =
        "\2\uffff\1\1\1\2";
    static final String DFA126_specialS =
        "\4\uffff}>";
    static final String[] DFA126_transitionS = {
            "\1\1",
            "\1\2\1\3\27\uffff\1\1",
            "",
            ""
    };

    static final short[] DFA126_eot = DFA.unpackEncodedString(DFA126_eotS);
    static final short[] DFA126_eof = DFA.unpackEncodedString(DFA126_eofS);
    static final char[] DFA126_min = DFA.unpackEncodedStringToUnsignedChars(DFA126_minS);
    static final char[] DFA126_max = DFA.unpackEncodedStringToUnsignedChars(DFA126_maxS);
    static final short[] DFA126_accept = DFA.unpackEncodedString(DFA126_acceptS);
    static final short[] DFA126_special = DFA.unpackEncodedString(DFA126_specialS);
    static final short[][] DFA126_transition;

    static {
        int numStates = DFA126_transitionS.length;
        DFA126_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA126_transition[i] = DFA.unpackEncodedString(DFA126_transitionS[i]);
        }
    }

    class DFA126 extends DFA {

        public DFA126(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 126;
            this.eot = DFA126_eot;
            this.eof = DFA126_eof;
            this.min = DFA126_min;
            this.max = DFA126_max;
            this.accept = DFA126_accept;
            this.special = DFA126_special;
            this.transition = DFA126_transition;
        }
        public String getDescription() {
            return "1058:1: compound_variable : ( ( DOLLAR_T )+ IDENTIFIER | ( DOLLAR_T )+ LEFT_BRACKET expression RIGHT_BRACKET );";
        }
    }
 

    public static final BitSet FOLLOW_SOC_T_in_php_source241 = new BitSet(new long[]{0x7000BB0000000000L,0x0010F7FFF30001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_SOC_PHP_T_in_php_source253 = new BitSet(new long[]{0x7000BB0000000000L,0x0010F7FFF30001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_top_statement_list_in_php_source268 = new BitSet(new long[]{0x0000010000000000L});
    public static final BitSet FOLLOW_EOC_T_in_php_source277 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_top_statement_in_top_statement_list315 = new BitSet(new long[]{0x7000BA0000000002L,0x0010F7FFF30001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_statement_in_top_statement329 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_function_declaration_statement_in_top_statement335 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_class_declaration_statement_in_top_statement341 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_halt_compiler_statement_in_top_statement347 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_inner_statement_in_inner_statement_list363 = new BitSet(new long[]{0x7000BA0000000002L,0x0010F7FFF30001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_statement_in_inner_statement380 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_function_declaration_statement_in_inner_statement386 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_class_declaration_statement_in_inner_statement392 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_halt_compiler_statement_in_inner_statement398 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_88_in_halt_compiler_statement413 = new BitSet(new long[]{0x0000020000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_halt_compiler_statement415 = new BitSet(new long[]{0x0000040000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_halt_compiler_statement417 = new BitSet(new long[]{0x0000000000000000L,0x0000000002000000L});
    public static final BitSet FOLLOW_89_in_halt_compiler_statement419 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_class_entr_type_in_class_declaration_statement454 = new BitSet(new long[]{0x0000080000000000L});
    public static final BitSet FOLLOW_CLASS_T_in_class_declaration_statement457 = new BitSet(new long[]{0x0000100000000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_class_declaration_statement459 = new BitSet(new long[]{0x0000200000000000L,0x000000000C000000L});
    public static final BitSet FOLLOW_90_in_class_declaration_statement462 = new BitSet(new long[]{0x0000100000000000L});
    public static final BitSet FOLLOW_fully_qualified_class_name_in_class_declaration_statement464 = new BitSet(new long[]{0x0000200000000000L,0x0000000008000000L});
    public static final BitSet FOLLOW_91_in_class_declaration_statement469 = new BitSet(new long[]{0x0000100000000000L});
    public static final BitSet FOLLOW_fully_qualified_class_name_list_in_class_declaration_statement471 = new BitSet(new long[]{0x0000200000000000L});
    public static final BitSet FOLLOW_LEFT_BRACKET_in_class_declaration_statement481 = new BitSet(new long[]{0x0000400000000000L,0x00020100E0000000L,0x000000000000001EL});
    public static final BitSet FOLLOW_class_statement_list_in_class_declaration_statement483 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_RIGHT_BRACKET_in_class_declaration_statement486 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_92_in_class_declaration_statement547 = new BitSet(new long[]{0x0000100000000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_class_declaration_statement549 = new BitSet(new long[]{0x0000200000000000L,0x000000000C000000L});
    public static final BitSet FOLLOW_90_in_class_declaration_statement552 = new BitSet(new long[]{0x0000100000000000L});
    public static final BitSet FOLLOW_fully_qualified_class_name_list_in_class_declaration_statement554 = new BitSet(new long[]{0x0000200000000000L,0x0000000008000000L});
    public static final BitSet FOLLOW_91_in_class_declaration_statement559 = new BitSet(new long[]{0x0000100000000000L});
    public static final BitSet FOLLOW_fully_qualified_class_name_list_in_class_declaration_statement561 = new BitSet(new long[]{0x0000200000000000L});
    public static final BitSet FOLLOW_LEFT_BRACKET_in_class_declaration_statement571 = new BitSet(new long[]{0x0000400000000000L,0x00020100E0000000L,0x000000000000001EL});
    public static final BitSet FOLLOW_class_statement_list_in_class_declaration_statement573 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_RIGHT_BRACKET_in_class_declaration_statement576 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_class_entr_type0 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_class_statement_in_class_statement_list651 = new BitSet(new long[]{0x0000000000000002L,0x00020100E0000000L,0x000000000000001EL});
    public static final BitSet FOLLOW_variable_modifiers_in_class_statement678 = new BitSet(new long[]{0x1000000000000000L,0x0000000000000020L});
    public static final BitSet FOLLOW_static_var_list_in_class_statement680 = new BitSet(new long[]{0x0000000000000000L,0x0000000002000000L});
    public static final BitSet FOLLOW_89_in_class_statement682 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_modifier_in_class_statement702 = new BitSet(new long[]{0x0000000000000000L,0x00000100E0000000L,0x000000000000001EL});
    public static final BitSet FOLLOW_method_declaration_in_class_statement705 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_class_constant_declaration_in_class_statement730 = new BitSet(new long[]{0x0000000000000000L,0x0000000002000000L});
    public static final BitSet FOLLOW_89_in_class_statement732 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_95_in_function_declaration_statement765 = new BitSet(new long[]{0x1000100000000000L});
    public static final BitSet FOLLOW_BIT_AND_in_function_declaration_statement767 = new BitSet(new long[]{0x0000100000000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_function_declaration_statement770 = new BitSet(new long[]{0x0000020000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_function_declaration_statement772 = new BitSet(new long[]{0x1000140000000000L,0x0002000000000020L,0x0000000FFE000000L});
    public static final BitSet FOLLOW_parameter_list_in_function_declaration_statement774 = new BitSet(new long[]{0x0000040000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_function_declaration_statement777 = new BitSet(new long[]{0x0000200000000000L});
    public static final BitSet FOLLOW_block_in_function_declaration_statement784 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LEFT_BRACKET_in_block816 = new BitSet(new long[]{0x7000FA0000000000L,0x0010F7FFF30001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_inner_statement_list_in_block818 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_RIGHT_BRACKET_in_block821 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_topStatement_in_statement858 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_block_in_topStatement890 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_if_stat_in_topStatement896 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_96_in_topStatement902 = new BitSet(new long[]{0x0000020000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_topStatement904 = new BitSet(new long[]{0x7000920000000000L,0x00000000800001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_expression_in_topStatement906 = new BitSet(new long[]{0x0000040000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_topStatement908 = new BitSet(new long[]{0x7000B20000000000L,0x0090F7FF820001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_while_statement_in_topStatement910 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_97_in_topStatement934 = new BitSet(new long[]{0x7000B20000000000L,0x0010F7FF820001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_statement_in_topStatement936 = new BitSet(new long[]{0x0000000000000000L,0x0000000100000000L});
    public static final BitSet FOLLOW_96_in_topStatement938 = new BitSet(new long[]{0x0000020000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_topStatement940 = new BitSet(new long[]{0x7000920000000000L,0x00000000800001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_expression_in_topStatement942 = new BitSet(new long[]{0x0000040000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_topStatement944 = new BitSet(new long[]{0x0000000000000000L,0x0000000002000000L});
    public static final BitSet FOLLOW_89_in_topStatement946 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_98_in_topStatement967 = new BitSet(new long[]{0x0000020000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_topStatement969 = new BitSet(new long[]{0x7000920000000000L,0x00000000820001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_expr_list_in_topStatement973 = new BitSet(new long[]{0x0000000000000000L,0x0000000002000000L});
    public static final BitSet FOLLOW_89_in_topStatement976 = new BitSet(new long[]{0x7000920000000000L,0x00000000820001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_expr_list_in_topStatement980 = new BitSet(new long[]{0x0000000000000000L,0x0000000002000000L});
    public static final BitSet FOLLOW_89_in_topStatement983 = new BitSet(new long[]{0x7000960000000000L,0x00000000800001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_expr_list_in_topStatement987 = new BitSet(new long[]{0x0000040000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_topStatement990 = new BitSet(new long[]{0x0000000000000002L,0x0080000000000000L});
    public static final BitSet FOLLOW_for_statement_in_topStatement992 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_99_in_topStatement1032 = new BitSet(new long[]{0x0000020000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_topStatement1034 = new BitSet(new long[]{0x7000920000000000L,0x00000000800001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_expression_in_topStatement1036 = new BitSet(new long[]{0x0000040000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_topStatement1038 = new BitSet(new long[]{0x0000200000000000L,0x0080000000000000L});
    public static final BitSet FOLLOW_switch_case_list_in_topStatement1040 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_100_in_topStatement1062 = new BitSet(new long[]{0x7000920000000000L,0x00000000820001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_expression_in_topStatement1064 = new BitSet(new long[]{0x0000000000000000L,0x0000000002000000L});
    public static final BitSet FOLLOW_89_in_topStatement1067 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_101_in_topStatement1095 = new BitSet(new long[]{0x7000920000000000L,0x00000000820001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_expression_in_topStatement1097 = new BitSet(new long[]{0x0000000000000000L,0x0000000002000000L});
    public static final BitSet FOLLOW_89_in_topStatement1100 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_102_in_topStatement1127 = new BitSet(new long[]{0x7000920000000000L,0x00000000820001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_expression_in_topStatement1129 = new BitSet(new long[]{0x0000000000000000L,0x0000000002000000L});
    public static final BitSet FOLLOW_89_in_topStatement1132 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_103_in_topStatement1159 = new BitSet(new long[]{0x0000100000000000L,0x0000000000000020L,0x0000010000000000L});
    public static final BitSet FOLLOW_variable_list_in_topStatement1161 = new BitSet(new long[]{0x0000000000000000L,0x0000000002000000L});
    public static final BitSet FOLLOW_89_in_topStatement1163 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_104_in_topStatement1189 = new BitSet(new long[]{0x1000000000000000L,0x0000000000000020L});
    public static final BitSet FOLLOW_static_var_list_in_topStatement1191 = new BitSet(new long[]{0x0000000000000000L,0x0000000002000000L});
    public static final BitSet FOLLOW_89_in_topStatement1193 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_105_in_topStatement1217 = new BitSet(new long[]{0x7000920000000000L,0x00000000800001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_expr_list_in_topStatement1219 = new BitSet(new long[]{0x0000000000000000L,0x0000000002000000L});
    public static final BitSet FOLLOW_89_in_topStatement1221 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_expression_in_topStatement1249 = new BitSet(new long[]{0x0000000000000000L,0x0000000002000000L});
    public static final BitSet FOLLOW_89_in_topStatement1251 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_106_in_topStatement1258 = new BitSet(new long[]{0x0000020000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_topStatement1260 = new BitSet(new long[]{0x7000920000000000L,0x00000000800001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_expression_in_topStatement1262 = new BitSet(new long[]{0x0000000000000000L,0x0000080000000000L});
    public static final BitSet FOLLOW_107_in_topStatement1264 = new BitSet(new long[]{0x0000100000000000L,0x0000000000000020L,0x0000010000000000L});
    public static final BitSet FOLLOW_foreach_variable_in_topStatement1266 = new BitSet(new long[]{0x0000040000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_topStatement1268 = new BitSet(new long[]{0x7000B20000000000L,0x0090F7FF820001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_foreach_statement_in_topStatement1278 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_108_in_topStatement1305 = new BitSet(new long[]{0x0000020000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_topStatement1307 = new BitSet(new long[]{0x0000100000000000L});
    public static final BitSet FOLLOW_directive_in_topStatement1309 = new BitSet(new long[]{0x0000040000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_topStatement1311 = new BitSet(new long[]{0x7000B20000000000L,0x0090F7FF820001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_declare_statement_in_topStatement1313 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_89_in_topStatement1335 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_109_in_topStatement1370 = new BitSet(new long[]{0x0000200000000000L});
    public static final BitSet FOLLOW_LEFT_BRACKET_in_topStatement1372 = new BitSet(new long[]{0x7000BA0000000000L,0x0010F7FFF30001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_top_statement_in_topStatement1374 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_RIGHT_BRACKET_in_topStatement1376 = new BitSet(new long[]{0x0000000000000000L,0x1000000000000000L});
    public static final BitSet FOLLOW_catch_branch_in_topStatement1378 = new BitSet(new long[]{0x0000000000000002L,0x1000000000000000L});
    public static final BitSet FOLLOW_110_in_topStatement1403 = new BitSet(new long[]{0x7000920000000000L,0x00000000800001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_expression_in_topStatement1405 = new BitSet(new long[]{0x0000000000000000L,0x0000000002000000L});
    public static final BitSet FOLLOW_89_in_topStatement1407 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_111_in_topStatement1435 = new BitSet(new long[]{0x0000820000000000L});
    public static final BitSet FOLLOW_use_filename_in_topStatement1437 = new BitSet(new long[]{0x0000000000000000L,0x0000000002000000L});
    public static final BitSet FOLLOW_89_in_topStatement1439 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_variable_in_foreach_variable1482 = new BitSet(new long[]{0x0000000000000002L,0x0001000000000000L});
    public static final BitSet FOLLOW_112_in_foreach_variable1494 = new BitSet(new long[]{0x0000100000000000L,0x0000000000000020L,0x0000010000000000L});
    public static final BitSet FOLLOW_variable_in_foreach_variable1498 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_STRINGLITERAL_in_use_filename1527 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_use_filename1533 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_STRINGLITERAL_in_use_filename1536 = new BitSet(new long[]{0x0000040000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_use_filename1538 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_95_in_method_declaration1554 = new BitSet(new long[]{0x1000100000000000L});
    public static final BitSet FOLLOW_BIT_AND_in_method_declaration1556 = new BitSet(new long[]{0x0000100000000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_method_declaration1559 = new BitSet(new long[]{0x0000020000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_method_declaration1561 = new BitSet(new long[]{0x1000140000000000L,0x0002000000000020L,0x0000000FFE000000L});
    public static final BitSet FOLLOW_parameter_list_in_method_declaration1563 = new BitSet(new long[]{0x0000040000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_method_declaration1566 = new BitSet(new long[]{0x0000200000000000L,0x0000000002000000L});
    public static final BitSet FOLLOW_89_in_method_declaration1579 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_block_in_method_declaration1610 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_113_in_class_constant_declaration1654 = new BitSet(new long[]{0x0000100000000000L});
    public static final BitSet FOLLOW_directive_in_class_constant_declaration1656 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_fully_qualified_class_name_in_fully_qualified_class_name_list1684 = new BitSet(new long[]{0x0000000000000002L,0x0004000000000000L});
    public static final BitSet FOLLOW_114_in_fully_qualified_class_name_list1687 = new BitSet(new long[]{0x0000100000000000L});
    public static final BitSet FOLLOW_fully_qualified_class_name_in_fully_qualified_class_name_list1689 = new BitSet(new long[]{0x0000000000000002L,0x0004000000000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_fully_qualified_class_name1713 = new BitSet(new long[]{0x0000000000000002L,0x0008000000000000L});
    public static final BitSet FOLLOW_115_in_fully_qualified_class_name1716 = new BitSet(new long[]{0x0000100000000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_fully_qualified_class_name1719 = new BitSet(new long[]{0x0000000000000002L,0x0008000000000000L});
    public static final BitSet FOLLOW_115_in_fully_qualified_class_name1723 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_static_scalar_element_in_static_array_pair_list1740 = new BitSet(new long[]{0x0000000000000002L,0x0004000000000000L});
    public static final BitSet FOLLOW_114_in_static_array_pair_list1743 = new BitSet(new long[]{0x0000900000000000L,0x00000000000001C0L,0x0007E10000000000L});
    public static final BitSet FOLLOW_static_scalar_element_in_static_array_pair_list1745 = new BitSet(new long[]{0x0000000000000002L,0x0004000000000000L});
    public static final BitSet FOLLOW_scalar_in_static_scalar_element1772 = new BitSet(new long[]{0x0000000000000002L,0x0001000000000000L});
    public static final BitSet FOLLOW_112_in_static_scalar_element1775 = new BitSet(new long[]{0x0000900000000000L,0x00000000000001C0L,0x0007E10000000000L});
    public static final BitSet FOLLOW_scalar_in_static_scalar_element1778 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_static_var_element_in_static_var_list1795 = new BitSet(new long[]{0x0000000000000002L,0x0004000000000000L});
    public static final BitSet FOLLOW_114_in_static_var_list1798 = new BitSet(new long[]{0x1000000000000000L,0x0000000000000020L});
    public static final BitSet FOLLOW_static_var_element_in_static_var_list1800 = new BitSet(new long[]{0x0000000000000002L,0x0004000000000000L});
    public static final BitSet FOLLOW_pure_variable_in_static_var_element1826 = new BitSet(new long[]{0x0001000000000002L});
    public static final BitSet FOLLOW_EQ_in_static_var_element1829 = new BitSet(new long[]{0x0000900000000000L,0x00000000000001C0L,0x0007E10000000000L});
    public static final BitSet FOLLOW_scalar_in_static_var_element1832 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_116_in_if_stat1849 = new BitSet(new long[]{0x0000020000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_if_stat1851 = new BitSet(new long[]{0x7000920000000000L,0x00000000800001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_expression_in_if_stat1855 = new BitSet(new long[]{0x0000040000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_if_stat1857 = new BitSet(new long[]{0x7000B20000000000L,0x0090F7FF820001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_statement_in_if_stat1873 = new BitSet(new long[]{0x0000000000000002L,0x0060000000000000L});
    public static final BitSet FOLLOW_117_in_if_stat1889 = new BitSet(new long[]{0x0000020000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_if_stat1891 = new BitSet(new long[]{0x7000920000000000L,0x00000000800001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_expression_in_if_stat1895 = new BitSet(new long[]{0x0000040000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_if_stat1897 = new BitSet(new long[]{0x7000B20000000000L,0x0010F7FF820001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_statement_in_if_stat1901 = new BitSet(new long[]{0x0000000000000002L,0x0060000000000000L});
    public static final BitSet FOLLOW_118_in_if_stat1927 = new BitSet(new long[]{0x7000B20000000000L,0x0010F7FF820001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_statement_in_if_stat1931 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_119_in_if_stat1990 = new BitSet(new long[]{0x7000BA0000000000L,0x0170F7FFF30001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_inner_statement_list_in_if_stat1992 = new BitSet(new long[]{0x0000000000000000L,0x0160000000000000L});
    public static final BitSet FOLLOW_new_elseif_branch_in_if_stat1995 = new BitSet(new long[]{0x0000000000000000L,0x0160000000000000L});
    public static final BitSet FOLLOW_118_in_if_stat2012 = new BitSet(new long[]{0x0000000000000000L,0x0080000000000000L});
    public static final BitSet FOLLOW_119_in_if_stat2014 = new BitSet(new long[]{0x7000B20000000000L,0x0010F7FF820001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_statement_in_if_stat2018 = new BitSet(new long[]{0x0000000000000000L,0x0100000000000000L});
    public static final BitSet FOLLOW_120_in_if_stat2022 = new BitSet(new long[]{0x0000000000000000L,0x0000000002000000L});
    public static final BitSet FOLLOW_89_in_if_stat2024 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_117_in_new_elseif_branch2078 = new BitSet(new long[]{0x0000020000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_new_elseif_branch2080 = new BitSet(new long[]{0x7000920000000000L,0x00000000800001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_expression_in_new_elseif_branch2082 = new BitSet(new long[]{0x0000040000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_new_elseif_branch2084 = new BitSet(new long[]{0x0000000000000000L,0x0080000000000000L});
    public static final BitSet FOLLOW_119_in_new_elseif_branch2086 = new BitSet(new long[]{0x7000BA0000000002L,0x0010F7FFF30001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_inner_statement_list_in_new_elseif_branch2088 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LEFT_BRACKET_in_switch_case_list2121 = new BitSet(new long[]{0x0000000000000000L,0x0C00000002000000L});
    public static final BitSet FOLLOW_89_in_switch_case_list2123 = new BitSet(new long[]{0x0000000000000000L,0x0C00000002000000L});
    public static final BitSet FOLLOW_case_list_in_switch_case_list2126 = new BitSet(new long[]{0x0000400000000000L,0x0C00000002000000L});
    public static final BitSet FOLLOW_RIGHT_BRACKET_in_switch_case_list2129 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_119_in_switch_case_list2151 = new BitSet(new long[]{0x0000000000000000L,0x0C00000002000000L});
    public static final BitSet FOLLOW_89_in_switch_case_list2153 = new BitSet(new long[]{0x0000000000000000L,0x0C00000002000000L});
    public static final BitSet FOLLOW_case_list_in_switch_case_list2156 = new BitSet(new long[]{0x0000000000000000L,0x0E00000002000000L});
    public static final BitSet FOLLOW_121_in_switch_case_list2159 = new BitSet(new long[]{0x0000000000000000L,0x0000000002000000L});
    public static final BitSet FOLLOW_89_in_switch_case_list2161 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_122_in_case_list2184 = new BitSet(new long[]{0x7000920000000000L,0x00000000800001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_expression_in_case_list2186 = new BitSet(new long[]{0x0000000000000000L,0x0080000002000000L});
    public static final BitSet FOLLOW_119_in_case_list2189 = new BitSet(new long[]{0x7000BA0000000002L,0x0010F7FFF30001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_89_in_case_list2193 = new BitSet(new long[]{0x7000BA0000000002L,0x0010F7FFF30001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_inner_statement_list_in_case_list2196 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_123_in_case_list2217 = new BitSet(new long[]{0x0000000000000000L,0x0080000002000000L});
    public static final BitSet FOLLOW_119_in_case_list2220 = new BitSet(new long[]{0x7000BA0000000002L,0x0010F7FFF30001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_89_in_case_list2224 = new BitSet(new long[]{0x7000BA0000000002L,0x0010F7FFF30001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_inner_statement_list_in_case_list2227 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_124_in_catch_branch2258 = new BitSet(new long[]{0x0000020000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_catch_branch2260 = new BitSet(new long[]{0x0000100000000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_catch_branch2262 = new BitSet(new long[]{0x0000100000000000L,0x0000000000000020L,0x0000010000000000L});
    public static final BitSet FOLLOW_variable_in_catch_branch2264 = new BitSet(new long[]{0x0000040000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_catch_branch2266 = new BitSet(new long[]{0x0000200000000000L});
    public static final BitSet FOLLOW_block_in_catch_branch2274 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_119_in_for_statement2303 = new BitSet(new long[]{0x7000BA0000000000L,0x2010F7FFF30001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_inner_statement_list_in_for_statement2305 = new BitSet(new long[]{0x0000000000000000L,0x2000000000000000L});
    public static final BitSet FOLLOW_125_in_for_statement2308 = new BitSet(new long[]{0x0000000000000000L,0x0000000002000000L});
    public static final BitSet FOLLOW_89_in_for_statement2310 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_statement_in_while_statement2330 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_119_in_while_statement2357 = new BitSet(new long[]{0x7000BA0000000000L,0x4010F7FFF30001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_inner_statement_list_in_while_statement2359 = new BitSet(new long[]{0x0000000000000000L,0x4000000000000000L});
    public static final BitSet FOLLOW_126_in_while_statement2362 = new BitSet(new long[]{0x0000000000000000L,0x0000000002000000L});
    public static final BitSet FOLLOW_89_in_while_statement2364 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_statement_in_foreach_statement2385 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_119_in_foreach_statement2412 = new BitSet(new long[]{0x7000BA0000000000L,0x8010F7FFF30001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_inner_statement_list_in_foreach_statement2414 = new BitSet(new long[]{0x0000000000000000L,0x8000000000000000L});
    public static final BitSet FOLLOW_127_in_foreach_statement2417 = new BitSet(new long[]{0x0000000000000000L,0x0000000002000000L});
    public static final BitSet FOLLOW_89_in_foreach_statement2419 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_statement_in_declare_statement2441 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_119_in_declare_statement2468 = new BitSet(new long[]{0x7000BA0000000000L,0x0010F7FFF30001E6L,0x0007EF7B00000001L});
    public static final BitSet FOLLOW_inner_statement_list_in_declare_statement2470 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000000001L});
    public static final BitSet FOLLOW_128_in_declare_statement2473 = new BitSet(new long[]{0x0000000000000000L,0x0000000002000000L});
    public static final BitSet FOLLOW_89_in_declare_statement2475 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_parameter_in_parameter_list2497 = new BitSet(new long[]{0x0000000000000002L,0x0004000000000000L});
    public static final BitSet FOLLOW_114_in_parameter_list2500 = new BitSet(new long[]{0x1000100000000000L,0x0002000000000020L,0x0000000FFE000000L});
    public static final BitSet FOLLOW_parameter_in_parameter_list2502 = new BitSet(new long[]{0x0000000000000002L,0x0004000000000000L});
    public static final BitSet FOLLOW_parameter_type_in_parameter2533 = new BitSet(new long[]{0x1000000000000000L,0x0002000000000020L});
    public static final BitSet FOLLOW_113_in_parameter2536 = new BitSet(new long[]{0x1000000000000000L,0x0000000000000020L});
    public static final BitSet FOLLOW_pure_variable_in_parameter2539 = new BitSet(new long[]{0x0001000000000002L});
    public static final BitSet FOLLOW_EQ_in_parameter2555 = new BitSet(new long[]{0x0000900000000000L,0x00000000000001C0L,0x0007E10000000000L});
    public static final BitSet FOLLOW_scalar_in_parameter2557 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_fully_qualified_class_name_in_parameter_type2597 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_cast_option_in_parameter_type2603 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_variable_in_variable_list2618 = new BitSet(new long[]{0x0000000000000002L,0x0004000000000000L});
    public static final BitSet FOLLOW_114_in_variable_list2621 = new BitSet(new long[]{0x0000100000000000L,0x0000000000000020L,0x0000010000000000L});
    public static final BitSet FOLLOW_variable_in_variable_list2623 = new BitSet(new long[]{0x0000000000000002L,0x0004000000000000L});
    public static final BitSet FOLLOW_129_in_variable_modifiers2649 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_modifier_in_variable_modifiers2655 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_modifier2669 = new BitSet(new long[]{0x0000000000000002L,0x0000010060000000L,0x000000000000001CL});
    public static final BitSet FOLLOW_IDENTIFIER_in_directive2720 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_EQ_in_directive2722 = new BitSet(new long[]{0x7000920000000000L,0x00000000800001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_expression_in_directive2724 = new BitSet(new long[]{0x0000000000000002L,0x0004000000000000L});
    public static final BitSet FOLLOW_114_in_directive2727 = new BitSet(new long[]{0x0000100000000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_directive2729 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_EQ_in_directive2731 = new BitSet(new long[]{0x7000920000000000L,0x00000000800001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_expression_in_directive2733 = new BitSet(new long[]{0x0000000000000002L,0x0004000000000000L});
    public static final BitSet FOLLOW_expression_in_expr_list2761 = new BitSet(new long[]{0x0000000000000002L,0x0004000000000000L});
    public static final BitSet FOLLOW_114_in_expr_list2764 = new BitSet(new long[]{0x7000920000000000L,0x00000000800001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_expression_in_expr_list2766 = new BitSet(new long[]{0x0000000000000002L,0x0004000000000000L});
    public static final BitSet FOLLOW_logical_text_or_expr_in_expression2801 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_logical_text_xor_expr_in_logical_text_or_expr2844 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000000020L});
    public static final BitSet FOLLOW_133_in_logical_text_or_expr2847 = new BitSet(new long[]{0x7000920000000000L,0x00000000800001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_logical_text_xor_expr_in_logical_text_or_expr2852 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000000020L});
    public static final BitSet FOLLOW_logical_text_and_expr_in_logical_text_xor_expr2883 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000000040L});
    public static final BitSet FOLLOW_134_in_logical_text_xor_expr2886 = new BitSet(new long[]{0x7000920000000000L,0x00000000800001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_logical_text_and_expr_in_logical_text_xor_expr2891 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000000040L});
    public static final BitSet FOLLOW_assignment_expr_in_logical_text_and_expr2922 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000000080L});
    public static final BitSet FOLLOW_135_in_logical_text_and_expr2925 = new BitSet(new long[]{0x7000920000000000L,0x00000000800001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_assignment_expr_in_logical_text_and_expr2930 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000000080L});
    public static final BitSet FOLLOW_conditional_expr_in_assignment_expr2961 = new BitSet(new long[]{0x0FFF000000000002L});
    public static final BitSet FOLLOW_assignment_operator_in_assignment_expr2964 = new BitSet(new long[]{0x7000920000000000L,0x00000000800001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_conditional_expr_in_assignment_expr2969 = new BitSet(new long[]{0x0FFF000000000002L});
    public static final BitSet FOLLOW_set_in_assignment_operator0 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_logical_or_expr_in_conditional_expr3107 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000000100L});
    public static final BitSet FOLLOW_136_in_conditional_expr3126 = new BitSet(new long[]{0x7000920000000000L,0x00800000800001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_expression_in_conditional_expr3128 = new BitSet(new long[]{0x0000000000000000L,0x0080000000000000L});
    public static final BitSet FOLLOW_119_in_conditional_expr3131 = new BitSet(new long[]{0x7000920000000000L,0x00000000800001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_logical_or_expr_in_conditional_expr3135 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_logical_and_expr_in_logical_or_expr3185 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000000200L});
    public static final BitSet FOLLOW_137_in_logical_or_expr3188 = new BitSet(new long[]{0x7000920000000000L,0x00000000800001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_logical_and_expr_in_logical_or_expr3193 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000000200L});
    public static final BitSet FOLLOW_bitwise_or_expr_in_logical_and_expr3224 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000000400L});
    public static final BitSet FOLLOW_138_in_logical_and_expr3227 = new BitSet(new long[]{0x7000920000000000L,0x00000000800001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_bitwise_or_expr_in_logical_and_expr3232 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000000400L});
    public static final BitSet FOLLOW_bitwise_xor_expr_in_bitwise_or_expr3263 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000000800L});
    public static final BitSet FOLLOW_139_in_bitwise_or_expr3266 = new BitSet(new long[]{0x7000920000000000L,0x00000000800001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_bitwise_xor_expr_in_bitwise_or_expr3271 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000000800L});
    public static final BitSet FOLLOW_bitwise_and_expr_in_bitwise_xor_expr3302 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000001000L});
    public static final BitSet FOLLOW_140_in_bitwise_xor_expr3305 = new BitSet(new long[]{0x7000920000000000L,0x00000000800001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_bitwise_and_expr_in_bitwise_xor_expr3310 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000001000L});
    public static final BitSet FOLLOW_concat_expr_in_bitwise_and_expr3341 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000002000L});
    public static final BitSet FOLLOW_141_in_bitwise_and_expr3344 = new BitSet(new long[]{0x7000920000000000L,0x00000000800001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_concat_expr_in_bitwise_and_expr3349 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000002000L});
    public static final BitSet FOLLOW_equality_expr_in_concat_expr3380 = new BitSet(new long[]{0x1000000000000002L});
    public static final BitSet FOLLOW_BIT_AND_in_concat_expr3383 = new BitSet(new long[]{0x7000920000000000L,0x00000000800001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_equality_expr_in_concat_expr3388 = new BitSet(new long[]{0x1000000000000002L});
    public static final BitSet FOLLOW_relational_expr_in_equality_expr3419 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x000000000003C000L});
    public static final BitSet FOLLOW_set_in_equality_expr3422 = new BitSet(new long[]{0x7000920000000000L,0x00000000800001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_relational_expr_in_equality_expr3441 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x000000000003C000L});
    public static final BitSet FOLLOW_shift_expr_in_relational_expr3472 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x00000000003C0000L});
    public static final BitSet FOLLOW_set_in_relational_expr3475 = new BitSet(new long[]{0x7000920000000000L,0x00000000800001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_shift_expr_in_relational_expr3494 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x00000000003C0000L});
    public static final BitSet FOLLOW_additive_expr_in_shift_expr3525 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000C00000L});
    public static final BitSet FOLLOW_set_in_shift_expr3528 = new BitSet(new long[]{0x7000920000000000L,0x00000000800001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_additive_expr_in_shift_expr3539 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000C00000L});
    public static final BitSet FOLLOW_multiplicative_expr_in_additive_expr3570 = new BitSet(new long[]{0x6000000000000002L});
    public static final BitSet FOLLOW_set_in_additive_expr3573 = new BitSet(new long[]{0x7000920000000000L,0x00000000800001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_multiplicative_expr_in_additive_expr3584 = new BitSet(new long[]{0x6000000000000002L});
    public static final BitSet FOLLOW_cast_expr_in_multiplicative_expr3615 = new BitSet(new long[]{0x8000000000000002L,0x0000000000000001L,0x0000000001000000L});
    public static final BitSet FOLLOW_set_in_multiplicative_expr3618 = new BitSet(new long[]{0x7000920000000000L,0x00000000800001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_cast_expr_in_multiplicative_expr3633 = new BitSet(new long[]{0x8000000000000002L,0x0000000000000001L,0x0000000001000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_cast_expr3663 = new BitSet(new long[]{0x0000100000000000L,0x0000000000000000L,0x0000000FFE000000L});
    public static final BitSet FOLLOW_cast_option_in_cast_expr3666 = new BitSet(new long[]{0x0000040000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_cast_expr3669 = new BitSet(new long[]{0x7000920000000000L,0x00000000800001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_unary_expr_in_cast_expr3674 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_cast_option0 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_unary_expr3779 = new BitSet(new long[]{0x7000920000000000L,0x00000000800001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_prefix_inc_dec_expr_in_unary_expr3802 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_prefix_inc_dec_expr3831 = new BitSet(new long[]{0x7000920000000000L,0x00000000800001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_post_inc_dec_expr_in_prefix_inc_dec_expr3842 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_instance_expr_in_post_inc_dec_expr3871 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000006000000000L});
    public static final BitSet FOLLOW_set_in_post_inc_dec_expr3874 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000006000000000L});
    public static final BitSet FOLLOW_atom_expr_in_instance_expr3910 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000008000000000L});
    public static final BitSet FOLLOW_167_in_instance_expr3913 = new BitSet(new long[]{0x0000100000000000L,0x0000000000000020L,0x0000010000000000L});
    public static final BitSet FOLLOW_class_name_reference_in_instance_expr3916 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_168_in_atom_expr3948 = new BitSet(new long[]{0x0000100000000000L,0x0000000000000020L,0x0000010000000000L});
    public static final BitSet FOLLOW_variable_in_atom_expr3951 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_168_in_atom_expr3958 = new BitSet(new long[]{0x0000900000000000L,0x00000000000001C0L,0x0007E10000000000L});
    public static final BitSet FOLLOW_scalar_in_atom_expr3961 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_atom_expr3968 = new BitSet(new long[]{0x7000920000000000L,0x00000000800001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_expression_in_atom_expr3970 = new BitSet(new long[]{0x0000040000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_atom_expr3972 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_169_in_atom_expr3979 = new BitSet(new long[]{0x0000020000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_atom_expr3981 = new BitSet(new long[]{0x0000140000000000L,0x0004000000000020L,0x0000030000000000L});
    public static final BitSet FOLLOW_assignment_list_in_atom_expr3983 = new BitSet(new long[]{0x0000040000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_atom_expr3985 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_163_in_atom_expr4005 = new BitSet(new long[]{0x0000020000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_atom_expr4007 = new BitSet(new long[]{0x7000960000000000L,0x00000000800001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_array_pair_list_in_atom_expr4009 = new BitSet(new long[]{0x0000040000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_atom_expr4012 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_170_in_atom_expr4041 = new BitSet(new long[]{0x0000100000000000L,0x0000000000000020L,0x0000010000000000L});
    public static final BitSet FOLLOW_class_name_reference_in_atom_expr4043 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_161_in_atom_expr4060 = new BitSet(new long[]{0x0000100000000000L,0x0000000000000020L,0x0000010000000000L});
    public static final BitSet FOLLOW_variable_in_atom_expr4062 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_171_in_atom_expr4084 = new BitSet(new long[]{0x0000020000000002L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_atom_expr4087 = new BitSet(new long[]{0x7000960000000000L,0x00000000800001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_expression_in_atom_expr4089 = new BitSet(new long[]{0x0000040000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_atom_expr4092 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_160_in_atom_expr4112 = new BitSet(new long[]{0x0000020000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_atom_expr4114 = new BitSet(new long[]{0x0000100000000000L,0x0000000000000020L,0x0000010000000000L});
    public static final BitSet FOLLOW_variable_list_in_atom_expr4116 = new BitSet(new long[]{0x0000040000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_atom_expr4118 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_lambda_function_declaration_in_atom_expr4135 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_BACKTRICKLITERAL_in_atom_expr4142 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_95_in_lambda_function_declaration4157 = new BitSet(new long[]{0x1000020000000000L});
    public static final BitSet FOLLOW_BIT_AND_in_lambda_function_declaration4159 = new BitSet(new long[]{0x0000020000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_lambda_function_declaration4162 = new BitSet(new long[]{0x1000140000000000L,0x0002000000000020L,0x0000000FFE000000L});
    public static final BitSet FOLLOW_parameter_list_in_lambda_function_declaration4164 = new BitSet(new long[]{0x0000040000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_lambda_function_declaration4167 = new BitSet(new long[]{0x0000200000000000L,0x0000800000000000L});
    public static final BitSet FOLLOW_111_in_lambda_function_declaration4170 = new BitSet(new long[]{0x0000020000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_lambda_function_declaration4172 = new BitSet(new long[]{0x7000960000000000L,0x00000000800001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_expr_list_in_lambda_function_declaration4174 = new BitSet(new long[]{0x0000040000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_lambda_function_declaration4177 = new BitSet(new long[]{0x0000200000000000L});
    public static final BitSet FOLLOW_block_in_lambda_function_declaration4185 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_variable_in_class_name_reference4232 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_fully_qualified_class_name_in_class_name_reference4238 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_assignment_element_in_assignment_list4255 = new BitSet(new long[]{0x0000000000000002L,0x0004000000000000L});
    public static final BitSet FOLLOW_114_in_assignment_list4259 = new BitSet(new long[]{0x0000100000000002L,0x0004000000000020L,0x0000030000000000L});
    public static final BitSet FOLLOW_assignment_element_in_assignment_list4261 = new BitSet(new long[]{0x0000000000000002L,0x0004000000000000L});
    public static final BitSet FOLLOW_variable_in_assignment_element4278 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_169_in_assignment_element4284 = new BitSet(new long[]{0x0000020000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_assignment_element4286 = new BitSet(new long[]{0x0000140000000000L,0x0004000000000020L,0x0000030000000000L});
    public static final BitSet FOLLOW_assignment_list_in_assignment_element4288 = new BitSet(new long[]{0x0000040000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_assignment_element4290 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_array_pair_element_in_array_pair_list4327 = new BitSet(new long[]{0x0000000000000002L,0x0004000000000000L});
    public static final BitSet FOLLOW_114_in_array_pair_list4330 = new BitSet(new long[]{0x7000920000000000L,0x00000000800001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_array_pair_element_in_array_pair_list4334 = new BitSet(new long[]{0x0000000000000002L,0x0004000000000000L});
    public static final BitSet FOLLOW_114_in_array_pair_list4338 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_expression_in_array_pair_element4383 = new BitSet(new long[]{0x0000000000000002L,0x0001000000000000L});
    public static final BitSet FOLLOW_112_in_array_pair_element4386 = new BitSet(new long[]{0x7000920000000000L,0x00000000800001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_expression_in_array_pair_element4391 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_base_variable_with_function_calls_in_variable4415 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000100000000000L});
    public static final BitSet FOLLOW_172_in_variable4427 = new BitSet(new long[]{0x0000300000000000L,0x0000000000000020L});
    public static final BitSet FOLLOW_object_property_in_variable4429 = new BitSet(new long[]{0x0000020000000002L,0x0000000000000000L,0x0000100000000000L});
    public static final BitSet FOLLOW_ctor_arguments_in_variable4431 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000100000000000L});
    public static final BitSet FOLLOW_fully_qualified_class_name_in_base_variable_with_function_calls4478 = new BitSet(new long[]{0x0000100000000000L,0x0000000000000020L});
    public static final BitSet FOLLOW_reference_variable_in_base_variable_with_function_calls4481 = new BitSet(new long[]{0x0000020000000002L});
    public static final BitSet FOLLOW_ctor_arguments_in_base_variable_with_function_calls4483 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_fully_qualified_class_name_in_base_variable_with_function_calls4517 = new BitSet(new long[]{0x0000020000000000L});
    public static final BitSet FOLLOW_ctor_arguments_in_base_variable_with_function_calls4519 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_reference_variable_in_object_property4562 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_reference_variable_without_dollar_in_object_property4568 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_compound_variable_in_reference_variable4594 = new BitSet(new long[]{0x0000200000000002L,0x0000000000000008L});
    public static final BitSet FOLLOW_LEFT_OPEN_RECT_in_reference_variable4615 = new BitSet(new long[]{0x7000920000000000L,0x00000000800001F6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_expression_in_reference_variable4619 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000010L});
    public static final BitSet FOLLOW_RIGHT_OPEN_RECT_in_reference_variable4622 = new BitSet(new long[]{0x0000200000000002L,0x0000000000000008L});
    public static final BitSet FOLLOW_LEFT_BRACKET_in_reference_variable4652 = new BitSet(new long[]{0x7000920000000000L,0x00000000800001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_expression_in_reference_variable4656 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_RIGHT_BRACKET_in_reference_variable4658 = new BitSet(new long[]{0x0000200000000002L,0x0000000000000008L});
    public static final BitSet FOLLOW_DOLLAR_T_in_compound_variable4699 = new BitSet(new long[]{0x0000100000000000L,0x0000000000000020L});
    public static final BitSet FOLLOW_IDENTIFIER_in_compound_variable4702 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_DOLLAR_T_in_compound_variable4709 = new BitSet(new long[]{0x0000200000000000L,0x0000000000000020L});
    public static final BitSet FOLLOW_LEFT_BRACKET_in_compound_variable4712 = new BitSet(new long[]{0x7000920000000000L,0x00000000800001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_expression_in_compound_variable4715 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_RIGHT_BRACKET_in_compound_variable4717 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_compound_variable_without_dollar_in_reference_variable_without_dollar4744 = new BitSet(new long[]{0x0000200000000002L,0x0000000000000008L});
    public static final BitSet FOLLOW_LEFT_OPEN_RECT_in_reference_variable_without_dollar4758 = new BitSet(new long[]{0x7000920000000000L,0x00000000800001F6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_expression_in_reference_variable_without_dollar4760 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000010L});
    public static final BitSet FOLLOW_RIGHT_OPEN_RECT_in_reference_variable_without_dollar4763 = new BitSet(new long[]{0x0000200000000002L,0x0000000000000008L});
    public static final BitSet FOLLOW_LEFT_BRACKET_in_reference_variable_without_dollar4786 = new BitSet(new long[]{0x7000920000000000L,0x00000000800001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_expression_in_reference_variable_without_dollar4788 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_RIGHT_BRACKET_in_reference_variable_without_dollar4790 = new BitSet(new long[]{0x0000200000000002L,0x0000000000000008L});
    public static final BitSet FOLLOW_IDENTIFIER_in_compound_variable_without_dollar4823 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LEFT_BRACKET_in_compound_variable_without_dollar4829 = new BitSet(new long[]{0x7000920000000000L,0x00000000800001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_expression_in_compound_variable_without_dollar4831 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_RIGHT_BRACKET_in_compound_variable_without_dollar4833 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_ctor_arguments4859 = new BitSet(new long[]{0x7000960000000000L,0x00000000800001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_expr_list_in_ctor_arguments4861 = new BitSet(new long[]{0x0000040000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_ctor_arguments4864 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_BIT_AND_in_pure_variable4900 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000020L});
    public static final BitSet FOLLOW_DOLLAR_T_in_pure_variable4903 = new BitSet(new long[]{0x0000100000000000L,0x0000000000000020L});
    public static final BitSet FOLLOW_IDENTIFIER_in_pure_variable4906 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_constant_in_scalar4947 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_INTLITERAL_in_constant4982 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_FLOATLITERAL_in_constant4991 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_STRINGLITERAL_in_constant4999 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_DOUBLELITERRAL_in_constant5008 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_common_scalar_in_constant5015 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_fully_qualified_class_name_in_constant5023 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_common_scalar0 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_117_in_synpred1_CompilerAst1889 = new BitSet(new long[]{0x0000020000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_synpred1_CompilerAst1891 = new BitSet(new long[]{0x7000920000000000L,0x00000000800001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_expression_in_synpred1_CompilerAst1895 = new BitSet(new long[]{0x0000040000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_synpred1_CompilerAst1897 = new BitSet(new long[]{0x7000B20000000000L,0x0010F7FF820001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_statement_in_synpred1_CompilerAst1901 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_118_in_synpred2_CompilerAst1927 = new BitSet(new long[]{0x7000B20000000000L,0x0010F7FF820001E6L,0x0007EF7B00000000L});
    public static final BitSet FOLLOW_statement_in_synpred2_CompilerAst1931 = new BitSet(new long[]{0x0000000000000002L});

}