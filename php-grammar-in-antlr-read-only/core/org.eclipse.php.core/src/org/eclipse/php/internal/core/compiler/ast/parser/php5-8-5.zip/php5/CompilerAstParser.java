// $ANTLR 3.1.3 Mar 17, 2009 19:23:44 /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g 2009-08-05 10:24:27

  package org.eclipse.php.internal.core.compiler.ast.parser.php5;
  
  import org.antlr.runtime.*;
  import org.antlr.runtime.tree.*;
  import org.antlr.runtime.BitSet;
  
  import java.util.*;
	import org.eclipse.dltk.ast.*;
	import org.eclipse.dltk.ast.declarations.*;
	import org.eclipse.dltk.ast.expressions.*;
	import org.eclipse.dltk.ast.references.*;
	import org.eclipse.dltk.ast.statements.*;
	import org.eclipse.php.internal.core.compiler.ast.nodes.*;
	import org.eclipse.php.internal.core.compiler.ast.parser.*;
	import org.eclipse.php.internal.core.ast.scanner.php5.*;


import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;

import org.antlr.runtime.tree.*;

public class CompilerAstParser extends AbstractASTParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "ModuleDeclaration", "ClassDeclaration", "PROG", "CLASS_BODY", "FIELD_DECL", "METHOD_DECL", "TYPE", "PARAMETER", "BLOCK", "VAR_DECL", "STATEMENT", "CONDITION", "LIST", "INDEX", "MEMBERACCESS", "CALL", "ELIST", "EXPR", "ASSIGN", "LIST_DECL", "SCALAR_ELEMENT", "SCALAR_VAR", "CAST", "LABEL", "ITERATE", "USE_DECL", "ARGU", "CALLED_OBJ", "PREFIX", "POSTFIX", "NAMESPACE", "EMPTYSTATEMENT", "SCALAR", "ARRAY_DECL", "PREFIX_EXPR", "POSTFIX_EXPR", "CAST_EXPR", "VAR", "HASH_INDEX", "SOC_T", "SOC_PHP_T", "EOC_T", "LEFT_PARETHESIS", "RIGHT_PARETHESIS", "SEMI_COLON", "CLASS_T", "IDENTIFIER", "EXTENDS_T", "IMPLEMENTS_T", "LEFT_BRACKET", "RIGHT_BRACKET", "INTERFACE_T", "FUNCTION_T", "REF_T", "CONST_T", "WHILE_T", "DO_T", "FOR_T", "SWITCH_T", "BREAK_T", "CONTINUE_T", "RETURN_T", "GLOBAL_T", "STATIC_T", "ECHO_T", "FOREACH_T", "AS_T", "ARROW_T", "DECLARE_T", "TRY_T", "THROW_T", "USE_T", "INCLUDE_T", "INCLUDE_ONCE_T", "STRINGLITERAL", "DOMAIN_T", "COMMA_T", "EQUAL_T", "IF_T", "ELSEIF_T", "ELSE_T", "COLON_T", "ENDIF_T", "ENDSWITCH_T", "CASE_T", "DEFAULT_T", "CATCH_T", "ENDFOR_T", "ENDWHILE_T", "ENDFOREACH_T", "ENDDECLARE_T", "OR_T", "XOR_T", "AND_T", "PLUS_EQ", "MINUS_EQ", "MUL_EQ", "DIV_EQ", "DOT_EQ", "PERCENT_EQ", "BIT_AND_EQ", "BIT_OR_EQ", "POWER_EQ", "LMOVE_EQ", "RMOVE_EQ", "QUESTION_T", "LOGICAL_OR_T", "LOGICAL_AND_T", "BIT_OR_T", "POWER_T", "DOT_T", "EQUAL_EQUAL_T", "NOT_EQUAL_T", "EQUAL_EQUAL_EQUAL_T", "NOT_EQUAL_EQUAL_T", "LT_T", "MT_T", "LE_T", "ME_T", "LSHIFT_T", "RSHIFT_T", "PLUS_T", "MINUS_T", "MUL_T", "DIV_T", "PERCENT_T", "UNSET_T", "CLONE_T", "TILDA_T", "EXC_NOT_T", "PLUS_PLUS_T", "MINUS_MINUS_T", "INSTANCEOF_T", "AT_T", "LIST_T", "NEW_T", "EXIT_T", "BACKTRICKLITERAL", "SINGLE_ARROW_T", "LEFT_OPEN_RECT", "RIGHT_OPEN_RECT", "DOLLAR_T", "INTLITERAL", "FLOATLITERAL", "DOUBLELITERRAL", "IntegerNumber", "LongSuffix", "HexPrefix", "HexDigit", "STATIC", "NonIntegerNumber", "FloatSuffix", "DoubleSuffix", "Exponent", "EscapeSequence", "IdentifierStart", "IdentifierPart", "WS", "COMMENT", "LINE_COMMENT", "'__halt_compiler'", "'abstract'", "'final'", "'var'", "'public'", "'protected'", "'private'", "'bool'", "'boolean'", "'int'", "'float'", "'double'", "'real'", "'string'", "'object'", "'array'", "'__CLASS__'", "'__DIR__'", "'__FILE__'", "'__FUNCTION__'", "'__METHOD__'", "'__NAMESPACE__'"
    };
    public static final int CAST=26;
    public static final int PREFIX=32;
    public static final int RIGHT_OPEN_RECT=144;
    public static final int XOR_T=96;
    public static final int TRY_T=73;
    public static final int POSTFIX=33;
    public static final int LOGICAL_OR_T=110;
    public static final int ENDFOR_T=91;
    public static final int PERCENT_EQ=103;
    public static final int HASH_INDEX=42;
    public static final int INCLUDE_T=76;
    public static final int AS_T=70;
    public static final int VAR_DECL=13;
    public static final int CONDITION=15;
    public static final int DIV_T=128;
    public static final int COMMA_T=80;
    public static final int DOMAIN_T=79;
    public static final int T__167=167;
    public static final int EOF=-1;
    public static final int T__168=168;
    public static final int EQUAL_EQUAL_T=115;
    public static final int T__165=165;
    public static final int T__166=166;
    public static final int STATIC_T=67;
    public static final int DOT_T=114;
    public static final int STATEMENT=14;
    public static final int T__164=164;
    public static final int ENDIF_T=86;
    public static final int TYPE=10;
    public static final int POSTFIX_EXPR=39;
    public static final int CALLED_OBJ=31;
    public static final int EOC_T=45;
    public static final int NOT_EQUAL_EQUAL_T=118;
    public static final int DIV_EQ=101;
    public static final int CAST_EXPR=40;
    public static final int ELIST=20;
    public static final int GLOBAL_T=66;
    public static final int IF_T=82;
    public static final int AT_T=137;
    public static final int FloatSuffix=155;
    public static final int NonIntegerNumber=154;
    public static final int MT_T=120;
    public static final int PARAMETER=11;
    public static final int AND_T=97;
    public static final int ELSE_T=84;
    public static final int SCALAR=36;
    public static final int RIGHT_BRACKET=54;
    public static final int SINGLE_ARROW_T=142;
    public static final int ARGU=30;
    public static final int VAR=41;
    public static final int FOR_T=61;
    public static final int RSHIFT_T=124;
    public static final int COMMENT=162;
    public static final int HexPrefix=151;
    public static final int MINUS_MINUS_T=135;
    public static final int ARROW_T=71;
    public static final int RMOVE_EQ=108;
    public static final int LINE_COMMENT=163;
    public static final int EQUAL_EQUAL_EQUAL_T=117;
    public static final int STATIC=153;
    public static final int CLONE_T=131;
    public static final int WHILE_T=59;
    public static final int ARRAY_DECL=37;
    public static final int MUL_EQ=100;
    public static final int IdentifierStart=159;
    public static final int DECLARE_T=72;
    public static final int SEMI_COLON=48;
    public static final int OR_T=95;
    public static final int INTERFACE_T=55;
    public static final int INTLITERAL=146;
    public static final int THROW_T=74;
    public static final int PLUS_EQ=98;
    public static final int LIST=16;
    public static final int REF_T=57;
    public static final int ENDDECLARE_T=94;
    public static final int PLUS_T=125;
    public static final int NAMESPACE=34;
    public static final int MINUS_EQ=99;
    public static final int LongSuffix=150;
    public static final int ENDFOREACH_T=93;
    public static final int EMPTYSTATEMENT=35;
    public static final int WS=161;
    public static final int DO_T=60;
    public static final int EQUAL_T=81;
    public static final int COLON_T=85;
    public static final int UNSET_T=130;
    public static final int NEW_T=139;
    public static final int USE_T=75;
    public static final int SOC_PHP_T=44;
    public static final int MINUS_T=126;
    public static final int PLUS_PLUS_T=134;
    public static final int MEMBERACCESS=18;
    public static final int CALL=19;
    public static final int SCALAR_ELEMENT=24;
    public static final int POWER_EQ=106;
    public static final int EscapeSequence=158;
    public static final int BIT_AND_EQ=104;
    public static final int INCLUDE_ONCE_T=77;
    public static final int IntegerNumber=149;
    public static final int CLASS_T=49;
    public static final int ECHO_T=68;
    public static final int DOLLAR_T=145;
    public static final int LEFT_BRACKET=53;
    public static final int DOUBLELITERRAL=148;
    public static final int Exponent=157;
    public static final int CATCH_T=90;
    public static final int METHOD_DECL=9;
    public static final int SOC_T=43;
    public static final int PERCENT_T=129;
    public static final int LE_T=121;
    public static final int IMPLEMENTS_T=52;
    public static final int HexDigit=152;
    public static final int DEFAULT_T=89;
    public static final int INDEX=17;
    public static final int PROG=6;
    public static final int EXPR=21;
    public static final int NOT_EQUAL_T=116;
    public static final int USE_DECL=29;
    public static final int POWER_T=113;
    public static final int IDENTIFIER=50;
    public static final int LEFT_OPEN_RECT=143;
    public static final int LMOVE_EQ=107;
    public static final int SCALAR_VAR=25;
    public static final int IdentifierPart=160;
    public static final int TILDA_T=132;
    public static final int CONST_T=58;
    public static final int FUNCTION_T=56;
    public static final int T__184=184;
    public static final int EXIT_T=140;
    public static final int T__183=183;
    public static final int SWITCH_T=62;
    public static final int T__185=185;
    public static final int MUL_T=127;
    public static final int LOGICAL_AND_T=111;
    public static final int LSHIFT_T=123;
    public static final int QUESTION_T=109;
    public static final int BIT_OR_EQ=105;
    public static final int BIT_OR_T=112;
    public static final int INSTANCEOF_T=136;
    public static final int T__180=180;
    public static final int ELSEIF_T=83;
    public static final int FOREACH_T=69;
    public static final int T__182=182;
    public static final int T__181=181;
    public static final int FIELD_DECL=8;
    public static final int PREFIX_EXPR=38;
    public static final int LT_T=119;
    public static final int LIST_T=138;
    public static final int CLASS_BODY=7;
    public static final int ModuleDeclaration=4;
    public static final int LIST_DECL=23;
    public static final int BACKTRICKLITERAL=141;
    public static final int T__175=175;
    public static final int T__174=174;
    public static final int T__173=173;
    public static final int ITERATE=28;
    public static final int T__172=172;
    public static final int T__179=179;
    public static final int LEFT_PARETHESIS=46;
    public static final int RETURN_T=65;
    public static final int T__178=178;
    public static final int T__177=177;
    public static final int DoubleSuffix=156;
    public static final int ME_T=122;
    public static final int T__176=176;
    public static final int LABEL=27;
    public static final int ENDWHILE_T=92;
    public static final int STRINGLITERAL=78;
    public static final int T__171=171;
    public static final int BLOCK=12;
    public static final int T__170=170;
    public static final int ASSIGN=22;
    public static final int RIGHT_PARETHESIS=47;
    public static final int EXC_NOT_T=133;
    public static final int CASE_T=88;
    public static final int BREAK_T=63;
    public static final int EXTENDS_T=51;
    public static final int CONTINUE_T=64;
    public static final int DOT_EQ=102;
    public static final int FLOATLITERAL=147;
    public static final int ClassDeclaration=5;
    public static final int T__169=169;
    public static final int ENDSWITCH_T=87;

    // delegates
    // delegators


        public CompilerAstParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public CompilerAstParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        
    protected TreeAdaptor adaptor = new CommonTreeAdaptor();

    public void setTreeAdaptor(TreeAdaptor adaptor) {
        this.adaptor = adaptor;
    }
    public TreeAdaptor getTreeAdaptor() {
        return adaptor;
    }

    public String[] getTokenNames() { return CompilerAstParser.tokenNames; }
    public String getGrammarFileName() { return "/home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g"; }


        private IErrorReporter errorReporter = null;
        public void setErrorReporter(IErrorReporter errorReporter) {
            this.errorReporter = errorReporter;
        }
    //    public void emitErrorMessage(String msg) {
    //        errorReporter.reportError(msg);
    //    }
        
        private List errors = new LinkedList();
        public void displayRecognitionError(String[] tokenNames,
                                            RecognitionException e) {
            String hdr = getErrorHeader(e);
            String msg = getErrorMessage(e, tokenNames);
            errors.add(hdr + " " + msg);
        }
        public List getErrors() {
            return errors;
        }


    public static class php_source_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "php_source"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:110:1: php_source : ( SOC_T | SOC_PHP_T ) ( top_statement_list )? EOC_T -> ^( ModuleDeclaration ( top_statement_list )? ) ;
    public final CompilerAstParser.php_source_return php_source() throws RecognitionException {
        CompilerAstParser.php_source_return retval = new CompilerAstParser.php_source_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token SOC_T1=null;
        Token SOC_PHP_T2=null;
        Token EOC_T4=null;
        CompilerAstParser.top_statement_list_return top_statement_list3 = null;


        SLAST SOC_T1_tree=null;
        SLAST SOC_PHP_T2_tree=null;
        SLAST EOC_T4_tree=null;
        RewriteRuleTokenStream stream_SOC_T=new RewriteRuleTokenStream(adaptor,"token SOC_T");
        RewriteRuleTokenStream stream_EOC_T=new RewriteRuleTokenStream(adaptor,"token EOC_T");
        RewriteRuleTokenStream stream_SOC_PHP_T=new RewriteRuleTokenStream(adaptor,"token SOC_PHP_T");
        RewriteRuleSubtreeStream stream_top_statement_list=new RewriteRuleSubtreeStream(adaptor,"rule top_statement_list");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:120:3: ( ( SOC_T | SOC_PHP_T ) ( top_statement_list )? EOC_T -> ^( ModuleDeclaration ( top_statement_list )? ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:120:5: ( SOC_T | SOC_PHP_T ) ( top_statement_list )? EOC_T
            {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:120:5: ( SOC_T | SOC_PHP_T )
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0==SOC_T) ) {
                alt1=1;
            }
            else if ( (LA1_0==SOC_PHP_T) ) {
                alt1=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 1, 0, input);

                throw nvae;
            }
            switch (alt1) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:120:6: SOC_T
                    {
                    SOC_T1=(Token)match(input,SOC_T,FOLLOW_SOC_T_in_php_source267); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SOC_T.add(SOC_T1);

                    if ( state.backtracking==0 ) {

                          token = (CommonToken)SOC_T1;
                          startIndex = token.getStartIndex();
                        
                    }

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:125:5: SOC_PHP_T
                    {
                    SOC_PHP_T2=(Token)match(input,SOC_PHP_T,FOLLOW_SOC_PHP_T_in_php_source279); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SOC_PHP_T.add(SOC_PHP_T2);

                    if ( state.backtracking==0 ) {

                          token = (CommonToken)SOC_PHP_T2;
                          startIndex = token.getStartIndex();
                        
                    }

                    }
                    break;

            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:130:9: ( top_statement_list )?
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==LEFT_PARETHESIS||(LA2_0>=SEMI_COLON && LA2_0<=IDENTIFIER)||LA2_0==LEFT_BRACKET||(LA2_0>=INTERFACE_T && LA2_0<=REF_T)||(LA2_0>=WHILE_T && LA2_0<=FOREACH_T)||(LA2_0>=DECLARE_T && LA2_0<=STRINGLITERAL)||LA2_0==IF_T||(LA2_0>=PLUS_T && LA2_0<=MINUS_T)||(LA2_0>=UNSET_T && LA2_0<=MINUS_MINUS_T)||(LA2_0>=AT_T && LA2_0<=BACKTRICKLITERAL)||(LA2_0>=DOLLAR_T && LA2_0<=DOUBLELITERRAL)||(LA2_0>=164 && LA2_0<=166)||(LA2_0>=179 && LA2_0<=185)) ) {
                alt2=1;
            }
            switch (alt2) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:130:9: top_statement_list
                    {
                    pushFollow(FOLLOW_top_statement_list_in_php_source294);
                    top_statement_list3=top_statement_list();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_top_statement_list.add(top_statement_list3.getTree());

                    }
                    break;

            }

            EOC_T4=(Token)match(input,EOC_T,FOLLOW_EOC_T_in_php_source303); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_EOC_T.add(EOC_T4);

            if ( state.backtracking==0 ) {

                  token = (CommonToken)EOC_T4;
                  endIndex = token.getStopIndex();
                
            }


            // AST REWRITE
            // elements: top_statement_list
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 136:5: -> ^( ModuleDeclaration ( top_statement_list )? )
            {
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:136:9: ^( ModuleDeclaration ( top_statement_list )? )
                {
                SLAST root_1 = (SLAST)adaptor.nil();
                root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(ModuleDeclaration, "ModuleDeclaration"), root_1);

                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:136:29: ( top_statement_list )?
                if ( stream_top_statement_list.hasNext() ) {
                    adaptor.addChild(root_1, stream_top_statement_list.nextTree());

                }
                stream_top_statement_list.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST phpSourceToken = retval.tree;
                phpSourceToken.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "php_source"

    public static class top_statement_list_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "top_statement_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:140:1: top_statement_list : ( top_statement )+ ;
    public final CompilerAstParser.top_statement_list_return top_statement_list() throws RecognitionException {
        CompilerAstParser.top_statement_list_return retval = new CompilerAstParser.top_statement_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        CompilerAstParser.top_statement_return top_statement5 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:141:3: ( ( top_statement )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:141:5: ( top_statement )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:141:5: ( top_statement )+
            int cnt3=0;
            loop3:
            do {
                int alt3=2;
                int LA3_0 = input.LA(1);

                if ( (LA3_0==LEFT_PARETHESIS||(LA3_0>=SEMI_COLON && LA3_0<=IDENTIFIER)||LA3_0==LEFT_BRACKET||(LA3_0>=INTERFACE_T && LA3_0<=REF_T)||(LA3_0>=WHILE_T && LA3_0<=FOREACH_T)||(LA3_0>=DECLARE_T && LA3_0<=STRINGLITERAL)||LA3_0==IF_T||(LA3_0>=PLUS_T && LA3_0<=MINUS_T)||(LA3_0>=UNSET_T && LA3_0<=MINUS_MINUS_T)||(LA3_0>=AT_T && LA3_0<=BACKTRICKLITERAL)||(LA3_0>=DOLLAR_T && LA3_0<=DOUBLELITERRAL)||(LA3_0>=164 && LA3_0<=166)||(LA3_0>=179 && LA3_0<=185)) ) {
                    alt3=1;
                }


                switch (alt3) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:141:5: top_statement
            	    {
            	    pushFollow(FOLLOW_top_statement_in_top_statement_list338);
            	    top_statement5=top_statement();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, top_statement5.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt3 >= 1 ) break loop3;
            	    if (state.backtracking>0) {state.failed=true; return retval;}
                        EarlyExitException eee =
                            new EarlyExitException(3, input);
                        throw eee;
                }
                cnt3++;
            } while (true);


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "top_statement_list"

    public static class top_statement_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "top_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:144:1: top_statement : ( statement | function_declaration_statement | class_declaration_statement | halt_compiler_statement );
    public final CompilerAstParser.top_statement_return top_statement() throws RecognitionException {
        CompilerAstParser.top_statement_return retval = new CompilerAstParser.top_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        CompilerAstParser.statement_return statement6 = null;

        CompilerAstParser.function_declaration_statement_return function_declaration_statement7 = null;

        CompilerAstParser.class_declaration_statement_return class_declaration_statement8 = null;

        CompilerAstParser.halt_compiler_statement_return halt_compiler_statement9 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:145:3: ( statement | function_declaration_statement | class_declaration_statement | halt_compiler_statement )
            int alt4=4;
            switch ( input.LA(1) ) {
            case LEFT_PARETHESIS:
            case SEMI_COLON:
            case IDENTIFIER:
            case LEFT_BRACKET:
            case REF_T:
            case WHILE_T:
            case DO_T:
            case FOR_T:
            case SWITCH_T:
            case BREAK_T:
            case CONTINUE_T:
            case RETURN_T:
            case GLOBAL_T:
            case STATIC_T:
            case ECHO_T:
            case FOREACH_T:
            case DECLARE_T:
            case TRY_T:
            case THROW_T:
            case USE_T:
            case INCLUDE_T:
            case INCLUDE_ONCE_T:
            case STRINGLITERAL:
            case IF_T:
            case PLUS_T:
            case MINUS_T:
            case UNSET_T:
            case CLONE_T:
            case TILDA_T:
            case EXC_NOT_T:
            case PLUS_PLUS_T:
            case MINUS_MINUS_T:
            case AT_T:
            case LIST_T:
            case NEW_T:
            case EXIT_T:
            case BACKTRICKLITERAL:
            case DOLLAR_T:
            case INTLITERAL:
            case FLOATLITERAL:
            case DOUBLELITERRAL:
            case 179:
            case 180:
            case 181:
            case 182:
            case 183:
            case 184:
            case 185:
                {
                alt4=1;
                }
                break;
            case FUNCTION_T:
                {
                switch ( input.LA(2) ) {
                case REF_T:
                    {
                    int LA4_5 = input.LA(3);

                    if ( (LA4_5==IDENTIFIER) ) {
                        alt4=2;
                    }
                    else if ( (LA4_5==LEFT_PARETHESIS) ) {
                        alt4=1;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return retval;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 4, 5, input);

                        throw nvae;
                    }
                    }
                    break;
                case LEFT_PARETHESIS:
                    {
                    alt4=1;
                    }
                    break;
                case IDENTIFIER:
                    {
                    alt4=2;
                    }
                    break;
                default:
                    if (state.backtracking>0) {state.failed=true; return retval;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 4, 2, input);

                    throw nvae;
                }

                }
                break;
            case CLASS_T:
            case INTERFACE_T:
            case 165:
            case 166:
                {
                alt4=3;
                }
                break;
            case 164:
                {
                alt4=4;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 4, 0, input);

                throw nvae;
            }

            switch (alt4) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:145:5: statement
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_statement_in_top_statement352);
                    statement6=statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, statement6.getTree());

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:146:5: function_declaration_statement
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_function_declaration_statement_in_top_statement358);
                    function_declaration_statement7=function_declaration_statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, function_declaration_statement7.getTree());

                    }
                    break;
                case 3 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:147:5: class_declaration_statement
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_class_declaration_statement_in_top_statement364);
                    class_declaration_statement8=class_declaration_statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, class_declaration_statement8.getTree());

                    }
                    break;
                case 4 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:148:5: halt_compiler_statement
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_halt_compiler_statement_in_top_statement370);
                    halt_compiler_statement9=halt_compiler_statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, halt_compiler_statement9.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "top_statement"

    public static class inner_statement_list_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "inner_statement_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:151:1: inner_statement_list : ( inner_statement )+ ;
    public final CompilerAstParser.inner_statement_list_return inner_statement_list() throws RecognitionException {
        CompilerAstParser.inner_statement_list_return retval = new CompilerAstParser.inner_statement_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        CompilerAstParser.inner_statement_return inner_statement10 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:152:3: ( ( inner_statement )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:152:5: ( inner_statement )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:152:5: ( inner_statement )+
            int cnt5=0;
            loop5:
            do {
                int alt5=2;
                int LA5_0 = input.LA(1);

                if ( (LA5_0==LEFT_PARETHESIS||(LA5_0>=SEMI_COLON && LA5_0<=IDENTIFIER)||LA5_0==LEFT_BRACKET||(LA5_0>=INTERFACE_T && LA5_0<=REF_T)||(LA5_0>=WHILE_T && LA5_0<=FOREACH_T)||(LA5_0>=DECLARE_T && LA5_0<=STRINGLITERAL)||LA5_0==IF_T||(LA5_0>=PLUS_T && LA5_0<=MINUS_T)||(LA5_0>=UNSET_T && LA5_0<=MINUS_MINUS_T)||(LA5_0>=AT_T && LA5_0<=BACKTRICKLITERAL)||(LA5_0>=DOLLAR_T && LA5_0<=DOUBLELITERRAL)||(LA5_0>=164 && LA5_0<=166)||(LA5_0>=179 && LA5_0<=185)) ) {
                    alt5=1;
                }


                switch (alt5) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:152:6: inner_statement
            	    {
            	    pushFollow(FOLLOW_inner_statement_in_inner_statement_list386);
            	    inner_statement10=inner_statement();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, inner_statement10.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt5 >= 1 ) break loop5;
            	    if (state.backtracking>0) {state.failed=true; return retval;}
                        EarlyExitException eee =
                            new EarlyExitException(5, input);
                        throw eee;
                }
                cnt5++;
            } while (true);


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "inner_statement_list"

    public static class inner_statement_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "inner_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:155:1: inner_statement : ( statement | function_declaration_statement | class_declaration_statement | halt_compiler_statement );
    public final CompilerAstParser.inner_statement_return inner_statement() throws RecognitionException {
        CompilerAstParser.inner_statement_return retval = new CompilerAstParser.inner_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        CompilerAstParser.statement_return statement11 = null;

        CompilerAstParser.function_declaration_statement_return function_declaration_statement12 = null;

        CompilerAstParser.class_declaration_statement_return class_declaration_statement13 = null;

        CompilerAstParser.halt_compiler_statement_return halt_compiler_statement14 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:156:3: ( statement | function_declaration_statement | class_declaration_statement | halt_compiler_statement )
            int alt6=4;
            switch ( input.LA(1) ) {
            case LEFT_PARETHESIS:
            case SEMI_COLON:
            case IDENTIFIER:
            case LEFT_BRACKET:
            case REF_T:
            case WHILE_T:
            case DO_T:
            case FOR_T:
            case SWITCH_T:
            case BREAK_T:
            case CONTINUE_T:
            case RETURN_T:
            case GLOBAL_T:
            case STATIC_T:
            case ECHO_T:
            case FOREACH_T:
            case DECLARE_T:
            case TRY_T:
            case THROW_T:
            case USE_T:
            case INCLUDE_T:
            case INCLUDE_ONCE_T:
            case STRINGLITERAL:
            case IF_T:
            case PLUS_T:
            case MINUS_T:
            case UNSET_T:
            case CLONE_T:
            case TILDA_T:
            case EXC_NOT_T:
            case PLUS_PLUS_T:
            case MINUS_MINUS_T:
            case AT_T:
            case LIST_T:
            case NEW_T:
            case EXIT_T:
            case BACKTRICKLITERAL:
            case DOLLAR_T:
            case INTLITERAL:
            case FLOATLITERAL:
            case DOUBLELITERRAL:
            case 179:
            case 180:
            case 181:
            case 182:
            case 183:
            case 184:
            case 185:
                {
                alt6=1;
                }
                break;
            case FUNCTION_T:
                {
                switch ( input.LA(2) ) {
                case REF_T:
                    {
                    int LA6_5 = input.LA(3);

                    if ( (LA6_5==LEFT_PARETHESIS) ) {
                        alt6=1;
                    }
                    else if ( (LA6_5==IDENTIFIER) ) {
                        alt6=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return retval;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 6, 5, input);

                        throw nvae;
                    }
                    }
                    break;
                case IDENTIFIER:
                    {
                    alt6=2;
                    }
                    break;
                case LEFT_PARETHESIS:
                    {
                    alt6=1;
                    }
                    break;
                default:
                    if (state.backtracking>0) {state.failed=true; return retval;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 6, 2, input);

                    throw nvae;
                }

                }
                break;
            case CLASS_T:
            case INTERFACE_T:
            case 165:
            case 166:
                {
                alt6=3;
                }
                break;
            case 164:
                {
                alt6=4;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 6, 0, input);

                throw nvae;
            }

            switch (alt6) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:156:5: statement
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_statement_in_inner_statement403);
                    statement11=statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, statement11.getTree());

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:157:5: function_declaration_statement
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_function_declaration_statement_in_inner_statement409);
                    function_declaration_statement12=function_declaration_statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, function_declaration_statement12.getTree());

                    }
                    break;
                case 3 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:158:5: class_declaration_statement
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_class_declaration_statement_in_inner_statement415);
                    class_declaration_statement13=class_declaration_statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, class_declaration_statement13.getTree());

                    }
                    break;
                case 4 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:159:5: halt_compiler_statement
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_halt_compiler_statement_in_inner_statement421);
                    halt_compiler_statement14=halt_compiler_statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, halt_compiler_statement14.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "inner_statement"

    public static class halt_compiler_statement_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "halt_compiler_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:162:1: halt_compiler_statement : '__halt_compiler' LEFT_PARETHESIS RIGHT_PARETHESIS SEMI_COLON -> '__halt_compiler' ;
    public final CompilerAstParser.halt_compiler_statement_return halt_compiler_statement() throws RecognitionException {
        CompilerAstParser.halt_compiler_statement_return retval = new CompilerAstParser.halt_compiler_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token string_literal15=null;
        Token LEFT_PARETHESIS16=null;
        Token RIGHT_PARETHESIS17=null;
        Token SEMI_COLON18=null;

        SLAST string_literal15_tree=null;
        SLAST LEFT_PARETHESIS16_tree=null;
        SLAST RIGHT_PARETHESIS17_tree=null;
        SLAST SEMI_COLON18_tree=null;
        RewriteRuleTokenStream stream_164=new RewriteRuleTokenStream(adaptor,"token 164");
        RewriteRuleTokenStream stream_LEFT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token LEFT_PARETHESIS");
        RewriteRuleTokenStream stream_SEMI_COLON=new RewriteRuleTokenStream(adaptor,"token SEMI_COLON");
        RewriteRuleTokenStream stream_RIGHT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token RIGHT_PARETHESIS");

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:163:3: ( '__halt_compiler' LEFT_PARETHESIS RIGHT_PARETHESIS SEMI_COLON -> '__halt_compiler' )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:163:5: '__halt_compiler' LEFT_PARETHESIS RIGHT_PARETHESIS SEMI_COLON
            {
            string_literal15=(Token)match(input,164,FOLLOW_164_in_halt_compiler_statement436); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_164.add(string_literal15);

            LEFT_PARETHESIS16=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_halt_compiler_statement438); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS16);

            RIGHT_PARETHESIS17=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_halt_compiler_statement440); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS17);

            SEMI_COLON18=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_halt_compiler_statement442); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON18);



            // AST REWRITE
            // elements: 164
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 163:69: -> '__halt_compiler'
            {
                adaptor.addChild(root_0, stream_164.nextNode());

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "halt_compiler_statement"

    public static class class_declaration_statement_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "class_declaration_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:166:1: class_declaration_statement : ( ( ( class_entr_type )? CLASS_T IDENTIFIER ( EXTENDS_T fully_qualified_class_name )? ( IMPLEMENTS_T fully_qualified_class_name_list )? LEFT_BRACKET ( class_statement_list )? RIGHT_BRACKET -> ^( CLASS_T ( class_entr_type )? IDENTIFIER ( ^( EXTENDS_T fully_qualified_class_name ) )? ( ^( IMPLEMENTS_T fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? ) ) | ( INTERFACE_T IDENTIFIER ( EXTENDS_T fully_qualified_class_name_list )? ( IMPLEMENTS_T fully_qualified_class_name_list )? LEFT_BRACKET ( class_statement_list )? RIGHT_BRACKET -> ^( INTERFACE_T IDENTIFIER ( ^( EXTENDS_T fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? ) ) );
    public final CompilerAstParser.class_declaration_statement_return class_declaration_statement() throws RecognitionException {
        CompilerAstParser.class_declaration_statement_return retval = new CompilerAstParser.class_declaration_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token CLASS_T20=null;
        Token IDENTIFIER21=null;
        Token EXTENDS_T22=null;
        Token IMPLEMENTS_T24=null;
        Token LEFT_BRACKET26=null;
        Token RIGHT_BRACKET28=null;
        Token INTERFACE_T29=null;
        Token IDENTIFIER30=null;
        Token EXTENDS_T31=null;
        Token IMPLEMENTS_T33=null;
        Token LEFT_BRACKET35=null;
        Token RIGHT_BRACKET37=null;
        CompilerAstParser.class_entr_type_return class_entr_type19 = null;

        CompilerAstParser.fully_qualified_class_name_return fully_qualified_class_name23 = null;

        CompilerAstParser.fully_qualified_class_name_list_return fully_qualified_class_name_list25 = null;

        CompilerAstParser.class_statement_list_return class_statement_list27 = null;

        CompilerAstParser.fully_qualified_class_name_list_return fully_qualified_class_name_list32 = null;

        CompilerAstParser.fully_qualified_class_name_list_return fully_qualified_class_name_list34 = null;

        CompilerAstParser.class_statement_list_return class_statement_list36 = null;


        SLAST CLASS_T20_tree=null;
        SLAST IDENTIFIER21_tree=null;
        SLAST EXTENDS_T22_tree=null;
        SLAST IMPLEMENTS_T24_tree=null;
        SLAST LEFT_BRACKET26_tree=null;
        SLAST RIGHT_BRACKET28_tree=null;
        SLAST INTERFACE_T29_tree=null;
        SLAST IDENTIFIER30_tree=null;
        SLAST EXTENDS_T31_tree=null;
        SLAST IMPLEMENTS_T33_tree=null;
        SLAST LEFT_BRACKET35_tree=null;
        SLAST RIGHT_BRACKET37_tree=null;
        RewriteRuleTokenStream stream_EXTENDS_T=new RewriteRuleTokenStream(adaptor,"token EXTENDS_T");
        RewriteRuleTokenStream stream_INTERFACE_T=new RewriteRuleTokenStream(adaptor,"token INTERFACE_T");
        RewriteRuleTokenStream stream_CLASS_T=new RewriteRuleTokenStream(adaptor,"token CLASS_T");
        RewriteRuleTokenStream stream_IMPLEMENTS_T=new RewriteRuleTokenStream(adaptor,"token IMPLEMENTS_T");
        RewriteRuleTokenStream stream_IDENTIFIER=new RewriteRuleTokenStream(adaptor,"token IDENTIFIER");
        RewriteRuleTokenStream stream_LEFT_BRACKET=new RewriteRuleTokenStream(adaptor,"token LEFT_BRACKET");
        RewriteRuleTokenStream stream_RIGHT_BRACKET=new RewriteRuleTokenStream(adaptor,"token RIGHT_BRACKET");
        RewriteRuleSubtreeStream stream_fully_qualified_class_name=new RewriteRuleSubtreeStream(adaptor,"rule fully_qualified_class_name");
        RewriteRuleSubtreeStream stream_fully_qualified_class_name_list=new RewriteRuleSubtreeStream(adaptor,"rule fully_qualified_class_name_list");
        RewriteRuleSubtreeStream stream_class_entr_type=new RewriteRuleSubtreeStream(adaptor,"rule class_entr_type");
        RewriteRuleSubtreeStream stream_class_statement_list=new RewriteRuleSubtreeStream(adaptor,"rule class_statement_list");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:176:3: ( ( ( class_entr_type )? CLASS_T IDENTIFIER ( EXTENDS_T fully_qualified_class_name )? ( IMPLEMENTS_T fully_qualified_class_name_list )? LEFT_BRACKET ( class_statement_list )? RIGHT_BRACKET -> ^( CLASS_T ( class_entr_type )? IDENTIFIER ( ^( EXTENDS_T fully_qualified_class_name ) )? ( ^( IMPLEMENTS_T fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? ) ) | ( INTERFACE_T IDENTIFIER ( EXTENDS_T fully_qualified_class_name_list )? ( IMPLEMENTS_T fully_qualified_class_name_list )? LEFT_BRACKET ( class_statement_list )? RIGHT_BRACKET -> ^( INTERFACE_T IDENTIFIER ( ^( EXTENDS_T fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? ) ) )
            int alt14=2;
            int LA14_0 = input.LA(1);

            if ( (LA14_0==CLASS_T||(LA14_0>=165 && LA14_0<=166)) ) {
                alt14=1;
            }
            else if ( (LA14_0==INTERFACE_T) ) {
                alt14=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 14, 0, input);

                throw nvae;
            }
            switch (alt14) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:176:5: ( ( class_entr_type )? CLASS_T IDENTIFIER ( EXTENDS_T fully_qualified_class_name )? ( IMPLEMENTS_T fully_qualified_class_name_list )? LEFT_BRACKET ( class_statement_list )? RIGHT_BRACKET -> ^( CLASS_T ( class_entr_type )? IDENTIFIER ( ^( EXTENDS_T fully_qualified_class_name ) )? ( ^( IMPLEMENTS_T fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? ) )
                    {
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:176:5: ( ( class_entr_type )? CLASS_T IDENTIFIER ( EXTENDS_T fully_qualified_class_name )? ( IMPLEMENTS_T fully_qualified_class_name_list )? LEFT_BRACKET ( class_statement_list )? RIGHT_BRACKET -> ^( CLASS_T ( class_entr_type )? IDENTIFIER ( ^( EXTENDS_T fully_qualified_class_name ) )? ( ^( IMPLEMENTS_T fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? ) )
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:176:7: ( class_entr_type )? CLASS_T IDENTIFIER ( EXTENDS_T fully_qualified_class_name )? ( IMPLEMENTS_T fully_qualified_class_name_list )? LEFT_BRACKET ( class_statement_list )? RIGHT_BRACKET
                    {
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:176:7: ( class_entr_type )?
                    int alt7=2;
                    int LA7_0 = input.LA(1);

                    if ( ((LA7_0>=165 && LA7_0<=166)) ) {
                        alt7=1;
                    }
                    switch (alt7) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:176:7: class_entr_type
                            {
                            pushFollow(FOLLOW_class_entr_type_in_class_declaration_statement477);
                            class_entr_type19=class_entr_type();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_class_entr_type.add(class_entr_type19.getTree());

                            }
                            break;

                    }

                    CLASS_T20=(Token)match(input,CLASS_T,FOLLOW_CLASS_T_in_class_declaration_statement480); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_CLASS_T.add(CLASS_T20);

                    IDENTIFIER21=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_class_declaration_statement482); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER21);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:176:43: ( EXTENDS_T fully_qualified_class_name )?
                    int alt8=2;
                    int LA8_0 = input.LA(1);

                    if ( (LA8_0==EXTENDS_T) ) {
                        alt8=1;
                    }
                    switch (alt8) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:176:44: EXTENDS_T fully_qualified_class_name
                            {
                            EXTENDS_T22=(Token)match(input,EXTENDS_T,FOLLOW_EXTENDS_T_in_class_declaration_statement485); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_EXTENDS_T.add(EXTENDS_T22);

                            pushFollow(FOLLOW_fully_qualified_class_name_in_class_declaration_statement487);
                            fully_qualified_class_name23=fully_qualified_class_name();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_fully_qualified_class_name.add(fully_qualified_class_name23.getTree());

                            }
                            break;

                    }

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:176:83: ( IMPLEMENTS_T fully_qualified_class_name_list )?
                    int alt9=2;
                    int LA9_0 = input.LA(1);

                    if ( (LA9_0==IMPLEMENTS_T) ) {
                        alt9=1;
                    }
                    switch (alt9) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:176:84: IMPLEMENTS_T fully_qualified_class_name_list
                            {
                            IMPLEMENTS_T24=(Token)match(input,IMPLEMENTS_T,FOLLOW_IMPLEMENTS_T_in_class_declaration_statement492); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_IMPLEMENTS_T.add(IMPLEMENTS_T24);

                            pushFollow(FOLLOW_fully_qualified_class_name_list_in_class_declaration_statement494);
                            fully_qualified_class_name_list25=fully_qualified_class_name_list();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_fully_qualified_class_name_list.add(fully_qualified_class_name_list25.getTree());

                            }
                            break;

                    }

                    LEFT_BRACKET26=(Token)match(input,LEFT_BRACKET,FOLLOW_LEFT_BRACKET_in_class_declaration_statement504); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LEFT_BRACKET.add(LEFT_BRACKET26);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:177:20: ( class_statement_list )?
                    int alt10=2;
                    int LA10_0 = input.LA(1);

                    if ( (LA10_0==FUNCTION_T||LA10_0==CONST_T||LA10_0==STATIC_T||(LA10_0>=165 && LA10_0<=170)) ) {
                        alt10=1;
                    }
                    switch (alt10) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:177:20: class_statement_list
                            {
                            pushFollow(FOLLOW_class_statement_list_in_class_declaration_statement506);
                            class_statement_list27=class_statement_list();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_class_statement_list.add(class_statement_list27.getTree());

                            }
                            break;

                    }

                    RIGHT_BRACKET28=(Token)match(input,RIGHT_BRACKET,FOLLOW_RIGHT_BRACKET_in_class_declaration_statement509); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RIGHT_BRACKET.add(RIGHT_BRACKET28);

                    if ( state.backtracking==0 ) {

                            startIndex = ((CommonToken)CLASS_T20).getStartIndex();
                            if ((class_entr_type19!=null?input.toString(class_entr_type19.start,class_entr_type19.stop):null) != null) {
                                token = (CommonToken)(class_entr_type19!=null?((Token)class_entr_type19.start):null);
                                startIndex = token.getStartIndex();
                            } 
                            token = (CommonToken)RIGHT_BRACKET28;
                            endIndex = token.getStopIndex(); 
                          
                    }


                    // AST REWRITE
                    // elements: fully_qualified_class_name, fully_qualified_class_name_list, IMPLEMENTS_T, EXTENDS_T, IDENTIFIER, class_statement_list, CLASS_T, class_entr_type
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 187:5: -> ^( CLASS_T ( class_entr_type )? IDENTIFIER ( ^( EXTENDS_T fully_qualified_class_name ) )? ( ^( IMPLEMENTS_T fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:187:9: ^( CLASS_T ( class_entr_type )? IDENTIFIER ( ^( EXTENDS_T fully_qualified_class_name ) )? ( ^( IMPLEMENTS_T fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_CLASS_T.nextNode(), root_1);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:187:19: ( class_entr_type )?
                        if ( stream_class_entr_type.hasNext() ) {
                            adaptor.addChild(root_1, stream_class_entr_type.nextTree());

                        }
                        stream_class_entr_type.reset();
                        adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:187:47: ( ^( EXTENDS_T fully_qualified_class_name ) )?
                        if ( stream_fully_qualified_class_name.hasNext()||stream_EXTENDS_T.hasNext() ) {
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:187:47: ^( EXTENDS_T fully_qualified_class_name )
                            {
                            SLAST root_2 = (SLAST)adaptor.nil();
                            root_2 = (SLAST)adaptor.becomeRoot(stream_EXTENDS_T.nextNode(), root_2);

                            adaptor.addChild(root_2, stream_fully_qualified_class_name.nextTree());

                            adaptor.addChild(root_1, root_2);
                            }

                        }
                        stream_fully_qualified_class_name.reset();
                        stream_EXTENDS_T.reset();
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:187:88: ( ^( IMPLEMENTS_T fully_qualified_class_name_list ) )?
                        if ( stream_fully_qualified_class_name_list.hasNext()||stream_IMPLEMENTS_T.hasNext() ) {
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:187:88: ^( IMPLEMENTS_T fully_qualified_class_name_list )
                            {
                            SLAST root_2 = (SLAST)adaptor.nil();
                            root_2 = (SLAST)adaptor.becomeRoot(stream_IMPLEMENTS_T.nextNode(), root_2);

                            adaptor.addChild(root_2, stream_fully_qualified_class_name_list.nextTree());

                            adaptor.addChild(root_1, root_2);
                            }

                        }
                        stream_fully_qualified_class_name_list.reset();
                        stream_IMPLEMENTS_T.reset();
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:188:7: ( ^( CLASS_BODY class_statement_list ) )?
                        if ( stream_class_statement_list.hasNext() ) {
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:188:7: ^( CLASS_BODY class_statement_list )
                            {
                            SLAST root_2 = (SLAST)adaptor.nil();
                            root_2 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(CLASS_BODY, "CLASS_BODY"), root_2);

                            adaptor.addChild(root_2, stream_class_statement_list.nextTree());

                            adaptor.addChild(root_1, root_2);
                            }

                        }
                        stream_class_statement_list.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }


                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:190:6: ( INTERFACE_T IDENTIFIER ( EXTENDS_T fully_qualified_class_name_list )? ( IMPLEMENTS_T fully_qualified_class_name_list )? LEFT_BRACKET ( class_statement_list )? RIGHT_BRACKET -> ^( INTERFACE_T IDENTIFIER ( ^( EXTENDS_T fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? ) )
                    {
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:190:6: ( INTERFACE_T IDENTIFIER ( EXTENDS_T fully_qualified_class_name_list )? ( IMPLEMENTS_T fully_qualified_class_name_list )? LEFT_BRACKET ( class_statement_list )? RIGHT_BRACKET -> ^( INTERFACE_T IDENTIFIER ( ^( EXTENDS_T fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? ) )
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:190:7: INTERFACE_T IDENTIFIER ( EXTENDS_T fully_qualified_class_name_list )? ( IMPLEMENTS_T fully_qualified_class_name_list )? LEFT_BRACKET ( class_statement_list )? RIGHT_BRACKET
                    {
                    INTERFACE_T29=(Token)match(input,INTERFACE_T,FOLLOW_INTERFACE_T_in_class_declaration_statement570); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_INTERFACE_T.add(INTERFACE_T29);

                    IDENTIFIER30=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_class_declaration_statement572); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER30);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:190:30: ( EXTENDS_T fully_qualified_class_name_list )?
                    int alt11=2;
                    int LA11_0 = input.LA(1);

                    if ( (LA11_0==EXTENDS_T) ) {
                        alt11=1;
                    }
                    switch (alt11) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:190:31: EXTENDS_T fully_qualified_class_name_list
                            {
                            EXTENDS_T31=(Token)match(input,EXTENDS_T,FOLLOW_EXTENDS_T_in_class_declaration_statement575); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_EXTENDS_T.add(EXTENDS_T31);

                            pushFollow(FOLLOW_fully_qualified_class_name_list_in_class_declaration_statement577);
                            fully_qualified_class_name_list32=fully_qualified_class_name_list();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_fully_qualified_class_name_list.add(fully_qualified_class_name_list32.getTree());

                            }
                            break;

                    }

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:190:75: ( IMPLEMENTS_T fully_qualified_class_name_list )?
                    int alt12=2;
                    int LA12_0 = input.LA(1);

                    if ( (LA12_0==IMPLEMENTS_T) ) {
                        alt12=1;
                    }
                    switch (alt12) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:190:76: IMPLEMENTS_T fully_qualified_class_name_list
                            {
                            IMPLEMENTS_T33=(Token)match(input,IMPLEMENTS_T,FOLLOW_IMPLEMENTS_T_in_class_declaration_statement582); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_IMPLEMENTS_T.add(IMPLEMENTS_T33);

                            pushFollow(FOLLOW_fully_qualified_class_name_list_in_class_declaration_statement584);
                            fully_qualified_class_name_list34=fully_qualified_class_name_list();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_fully_qualified_class_name_list.add(fully_qualified_class_name_list34.getTree());

                            }
                            break;

                    }

                    LEFT_BRACKET35=(Token)match(input,LEFT_BRACKET,FOLLOW_LEFT_BRACKET_in_class_declaration_statement594); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LEFT_BRACKET.add(LEFT_BRACKET35);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:191:20: ( class_statement_list )?
                    int alt13=2;
                    int LA13_0 = input.LA(1);

                    if ( (LA13_0==FUNCTION_T||LA13_0==CONST_T||LA13_0==STATIC_T||(LA13_0>=165 && LA13_0<=170)) ) {
                        alt13=1;
                    }
                    switch (alt13) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:191:20: class_statement_list
                            {
                            pushFollow(FOLLOW_class_statement_list_in_class_declaration_statement596);
                            class_statement_list36=class_statement_list();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_class_statement_list.add(class_statement_list36.getTree());

                            }
                            break;

                    }

                    RIGHT_BRACKET37=(Token)match(input,RIGHT_BRACKET,FOLLOW_RIGHT_BRACKET_in_class_declaration_statement599); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RIGHT_BRACKET.add(RIGHT_BRACKET37);



                    // AST REWRITE
                    // elements: INTERFACE_T, EXTENDS_T, fully_qualified_class_name_list, IDENTIFIER, class_statement_list
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 192:5: -> ^( INTERFACE_T IDENTIFIER ( ^( EXTENDS_T fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:192:9: ^( INTERFACE_T IDENTIFIER ( ^( EXTENDS_T fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_INTERFACE_T.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:192:34: ( ^( EXTENDS_T fully_qualified_class_name_list ) )?
                        if ( stream_EXTENDS_T.hasNext()||stream_fully_qualified_class_name_list.hasNext() ) {
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:192:34: ^( EXTENDS_T fully_qualified_class_name_list )
                            {
                            SLAST root_2 = (SLAST)adaptor.nil();
                            root_2 = (SLAST)adaptor.becomeRoot(stream_EXTENDS_T.nextNode(), root_2);

                            adaptor.addChild(root_2, stream_fully_qualified_class_name_list.nextTree());

                            adaptor.addChild(root_1, root_2);
                            }

                        }
                        stream_EXTENDS_T.reset();
                        stream_fully_qualified_class_name_list.reset();
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:193:7: ( ^( CLASS_BODY class_statement_list ) )?
                        if ( stream_class_statement_list.hasNext() ) {
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:193:7: ^( CLASS_BODY class_statement_list )
                            {
                            SLAST root_2 = (SLAST)adaptor.nil();
                            root_2 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(CLASS_BODY, "CLASS_BODY"), root_2);

                            adaptor.addChild(root_2, stream_class_statement_list.nextTree());

                            adaptor.addChild(root_1, root_2);
                            }

                        }
                        stream_class_statement_list.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }


                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "class_declaration_statement"

    public static class class_entr_type_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "class_entr_type"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:197:1: class_entr_type : ( 'abstract' | 'final' );
    public final CompilerAstParser.class_entr_type_return class_entr_type() throws RecognitionException {
        CompilerAstParser.class_entr_type_return retval = new CompilerAstParser.class_entr_type_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token set38=null;

        SLAST set38_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:198:3: ( 'abstract' | 'final' )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:
            {
            root_0 = (SLAST)adaptor.nil();

            set38=(Token)input.LT(1);
            if ( (input.LA(1)>=165 && input.LA(1)<=166) ) {
                input.consume();
                if ( state.backtracking==0 ) adaptor.addChild(root_0, (SLAST)adaptor.create(set38));
                state.errorRecovery=false;state.failed=false;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                MismatchedSetException mse = new MismatchedSetException(null,input);
                throw mse;
            }


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "class_entr_type"

    public static class class_statement_list_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "class_statement_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:202:1: class_statement_list : ( class_statement )+ -> ( class_statement )+ ;
    public final CompilerAstParser.class_statement_list_return class_statement_list() throws RecognitionException {
        CompilerAstParser.class_statement_list_return retval = new CompilerAstParser.class_statement_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        CompilerAstParser.class_statement_return class_statement39 = null;


        RewriteRuleSubtreeStream stream_class_statement=new RewriteRuleSubtreeStream(adaptor,"rule class_statement");
        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:203:3: ( ( class_statement )+ -> ( class_statement )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:203:5: ( class_statement )+
            {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:203:5: ( class_statement )+
            int cnt15=0;
            loop15:
            do {
                int alt15=2;
                int LA15_0 = input.LA(1);

                if ( (LA15_0==FUNCTION_T||LA15_0==CONST_T||LA15_0==STATIC_T||(LA15_0>=165 && LA15_0<=170)) ) {
                    alt15=1;
                }


                switch (alt15) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:203:6: class_statement
            	    {
            	    pushFollow(FOLLOW_class_statement_in_class_statement_list674);
            	    class_statement39=class_statement();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_class_statement.add(class_statement39.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt15 >= 1 ) break loop15;
            	    if (state.backtracking>0) {state.failed=true; return retval;}
                        EarlyExitException eee =
                            new EarlyExitException(15, input);
                        throw eee;
                }
                cnt15++;
            } while (true);



            // AST REWRITE
            // elements: class_statement
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 203:29: -> ( class_statement )+
            {
                if ( !(stream_class_statement.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_class_statement.hasNext() ) {
                    adaptor.addChild(root_0, stream_class_statement.nextTree());

                }
                stream_class_statement.reset();

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "class_statement_list"

    public static class class_statement_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "class_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:206:1: class_statement : ( variable_modifiers static_var_list SEMI_COLON -> ^( FIELD_DECL variable_modifiers static_var_list ) | ( modifier )? FUNCTION_T ( REF_T )? IDENTIFIER LEFT_PARETHESIS ( parameter_list )? RIGHT_PARETHESIS SEMI_COLON -> ^( METHOD_DECL ( modifier )? ( REF_T )? IDENTIFIER ( parameter_list )? EMPTYSTATEMENT ) | ( modifier )? FUNCTION_T ( REF_T )? IDENTIFIER LEFT_PARETHESIS ( parameter_list )? RIGHT_PARETHESIS block -> ^( METHOD_DECL ( modifier )? ( REF_T )? IDENTIFIER ( parameter_list )? block ) | CONST_T directive SEMI_COLON -> ^( FIELD_DECL CONST_T directive ) );
    public final CompilerAstParser.class_statement_return class_statement() throws RecognitionException {
        CompilerAstParser.class_statement_return retval = new CompilerAstParser.class_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token SEMI_COLON42=null;
        Token FUNCTION_T44=null;
        Token REF_T45=null;
        Token IDENTIFIER46=null;
        Token LEFT_PARETHESIS47=null;
        Token RIGHT_PARETHESIS49=null;
        Token SEMI_COLON50=null;
        Token FUNCTION_T52=null;
        Token REF_T53=null;
        Token IDENTIFIER54=null;
        Token LEFT_PARETHESIS55=null;
        Token RIGHT_PARETHESIS57=null;
        Token CONST_T59=null;
        Token SEMI_COLON61=null;
        CompilerAstParser.variable_modifiers_return variable_modifiers40 = null;

        CompilerAstParser.static_var_list_return static_var_list41 = null;

        CompilerAstParser.modifier_return modifier43 = null;

        CompilerAstParser.parameter_list_return parameter_list48 = null;

        CompilerAstParser.modifier_return modifier51 = null;

        CompilerAstParser.parameter_list_return parameter_list56 = null;

        CompilerAstParser.block_return block58 = null;

        CompilerAstParser.directive_return directive60 = null;


        SLAST SEMI_COLON42_tree=null;
        SLAST FUNCTION_T44_tree=null;
        SLAST REF_T45_tree=null;
        SLAST IDENTIFIER46_tree=null;
        SLAST LEFT_PARETHESIS47_tree=null;
        SLAST RIGHT_PARETHESIS49_tree=null;
        SLAST SEMI_COLON50_tree=null;
        SLAST FUNCTION_T52_tree=null;
        SLAST REF_T53_tree=null;
        SLAST IDENTIFIER54_tree=null;
        SLAST LEFT_PARETHESIS55_tree=null;
        SLAST RIGHT_PARETHESIS57_tree=null;
        SLAST CONST_T59_tree=null;
        SLAST SEMI_COLON61_tree=null;
        RewriteRuleTokenStream stream_LEFT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token LEFT_PARETHESIS");
        RewriteRuleTokenStream stream_SEMI_COLON=new RewriteRuleTokenStream(adaptor,"token SEMI_COLON");
        RewriteRuleTokenStream stream_REF_T=new RewriteRuleTokenStream(adaptor,"token REF_T");
        RewriteRuleTokenStream stream_IDENTIFIER=new RewriteRuleTokenStream(adaptor,"token IDENTIFIER");
        RewriteRuleTokenStream stream_CONST_T=new RewriteRuleTokenStream(adaptor,"token CONST_T");
        RewriteRuleTokenStream stream_FUNCTION_T=new RewriteRuleTokenStream(adaptor,"token FUNCTION_T");
        RewriteRuleTokenStream stream_RIGHT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token RIGHT_PARETHESIS");
        RewriteRuleSubtreeStream stream_modifier=new RewriteRuleSubtreeStream(adaptor,"rule modifier");
        RewriteRuleSubtreeStream stream_block=new RewriteRuleSubtreeStream(adaptor,"rule block");
        RewriteRuleSubtreeStream stream_directive=new RewriteRuleSubtreeStream(adaptor,"rule directive");
        RewriteRuleSubtreeStream stream_static_var_list=new RewriteRuleSubtreeStream(adaptor,"rule static_var_list");
        RewriteRuleSubtreeStream stream_parameter_list=new RewriteRuleSubtreeStream(adaptor,"rule parameter_list");
        RewriteRuleSubtreeStream stream_variable_modifiers=new RewriteRuleSubtreeStream(adaptor,"rule variable_modifiers");
        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:207:3: ( variable_modifiers static_var_list SEMI_COLON -> ^( FIELD_DECL variable_modifiers static_var_list ) | ( modifier )? FUNCTION_T ( REF_T )? IDENTIFIER LEFT_PARETHESIS ( parameter_list )? RIGHT_PARETHESIS SEMI_COLON -> ^( METHOD_DECL ( modifier )? ( REF_T )? IDENTIFIER ( parameter_list )? EMPTYSTATEMENT ) | ( modifier )? FUNCTION_T ( REF_T )? IDENTIFIER LEFT_PARETHESIS ( parameter_list )? RIGHT_PARETHESIS block -> ^( METHOD_DECL ( modifier )? ( REF_T )? IDENTIFIER ( parameter_list )? block ) | CONST_T directive SEMI_COLON -> ^( FIELD_DECL CONST_T directive ) )
            int alt22=4;
            alt22 = dfa22.predict(input);
            switch (alt22) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:207:5: variable_modifiers static_var_list SEMI_COLON
                    {
                    pushFollow(FOLLOW_variable_modifiers_in_class_statement701);
                    variable_modifiers40=variable_modifiers();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_variable_modifiers.add(variable_modifiers40.getTree());
                    pushFollow(FOLLOW_static_var_list_in_class_statement703);
                    static_var_list41=static_var_list();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_static_var_list.add(static_var_list41.getTree());
                    SEMI_COLON42=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_class_statement705); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON42);



                    // AST REWRITE
                    // elements: static_var_list, variable_modifiers
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 207:54: -> ^( FIELD_DECL variable_modifiers static_var_list )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:207:58: ^( FIELD_DECL variable_modifiers static_var_list )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(FIELD_DECL, "FIELD_DECL"), root_1);

                        adaptor.addChild(root_1, stream_variable_modifiers.nextTree());
                        adaptor.addChild(root_1, stream_static_var_list.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:208:5: ( modifier )? FUNCTION_T ( REF_T )? IDENTIFIER LEFT_PARETHESIS ( parameter_list )? RIGHT_PARETHESIS SEMI_COLON
                    {
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:208:5: ( modifier )?
                    int alt16=2;
                    int LA16_0 = input.LA(1);

                    if ( (LA16_0==STATIC_T||(LA16_0>=165 && LA16_0<=166)||(LA16_0>=168 && LA16_0<=170)) ) {
                        alt16=1;
                    }
                    switch (alt16) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:208:5: modifier
                            {
                            pushFollow(FOLLOW_modifier_in_class_statement725);
                            modifier43=modifier();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_modifier.add(modifier43.getTree());

                            }
                            break;

                    }

                    FUNCTION_T44=(Token)match(input,FUNCTION_T,FOLLOW_FUNCTION_T_in_class_statement728); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_FUNCTION_T.add(FUNCTION_T44);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:208:26: ( REF_T )?
                    int alt17=2;
                    int LA17_0 = input.LA(1);

                    if ( (LA17_0==REF_T) ) {
                        alt17=1;
                    }
                    switch (alt17) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:208:26: REF_T
                            {
                            REF_T45=(Token)match(input,REF_T,FOLLOW_REF_T_in_class_statement730); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_REF_T.add(REF_T45);


                            }
                            break;

                    }

                    IDENTIFIER46=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_class_statement733); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER46);

                    LEFT_PARETHESIS47=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_class_statement735); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS47);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:208:60: ( parameter_list )?
                    int alt18=2;
                    int LA18_0 = input.LA(1);

                    if ( (LA18_0==IDENTIFIER||(LA18_0>=REF_T && LA18_0<=CONST_T)||(LA18_0>=UNSET_T && LA18_0<=CLONE_T)||LA18_0==DOLLAR_T||(LA18_0>=171 && LA18_0<=179)) ) {
                        alt18=1;
                    }
                    switch (alt18) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:208:60: parameter_list
                            {
                            pushFollow(FOLLOW_parameter_list_in_class_statement737);
                            parameter_list48=parameter_list();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_parameter_list.add(parameter_list48.getTree());

                            }
                            break;

                    }

                    RIGHT_PARETHESIS49=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_class_statement740); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS49);

                    SEMI_COLON50=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_class_statement742); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON50);



                    // AST REWRITE
                    // elements: REF_T, parameter_list, IDENTIFIER, modifier
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 209:6: -> ^( METHOD_DECL ( modifier )? ( REF_T )? IDENTIFIER ( parameter_list )? EMPTYSTATEMENT )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:209:10: ^( METHOD_DECL ( modifier )? ( REF_T )? IDENTIFIER ( parameter_list )? EMPTYSTATEMENT )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(METHOD_DECL, "METHOD_DECL"), root_1);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:209:24: ( modifier )?
                        if ( stream_modifier.hasNext() ) {
                            adaptor.addChild(root_1, stream_modifier.nextTree());

                        }
                        stream_modifier.reset();
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:209:34: ( REF_T )?
                        if ( stream_REF_T.hasNext() ) {
                            adaptor.addChild(root_1, stream_REF_T.nextNode());

                        }
                        stream_REF_T.reset();
                        adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:209:52: ( parameter_list )?
                        if ( stream_parameter_list.hasNext() ) {
                            adaptor.addChild(root_1, stream_parameter_list.nextTree());

                        }
                        stream_parameter_list.reset();
                        adaptor.addChild(root_1, (SLAST)adaptor.create(EMPTYSTATEMENT, "EMPTYSTATEMENT"));

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 3 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:210:5: ( modifier )? FUNCTION_T ( REF_T )? IDENTIFIER LEFT_PARETHESIS ( parameter_list )? RIGHT_PARETHESIS block
                    {
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:210:5: ( modifier )?
                    int alt19=2;
                    int LA19_0 = input.LA(1);

                    if ( (LA19_0==STATIC_T||(LA19_0>=165 && LA19_0<=166)||(LA19_0>=168 && LA19_0<=170)) ) {
                        alt19=1;
                    }
                    switch (alt19) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:210:5: modifier
                            {
                            pushFollow(FOLLOW_modifier_in_class_statement773);
                            modifier51=modifier();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_modifier.add(modifier51.getTree());

                            }
                            break;

                    }

                    FUNCTION_T52=(Token)match(input,FUNCTION_T,FOLLOW_FUNCTION_T_in_class_statement776); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_FUNCTION_T.add(FUNCTION_T52);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:210:26: ( REF_T )?
                    int alt20=2;
                    int LA20_0 = input.LA(1);

                    if ( (LA20_0==REF_T) ) {
                        alt20=1;
                    }
                    switch (alt20) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:210:26: REF_T
                            {
                            REF_T53=(Token)match(input,REF_T,FOLLOW_REF_T_in_class_statement778); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_REF_T.add(REF_T53);


                            }
                            break;

                    }

                    IDENTIFIER54=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_class_statement781); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER54);

                    LEFT_PARETHESIS55=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_class_statement783); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS55);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:210:60: ( parameter_list )?
                    int alt21=2;
                    int LA21_0 = input.LA(1);

                    if ( (LA21_0==IDENTIFIER||(LA21_0>=REF_T && LA21_0<=CONST_T)||(LA21_0>=UNSET_T && LA21_0<=CLONE_T)||LA21_0==DOLLAR_T||(LA21_0>=171 && LA21_0<=179)) ) {
                        alt21=1;
                    }
                    switch (alt21) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:210:60: parameter_list
                            {
                            pushFollow(FOLLOW_parameter_list_in_class_statement785);
                            parameter_list56=parameter_list();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_parameter_list.add(parameter_list56.getTree());

                            }
                            break;

                    }

                    RIGHT_PARETHESIS57=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_class_statement788); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS57);

                    pushFollow(FOLLOW_block_in_class_statement790);
                    block58=block();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_block.add(block58.getTree());


                    // AST REWRITE
                    // elements: block, parameter_list, IDENTIFIER, REF_T, modifier
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 211:6: -> ^( METHOD_DECL ( modifier )? ( REF_T )? IDENTIFIER ( parameter_list )? block )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:211:10: ^( METHOD_DECL ( modifier )? ( REF_T )? IDENTIFIER ( parameter_list )? block )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(METHOD_DECL, "METHOD_DECL"), root_1);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:211:24: ( modifier )?
                        if ( stream_modifier.hasNext() ) {
                            adaptor.addChild(root_1, stream_modifier.nextTree());

                        }
                        stream_modifier.reset();
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:211:34: ( REF_T )?
                        if ( stream_REF_T.hasNext() ) {
                            adaptor.addChild(root_1, stream_REF_T.nextNode());

                        }
                        stream_REF_T.reset();
                        adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:211:52: ( parameter_list )?
                        if ( stream_parameter_list.hasNext() ) {
                            adaptor.addChild(root_1, stream_parameter_list.nextTree());

                        }
                        stream_parameter_list.reset();
                        adaptor.addChild(root_1, stream_block.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 4 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:212:5: CONST_T directive SEMI_COLON
                    {
                    CONST_T59=(Token)match(input,CONST_T,FOLLOW_CONST_T_in_class_statement821); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_CONST_T.add(CONST_T59);

                    pushFollow(FOLLOW_directive_in_class_statement823);
                    directive60=directive();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_directive.add(directive60.getTree());
                    SEMI_COLON61=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_class_statement825); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON61);



                    // AST REWRITE
                    // elements: directive, CONST_T
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 212:43: -> ^( FIELD_DECL CONST_T directive )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:212:47: ^( FIELD_DECL CONST_T directive )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(FIELD_DECL, "FIELD_DECL"), root_1);

                        adaptor.addChild(root_1, stream_CONST_T.nextNode());
                        adaptor.addChild(root_1, stream_directive.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "class_statement"

    public static class function_declaration_statement_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "function_declaration_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:215:1: function_declaration_statement : FUNCTION_T ( REF_T )? IDENTIFIER LEFT_PARETHESIS ( parameter_list )? RIGHT_PARETHESIS block -> ^( METHOD_DECL ( REF_T )? IDENTIFIER ( parameter_list )? block ) ;
    public final CompilerAstParser.function_declaration_statement_return function_declaration_statement() throws RecognitionException {
        CompilerAstParser.function_declaration_statement_return retval = new CompilerAstParser.function_declaration_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token FUNCTION_T62=null;
        Token REF_T63=null;
        Token IDENTIFIER64=null;
        Token LEFT_PARETHESIS65=null;
        Token RIGHT_PARETHESIS67=null;
        CompilerAstParser.parameter_list_return parameter_list66 = null;

        CompilerAstParser.block_return block68 = null;


        SLAST FUNCTION_T62_tree=null;
        SLAST REF_T63_tree=null;
        SLAST IDENTIFIER64_tree=null;
        SLAST LEFT_PARETHESIS65_tree=null;
        SLAST RIGHT_PARETHESIS67_tree=null;
        RewriteRuleTokenStream stream_LEFT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token LEFT_PARETHESIS");
        RewriteRuleTokenStream stream_REF_T=new RewriteRuleTokenStream(adaptor,"token REF_T");
        RewriteRuleTokenStream stream_IDENTIFIER=new RewriteRuleTokenStream(adaptor,"token IDENTIFIER");
        RewriteRuleTokenStream stream_FUNCTION_T=new RewriteRuleTokenStream(adaptor,"token FUNCTION_T");
        RewriteRuleTokenStream stream_RIGHT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token RIGHT_PARETHESIS");
        RewriteRuleSubtreeStream stream_block=new RewriteRuleSubtreeStream(adaptor,"rule block");
        RewriteRuleSubtreeStream stream_parameter_list=new RewriteRuleSubtreeStream(adaptor,"rule parameter_list");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:225:3: ( FUNCTION_T ( REF_T )? IDENTIFIER LEFT_PARETHESIS ( parameter_list )? RIGHT_PARETHESIS block -> ^( METHOD_DECL ( REF_T )? IDENTIFIER ( parameter_list )? block ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:225:5: FUNCTION_T ( REF_T )? IDENTIFIER LEFT_PARETHESIS ( parameter_list )? RIGHT_PARETHESIS block
            {
            FUNCTION_T62=(Token)match(input,FUNCTION_T,FOLLOW_FUNCTION_T_in_function_declaration_statement870); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_FUNCTION_T.add(FUNCTION_T62);

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:225:16: ( REF_T )?
            int alt23=2;
            int LA23_0 = input.LA(1);

            if ( (LA23_0==REF_T) ) {
                alt23=1;
            }
            switch (alt23) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:225:16: REF_T
                    {
                    REF_T63=(Token)match(input,REF_T,FOLLOW_REF_T_in_function_declaration_statement872); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_REF_T.add(REF_T63);


                    }
                    break;

            }

            IDENTIFIER64=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_function_declaration_statement875); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER64);

            LEFT_PARETHESIS65=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_function_declaration_statement877); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS65);

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:225:50: ( parameter_list )?
            int alt24=2;
            int LA24_0 = input.LA(1);

            if ( (LA24_0==IDENTIFIER||(LA24_0>=REF_T && LA24_0<=CONST_T)||(LA24_0>=UNSET_T && LA24_0<=CLONE_T)||LA24_0==DOLLAR_T||(LA24_0>=171 && LA24_0<=179)) ) {
                alt24=1;
            }
            switch (alt24) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:225:50: parameter_list
                    {
                    pushFollow(FOLLOW_parameter_list_in_function_declaration_statement879);
                    parameter_list66=parameter_list();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_parameter_list.add(parameter_list66.getTree());

                    }
                    break;

            }

            RIGHT_PARETHESIS67=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_function_declaration_statement882); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS67);

            pushFollow(FOLLOW_block_in_function_declaration_statement889);
            block68=block();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_block.add(block68.getTree());
            if ( state.backtracking==0 ) {

                  token = (CommonToken)FUNCTION_T62;
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(block68!=null?((Token)block68.stop):null);
                  endIndex = token.getStopIndex();
                
            }


            // AST REWRITE
            // elements: IDENTIFIER, block, REF_T, parameter_list
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 233:3: -> ^( METHOD_DECL ( REF_T )? IDENTIFIER ( parameter_list )? block )
            {
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:233:6: ^( METHOD_DECL ( REF_T )? IDENTIFIER ( parameter_list )? block )
                {
                SLAST root_1 = (SLAST)adaptor.nil();
                root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(METHOD_DECL, "METHOD_DECL"), root_1);

                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:233:20: ( REF_T )?
                if ( stream_REF_T.hasNext() ) {
                    adaptor.addChild(root_1, stream_REF_T.nextNode());

                }
                stream_REF_T.reset();
                adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:233:38: ( parameter_list )?
                if ( stream_parameter_list.hasNext() ) {
                    adaptor.addChild(root_1, stream_parameter_list.nextTree());

                }
                stream_parameter_list.reset();
                adaptor.addChild(root_1, stream_block.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "function_declaration_statement"

    public static class block_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "block"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:236:1: block : LEFT_BRACKET ( inner_statement_list )? RIGHT_BRACKET -> ^( BLOCK ( inner_statement_list )? ) ;
    public final CompilerAstParser.block_return block() throws RecognitionException {
        CompilerAstParser.block_return retval = new CompilerAstParser.block_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token LEFT_BRACKET69=null;
        Token RIGHT_BRACKET71=null;
        CompilerAstParser.inner_statement_list_return inner_statement_list70 = null;


        SLAST LEFT_BRACKET69_tree=null;
        SLAST RIGHT_BRACKET71_tree=null;
        RewriteRuleTokenStream stream_LEFT_BRACKET=new RewriteRuleTokenStream(adaptor,"token LEFT_BRACKET");
        RewriteRuleTokenStream stream_RIGHT_BRACKET=new RewriteRuleTokenStream(adaptor,"token RIGHT_BRACKET");
        RewriteRuleSubtreeStream stream_inner_statement_list=new RewriteRuleSubtreeStream(adaptor,"rule inner_statement_list");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:246:3: ( LEFT_BRACKET ( inner_statement_list )? RIGHT_BRACKET -> ^( BLOCK ( inner_statement_list )? ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:246:5: LEFT_BRACKET ( inner_statement_list )? RIGHT_BRACKET
            {
            LEFT_BRACKET69=(Token)match(input,LEFT_BRACKET,FOLLOW_LEFT_BRACKET_in_block935); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_LEFT_BRACKET.add(LEFT_BRACKET69);

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:246:18: ( inner_statement_list )?
            int alt25=2;
            int LA25_0 = input.LA(1);

            if ( (LA25_0==LEFT_PARETHESIS||(LA25_0>=SEMI_COLON && LA25_0<=IDENTIFIER)||LA25_0==LEFT_BRACKET||(LA25_0>=INTERFACE_T && LA25_0<=REF_T)||(LA25_0>=WHILE_T && LA25_0<=FOREACH_T)||(LA25_0>=DECLARE_T && LA25_0<=STRINGLITERAL)||LA25_0==IF_T||(LA25_0>=PLUS_T && LA25_0<=MINUS_T)||(LA25_0>=UNSET_T && LA25_0<=MINUS_MINUS_T)||(LA25_0>=AT_T && LA25_0<=BACKTRICKLITERAL)||(LA25_0>=DOLLAR_T && LA25_0<=DOUBLELITERRAL)||(LA25_0>=164 && LA25_0<=166)||(LA25_0>=179 && LA25_0<=185)) ) {
                alt25=1;
            }
            switch (alt25) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:246:18: inner_statement_list
                    {
                    pushFollow(FOLLOW_inner_statement_list_in_block937);
                    inner_statement_list70=inner_statement_list();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_inner_statement_list.add(inner_statement_list70.getTree());

                    }
                    break;

            }

            RIGHT_BRACKET71=(Token)match(input,RIGHT_BRACKET,FOLLOW_RIGHT_BRACKET_in_block940); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_RIGHT_BRACKET.add(RIGHT_BRACKET71);

            if ( state.backtracking==0 ) {

                  token = (CommonToken)LEFT_BRACKET69;
                  startIndex = token.getStartIndex();
                  token = (CommonToken)RIGHT_BRACKET71;
                  endIndex = token.getStopIndex();
                
            }


            // AST REWRITE
            // elements: inner_statement_list
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 254:6: -> ^( BLOCK ( inner_statement_list )? )
            {
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:254:10: ^( BLOCK ( inner_statement_list )? )
                {
                SLAST root_1 = (SLAST)adaptor.nil();
                root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(BLOCK, "BLOCK"), root_1);

                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:254:18: ( inner_statement_list )?
                if ( stream_inner_statement_list.hasNext() ) {
                    adaptor.addChild(root_1, stream_inner_statement_list.nextTree());

                }
                stream_inner_statement_list.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "block"

    public static class statement_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:257:1: statement : topStatement -> ^( STATEMENT topStatement ) ;
    public final CompilerAstParser.statement_return statement() throws RecognitionException {
        CompilerAstParser.statement_return retval = new CompilerAstParser.statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        CompilerAstParser.topStatement_return topStatement72 = null;


        RewriteRuleSubtreeStream stream_topStatement=new RewriteRuleSubtreeStream(adaptor,"rule topStatement");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:267:3: ( topStatement -> ^( STATEMENT topStatement ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:267:5: topStatement
            {
            pushFollow(FOLLOW_topStatement_in_statement987);
            topStatement72=topStatement();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_topStatement.add(topStatement72.getTree());
            if ( state.backtracking==0 ) {

                  token = (CommonToken)(topStatement72!=null?((Token)topStatement72.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(topStatement72!=null?((Token)topStatement72.stop):null);
                  endIndex = token.getStopIndex();
                
            }


            // AST REWRITE
            // elements: topStatement
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 274:5: -> ^( STATEMENT topStatement )
            {
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:274:8: ^( STATEMENT topStatement )
                {
                SLAST root_1 = (SLAST)adaptor.nil();
                root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(STATEMENT, "STATEMENT"), root_1);

                adaptor.addChild(root_1, stream_topStatement.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST exprToken = retval.tree;
                exprToken.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "statement"

    public static class topStatement_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "topStatement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:277:1: topStatement : ( block | if_stat | WHILE_T LEFT_PARETHESIS expression RIGHT_PARETHESIS while_statement -> ^( WHILE_T ^( CONDITION expression ) while_statement ) | DO_T statement WHILE_T LEFT_PARETHESIS expression RIGHT_PARETHESIS SEMI_COLON -> ^( DO_T ^( CONDITION expression ) statement ) | FOR_T LEFT_PARETHESIS (e1= expr_list )? SEMI_COLON (e2= expr_list )? SEMI_COLON (e3= expr_list )? RIGHT_PARETHESIS for_statement -> ^( FOR_T ( $e1)? ^( CONDITION ( $e2)? ) ^( ITERATE ( $e3)? ) ( for_statement )? ) | SWITCH_T LEFT_PARETHESIS expression RIGHT_PARETHESIS switch_case_list -> ^( SWITCH_T ^( CONDITION expression ) switch_case_list ) | BREAK_T ( expression )? SEMI_COLON -> ^( BREAK_T ( expression )? ) | CONTINUE_T ( expression )? SEMI_COLON -> ^( CONTINUE_T ( expression )? ) | RETURN_T ( expression )? SEMI_COLON -> ^( RETURN_T ( expression )? ) | GLOBAL_T variable_list SEMI_COLON -> ^( GLOBAL_T variable_list ) | STATIC_T static_var_list SEMI_COLON -> ^( STATIC_T static_var_list ) | ECHO_T expr_list SEMI_COLON -> ^( ECHO_T expr_list ) | expression SEMI_COLON | FOREACH_T LEFT_PARETHESIS expression AS_T foreach_variable ( ARROW_T foreach_variable )? RIGHT_PARETHESIS foreach_statement -> ^( FOREACH_T ^( AS_T expression foreach_variable ( foreach_variable )? ) foreach_statement ) | DECLARE_T LEFT_PARETHESIS directive RIGHT_PARETHESIS declare_statement -> ^( DECLARE_T directive ( declare_statement )? ) | SEMI_COLON -> ^( EMPTYSTATEMENT SEMI_COLON ) | TRY_T LEFT_BRACKET top_statement RIGHT_BRACKET ( catch_branch )+ -> ^( TRY_T ^( BLOCK top_statement ) ( catch_branch )+ ) | THROW_T expression SEMI_COLON -> ^( THROW_T expression ) | USE_T use_filename SEMI_COLON -> ^( USE_T use_filename ) | INCLUDE_T LEFT_PARETHESIS expression RIGHT_PARETHESIS SEMI_COLON -> ^( INCLUDE_T expression ) | INCLUDE_ONCE_T LEFT_PARETHESIS expression RIGHT_PARETHESIS SEMI_COLON -> ^( INCLUDE_ONCE_T expression ) );
    public final CompilerAstParser.topStatement_return topStatement() throws RecognitionException {
        CompilerAstParser.topStatement_return retval = new CompilerAstParser.topStatement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token WHILE_T75=null;
        Token LEFT_PARETHESIS76=null;
        Token RIGHT_PARETHESIS78=null;
        Token DO_T80=null;
        Token WHILE_T82=null;
        Token LEFT_PARETHESIS83=null;
        Token RIGHT_PARETHESIS85=null;
        Token SEMI_COLON86=null;
        Token FOR_T87=null;
        Token LEFT_PARETHESIS88=null;
        Token SEMI_COLON89=null;
        Token SEMI_COLON90=null;
        Token RIGHT_PARETHESIS91=null;
        Token SWITCH_T93=null;
        Token LEFT_PARETHESIS94=null;
        Token RIGHT_PARETHESIS96=null;
        Token BREAK_T98=null;
        Token SEMI_COLON100=null;
        Token CONTINUE_T101=null;
        Token SEMI_COLON103=null;
        Token RETURN_T104=null;
        Token SEMI_COLON106=null;
        Token GLOBAL_T107=null;
        Token SEMI_COLON109=null;
        Token STATIC_T110=null;
        Token SEMI_COLON112=null;
        Token ECHO_T113=null;
        Token SEMI_COLON115=null;
        Token SEMI_COLON117=null;
        Token FOREACH_T118=null;
        Token LEFT_PARETHESIS119=null;
        Token AS_T121=null;
        Token ARROW_T123=null;
        Token RIGHT_PARETHESIS125=null;
        Token DECLARE_T127=null;
        Token LEFT_PARETHESIS128=null;
        Token RIGHT_PARETHESIS130=null;
        Token SEMI_COLON132=null;
        Token TRY_T133=null;
        Token LEFT_BRACKET134=null;
        Token RIGHT_BRACKET136=null;
        Token THROW_T138=null;
        Token SEMI_COLON140=null;
        Token USE_T141=null;
        Token SEMI_COLON143=null;
        Token INCLUDE_T144=null;
        Token LEFT_PARETHESIS145=null;
        Token RIGHT_PARETHESIS147=null;
        Token SEMI_COLON148=null;
        Token INCLUDE_ONCE_T149=null;
        Token LEFT_PARETHESIS150=null;
        Token RIGHT_PARETHESIS152=null;
        Token SEMI_COLON153=null;
        CompilerAstParser.expr_list_return e1 = null;

        CompilerAstParser.expr_list_return e2 = null;

        CompilerAstParser.expr_list_return e3 = null;

        CompilerAstParser.block_return block73 = null;

        CompilerAstParser.if_stat_return if_stat74 = null;

        CompilerAstParser.expression_return expression77 = null;

        CompilerAstParser.while_statement_return while_statement79 = null;

        CompilerAstParser.statement_return statement81 = null;

        CompilerAstParser.expression_return expression84 = null;

        CompilerAstParser.for_statement_return for_statement92 = null;

        CompilerAstParser.expression_return expression95 = null;

        CompilerAstParser.switch_case_list_return switch_case_list97 = null;

        CompilerAstParser.expression_return expression99 = null;

        CompilerAstParser.expression_return expression102 = null;

        CompilerAstParser.expression_return expression105 = null;

        CompilerAstParser.variable_list_return variable_list108 = null;

        CompilerAstParser.static_var_list_return static_var_list111 = null;

        CompilerAstParser.expr_list_return expr_list114 = null;

        CompilerAstParser.expression_return expression116 = null;

        CompilerAstParser.expression_return expression120 = null;

        CompilerAstParser.foreach_variable_return foreach_variable122 = null;

        CompilerAstParser.foreach_variable_return foreach_variable124 = null;

        CompilerAstParser.foreach_statement_return foreach_statement126 = null;

        CompilerAstParser.directive_return directive129 = null;

        CompilerAstParser.declare_statement_return declare_statement131 = null;

        CompilerAstParser.top_statement_return top_statement135 = null;

        CompilerAstParser.catch_branch_return catch_branch137 = null;

        CompilerAstParser.expression_return expression139 = null;

        CompilerAstParser.use_filename_return use_filename142 = null;

        CompilerAstParser.expression_return expression146 = null;

        CompilerAstParser.expression_return expression151 = null;


        SLAST WHILE_T75_tree=null;
        SLAST LEFT_PARETHESIS76_tree=null;
        SLAST RIGHT_PARETHESIS78_tree=null;
        SLAST DO_T80_tree=null;
        SLAST WHILE_T82_tree=null;
        SLAST LEFT_PARETHESIS83_tree=null;
        SLAST RIGHT_PARETHESIS85_tree=null;
        SLAST SEMI_COLON86_tree=null;
        SLAST FOR_T87_tree=null;
        SLAST LEFT_PARETHESIS88_tree=null;
        SLAST SEMI_COLON89_tree=null;
        SLAST SEMI_COLON90_tree=null;
        SLAST RIGHT_PARETHESIS91_tree=null;
        SLAST SWITCH_T93_tree=null;
        SLAST LEFT_PARETHESIS94_tree=null;
        SLAST RIGHT_PARETHESIS96_tree=null;
        SLAST BREAK_T98_tree=null;
        SLAST SEMI_COLON100_tree=null;
        SLAST CONTINUE_T101_tree=null;
        SLAST SEMI_COLON103_tree=null;
        SLAST RETURN_T104_tree=null;
        SLAST SEMI_COLON106_tree=null;
        SLAST GLOBAL_T107_tree=null;
        SLAST SEMI_COLON109_tree=null;
        SLAST STATIC_T110_tree=null;
        SLAST SEMI_COLON112_tree=null;
        SLAST ECHO_T113_tree=null;
        SLAST SEMI_COLON115_tree=null;
        SLAST SEMI_COLON117_tree=null;
        SLAST FOREACH_T118_tree=null;
        SLAST LEFT_PARETHESIS119_tree=null;
        SLAST AS_T121_tree=null;
        SLAST ARROW_T123_tree=null;
        SLAST RIGHT_PARETHESIS125_tree=null;
        SLAST DECLARE_T127_tree=null;
        SLAST LEFT_PARETHESIS128_tree=null;
        SLAST RIGHT_PARETHESIS130_tree=null;
        SLAST SEMI_COLON132_tree=null;
        SLAST TRY_T133_tree=null;
        SLAST LEFT_BRACKET134_tree=null;
        SLAST RIGHT_BRACKET136_tree=null;
        SLAST THROW_T138_tree=null;
        SLAST SEMI_COLON140_tree=null;
        SLAST USE_T141_tree=null;
        SLAST SEMI_COLON143_tree=null;
        SLAST INCLUDE_T144_tree=null;
        SLAST LEFT_PARETHESIS145_tree=null;
        SLAST RIGHT_PARETHESIS147_tree=null;
        SLAST SEMI_COLON148_tree=null;
        SLAST INCLUDE_ONCE_T149_tree=null;
        SLAST LEFT_PARETHESIS150_tree=null;
        SLAST RIGHT_PARETHESIS152_tree=null;
        SLAST SEMI_COLON153_tree=null;
        RewriteRuleTokenStream stream_SWITCH_T=new RewriteRuleTokenStream(adaptor,"token SWITCH_T");
        RewriteRuleTokenStream stream_ARROW_T=new RewriteRuleTokenStream(adaptor,"token ARROW_T");
        RewriteRuleTokenStream stream_LEFT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token LEFT_PARETHESIS");
        RewriteRuleTokenStream stream_RETURN_T=new RewriteRuleTokenStream(adaptor,"token RETURN_T");
        RewriteRuleTokenStream stream_TRY_T=new RewriteRuleTokenStream(adaptor,"token TRY_T");
        RewriteRuleTokenStream stream_DO_T=new RewriteRuleTokenStream(adaptor,"token DO_T");
        RewriteRuleTokenStream stream_GLOBAL_T=new RewriteRuleTokenStream(adaptor,"token GLOBAL_T");
        RewriteRuleTokenStream stream_ECHO_T=new RewriteRuleTokenStream(adaptor,"token ECHO_T");
        RewriteRuleTokenStream stream_USE_T=new RewriteRuleTokenStream(adaptor,"token USE_T");
        RewriteRuleTokenStream stream_LEFT_BRACKET=new RewriteRuleTokenStream(adaptor,"token LEFT_BRACKET");
        RewriteRuleTokenStream stream_FOREACH_T=new RewriteRuleTokenStream(adaptor,"token FOREACH_T");
        RewriteRuleTokenStream stream_WHILE_T=new RewriteRuleTokenStream(adaptor,"token WHILE_T");
        RewriteRuleTokenStream stream_INCLUDE_T=new RewriteRuleTokenStream(adaptor,"token INCLUDE_T");
        RewriteRuleTokenStream stream_RIGHT_BRACKET=new RewriteRuleTokenStream(adaptor,"token RIGHT_BRACKET");
        RewriteRuleTokenStream stream_RIGHT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token RIGHT_PARETHESIS");
        RewriteRuleTokenStream stream_AS_T=new RewriteRuleTokenStream(adaptor,"token AS_T");
        RewriteRuleTokenStream stream_BREAK_T=new RewriteRuleTokenStream(adaptor,"token BREAK_T");
        RewriteRuleTokenStream stream_DECLARE_T=new RewriteRuleTokenStream(adaptor,"token DECLARE_T");
        RewriteRuleTokenStream stream_SEMI_COLON=new RewriteRuleTokenStream(adaptor,"token SEMI_COLON");
        RewriteRuleTokenStream stream_FOR_T=new RewriteRuleTokenStream(adaptor,"token FOR_T");
        RewriteRuleTokenStream stream_CONTINUE_T=new RewriteRuleTokenStream(adaptor,"token CONTINUE_T");
        RewriteRuleTokenStream stream_THROW_T=new RewriteRuleTokenStream(adaptor,"token THROW_T");
        RewriteRuleTokenStream stream_INCLUDE_ONCE_T=new RewriteRuleTokenStream(adaptor,"token INCLUDE_ONCE_T");
        RewriteRuleTokenStream stream_STATIC_T=new RewriteRuleTokenStream(adaptor,"token STATIC_T");
        RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");
        RewriteRuleSubtreeStream stream_while_statement=new RewriteRuleSubtreeStream(adaptor,"rule while_statement");
        RewriteRuleSubtreeStream stream_static_var_list=new RewriteRuleSubtreeStream(adaptor,"rule static_var_list");
        RewriteRuleSubtreeStream stream_declare_statement=new RewriteRuleSubtreeStream(adaptor,"rule declare_statement");
        RewriteRuleSubtreeStream stream_statement=new RewriteRuleSubtreeStream(adaptor,"rule statement");
        RewriteRuleSubtreeStream stream_use_filename=new RewriteRuleSubtreeStream(adaptor,"rule use_filename");
        RewriteRuleSubtreeStream stream_variable_list=new RewriteRuleSubtreeStream(adaptor,"rule variable_list");
        RewriteRuleSubtreeStream stream_catch_branch=new RewriteRuleSubtreeStream(adaptor,"rule catch_branch");
        RewriteRuleSubtreeStream stream_foreach_statement=new RewriteRuleSubtreeStream(adaptor,"rule foreach_statement");
        RewriteRuleSubtreeStream stream_top_statement=new RewriteRuleSubtreeStream(adaptor,"rule top_statement");
        RewriteRuleSubtreeStream stream_for_statement=new RewriteRuleSubtreeStream(adaptor,"rule for_statement");
        RewriteRuleSubtreeStream stream_directive=new RewriteRuleSubtreeStream(adaptor,"rule directive");
        RewriteRuleSubtreeStream stream_foreach_variable=new RewriteRuleSubtreeStream(adaptor,"rule foreach_variable");
        RewriteRuleSubtreeStream stream_expr_list=new RewriteRuleSubtreeStream(adaptor,"rule expr_list");
        RewriteRuleSubtreeStream stream_switch_case_list=new RewriteRuleSubtreeStream(adaptor,"rule switch_case_list");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:289:3: ( block | if_stat | WHILE_T LEFT_PARETHESIS expression RIGHT_PARETHESIS while_statement -> ^( WHILE_T ^( CONDITION expression ) while_statement ) | DO_T statement WHILE_T LEFT_PARETHESIS expression RIGHT_PARETHESIS SEMI_COLON -> ^( DO_T ^( CONDITION expression ) statement ) | FOR_T LEFT_PARETHESIS (e1= expr_list )? SEMI_COLON (e2= expr_list )? SEMI_COLON (e3= expr_list )? RIGHT_PARETHESIS for_statement -> ^( FOR_T ( $e1)? ^( CONDITION ( $e2)? ) ^( ITERATE ( $e3)? ) ( for_statement )? ) | SWITCH_T LEFT_PARETHESIS expression RIGHT_PARETHESIS switch_case_list -> ^( SWITCH_T ^( CONDITION expression ) switch_case_list ) | BREAK_T ( expression )? SEMI_COLON -> ^( BREAK_T ( expression )? ) | CONTINUE_T ( expression )? SEMI_COLON -> ^( CONTINUE_T ( expression )? ) | RETURN_T ( expression )? SEMI_COLON -> ^( RETURN_T ( expression )? ) | GLOBAL_T variable_list SEMI_COLON -> ^( GLOBAL_T variable_list ) | STATIC_T static_var_list SEMI_COLON -> ^( STATIC_T static_var_list ) | ECHO_T expr_list SEMI_COLON -> ^( ECHO_T expr_list ) | expression SEMI_COLON | FOREACH_T LEFT_PARETHESIS expression AS_T foreach_variable ( ARROW_T foreach_variable )? RIGHT_PARETHESIS foreach_statement -> ^( FOREACH_T ^( AS_T expression foreach_variable ( foreach_variable )? ) foreach_statement ) | DECLARE_T LEFT_PARETHESIS directive RIGHT_PARETHESIS declare_statement -> ^( DECLARE_T directive ( declare_statement )? ) | SEMI_COLON -> ^( EMPTYSTATEMENT SEMI_COLON ) | TRY_T LEFT_BRACKET top_statement RIGHT_BRACKET ( catch_branch )+ -> ^( TRY_T ^( BLOCK top_statement ) ( catch_branch )+ ) | THROW_T expression SEMI_COLON -> ^( THROW_T expression ) | USE_T use_filename SEMI_COLON -> ^( USE_T use_filename ) | INCLUDE_T LEFT_PARETHESIS expression RIGHT_PARETHESIS SEMI_COLON -> ^( INCLUDE_T expression ) | INCLUDE_ONCE_T LEFT_PARETHESIS expression RIGHT_PARETHESIS SEMI_COLON -> ^( INCLUDE_ONCE_T expression ) )
            int alt34=21;
            switch ( input.LA(1) ) {
            case LEFT_BRACKET:
                {
                alt34=1;
                }
                break;
            case IF_T:
                {
                alt34=2;
                }
                break;
            case WHILE_T:
                {
                alt34=3;
                }
                break;
            case DO_T:
                {
                alt34=4;
                }
                break;
            case FOR_T:
                {
                alt34=5;
                }
                break;
            case SWITCH_T:
                {
                alt34=6;
                }
                break;
            case BREAK_T:
                {
                alt34=7;
                }
                break;
            case CONTINUE_T:
                {
                alt34=8;
                }
                break;
            case RETURN_T:
                {
                alt34=9;
                }
                break;
            case GLOBAL_T:
                {
                alt34=10;
                }
                break;
            case STATIC_T:
                {
                alt34=11;
                }
                break;
            case ECHO_T:
                {
                alt34=12;
                }
                break;
            case LEFT_PARETHESIS:
            case IDENTIFIER:
            case FUNCTION_T:
            case REF_T:
            case STRINGLITERAL:
            case PLUS_T:
            case MINUS_T:
            case UNSET_T:
            case CLONE_T:
            case TILDA_T:
            case EXC_NOT_T:
            case PLUS_PLUS_T:
            case MINUS_MINUS_T:
            case AT_T:
            case LIST_T:
            case NEW_T:
            case EXIT_T:
            case BACKTRICKLITERAL:
            case DOLLAR_T:
            case INTLITERAL:
            case FLOATLITERAL:
            case DOUBLELITERRAL:
            case 179:
            case 180:
            case 181:
            case 182:
            case 183:
            case 184:
            case 185:
                {
                alt34=13;
                }
                break;
            case FOREACH_T:
                {
                alt34=14;
                }
                break;
            case DECLARE_T:
                {
                alt34=15;
                }
                break;
            case SEMI_COLON:
                {
                alt34=16;
                }
                break;
            case TRY_T:
                {
                alt34=17;
                }
                break;
            case THROW_T:
                {
                alt34=18;
                }
                break;
            case USE_T:
                {
                alt34=19;
                }
                break;
            case INCLUDE_T:
                {
                alt34=20;
                }
                break;
            case INCLUDE_ONCE_T:
                {
                alt34=21;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 34, 0, input);

                throw nvae;
            }

            switch (alt34) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:289:5: block
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_block_in_topStatement1029);
                    block73=block();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, block73.getTree());

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:290:5: if_stat
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_if_stat_in_topStatement1035);
                    if_stat74=if_stat();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, if_stat74.getTree());

                    }
                    break;
                case 3 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:291:5: WHILE_T LEFT_PARETHESIS expression RIGHT_PARETHESIS while_statement
                    {
                    WHILE_T75=(Token)match(input,WHILE_T,FOLLOW_WHILE_T_in_topStatement1041); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_WHILE_T.add(WHILE_T75);

                    LEFT_PARETHESIS76=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_topStatement1043); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS76);

                    pushFollow(FOLLOW_expression_in_topStatement1045);
                    expression77=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_expression.add(expression77.getTree());
                    RIGHT_PARETHESIS78=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_topStatement1047); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS78);

                    pushFollow(FOLLOW_while_statement_in_topStatement1049);
                    while_statement79=while_statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_while_statement.add(while_statement79.getTree());
                    if ( state.backtracking==0 ) {

                          startIndex = ((CommonToken)WHILE_T75).getStartIndex();
                          endIndex = ((CommonToken)(while_statement79!=null?((Token)while_statement79.stop):null)).getStopIndex();
                        
                    }


                    // AST REWRITE
                    // elements: while_statement, WHILE_T, expression
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 296:5: -> ^( WHILE_T ^( CONDITION expression ) while_statement )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:296:9: ^( WHILE_T ^( CONDITION expression ) while_statement )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_WHILE_T.nextNode(), root_1);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:296:19: ^( CONDITION expression )
                        {
                        SLAST root_2 = (SLAST)adaptor.nil();
                        root_2 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(CONDITION, "CONDITION"), root_2);

                        adaptor.addChild(root_2, stream_expression.nextTree());

                        adaptor.addChild(root_1, root_2);
                        }
                        adaptor.addChild(root_1, stream_while_statement.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 4 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:297:5: DO_T statement WHILE_T LEFT_PARETHESIS expression RIGHT_PARETHESIS SEMI_COLON
                    {
                    DO_T80=(Token)match(input,DO_T,FOLLOW_DO_T_in_topStatement1082); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_DO_T.add(DO_T80);

                    pushFollow(FOLLOW_statement_in_topStatement1084);
                    statement81=statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_statement.add(statement81.getTree());
                    WHILE_T82=(Token)match(input,WHILE_T,FOLLOW_WHILE_T_in_topStatement1086); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_WHILE_T.add(WHILE_T82);

                    LEFT_PARETHESIS83=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_topStatement1088); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS83);

                    pushFollow(FOLLOW_expression_in_topStatement1090);
                    expression84=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_expression.add(expression84.getTree());
                    RIGHT_PARETHESIS85=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_topStatement1092); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS85);

                    SEMI_COLON86=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_topStatement1094); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON86);

                    if ( state.backtracking==0 ) {

                          startIndex = ((CommonToken)DO_T80).getStartIndex();
                          endIndex = ((CommonToken)SEMI_COLON86).getStartIndex();
                        
                    }


                    // AST REWRITE
                    // elements: expression, DO_T, statement
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 302:5: -> ^( DO_T ^( CONDITION expression ) statement )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:302:9: ^( DO_T ^( CONDITION expression ) statement )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_DO_T.nextNode(), root_1);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:302:16: ^( CONDITION expression )
                        {
                        SLAST root_2 = (SLAST)adaptor.nil();
                        root_2 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(CONDITION, "CONDITION"), root_2);

                        adaptor.addChild(root_2, stream_expression.nextTree());

                        adaptor.addChild(root_1, root_2);
                        }
                        adaptor.addChild(root_1, stream_statement.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 5 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:303:5: FOR_T LEFT_PARETHESIS (e1= expr_list )? SEMI_COLON (e2= expr_list )? SEMI_COLON (e3= expr_list )? RIGHT_PARETHESIS for_statement
                    {
                    FOR_T87=(Token)match(input,FOR_T,FOLLOW_FOR_T_in_topStatement1124); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_FOR_T.add(FOR_T87);

                    LEFT_PARETHESIS88=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_topStatement1126); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS88);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:303:29: (e1= expr_list )?
                    int alt26=2;
                    int LA26_0 = input.LA(1);

                    if ( (LA26_0==LEFT_PARETHESIS||LA26_0==IDENTIFIER||(LA26_0>=FUNCTION_T && LA26_0<=REF_T)||LA26_0==STRINGLITERAL||(LA26_0>=PLUS_T && LA26_0<=MINUS_T)||(LA26_0>=UNSET_T && LA26_0<=MINUS_MINUS_T)||(LA26_0>=AT_T && LA26_0<=BACKTRICKLITERAL)||(LA26_0>=DOLLAR_T && LA26_0<=DOUBLELITERRAL)||(LA26_0>=179 && LA26_0<=185)) ) {
                        alt26=1;
                    }
                    switch (alt26) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:303:29: e1= expr_list
                            {
                            pushFollow(FOLLOW_expr_list_in_topStatement1130);
                            e1=expr_list();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_expr_list.add(e1.getTree());

                            }
                            break;

                    }

                    SEMI_COLON89=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_topStatement1133); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON89);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:303:54: (e2= expr_list )?
                    int alt27=2;
                    int LA27_0 = input.LA(1);

                    if ( (LA27_0==LEFT_PARETHESIS||LA27_0==IDENTIFIER||(LA27_0>=FUNCTION_T && LA27_0<=REF_T)||LA27_0==STRINGLITERAL||(LA27_0>=PLUS_T && LA27_0<=MINUS_T)||(LA27_0>=UNSET_T && LA27_0<=MINUS_MINUS_T)||(LA27_0>=AT_T && LA27_0<=BACKTRICKLITERAL)||(LA27_0>=DOLLAR_T && LA27_0<=DOUBLELITERRAL)||(LA27_0>=179 && LA27_0<=185)) ) {
                        alt27=1;
                    }
                    switch (alt27) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:303:54: e2= expr_list
                            {
                            pushFollow(FOLLOW_expr_list_in_topStatement1137);
                            e2=expr_list();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_expr_list.add(e2.getTree());

                            }
                            break;

                    }

                    SEMI_COLON90=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_topStatement1140); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON90);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:303:79: (e3= expr_list )?
                    int alt28=2;
                    int LA28_0 = input.LA(1);

                    if ( (LA28_0==LEFT_PARETHESIS||LA28_0==IDENTIFIER||(LA28_0>=FUNCTION_T && LA28_0<=REF_T)||LA28_0==STRINGLITERAL||(LA28_0>=PLUS_T && LA28_0<=MINUS_T)||(LA28_0>=UNSET_T && LA28_0<=MINUS_MINUS_T)||(LA28_0>=AT_T && LA28_0<=BACKTRICKLITERAL)||(LA28_0>=DOLLAR_T && LA28_0<=DOUBLELITERRAL)||(LA28_0>=179 && LA28_0<=185)) ) {
                        alt28=1;
                    }
                    switch (alt28) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:303:79: e3= expr_list
                            {
                            pushFollow(FOLLOW_expr_list_in_topStatement1144);
                            e3=expr_list();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_expr_list.add(e3.getTree());

                            }
                            break;

                    }

                    RIGHT_PARETHESIS91=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_topStatement1147); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS91);

                    pushFollow(FOLLOW_for_statement_in_topStatement1149);
                    for_statement92=for_statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_for_statement.add(for_statement92.getTree());
                    if ( state.backtracking==0 ) {

                          startIndex = ((CommonToken)FOR_T87).getStartIndex();
                          endIndex = ((CommonToken)RIGHT_PARETHESIS91).getStopIndex();
                          if ((for_statement92!=null?input.toString(for_statement92.start,for_statement92.stop):null) != null) {
                            endIndex = ((CommonToken)(for_statement92!=null?((Token)for_statement92.stop):null)).getStopIndex();
                          }
                        
                    }


                    // AST REWRITE
                    // elements: e2, for_statement, e3, FOR_T, e1
                    // token labels: 
                    // rule labels: e3, retval, e1, e2
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_e3=new RewriteRuleSubtreeStream(adaptor,"rule e3",e3!=null?e3.tree:null);
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
                    RewriteRuleSubtreeStream stream_e1=new RewriteRuleSubtreeStream(adaptor,"rule e1",e1!=null?e1.tree:null);
                    RewriteRuleSubtreeStream stream_e2=new RewriteRuleSubtreeStream(adaptor,"rule e2",e2!=null?e2.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 311:5: -> ^( FOR_T ( $e1)? ^( CONDITION ( $e2)? ) ^( ITERATE ( $e3)? ) ( for_statement )? )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:311:9: ^( FOR_T ( $e1)? ^( CONDITION ( $e2)? ) ^( ITERATE ( $e3)? ) ( for_statement )? )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_FOR_T.nextNode(), root_1);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:311:17: ( $e1)?
                        if ( stream_e1.hasNext() ) {
                            adaptor.addChild(root_1, stream_e1.nextTree());

                        }
                        stream_e1.reset();
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:311:22: ^( CONDITION ( $e2)? )
                        {
                        SLAST root_2 = (SLAST)adaptor.nil();
                        root_2 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(CONDITION, "CONDITION"), root_2);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:311:34: ( $e2)?
                        if ( stream_e2.hasNext() ) {
                            adaptor.addChild(root_2, stream_e2.nextTree());

                        }
                        stream_e2.reset();

                        adaptor.addChild(root_1, root_2);
                        }
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:311:40: ^( ITERATE ( $e3)? )
                        {
                        SLAST root_2 = (SLAST)adaptor.nil();
                        root_2 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(ITERATE, "ITERATE"), root_2);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:311:50: ( $e3)?
                        if ( stream_e3.hasNext() ) {
                            adaptor.addChild(root_2, stream_e3.nextTree());

                        }
                        stream_e3.reset();

                        adaptor.addChild(root_1, root_2);
                        }
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:311:56: ( for_statement )?
                        if ( stream_for_statement.hasNext() ) {
                            adaptor.addChild(root_1, stream_for_statement.nextTree());

                        }
                        stream_for_statement.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 6 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:312:5: SWITCH_T LEFT_PARETHESIS expression RIGHT_PARETHESIS switch_case_list
                    {
                    SWITCH_T93=(Token)match(input,SWITCH_T,FOLLOW_SWITCH_T_in_topStatement1193); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SWITCH_T.add(SWITCH_T93);

                    LEFT_PARETHESIS94=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_topStatement1195); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS94);

                    pushFollow(FOLLOW_expression_in_topStatement1197);
                    expression95=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_expression.add(expression95.getTree());
                    RIGHT_PARETHESIS96=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_topStatement1199); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS96);

                    pushFollow(FOLLOW_switch_case_list_in_topStatement1201);
                    switch_case_list97=switch_case_list();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_switch_case_list.add(switch_case_list97.getTree());
                    if ( state.backtracking==0 ) {

                          startIndex = ((CommonToken)SWITCH_T93).getStartIndex();
                          endIndex = ((CommonToken)(switch_case_list97!=null?((Token)switch_case_list97.stop):null)).getStopIndex();
                        
                    }


                    // AST REWRITE
                    // elements: switch_case_list, SWITCH_T, expression
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 317:5: -> ^( SWITCH_T ^( CONDITION expression ) switch_case_list )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:317:9: ^( SWITCH_T ^( CONDITION expression ) switch_case_list )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_SWITCH_T.nextNode(), root_1);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:317:20: ^( CONDITION expression )
                        {
                        SLAST root_2 = (SLAST)adaptor.nil();
                        root_2 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(CONDITION, "CONDITION"), root_2);

                        adaptor.addChild(root_2, stream_expression.nextTree());

                        adaptor.addChild(root_1, root_2);
                        }
                        adaptor.addChild(root_1, stream_switch_case_list.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 7 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:318:5: BREAK_T ( expression )? SEMI_COLON
                    {
                    BREAK_T98=(Token)match(input,BREAK_T,FOLLOW_BREAK_T_in_topStatement1230); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_BREAK_T.add(BREAK_T98);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:318:13: ( expression )?
                    int alt29=2;
                    int LA29_0 = input.LA(1);

                    if ( (LA29_0==LEFT_PARETHESIS||LA29_0==IDENTIFIER||(LA29_0>=FUNCTION_T && LA29_0<=REF_T)||LA29_0==STRINGLITERAL||(LA29_0>=PLUS_T && LA29_0<=MINUS_T)||(LA29_0>=UNSET_T && LA29_0<=MINUS_MINUS_T)||(LA29_0>=AT_T && LA29_0<=BACKTRICKLITERAL)||(LA29_0>=DOLLAR_T && LA29_0<=DOUBLELITERRAL)||(LA29_0>=179 && LA29_0<=185)) ) {
                        alt29=1;
                    }
                    switch (alt29) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:318:13: expression
                            {
                            pushFollow(FOLLOW_expression_in_topStatement1232);
                            expression99=expression();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_expression.add(expression99.getTree());

                            }
                            break;

                    }

                    SEMI_COLON100=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_topStatement1235); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON100);

                    if ( state.backtracking==0 ) {

                          startIndex = ((CommonToken)BREAK_T98).getStartIndex();
                          endIndex = ((CommonToken)SEMI_COLON100).getStartIndex();
                        
                    }


                    // AST REWRITE
                    // elements: BREAK_T, expression
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 323:5: -> ^( BREAK_T ( expression )? )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:323:9: ^( BREAK_T ( expression )? )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_BREAK_T.nextNode(), root_1);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:323:19: ( expression )?
                        if ( stream_expression.hasNext() ) {
                            adaptor.addChild(root_1, stream_expression.nextTree());

                        }
                        stream_expression.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 8 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:324:5: CONTINUE_T ( expression )? SEMI_COLON
                    {
                    CONTINUE_T101=(Token)match(input,CONTINUE_T,FOLLOW_CONTINUE_T_in_topStatement1259); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_CONTINUE_T.add(CONTINUE_T101);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:324:16: ( expression )?
                    int alt30=2;
                    int LA30_0 = input.LA(1);

                    if ( (LA30_0==LEFT_PARETHESIS||LA30_0==IDENTIFIER||(LA30_0>=FUNCTION_T && LA30_0<=REF_T)||LA30_0==STRINGLITERAL||(LA30_0>=PLUS_T && LA30_0<=MINUS_T)||(LA30_0>=UNSET_T && LA30_0<=MINUS_MINUS_T)||(LA30_0>=AT_T && LA30_0<=BACKTRICKLITERAL)||(LA30_0>=DOLLAR_T && LA30_0<=DOUBLELITERRAL)||(LA30_0>=179 && LA30_0<=185)) ) {
                        alt30=1;
                    }
                    switch (alt30) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:324:16: expression
                            {
                            pushFollow(FOLLOW_expression_in_topStatement1261);
                            expression102=expression();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_expression.add(expression102.getTree());

                            }
                            break;

                    }

                    SEMI_COLON103=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_topStatement1264); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON103);

                    if ( state.backtracking==0 ) {

                          startIndex = ((CommonToken)CONTINUE_T101).getStartIndex();
                          endIndex = ((CommonToken)SEMI_COLON103).getStartIndex();
                        
                    }


                    // AST REWRITE
                    // elements: expression, CONTINUE_T
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 329:5: -> ^( CONTINUE_T ( expression )? )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:329:9: ^( CONTINUE_T ( expression )? )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_CONTINUE_T.nextNode(), root_1);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:329:22: ( expression )?
                        if ( stream_expression.hasNext() ) {
                            adaptor.addChild(root_1, stream_expression.nextTree());

                        }
                        stream_expression.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 9 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:330:5: RETURN_T ( expression )? SEMI_COLON
                    {
                    RETURN_T104=(Token)match(input,RETURN_T,FOLLOW_RETURN_T_in_topStatement1300); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RETURN_T.add(RETURN_T104);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:330:14: ( expression )?
                    int alt31=2;
                    int LA31_0 = input.LA(1);

                    if ( (LA31_0==LEFT_PARETHESIS||LA31_0==IDENTIFIER||(LA31_0>=FUNCTION_T && LA31_0<=REF_T)||LA31_0==STRINGLITERAL||(LA31_0>=PLUS_T && LA31_0<=MINUS_T)||(LA31_0>=UNSET_T && LA31_0<=MINUS_MINUS_T)||(LA31_0>=AT_T && LA31_0<=BACKTRICKLITERAL)||(LA31_0>=DOLLAR_T && LA31_0<=DOUBLELITERRAL)||(LA31_0>=179 && LA31_0<=185)) ) {
                        alt31=1;
                    }
                    switch (alt31) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:330:14: expression
                            {
                            pushFollow(FOLLOW_expression_in_topStatement1302);
                            expression105=expression();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_expression.add(expression105.getTree());

                            }
                            break;

                    }

                    SEMI_COLON106=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_topStatement1305); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON106);

                    if ( state.backtracking==0 ) {

                          startIndex = ((CommonToken)RETURN_T104).getStartIndex();
                          endIndex = ((CommonToken)SEMI_COLON106).getStartIndex();
                        
                    }


                    // AST REWRITE
                    // elements: RETURN_T, expression
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 335:5: -> ^( RETURN_T ( expression )? )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:335:9: ^( RETURN_T ( expression )? )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_RETURN_T.nextNode(), root_1);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:335:20: ( expression )?
                        if ( stream_expression.hasNext() ) {
                            adaptor.addChild(root_1, stream_expression.nextTree());

                        }
                        stream_expression.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 10 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:336:5: GLOBAL_T variable_list SEMI_COLON
                    {
                    GLOBAL_T107=(Token)match(input,GLOBAL_T,FOLLOW_GLOBAL_T_in_topStatement1344); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_GLOBAL_T.add(GLOBAL_T107);

                    pushFollow(FOLLOW_variable_list_in_topStatement1346);
                    variable_list108=variable_list();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_variable_list.add(variable_list108.getTree());
                    SEMI_COLON109=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_topStatement1348); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON109);

                    if ( state.backtracking==0 ) {

                          startIndex = ((CommonToken)GLOBAL_T107).getStartIndex();
                          endIndex = ((CommonToken)SEMI_COLON109).getStartIndex();
                        
                    }


                    // AST REWRITE
                    // elements: variable_list, GLOBAL_T
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 341:5: -> ^( GLOBAL_T variable_list )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:341:9: ^( GLOBAL_T variable_list )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_GLOBAL_T.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_variable_list.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 11 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:342:5: STATIC_T static_var_list SEMI_COLON
                    {
                    STATIC_T110=(Token)match(input,STATIC_T,FOLLOW_STATIC_T_in_topStatement1386); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_STATIC_T.add(STATIC_T110);

                    pushFollow(FOLLOW_static_var_list_in_topStatement1388);
                    static_var_list111=static_var_list();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_static_var_list.add(static_var_list111.getTree());
                    SEMI_COLON112=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_topStatement1390); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON112);

                    if ( state.backtracking==0 ) {

                          startIndex = ((CommonToken)STATIC_T110).getStartIndex();
                          endIndex = ((CommonToken)SEMI_COLON112).getStartIndex();
                        
                    }


                    // AST REWRITE
                    // elements: STATIC_T, static_var_list
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 347:5: -> ^( STATIC_T static_var_list )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:347:9: ^( STATIC_T static_var_list )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_STATIC_T.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_static_var_list.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 12 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:348:5: ECHO_T expr_list SEMI_COLON
                    {
                    ECHO_T113=(Token)match(input,ECHO_T,FOLLOW_ECHO_T_in_topStatement1425); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_ECHO_T.add(ECHO_T113);

                    pushFollow(FOLLOW_expr_list_in_topStatement1427);
                    expr_list114=expr_list();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_expr_list.add(expr_list114.getTree());
                    SEMI_COLON115=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_topStatement1429); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON115);

                    if ( state.backtracking==0 ) {

                          startIndex = ((CommonToken)ECHO_T113).getStartIndex();
                          endIndex = ((CommonToken)SEMI_COLON115).getStartIndex();
                        
                    }


                    // AST REWRITE
                    // elements: expr_list, ECHO_T
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 353:5: -> ^( ECHO_T expr_list )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:353:9: ^( ECHO_T expr_list )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_ECHO_T.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_expr_list.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 13 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:354:5: expression SEMI_COLON
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_expression_in_topStatement1452);
                    expression116=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, expression116.getTree());
                    SEMI_COLON117=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_topStatement1454); if (state.failed) return retval;

                    }
                    break;
                case 14 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:355:5: FOREACH_T LEFT_PARETHESIS expression AS_T foreach_variable ( ARROW_T foreach_variable )? RIGHT_PARETHESIS foreach_statement
                    {
                    FOREACH_T118=(Token)match(input,FOREACH_T,FOLLOW_FOREACH_T_in_topStatement1461); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_FOREACH_T.add(FOREACH_T118);

                    LEFT_PARETHESIS119=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_topStatement1463); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS119);

                    pushFollow(FOLLOW_expression_in_topStatement1465);
                    expression120=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_expression.add(expression120.getTree());
                    AS_T121=(Token)match(input,AS_T,FOLLOW_AS_T_in_topStatement1467); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_AS_T.add(AS_T121);

                    pushFollow(FOLLOW_foreach_variable_in_topStatement1469);
                    foreach_variable122=foreach_variable();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_foreach_variable.add(foreach_variable122.getTree());
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:355:64: ( ARROW_T foreach_variable )?
                    int alt32=2;
                    int LA32_0 = input.LA(1);

                    if ( (LA32_0==ARROW_T) ) {
                        alt32=1;
                    }
                    switch (alt32) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:355:65: ARROW_T foreach_variable
                            {
                            ARROW_T123=(Token)match(input,ARROW_T,FOLLOW_ARROW_T_in_topStatement1472); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_ARROW_T.add(ARROW_T123);

                            pushFollow(FOLLOW_foreach_variable_in_topStatement1474);
                            foreach_variable124=foreach_variable();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_foreach_variable.add(foreach_variable124.getTree());

                            }
                            break;

                    }

                    RIGHT_PARETHESIS125=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_topStatement1478); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS125);

                    pushFollow(FOLLOW_foreach_statement_in_topStatement1488);
                    foreach_statement126=foreach_statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_foreach_statement.add(foreach_statement126.getTree());
                    if ( state.backtracking==0 ) {

                          startIndex = ((CommonToken)FOREACH_T118).getStartIndex();
                          endIndex = ((CommonToken)(foreach_statement126!=null?((Token)foreach_statement126.stop):null)).getStopIndex();
                        
                    }


                    // AST REWRITE
                    // elements: foreach_variable, AS_T, foreach_statement, FOREACH_T, foreach_variable, expression
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 361:6: -> ^( FOREACH_T ^( AS_T expression foreach_variable ( foreach_variable )? ) foreach_statement )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:361:9: ^( FOREACH_T ^( AS_T expression foreach_variable ( foreach_variable )? ) foreach_statement )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_FOREACH_T.nextNode(), root_1);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:361:21: ^( AS_T expression foreach_variable ( foreach_variable )? )
                        {
                        SLAST root_2 = (SLAST)adaptor.nil();
                        root_2 = (SLAST)adaptor.becomeRoot(stream_AS_T.nextNode(), root_2);

                        adaptor.addChild(root_2, stream_expression.nextTree());
                        adaptor.addChild(root_2, stream_foreach_variable.nextTree());
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:361:56: ( foreach_variable )?
                        if ( stream_foreach_variable.hasNext() ) {
                            adaptor.addChild(root_2, stream_foreach_variable.nextTree());

                        }
                        stream_foreach_variable.reset();

                        adaptor.addChild(root_1, root_2);
                        }
                        adaptor.addChild(root_1, stream_foreach_statement.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 15 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:362:5: DECLARE_T LEFT_PARETHESIS directive RIGHT_PARETHESIS declare_statement
                    {
                    DECLARE_T127=(Token)match(input,DECLARE_T,FOLLOW_DECLARE_T_in_topStatement1523); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_DECLARE_T.add(DECLARE_T127);

                    LEFT_PARETHESIS128=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_topStatement1525); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS128);

                    pushFollow(FOLLOW_directive_in_topStatement1527);
                    directive129=directive();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_directive.add(directive129.getTree());
                    RIGHT_PARETHESIS130=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_topStatement1529); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS130);

                    pushFollow(FOLLOW_declare_statement_in_topStatement1531);
                    declare_statement131=declare_statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_declare_statement.add(declare_statement131.getTree());
                    if ( state.backtracking==0 ) {

                          startIndex = ((CommonToken)DECLARE_T127).getStartIndex();
                          endIndex = ((CommonToken)(declare_statement131!=null?((Token)declare_statement131.stop):null)).getStopIndex();
                        
                    }


                    // AST REWRITE
                    // elements: directive, declare_statement, DECLARE_T
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 367:5: -> ^( DECLARE_T directive ( declare_statement )? )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:367:9: ^( DECLARE_T directive ( declare_statement )? )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_DECLARE_T.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_directive.nextTree());
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:367:31: ( declare_statement )?
                        if ( stream_declare_statement.hasNext() ) {
                            adaptor.addChild(root_1, stream_declare_statement.nextTree());

                        }
                        stream_declare_statement.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 16 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:368:5: SEMI_COLON
                    {
                    SEMI_COLON132=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_topStatement1557); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON132);



                    // AST REWRITE
                    // elements: SEMI_COLON
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 369:5: -> ^( EMPTYSTATEMENT SEMI_COLON )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:369:9: ^( EMPTYSTATEMENT SEMI_COLON )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(EMPTYSTATEMENT, "EMPTYSTATEMENT"), root_1);

                        adaptor.addChild(root_1, stream_SEMI_COLON.nextNode());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 17 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:370:5: TRY_T LEFT_BRACKET top_statement RIGHT_BRACKET ( catch_branch )+
                    {
                    TRY_T133=(Token)match(input,TRY_T,FOLLOW_TRY_T_in_topStatement1576); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_TRY_T.add(TRY_T133);

                    LEFT_BRACKET134=(Token)match(input,LEFT_BRACKET,FOLLOW_LEFT_BRACKET_in_topStatement1578); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LEFT_BRACKET.add(LEFT_BRACKET134);

                    pushFollow(FOLLOW_top_statement_in_topStatement1580);
                    top_statement135=top_statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_top_statement.add(top_statement135.getTree());
                    RIGHT_BRACKET136=(Token)match(input,RIGHT_BRACKET,FOLLOW_RIGHT_BRACKET_in_topStatement1582); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RIGHT_BRACKET.add(RIGHT_BRACKET136);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:370:52: ( catch_branch )+
                    int cnt33=0;
                    loop33:
                    do {
                        int alt33=2;
                        int LA33_0 = input.LA(1);

                        if ( (LA33_0==CATCH_T) ) {
                            alt33=1;
                        }


                        switch (alt33) {
                    	case 1 :
                    	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:370:52: catch_branch
                    	    {
                    	    pushFollow(FOLLOW_catch_branch_in_topStatement1584);
                    	    catch_branch137=catch_branch();

                    	    state._fsp--;
                    	    if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) stream_catch_branch.add(catch_branch137.getTree());

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt33 >= 1 ) break loop33;
                    	    if (state.backtracking>0) {state.failed=true; return retval;}
                                EarlyExitException eee =
                                    new EarlyExitException(33, input);
                                throw eee;
                        }
                        cnt33++;
                    } while (true);

                    if ( state.backtracking==0 ) {

                          startIndex = ((CommonToken)TRY_T133).getStartIndex();
                          endIndex = ((CommonToken)(catch_branch137!=null?((Token)catch_branch137.stop):null)).getStopIndex();
                        
                    }


                    // AST REWRITE
                    // elements: TRY_T, catch_branch, top_statement
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 375:5: -> ^( TRY_T ^( BLOCK top_statement ) ( catch_branch )+ )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:375:9: ^( TRY_T ^( BLOCK top_statement ) ( catch_branch )+ )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_TRY_T.nextNode(), root_1);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:375:17: ^( BLOCK top_statement )
                        {
                        SLAST root_2 = (SLAST)adaptor.nil();
                        root_2 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(BLOCK, "BLOCK"), root_2);

                        adaptor.addChild(root_2, stream_top_statement.nextTree());

                        adaptor.addChild(root_1, root_2);
                        }
                        if ( !(stream_catch_branch.hasNext()) ) {
                            throw new RewriteEarlyExitException();
                        }
                        while ( stream_catch_branch.hasNext() ) {
                            adaptor.addChild(root_1, stream_catch_branch.nextTree());

                        }
                        stream_catch_branch.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 18 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:376:5: THROW_T expression SEMI_COLON
                    {
                    THROW_T138=(Token)match(input,THROW_T,FOLLOW_THROW_T_in_topStatement1615); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_THROW_T.add(THROW_T138);

                    pushFollow(FOLLOW_expression_in_topStatement1617);
                    expression139=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_expression.add(expression139.getTree());
                    SEMI_COLON140=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_topStatement1619); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON140);

                    if ( state.backtracking==0 ) {

                          startIndex = ((CommonToken)THROW_T138).getStartIndex();
                          endIndex = ((CommonToken)SEMI_COLON140).getStartIndex();
                        
                    }


                    // AST REWRITE
                    // elements: THROW_T, expression
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 381:5: -> ^( THROW_T expression )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:381:9: ^( THROW_T expression )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_THROW_T.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_expression.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 19 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:382:5: USE_T use_filename SEMI_COLON
                    {
                    USE_T141=(Token)match(input,USE_T,FOLLOW_USE_T_in_topStatement1656); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_USE_T.add(USE_T141);

                    pushFollow(FOLLOW_use_filename_in_topStatement1658);
                    use_filename142=use_filename();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_use_filename.add(use_filename142.getTree());
                    SEMI_COLON143=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_topStatement1660); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON143);

                    if ( state.backtracking==0 ) {

                          startIndex = ((CommonToken)USE_T141).getStartIndex();
                          endIndex = ((CommonToken)SEMI_COLON143).getStartIndex();
                        
                    }


                    // AST REWRITE
                    // elements: USE_T, use_filename
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 387:5: -> ^( USE_T use_filename )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:387:9: ^( USE_T use_filename )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_USE_T.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_use_filename.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 20 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:388:5: INCLUDE_T LEFT_PARETHESIS expression RIGHT_PARETHESIS SEMI_COLON
                    {
                    INCLUDE_T144=(Token)match(input,INCLUDE_T,FOLLOW_INCLUDE_T_in_topStatement1697); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_INCLUDE_T.add(INCLUDE_T144);

                    LEFT_PARETHESIS145=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_topStatement1699); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS145);

                    pushFollow(FOLLOW_expression_in_topStatement1701);
                    expression146=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_expression.add(expression146.getTree());
                    RIGHT_PARETHESIS147=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_topStatement1703); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS147);

                    SEMI_COLON148=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_topStatement1705); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON148);

                    if ( state.backtracking==0 ) {

                          startIndex = ((CommonToken)INCLUDE_T144).getStartIndex();
                          endIndex = ((CommonToken)SEMI_COLON148).getStartIndex();
                        
                    }


                    // AST REWRITE
                    // elements: INCLUDE_T, expression
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 393:5: -> ^( INCLUDE_T expression )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:393:9: ^( INCLUDE_T expression )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_INCLUDE_T.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_expression.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 21 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:394:5: INCLUDE_ONCE_T LEFT_PARETHESIS expression RIGHT_PARETHESIS SEMI_COLON
                    {
                    INCLUDE_ONCE_T149=(Token)match(input,INCLUDE_ONCE_T,FOLLOW_INCLUDE_ONCE_T_in_topStatement1728); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_INCLUDE_ONCE_T.add(INCLUDE_ONCE_T149);

                    LEFT_PARETHESIS150=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_topStatement1730); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS150);

                    pushFollow(FOLLOW_expression_in_topStatement1732);
                    expression151=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_expression.add(expression151.getTree());
                    RIGHT_PARETHESIS152=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_topStatement1734); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS152);

                    SEMI_COLON153=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_topStatement1736); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON153);

                    if ( state.backtracking==0 ) {

                          startIndex = ((CommonToken)INCLUDE_ONCE_T149).getStartIndex();
                          endIndex = ((CommonToken)SEMI_COLON153).getStartIndex();
                        
                    }


                    // AST REWRITE
                    // elements: expression, INCLUDE_ONCE_T
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 399:5: -> ^( INCLUDE_ONCE_T expression )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:399:9: ^( INCLUDE_ONCE_T expression )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_INCLUDE_ONCE_T.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_expression.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                if (ast != null) {
                  ast.setIndex(startIndex, endIndex);
                }

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "topStatement"

    public static class foreach_variable_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "foreach_variable"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:406:1: foreach_variable : ( REF_T )? variable ;
    public final CompilerAstParser.foreach_variable_return foreach_variable() throws RecognitionException {
        CompilerAstParser.foreach_variable_return retval = new CompilerAstParser.foreach_variable_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token REF_T154=null;
        CompilerAstParser.variable_return variable155 = null;


        SLAST REF_T154_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:409:3: ( ( REF_T )? variable )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:409:5: ( REF_T )? variable
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:409:5: ( REF_T )?
            int alt35=2;
            int LA35_0 = input.LA(1);

            if ( (LA35_0==REF_T) ) {
                alt35=1;
            }
            switch (alt35) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:409:5: REF_T
                    {
                    REF_T154=(Token)match(input,REF_T,FOLLOW_REF_T_in_foreach_variable1776); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    REF_T154_tree = (SLAST)adaptor.create(REF_T154);
                    adaptor.addChild(root_0, REF_T154_tree);
                    }

                    }
                    break;

            }

            pushFollow(FOLLOW_variable_in_foreach_variable1779);
            variable155=variable();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, variable155.getTree());

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "foreach_variable"

    public static class use_filename_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "use_filename"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:412:1: use_filename : ( STRINGLITERAL | LEFT_PARETHESIS STRINGLITERAL RIGHT_PARETHESIS );
    public final CompilerAstParser.use_filename_return use_filename() throws RecognitionException {
        CompilerAstParser.use_filename_return retval = new CompilerAstParser.use_filename_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token STRINGLITERAL156=null;
        Token LEFT_PARETHESIS157=null;
        Token STRINGLITERAL158=null;
        Token RIGHT_PARETHESIS159=null;

        SLAST STRINGLITERAL156_tree=null;
        SLAST LEFT_PARETHESIS157_tree=null;
        SLAST STRINGLITERAL158_tree=null;
        SLAST RIGHT_PARETHESIS159_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:413:3: ( STRINGLITERAL | LEFT_PARETHESIS STRINGLITERAL RIGHT_PARETHESIS )
            int alt36=2;
            int LA36_0 = input.LA(1);

            if ( (LA36_0==STRINGLITERAL) ) {
                alt36=1;
            }
            else if ( (LA36_0==LEFT_PARETHESIS) ) {
                alt36=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 36, 0, input);

                throw nvae;
            }
            switch (alt36) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:413:5: STRINGLITERAL
                    {
                    root_0 = (SLAST)adaptor.nil();

                    STRINGLITERAL156=(Token)match(input,STRINGLITERAL,FOLLOW_STRINGLITERAL_in_use_filename1794); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    STRINGLITERAL156_tree = (SLAST)adaptor.create(STRINGLITERAL156);
                    adaptor.addChild(root_0, STRINGLITERAL156_tree);
                    }

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:414:5: LEFT_PARETHESIS STRINGLITERAL RIGHT_PARETHESIS
                    {
                    root_0 = (SLAST)adaptor.nil();

                    LEFT_PARETHESIS157=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_use_filename1800); if (state.failed) return retval;
                    STRINGLITERAL158=(Token)match(input,STRINGLITERAL,FOLLOW_STRINGLITERAL_in_use_filename1803); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    STRINGLITERAL158_tree = (SLAST)adaptor.create(STRINGLITERAL158);
                    adaptor.addChild(root_0, STRINGLITERAL158_tree);
                    }
                    RIGHT_PARETHESIS159=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_use_filename1805); if (state.failed) return retval;

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "use_filename"

    public static class fully_qualified_class_name_list_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "fully_qualified_class_name_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:430:1: fully_qualified_class_name_list : fully_qualified_class_name ( ',' fully_qualified_class_name )* -> ( fully_qualified_class_name )+ ;
    public final CompilerAstParser.fully_qualified_class_name_list_return fully_qualified_class_name_list() throws RecognitionException {
        CompilerAstParser.fully_qualified_class_name_list_return retval = new CompilerAstParser.fully_qualified_class_name_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token char_literal161=null;
        CompilerAstParser.fully_qualified_class_name_return fully_qualified_class_name160 = null;

        CompilerAstParser.fully_qualified_class_name_return fully_qualified_class_name162 = null;


        SLAST char_literal161_tree=null;
        RewriteRuleTokenStream stream_COMMA_T=new RewriteRuleTokenStream(adaptor,"token COMMA_T");
        RewriteRuleSubtreeStream stream_fully_qualified_class_name=new RewriteRuleSubtreeStream(adaptor,"rule fully_qualified_class_name");
        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:431:3: ( fully_qualified_class_name ( ',' fully_qualified_class_name )* -> ( fully_qualified_class_name )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:431:5: fully_qualified_class_name ( ',' fully_qualified_class_name )*
            {
            pushFollow(FOLLOW_fully_qualified_class_name_in_fully_qualified_class_name_list1834);
            fully_qualified_class_name160=fully_qualified_class_name();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_fully_qualified_class_name.add(fully_qualified_class_name160.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:431:32: ( ',' fully_qualified_class_name )*
            loop37:
            do {
                int alt37=2;
                int LA37_0 = input.LA(1);

                if ( (LA37_0==COMMA_T) ) {
                    alt37=1;
                }


                switch (alt37) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:431:33: ',' fully_qualified_class_name
            	    {
            	    char_literal161=(Token)match(input,COMMA_T,FOLLOW_COMMA_T_in_fully_qualified_class_name_list1837); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_COMMA_T.add(char_literal161);

            	    pushFollow(FOLLOW_fully_qualified_class_name_in_fully_qualified_class_name_list1839);
            	    fully_qualified_class_name162=fully_qualified_class_name();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_fully_qualified_class_name.add(fully_qualified_class_name162.getTree());

            	    }
            	    break;

            	default :
            	    break loop37;
                }
            } while (true);



            // AST REWRITE
            // elements: fully_qualified_class_name
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 431:69: -> ( fully_qualified_class_name )+
            {
                if ( !(stream_fully_qualified_class_name.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_fully_qualified_class_name.hasNext() ) {
                    adaptor.addChild(root_0, stream_fully_qualified_class_name.nextTree());

                }
                stream_fully_qualified_class_name.reset();

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "fully_qualified_class_name_list"

    public static class fully_qualified_class_name_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "fully_qualified_class_name"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:434:1: fully_qualified_class_name : id1= IDENTIFIER ( DOMAIN_T id2= IDENTIFIER )* (d2= DOMAIN_T )? ;
    public final CompilerAstParser.fully_qualified_class_name_return fully_qualified_class_name() throws RecognitionException {
        CompilerAstParser.fully_qualified_class_name_return retval = new CompilerAstParser.fully_qualified_class_name_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token id1=null;
        Token id2=null;
        Token d2=null;
        Token DOMAIN_T163=null;

        SLAST id1_tree=null;
        SLAST id2_tree=null;
        SLAST d2_tree=null;
        SLAST DOMAIN_T163_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:444:3: (id1= IDENTIFIER ( DOMAIN_T id2= IDENTIFIER )* (d2= DOMAIN_T )? )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:444:5: id1= IDENTIFIER ( DOMAIN_T id2= IDENTIFIER )* (d2= DOMAIN_T )?
            {
            root_0 = (SLAST)adaptor.nil();

            id1=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_fully_qualified_class_name1875); if (state.failed) return retval;
            if ( state.backtracking==0 ) {
            id1_tree = (SLAST)adaptor.create(id1);
            adaptor.addChild(root_0, id1_tree);
            }
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:444:20: ( DOMAIN_T id2= IDENTIFIER )*
            loop38:
            do {
                int alt38=2;
                int LA38_0 = input.LA(1);

                if ( (LA38_0==DOMAIN_T) ) {
                    int LA38_1 = input.LA(2);

                    if ( (LA38_1==IDENTIFIER) ) {
                        alt38=1;
                    }


                }


                switch (alt38) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:444:21: DOMAIN_T id2= IDENTIFIER
            	    {
            	    DOMAIN_T163=(Token)match(input,DOMAIN_T,FOLLOW_DOMAIN_T_in_fully_qualified_class_name1878); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    DOMAIN_T163_tree = (SLAST)adaptor.create(DOMAIN_T163);
            	    root_0 = (SLAST)adaptor.becomeRoot(DOMAIN_T163_tree, root_0);
            	    }
            	    id2=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_fully_qualified_class_name1883); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    id2_tree = (SLAST)adaptor.create(id2);
            	    adaptor.addChild(root_0, id2_tree);
            	    }

            	    }
            	    break;

            	default :
            	    break loop38;
                }
            } while (true);

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:444:50: (d2= DOMAIN_T )?
            int alt39=2;
            int LA39_0 = input.LA(1);

            if ( (LA39_0==DOMAIN_T) ) {
                alt39=1;
            }
            switch (alt39) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:444:50: d2= DOMAIN_T
                    {
                    d2=(Token)match(input,DOMAIN_T,FOLLOW_DOMAIN_T_in_fully_qualified_class_name1889); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    d2_tree = (SLAST)adaptor.create(d2);
                    adaptor.addChild(root_0, d2_tree);
                    }

                    }
                    break;

            }

            if ( state.backtracking==0 ) {

                  token = (CommonToken)id1;
                  startIndex = token.getStartIndex();
                  endIndex = token.getStopIndex();
                  if ((d2!=null?d2.getText():null) != null) {
                    endIndex = ((CommonToken)d2).getStopIndex();
                  }
                  else if ((id2!=null?id2.getText():null) != null) {
                    endIndex = ((CommonToken)id2).getStopIndex();
                  }
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "fully_qualified_class_name"

    public static class static_array_pair_list_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "static_array_pair_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:458:1: static_array_pair_list : static_scalar_element ( COMMA_T static_scalar_element )* -> ( ^( SCALAR_ELEMENT static_scalar_element ) )+ ;
    public final CompilerAstParser.static_array_pair_list_return static_array_pair_list() throws RecognitionException {
        CompilerAstParser.static_array_pair_list_return retval = new CompilerAstParser.static_array_pair_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token COMMA_T165=null;
        CompilerAstParser.static_scalar_element_return static_scalar_element164 = null;

        CompilerAstParser.static_scalar_element_return static_scalar_element166 = null;


        SLAST COMMA_T165_tree=null;
        RewriteRuleTokenStream stream_COMMA_T=new RewriteRuleTokenStream(adaptor,"token COMMA_T");
        RewriteRuleSubtreeStream stream_static_scalar_element=new RewriteRuleSubtreeStream(adaptor,"rule static_scalar_element");
        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:459:3: ( static_scalar_element ( COMMA_T static_scalar_element )* -> ( ^( SCALAR_ELEMENT static_scalar_element ) )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:459:5: static_scalar_element ( COMMA_T static_scalar_element )*
            {
            pushFollow(FOLLOW_static_scalar_element_in_static_array_pair_list1910);
            static_scalar_element164=static_scalar_element();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_static_scalar_element.add(static_scalar_element164.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:459:27: ( COMMA_T static_scalar_element )*
            loop40:
            do {
                int alt40=2;
                int LA40_0 = input.LA(1);

                if ( (LA40_0==COMMA_T) ) {
                    alt40=1;
                }


                switch (alt40) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:459:28: COMMA_T static_scalar_element
            	    {
            	    COMMA_T165=(Token)match(input,COMMA_T,FOLLOW_COMMA_T_in_static_array_pair_list1913); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_COMMA_T.add(COMMA_T165);

            	    pushFollow(FOLLOW_static_scalar_element_in_static_array_pair_list1915);
            	    static_scalar_element166=static_scalar_element();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_static_scalar_element.add(static_scalar_element166.getTree());

            	    }
            	    break;

            	default :
            	    break loop40;
                }
            } while (true);



            // AST REWRITE
            // elements: static_scalar_element
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 459:61: -> ( ^( SCALAR_ELEMENT static_scalar_element ) )+
            {
                if ( !(stream_static_scalar_element.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_static_scalar_element.hasNext() ) {
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:459:65: ^( SCALAR_ELEMENT static_scalar_element )
                    {
                    SLAST root_1 = (SLAST)adaptor.nil();
                    root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(SCALAR_ELEMENT, "SCALAR_ELEMENT"), root_1);

                    adaptor.addChild(root_1, stream_static_scalar_element.nextTree());

                    adaptor.addChild(root_0, root_1);
                    }

                }
                stream_static_scalar_element.reset();

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "static_array_pair_list"

    public static class static_scalar_element_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "static_scalar_element"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:462:1: static_scalar_element : scalar ( ARROW_T scalar )? ;
    public final CompilerAstParser.static_scalar_element_return static_scalar_element() throws RecognitionException {
        CompilerAstParser.static_scalar_element_return retval = new CompilerAstParser.static_scalar_element_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token ARROW_T168=null;
        CompilerAstParser.scalar_return scalar167 = null;

        CompilerAstParser.scalar_return scalar169 = null;


        SLAST ARROW_T168_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:463:3: ( scalar ( ARROW_T scalar )? )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:463:5: scalar ( ARROW_T scalar )?
            {
            root_0 = (SLAST)adaptor.nil();

            pushFollow(FOLLOW_scalar_in_static_scalar_element1942);
            scalar167=scalar();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, scalar167.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:463:12: ( ARROW_T scalar )?
            int alt41=2;
            int LA41_0 = input.LA(1);

            if ( (LA41_0==ARROW_T) ) {
                alt41=1;
            }
            switch (alt41) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:463:13: ARROW_T scalar
                    {
                    ARROW_T168=(Token)match(input,ARROW_T,FOLLOW_ARROW_T_in_static_scalar_element1945); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    ARROW_T168_tree = (SLAST)adaptor.create(ARROW_T168);
                    root_0 = (SLAST)adaptor.becomeRoot(ARROW_T168_tree, root_0);
                    }
                    pushFollow(FOLLOW_scalar_in_static_scalar_element1948);
                    scalar169=scalar();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, scalar169.getTree());

                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "static_scalar_element"

    public static class static_var_list_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "static_var_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:466:1: static_var_list : static_var_element ( COMMA_T static_var_element )* -> ( static_var_element )+ ;
    public final CompilerAstParser.static_var_list_return static_var_list() throws RecognitionException {
        CompilerAstParser.static_var_list_return retval = new CompilerAstParser.static_var_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token COMMA_T171=null;
        CompilerAstParser.static_var_element_return static_var_element170 = null;

        CompilerAstParser.static_var_element_return static_var_element172 = null;


        SLAST COMMA_T171_tree=null;
        RewriteRuleTokenStream stream_COMMA_T=new RewriteRuleTokenStream(adaptor,"token COMMA_T");
        RewriteRuleSubtreeStream stream_static_var_element=new RewriteRuleSubtreeStream(adaptor,"rule static_var_element");
        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:467:3: ( static_var_element ( COMMA_T static_var_element )* -> ( static_var_element )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:467:5: static_var_element ( COMMA_T static_var_element )*
            {
            pushFollow(FOLLOW_static_var_element_in_static_var_list1965);
            static_var_element170=static_var_element();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_static_var_element.add(static_var_element170.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:467:24: ( COMMA_T static_var_element )*
            loop42:
            do {
                int alt42=2;
                int LA42_0 = input.LA(1);

                if ( (LA42_0==COMMA_T) ) {
                    alt42=1;
                }


                switch (alt42) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:467:25: COMMA_T static_var_element
            	    {
            	    COMMA_T171=(Token)match(input,COMMA_T,FOLLOW_COMMA_T_in_static_var_list1968); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_COMMA_T.add(COMMA_T171);

            	    pushFollow(FOLLOW_static_var_element_in_static_var_list1970);
            	    static_var_element172=static_var_element();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_static_var_element.add(static_var_element172.getTree());

            	    }
            	    break;

            	default :
            	    break loop42;
                }
            } while (true);



            // AST REWRITE
            // elements: static_var_element
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 467:55: -> ( static_var_element )+
            {
                if ( !(stream_static_var_element.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_static_var_element.hasNext() ) {
                    adaptor.addChild(root_0, stream_static_var_element.nextTree());

                }
                stream_static_var_element.reset();

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "static_var_list"

    public static class static_var_element_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "static_var_element"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:470:1: static_var_element : pure_variable ( EQUAL_T scalar )? ;
    public final CompilerAstParser.static_var_element_return static_var_element() throws RecognitionException {
        CompilerAstParser.static_var_element_return retval = new CompilerAstParser.static_var_element_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token EQUAL_T174=null;
        CompilerAstParser.pure_variable_return pure_variable173 = null;

        CompilerAstParser.scalar_return scalar175 = null;


        SLAST EQUAL_T174_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:480:3: ( pure_variable ( EQUAL_T scalar )? )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:480:5: pure_variable ( EQUAL_T scalar )?
            {
            root_0 = (SLAST)adaptor.nil();

            pushFollow(FOLLOW_pure_variable_in_static_var_element2002);
            pure_variable173=pure_variable();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, pure_variable173.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:480:19: ( EQUAL_T scalar )?
            int alt43=2;
            int LA43_0 = input.LA(1);

            if ( (LA43_0==EQUAL_T) ) {
                alt43=1;
            }
            switch (alt43) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:480:20: EQUAL_T scalar
                    {
                    EQUAL_T174=(Token)match(input,EQUAL_T,FOLLOW_EQUAL_T_in_static_var_element2005); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    EQUAL_T174_tree = (SLAST)adaptor.create(EQUAL_T174);
                    root_0 = (SLAST)adaptor.becomeRoot(EQUAL_T174_tree, root_0);
                    }
                    pushFollow(FOLLOW_scalar_in_static_var_element2008);
                    scalar175=scalar();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, scalar175.getTree());

                    }
                    break;

            }

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(pure_variable173!=null?((Token)pure_variable173.start):null);
                  startIndex = token.getStartIndex();
                  endIndex = token.getStopIndex();
                  if ((scalar175!=null?input.toString(scalar175.start,scalar175.stop):null) != null) {
                    endIndex = ((CommonToken)(scalar175!=null?((Token)scalar175.stop):null)).getStopIndex();
                  }
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "static_var_element"

    public static class if_stat_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "if_stat"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:491:1: if_stat : IF_T LEFT_PARETHESIS eIfCond= expression RIGHT_PARETHESIS (s1= statement ( options {k=1; backtrack=true; } : ELSEIF_T LEFT_PARETHESIS eElseCond= expression RIGHT_PARETHESIS s2= statement )* ( options {k=1; backtrack=true; } : ELSE_T s3= statement )? -> ^( IF_T ^( CONDITION $eIfCond) $s1 ( ^( ELSEIF_T ^( CONDITION $eElseCond) $s2) )* ( ^( ELSE_T $s3) )? ) | COLON_T ( inner_statement_list )? ( new_elseif_branch )* ( options {k=1; backtrack=true; } : ELSE_T COLON_T s4= statement )? ENDIF_T SEMI_COLON -> ^( IF_T ^( CONDITION $eIfCond) ( inner_statement_list )? ( new_elseif_branch )* ( ^( ELSE_T $s4) )? ) ) ;
    public final CompilerAstParser.if_stat_return if_stat() throws RecognitionException {
        CompilerAstParser.if_stat_return retval = new CompilerAstParser.if_stat_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token IF_T176=null;
        Token LEFT_PARETHESIS177=null;
        Token RIGHT_PARETHESIS178=null;
        Token ELSEIF_T179=null;
        Token LEFT_PARETHESIS180=null;
        Token RIGHT_PARETHESIS181=null;
        Token ELSE_T182=null;
        Token COLON_T183=null;
        Token ELSE_T186=null;
        Token COLON_T187=null;
        Token ENDIF_T188=null;
        Token SEMI_COLON189=null;
        CompilerAstParser.expression_return eIfCond = null;

        CompilerAstParser.statement_return s1 = null;

        CompilerAstParser.expression_return eElseCond = null;

        CompilerAstParser.statement_return s2 = null;

        CompilerAstParser.statement_return s3 = null;

        CompilerAstParser.statement_return s4 = null;

        CompilerAstParser.inner_statement_list_return inner_statement_list184 = null;

        CompilerAstParser.new_elseif_branch_return new_elseif_branch185 = null;


        SLAST IF_T176_tree=null;
        SLAST LEFT_PARETHESIS177_tree=null;
        SLAST RIGHT_PARETHESIS178_tree=null;
        SLAST ELSEIF_T179_tree=null;
        SLAST LEFT_PARETHESIS180_tree=null;
        SLAST RIGHT_PARETHESIS181_tree=null;
        SLAST ELSE_T182_tree=null;
        SLAST COLON_T183_tree=null;
        SLAST ELSE_T186_tree=null;
        SLAST COLON_T187_tree=null;
        SLAST ENDIF_T188_tree=null;
        SLAST SEMI_COLON189_tree=null;
        RewriteRuleTokenStream stream_LEFT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token LEFT_PARETHESIS");
        RewriteRuleTokenStream stream_SEMI_COLON=new RewriteRuleTokenStream(adaptor,"token SEMI_COLON");
        RewriteRuleTokenStream stream_COLON_T=new RewriteRuleTokenStream(adaptor,"token COLON_T");
        RewriteRuleTokenStream stream_IF_T=new RewriteRuleTokenStream(adaptor,"token IF_T");
        RewriteRuleTokenStream stream_ELSEIF_T=new RewriteRuleTokenStream(adaptor,"token ELSEIF_T");
        RewriteRuleTokenStream stream_ENDIF_T=new RewriteRuleTokenStream(adaptor,"token ENDIF_T");
        RewriteRuleTokenStream stream_RIGHT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token RIGHT_PARETHESIS");
        RewriteRuleTokenStream stream_ELSE_T=new RewriteRuleTokenStream(adaptor,"token ELSE_T");
        RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");
        RewriteRuleSubtreeStream stream_statement=new RewriteRuleSubtreeStream(adaptor,"rule statement");
        RewriteRuleSubtreeStream stream_inner_statement_list=new RewriteRuleSubtreeStream(adaptor,"rule inner_statement_list");
        RewriteRuleSubtreeStream stream_new_elseif_branch=new RewriteRuleSubtreeStream(adaptor,"rule new_elseif_branch");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:501:3: ( IF_T LEFT_PARETHESIS eIfCond= expression RIGHT_PARETHESIS (s1= statement ( options {k=1; backtrack=true; } : ELSEIF_T LEFT_PARETHESIS eElseCond= expression RIGHT_PARETHESIS s2= statement )* ( options {k=1; backtrack=true; } : ELSE_T s3= statement )? -> ^( IF_T ^( CONDITION $eIfCond) $s1 ( ^( ELSEIF_T ^( CONDITION $eElseCond) $s2) )* ( ^( ELSE_T $s3) )? ) | COLON_T ( inner_statement_list )? ( new_elseif_branch )* ( options {k=1; backtrack=true; } : ELSE_T COLON_T s4= statement )? ENDIF_T SEMI_COLON -> ^( IF_T ^( CONDITION $eIfCond) ( inner_statement_list )? ( new_elseif_branch )* ( ^( ELSE_T $s4) )? ) ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:501:5: IF_T LEFT_PARETHESIS eIfCond= expression RIGHT_PARETHESIS (s1= statement ( options {k=1; backtrack=true; } : ELSEIF_T LEFT_PARETHESIS eElseCond= expression RIGHT_PARETHESIS s2= statement )* ( options {k=1; backtrack=true; } : ELSE_T s3= statement )? -> ^( IF_T ^( CONDITION $eIfCond) $s1 ( ^( ELSEIF_T ^( CONDITION $eElseCond) $s2) )* ( ^( ELSE_T $s3) )? ) | COLON_T ( inner_statement_list )? ( new_elseif_branch )* ( options {k=1; backtrack=true; } : ELSE_T COLON_T s4= statement )? ENDIF_T SEMI_COLON -> ^( IF_T ^( CONDITION $eIfCond) ( inner_statement_list )? ( new_elseif_branch )* ( ^( ELSE_T $s4) )? ) )
            {
            IF_T176=(Token)match(input,IF_T,FOLLOW_IF_T_in_if_stat2039); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_IF_T.add(IF_T176);

            LEFT_PARETHESIS177=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_if_stat2041); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS177);

            pushFollow(FOLLOW_expression_in_if_stat2045);
            eIfCond=expression();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_expression.add(eIfCond.getTree());
            RIGHT_PARETHESIS178=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_if_stat2047); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS178);

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:502:5: (s1= statement ( options {k=1; backtrack=true; } : ELSEIF_T LEFT_PARETHESIS eElseCond= expression RIGHT_PARETHESIS s2= statement )* ( options {k=1; backtrack=true; } : ELSE_T s3= statement )? -> ^( IF_T ^( CONDITION $eIfCond) $s1 ( ^( ELSEIF_T ^( CONDITION $eElseCond) $s2) )* ( ^( ELSE_T $s3) )? ) | COLON_T ( inner_statement_list )? ( new_elseif_branch )* ( options {k=1; backtrack=true; } : ELSE_T COLON_T s4= statement )? ENDIF_T SEMI_COLON -> ^( IF_T ^( CONDITION $eIfCond) ( inner_statement_list )? ( new_elseif_branch )* ( ^( ELSE_T $s4) )? ) )
            int alt49=2;
            int LA49_0 = input.LA(1);

            if ( (LA49_0==LEFT_PARETHESIS||LA49_0==SEMI_COLON||LA49_0==IDENTIFIER||LA49_0==LEFT_BRACKET||(LA49_0>=FUNCTION_T && LA49_0<=REF_T)||(LA49_0>=WHILE_T && LA49_0<=FOREACH_T)||(LA49_0>=DECLARE_T && LA49_0<=STRINGLITERAL)||LA49_0==IF_T||(LA49_0>=PLUS_T && LA49_0<=MINUS_T)||(LA49_0>=UNSET_T && LA49_0<=MINUS_MINUS_T)||(LA49_0>=AT_T && LA49_0<=BACKTRICKLITERAL)||(LA49_0>=DOLLAR_T && LA49_0<=DOUBLELITERRAL)||(LA49_0>=179 && LA49_0<=185)) ) {
                alt49=1;
            }
            else if ( (LA49_0==COLON_T) ) {
                alt49=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 49, 0, input);

                throw nvae;
            }
            switch (alt49) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:503:7: s1= statement ( options {k=1; backtrack=true; } : ELSEIF_T LEFT_PARETHESIS eElseCond= expression RIGHT_PARETHESIS s2= statement )* ( options {k=1; backtrack=true; } : ELSE_T s3= statement )?
                    {
                    pushFollow(FOLLOW_statement_in_if_stat2063);
                    s1=statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_statement.add(s1.getTree());
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:503:20: ( options {k=1; backtrack=true; } : ELSEIF_T LEFT_PARETHESIS eElseCond= expression RIGHT_PARETHESIS s2= statement )*
                    loop44:
                    do {
                        int alt44=2;
                        alt44 = dfa44.predict(input);
                        switch (alt44) {
                    	case 1 :
                    	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:503:53: ELSEIF_T LEFT_PARETHESIS eElseCond= expression RIGHT_PARETHESIS s2= statement
                    	    {
                    	    ELSEIF_T179=(Token)match(input,ELSEIF_T,FOLLOW_ELSEIF_T_in_if_stat2079); if (state.failed) return retval; 
                    	    if ( state.backtracking==0 ) stream_ELSEIF_T.add(ELSEIF_T179);

                    	    LEFT_PARETHESIS180=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_if_stat2081); if (state.failed) return retval; 
                    	    if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS180);

                    	    pushFollow(FOLLOW_expression_in_if_stat2085);
                    	    eElseCond=expression();

                    	    state._fsp--;
                    	    if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) stream_expression.add(eElseCond.getTree());
                    	    RIGHT_PARETHESIS181=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_if_stat2087); if (state.failed) return retval; 
                    	    if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS181);

                    	    pushFollow(FOLLOW_statement_in_if_stat2091);
                    	    s2=statement();

                    	    state._fsp--;
                    	    if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) stream_statement.add(s2.getTree());

                    	    }
                    	    break;

                    	default :
                    	    break loop44;
                        }
                    } while (true);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:504:9: ( options {k=1; backtrack=true; } : ELSE_T s3= statement )?
                    int alt45=2;
                    alt45 = dfa45.predict(input);
                    switch (alt45) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:504:42: ELSE_T s3= statement
                            {
                            ELSE_T182=(Token)match(input,ELSE_T,FOLLOW_ELSE_T_in_if_stat2117); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_ELSE_T.add(ELSE_T182);

                            pushFollow(FOLLOW_statement_in_if_stat2121);
                            s3=statement();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_statement.add(s3.getTree());

                            }
                            break;

                    }

                    if ( state.backtracking==0 ) {

                              startIndex = ((CommonToken)IF_T176).getStartIndex();
                              endIndex = ((CommonToken)(s1!=null?((Token)s1.stop):null)).getStopIndex();
                              if ((s2!=null?input.toString(s2.start,s2.stop):null) != null) {
                                endIndex = ((CommonToken)(s2!=null?((Token)s2.stop):null)).getStopIndex();
                              }
                              if ((s3!=null?input.toString(s3.start,s3.stop):null) != null) {
                                endIndex = ((CommonToken)(s3!=null?((Token)s3.stop):null)).getStopIndex();
                              }
                           
                    }


                    // AST REWRITE
                    // elements: eIfCond, ELSEIF_T, s1, s2, eElseCond, s3, IF_T, ELSE_T
                    // token labels: 
                    // rule labels: retval, s2, s1, eIfCond, s3, eElseCond
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
                    RewriteRuleSubtreeStream stream_s2=new RewriteRuleSubtreeStream(adaptor,"rule s2",s2!=null?s2.tree:null);
                    RewriteRuleSubtreeStream stream_s1=new RewriteRuleSubtreeStream(adaptor,"rule s1",s1!=null?s1.tree:null);
                    RewriteRuleSubtreeStream stream_eIfCond=new RewriteRuleSubtreeStream(adaptor,"rule eIfCond",eIfCond!=null?eIfCond.tree:null);
                    RewriteRuleSubtreeStream stream_s3=new RewriteRuleSubtreeStream(adaptor,"rule s3",s3!=null?s3.tree:null);
                    RewriteRuleSubtreeStream stream_eElseCond=new RewriteRuleSubtreeStream(adaptor,"rule eElseCond",eElseCond!=null?eElseCond.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 515:7: -> ^( IF_T ^( CONDITION $eIfCond) $s1 ( ^( ELSEIF_T ^( CONDITION $eElseCond) $s2) )* ( ^( ELSE_T $s3) )? )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:515:11: ^( IF_T ^( CONDITION $eIfCond) $s1 ( ^( ELSEIF_T ^( CONDITION $eElseCond) $s2) )* ( ^( ELSE_T $s3) )? )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_IF_T.nextNode(), root_1);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:515:18: ^( CONDITION $eIfCond)
                        {
                        SLAST root_2 = (SLAST)adaptor.nil();
                        root_2 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(CONDITION, "CONDITION"), root_2);

                        adaptor.addChild(root_2, stream_eIfCond.nextTree());

                        adaptor.addChild(root_1, root_2);
                        }
                        adaptor.addChild(root_1, stream_s1.nextTree());
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:515:45: ( ^( ELSEIF_T ^( CONDITION $eElseCond) $s2) )*
                        while ( stream_ELSEIF_T.hasNext()||stream_s2.hasNext()||stream_eElseCond.hasNext() ) {
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:515:45: ^( ELSEIF_T ^( CONDITION $eElseCond) $s2)
                            {
                            SLAST root_2 = (SLAST)adaptor.nil();
                            root_2 = (SLAST)adaptor.becomeRoot(stream_ELSEIF_T.nextNode(), root_2);

                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:515:56: ^( CONDITION $eElseCond)
                            {
                            SLAST root_3 = (SLAST)adaptor.nil();
                            root_3 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(CONDITION, "CONDITION"), root_3);

                            adaptor.addChild(root_3, stream_eElseCond.nextTree());

                            adaptor.addChild(root_2, root_3);
                            }
                            adaptor.addChild(root_2, stream_s2.nextTree());

                            adaptor.addChild(root_1, root_2);
                            }

                        }
                        stream_ELSEIF_T.reset();
                        stream_s2.reset();
                        stream_eElseCond.reset();
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:515:86: ( ^( ELSE_T $s3) )?
                        if ( stream_s3.hasNext()||stream_ELSE_T.hasNext() ) {
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:515:86: ^( ELSE_T $s3)
                            {
                            SLAST root_2 = (SLAST)adaptor.nil();
                            root_2 = (SLAST)adaptor.becomeRoot(stream_ELSE_T.nextNode(), root_2);

                            adaptor.addChild(root_2, stream_s3.nextTree());

                            adaptor.addChild(root_1, root_2);
                            }

                        }
                        stream_s3.reset();
                        stream_ELSE_T.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:516:9: COLON_T ( inner_statement_list )? ( new_elseif_branch )* ( options {k=1; backtrack=true; } : ELSE_T COLON_T s4= statement )? ENDIF_T SEMI_COLON
                    {
                    COLON_T183=(Token)match(input,COLON_T,FOLLOW_COLON_T_in_if_stat2187); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_COLON_T.add(COLON_T183);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:516:17: ( inner_statement_list )?
                    int alt46=2;
                    int LA46_0 = input.LA(1);

                    if ( (LA46_0==LEFT_PARETHESIS||(LA46_0>=SEMI_COLON && LA46_0<=IDENTIFIER)||LA46_0==LEFT_BRACKET||(LA46_0>=INTERFACE_T && LA46_0<=REF_T)||(LA46_0>=WHILE_T && LA46_0<=FOREACH_T)||(LA46_0>=DECLARE_T && LA46_0<=STRINGLITERAL)||LA46_0==IF_T||(LA46_0>=PLUS_T && LA46_0<=MINUS_T)||(LA46_0>=UNSET_T && LA46_0<=MINUS_MINUS_T)||(LA46_0>=AT_T && LA46_0<=BACKTRICKLITERAL)||(LA46_0>=DOLLAR_T && LA46_0<=DOUBLELITERRAL)||(LA46_0>=164 && LA46_0<=166)||(LA46_0>=179 && LA46_0<=185)) ) {
                        alt46=1;
                    }
                    switch (alt46) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:516:17: inner_statement_list
                            {
                            pushFollow(FOLLOW_inner_statement_list_in_if_stat2189);
                            inner_statement_list184=inner_statement_list();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_inner_statement_list.add(inner_statement_list184.getTree());

                            }
                            break;

                    }

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:516:39: ( new_elseif_branch )*
                    loop47:
                    do {
                        int alt47=2;
                        int LA47_0 = input.LA(1);

                        if ( (LA47_0==ELSEIF_T) ) {
                            alt47=1;
                        }


                        switch (alt47) {
                    	case 1 :
                    	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:516:39: new_elseif_branch
                    	    {
                    	    pushFollow(FOLLOW_new_elseif_branch_in_if_stat2192);
                    	    new_elseif_branch185=new_elseif_branch();

                    	    state._fsp--;
                    	    if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) stream_new_elseif_branch.add(new_elseif_branch185.getTree());

                    	    }
                    	    break;

                    	default :
                    	    break loop47;
                        }
                    } while (true);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:516:58: ( options {k=1; backtrack=true; } : ELSE_T COLON_T s4= statement )?
                    int alt48=2;
                    int LA48_0 = input.LA(1);

                    if ( (LA48_0==ELSE_T) ) {
                        alt48=1;
                    }
                    switch (alt48) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:516:91: ELSE_T COLON_T s4= statement
                            {
                            ELSE_T186=(Token)match(input,ELSE_T,FOLLOW_ELSE_T_in_if_stat2209); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_ELSE_T.add(ELSE_T186);

                            COLON_T187=(Token)match(input,COLON_T,FOLLOW_COLON_T_in_if_stat2211); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_COLON_T.add(COLON_T187);

                            pushFollow(FOLLOW_statement_in_if_stat2215);
                            s4=statement();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_statement.add(s4.getTree());

                            }
                            break;

                    }

                    ENDIF_T188=(Token)match(input,ENDIF_T,FOLLOW_ENDIF_T_in_if_stat2219); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_ENDIF_T.add(ENDIF_T188);

                    SEMI_COLON189=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_if_stat2221); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON189);

                    if ( state.backtracking==0 ) {

                              startIndex = ((CommonToken)IF_T176).getStartIndex();
                              endIndex = ((CommonToken)SEMI_COLON189).getStopIndex();
                           
                    }


                    // AST REWRITE
                    // elements: new_elseif_branch, eIfCond, inner_statement_list, ELSE_T, IF_T, s4
                    // token labels: 
                    // rule labels: retval, eIfCond, s4
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
                    RewriteRuleSubtreeStream stream_eIfCond=new RewriteRuleSubtreeStream(adaptor,"rule eIfCond",eIfCond!=null?eIfCond.tree:null);
                    RewriteRuleSubtreeStream stream_s4=new RewriteRuleSubtreeStream(adaptor,"rule s4",s4!=null?s4.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 521:7: -> ^( IF_T ^( CONDITION $eIfCond) ( inner_statement_list )? ( new_elseif_branch )* ( ^( ELSE_T $s4) )? )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:521:11: ^( IF_T ^( CONDITION $eIfCond) ( inner_statement_list )? ( new_elseif_branch )* ( ^( ELSE_T $s4) )? )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_IF_T.nextNode(), root_1);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:521:18: ^( CONDITION $eIfCond)
                        {
                        SLAST root_2 = (SLAST)adaptor.nil();
                        root_2 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(CONDITION, "CONDITION"), root_2);

                        adaptor.addChild(root_2, stream_eIfCond.nextTree());

                        adaptor.addChild(root_1, root_2);
                        }
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:521:40: ( inner_statement_list )?
                        if ( stream_inner_statement_list.hasNext() ) {
                            adaptor.addChild(root_1, stream_inner_statement_list.nextTree());

                        }
                        stream_inner_statement_list.reset();
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:521:62: ( new_elseif_branch )*
                        while ( stream_new_elseif_branch.hasNext() ) {
                            adaptor.addChild(root_1, stream_new_elseif_branch.nextTree());

                        }
                        stream_new_elseif_branch.reset();
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:521:81: ( ^( ELSE_T $s4) )?
                        if ( stream_ELSE_T.hasNext()||stream_s4.hasNext() ) {
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:521:81: ^( ELSE_T $s4)
                            {
                            SLAST root_2 = (SLAST)adaptor.nil();
                            root_2 = (SLAST)adaptor.becomeRoot(stream_ELSE_T.nextNode(), root_2);

                            adaptor.addChild(root_2, stream_s4.nextTree());

                            adaptor.addChild(root_1, root_2);
                            }

                        }
                        stream_ELSE_T.reset();
                        stream_s4.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "if_stat"

    public static class new_elseif_branch_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "new_elseif_branch"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:525:1: new_elseif_branch : ELSEIF_T LEFT_PARETHESIS expression RIGHT_PARETHESIS COLON_T ( inner_statement_list )? -> ^( ELSEIF_T ^( CONDITION expression ) ( inner_statement_list )? ) ;
    public final CompilerAstParser.new_elseif_branch_return new_elseif_branch() throws RecognitionException {
        CompilerAstParser.new_elseif_branch_return retval = new CompilerAstParser.new_elseif_branch_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token ELSEIF_T190=null;
        Token LEFT_PARETHESIS191=null;
        Token RIGHT_PARETHESIS193=null;
        Token COLON_T194=null;
        CompilerAstParser.expression_return expression192 = null;

        CompilerAstParser.inner_statement_list_return inner_statement_list195 = null;


        SLAST ELSEIF_T190_tree=null;
        SLAST LEFT_PARETHESIS191_tree=null;
        SLAST RIGHT_PARETHESIS193_tree=null;
        SLAST COLON_T194_tree=null;
        RewriteRuleTokenStream stream_LEFT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token LEFT_PARETHESIS");
        RewriteRuleTokenStream stream_COLON_T=new RewriteRuleTokenStream(adaptor,"token COLON_T");
        RewriteRuleTokenStream stream_ELSEIF_T=new RewriteRuleTokenStream(adaptor,"token ELSEIF_T");
        RewriteRuleTokenStream stream_RIGHT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token RIGHT_PARETHESIS");
        RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");
        RewriteRuleSubtreeStream stream_inner_statement_list=new RewriteRuleSubtreeStream(adaptor,"rule inner_statement_list");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:535:2: ( ELSEIF_T LEFT_PARETHESIS expression RIGHT_PARETHESIS COLON_T ( inner_statement_list )? -> ^( ELSEIF_T ^( CONDITION expression ) ( inner_statement_list )? ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:535:4: ELSEIF_T LEFT_PARETHESIS expression RIGHT_PARETHESIS COLON_T ( inner_statement_list )?
            {
            ELSEIF_T190=(Token)match(input,ELSEIF_T,FOLLOW_ELSEIF_T_in_new_elseif_branch2292); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_ELSEIF_T.add(ELSEIF_T190);

            LEFT_PARETHESIS191=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_new_elseif_branch2294); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS191);

            pushFollow(FOLLOW_expression_in_new_elseif_branch2296);
            expression192=expression();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_expression.add(expression192.getTree());
            RIGHT_PARETHESIS193=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_new_elseif_branch2298); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS193);

            COLON_T194=(Token)match(input,COLON_T,FOLLOW_COLON_T_in_new_elseif_branch2300); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_COLON_T.add(COLON_T194);

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:535:65: ( inner_statement_list )?
            int alt50=2;
            int LA50_0 = input.LA(1);

            if ( (LA50_0==LEFT_PARETHESIS||(LA50_0>=SEMI_COLON && LA50_0<=IDENTIFIER)||LA50_0==LEFT_BRACKET||(LA50_0>=INTERFACE_T && LA50_0<=REF_T)||(LA50_0>=WHILE_T && LA50_0<=FOREACH_T)||(LA50_0>=DECLARE_T && LA50_0<=STRINGLITERAL)||LA50_0==IF_T||(LA50_0>=PLUS_T && LA50_0<=MINUS_T)||(LA50_0>=UNSET_T && LA50_0<=MINUS_MINUS_T)||(LA50_0>=AT_T && LA50_0<=BACKTRICKLITERAL)||(LA50_0>=DOLLAR_T && LA50_0<=DOUBLELITERRAL)||(LA50_0>=164 && LA50_0<=166)||(LA50_0>=179 && LA50_0<=185)) ) {
                alt50=1;
            }
            switch (alt50) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:535:65: inner_statement_list
                    {
                    pushFollow(FOLLOW_inner_statement_list_in_new_elseif_branch2302);
                    inner_statement_list195=inner_statement_list();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_inner_statement_list.add(inner_statement_list195.getTree());

                    }
                    break;

            }

            if ( state.backtracking==0 ) {

                  token = (CommonToken)ELSEIF_T190;
                  startIndex = token.getStartIndex();
                  token = (CommonToken)COLON_T194;
                  endIndex = token.getStopIndex();
                  if ((inner_statement_list195!=null?input.toString(inner_statement_list195.start,inner_statement_list195.stop):null) != null) {
                    endIndex = ((CommonToken)(inner_statement_list195!=null?((Token)inner_statement_list195.stop):null)).getStopIndex();
                  }
                
            }


            // AST REWRITE
            // elements: expression, inner_statement_list, ELSEIF_T
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 545:4: -> ^( ELSEIF_T ^( CONDITION expression ) ( inner_statement_list )? )
            {
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:545:8: ^( ELSEIF_T ^( CONDITION expression ) ( inner_statement_list )? )
                {
                SLAST root_1 = (SLAST)adaptor.nil();
                root_1 = (SLAST)adaptor.becomeRoot(stream_ELSEIF_T.nextNode(), root_1);

                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:545:19: ^( CONDITION expression )
                {
                SLAST root_2 = (SLAST)adaptor.nil();
                root_2 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(CONDITION, "CONDITION"), root_2);

                adaptor.addChild(root_2, stream_expression.nextTree());

                adaptor.addChild(root_1, root_2);
                }
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:545:43: ( inner_statement_list )?
                if ( stream_inner_statement_list.hasNext() ) {
                    adaptor.addChild(root_1, stream_inner_statement_list.nextTree());

                }
                stream_inner_statement_list.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "new_elseif_branch"

    public static class switch_case_list_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "switch_case_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:548:1: switch_case_list : ( LEFT_BRACKET ( SEMI_COLON )? ( case_list )+ RIGHT_BRACKET -> ( case_list )+ | COLON_T ( SEMI_COLON )? ( case_list )+ ENDSWITCH_T SEMI_COLON -> ( case_list )+ );
    public final CompilerAstParser.switch_case_list_return switch_case_list() throws RecognitionException {
        CompilerAstParser.switch_case_list_return retval = new CompilerAstParser.switch_case_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token LEFT_BRACKET196=null;
        Token SEMI_COLON197=null;
        Token RIGHT_BRACKET199=null;
        Token COLON_T200=null;
        Token SEMI_COLON201=null;
        Token ENDSWITCH_T203=null;
        Token SEMI_COLON204=null;
        CompilerAstParser.case_list_return case_list198 = null;

        CompilerAstParser.case_list_return case_list202 = null;


        SLAST LEFT_BRACKET196_tree=null;
        SLAST SEMI_COLON197_tree=null;
        SLAST RIGHT_BRACKET199_tree=null;
        SLAST COLON_T200_tree=null;
        SLAST SEMI_COLON201_tree=null;
        SLAST ENDSWITCH_T203_tree=null;
        SLAST SEMI_COLON204_tree=null;
        RewriteRuleTokenStream stream_SEMI_COLON=new RewriteRuleTokenStream(adaptor,"token SEMI_COLON");
        RewriteRuleTokenStream stream_COLON_T=new RewriteRuleTokenStream(adaptor,"token COLON_T");
        RewriteRuleTokenStream stream_ENDSWITCH_T=new RewriteRuleTokenStream(adaptor,"token ENDSWITCH_T");
        RewriteRuleTokenStream stream_LEFT_BRACKET=new RewriteRuleTokenStream(adaptor,"token LEFT_BRACKET");
        RewriteRuleTokenStream stream_RIGHT_BRACKET=new RewriteRuleTokenStream(adaptor,"token RIGHT_BRACKET");
        RewriteRuleSubtreeStream stream_case_list=new RewriteRuleSubtreeStream(adaptor,"rule case_list");
        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:549:3: ( LEFT_BRACKET ( SEMI_COLON )? ( case_list )+ RIGHT_BRACKET -> ( case_list )+ | COLON_T ( SEMI_COLON )? ( case_list )+ ENDSWITCH_T SEMI_COLON -> ( case_list )+ )
            int alt55=2;
            int LA55_0 = input.LA(1);

            if ( (LA55_0==LEFT_BRACKET) ) {
                alt55=1;
            }
            else if ( (LA55_0==COLON_T) ) {
                alt55=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 55, 0, input);

                throw nvae;
            }
            switch (alt55) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:549:5: LEFT_BRACKET ( SEMI_COLON )? ( case_list )+ RIGHT_BRACKET
                    {
                    LEFT_BRACKET196=(Token)match(input,LEFT_BRACKET,FOLLOW_LEFT_BRACKET_in_switch_case_list2340); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LEFT_BRACKET.add(LEFT_BRACKET196);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:549:18: ( SEMI_COLON )?
                    int alt51=2;
                    int LA51_0 = input.LA(1);

                    if ( (LA51_0==SEMI_COLON) ) {
                        alt51=1;
                    }
                    switch (alt51) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:549:18: SEMI_COLON
                            {
                            SEMI_COLON197=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_switch_case_list2342); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON197);


                            }
                            break;

                    }

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:549:30: ( case_list )+
                    int cnt52=0;
                    loop52:
                    do {
                        int alt52=2;
                        int LA52_0 = input.LA(1);

                        if ( ((LA52_0>=CASE_T && LA52_0<=DEFAULT_T)) ) {
                            alt52=1;
                        }


                        switch (alt52) {
                    	case 1 :
                    	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:549:30: case_list
                    	    {
                    	    pushFollow(FOLLOW_case_list_in_switch_case_list2345);
                    	    case_list198=case_list();

                    	    state._fsp--;
                    	    if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) stream_case_list.add(case_list198.getTree());

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt52 >= 1 ) break loop52;
                    	    if (state.backtracking>0) {state.failed=true; return retval;}
                                EarlyExitException eee =
                                    new EarlyExitException(52, input);
                                throw eee;
                        }
                        cnt52++;
                    } while (true);

                    RIGHT_BRACKET199=(Token)match(input,RIGHT_BRACKET,FOLLOW_RIGHT_BRACKET_in_switch_case_list2348); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RIGHT_BRACKET.add(RIGHT_BRACKET199);



                    // AST REWRITE
                    // elements: case_list
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 549:65: -> ( case_list )+
                    {
                        if ( !(stream_case_list.hasNext()) ) {
                            throw new RewriteEarlyExitException();
                        }
                        while ( stream_case_list.hasNext() ) {
                            adaptor.addChild(root_0, stream_case_list.nextTree());

                        }
                        stream_case_list.reset();

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:550:5: COLON_T ( SEMI_COLON )? ( case_list )+ ENDSWITCH_T SEMI_COLON
                    {
                    COLON_T200=(Token)match(input,COLON_T,FOLLOW_COLON_T_in_switch_case_list2370); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_COLON_T.add(COLON_T200);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:550:13: ( SEMI_COLON )?
                    int alt53=2;
                    int LA53_0 = input.LA(1);

                    if ( (LA53_0==SEMI_COLON) ) {
                        alt53=1;
                    }
                    switch (alt53) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:550:13: SEMI_COLON
                            {
                            SEMI_COLON201=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_switch_case_list2372); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON201);


                            }
                            break;

                    }

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:550:25: ( case_list )+
                    int cnt54=0;
                    loop54:
                    do {
                        int alt54=2;
                        int LA54_0 = input.LA(1);

                        if ( ((LA54_0>=CASE_T && LA54_0<=DEFAULT_T)) ) {
                            alt54=1;
                        }


                        switch (alt54) {
                    	case 1 :
                    	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:550:25: case_list
                    	    {
                    	    pushFollow(FOLLOW_case_list_in_switch_case_list2375);
                    	    case_list202=case_list();

                    	    state._fsp--;
                    	    if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) stream_case_list.add(case_list202.getTree());

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt54 >= 1 ) break loop54;
                    	    if (state.backtracking>0) {state.failed=true; return retval;}
                                EarlyExitException eee =
                                    new EarlyExitException(54, input);
                                throw eee;
                        }
                        cnt54++;
                    } while (true);

                    ENDSWITCH_T203=(Token)match(input,ENDSWITCH_T,FOLLOW_ENDSWITCH_T_in_switch_case_list2378); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_ENDSWITCH_T.add(ENDSWITCH_T203);

                    SEMI_COLON204=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_switch_case_list2380); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON204);



                    // AST REWRITE
                    // elements: case_list
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 550:63: -> ( case_list )+
                    {
                        if ( !(stream_case_list.hasNext()) ) {
                            throw new RewriteEarlyExitException();
                        }
                        while ( stream_case_list.hasNext() ) {
                            adaptor.addChild(root_0, stream_case_list.nextTree());

                        }
                        stream_case_list.reset();

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "switch_case_list"

    public static class case_list_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "case_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:553:1: case_list : ( CASE_T expression ( COLON_T | SEMI_COLON ) ( inner_statement_list )? -> ^( CASE_T expression ( inner_statement_list )? ) | DEFAULT_T ( COLON_T | SEMI_COLON ) ( inner_statement_list )? -> ^( DEFAULT_T ( inner_statement_list )? ) );
    public final CompilerAstParser.case_list_return case_list() throws RecognitionException {
        CompilerAstParser.case_list_return retval = new CompilerAstParser.case_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token CASE_T205=null;
        Token COLON_T207=null;
        Token SEMI_COLON208=null;
        Token DEFAULT_T210=null;
        Token COLON_T211=null;
        Token SEMI_COLON212=null;
        CompilerAstParser.expression_return expression206 = null;

        CompilerAstParser.inner_statement_list_return inner_statement_list209 = null;

        CompilerAstParser.inner_statement_list_return inner_statement_list213 = null;


        SLAST CASE_T205_tree=null;
        SLAST COLON_T207_tree=null;
        SLAST SEMI_COLON208_tree=null;
        SLAST DEFAULT_T210_tree=null;
        SLAST COLON_T211_tree=null;
        SLAST SEMI_COLON212_tree=null;
        RewriteRuleTokenStream stream_CASE_T=new RewriteRuleTokenStream(adaptor,"token CASE_T");
        RewriteRuleTokenStream stream_SEMI_COLON=new RewriteRuleTokenStream(adaptor,"token SEMI_COLON");
        RewriteRuleTokenStream stream_COLON_T=new RewriteRuleTokenStream(adaptor,"token COLON_T");
        RewriteRuleTokenStream stream_DEFAULT_T=new RewriteRuleTokenStream(adaptor,"token DEFAULT_T");
        RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");
        RewriteRuleSubtreeStream stream_inner_statement_list=new RewriteRuleSubtreeStream(adaptor,"rule inner_statement_list");
        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:554:3: ( CASE_T expression ( COLON_T | SEMI_COLON ) ( inner_statement_list )? -> ^( CASE_T expression ( inner_statement_list )? ) | DEFAULT_T ( COLON_T | SEMI_COLON ) ( inner_statement_list )? -> ^( DEFAULT_T ( inner_statement_list )? ) )
            int alt60=2;
            int LA60_0 = input.LA(1);

            if ( (LA60_0==CASE_T) ) {
                alt60=1;
            }
            else if ( (LA60_0==DEFAULT_T) ) {
                alt60=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 60, 0, input);

                throw nvae;
            }
            switch (alt60) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:554:5: CASE_T expression ( COLON_T | SEMI_COLON ) ( inner_statement_list )?
                    {
                    CASE_T205=(Token)match(input,CASE_T,FOLLOW_CASE_T_in_case_list2403); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_CASE_T.add(CASE_T205);

                    pushFollow(FOLLOW_expression_in_case_list2405);
                    expression206=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_expression.add(expression206.getTree());
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:554:23: ( COLON_T | SEMI_COLON )
                    int alt56=2;
                    int LA56_0 = input.LA(1);

                    if ( (LA56_0==COLON_T) ) {
                        alt56=1;
                    }
                    else if ( (LA56_0==SEMI_COLON) ) {
                        alt56=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return retval;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 56, 0, input);

                        throw nvae;
                    }
                    switch (alt56) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:554:24: COLON_T
                            {
                            COLON_T207=(Token)match(input,COLON_T,FOLLOW_COLON_T_in_case_list2408); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_COLON_T.add(COLON_T207);


                            }
                            break;
                        case 2 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:554:34: SEMI_COLON
                            {
                            SEMI_COLON208=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_case_list2412); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON208);


                            }
                            break;

                    }

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:554:46: ( inner_statement_list )?
                    int alt57=2;
                    int LA57_0 = input.LA(1);

                    if ( (LA57_0==LEFT_PARETHESIS||(LA57_0>=SEMI_COLON && LA57_0<=IDENTIFIER)||LA57_0==LEFT_BRACKET||(LA57_0>=INTERFACE_T && LA57_0<=REF_T)||(LA57_0>=WHILE_T && LA57_0<=FOREACH_T)||(LA57_0>=DECLARE_T && LA57_0<=STRINGLITERAL)||LA57_0==IF_T||(LA57_0>=PLUS_T && LA57_0<=MINUS_T)||(LA57_0>=UNSET_T && LA57_0<=MINUS_MINUS_T)||(LA57_0>=AT_T && LA57_0<=BACKTRICKLITERAL)||(LA57_0>=DOLLAR_T && LA57_0<=DOUBLELITERRAL)||(LA57_0>=164 && LA57_0<=166)||(LA57_0>=179 && LA57_0<=185)) ) {
                        alt57=1;
                    }
                    switch (alt57) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:554:46: inner_statement_list
                            {
                            pushFollow(FOLLOW_inner_statement_list_in_case_list2415);
                            inner_statement_list209=inner_statement_list();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_inner_statement_list.add(inner_statement_list209.getTree());

                            }
                            break;

                    }



                    // AST REWRITE
                    // elements: expression, inner_statement_list, CASE_T
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 554:70: -> ^( CASE_T expression ( inner_statement_list )? )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:554:74: ^( CASE_T expression ( inner_statement_list )? )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_CASE_T.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_expression.nextTree());
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:554:94: ( inner_statement_list )?
                        if ( stream_inner_statement_list.hasNext() ) {
                            adaptor.addChild(root_1, stream_inner_statement_list.nextTree());

                        }
                        stream_inner_statement_list.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:555:5: DEFAULT_T ( COLON_T | SEMI_COLON ) ( inner_statement_list )?
                    {
                    DEFAULT_T210=(Token)match(input,DEFAULT_T,FOLLOW_DEFAULT_T_in_case_list2436); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_DEFAULT_T.add(DEFAULT_T210);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:555:15: ( COLON_T | SEMI_COLON )
                    int alt58=2;
                    int LA58_0 = input.LA(1);

                    if ( (LA58_0==COLON_T) ) {
                        alt58=1;
                    }
                    else if ( (LA58_0==SEMI_COLON) ) {
                        alt58=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return retval;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 58, 0, input);

                        throw nvae;
                    }
                    switch (alt58) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:555:16: COLON_T
                            {
                            COLON_T211=(Token)match(input,COLON_T,FOLLOW_COLON_T_in_case_list2439); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_COLON_T.add(COLON_T211);


                            }
                            break;
                        case 2 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:555:26: SEMI_COLON
                            {
                            SEMI_COLON212=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_case_list2443); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON212);


                            }
                            break;

                    }

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:555:38: ( inner_statement_list )?
                    int alt59=2;
                    int LA59_0 = input.LA(1);

                    if ( (LA59_0==LEFT_PARETHESIS||(LA59_0>=SEMI_COLON && LA59_0<=IDENTIFIER)||LA59_0==LEFT_BRACKET||(LA59_0>=INTERFACE_T && LA59_0<=REF_T)||(LA59_0>=WHILE_T && LA59_0<=FOREACH_T)||(LA59_0>=DECLARE_T && LA59_0<=STRINGLITERAL)||LA59_0==IF_T||(LA59_0>=PLUS_T && LA59_0<=MINUS_T)||(LA59_0>=UNSET_T && LA59_0<=MINUS_MINUS_T)||(LA59_0>=AT_T && LA59_0<=BACKTRICKLITERAL)||(LA59_0>=DOLLAR_T && LA59_0<=DOUBLELITERRAL)||(LA59_0>=164 && LA59_0<=166)||(LA59_0>=179 && LA59_0<=185)) ) {
                        alt59=1;
                    }
                    switch (alt59) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:555:38: inner_statement_list
                            {
                            pushFollow(FOLLOW_inner_statement_list_in_case_list2446);
                            inner_statement_list213=inner_statement_list();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_inner_statement_list.add(inner_statement_list213.getTree());

                            }
                            break;

                    }



                    // AST REWRITE
                    // elements: inner_statement_list, DEFAULT_T
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 555:66: -> ^( DEFAULT_T ( inner_statement_list )? )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:555:70: ^( DEFAULT_T ( inner_statement_list )? )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_DEFAULT_T.nextNode(), root_1);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:555:82: ( inner_statement_list )?
                        if ( stream_inner_statement_list.hasNext() ) {
                            adaptor.addChild(root_1, stream_inner_statement_list.nextTree());

                        }
                        stream_inner_statement_list.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "case_list"

    public static class catch_branch_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "catch_branch"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:558:1: catch_branch : CATCH_T LEFT_PARETHESIS IDENTIFIER variable RIGHT_PARETHESIS block -> ^( CATCH_T IDENTIFIER variable block ) ;
    public final CompilerAstParser.catch_branch_return catch_branch() throws RecognitionException {
        CompilerAstParser.catch_branch_return retval = new CompilerAstParser.catch_branch_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token CATCH_T214=null;
        Token LEFT_PARETHESIS215=null;
        Token IDENTIFIER216=null;
        Token RIGHT_PARETHESIS218=null;
        CompilerAstParser.variable_return variable217 = null;

        CompilerAstParser.block_return block219 = null;


        SLAST CATCH_T214_tree=null;
        SLAST LEFT_PARETHESIS215_tree=null;
        SLAST IDENTIFIER216_tree=null;
        SLAST RIGHT_PARETHESIS218_tree=null;
        RewriteRuleTokenStream stream_CATCH_T=new RewriteRuleTokenStream(adaptor,"token CATCH_T");
        RewriteRuleTokenStream stream_LEFT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token LEFT_PARETHESIS");
        RewriteRuleTokenStream stream_IDENTIFIER=new RewriteRuleTokenStream(adaptor,"token IDENTIFIER");
        RewriteRuleTokenStream stream_RIGHT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token RIGHT_PARETHESIS");
        RewriteRuleSubtreeStream stream_block=new RewriteRuleSubtreeStream(adaptor,"rule block");
        RewriteRuleSubtreeStream stream_variable=new RewriteRuleSubtreeStream(adaptor,"rule variable");
        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:559:3: ( CATCH_T LEFT_PARETHESIS IDENTIFIER variable RIGHT_PARETHESIS block -> ^( CATCH_T IDENTIFIER variable block ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:559:5: CATCH_T LEFT_PARETHESIS IDENTIFIER variable RIGHT_PARETHESIS block
            {
            CATCH_T214=(Token)match(input,CATCH_T,FOLLOW_CATCH_T_in_catch_branch2477); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_CATCH_T.add(CATCH_T214);

            LEFT_PARETHESIS215=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_catch_branch2479); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS215);

            IDENTIFIER216=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_catch_branch2481); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER216);

            pushFollow(FOLLOW_variable_in_catch_branch2483);
            variable217=variable();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_variable.add(variable217.getTree());
            RIGHT_PARETHESIS218=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_catch_branch2485); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS218);

            pushFollow(FOLLOW_block_in_catch_branch2493);
            block219=block();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_block.add(block219.getTree());


            // AST REWRITE
            // elements: IDENTIFIER, variable, CATCH_T, block
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 561:5: -> ^( CATCH_T IDENTIFIER variable block )
            {
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:561:9: ^( CATCH_T IDENTIFIER variable block )
                {
                SLAST root_1 = (SLAST)adaptor.nil();
                root_1 = (SLAST)adaptor.becomeRoot(stream_CATCH_T.nextNode(), root_1);

                adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());
                adaptor.addChild(root_1, stream_variable.nextTree());
                adaptor.addChild(root_1, stream_block.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "catch_branch"

    public static class for_statement_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "for_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:564:1: for_statement : ( statement -> statement | COLON_T ( inner_statement_list )? ENDFOR_T SEMI_COLON -> ( inner_statement_list )? );
    public final CompilerAstParser.for_statement_return for_statement() throws RecognitionException {
        CompilerAstParser.for_statement_return retval = new CompilerAstParser.for_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token COLON_T221=null;
        Token ENDFOR_T223=null;
        Token SEMI_COLON224=null;
        CompilerAstParser.statement_return statement220 = null;

        CompilerAstParser.inner_statement_list_return inner_statement_list222 = null;


        SLAST COLON_T221_tree=null;
        SLAST ENDFOR_T223_tree=null;
        SLAST SEMI_COLON224_tree=null;
        RewriteRuleTokenStream stream_SEMI_COLON=new RewriteRuleTokenStream(adaptor,"token SEMI_COLON");
        RewriteRuleTokenStream stream_COLON_T=new RewriteRuleTokenStream(adaptor,"token COLON_T");
        RewriteRuleTokenStream stream_ENDFOR_T=new RewriteRuleTokenStream(adaptor,"token ENDFOR_T");
        RewriteRuleSubtreeStream stream_statement=new RewriteRuleSubtreeStream(adaptor,"rule statement");
        RewriteRuleSubtreeStream stream_inner_statement_list=new RewriteRuleSubtreeStream(adaptor,"rule inner_statement_list");
        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:565:2: ( statement -> statement | COLON_T ( inner_statement_list )? ENDFOR_T SEMI_COLON -> ( inner_statement_list )? )
            int alt62=2;
            int LA62_0 = input.LA(1);

            if ( (LA62_0==LEFT_PARETHESIS||LA62_0==SEMI_COLON||LA62_0==IDENTIFIER||LA62_0==LEFT_BRACKET||(LA62_0>=FUNCTION_T && LA62_0<=REF_T)||(LA62_0>=WHILE_T && LA62_0<=FOREACH_T)||(LA62_0>=DECLARE_T && LA62_0<=STRINGLITERAL)||LA62_0==IF_T||(LA62_0>=PLUS_T && LA62_0<=MINUS_T)||(LA62_0>=UNSET_T && LA62_0<=MINUS_MINUS_T)||(LA62_0>=AT_T && LA62_0<=BACKTRICKLITERAL)||(LA62_0>=DOLLAR_T && LA62_0<=DOUBLELITERRAL)||(LA62_0>=179 && LA62_0<=185)) ) {
                alt62=1;
            }
            else if ( (LA62_0==COLON_T) ) {
                alt62=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 62, 0, input);

                throw nvae;
            }
            switch (alt62) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:565:4: statement
                    {
                    pushFollow(FOLLOW_statement_in_for_statement2522);
                    statement220=statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_statement.add(statement220.getTree());


                    // AST REWRITE
                    // elements: statement
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 565:31: -> statement
                    {
                        adaptor.addChild(root_0, stream_statement.nextTree());

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:566:4: COLON_T ( inner_statement_list )? ENDFOR_T SEMI_COLON
                    {
                    COLON_T221=(Token)match(input,COLON_T,FOLLOW_COLON_T_in_for_statement2549); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_COLON_T.add(COLON_T221);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:566:12: ( inner_statement_list )?
                    int alt61=2;
                    int LA61_0 = input.LA(1);

                    if ( (LA61_0==LEFT_PARETHESIS||(LA61_0>=SEMI_COLON && LA61_0<=IDENTIFIER)||LA61_0==LEFT_BRACKET||(LA61_0>=INTERFACE_T && LA61_0<=REF_T)||(LA61_0>=WHILE_T && LA61_0<=FOREACH_T)||(LA61_0>=DECLARE_T && LA61_0<=STRINGLITERAL)||LA61_0==IF_T||(LA61_0>=PLUS_T && LA61_0<=MINUS_T)||(LA61_0>=UNSET_T && LA61_0<=MINUS_MINUS_T)||(LA61_0>=AT_T && LA61_0<=BACKTRICKLITERAL)||(LA61_0>=DOLLAR_T && LA61_0<=DOUBLELITERRAL)||(LA61_0>=164 && LA61_0<=166)||(LA61_0>=179 && LA61_0<=185)) ) {
                        alt61=1;
                    }
                    switch (alt61) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:566:12: inner_statement_list
                            {
                            pushFollow(FOLLOW_inner_statement_list_in_for_statement2551);
                            inner_statement_list222=inner_statement_list();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_inner_statement_list.add(inner_statement_list222.getTree());

                            }
                            break;

                    }

                    ENDFOR_T223=(Token)match(input,ENDFOR_T,FOLLOW_ENDFOR_T_in_for_statement2554); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_ENDFOR_T.add(ENDFOR_T223);

                    SEMI_COLON224=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_for_statement2556); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON224);



                    // AST REWRITE
                    // elements: inner_statement_list
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 566:56: -> ( inner_statement_list )?
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:566:60: ( inner_statement_list )?
                        if ( stream_inner_statement_list.hasNext() ) {
                            adaptor.addChild(root_0, stream_inner_statement_list.nextTree());

                        }
                        stream_inner_statement_list.reset();

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "for_statement"

    public static class while_statement_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "while_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:569:1: while_statement : ( statement -> statement | COLON_T ( inner_statement_list )? ENDWHILE_T SEMI_COLON -> ( inner_statement_list )? );
    public final CompilerAstParser.while_statement_return while_statement() throws RecognitionException {
        CompilerAstParser.while_statement_return retval = new CompilerAstParser.while_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token COLON_T226=null;
        Token ENDWHILE_T228=null;
        Token SEMI_COLON229=null;
        CompilerAstParser.statement_return statement225 = null;

        CompilerAstParser.inner_statement_list_return inner_statement_list227 = null;


        SLAST COLON_T226_tree=null;
        SLAST ENDWHILE_T228_tree=null;
        SLAST SEMI_COLON229_tree=null;
        RewriteRuleTokenStream stream_SEMI_COLON=new RewriteRuleTokenStream(adaptor,"token SEMI_COLON");
        RewriteRuleTokenStream stream_COLON_T=new RewriteRuleTokenStream(adaptor,"token COLON_T");
        RewriteRuleTokenStream stream_ENDWHILE_T=new RewriteRuleTokenStream(adaptor,"token ENDWHILE_T");
        RewriteRuleSubtreeStream stream_statement=new RewriteRuleSubtreeStream(adaptor,"rule statement");
        RewriteRuleSubtreeStream stream_inner_statement_list=new RewriteRuleSubtreeStream(adaptor,"rule inner_statement_list");
        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:570:2: ( statement -> statement | COLON_T ( inner_statement_list )? ENDWHILE_T SEMI_COLON -> ( inner_statement_list )? )
            int alt64=2;
            int LA64_0 = input.LA(1);

            if ( (LA64_0==LEFT_PARETHESIS||LA64_0==SEMI_COLON||LA64_0==IDENTIFIER||LA64_0==LEFT_BRACKET||(LA64_0>=FUNCTION_T && LA64_0<=REF_T)||(LA64_0>=WHILE_T && LA64_0<=FOREACH_T)||(LA64_0>=DECLARE_T && LA64_0<=STRINGLITERAL)||LA64_0==IF_T||(LA64_0>=PLUS_T && LA64_0<=MINUS_T)||(LA64_0>=UNSET_T && LA64_0<=MINUS_MINUS_T)||(LA64_0>=AT_T && LA64_0<=BACKTRICKLITERAL)||(LA64_0>=DOLLAR_T && LA64_0<=DOUBLELITERRAL)||(LA64_0>=179 && LA64_0<=185)) ) {
                alt64=1;
            }
            else if ( (LA64_0==COLON_T) ) {
                alt64=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 64, 0, input);

                throw nvae;
            }
            switch (alt64) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:570:4: statement
                    {
                    pushFollow(FOLLOW_statement_in_while_statement2576);
                    statement225=statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_statement.add(statement225.getTree());


                    // AST REWRITE
                    // elements: statement
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 570:31: -> statement
                    {
                        adaptor.addChild(root_0, stream_statement.nextTree());

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:571:4: COLON_T ( inner_statement_list )? ENDWHILE_T SEMI_COLON
                    {
                    COLON_T226=(Token)match(input,COLON_T,FOLLOW_COLON_T_in_while_statement2603); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_COLON_T.add(COLON_T226);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:571:12: ( inner_statement_list )?
                    int alt63=2;
                    int LA63_0 = input.LA(1);

                    if ( (LA63_0==LEFT_PARETHESIS||(LA63_0>=SEMI_COLON && LA63_0<=IDENTIFIER)||LA63_0==LEFT_BRACKET||(LA63_0>=INTERFACE_T && LA63_0<=REF_T)||(LA63_0>=WHILE_T && LA63_0<=FOREACH_T)||(LA63_0>=DECLARE_T && LA63_0<=STRINGLITERAL)||LA63_0==IF_T||(LA63_0>=PLUS_T && LA63_0<=MINUS_T)||(LA63_0>=UNSET_T && LA63_0<=MINUS_MINUS_T)||(LA63_0>=AT_T && LA63_0<=BACKTRICKLITERAL)||(LA63_0>=DOLLAR_T && LA63_0<=DOUBLELITERRAL)||(LA63_0>=164 && LA63_0<=166)||(LA63_0>=179 && LA63_0<=185)) ) {
                        alt63=1;
                    }
                    switch (alt63) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:571:12: inner_statement_list
                            {
                            pushFollow(FOLLOW_inner_statement_list_in_while_statement2605);
                            inner_statement_list227=inner_statement_list();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_inner_statement_list.add(inner_statement_list227.getTree());

                            }
                            break;

                    }

                    ENDWHILE_T228=(Token)match(input,ENDWHILE_T,FOLLOW_ENDWHILE_T_in_while_statement2608); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_ENDWHILE_T.add(ENDWHILE_T228);

                    SEMI_COLON229=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_while_statement2610); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON229);



                    // AST REWRITE
                    // elements: inner_statement_list
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 571:58: -> ( inner_statement_list )?
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:571:62: ( inner_statement_list )?
                        if ( stream_inner_statement_list.hasNext() ) {
                            adaptor.addChild(root_0, stream_inner_statement_list.nextTree());

                        }
                        stream_inner_statement_list.reset();

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "while_statement"

    public static class foreach_statement_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "foreach_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:574:1: foreach_statement : ( statement -> statement | COLON_T ( inner_statement_list )? ENDFOREACH_T SEMI_COLON -> ( inner_statement_list )? );
    public final CompilerAstParser.foreach_statement_return foreach_statement() throws RecognitionException {
        CompilerAstParser.foreach_statement_return retval = new CompilerAstParser.foreach_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token COLON_T231=null;
        Token ENDFOREACH_T233=null;
        Token SEMI_COLON234=null;
        CompilerAstParser.statement_return statement230 = null;

        CompilerAstParser.inner_statement_list_return inner_statement_list232 = null;


        SLAST COLON_T231_tree=null;
        SLAST ENDFOREACH_T233_tree=null;
        SLAST SEMI_COLON234_tree=null;
        RewriteRuleTokenStream stream_ENDFOREACH_T=new RewriteRuleTokenStream(adaptor,"token ENDFOREACH_T");
        RewriteRuleTokenStream stream_SEMI_COLON=new RewriteRuleTokenStream(adaptor,"token SEMI_COLON");
        RewriteRuleTokenStream stream_COLON_T=new RewriteRuleTokenStream(adaptor,"token COLON_T");
        RewriteRuleSubtreeStream stream_statement=new RewriteRuleSubtreeStream(adaptor,"rule statement");
        RewriteRuleSubtreeStream stream_inner_statement_list=new RewriteRuleSubtreeStream(adaptor,"rule inner_statement_list");
        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:575:3: ( statement -> statement | COLON_T ( inner_statement_list )? ENDFOREACH_T SEMI_COLON -> ( inner_statement_list )? )
            int alt66=2;
            int LA66_0 = input.LA(1);

            if ( (LA66_0==LEFT_PARETHESIS||LA66_0==SEMI_COLON||LA66_0==IDENTIFIER||LA66_0==LEFT_BRACKET||(LA66_0>=FUNCTION_T && LA66_0<=REF_T)||(LA66_0>=WHILE_T && LA66_0<=FOREACH_T)||(LA66_0>=DECLARE_T && LA66_0<=STRINGLITERAL)||LA66_0==IF_T||(LA66_0>=PLUS_T && LA66_0<=MINUS_T)||(LA66_0>=UNSET_T && LA66_0<=MINUS_MINUS_T)||(LA66_0>=AT_T && LA66_0<=BACKTRICKLITERAL)||(LA66_0>=DOLLAR_T && LA66_0<=DOUBLELITERRAL)||(LA66_0>=179 && LA66_0<=185)) ) {
                alt66=1;
            }
            else if ( (LA66_0==COLON_T) ) {
                alt66=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 66, 0, input);

                throw nvae;
            }
            switch (alt66) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:575:5: statement
                    {
                    pushFollow(FOLLOW_statement_in_foreach_statement2631);
                    statement230=statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_statement.add(statement230.getTree());


                    // AST REWRITE
                    // elements: statement
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 575:31: -> statement
                    {
                        adaptor.addChild(root_0, stream_statement.nextTree());

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:576:5: COLON_T ( inner_statement_list )? ENDFOREACH_T SEMI_COLON
                    {
                    COLON_T231=(Token)match(input,COLON_T,FOLLOW_COLON_T_in_foreach_statement2658); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_COLON_T.add(COLON_T231);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:576:13: ( inner_statement_list )?
                    int alt65=2;
                    int LA65_0 = input.LA(1);

                    if ( (LA65_0==LEFT_PARETHESIS||(LA65_0>=SEMI_COLON && LA65_0<=IDENTIFIER)||LA65_0==LEFT_BRACKET||(LA65_0>=INTERFACE_T && LA65_0<=REF_T)||(LA65_0>=WHILE_T && LA65_0<=FOREACH_T)||(LA65_0>=DECLARE_T && LA65_0<=STRINGLITERAL)||LA65_0==IF_T||(LA65_0>=PLUS_T && LA65_0<=MINUS_T)||(LA65_0>=UNSET_T && LA65_0<=MINUS_MINUS_T)||(LA65_0>=AT_T && LA65_0<=BACKTRICKLITERAL)||(LA65_0>=DOLLAR_T && LA65_0<=DOUBLELITERRAL)||(LA65_0>=164 && LA65_0<=166)||(LA65_0>=179 && LA65_0<=185)) ) {
                        alt65=1;
                    }
                    switch (alt65) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:576:13: inner_statement_list
                            {
                            pushFollow(FOLLOW_inner_statement_list_in_foreach_statement2660);
                            inner_statement_list232=inner_statement_list();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_inner_statement_list.add(inner_statement_list232.getTree());

                            }
                            break;

                    }

                    ENDFOREACH_T233=(Token)match(input,ENDFOREACH_T,FOLLOW_ENDFOREACH_T_in_foreach_statement2663); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_ENDFOREACH_T.add(ENDFOREACH_T233);

                    SEMI_COLON234=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_foreach_statement2665); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON234);



                    // AST REWRITE
                    // elements: inner_statement_list
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 576:60: -> ( inner_statement_list )?
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:576:64: ( inner_statement_list )?
                        if ( stream_inner_statement_list.hasNext() ) {
                            adaptor.addChild(root_0, stream_inner_statement_list.nextTree());

                        }
                        stream_inner_statement_list.reset();

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "foreach_statement"

    public static class declare_statement_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "declare_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:579:1: declare_statement : ( statement -> statement | COLON_T ( inner_statement_list )? ENDDECLARE_T SEMI_COLON -> ( inner_statement_list )? );
    public final CompilerAstParser.declare_statement_return declare_statement() throws RecognitionException {
        CompilerAstParser.declare_statement_return retval = new CompilerAstParser.declare_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token COLON_T236=null;
        Token ENDDECLARE_T238=null;
        Token SEMI_COLON239=null;
        CompilerAstParser.statement_return statement235 = null;

        CompilerAstParser.inner_statement_list_return inner_statement_list237 = null;


        SLAST COLON_T236_tree=null;
        SLAST ENDDECLARE_T238_tree=null;
        SLAST SEMI_COLON239_tree=null;
        RewriteRuleTokenStream stream_SEMI_COLON=new RewriteRuleTokenStream(adaptor,"token SEMI_COLON");
        RewriteRuleTokenStream stream_COLON_T=new RewriteRuleTokenStream(adaptor,"token COLON_T");
        RewriteRuleTokenStream stream_ENDDECLARE_T=new RewriteRuleTokenStream(adaptor,"token ENDDECLARE_T");
        RewriteRuleSubtreeStream stream_statement=new RewriteRuleSubtreeStream(adaptor,"rule statement");
        RewriteRuleSubtreeStream stream_inner_statement_list=new RewriteRuleSubtreeStream(adaptor,"rule inner_statement_list");
        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:580:3: ( statement -> statement | COLON_T ( inner_statement_list )? ENDDECLARE_T SEMI_COLON -> ( inner_statement_list )? )
            int alt68=2;
            int LA68_0 = input.LA(1);

            if ( (LA68_0==LEFT_PARETHESIS||LA68_0==SEMI_COLON||LA68_0==IDENTIFIER||LA68_0==LEFT_BRACKET||(LA68_0>=FUNCTION_T && LA68_0<=REF_T)||(LA68_0>=WHILE_T && LA68_0<=FOREACH_T)||(LA68_0>=DECLARE_T && LA68_0<=STRINGLITERAL)||LA68_0==IF_T||(LA68_0>=PLUS_T && LA68_0<=MINUS_T)||(LA68_0>=UNSET_T && LA68_0<=MINUS_MINUS_T)||(LA68_0>=AT_T && LA68_0<=BACKTRICKLITERAL)||(LA68_0>=DOLLAR_T && LA68_0<=DOUBLELITERRAL)||(LA68_0>=179 && LA68_0<=185)) ) {
                alt68=1;
            }
            else if ( (LA68_0==COLON_T) ) {
                alt68=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 68, 0, input);

                throw nvae;
            }
            switch (alt68) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:580:5: statement
                    {
                    pushFollow(FOLLOW_statement_in_declare_statement2687);
                    statement235=statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_statement.add(statement235.getTree());


                    // AST REWRITE
                    // elements: statement
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 580:31: -> statement
                    {
                        adaptor.addChild(root_0, stream_statement.nextTree());

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:581:5: COLON_T ( inner_statement_list )? ENDDECLARE_T SEMI_COLON
                    {
                    COLON_T236=(Token)match(input,COLON_T,FOLLOW_COLON_T_in_declare_statement2714); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_COLON_T.add(COLON_T236);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:581:13: ( inner_statement_list )?
                    int alt67=2;
                    int LA67_0 = input.LA(1);

                    if ( (LA67_0==LEFT_PARETHESIS||(LA67_0>=SEMI_COLON && LA67_0<=IDENTIFIER)||LA67_0==LEFT_BRACKET||(LA67_0>=INTERFACE_T && LA67_0<=REF_T)||(LA67_0>=WHILE_T && LA67_0<=FOREACH_T)||(LA67_0>=DECLARE_T && LA67_0<=STRINGLITERAL)||LA67_0==IF_T||(LA67_0>=PLUS_T && LA67_0<=MINUS_T)||(LA67_0>=UNSET_T && LA67_0<=MINUS_MINUS_T)||(LA67_0>=AT_T && LA67_0<=BACKTRICKLITERAL)||(LA67_0>=DOLLAR_T && LA67_0<=DOUBLELITERRAL)||(LA67_0>=164 && LA67_0<=166)||(LA67_0>=179 && LA67_0<=185)) ) {
                        alt67=1;
                    }
                    switch (alt67) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:581:13: inner_statement_list
                            {
                            pushFollow(FOLLOW_inner_statement_list_in_declare_statement2716);
                            inner_statement_list237=inner_statement_list();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_inner_statement_list.add(inner_statement_list237.getTree());

                            }
                            break;

                    }

                    ENDDECLARE_T238=(Token)match(input,ENDDECLARE_T,FOLLOW_ENDDECLARE_T_in_declare_statement2719); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_ENDDECLARE_T.add(ENDDECLARE_T238);

                    SEMI_COLON239=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_declare_statement2721); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON239);



                    // AST REWRITE
                    // elements: inner_statement_list
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 581:60: -> ( inner_statement_list )?
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:581:64: ( inner_statement_list )?
                        if ( stream_inner_statement_list.hasNext() ) {
                            adaptor.addChild(root_0, stream_inner_statement_list.nextTree());

                        }
                        stream_inner_statement_list.reset();

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "declare_statement"

    public static class parameter_list_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "parameter_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:584:1: parameter_list : parameter ( COMMA_T parameter )* -> ( parameter )+ ;
    public final CompilerAstParser.parameter_list_return parameter_list() throws RecognitionException {
        CompilerAstParser.parameter_list_return retval = new CompilerAstParser.parameter_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token COMMA_T241=null;
        CompilerAstParser.parameter_return parameter240 = null;

        CompilerAstParser.parameter_return parameter242 = null;


        SLAST COMMA_T241_tree=null;
        RewriteRuleTokenStream stream_COMMA_T=new RewriteRuleTokenStream(adaptor,"token COMMA_T");
        RewriteRuleSubtreeStream stream_parameter=new RewriteRuleSubtreeStream(adaptor,"rule parameter");
        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:585:3: ( parameter ( COMMA_T parameter )* -> ( parameter )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:585:5: parameter ( COMMA_T parameter )*
            {
            pushFollow(FOLLOW_parameter_in_parameter_list2743);
            parameter240=parameter();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_parameter.add(parameter240.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:585:15: ( COMMA_T parameter )*
            loop69:
            do {
                int alt69=2;
                int LA69_0 = input.LA(1);

                if ( (LA69_0==COMMA_T) ) {
                    alt69=1;
                }


                switch (alt69) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:585:16: COMMA_T parameter
            	    {
            	    COMMA_T241=(Token)match(input,COMMA_T,FOLLOW_COMMA_T_in_parameter_list2746); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_COMMA_T.add(COMMA_T241);

            	    pushFollow(FOLLOW_parameter_in_parameter_list2748);
            	    parameter242=parameter();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_parameter.add(parameter242.getTree());

            	    }
            	    break;

            	default :
            	    break loop69;
                }
            } while (true);



            // AST REWRITE
            // elements: parameter
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 585:45: -> ( parameter )+
            {
                if ( !(stream_parameter.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_parameter.hasNext() ) {
                    adaptor.addChild(root_0, stream_parameter.nextTree());

                }
                stream_parameter.reset();

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "parameter_list"

    public static class parameter_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "parameter"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:588:1: parameter : ( parameter_type )? ( CONST_T )? pure_variable ( options {k=1; backtrack=true; } : EQUAL_T scalar )? -> ^( PARAMETER ( ^( TYPE parameter_type ) )? ( CONST_T )? pure_variable ( scalar )? ) ;
    public final CompilerAstParser.parameter_return parameter() throws RecognitionException {
        CompilerAstParser.parameter_return retval = new CompilerAstParser.parameter_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token CONST_T244=null;
        Token EQUAL_T246=null;
        CompilerAstParser.parameter_type_return parameter_type243 = null;

        CompilerAstParser.pure_variable_return pure_variable245 = null;

        CompilerAstParser.scalar_return scalar247 = null;


        SLAST CONST_T244_tree=null;
        SLAST EQUAL_T246_tree=null;
        RewriteRuleTokenStream stream_EQUAL_T=new RewriteRuleTokenStream(adaptor,"token EQUAL_T");
        RewriteRuleTokenStream stream_CONST_T=new RewriteRuleTokenStream(adaptor,"token CONST_T");
        RewriteRuleSubtreeStream stream_scalar=new RewriteRuleSubtreeStream(adaptor,"rule scalar");
        RewriteRuleSubtreeStream stream_parameter_type=new RewriteRuleSubtreeStream(adaptor,"rule parameter_type");
        RewriteRuleSubtreeStream stream_pure_variable=new RewriteRuleSubtreeStream(adaptor,"rule pure_variable");
        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:589:3: ( ( parameter_type )? ( CONST_T )? pure_variable ( options {k=1; backtrack=true; } : EQUAL_T scalar )? -> ^( PARAMETER ( ^( TYPE parameter_type ) )? ( CONST_T )? pure_variable ( scalar )? ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:589:5: ( parameter_type )? ( CONST_T )? pure_variable ( options {k=1; backtrack=true; } : EQUAL_T scalar )?
            {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:589:5: ( parameter_type )?
            int alt70=2;
            int LA70_0 = input.LA(1);

            if ( (LA70_0==IDENTIFIER||(LA70_0>=UNSET_T && LA70_0<=CLONE_T)||(LA70_0>=171 && LA70_0<=179)) ) {
                alt70=1;
            }
            switch (alt70) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:589:5: parameter_type
                    {
                    pushFollow(FOLLOW_parameter_type_in_parameter2779);
                    parameter_type243=parameter_type();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_parameter_type.add(parameter_type243.getTree());

                    }
                    break;

            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:589:21: ( CONST_T )?
            int alt71=2;
            int LA71_0 = input.LA(1);

            if ( (LA71_0==CONST_T) ) {
                alt71=1;
            }
            switch (alt71) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:589:21: CONST_T
                    {
                    CONST_T244=(Token)match(input,CONST_T,FOLLOW_CONST_T_in_parameter2782); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_CONST_T.add(CONST_T244);


                    }
                    break;

            }

            pushFollow(FOLLOW_pure_variable_in_parameter2785);
            pure_variable245=pure_variable();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_pure_variable.add(pure_variable245.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:589:44: ( options {k=1; backtrack=true; } : EQUAL_T scalar )?
            int alt72=2;
            int LA72_0 = input.LA(1);

            if ( (LA72_0==EQUAL_T) ) {
                alt72=1;
            }
            switch (alt72) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:589:76: EQUAL_T scalar
                    {
                    EQUAL_T246=(Token)match(input,EQUAL_T,FOLLOW_EQUAL_T_in_parameter2801); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_EQUAL_T.add(EQUAL_T246);

                    pushFollow(FOLLOW_scalar_in_parameter2803);
                    scalar247=scalar();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_scalar.add(scalar247.getTree());

                    }
                    break;

            }



            // AST REWRITE
            // elements: pure_variable, parameter_type, CONST_T, scalar
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 590:3: -> ^( PARAMETER ( ^( TYPE parameter_type ) )? ( CONST_T )? pure_variable ( scalar )? )
            {
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:590:6: ^( PARAMETER ( ^( TYPE parameter_type ) )? ( CONST_T )? pure_variable ( scalar )? )
                {
                SLAST root_1 = (SLAST)adaptor.nil();
                root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(PARAMETER, "PARAMETER"), root_1);

                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:590:18: ( ^( TYPE parameter_type ) )?
                if ( stream_parameter_type.hasNext() ) {
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:590:18: ^( TYPE parameter_type )
                    {
                    SLAST root_2 = (SLAST)adaptor.nil();
                    root_2 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(TYPE, "TYPE"), root_2);

                    adaptor.addChild(root_2, stream_parameter_type.nextTree());

                    adaptor.addChild(root_1, root_2);
                    }

                }
                stream_parameter_type.reset();
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:590:42: ( CONST_T )?
                if ( stream_CONST_T.hasNext() ) {
                    adaptor.addChild(root_1, stream_CONST_T.nextNode());

                }
                stream_CONST_T.reset();
                adaptor.addChild(root_1, stream_pure_variable.nextTree());
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:590:65: ( scalar )?
                if ( stream_scalar.hasNext() ) {
                    adaptor.addChild(root_1, stream_scalar.nextTree());

                }
                stream_scalar.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "parameter"

    public static class parameter_type_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "parameter_type"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:593:1: parameter_type : ( fully_qualified_class_name | cast_option );
    public final CompilerAstParser.parameter_type_return parameter_type() throws RecognitionException {
        CompilerAstParser.parameter_type_return retval = new CompilerAstParser.parameter_type_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        CompilerAstParser.fully_qualified_class_name_return fully_qualified_class_name248 = null;

        CompilerAstParser.cast_option_return cast_option249 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:594:3: ( fully_qualified_class_name | cast_option )
            int alt73=2;
            int LA73_0 = input.LA(1);

            if ( (LA73_0==IDENTIFIER) ) {
                alt73=1;
            }
            else if ( ((LA73_0>=UNSET_T && LA73_0<=CLONE_T)||(LA73_0>=171 && LA73_0<=179)) ) {
                alt73=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 73, 0, input);

                throw nvae;
            }
            switch (alt73) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:594:5: fully_qualified_class_name
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_fully_qualified_class_name_in_parameter_type2843);
                    fully_qualified_class_name248=fully_qualified_class_name();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, fully_qualified_class_name248.getTree());

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:595:5: cast_option
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_cast_option_in_parameter_type2849);
                    cast_option249=cast_option();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, cast_option249.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "parameter_type"

    public static class variable_list_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "variable_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:598:1: variable_list : variable ( COMMA_T variable )* -> ( variable )+ ;
    public final CompilerAstParser.variable_list_return variable_list() throws RecognitionException {
        CompilerAstParser.variable_list_return retval = new CompilerAstParser.variable_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token COMMA_T251=null;
        CompilerAstParser.variable_return variable250 = null;

        CompilerAstParser.variable_return variable252 = null;


        SLAST COMMA_T251_tree=null;
        RewriteRuleTokenStream stream_COMMA_T=new RewriteRuleTokenStream(adaptor,"token COMMA_T");
        RewriteRuleSubtreeStream stream_variable=new RewriteRuleSubtreeStream(adaptor,"rule variable");
        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:599:3: ( variable ( COMMA_T variable )* -> ( variable )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:599:5: variable ( COMMA_T variable )*
            {
            pushFollow(FOLLOW_variable_in_variable_list2864);
            variable250=variable();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_variable.add(variable250.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:599:14: ( COMMA_T variable )*
            loop74:
            do {
                int alt74=2;
                int LA74_0 = input.LA(1);

                if ( (LA74_0==COMMA_T) ) {
                    alt74=1;
                }


                switch (alt74) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:599:15: COMMA_T variable
            	    {
            	    COMMA_T251=(Token)match(input,COMMA_T,FOLLOW_COMMA_T_in_variable_list2867); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_COMMA_T.add(COMMA_T251);

            	    pushFollow(FOLLOW_variable_in_variable_list2869);
            	    variable252=variable();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_variable.add(variable252.getTree());

            	    }
            	    break;

            	default :
            	    break loop74;
                }
            } while (true);



            // AST REWRITE
            // elements: variable
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 599:37: -> ( variable )+
            {
                if ( !(stream_variable.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_variable.hasNext() ) {
                    adaptor.addChild(root_0, stream_variable.nextTree());

                }
                stream_variable.reset();

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "variable_list"

    public static class variable_modifiers_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "variable_modifiers"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:602:1: variable_modifiers : ( 'var' | modifier );
    public final CompilerAstParser.variable_modifiers_return variable_modifiers() throws RecognitionException {
        CompilerAstParser.variable_modifiers_return retval = new CompilerAstParser.variable_modifiers_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token string_literal253=null;
        CompilerAstParser.modifier_return modifier254 = null;


        SLAST string_literal253_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:603:3: ( 'var' | modifier )
            int alt75=2;
            int LA75_0 = input.LA(1);

            if ( (LA75_0==167) ) {
                alt75=1;
            }
            else if ( (LA75_0==STATIC_T||(LA75_0>=165 && LA75_0<=166)||(LA75_0>=168 && LA75_0<=170)) ) {
                alt75=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 75, 0, input);

                throw nvae;
            }
            switch (alt75) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:603:5: 'var'
                    {
                    root_0 = (SLAST)adaptor.nil();

                    string_literal253=(Token)match(input,167,FOLLOW_167_in_variable_modifiers2895); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    string_literal253_tree = (SLAST)adaptor.create(string_literal253);
                    adaptor.addChild(root_0, string_literal253_tree);
                    }

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:604:5: modifier
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_modifier_in_variable_modifiers2901);
                    modifier254=modifier();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, modifier254.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "variable_modifiers"

    public static class modifier_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "modifier"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:607:1: modifier : ( 'public' | 'protected' | 'private' | 'static' | 'abstract' | 'final' )+ ;
    public final CompilerAstParser.modifier_return modifier() throws RecognitionException {
        CompilerAstParser.modifier_return retval = new CompilerAstParser.modifier_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token set255=null;

        SLAST set255_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:608:3: ( ( 'public' | 'protected' | 'private' | 'static' | 'abstract' | 'final' )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:608:5: ( 'public' | 'protected' | 'private' | 'static' | 'abstract' | 'final' )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:608:5: ( 'public' | 'protected' | 'private' | 'static' | 'abstract' | 'final' )+
            int cnt76=0;
            loop76:
            do {
                int alt76=2;
                int LA76_0 = input.LA(1);

                if ( (LA76_0==STATIC_T||(LA76_0>=165 && LA76_0<=166)||(LA76_0>=168 && LA76_0<=170)) ) {
                    alt76=1;
                }


                switch (alt76) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:
            	    {
            	    set255=(Token)input.LT(1);
            	    if ( input.LA(1)==STATIC_T||(input.LA(1)>=165 && input.LA(1)<=166)||(input.LA(1)>=168 && input.LA(1)<=170) ) {
            	        input.consume();
            	        if ( state.backtracking==0 ) adaptor.addChild(root_0, (SLAST)adaptor.create(set255));
            	        state.errorRecovery=false;state.failed=false;
            	    }
            	    else {
            	        if (state.backtracking>0) {state.failed=true; return retval;}
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        throw mse;
            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt76 >= 1 ) break loop76;
            	    if (state.backtracking>0) {state.failed=true; return retval;}
                        EarlyExitException eee =
                            new EarlyExitException(76, input);
                        throw eee;
                }
                cnt76++;
            } while (true);


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "modifier"

    public static class directive_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "directive"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:616:1: directive : directive_element ( COMMA_T directive_element )* -> ( directive_element )+ ;
    public final CompilerAstParser.directive_return directive() throws RecognitionException {
        CompilerAstParser.directive_return retval = new CompilerAstParser.directive_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token COMMA_T257=null;
        CompilerAstParser.directive_element_return directive_element256 = null;

        CompilerAstParser.directive_element_return directive_element258 = null;


        SLAST COMMA_T257_tree=null;
        RewriteRuleTokenStream stream_COMMA_T=new RewriteRuleTokenStream(adaptor,"token COMMA_T");
        RewriteRuleSubtreeStream stream_directive_element=new RewriteRuleSubtreeStream(adaptor,"rule directive_element");
        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:617:3: ( directive_element ( COMMA_T directive_element )* -> ( directive_element )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:617:5: directive_element ( COMMA_T directive_element )*
            {
            pushFollow(FOLLOW_directive_element_in_directive2966);
            directive_element256=directive_element();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_directive_element.add(directive_element256.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:617:23: ( COMMA_T directive_element )*
            loop77:
            do {
                int alt77=2;
                int LA77_0 = input.LA(1);

                if ( (LA77_0==COMMA_T) ) {
                    alt77=1;
                }


                switch (alt77) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:617:24: COMMA_T directive_element
            	    {
            	    COMMA_T257=(Token)match(input,COMMA_T,FOLLOW_COMMA_T_in_directive2969); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_COMMA_T.add(COMMA_T257);

            	    pushFollow(FOLLOW_directive_element_in_directive2971);
            	    directive_element258=directive_element();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_directive_element.add(directive_element258.getTree());

            	    }
            	    break;

            	default :
            	    break loop77;
                }
            } while (true);



            // AST REWRITE
            // elements: directive_element
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 617:53: -> ( directive_element )+
            {
                if ( !(stream_directive_element.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_directive_element.hasNext() ) {
                    adaptor.addChild(root_0, stream_directive_element.nextTree());

                }
                stream_directive_element.reset();

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "directive"

    public static class directive_element_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "directive_element"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:620:1: directive_element : IDENTIFIER EQUAL_T expression -> ^( EQUAL_T IDENTIFIER expression ) ;
    public final CompilerAstParser.directive_element_return directive_element() throws RecognitionException {
        CompilerAstParser.directive_element_return retval = new CompilerAstParser.directive_element_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token IDENTIFIER259=null;
        Token EQUAL_T260=null;
        CompilerAstParser.expression_return expression261 = null;


        SLAST IDENTIFIER259_tree=null;
        SLAST EQUAL_T260_tree=null;
        RewriteRuleTokenStream stream_EQUAL_T=new RewriteRuleTokenStream(adaptor,"token EQUAL_T");
        RewriteRuleTokenStream stream_IDENTIFIER=new RewriteRuleTokenStream(adaptor,"token IDENTIFIER");
        RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:630:3: ( IDENTIFIER EQUAL_T expression -> ^( EQUAL_T IDENTIFIER expression ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:630:5: IDENTIFIER EQUAL_T expression
            {
            IDENTIFIER259=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_directive_element3005); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER259);

            EQUAL_T260=(Token)match(input,EQUAL_T,FOLLOW_EQUAL_T_in_directive_element3007); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_EQUAL_T.add(EQUAL_T260);

            pushFollow(FOLLOW_expression_in_directive_element3009);
            expression261=expression();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_expression.add(expression261.getTree());
            if ( state.backtracking==0 ) {

                  token = (CommonToken)IDENTIFIER259;
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(expression261!=null?((Token)expression261.stop):null);
                  endIndex = token.getStopIndex();  
                
            }


            // AST REWRITE
            // elements: IDENTIFIER, expression, EQUAL_T
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 637:6: -> ^( EQUAL_T IDENTIFIER expression )
            {
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:637:10: ^( EQUAL_T IDENTIFIER expression )
                {
                SLAST root_1 = (SLAST)adaptor.nil();
                root_1 = (SLAST)adaptor.becomeRoot(stream_EQUAL_T.nextNode(), root_1);

                adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());
                adaptor.addChild(root_1, stream_expression.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "directive_element"

    public static class expr_list_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "expr_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:640:1: expr_list : expression ( COMMA_T expression )* -> ( expression )+ ;
    public final CompilerAstParser.expr_list_return expr_list() throws RecognitionException {
        CompilerAstParser.expr_list_return retval = new CompilerAstParser.expr_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token COMMA_T263=null;
        CompilerAstParser.expression_return expression262 = null;

        CompilerAstParser.expression_return expression264 = null;


        SLAST COMMA_T263_tree=null;
        RewriteRuleTokenStream stream_COMMA_T=new RewriteRuleTokenStream(adaptor,"token COMMA_T");
        RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");
        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:641:2: ( expression ( COMMA_T expression )* -> ( expression )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:641:4: expression ( COMMA_T expression )*
            {
            pushFollow(FOLLOW_expression_in_expr_list3043);
            expression262=expression();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_expression.add(expression262.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:641:15: ( COMMA_T expression )*
            loop78:
            do {
                int alt78=2;
                int LA78_0 = input.LA(1);

                if ( (LA78_0==COMMA_T) ) {
                    alt78=1;
                }


                switch (alt78) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:641:16: COMMA_T expression
            	    {
            	    COMMA_T263=(Token)match(input,COMMA_T,FOLLOW_COMMA_T_in_expr_list3046); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_COMMA_T.add(COMMA_T263);

            	    pushFollow(FOLLOW_expression_in_expr_list3048);
            	    expression264=expression();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_expression.add(expression264.getTree());

            	    }
            	    break;

            	default :
            	    break loop78;
                }
            } while (true);



            // AST REWRITE
            // elements: expression
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 641:39: -> ( expression )+
            {
                if ( !(stream_expression.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_expression.hasNext() ) {
                    adaptor.addChild(root_0, stream_expression.nextTree());

                }
                stream_expression.reset();

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "expr_list"

    public static class expression_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "expression"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:644:1: expression : logical_text_or_expr -> ^( EXPR logical_text_or_expr ) ;
    public final CompilerAstParser.expression_return expression() throws RecognitionException {
        CompilerAstParser.expression_return retval = new CompilerAstParser.expression_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        CompilerAstParser.logical_text_or_expr_return logical_text_or_expr265 = null;


        RewriteRuleSubtreeStream stream_logical_text_or_expr=new RewriteRuleSubtreeStream(adaptor,"rule logical_text_or_expr");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:654:3: ( logical_text_or_expr -> ^( EXPR logical_text_or_expr ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:654:5: logical_text_or_expr
            {
            pushFollow(FOLLOW_logical_text_or_expr_in_expression3083);
            logical_text_or_expr265=logical_text_or_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_logical_text_or_expr.add(logical_text_or_expr265.getTree());
            if ( state.backtracking==0 ) {

                  token = (CommonToken)(logical_text_or_expr265!=null?((Token)logical_text_or_expr265.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(logical_text_or_expr265!=null?((Token)logical_text_or_expr265.stop):null);
                  endIndex = token.getStopIndex();
                
            }


            // AST REWRITE
            // elements: logical_text_or_expr
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 661:5: -> ^( EXPR logical_text_or_expr )
            {
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:661:9: ^( EXPR logical_text_or_expr )
                {
                SLAST root_1 = (SLAST)adaptor.nil();
                root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(EXPR, "EXPR"), root_1);

                adaptor.addChild(root_1, stream_logical_text_or_expr.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "expression"

    public static class logical_text_or_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "logical_text_or_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:664:1: logical_text_or_expr : e1= logical_text_xor_expr ( OR_T e2= logical_text_xor_expr )* ;
    public final CompilerAstParser.logical_text_or_expr_return logical_text_or_expr() throws RecognitionException {
        CompilerAstParser.logical_text_or_expr_return retval = new CompilerAstParser.logical_text_or_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token OR_T266=null;
        CompilerAstParser.logical_text_xor_expr_return e1 = null;

        CompilerAstParser.logical_text_xor_expr_return e2 = null;


        SLAST OR_T266_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:674:3: (e1= logical_text_xor_expr ( OR_T e2= logical_text_xor_expr )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:674:5: e1= logical_text_xor_expr ( OR_T e2= logical_text_xor_expr )*
            {
            root_0 = (SLAST)adaptor.nil();

            pushFollow(FOLLOW_logical_text_xor_expr_in_logical_text_or_expr3126);
            e1=logical_text_xor_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, e1.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:674:30: ( OR_T e2= logical_text_xor_expr )*
            loop79:
            do {
                int alt79=2;
                int LA79_0 = input.LA(1);

                if ( (LA79_0==OR_T) ) {
                    alt79=1;
                }


                switch (alt79) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:674:31: OR_T e2= logical_text_xor_expr
            	    {
            	    OR_T266=(Token)match(input,OR_T,FOLLOW_OR_T_in_logical_text_or_expr3129); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    OR_T266_tree = (SLAST)adaptor.create(OR_T266);
            	    root_0 = (SLAST)adaptor.becomeRoot(OR_T266_tree, root_0);
            	    }
            	    pushFollow(FOLLOW_logical_text_xor_expr_in_logical_text_or_expr3134);
            	    e2=logical_text_xor_expr();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, e2.getTree());

            	    }
            	    break;

            	default :
            	    break loop79;
                }
            } while (true);

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(e1!=null?((Token)e1.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(e1!=null?((Token)e1.stop):null);
                  if ((e2!=null?input.toString(e2.start,e2.stop):null) != null) {
                    token = (CommonToken)(e2!=null?((Token)e2.stop):null);
                  }
                  endIndex = token.getStopIndex();
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "logical_text_or_expr"

    public static class logical_text_xor_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "logical_text_xor_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:686:1: logical_text_xor_expr : e1= logical_text_and_expr ( XOR_T e2= logical_text_and_expr )* ;
    public final CompilerAstParser.logical_text_xor_expr_return logical_text_xor_expr() throws RecognitionException {
        CompilerAstParser.logical_text_xor_expr_return retval = new CompilerAstParser.logical_text_xor_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token XOR_T267=null;
        CompilerAstParser.logical_text_and_expr_return e1 = null;

        CompilerAstParser.logical_text_and_expr_return e2 = null;


        SLAST XOR_T267_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:696:3: (e1= logical_text_and_expr ( XOR_T e2= logical_text_and_expr )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:696:5: e1= logical_text_and_expr ( XOR_T e2= logical_text_and_expr )*
            {
            root_0 = (SLAST)adaptor.nil();

            pushFollow(FOLLOW_logical_text_and_expr_in_logical_text_xor_expr3165);
            e1=logical_text_and_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, e1.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:696:30: ( XOR_T e2= logical_text_and_expr )*
            loop80:
            do {
                int alt80=2;
                int LA80_0 = input.LA(1);

                if ( (LA80_0==XOR_T) ) {
                    alt80=1;
                }


                switch (alt80) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:696:31: XOR_T e2= logical_text_and_expr
            	    {
            	    XOR_T267=(Token)match(input,XOR_T,FOLLOW_XOR_T_in_logical_text_xor_expr3168); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    XOR_T267_tree = (SLAST)adaptor.create(XOR_T267);
            	    root_0 = (SLAST)adaptor.becomeRoot(XOR_T267_tree, root_0);
            	    }
            	    pushFollow(FOLLOW_logical_text_and_expr_in_logical_text_xor_expr3173);
            	    e2=logical_text_and_expr();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, e2.getTree());

            	    }
            	    break;

            	default :
            	    break loop80;
                }
            } while (true);

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(e1!=null?((Token)e1.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(e1!=null?((Token)e1.stop):null);
                  if ((e2!=null?input.toString(e2.start,e2.stop):null) != null) {
                    token = (CommonToken)(e2!=null?((Token)e2.stop):null);
                  }
                  endIndex = token.getStopIndex();
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "logical_text_xor_expr"

    public static class logical_text_and_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "logical_text_and_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:708:1: logical_text_and_expr : e1= assignment_expr ( AND_T e2= assignment_expr )* ;
    public final CompilerAstParser.logical_text_and_expr_return logical_text_and_expr() throws RecognitionException {
        CompilerAstParser.logical_text_and_expr_return retval = new CompilerAstParser.logical_text_and_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token AND_T268=null;
        CompilerAstParser.assignment_expr_return e1 = null;

        CompilerAstParser.assignment_expr_return e2 = null;


        SLAST AND_T268_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:718:3: (e1= assignment_expr ( AND_T e2= assignment_expr )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:718:5: e1= assignment_expr ( AND_T e2= assignment_expr )*
            {
            root_0 = (SLAST)adaptor.nil();

            pushFollow(FOLLOW_assignment_expr_in_logical_text_and_expr3204);
            e1=assignment_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, e1.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:718:24: ( AND_T e2= assignment_expr )*
            loop81:
            do {
                int alt81=2;
                int LA81_0 = input.LA(1);

                if ( (LA81_0==AND_T) ) {
                    alt81=1;
                }


                switch (alt81) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:718:25: AND_T e2= assignment_expr
            	    {
            	    AND_T268=(Token)match(input,AND_T,FOLLOW_AND_T_in_logical_text_and_expr3207); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    AND_T268_tree = (SLAST)adaptor.create(AND_T268);
            	    root_0 = (SLAST)adaptor.becomeRoot(AND_T268_tree, root_0);
            	    }
            	    pushFollow(FOLLOW_assignment_expr_in_logical_text_and_expr3212);
            	    e2=assignment_expr();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, e2.getTree());

            	    }
            	    break;

            	default :
            	    break loop81;
                }
            } while (true);

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(e1!=null?((Token)e1.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(e1!=null?((Token)e1.stop):null);
                  if ((e2!=null?input.toString(e2.start,e2.stop):null) != null) {
                    token = (CommonToken)(e2!=null?((Token)e2.stop):null);
                  }
                  endIndex = token.getStopIndex();
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "logical_text_and_expr"

    public static class assignment_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "assignment_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:730:1: assignment_expr : e1= conditional_expr ( assignment_operator e2= conditional_expr )* ;
    public final CompilerAstParser.assignment_expr_return assignment_expr() throws RecognitionException {
        CompilerAstParser.assignment_expr_return retval = new CompilerAstParser.assignment_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        CompilerAstParser.conditional_expr_return e1 = null;

        CompilerAstParser.conditional_expr_return e2 = null;

        CompilerAstParser.assignment_operator_return assignment_operator269 = null;




          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:740:3: (e1= conditional_expr ( assignment_operator e2= conditional_expr )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:740:5: e1= conditional_expr ( assignment_operator e2= conditional_expr )*
            {
            root_0 = (SLAST)adaptor.nil();

            pushFollow(FOLLOW_conditional_expr_in_assignment_expr3243);
            e1=conditional_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, e1.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:740:25: ( assignment_operator e2= conditional_expr )*
            loop82:
            do {
                int alt82=2;
                int LA82_0 = input.LA(1);

                if ( (LA82_0==EQUAL_T||(LA82_0>=PLUS_EQ && LA82_0<=RMOVE_EQ)) ) {
                    alt82=1;
                }


                switch (alt82) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:740:26: assignment_operator e2= conditional_expr
            	    {
            	    pushFollow(FOLLOW_assignment_operator_in_assignment_expr3246);
            	    assignment_operator269=assignment_operator();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) root_0 = (SLAST)adaptor.becomeRoot(assignment_operator269.getTree(), root_0);
            	    pushFollow(FOLLOW_conditional_expr_in_assignment_expr3251);
            	    e2=conditional_expr();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, e2.getTree());

            	    }
            	    break;

            	default :
            	    break loop82;
                }
            } while (true);

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(e1!=null?((Token)e1.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(e1!=null?((Token)e1.stop):null);
                  if ((e2!=null?input.toString(e2.start,e2.stop):null) != null) {
                    token = (CommonToken)(e2!=null?((Token)e2.stop):null);
                  }
                  endIndex = token.getStopIndex();
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "assignment_expr"

    public static class assignment_operator_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "assignment_operator"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:752:1: assignment_operator : ( EQUAL_T | PLUS_EQ | MINUS_EQ | MUL_EQ | DIV_EQ | DOT_EQ | PERCENT_EQ | BIT_AND_EQ | BIT_OR_EQ | POWER_EQ | LMOVE_EQ | RMOVE_EQ );
    public final CompilerAstParser.assignment_operator_return assignment_operator() throws RecognitionException {
        CompilerAstParser.assignment_operator_return retval = new CompilerAstParser.assignment_operator_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token set270=null;

        SLAST set270_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:753:3: ( EQUAL_T | PLUS_EQ | MINUS_EQ | MUL_EQ | DIV_EQ | DOT_EQ | PERCENT_EQ | BIT_AND_EQ | BIT_OR_EQ | POWER_EQ | LMOVE_EQ | RMOVE_EQ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:
            {
            root_0 = (SLAST)adaptor.nil();

            set270=(Token)input.LT(1);
            if ( input.LA(1)==EQUAL_T||(input.LA(1)>=PLUS_EQ && input.LA(1)<=RMOVE_EQ) ) {
                input.consume();
                if ( state.backtracking==0 ) adaptor.addChild(root_0, (SLAST)adaptor.create(set270));
                state.errorRecovery=false;state.failed=false;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                MismatchedSetException mse = new MismatchedSetException(null,input);
                throw mse;
            }


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "assignment_operator"

    public static class conditional_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "conditional_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:767:1: conditional_expr : (ll= logical_or_expr -> $ll) ( QUESTION_T ( expression )? COLON_T lr= logical_or_expr -> ^( QUESTION_T $ll ^( COLON_T ( expression )? $lr) ) )? ;
    public final CompilerAstParser.conditional_expr_return conditional_expr() throws RecognitionException {
        CompilerAstParser.conditional_expr_return retval = new CompilerAstParser.conditional_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token QUESTION_T271=null;
        Token COLON_T273=null;
        CompilerAstParser.logical_or_expr_return ll = null;

        CompilerAstParser.logical_or_expr_return lr = null;

        CompilerAstParser.expression_return expression272 = null;


        SLAST QUESTION_T271_tree=null;
        SLAST COLON_T273_tree=null;
        RewriteRuleTokenStream stream_QUESTION_T=new RewriteRuleTokenStream(adaptor,"token QUESTION_T");
        RewriteRuleTokenStream stream_COLON_T=new RewriteRuleTokenStream(adaptor,"token COLON_T");
        RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");
        RewriteRuleSubtreeStream stream_logical_or_expr=new RewriteRuleSubtreeStream(adaptor,"rule logical_or_expr");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:777:3: ( (ll= logical_or_expr -> $ll) ( QUESTION_T ( expression )? COLON_T lr= logical_or_expr -> ^( QUESTION_T $ll ^( COLON_T ( expression )? $lr) ) )? )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:777:5: (ll= logical_or_expr -> $ll) ( QUESTION_T ( expression )? COLON_T lr= logical_or_expr -> ^( QUESTION_T $ll ^( COLON_T ( expression )? $lr) ) )?
            {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:777:5: (ll= logical_or_expr -> $ll)
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:777:6: ll= logical_or_expr
            {
            pushFollow(FOLLOW_logical_or_expr_in_conditional_expr3388);
            ll=logical_or_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_logical_or_expr.add(ll.getTree());
            if ( state.backtracking==0 ) {

                  token = (CommonToken)(ll!=null?((Token)ll.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(ll!=null?((Token)ll.stop):null);
                  endIndex = token.getStopIndex();
                
            }


            // AST REWRITE
            // elements: ll
            // token labels: 
            // rule labels: retval, ll
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
            RewriteRuleSubtreeStream stream_ll=new RewriteRuleSubtreeStream(adaptor,"rule ll",ll!=null?ll.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 784:4: -> $ll
            {
                adaptor.addChild(root_0, stream_ll.nextTree());

            }

            retval.tree = root_0;}
            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:785:4: ( QUESTION_T ( expression )? COLON_T lr= logical_or_expr -> ^( QUESTION_T $ll ^( COLON_T ( expression )? $lr) ) )?
            int alt84=2;
            int LA84_0 = input.LA(1);

            if ( (LA84_0==QUESTION_T) ) {
                alt84=1;
            }
            switch (alt84) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:785:5: QUESTION_T ( expression )? COLON_T lr= logical_or_expr
                    {
                    QUESTION_T271=(Token)match(input,QUESTION_T,FOLLOW_QUESTION_T_in_conditional_expr3407); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_QUESTION_T.add(QUESTION_T271);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:785:16: ( expression )?
                    int alt83=2;
                    int LA83_0 = input.LA(1);

                    if ( (LA83_0==LEFT_PARETHESIS||LA83_0==IDENTIFIER||(LA83_0>=FUNCTION_T && LA83_0<=REF_T)||LA83_0==STRINGLITERAL||(LA83_0>=PLUS_T && LA83_0<=MINUS_T)||(LA83_0>=UNSET_T && LA83_0<=MINUS_MINUS_T)||(LA83_0>=AT_T && LA83_0<=BACKTRICKLITERAL)||(LA83_0>=DOLLAR_T && LA83_0<=DOUBLELITERRAL)||(LA83_0>=179 && LA83_0<=185)) ) {
                        alt83=1;
                    }
                    switch (alt83) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:785:16: expression
                            {
                            pushFollow(FOLLOW_expression_in_conditional_expr3409);
                            expression272=expression();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_expression.add(expression272.getTree());

                            }
                            break;

                    }

                    COLON_T273=(Token)match(input,COLON_T,FOLLOW_COLON_T_in_conditional_expr3412); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_COLON_T.add(COLON_T273);

                    pushFollow(FOLLOW_logical_or_expr_in_conditional_expr3416);
                    lr=logical_or_expr();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_logical_or_expr.add(lr.getTree());
                    if ( state.backtracking==0 ) {

                          token = (CommonToken)(lr!=null?((Token)lr.stop):null);
                          endIndex = token.getStopIndex();
                        
                    }


                    // AST REWRITE
                    // elements: lr, ll, QUESTION_T, expression, COLON_T
                    // token labels: 
                    // rule labels: retval, ll, lr
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
                    RewriteRuleSubtreeStream stream_ll=new RewriteRuleSubtreeStream(adaptor,"rule ll",ll!=null?ll.tree:null);
                    RewriteRuleSubtreeStream stream_lr=new RewriteRuleSubtreeStream(adaptor,"rule lr",lr!=null?lr.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 789:5: -> ^( QUESTION_T $ll ^( COLON_T ( expression )? $lr) )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:789:8: ^( QUESTION_T $ll ^( COLON_T ( expression )? $lr) )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_QUESTION_T.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_ll.nextTree());
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:789:25: ^( COLON_T ( expression )? $lr)
                        {
                        SLAST root_2 = (SLAST)adaptor.nil();
                        root_2 = (SLAST)adaptor.becomeRoot(stream_COLON_T.nextNode(), root_2);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:789:35: ( expression )?
                        if ( stream_expression.hasNext() ) {
                            adaptor.addChild(root_2, stream_expression.nextTree());

                        }
                        stream_expression.reset();
                        adaptor.addChild(root_2, stream_lr.nextTree());

                        adaptor.addChild(root_1, root_2);
                        }

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "conditional_expr"

    public static class logical_or_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "logical_or_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:792:1: logical_or_expr : e1= logical_and_expr ( LOGICAL_OR_T e2= logical_and_expr )* ;
    public final CompilerAstParser.logical_or_expr_return logical_or_expr() throws RecognitionException {
        CompilerAstParser.logical_or_expr_return retval = new CompilerAstParser.logical_or_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token LOGICAL_OR_T274=null;
        CompilerAstParser.logical_and_expr_return e1 = null;

        CompilerAstParser.logical_and_expr_return e2 = null;


        SLAST LOGICAL_OR_T274_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:802:3: (e1= logical_and_expr ( LOGICAL_OR_T e2= logical_and_expr )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:802:5: e1= logical_and_expr ( LOGICAL_OR_T e2= logical_and_expr )*
            {
            root_0 = (SLAST)adaptor.nil();

            pushFollow(FOLLOW_logical_and_expr_in_logical_or_expr3466);
            e1=logical_and_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, e1.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:802:25: ( LOGICAL_OR_T e2= logical_and_expr )*
            loop85:
            do {
                int alt85=2;
                int LA85_0 = input.LA(1);

                if ( (LA85_0==LOGICAL_OR_T) ) {
                    alt85=1;
                }


                switch (alt85) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:802:26: LOGICAL_OR_T e2= logical_and_expr
            	    {
            	    LOGICAL_OR_T274=(Token)match(input,LOGICAL_OR_T,FOLLOW_LOGICAL_OR_T_in_logical_or_expr3469); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    LOGICAL_OR_T274_tree = (SLAST)adaptor.create(LOGICAL_OR_T274);
            	    root_0 = (SLAST)adaptor.becomeRoot(LOGICAL_OR_T274_tree, root_0);
            	    }
            	    pushFollow(FOLLOW_logical_and_expr_in_logical_or_expr3474);
            	    e2=logical_and_expr();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, e2.getTree());

            	    }
            	    break;

            	default :
            	    break loop85;
                }
            } while (true);

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(e1!=null?((Token)e1.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(e1!=null?((Token)e1.stop):null);
                  if ((e2!=null?input.toString(e2.start,e2.stop):null) != null) {
                    token = (CommonToken)(e2!=null?((Token)e2.stop):null);
                  }
                  endIndex = token.getStopIndex();
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "logical_or_expr"

    public static class logical_and_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "logical_and_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:814:1: logical_and_expr : e1= bitwise_or_expr ( LOGICAL_AND_T e2= bitwise_or_expr )* ;
    public final CompilerAstParser.logical_and_expr_return logical_and_expr() throws RecognitionException {
        CompilerAstParser.logical_and_expr_return retval = new CompilerAstParser.logical_and_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token LOGICAL_AND_T275=null;
        CompilerAstParser.bitwise_or_expr_return e1 = null;

        CompilerAstParser.bitwise_or_expr_return e2 = null;


        SLAST LOGICAL_AND_T275_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:824:3: (e1= bitwise_or_expr ( LOGICAL_AND_T e2= bitwise_or_expr )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:824:5: e1= bitwise_or_expr ( LOGICAL_AND_T e2= bitwise_or_expr )*
            {
            root_0 = (SLAST)adaptor.nil();

            pushFollow(FOLLOW_bitwise_or_expr_in_logical_and_expr3505);
            e1=bitwise_or_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, e1.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:824:24: ( LOGICAL_AND_T e2= bitwise_or_expr )*
            loop86:
            do {
                int alt86=2;
                int LA86_0 = input.LA(1);

                if ( (LA86_0==LOGICAL_AND_T) ) {
                    alt86=1;
                }


                switch (alt86) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:824:25: LOGICAL_AND_T e2= bitwise_or_expr
            	    {
            	    LOGICAL_AND_T275=(Token)match(input,LOGICAL_AND_T,FOLLOW_LOGICAL_AND_T_in_logical_and_expr3508); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    LOGICAL_AND_T275_tree = (SLAST)adaptor.create(LOGICAL_AND_T275);
            	    root_0 = (SLAST)adaptor.becomeRoot(LOGICAL_AND_T275_tree, root_0);
            	    }
            	    pushFollow(FOLLOW_bitwise_or_expr_in_logical_and_expr3513);
            	    e2=bitwise_or_expr();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, e2.getTree());

            	    }
            	    break;

            	default :
            	    break loop86;
                }
            } while (true);

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(e1!=null?((Token)e1.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(e1!=null?((Token)e1.stop):null);
                  if ((e2!=null?input.toString(e2.start,e2.stop):null) != null) {
                    token = (CommonToken)(e2!=null?((Token)e2.stop):null);
                  }
                  endIndex = token.getStopIndex();
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "logical_and_expr"

    public static class bitwise_or_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "bitwise_or_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:836:1: bitwise_or_expr : e1= bitwise_xor_expr ( BIT_OR_T e2= bitwise_xor_expr )* ;
    public final CompilerAstParser.bitwise_or_expr_return bitwise_or_expr() throws RecognitionException {
        CompilerAstParser.bitwise_or_expr_return retval = new CompilerAstParser.bitwise_or_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token BIT_OR_T276=null;
        CompilerAstParser.bitwise_xor_expr_return e1 = null;

        CompilerAstParser.bitwise_xor_expr_return e2 = null;


        SLAST BIT_OR_T276_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:846:3: (e1= bitwise_xor_expr ( BIT_OR_T e2= bitwise_xor_expr )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:846:5: e1= bitwise_xor_expr ( BIT_OR_T e2= bitwise_xor_expr )*
            {
            root_0 = (SLAST)adaptor.nil();

            pushFollow(FOLLOW_bitwise_xor_expr_in_bitwise_or_expr3544);
            e1=bitwise_xor_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, e1.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:846:25: ( BIT_OR_T e2= bitwise_xor_expr )*
            loop87:
            do {
                int alt87=2;
                int LA87_0 = input.LA(1);

                if ( (LA87_0==BIT_OR_T) ) {
                    alt87=1;
                }


                switch (alt87) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:846:26: BIT_OR_T e2= bitwise_xor_expr
            	    {
            	    BIT_OR_T276=(Token)match(input,BIT_OR_T,FOLLOW_BIT_OR_T_in_bitwise_or_expr3547); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    BIT_OR_T276_tree = (SLAST)adaptor.create(BIT_OR_T276);
            	    root_0 = (SLAST)adaptor.becomeRoot(BIT_OR_T276_tree, root_0);
            	    }
            	    pushFollow(FOLLOW_bitwise_xor_expr_in_bitwise_or_expr3552);
            	    e2=bitwise_xor_expr();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, e2.getTree());

            	    }
            	    break;

            	default :
            	    break loop87;
                }
            } while (true);

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(e1!=null?((Token)e1.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(e1!=null?((Token)e1.stop):null);
                  if ((e2!=null?input.toString(e2.start,e2.stop):null) != null) {
                    token = (CommonToken)(e2!=null?((Token)e2.stop):null);
                  }
                  endIndex = token.getStopIndex();
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "bitwise_or_expr"

    public static class bitwise_xor_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "bitwise_xor_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:858:1: bitwise_xor_expr : e1= bitwise_and_expr ( POWER_T e2= bitwise_and_expr )* ;
    public final CompilerAstParser.bitwise_xor_expr_return bitwise_xor_expr() throws RecognitionException {
        CompilerAstParser.bitwise_xor_expr_return retval = new CompilerAstParser.bitwise_xor_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token POWER_T277=null;
        CompilerAstParser.bitwise_and_expr_return e1 = null;

        CompilerAstParser.bitwise_and_expr_return e2 = null;


        SLAST POWER_T277_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:868:3: (e1= bitwise_and_expr ( POWER_T e2= bitwise_and_expr )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:868:5: e1= bitwise_and_expr ( POWER_T e2= bitwise_and_expr )*
            {
            root_0 = (SLAST)adaptor.nil();

            pushFollow(FOLLOW_bitwise_and_expr_in_bitwise_xor_expr3583);
            e1=bitwise_and_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, e1.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:868:25: ( POWER_T e2= bitwise_and_expr )*
            loop88:
            do {
                int alt88=2;
                int LA88_0 = input.LA(1);

                if ( (LA88_0==POWER_T) ) {
                    alt88=1;
                }


                switch (alt88) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:868:26: POWER_T e2= bitwise_and_expr
            	    {
            	    POWER_T277=(Token)match(input,POWER_T,FOLLOW_POWER_T_in_bitwise_xor_expr3586); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    POWER_T277_tree = (SLAST)adaptor.create(POWER_T277);
            	    root_0 = (SLAST)adaptor.becomeRoot(POWER_T277_tree, root_0);
            	    }
            	    pushFollow(FOLLOW_bitwise_and_expr_in_bitwise_xor_expr3591);
            	    e2=bitwise_and_expr();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, e2.getTree());

            	    }
            	    break;

            	default :
            	    break loop88;
                }
            } while (true);

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(e1!=null?((Token)e1.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(e1!=null?((Token)e1.stop):null);
                  if ((e2!=null?input.toString(e2.start,e2.stop):null) != null) {
                    token = (CommonToken)(e2!=null?((Token)e2.stop):null);
                  }
                  endIndex = token.getStopIndex();
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "bitwise_xor_expr"

    public static class bitwise_and_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "bitwise_and_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:880:1: bitwise_and_expr : e1= concat_expr ( DOT_T e2= concat_expr )* ;
    public final CompilerAstParser.bitwise_and_expr_return bitwise_and_expr() throws RecognitionException {
        CompilerAstParser.bitwise_and_expr_return retval = new CompilerAstParser.bitwise_and_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token DOT_T278=null;
        CompilerAstParser.concat_expr_return e1 = null;

        CompilerAstParser.concat_expr_return e2 = null;


        SLAST DOT_T278_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:890:3: (e1= concat_expr ( DOT_T e2= concat_expr )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:890:5: e1= concat_expr ( DOT_T e2= concat_expr )*
            {
            root_0 = (SLAST)adaptor.nil();

            pushFollow(FOLLOW_concat_expr_in_bitwise_and_expr3622);
            e1=concat_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, e1.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:890:20: ( DOT_T e2= concat_expr )*
            loop89:
            do {
                int alt89=2;
                int LA89_0 = input.LA(1);

                if ( (LA89_0==DOT_T) ) {
                    alt89=1;
                }


                switch (alt89) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:890:21: DOT_T e2= concat_expr
            	    {
            	    DOT_T278=(Token)match(input,DOT_T,FOLLOW_DOT_T_in_bitwise_and_expr3625); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    DOT_T278_tree = (SLAST)adaptor.create(DOT_T278);
            	    root_0 = (SLAST)adaptor.becomeRoot(DOT_T278_tree, root_0);
            	    }
            	    pushFollow(FOLLOW_concat_expr_in_bitwise_and_expr3630);
            	    e2=concat_expr();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, e2.getTree());

            	    }
            	    break;

            	default :
            	    break loop89;
                }
            } while (true);

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(e1!=null?((Token)e1.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(e1!=null?((Token)e1.stop):null);
                  if ((e2!=null?input.toString(e2.start,e2.stop):null) != null) {
                    token = (CommonToken)(e2!=null?((Token)e2.stop):null);
                  }
                  endIndex = token.getStopIndex();
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "bitwise_and_expr"

    public static class concat_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "concat_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:902:1: concat_expr : e1= equality_expr ( REF_T e2= equality_expr )* ;
    public final CompilerAstParser.concat_expr_return concat_expr() throws RecognitionException {
        CompilerAstParser.concat_expr_return retval = new CompilerAstParser.concat_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token REF_T279=null;
        CompilerAstParser.equality_expr_return e1 = null;

        CompilerAstParser.equality_expr_return e2 = null;


        SLAST REF_T279_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:912:3: (e1= equality_expr ( REF_T e2= equality_expr )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:912:5: e1= equality_expr ( REF_T e2= equality_expr )*
            {
            root_0 = (SLAST)adaptor.nil();

            pushFollow(FOLLOW_equality_expr_in_concat_expr3661);
            e1=equality_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, e1.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:912:22: ( REF_T e2= equality_expr )*
            loop90:
            do {
                int alt90=2;
                int LA90_0 = input.LA(1);

                if ( (LA90_0==REF_T) ) {
                    alt90=1;
                }


                switch (alt90) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:912:23: REF_T e2= equality_expr
            	    {
            	    REF_T279=(Token)match(input,REF_T,FOLLOW_REF_T_in_concat_expr3664); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    REF_T279_tree = (SLAST)adaptor.create(REF_T279);
            	    root_0 = (SLAST)adaptor.becomeRoot(REF_T279_tree, root_0);
            	    }
            	    pushFollow(FOLLOW_equality_expr_in_concat_expr3669);
            	    e2=equality_expr();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, e2.getTree());

            	    }
            	    break;

            	default :
            	    break loop90;
                }
            } while (true);

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(e1!=null?((Token)e1.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(e1!=null?((Token)e1.stop):null);
                  if ((e2!=null?input.toString(e2.start,e2.stop):null) != null) {
                    token = (CommonToken)(e2!=null?((Token)e2.stop):null);
                  }
                  endIndex = token.getStopIndex();
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "concat_expr"

    public static class equality_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "equality_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:924:1: equality_expr : e1= relational_expr ( ( EQUAL_EQUAL_T | NOT_EQUAL_T | EQUAL_EQUAL_EQUAL_T | NOT_EQUAL_EQUAL_T ) e2= relational_expr )* ;
    public final CompilerAstParser.equality_expr_return equality_expr() throws RecognitionException {
        CompilerAstParser.equality_expr_return retval = new CompilerAstParser.equality_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token set280=null;
        CompilerAstParser.relational_expr_return e1 = null;

        CompilerAstParser.relational_expr_return e2 = null;


        SLAST set280_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:934:3: (e1= relational_expr ( ( EQUAL_EQUAL_T | NOT_EQUAL_T | EQUAL_EQUAL_EQUAL_T | NOT_EQUAL_EQUAL_T ) e2= relational_expr )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:934:5: e1= relational_expr ( ( EQUAL_EQUAL_T | NOT_EQUAL_T | EQUAL_EQUAL_EQUAL_T | NOT_EQUAL_EQUAL_T ) e2= relational_expr )*
            {
            root_0 = (SLAST)adaptor.nil();

            pushFollow(FOLLOW_relational_expr_in_equality_expr3700);
            e1=relational_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, e1.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:934:24: ( ( EQUAL_EQUAL_T | NOT_EQUAL_T | EQUAL_EQUAL_EQUAL_T | NOT_EQUAL_EQUAL_T ) e2= relational_expr )*
            loop91:
            do {
                int alt91=2;
                int LA91_0 = input.LA(1);

                if ( ((LA91_0>=EQUAL_EQUAL_T && LA91_0<=NOT_EQUAL_EQUAL_T)) ) {
                    alt91=1;
                }


                switch (alt91) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:934:25: ( EQUAL_EQUAL_T | NOT_EQUAL_T | EQUAL_EQUAL_EQUAL_T | NOT_EQUAL_EQUAL_T ) e2= relational_expr
            	    {
            	    set280=(Token)input.LT(1);
            	    set280=(Token)input.LT(1);
            	    if ( (input.LA(1)>=EQUAL_EQUAL_T && input.LA(1)<=NOT_EQUAL_EQUAL_T) ) {
            	        input.consume();
            	        if ( state.backtracking==0 ) root_0 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(set280), root_0);
            	        state.errorRecovery=false;state.failed=false;
            	    }
            	    else {
            	        if (state.backtracking>0) {state.failed=true; return retval;}
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        throw mse;
            	    }

            	    pushFollow(FOLLOW_relational_expr_in_equality_expr3722);
            	    e2=relational_expr();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, e2.getTree());

            	    }
            	    break;

            	default :
            	    break loop91;
                }
            } while (true);

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(e1!=null?((Token)e1.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(e1!=null?((Token)e1.stop):null);
                  if ((e2!=null?input.toString(e2.start,e2.stop):null) != null) {
                    token = (CommonToken)(e2!=null?((Token)e2.stop):null);
                  }
                  endIndex = token.getStopIndex();
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "equality_expr"

    public static class relational_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "relational_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:946:1: relational_expr : e1= shift_expr ( ( LT_T | MT_T | LE_T | ME_T ) e2= shift_expr )* ;
    public final CompilerAstParser.relational_expr_return relational_expr() throws RecognitionException {
        CompilerAstParser.relational_expr_return retval = new CompilerAstParser.relational_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token set281=null;
        CompilerAstParser.shift_expr_return e1 = null;

        CompilerAstParser.shift_expr_return e2 = null;


        SLAST set281_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:956:3: (e1= shift_expr ( ( LT_T | MT_T | LE_T | ME_T ) e2= shift_expr )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:956:5: e1= shift_expr ( ( LT_T | MT_T | LE_T | ME_T ) e2= shift_expr )*
            {
            root_0 = (SLAST)adaptor.nil();

            pushFollow(FOLLOW_shift_expr_in_relational_expr3753);
            e1=shift_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, e1.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:956:19: ( ( LT_T | MT_T | LE_T | ME_T ) e2= shift_expr )*
            loop92:
            do {
                int alt92=2;
                int LA92_0 = input.LA(1);

                if ( ((LA92_0>=LT_T && LA92_0<=ME_T)) ) {
                    alt92=1;
                }


                switch (alt92) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:956:20: ( LT_T | MT_T | LE_T | ME_T ) e2= shift_expr
            	    {
            	    set281=(Token)input.LT(1);
            	    set281=(Token)input.LT(1);
            	    if ( (input.LA(1)>=LT_T && input.LA(1)<=ME_T) ) {
            	        input.consume();
            	        if ( state.backtracking==0 ) root_0 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(set281), root_0);
            	        state.errorRecovery=false;state.failed=false;
            	    }
            	    else {
            	        if (state.backtracking>0) {state.failed=true; return retval;}
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        throw mse;
            	    }

            	    pushFollow(FOLLOW_shift_expr_in_relational_expr3775);
            	    e2=shift_expr();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, e2.getTree());

            	    }
            	    break;

            	default :
            	    break loop92;
                }
            } while (true);

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(e1!=null?((Token)e1.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(e1!=null?((Token)e1.stop):null);
                  if ((e2!=null?input.toString(e2.start,e2.stop):null) != null) {
                    token = (CommonToken)(e2!=null?((Token)e2.stop):null);
                  }
                  endIndex = token.getStopIndex();
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "relational_expr"

    public static class shift_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "shift_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:968:1: shift_expr : e1= additive_expr ( ( LSHIFT_T | RSHIFT_T ) e2= additive_expr )* ;
    public final CompilerAstParser.shift_expr_return shift_expr() throws RecognitionException {
        CompilerAstParser.shift_expr_return retval = new CompilerAstParser.shift_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token set282=null;
        CompilerAstParser.additive_expr_return e1 = null;

        CompilerAstParser.additive_expr_return e2 = null;


        SLAST set282_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:978:3: (e1= additive_expr ( ( LSHIFT_T | RSHIFT_T ) e2= additive_expr )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:978:5: e1= additive_expr ( ( LSHIFT_T | RSHIFT_T ) e2= additive_expr )*
            {
            root_0 = (SLAST)adaptor.nil();

            pushFollow(FOLLOW_additive_expr_in_shift_expr3806);
            e1=additive_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, e1.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:978:22: ( ( LSHIFT_T | RSHIFT_T ) e2= additive_expr )*
            loop93:
            do {
                int alt93=2;
                int LA93_0 = input.LA(1);

                if ( ((LA93_0>=LSHIFT_T && LA93_0<=RSHIFT_T)) ) {
                    alt93=1;
                }


                switch (alt93) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:978:23: ( LSHIFT_T | RSHIFT_T ) e2= additive_expr
            	    {
            	    set282=(Token)input.LT(1);
            	    set282=(Token)input.LT(1);
            	    if ( (input.LA(1)>=LSHIFT_T && input.LA(1)<=RSHIFT_T) ) {
            	        input.consume();
            	        if ( state.backtracking==0 ) root_0 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(set282), root_0);
            	        state.errorRecovery=false;state.failed=false;
            	    }
            	    else {
            	        if (state.backtracking>0) {state.failed=true; return retval;}
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        throw mse;
            	    }

            	    pushFollow(FOLLOW_additive_expr_in_shift_expr3820);
            	    e2=additive_expr();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, e2.getTree());

            	    }
            	    break;

            	default :
            	    break loop93;
                }
            } while (true);

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(e1!=null?((Token)e1.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(e1!=null?((Token)e1.stop):null);
                  if ((e2!=null?input.toString(e2.start,e2.stop):null) != null) {
                    token = (CommonToken)(e2!=null?((Token)e2.stop):null);
                  }
                  endIndex = token.getStopIndex();
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "shift_expr"

    public static class additive_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "additive_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:990:1: additive_expr : e1= multiplicative_expr ( ( PLUS_T | MINUS_T ) e2= multiplicative_expr )* ;
    public final CompilerAstParser.additive_expr_return additive_expr() throws RecognitionException {
        CompilerAstParser.additive_expr_return retval = new CompilerAstParser.additive_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token set283=null;
        CompilerAstParser.multiplicative_expr_return e1 = null;

        CompilerAstParser.multiplicative_expr_return e2 = null;


        SLAST set283_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1000:3: (e1= multiplicative_expr ( ( PLUS_T | MINUS_T ) e2= multiplicative_expr )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1000:5: e1= multiplicative_expr ( ( PLUS_T | MINUS_T ) e2= multiplicative_expr )*
            {
            root_0 = (SLAST)adaptor.nil();

            pushFollow(FOLLOW_multiplicative_expr_in_additive_expr3851);
            e1=multiplicative_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, e1.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1000:28: ( ( PLUS_T | MINUS_T ) e2= multiplicative_expr )*
            loop94:
            do {
                int alt94=2;
                int LA94_0 = input.LA(1);

                if ( ((LA94_0>=PLUS_T && LA94_0<=MINUS_T)) ) {
                    alt94=1;
                }


                switch (alt94) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1000:29: ( PLUS_T | MINUS_T ) e2= multiplicative_expr
            	    {
            	    set283=(Token)input.LT(1);
            	    set283=(Token)input.LT(1);
            	    if ( (input.LA(1)>=PLUS_T && input.LA(1)<=MINUS_T) ) {
            	        input.consume();
            	        if ( state.backtracking==0 ) root_0 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(set283), root_0);
            	        state.errorRecovery=false;state.failed=false;
            	    }
            	    else {
            	        if (state.backtracking>0) {state.failed=true; return retval;}
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        throw mse;
            	    }

            	    pushFollow(FOLLOW_multiplicative_expr_in_additive_expr3865);
            	    e2=multiplicative_expr();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, e2.getTree());

            	    }
            	    break;

            	default :
            	    break loop94;
                }
            } while (true);

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(e1!=null?((Token)e1.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(e1!=null?((Token)e1.stop):null);
                  if ((e2!=null?input.toString(e2.start,e2.stop):null) != null) {
                    token = (CommonToken)(e2!=null?((Token)e2.stop):null);
                  }
                  endIndex = token.getStopIndex();
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "additive_expr"

    public static class multiplicative_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "multiplicative_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1012:1: multiplicative_expr : e1= cast_expr ( ( MUL_T | DIV_T | PERCENT_T ) e2= cast_expr )* ;
    public final CompilerAstParser.multiplicative_expr_return multiplicative_expr() throws RecognitionException {
        CompilerAstParser.multiplicative_expr_return retval = new CompilerAstParser.multiplicative_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token set284=null;
        CompilerAstParser.cast_expr_return e1 = null;

        CompilerAstParser.cast_expr_return e2 = null;


        SLAST set284_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1022:3: (e1= cast_expr ( ( MUL_T | DIV_T | PERCENT_T ) e2= cast_expr )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1022:5: e1= cast_expr ( ( MUL_T | DIV_T | PERCENT_T ) e2= cast_expr )*
            {
            root_0 = (SLAST)adaptor.nil();

            pushFollow(FOLLOW_cast_expr_in_multiplicative_expr3896);
            e1=cast_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, e1.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1022:18: ( ( MUL_T | DIV_T | PERCENT_T ) e2= cast_expr )*
            loop95:
            do {
                int alt95=2;
                int LA95_0 = input.LA(1);

                if ( ((LA95_0>=MUL_T && LA95_0<=PERCENT_T)) ) {
                    alt95=1;
                }


                switch (alt95) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1022:19: ( MUL_T | DIV_T | PERCENT_T ) e2= cast_expr
            	    {
            	    set284=(Token)input.LT(1);
            	    set284=(Token)input.LT(1);
            	    if ( (input.LA(1)>=MUL_T && input.LA(1)<=PERCENT_T) ) {
            	        input.consume();
            	        if ( state.backtracking==0 ) root_0 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(set284), root_0);
            	        state.errorRecovery=false;state.failed=false;
            	    }
            	    else {
            	        if (state.backtracking>0) {state.failed=true; return retval;}
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        throw mse;
            	    }

            	    pushFollow(FOLLOW_cast_expr_in_multiplicative_expr3914);
            	    e2=cast_expr();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, e2.getTree());

            	    }
            	    break;

            	default :
            	    break loop95;
                }
            } while (true);

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(e1!=null?((Token)e1.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(e1!=null?((Token)e1.stop):null);
                  if ((e2!=null?input.toString(e2.start,e2.stop):null) != null) {
                    token = (CommonToken)(e2!=null?((Token)e2.stop):null);
                  }
                  endIndex = token.getStopIndex();
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "multiplicative_expr"

    public static class cast_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "cast_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1034:1: cast_expr : ( unary_expr | ( LEFT_PARETHESIS cast_option RIGHT_PARETHESIS )+ unary_expr -> ^( CAST_EXPR cast_option unary_expr ) );
    public final CompilerAstParser.cast_expr_return cast_expr() throws RecognitionException {
        CompilerAstParser.cast_expr_return retval = new CompilerAstParser.cast_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token LEFT_PARETHESIS286=null;
        Token RIGHT_PARETHESIS288=null;
        CompilerAstParser.unary_expr_return unary_expr285 = null;

        CompilerAstParser.cast_option_return cast_option287 = null;

        CompilerAstParser.unary_expr_return unary_expr289 = null;


        SLAST LEFT_PARETHESIS286_tree=null;
        SLAST RIGHT_PARETHESIS288_tree=null;
        RewriteRuleTokenStream stream_LEFT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token LEFT_PARETHESIS");
        RewriteRuleTokenStream stream_RIGHT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token RIGHT_PARETHESIS");
        RewriteRuleSubtreeStream stream_unary_expr=new RewriteRuleSubtreeStream(adaptor,"rule unary_expr");
        RewriteRuleSubtreeStream stream_cast_option=new RewriteRuleSubtreeStream(adaptor,"rule cast_option");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1044:3: ( unary_expr | ( LEFT_PARETHESIS cast_option RIGHT_PARETHESIS )+ unary_expr -> ^( CAST_EXPR cast_option unary_expr ) )
            int alt97=2;
            int LA97_0 = input.LA(1);

            if ( (LA97_0==IDENTIFIER||(LA97_0>=FUNCTION_T && LA97_0<=REF_T)||LA97_0==STRINGLITERAL||(LA97_0>=PLUS_T && LA97_0<=MINUS_T)||(LA97_0>=UNSET_T && LA97_0<=MINUS_MINUS_T)||(LA97_0>=AT_T && LA97_0<=BACKTRICKLITERAL)||(LA97_0>=DOLLAR_T && LA97_0<=DOUBLELITERRAL)||(LA97_0>=179 && LA97_0<=185)) ) {
                alt97=1;
            }
            else if ( (LA97_0==LEFT_PARETHESIS) ) {
                switch ( input.LA(2) ) {
                case 179:
                    {
                    int LA97_3 = input.LA(3);

                    if ( (LA97_3==LEFT_PARETHESIS) ) {
                        alt97=1;
                    }
                    else if ( (LA97_3==RIGHT_PARETHESIS) ) {
                        alt97=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return retval;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 97, 3, input);

                        throw nvae;
                    }
                    }
                    break;
                case LEFT_PARETHESIS:
                case IDENTIFIER:
                case FUNCTION_T:
                case REF_T:
                case STRINGLITERAL:
                case PLUS_T:
                case MINUS_T:
                case TILDA_T:
                case EXC_NOT_T:
                case PLUS_PLUS_T:
                case MINUS_MINUS_T:
                case AT_T:
                case LIST_T:
                case NEW_T:
                case EXIT_T:
                case BACKTRICKLITERAL:
                case DOLLAR_T:
                case INTLITERAL:
                case FLOATLITERAL:
                case DOUBLELITERRAL:
                case 180:
                case 181:
                case 182:
                case 183:
                case 184:
                case 185:
                    {
                    alt97=1;
                    }
                    break;
                case CLONE_T:
                    {
                    int LA97_4 = input.LA(3);

                    if ( (LA97_4==IDENTIFIER||LA97_4==DOLLAR_T) ) {
                        alt97=1;
                    }
                    else if ( (LA97_4==RIGHT_PARETHESIS) ) {
                        alt97=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return retval;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 97, 4, input);

                        throw nvae;
                    }
                    }
                    break;
                case UNSET_T:
                    {
                    int LA97_5 = input.LA(3);

                    if ( (LA97_5==LEFT_PARETHESIS) ) {
                        alt97=1;
                    }
                    else if ( (LA97_5==RIGHT_PARETHESIS) ) {
                        alt97=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return retval;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 97, 5, input);

                        throw nvae;
                    }
                    }
                    break;
                case 171:
                case 172:
                case 173:
                case 174:
                case 175:
                case 176:
                case 177:
                case 178:
                    {
                    alt97=2;
                    }
                    break;
                default:
                    if (state.backtracking>0) {state.failed=true; return retval;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 97, 2, input);

                    throw nvae;
                }

            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 97, 0, input);

                throw nvae;
            }
            switch (alt97) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1044:5: unary_expr
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_unary_expr_in_cast_expr3943);
                    unary_expr285=unary_expr();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, unary_expr285.getTree());

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1045:5: ( LEFT_PARETHESIS cast_option RIGHT_PARETHESIS )+ unary_expr
                    {
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1045:5: ( LEFT_PARETHESIS cast_option RIGHT_PARETHESIS )+
                    int cnt96=0;
                    loop96:
                    do {
                        int alt96=2;
                        int LA96_0 = input.LA(1);

                        if ( (LA96_0==LEFT_PARETHESIS) ) {
                            switch ( input.LA(2) ) {
                            case 179:
                                {
                                int LA96_3 = input.LA(3);

                                if ( (LA96_3==RIGHT_PARETHESIS) ) {
                                    alt96=1;
                                }


                                }
                                break;
                            case CLONE_T:
                                {
                                int LA96_4 = input.LA(3);

                                if ( (LA96_4==RIGHT_PARETHESIS) ) {
                                    alt96=1;
                                }


                                }
                                break;
                            case UNSET_T:
                                {
                                int LA96_5 = input.LA(3);

                                if ( (LA96_5==RIGHT_PARETHESIS) ) {
                                    alt96=1;
                                }


                                }
                                break;
                            case 171:
                            case 172:
                            case 173:
                            case 174:
                            case 175:
                            case 176:
                            case 177:
                            case 178:
                                {
                                alt96=1;
                                }
                                break;

                            }

                        }


                        switch (alt96) {
                    	case 1 :
                    	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1045:6: LEFT_PARETHESIS cast_option RIGHT_PARETHESIS
                    	    {
                    	    LEFT_PARETHESIS286=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_cast_expr3950); if (state.failed) return retval; 
                    	    if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS286);

                    	    pushFollow(FOLLOW_cast_option_in_cast_expr3952);
                    	    cast_option287=cast_option();

                    	    state._fsp--;
                    	    if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) stream_cast_option.add(cast_option287.getTree());
                    	    RIGHT_PARETHESIS288=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_cast_expr3954); if (state.failed) return retval; 
                    	    if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS288);


                    	    }
                    	    break;

                    	default :
                    	    if ( cnt96 >= 1 ) break loop96;
                    	    if (state.backtracking>0) {state.failed=true; return retval;}
                                EarlyExitException eee =
                                    new EarlyExitException(96, input);
                                throw eee;
                        }
                        cnt96++;
                    } while (true);

                    pushFollow(FOLLOW_unary_expr_in_cast_expr3958);
                    unary_expr289=unary_expr();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_unary_expr.add(unary_expr289.getTree());
                    if ( state.backtracking==0 ) {

                          token = (CommonToken)LEFT_PARETHESIS286;
                          startIndex = token.getStartIndex();
                          token = (CommonToken)(unary_expr289!=null?((Token)unary_expr289.stop):null);
                          endIndex = token.getStopIndex();
                        
                    }


                    // AST REWRITE
                    // elements: unary_expr, cast_option
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 1052:4: -> ^( CAST_EXPR cast_option unary_expr )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1052:7: ^( CAST_EXPR cast_option unary_expr )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(CAST_EXPR, "CAST_EXPR"), root_1);

                        adaptor.addChild(root_1, stream_cast_option.nextTree());
                        adaptor.addChild(root_1, stream_unary_expr.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "cast_expr"

    public static class cast_option_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "cast_option"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1055:1: cast_option : ( 'bool' | 'boolean' | 'int' | 'float' | 'double' | 'real' | 'string' | UNSET_T | CLONE_T | 'object' | 'array' );
    public final CompilerAstParser.cast_option_return cast_option() throws RecognitionException {
        CompilerAstParser.cast_option_return retval = new CompilerAstParser.cast_option_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token set290=null;

        SLAST set290_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1056:3: ( 'bool' | 'boolean' | 'int' | 'float' | 'double' | 'real' | 'string' | UNSET_T | CLONE_T | 'object' | 'array' )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:
            {
            root_0 = (SLAST)adaptor.nil();

            set290=(Token)input.LT(1);
            if ( (input.LA(1)>=UNSET_T && input.LA(1)<=CLONE_T)||(input.LA(1)>=171 && input.LA(1)<=179) ) {
                input.consume();
                if ( state.backtracking==0 ) adaptor.addChild(root_0, (SLAST)adaptor.create(set290));
                state.errorRecovery=false;state.failed=false;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                MismatchedSetException mse = new MismatchedSetException(null,input);
                throw mse;
            }


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "cast_option"

    public static class unary_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "unary_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1069:1: unary_expr : ( ( REF_T | PLUS_T | MINUS_T | TILDA_T | EXC_NOT_T ) )* prefix_inc_dec_expr ;
    public final CompilerAstParser.unary_expr_return unary_expr() throws RecognitionException {
        CompilerAstParser.unary_expr_return retval = new CompilerAstParser.unary_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token set291=null;
        CompilerAstParser.prefix_inc_dec_expr_return prefix_inc_dec_expr292 = null;


        SLAST set291_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1079:3: ( ( ( REF_T | PLUS_T | MINUS_T | TILDA_T | EXC_NOT_T ) )* prefix_inc_dec_expr )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1079:5: ( ( REF_T | PLUS_T | MINUS_T | TILDA_T | EXC_NOT_T ) )* prefix_inc_dec_expr
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1079:5: ( ( REF_T | PLUS_T | MINUS_T | TILDA_T | EXC_NOT_T ) )*
            loop98:
            do {
                int alt98=2;
                int LA98_0 = input.LA(1);

                if ( (LA98_0==REF_T||(LA98_0>=PLUS_T && LA98_0<=MINUS_T)||(LA98_0>=TILDA_T && LA98_0<=EXC_NOT_T)) ) {
                    alt98=1;
                }


                switch (alt98) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1079:6: ( REF_T | PLUS_T | MINUS_T | TILDA_T | EXC_NOT_T )
            	    {
            	    set291=(Token)input.LT(1);
            	    set291=(Token)input.LT(1);
            	    if ( input.LA(1)==REF_T||(input.LA(1)>=PLUS_T && input.LA(1)<=MINUS_T)||(input.LA(1)>=TILDA_T && input.LA(1)<=EXC_NOT_T) ) {
            	        input.consume();
            	        if ( state.backtracking==0 ) root_0 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(set291), root_0);
            	        state.errorRecovery=false;state.failed=false;
            	    }
            	    else {
            	        if (state.backtracking>0) {state.failed=true; return retval;}
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        throw mse;
            	    }


            	    }
            	    break;

            	default :
            	    break loop98;
                }
            } while (true);

            pushFollow(FOLLOW_prefix_inc_dec_expr_in_unary_expr4101);
            prefix_inc_dec_expr292=prefix_inc_dec_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, prefix_inc_dec_expr292.getTree());
            if ( state.backtracking==0 ) {

                  token = (CommonToken)(prefix_inc_dec_expr292!=null?((Token)prefix_inc_dec_expr292.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(prefix_inc_dec_expr292!=null?((Token)prefix_inc_dec_expr292.stop):null);
                  endIndex = token.getStopIndex();
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "unary_expr"

    public static class prefix_inc_dec_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "prefix_inc_dec_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1089:1: prefix_inc_dec_expr : ( post_inc_dec_expr | ( plus_minus )+ post_inc_dec_expr -> ^( PREFIX_EXPR ( plus_minus )+ post_inc_dec_expr ) );
    public final CompilerAstParser.prefix_inc_dec_expr_return prefix_inc_dec_expr() throws RecognitionException {
        CompilerAstParser.prefix_inc_dec_expr_return retval = new CompilerAstParser.prefix_inc_dec_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        CompilerAstParser.post_inc_dec_expr_return post_inc_dec_expr293 = null;

        CompilerAstParser.plus_minus_return plus_minus294 = null;

        CompilerAstParser.post_inc_dec_expr_return post_inc_dec_expr295 = null;


        RewriteRuleSubtreeStream stream_plus_minus=new RewriteRuleSubtreeStream(adaptor,"rule plus_minus");
        RewriteRuleSubtreeStream stream_post_inc_dec_expr=new RewriteRuleSubtreeStream(adaptor,"rule post_inc_dec_expr");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1099:3: ( post_inc_dec_expr | ( plus_minus )+ post_inc_dec_expr -> ^( PREFIX_EXPR ( plus_minus )+ post_inc_dec_expr ) )
            int alt100=2;
            int LA100_0 = input.LA(1);

            if ( (LA100_0==LEFT_PARETHESIS||LA100_0==IDENTIFIER||LA100_0==FUNCTION_T||LA100_0==STRINGLITERAL||(LA100_0>=UNSET_T && LA100_0<=CLONE_T)||(LA100_0>=AT_T && LA100_0<=BACKTRICKLITERAL)||(LA100_0>=DOLLAR_T && LA100_0<=DOUBLELITERRAL)||(LA100_0>=179 && LA100_0<=185)) ) {
                alt100=1;
            }
            else if ( ((LA100_0>=PLUS_PLUS_T && LA100_0<=MINUS_MINUS_T)) ) {
                alt100=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 100, 0, input);

                throw nvae;
            }
            switch (alt100) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1099:5: post_inc_dec_expr
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_post_inc_dec_expr_in_prefix_inc_dec_expr4129);
                    post_inc_dec_expr293=post_inc_dec_expr();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, post_inc_dec_expr293.getTree());

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1100:5: ( plus_minus )+ post_inc_dec_expr
                    {
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1100:5: ( plus_minus )+
                    int cnt99=0;
                    loop99:
                    do {
                        int alt99=2;
                        int LA99_0 = input.LA(1);

                        if ( ((LA99_0>=PLUS_PLUS_T && LA99_0<=MINUS_MINUS_T)) ) {
                            alt99=1;
                        }


                        switch (alt99) {
                    	case 1 :
                    	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1100:6: plus_minus
                    	    {
                    	    pushFollow(FOLLOW_plus_minus_in_prefix_inc_dec_expr4136);
                    	    plus_minus294=plus_minus();

                    	    state._fsp--;
                    	    if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) stream_plus_minus.add(plus_minus294.getTree());

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt99 >= 1 ) break loop99;
                    	    if (state.backtracking>0) {state.failed=true; return retval;}
                                EarlyExitException eee =
                                    new EarlyExitException(99, input);
                                throw eee;
                        }
                        cnt99++;
                    } while (true);

                    pushFollow(FOLLOW_post_inc_dec_expr_in_prefix_inc_dec_expr4140);
                    post_inc_dec_expr295=post_inc_dec_expr();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_post_inc_dec_expr.add(post_inc_dec_expr295.getTree());
                    if ( state.backtracking==0 ) {

                          token = (CommonToken)(plus_minus294!=null?((Token)plus_minus294.start):null);
                          startIndex = token.getStartIndex();
                          token = (CommonToken)(post_inc_dec_expr295!=null?((Token)post_inc_dec_expr295.stop):null);
                          endIndex = token.getStopIndex();
                        
                    }


                    // AST REWRITE
                    // elements: plus_minus, post_inc_dec_expr
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 1107:4: -> ^( PREFIX_EXPR ( plus_minus )+ post_inc_dec_expr )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1107:8: ^( PREFIX_EXPR ( plus_minus )+ post_inc_dec_expr )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(PREFIX_EXPR, "PREFIX_EXPR"), root_1);

                        if ( !(stream_plus_minus.hasNext()) ) {
                            throw new RewriteEarlyExitException();
                        }
                        while ( stream_plus_minus.hasNext() ) {
                            adaptor.addChild(root_1, stream_plus_minus.nextTree());

                        }
                        stream_plus_minus.reset();
                        adaptor.addChild(root_1, stream_post_inc_dec_expr.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "prefix_inc_dec_expr"

    public static class post_inc_dec_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "post_inc_dec_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1110:1: post_inc_dec_expr : ( instance_expr -> instance_expr ) ( plus_minus -> ^( POSTFIX_EXPR instance_expr plus_minus ) )* ;
    public final CompilerAstParser.post_inc_dec_expr_return post_inc_dec_expr() throws RecognitionException {
        CompilerAstParser.post_inc_dec_expr_return retval = new CompilerAstParser.post_inc_dec_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        CompilerAstParser.instance_expr_return instance_expr296 = null;

        CompilerAstParser.plus_minus_return plus_minus297 = null;


        RewriteRuleSubtreeStream stream_plus_minus=new RewriteRuleSubtreeStream(adaptor,"rule plus_minus");
        RewriteRuleSubtreeStream stream_instance_expr=new RewriteRuleSubtreeStream(adaptor,"rule instance_expr");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1120:3: ( ( instance_expr -> instance_expr ) ( plus_minus -> ^( POSTFIX_EXPR instance_expr plus_minus ) )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1120:5: ( instance_expr -> instance_expr ) ( plus_minus -> ^( POSTFIX_EXPR instance_expr plus_minus ) )*
            {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1120:5: ( instance_expr -> instance_expr )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1120:6: instance_expr
            {
            pushFollow(FOLLOW_instance_expr_in_post_inc_dec_expr4185);
            instance_expr296=instance_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_instance_expr.add(instance_expr296.getTree());


            // AST REWRITE
            // elements: instance_expr
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 1120:20: -> instance_expr
            {
                adaptor.addChild(root_0, stream_instance_expr.nextTree());

            }

            retval.tree = root_0;}
            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1121:3: ( plus_minus -> ^( POSTFIX_EXPR instance_expr plus_minus ) )*
            loop101:
            do {
                int alt101=2;
                int LA101_0 = input.LA(1);

                if ( ((LA101_0>=PLUS_PLUS_T && LA101_0<=MINUS_MINUS_T)) ) {
                    alt101=1;
                }


                switch (alt101) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1121:4: plus_minus
            	    {
            	    pushFollow(FOLLOW_plus_minus_in_post_inc_dec_expr4195);
            	    plus_minus297=plus_minus();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_plus_minus.add(plus_minus297.getTree());
            	    if ( state.backtracking==0 ) {

            	          token = (CommonToken)(instance_expr296!=null?((Token)instance_expr296.start):null);
            	          startIndex = token.getStartIndex();
            	          token = (CommonToken)(plus_minus297!=null?((Token)plus_minus297.stop):null);
            	          endIndex = token.getStopIndex();
            	        
            	    }


            	    // AST REWRITE
            	    // elements: instance_expr, plus_minus
            	    // token labels: 
            	    // rule labels: retval
            	    // token list labels: 
            	    // rule list labels: 
            	    // wildcard labels: 
            	    if ( state.backtracking==0 ) {
            	    retval.tree = root_0;
            	    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            	    root_0 = (SLAST)adaptor.nil();
            	    // 1128:4: -> ^( POSTFIX_EXPR instance_expr plus_minus )
            	    {
            	        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1128:7: ^( POSTFIX_EXPR instance_expr plus_minus )
            	        {
            	        SLAST root_1 = (SLAST)adaptor.nil();
            	        root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(POSTFIX_EXPR, "POSTFIX_EXPR"), root_1);

            	        adaptor.addChild(root_1, stream_instance_expr.nextTree());
            	        adaptor.addChild(root_1, stream_plus_minus.nextTree());

            	        adaptor.addChild(root_0, root_1);
            	        }

            	    }

            	    retval.tree = root_0;}
            	    }
            	    break;

            	default :
            	    break loop101;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "post_inc_dec_expr"

    public static class plus_minus_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "plus_minus"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1133:1: plus_minus : ( PLUS_PLUS_T | MINUS_MINUS_T );
    public final CompilerAstParser.plus_minus_return plus_minus() throws RecognitionException {
        CompilerAstParser.plus_minus_return retval = new CompilerAstParser.plus_minus_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token set298=null;

        SLAST set298_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1134:3: ( PLUS_PLUS_T | MINUS_MINUS_T )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:
            {
            root_0 = (SLAST)adaptor.nil();

            set298=(Token)input.LT(1);
            if ( (input.LA(1)>=PLUS_PLUS_T && input.LA(1)<=MINUS_MINUS_T) ) {
                input.consume();
                if ( state.backtracking==0 ) adaptor.addChild(root_0, (SLAST)adaptor.create(set298));
                state.errorRecovery=false;state.failed=false;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                MismatchedSetException mse = new MismatchedSetException(null,input);
                throw mse;
            }


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "plus_minus"

    public static class instance_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "instance_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1138:1: instance_expr : atom_expr ( INSTANCEOF_T class_name_reference )? ;
    public final CompilerAstParser.instance_expr_return instance_expr() throws RecognitionException {
        CompilerAstParser.instance_expr_return retval = new CompilerAstParser.instance_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token INSTANCEOF_T300=null;
        CompilerAstParser.atom_expr_return atom_expr299 = null;

        CompilerAstParser.class_name_reference_return class_name_reference301 = null;


        SLAST INSTANCEOF_T300_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1148:3: ( atom_expr ( INSTANCEOF_T class_name_reference )? )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1148:5: atom_expr ( INSTANCEOF_T class_name_reference )?
            {
            root_0 = (SLAST)adaptor.nil();

            pushFollow(FOLLOW_atom_expr_in_instance_expr4264);
            atom_expr299=atom_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, atom_expr299.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1148:15: ( INSTANCEOF_T class_name_reference )?
            int alt102=2;
            int LA102_0 = input.LA(1);

            if ( (LA102_0==INSTANCEOF_T) ) {
                alt102=1;
            }
            switch (alt102) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1148:16: INSTANCEOF_T class_name_reference
                    {
                    INSTANCEOF_T300=(Token)match(input,INSTANCEOF_T,FOLLOW_INSTANCEOF_T_in_instance_expr4267); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    INSTANCEOF_T300_tree = (SLAST)adaptor.create(INSTANCEOF_T300);
                    root_0 = (SLAST)adaptor.becomeRoot(INSTANCEOF_T300_tree, root_0);
                    }
                    pushFollow(FOLLOW_class_name_reference_in_instance_expr4270);
                    class_name_reference301=class_name_reference();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, class_name_reference301.getTree());

                    }
                    break;

            }

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(atom_expr299!=null?((Token)atom_expr299.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(atom_expr299!=null?((Token)atom_expr299.stop):null);
                  endIndex = token.getStopIndex();
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "instance_expr"

    public static class atom_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "atom_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1157:1: atom_expr : ( ( AT_T )? variable | ( AT_T )? scalar | LEFT_PARETHESIS expression RIGHT_PARETHESIS | LIST_T LEFT_PARETHESIS assignment_list RIGHT_PARETHESIS -> ^( LIST_T assignment_list ) | 'array' LEFT_PARETHESIS ( array_pair_list )? RIGHT_PARETHESIS -> ^( ARRAY_DECL ( array_pair_list )? ) | NEW_T class_name_reference -> ^( NEW_T class_name_reference ) | CLONE_T variable -> ^( CLONE_T variable ) | EXIT_T ( LEFT_PARETHESIS ( expression )? RIGHT_PARETHESIS )? -> ^( EXIT_T ( expression )? ) | UNSET_T LEFT_PARETHESIS variable_list RIGHT_PARETHESIS -> ^( UNSET_T variable_list ) | lambda_function_declaration | BACKTRICKLITERAL );
    public final CompilerAstParser.atom_expr_return atom_expr() throws RecognitionException {
        CompilerAstParser.atom_expr_return retval = new CompilerAstParser.atom_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token AT_T302=null;
        Token AT_T304=null;
        Token LEFT_PARETHESIS306=null;
        Token RIGHT_PARETHESIS308=null;
        Token LIST_T309=null;
        Token LEFT_PARETHESIS310=null;
        Token RIGHT_PARETHESIS312=null;
        Token string_literal313=null;
        Token LEFT_PARETHESIS314=null;
        Token RIGHT_PARETHESIS316=null;
        Token NEW_T317=null;
        Token CLONE_T319=null;
        Token EXIT_T321=null;
        Token LEFT_PARETHESIS322=null;
        Token RIGHT_PARETHESIS324=null;
        Token UNSET_T325=null;
        Token LEFT_PARETHESIS326=null;
        Token RIGHT_PARETHESIS328=null;
        Token BACKTRICKLITERAL330=null;
        CompilerAstParser.variable_return variable303 = null;

        CompilerAstParser.scalar_return scalar305 = null;

        CompilerAstParser.expression_return expression307 = null;

        CompilerAstParser.assignment_list_return assignment_list311 = null;

        CompilerAstParser.array_pair_list_return array_pair_list315 = null;

        CompilerAstParser.class_name_reference_return class_name_reference318 = null;

        CompilerAstParser.variable_return variable320 = null;

        CompilerAstParser.expression_return expression323 = null;

        CompilerAstParser.variable_list_return variable_list327 = null;

        CompilerAstParser.lambda_function_declaration_return lambda_function_declaration329 = null;


        SLAST AT_T302_tree=null;
        SLAST AT_T304_tree=null;
        SLAST LEFT_PARETHESIS306_tree=null;
        SLAST RIGHT_PARETHESIS308_tree=null;
        SLAST LIST_T309_tree=null;
        SLAST LEFT_PARETHESIS310_tree=null;
        SLAST RIGHT_PARETHESIS312_tree=null;
        SLAST string_literal313_tree=null;
        SLAST LEFT_PARETHESIS314_tree=null;
        SLAST RIGHT_PARETHESIS316_tree=null;
        SLAST NEW_T317_tree=null;
        SLAST CLONE_T319_tree=null;
        SLAST EXIT_T321_tree=null;
        SLAST LEFT_PARETHESIS322_tree=null;
        SLAST RIGHT_PARETHESIS324_tree=null;
        SLAST UNSET_T325_tree=null;
        SLAST LEFT_PARETHESIS326_tree=null;
        SLAST RIGHT_PARETHESIS328_tree=null;
        SLAST BACKTRICKLITERAL330_tree=null;
        RewriteRuleTokenStream stream_EXIT_T=new RewriteRuleTokenStream(adaptor,"token EXIT_T");
        RewriteRuleTokenStream stream_LEFT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token LEFT_PARETHESIS");
        RewriteRuleTokenStream stream_179=new RewriteRuleTokenStream(adaptor,"token 179");
        RewriteRuleTokenStream stream_UNSET_T=new RewriteRuleTokenStream(adaptor,"token UNSET_T");
        RewriteRuleTokenStream stream_LIST_T=new RewriteRuleTokenStream(adaptor,"token LIST_T");
        RewriteRuleTokenStream stream_NEW_T=new RewriteRuleTokenStream(adaptor,"token NEW_T");
        RewriteRuleTokenStream stream_CLONE_T=new RewriteRuleTokenStream(adaptor,"token CLONE_T");
        RewriteRuleTokenStream stream_RIGHT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token RIGHT_PARETHESIS");
        RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");
        RewriteRuleSubtreeStream stream_variable_list=new RewriteRuleSubtreeStream(adaptor,"rule variable_list");
        RewriteRuleSubtreeStream stream_array_pair_list=new RewriteRuleSubtreeStream(adaptor,"rule array_pair_list");
        RewriteRuleSubtreeStream stream_class_name_reference=new RewriteRuleSubtreeStream(adaptor,"rule class_name_reference");
        RewriteRuleSubtreeStream stream_assignment_list=new RewriteRuleSubtreeStream(adaptor,"rule assignment_list");
        RewriteRuleSubtreeStream stream_variable=new RewriteRuleSubtreeStream(adaptor,"rule variable");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1167:3: ( ( AT_T )? variable | ( AT_T )? scalar | LEFT_PARETHESIS expression RIGHT_PARETHESIS | LIST_T LEFT_PARETHESIS assignment_list RIGHT_PARETHESIS -> ^( LIST_T assignment_list ) | 'array' LEFT_PARETHESIS ( array_pair_list )? RIGHT_PARETHESIS -> ^( ARRAY_DECL ( array_pair_list )? ) | NEW_T class_name_reference -> ^( NEW_T class_name_reference ) | CLONE_T variable -> ^( CLONE_T variable ) | EXIT_T ( LEFT_PARETHESIS ( expression )? RIGHT_PARETHESIS )? -> ^( EXIT_T ( expression )? ) | UNSET_T LEFT_PARETHESIS variable_list RIGHT_PARETHESIS -> ^( UNSET_T variable_list ) | lambda_function_declaration | BACKTRICKLITERAL )
            int alt108=11;
            alt108 = dfa108.predict(input);
            switch (alt108) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1167:6: ( AT_T )? variable
                    {
                    root_0 = (SLAST)adaptor.nil();

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1167:6: ( AT_T )?
                    int alt103=2;
                    int LA103_0 = input.LA(1);

                    if ( (LA103_0==AT_T) ) {
                        alt103=1;
                    }
                    switch (alt103) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1167:6: AT_T
                            {
                            AT_T302=(Token)match(input,AT_T,FOLLOW_AT_T_in_atom_expr4302); if (state.failed) return retval;
                            if ( state.backtracking==0 ) {
                            AT_T302_tree = (SLAST)adaptor.create(AT_T302);
                            adaptor.addChild(root_0, AT_T302_tree);
                            }

                            }
                            break;

                    }

                    pushFollow(FOLLOW_variable_in_atom_expr4305);
                    variable303=variable();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, variable303.getTree());

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1168:6: ( AT_T )? scalar
                    {
                    root_0 = (SLAST)adaptor.nil();

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1168:6: ( AT_T )?
                    int alt104=2;
                    int LA104_0 = input.LA(1);

                    if ( (LA104_0==AT_T) ) {
                        alt104=1;
                    }
                    switch (alt104) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1168:6: AT_T
                            {
                            AT_T304=(Token)match(input,AT_T,FOLLOW_AT_T_in_atom_expr4312); if (state.failed) return retval;
                            if ( state.backtracking==0 ) {
                            AT_T304_tree = (SLAST)adaptor.create(AT_T304);
                            adaptor.addChild(root_0, AT_T304_tree);
                            }

                            }
                            break;

                    }

                    pushFollow(FOLLOW_scalar_in_atom_expr4315);
                    scalar305=scalar();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, scalar305.getTree());

                    }
                    break;
                case 3 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1169:6: LEFT_PARETHESIS expression RIGHT_PARETHESIS
                    {
                    root_0 = (SLAST)adaptor.nil();

                    LEFT_PARETHESIS306=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_atom_expr4322); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    LEFT_PARETHESIS306_tree = (SLAST)adaptor.create(LEFT_PARETHESIS306);
                    adaptor.addChild(root_0, LEFT_PARETHESIS306_tree);
                    }
                    pushFollow(FOLLOW_expression_in_atom_expr4324);
                    expression307=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, expression307.getTree());
                    RIGHT_PARETHESIS308=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_atom_expr4326); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    RIGHT_PARETHESIS308_tree = (SLAST)adaptor.create(RIGHT_PARETHESIS308);
                    adaptor.addChild(root_0, RIGHT_PARETHESIS308_tree);
                    }

                    }
                    break;
                case 4 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1170:6: LIST_T LEFT_PARETHESIS assignment_list RIGHT_PARETHESIS
                    {
                    LIST_T309=(Token)match(input,LIST_T,FOLLOW_LIST_T_in_atom_expr4333); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LIST_T.add(LIST_T309);

                    LEFT_PARETHESIS310=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_atom_expr4335); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS310);

                    pushFollow(FOLLOW_assignment_list_in_atom_expr4337);
                    assignment_list311=assignment_list();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_assignment_list.add(assignment_list311.getTree());
                    RIGHT_PARETHESIS312=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_atom_expr4339); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS312);



                    // AST REWRITE
                    // elements: assignment_list, LIST_T
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 1170:66: -> ^( LIST_T assignment_list )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1170:70: ^( LIST_T assignment_list )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_LIST_T.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_assignment_list.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 5 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1171:6: 'array' LEFT_PARETHESIS ( array_pair_list )? RIGHT_PARETHESIS
                    {
                    string_literal313=(Token)match(input,179,FOLLOW_179_in_atom_expr4359); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_179.add(string_literal313);

                    LEFT_PARETHESIS314=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_atom_expr4361); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS314);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1171:30: ( array_pair_list )?
                    int alt105=2;
                    int LA105_0 = input.LA(1);

                    if ( (LA105_0==LEFT_PARETHESIS||LA105_0==IDENTIFIER||(LA105_0>=FUNCTION_T && LA105_0<=REF_T)||LA105_0==STRINGLITERAL||(LA105_0>=PLUS_T && LA105_0<=MINUS_T)||(LA105_0>=UNSET_T && LA105_0<=MINUS_MINUS_T)||(LA105_0>=AT_T && LA105_0<=BACKTRICKLITERAL)||(LA105_0>=DOLLAR_T && LA105_0<=DOUBLELITERRAL)||(LA105_0>=179 && LA105_0<=185)) ) {
                        alt105=1;
                    }
                    switch (alt105) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1171:30: array_pair_list
                            {
                            pushFollow(FOLLOW_array_pair_list_in_atom_expr4363);
                            array_pair_list315=array_pair_list();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_array_pair_list.add(array_pair_list315.getTree());

                            }
                            break;

                    }

                    RIGHT_PARETHESIS316=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_atom_expr4366); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS316);

                    if ( state.backtracking==0 ) {

                            token = (CommonToken)LEFT_PARETHESIS314;
                      	    startIndex = token.getStartIndex();
                      	    token = (CommonToken)RIGHT_PARETHESIS316;
                      	    endIndex = token.getStopIndex();
                          
                    }


                    // AST REWRITE
                    // elements: array_pair_list
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 1178:7: -> ^( ARRAY_DECL ( array_pair_list )? )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1178:11: ^( ARRAY_DECL ( array_pair_list )? )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(ARRAY_DECL, "ARRAY_DECL"), root_1);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1178:24: ( array_pair_list )?
                        if ( stream_array_pair_list.hasNext() ) {
                            adaptor.addChild(root_1, stream_array_pair_list.nextTree());

                        }
                        stream_array_pair_list.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 6 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1179:6: NEW_T class_name_reference
                    {
                    NEW_T317=(Token)match(input,NEW_T,FOLLOW_NEW_T_in_atom_expr4395); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_NEW_T.add(NEW_T317);

                    pushFollow(FOLLOW_class_name_reference_in_atom_expr4397);
                    class_name_reference318=class_name_reference();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_class_name_reference.add(class_name_reference318.getTree());


                    // AST REWRITE
                    // elements: class_name_reference, NEW_T
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 1179:33: -> ^( NEW_T class_name_reference )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1179:37: ^( NEW_T class_name_reference )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_NEW_T.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_class_name_reference.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 7 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1181:6: CLONE_T variable
                    {
                    CLONE_T319=(Token)match(input,CLONE_T,FOLLOW_CLONE_T_in_atom_expr4414); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_CLONE_T.add(CLONE_T319);

                    pushFollow(FOLLOW_variable_in_atom_expr4416);
                    variable320=variable();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_variable.add(variable320.getTree());


                    // AST REWRITE
                    // elements: variable, CLONE_T
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 1181:29: -> ^( CLONE_T variable )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1181:33: ^( CLONE_T variable )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_CLONE_T.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_variable.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 8 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1182:6: EXIT_T ( LEFT_PARETHESIS ( expression )? RIGHT_PARETHESIS )?
                    {
                    EXIT_T321=(Token)match(input,EXIT_T,FOLLOW_EXIT_T_in_atom_expr4438); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_EXIT_T.add(EXIT_T321);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1182:13: ( LEFT_PARETHESIS ( expression )? RIGHT_PARETHESIS )?
                    int alt107=2;
                    int LA107_0 = input.LA(1);

                    if ( (LA107_0==LEFT_PARETHESIS) ) {
                        alt107=1;
                    }
                    switch (alt107) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1182:14: LEFT_PARETHESIS ( expression )? RIGHT_PARETHESIS
                            {
                            LEFT_PARETHESIS322=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_atom_expr4441); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS322);

                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1182:30: ( expression )?
                            int alt106=2;
                            int LA106_0 = input.LA(1);

                            if ( (LA106_0==LEFT_PARETHESIS||LA106_0==IDENTIFIER||(LA106_0>=FUNCTION_T && LA106_0<=REF_T)||LA106_0==STRINGLITERAL||(LA106_0>=PLUS_T && LA106_0<=MINUS_T)||(LA106_0>=UNSET_T && LA106_0<=MINUS_MINUS_T)||(LA106_0>=AT_T && LA106_0<=BACKTRICKLITERAL)||(LA106_0>=DOLLAR_T && LA106_0<=DOUBLELITERRAL)||(LA106_0>=179 && LA106_0<=185)) ) {
                                alt106=1;
                            }
                            switch (alt106) {
                                case 1 :
                                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1182:30: expression
                                    {
                                    pushFollow(FOLLOW_expression_in_atom_expr4443);
                                    expression323=expression();

                                    state._fsp--;
                                    if (state.failed) return retval;
                                    if ( state.backtracking==0 ) stream_expression.add(expression323.getTree());

                                    }
                                    break;

                            }

                            RIGHT_PARETHESIS324=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_atom_expr4446); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS324);


                            }
                            break;

                    }



                    // AST REWRITE
                    // elements: EXIT_T, expression
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 1182:62: -> ^( EXIT_T ( expression )? )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1182:66: ^( EXIT_T ( expression )? )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_EXIT_T.nextNode(), root_1);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1182:75: ( expression )?
                        if ( stream_expression.hasNext() ) {
                            adaptor.addChild(root_1, stream_expression.nextTree());

                        }
                        stream_expression.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 9 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1183:6: UNSET_T LEFT_PARETHESIS variable_list RIGHT_PARETHESIS
                    {
                    UNSET_T325=(Token)match(input,UNSET_T,FOLLOW_UNSET_T_in_atom_expr4466); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_UNSET_T.add(UNSET_T325);

                    LEFT_PARETHESIS326=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_atom_expr4468); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS326);

                    pushFollow(FOLLOW_variable_list_in_atom_expr4470);
                    variable_list327=variable_list();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_variable_list.add(variable_list327.getTree());
                    RIGHT_PARETHESIS328=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_atom_expr4472); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS328);



                    // AST REWRITE
                    // elements: UNSET_T, variable_list
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 1183:62: -> ^( UNSET_T variable_list )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1183:66: ^( UNSET_T variable_list )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_UNSET_T.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_variable_list.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 10 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1184:6: lambda_function_declaration
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_lambda_function_declaration_in_atom_expr4489);
                    lambda_function_declaration329=lambda_function_declaration();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, lambda_function_declaration329.getTree());

                    }
                    break;
                case 11 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1185:6: BACKTRICKLITERAL
                    {
                    root_0 = (SLAST)adaptor.nil();

                    BACKTRICKLITERAL330=(Token)match(input,BACKTRICKLITERAL,FOLLOW_BACKTRICKLITERAL_in_atom_expr4496); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    BACKTRICKLITERAL330_tree = (SLAST)adaptor.create(BACKTRICKLITERAL330);
                    adaptor.addChild(root_0, BACKTRICKLITERAL330_tree);
                    }

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "atom_expr"

    public static class lambda_function_declaration_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "lambda_function_declaration"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1189:1: lambda_function_declaration : FUNCTION_T ( REF_T )? LEFT_PARETHESIS ( parameter_list )? RIGHT_PARETHESIS ( USE_T LEFT_PARETHESIS ( expr_list )? RIGHT_PARETHESIS )? block -> ^( METHOD_DECL ( REF_T )? ( parameter_list )? ( ^( USE_T ( expr_list )? ) )? block ) ;
    public final CompilerAstParser.lambda_function_declaration_return lambda_function_declaration() throws RecognitionException {
        CompilerAstParser.lambda_function_declaration_return retval = new CompilerAstParser.lambda_function_declaration_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token FUNCTION_T331=null;
        Token REF_T332=null;
        Token LEFT_PARETHESIS333=null;
        Token RIGHT_PARETHESIS335=null;
        Token USE_T336=null;
        Token LEFT_PARETHESIS337=null;
        Token RIGHT_PARETHESIS339=null;
        CompilerAstParser.parameter_list_return parameter_list334 = null;

        CompilerAstParser.expr_list_return expr_list338 = null;

        CompilerAstParser.block_return block340 = null;


        SLAST FUNCTION_T331_tree=null;
        SLAST REF_T332_tree=null;
        SLAST LEFT_PARETHESIS333_tree=null;
        SLAST RIGHT_PARETHESIS335_tree=null;
        SLAST USE_T336_tree=null;
        SLAST LEFT_PARETHESIS337_tree=null;
        SLAST RIGHT_PARETHESIS339_tree=null;
        RewriteRuleTokenStream stream_LEFT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token LEFT_PARETHESIS");
        RewriteRuleTokenStream stream_REF_T=new RewriteRuleTokenStream(adaptor,"token REF_T");
        RewriteRuleTokenStream stream_USE_T=new RewriteRuleTokenStream(adaptor,"token USE_T");
        RewriteRuleTokenStream stream_FUNCTION_T=new RewriteRuleTokenStream(adaptor,"token FUNCTION_T");
        RewriteRuleTokenStream stream_RIGHT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token RIGHT_PARETHESIS");
        RewriteRuleSubtreeStream stream_block=new RewriteRuleSubtreeStream(adaptor,"rule block");
        RewriteRuleSubtreeStream stream_parameter_list=new RewriteRuleSubtreeStream(adaptor,"rule parameter_list");
        RewriteRuleSubtreeStream stream_expr_list=new RewriteRuleSubtreeStream(adaptor,"rule expr_list");
        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1190:3: ( FUNCTION_T ( REF_T )? LEFT_PARETHESIS ( parameter_list )? RIGHT_PARETHESIS ( USE_T LEFT_PARETHESIS ( expr_list )? RIGHT_PARETHESIS )? block -> ^( METHOD_DECL ( REF_T )? ( parameter_list )? ( ^( USE_T ( expr_list )? ) )? block ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1190:5: FUNCTION_T ( REF_T )? LEFT_PARETHESIS ( parameter_list )? RIGHT_PARETHESIS ( USE_T LEFT_PARETHESIS ( expr_list )? RIGHT_PARETHESIS )? block
            {
            FUNCTION_T331=(Token)match(input,FUNCTION_T,FOLLOW_FUNCTION_T_in_lambda_function_declaration4511); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_FUNCTION_T.add(FUNCTION_T331);

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1190:16: ( REF_T )?
            int alt109=2;
            int LA109_0 = input.LA(1);

            if ( (LA109_0==REF_T) ) {
                alt109=1;
            }
            switch (alt109) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1190:16: REF_T
                    {
                    REF_T332=(Token)match(input,REF_T,FOLLOW_REF_T_in_lambda_function_declaration4513); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_REF_T.add(REF_T332);


                    }
                    break;

            }

            LEFT_PARETHESIS333=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_lambda_function_declaration4516); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS333);

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1190:39: ( parameter_list )?
            int alt110=2;
            int LA110_0 = input.LA(1);

            if ( (LA110_0==IDENTIFIER||(LA110_0>=REF_T && LA110_0<=CONST_T)||(LA110_0>=UNSET_T && LA110_0<=CLONE_T)||LA110_0==DOLLAR_T||(LA110_0>=171 && LA110_0<=179)) ) {
                alt110=1;
            }
            switch (alt110) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1190:39: parameter_list
                    {
                    pushFollow(FOLLOW_parameter_list_in_lambda_function_declaration4518);
                    parameter_list334=parameter_list();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_parameter_list.add(parameter_list334.getTree());

                    }
                    break;

            }

            RIGHT_PARETHESIS335=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_lambda_function_declaration4521); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS335);

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1190:72: ( USE_T LEFT_PARETHESIS ( expr_list )? RIGHT_PARETHESIS )?
            int alt112=2;
            int LA112_0 = input.LA(1);

            if ( (LA112_0==USE_T) ) {
                alt112=1;
            }
            switch (alt112) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1190:73: USE_T LEFT_PARETHESIS ( expr_list )? RIGHT_PARETHESIS
                    {
                    USE_T336=(Token)match(input,USE_T,FOLLOW_USE_T_in_lambda_function_declaration4524); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_USE_T.add(USE_T336);

                    LEFT_PARETHESIS337=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_lambda_function_declaration4526); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS337);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1190:95: ( expr_list )?
                    int alt111=2;
                    int LA111_0 = input.LA(1);

                    if ( (LA111_0==LEFT_PARETHESIS||LA111_0==IDENTIFIER||(LA111_0>=FUNCTION_T && LA111_0<=REF_T)||LA111_0==STRINGLITERAL||(LA111_0>=PLUS_T && LA111_0<=MINUS_T)||(LA111_0>=UNSET_T && LA111_0<=MINUS_MINUS_T)||(LA111_0>=AT_T && LA111_0<=BACKTRICKLITERAL)||(LA111_0>=DOLLAR_T && LA111_0<=DOUBLELITERRAL)||(LA111_0>=179 && LA111_0<=185)) ) {
                        alt111=1;
                    }
                    switch (alt111) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1190:95: expr_list
                            {
                            pushFollow(FOLLOW_expr_list_in_lambda_function_declaration4528);
                            expr_list338=expr_list();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_expr_list.add(expr_list338.getTree());

                            }
                            break;

                    }

                    RIGHT_PARETHESIS339=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_lambda_function_declaration4531); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS339);


                    }
                    break;

            }

            pushFollow(FOLLOW_block_in_lambda_function_declaration4539);
            block340=block();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_block.add(block340.getTree());


            // AST REWRITE
            // elements: block, parameter_list, USE_T, expr_list, REF_T
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 1192:3: -> ^( METHOD_DECL ( REF_T )? ( parameter_list )? ( ^( USE_T ( expr_list )? ) )? block )
            {
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1192:7: ^( METHOD_DECL ( REF_T )? ( parameter_list )? ( ^( USE_T ( expr_list )? ) )? block )
                {
                SLAST root_1 = (SLAST)adaptor.nil();
                root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(METHOD_DECL, "METHOD_DECL"), root_1);

                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1192:21: ( REF_T )?
                if ( stream_REF_T.hasNext() ) {
                    adaptor.addChild(root_1, stream_REF_T.nextNode());

                }
                stream_REF_T.reset();
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1192:28: ( parameter_list )?
                if ( stream_parameter_list.hasNext() ) {
                    adaptor.addChild(root_1, stream_parameter_list.nextTree());

                }
                stream_parameter_list.reset();
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1192:44: ( ^( USE_T ( expr_list )? ) )?
                if ( stream_USE_T.hasNext()||stream_expr_list.hasNext() ) {
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1192:44: ^( USE_T ( expr_list )? )
                    {
                    SLAST root_2 = (SLAST)adaptor.nil();
                    root_2 = (SLAST)adaptor.becomeRoot(stream_USE_T.nextNode(), root_2);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1192:52: ( expr_list )?
                    if ( stream_expr_list.hasNext() ) {
                        adaptor.addChild(root_2, stream_expr_list.nextTree());

                    }
                    stream_expr_list.reset();

                    adaptor.addChild(root_1, root_2);
                    }

                }
                stream_USE_T.reset();
                stream_expr_list.reset();
                adaptor.addChild(root_1, stream_block.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "lambda_function_declaration"

    public static class class_name_reference_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "class_name_reference"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1196:1: class_name_reference : ( dynamic_name_reference | fully_qualified_class_name );
    public final CompilerAstParser.class_name_reference_return class_name_reference() throws RecognitionException {
        CompilerAstParser.class_name_reference_return retval = new CompilerAstParser.class_name_reference_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        CompilerAstParser.dynamic_name_reference_return dynamic_name_reference341 = null;

        CompilerAstParser.fully_qualified_class_name_return fully_qualified_class_name342 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1197:3: ( dynamic_name_reference | fully_qualified_class_name )
            int alt113=2;
            alt113 = dfa113.predict(input);
            switch (alt113) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1198:5: dynamic_name_reference
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_dynamic_name_reference_in_class_name_reference4591);
                    dynamic_name_reference341=dynamic_name_reference();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, dynamic_name_reference341.getTree());

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1199:5: fully_qualified_class_name
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_fully_qualified_class_name_in_class_name_reference4597);
                    fully_qualified_class_name342=fully_qualified_class_name();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, fully_qualified_class_name342.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "class_name_reference"

    public static class dynamic_name_reference_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "dynamic_name_reference"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1202:1: dynamic_name_reference : ( base_variable_with_function_calls -> base_variable_with_function_calls ) ( SINGLE_ARROW_T object_property ( ctor_arguments )? -> ^( CALL $dynamic_name_reference object_property ( ctor_arguments )? ) )* ;
    public final CompilerAstParser.dynamic_name_reference_return dynamic_name_reference() throws RecognitionException {
        CompilerAstParser.dynamic_name_reference_return retval = new CompilerAstParser.dynamic_name_reference_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token SINGLE_ARROW_T344=null;
        CompilerAstParser.base_variable_with_function_calls_return base_variable_with_function_calls343 = null;

        CompilerAstParser.object_property_return object_property345 = null;

        CompilerAstParser.ctor_arguments_return ctor_arguments346 = null;


        SLAST SINGLE_ARROW_T344_tree=null;
        RewriteRuleTokenStream stream_SINGLE_ARROW_T=new RewriteRuleTokenStream(adaptor,"token SINGLE_ARROW_T");
        RewriteRuleSubtreeStream stream_ctor_arguments=new RewriteRuleSubtreeStream(adaptor,"rule ctor_arguments");
        RewriteRuleSubtreeStream stream_object_property=new RewriteRuleSubtreeStream(adaptor,"rule object_property");
        RewriteRuleSubtreeStream stream_base_variable_with_function_calls=new RewriteRuleSubtreeStream(adaptor,"rule base_variable_with_function_calls");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1212:3: ( ( base_variable_with_function_calls -> base_variable_with_function_calls ) ( SINGLE_ARROW_T object_property ( ctor_arguments )? -> ^( CALL $dynamic_name_reference object_property ( ctor_arguments )? ) )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1212:5: ( base_variable_with_function_calls -> base_variable_with_function_calls ) ( SINGLE_ARROW_T object_property ( ctor_arguments )? -> ^( CALL $dynamic_name_reference object_property ( ctor_arguments )? ) )*
            {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1212:5: ( base_variable_with_function_calls -> base_variable_with_function_calls )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1212:6: base_variable_with_function_calls
            {
            pushFollow(FOLLOW_base_variable_with_function_calls_in_dynamic_name_reference4625);
            base_variable_with_function_calls343=base_variable_with_function_calls();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_base_variable_with_function_calls.add(base_variable_with_function_calls343.getTree());
            if ( state.backtracking==0 ) {

                    token = (CommonToken)(base_variable_with_function_calls343!=null?((Token)base_variable_with_function_calls343.start):null);
                    startIndex = token.getStartIndex();
                    endIndex = token.getStopIndex();
                  
            }


            // AST REWRITE
            // elements: base_variable_with_function_calls
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 1218:7: -> base_variable_with_function_calls
            {
                adaptor.addChild(root_0, stream_base_variable_with_function_calls.nextTree());

            }

            retval.tree = root_0;}
            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1219:5: ( SINGLE_ARROW_T object_property ( ctor_arguments )? -> ^( CALL $dynamic_name_reference object_property ( ctor_arguments )? ) )*
            loop115:
            do {
                int alt115=2;
                int LA115_0 = input.LA(1);

                if ( (LA115_0==SINGLE_ARROW_T) ) {
                    alt115=1;
                }


                switch (alt115) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1219:6: SINGLE_ARROW_T object_property ( ctor_arguments )?
            	    {
            	    SINGLE_ARROW_T344=(Token)match(input,SINGLE_ARROW_T,FOLLOW_SINGLE_ARROW_T_in_dynamic_name_reference4650); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_SINGLE_ARROW_T.add(SINGLE_ARROW_T344);

            	    pushFollow(FOLLOW_object_property_in_dynamic_name_reference4652);
            	    object_property345=object_property();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_object_property.add(object_property345.getTree());
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1219:37: ( ctor_arguments )?
            	    int alt114=2;
            	    int LA114_0 = input.LA(1);

            	    if ( (LA114_0==LEFT_PARETHESIS) ) {
            	        alt114=1;
            	    }
            	    switch (alt114) {
            	        case 1 :
            	            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1219:37: ctor_arguments
            	            {
            	            pushFollow(FOLLOW_ctor_arguments_in_dynamic_name_reference4654);
            	            ctor_arguments346=ctor_arguments();

            	            state._fsp--;
            	            if (state.failed) return retval;
            	            if ( state.backtracking==0 ) stream_ctor_arguments.add(ctor_arguments346.getTree());

            	            }
            	            break;

            	    }

            	    if ( state.backtracking==0 ) {

            	            token = (CommonToken)(base_variable_with_function_calls343!=null?((Token)base_variable_with_function_calls343.start):null);
            	            startIndex = token.getStartIndex();
            	            token = (CommonToken)(object_property345!=null?((Token)object_property345.stop):null);
            	            endIndex = token.getStopIndex();
            	            if ((ctor_arguments346!=null?input.toString(ctor_arguments346.start,ctor_arguments346.stop):null) != null) {
            	              endIndex = ((CommonToken)(ctor_arguments346!=null?((Token)ctor_arguments346.stop):null)).getStopIndex();
            	            }
            	          
            	    }


            	    // AST REWRITE
            	    // elements: object_property, ctor_arguments, dynamic_name_reference
            	    // token labels: 
            	    // rule labels: retval
            	    // token list labels: 
            	    // rule list labels: 
            	    // wildcard labels: 
            	    if ( state.backtracking==0 ) {
            	    retval.tree = root_0;
            	    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            	    root_0 = (SLAST)adaptor.nil();
            	    // 1229:5: -> ^( CALL $dynamic_name_reference object_property ( ctor_arguments )? )
            	    {
            	        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1229:9: ^( CALL $dynamic_name_reference object_property ( ctor_arguments )? )
            	        {
            	        SLAST root_1 = (SLAST)adaptor.nil();
            	        root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(CALL, "CALL"), root_1);

            	        adaptor.addChild(root_1, stream_retval.nextTree());
            	        adaptor.addChild(root_1, stream_object_property.nextTree());
            	        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1229:56: ( ctor_arguments )?
            	        if ( stream_ctor_arguments.hasNext() ) {
            	            adaptor.addChild(root_1, stream_ctor_arguments.nextTree());

            	        }
            	        stream_ctor_arguments.reset();

            	        adaptor.addChild(root_0, root_1);
            	        }

            	    }

            	    retval.tree = root_0;}
            	    }
            	    break;

            	default :
            	    break loop115;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "dynamic_name_reference"

    public static class assignment_list_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "assignment_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1232:1: assignment_list : ( assignment_element )? ( COMMA_T ( assignment_element )? )* -> ( assignment_element )* ;
    public final CompilerAstParser.assignment_list_return assignment_list() throws RecognitionException {
        CompilerAstParser.assignment_list_return retval = new CompilerAstParser.assignment_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token COMMA_T348=null;
        CompilerAstParser.assignment_element_return assignment_element347 = null;

        CompilerAstParser.assignment_element_return assignment_element349 = null;


        SLAST COMMA_T348_tree=null;
        RewriteRuleTokenStream stream_COMMA_T=new RewriteRuleTokenStream(adaptor,"token COMMA_T");
        RewriteRuleSubtreeStream stream_assignment_element=new RewriteRuleSubtreeStream(adaptor,"rule assignment_element");
        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1233:3: ( ( assignment_element )? ( COMMA_T ( assignment_element )? )* -> ( assignment_element )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1233:5: ( assignment_element )? ( COMMA_T ( assignment_element )? )*
            {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1233:5: ( assignment_element )?
            int alt116=2;
            int LA116_0 = input.LA(1);

            if ( (LA116_0==IDENTIFIER||LA116_0==LIST_T||LA116_0==DOLLAR_T) ) {
                alt116=1;
            }
            switch (alt116) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1233:5: assignment_element
                    {
                    pushFollow(FOLLOW_assignment_element_in_assignment_list4705);
                    assignment_element347=assignment_element();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_assignment_element.add(assignment_element347.getTree());

                    }
                    break;

            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1233:25: ( COMMA_T ( assignment_element )? )*
            loop118:
            do {
                int alt118=2;
                int LA118_0 = input.LA(1);

                if ( (LA118_0==COMMA_T) ) {
                    alt118=1;
                }


                switch (alt118) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1233:26: COMMA_T ( assignment_element )?
            	    {
            	    COMMA_T348=(Token)match(input,COMMA_T,FOLLOW_COMMA_T_in_assignment_list4709); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_COMMA_T.add(COMMA_T348);

            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1233:34: ( assignment_element )?
            	    int alt117=2;
            	    int LA117_0 = input.LA(1);

            	    if ( (LA117_0==IDENTIFIER||LA117_0==LIST_T||LA117_0==DOLLAR_T) ) {
            	        alt117=1;
            	    }
            	    switch (alt117) {
            	        case 1 :
            	            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1233:34: assignment_element
            	            {
            	            pushFollow(FOLLOW_assignment_element_in_assignment_list4711);
            	            assignment_element349=assignment_element();

            	            state._fsp--;
            	            if (state.failed) return retval;
            	            if ( state.backtracking==0 ) stream_assignment_element.add(assignment_element349.getTree());

            	            }
            	            break;

            	    }


            	    }
            	    break;

            	default :
            	    break loop118;
                }
            } while (true);



            // AST REWRITE
            // elements: assignment_element
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 1233:57: -> ( assignment_element )*
            {
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1233:61: ( assignment_element )*
                while ( stream_assignment_element.hasNext() ) {
                    adaptor.addChild(root_0, stream_assignment_element.nextTree());

                }
                stream_assignment_element.reset();

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "assignment_list"

    public static class assignment_element_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "assignment_element"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1236:1: assignment_element : ( variable | LIST_T LEFT_PARETHESIS assignment_list RIGHT_PARETHESIS -> ^( LIST_T assignment_list ) );
    public final CompilerAstParser.assignment_element_return assignment_element() throws RecognitionException {
        CompilerAstParser.assignment_element_return retval = new CompilerAstParser.assignment_element_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token LIST_T351=null;
        Token LEFT_PARETHESIS352=null;
        Token RIGHT_PARETHESIS354=null;
        CompilerAstParser.variable_return variable350 = null;

        CompilerAstParser.assignment_list_return assignment_list353 = null;


        SLAST LIST_T351_tree=null;
        SLAST LEFT_PARETHESIS352_tree=null;
        SLAST RIGHT_PARETHESIS354_tree=null;
        RewriteRuleTokenStream stream_LEFT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token LEFT_PARETHESIS");
        RewriteRuleTokenStream stream_LIST_T=new RewriteRuleTokenStream(adaptor,"token LIST_T");
        RewriteRuleTokenStream stream_RIGHT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token RIGHT_PARETHESIS");
        RewriteRuleSubtreeStream stream_assignment_list=new RewriteRuleSubtreeStream(adaptor,"rule assignment_list");
        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1237:3: ( variable | LIST_T LEFT_PARETHESIS assignment_list RIGHT_PARETHESIS -> ^( LIST_T assignment_list ) )
            int alt119=2;
            int LA119_0 = input.LA(1);

            if ( (LA119_0==IDENTIFIER||LA119_0==DOLLAR_T) ) {
                alt119=1;
            }
            else if ( (LA119_0==LIST_T) ) {
                alt119=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 119, 0, input);

                throw nvae;
            }
            switch (alt119) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1237:5: variable
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_variable_in_assignment_element4735);
                    variable350=variable();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, variable350.getTree());

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1238:5: LIST_T LEFT_PARETHESIS assignment_list RIGHT_PARETHESIS
                    {
                    LIST_T351=(Token)match(input,LIST_T,FOLLOW_LIST_T_in_assignment_element4741); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LIST_T.add(LIST_T351);

                    LEFT_PARETHESIS352=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_assignment_element4743); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS352);

                    pushFollow(FOLLOW_assignment_list_in_assignment_element4745);
                    assignment_list353=assignment_list();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_assignment_list.add(assignment_list353.getTree());
                    RIGHT_PARETHESIS354=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_assignment_element4747); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS354);



                    // AST REWRITE
                    // elements: assignment_list, LIST_T
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 1238:62: -> ^( LIST_T assignment_list )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1238:66: ^( LIST_T assignment_list )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_LIST_T.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_assignment_list.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "assignment_element"

    public static class array_pair_list_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "array_pair_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1241:1: array_pair_list : e1= array_pair_element ( COMMA_T e2= array_pair_element )* ( COMMA_T )? -> ( array_pair_element )+ ;
    public final CompilerAstParser.array_pair_list_return array_pair_list() throws RecognitionException {
        CompilerAstParser.array_pair_list_return retval = new CompilerAstParser.array_pair_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token COMMA_T355=null;
        Token COMMA_T356=null;
        CompilerAstParser.array_pair_element_return e1 = null;

        CompilerAstParser.array_pair_element_return e2 = null;


        SLAST COMMA_T355_tree=null;
        SLAST COMMA_T356_tree=null;
        RewriteRuleTokenStream stream_COMMA_T=new RewriteRuleTokenStream(adaptor,"token COMMA_T");
        RewriteRuleSubtreeStream stream_array_pair_element=new RewriteRuleSubtreeStream(adaptor,"rule array_pair_element");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1251:3: (e1= array_pair_element ( COMMA_T e2= array_pair_element )* ( COMMA_T )? -> ( array_pair_element )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1251:5: e1= array_pair_element ( COMMA_T e2= array_pair_element )* ( COMMA_T )?
            {
            pushFollow(FOLLOW_array_pair_element_in_array_pair_list4784);
            e1=array_pair_element();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_array_pair_element.add(e1.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1251:27: ( COMMA_T e2= array_pair_element )*
            loop120:
            do {
                int alt120=2;
                int LA120_0 = input.LA(1);

                if ( (LA120_0==COMMA_T) ) {
                    int LA120_1 = input.LA(2);

                    if ( (LA120_1==LEFT_PARETHESIS||LA120_1==IDENTIFIER||(LA120_1>=FUNCTION_T && LA120_1<=REF_T)||LA120_1==STRINGLITERAL||(LA120_1>=PLUS_T && LA120_1<=MINUS_T)||(LA120_1>=UNSET_T && LA120_1<=MINUS_MINUS_T)||(LA120_1>=AT_T && LA120_1<=BACKTRICKLITERAL)||(LA120_1>=DOLLAR_T && LA120_1<=DOUBLELITERRAL)||(LA120_1>=179 && LA120_1<=185)) ) {
                        alt120=1;
                    }


                }


                switch (alt120) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1251:28: COMMA_T e2= array_pair_element
            	    {
            	    COMMA_T355=(Token)match(input,COMMA_T,FOLLOW_COMMA_T_in_array_pair_list4787); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_COMMA_T.add(COMMA_T355);

            	    pushFollow(FOLLOW_array_pair_element_in_array_pair_list4791);
            	    e2=array_pair_element();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_array_pair_element.add(e2.getTree());

            	    }
            	    break;

            	default :
            	    break loop120;
                }
            } while (true);

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1251:60: ( COMMA_T )?
            int alt121=2;
            int LA121_0 = input.LA(1);

            if ( (LA121_0==COMMA_T) ) {
                alt121=1;
            }
            switch (alt121) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1251:60: COMMA_T
                    {
                    COMMA_T356=(Token)match(input,COMMA_T,FOLLOW_COMMA_T_in_array_pair_list4795); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_COMMA_T.add(COMMA_T356);


                    }
                    break;

            }

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(e1!=null?((Token)e1.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(e1!=null?((Token)e1.stop):null);
                  if ((e2!=null?input.toString(e2.start,e2.stop):null) != null) {
                    token = (CommonToken)(e2!=null?((Token)e2.stop):null);
                  }
                  endIndex = token.getStopIndex();
                
            }


            // AST REWRITE
            // elements: array_pair_element
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 1261:6: -> ( array_pair_element )+
            {
                if ( !(stream_array_pair_element.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_array_pair_element.hasNext() ) {
                    adaptor.addChild(root_0, stream_array_pair_element.nextTree());

                }
                stream_array_pair_element.reset();

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "array_pair_list"

    public static class array_pair_element_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "array_pair_element"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1264:1: array_pair_element : e1= expression ( ARROW_T e2= expression )? ;
    public final CompilerAstParser.array_pair_element_return array_pair_element() throws RecognitionException {
        CompilerAstParser.array_pair_element_return retval = new CompilerAstParser.array_pair_element_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token ARROW_T357=null;
        CompilerAstParser.expression_return e1 = null;

        CompilerAstParser.expression_return e2 = null;


        SLAST ARROW_T357_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1274:3: (e1= expression ( ARROW_T e2= expression )? )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1274:5: e1= expression ( ARROW_T e2= expression )?
            {
            root_0 = (SLAST)adaptor.nil();

            pushFollow(FOLLOW_expression_in_array_pair_element4840);
            e1=expression();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, e1.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1274:19: ( ARROW_T e2= expression )?
            int alt122=2;
            int LA122_0 = input.LA(1);

            if ( (LA122_0==ARROW_T) ) {
                alt122=1;
            }
            switch (alt122) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1274:20: ARROW_T e2= expression
                    {
                    ARROW_T357=(Token)match(input,ARROW_T,FOLLOW_ARROW_T_in_array_pair_element4843); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    ARROW_T357_tree = (SLAST)adaptor.create(ARROW_T357);
                    root_0 = (SLAST)adaptor.becomeRoot(ARROW_T357_tree, root_0);
                    }
                    pushFollow(FOLLOW_expression_in_array_pair_element4848);
                    e2=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, e2.getTree());

                    }
                    break;

            }

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(e1!=null?((Token)e1.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(e1!=null?((Token)e1.stop):null);
                  if ((e2!=null?input.toString(e2.start,e2.stop):null) != null) {
                    token = (CommonToken)(e2!=null?((Token)e2.stop):null);
                  }
                  endIndex = token.getStopIndex();
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "array_pair_element"

    public static class variable_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "variable"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1286:1: variable : ( base_variable_with_function_calls -> base_variable_with_function_calls ) ( SINGLE_ARROW_T object_property ( ctor_arguments )? -> ^( CALL $variable object_property ( ctor_arguments )? ) )* ;
    public final CompilerAstParser.variable_return variable() throws RecognitionException {
        CompilerAstParser.variable_return retval = new CompilerAstParser.variable_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token SINGLE_ARROW_T359=null;
        CompilerAstParser.base_variable_with_function_calls_return base_variable_with_function_calls358 = null;

        CompilerAstParser.object_property_return object_property360 = null;

        CompilerAstParser.ctor_arguments_return ctor_arguments361 = null;


        SLAST SINGLE_ARROW_T359_tree=null;
        RewriteRuleTokenStream stream_SINGLE_ARROW_T=new RewriteRuleTokenStream(adaptor,"token SINGLE_ARROW_T");
        RewriteRuleSubtreeStream stream_ctor_arguments=new RewriteRuleSubtreeStream(adaptor,"rule ctor_arguments");
        RewriteRuleSubtreeStream stream_object_property=new RewriteRuleSubtreeStream(adaptor,"rule object_property");
        RewriteRuleSubtreeStream stream_base_variable_with_function_calls=new RewriteRuleSubtreeStream(adaptor,"rule base_variable_with_function_calls");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1296:3: ( ( base_variable_with_function_calls -> base_variable_with_function_calls ) ( SINGLE_ARROW_T object_property ( ctor_arguments )? -> ^( CALL $variable object_property ( ctor_arguments )? ) )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1296:5: ( base_variable_with_function_calls -> base_variable_with_function_calls ) ( SINGLE_ARROW_T object_property ( ctor_arguments )? -> ^( CALL $variable object_property ( ctor_arguments )? ) )*
            {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1296:5: ( base_variable_with_function_calls -> base_variable_with_function_calls )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1296:6: base_variable_with_function_calls
            {
            pushFollow(FOLLOW_base_variable_with_function_calls_in_variable4882);
            base_variable_with_function_calls358=base_variable_with_function_calls();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_base_variable_with_function_calls.add(base_variable_with_function_calls358.getTree());
            if ( state.backtracking==0 ) {

                    token = (CommonToken)(base_variable_with_function_calls358!=null?((Token)base_variable_with_function_calls358.start):null);
                    startIndex = token.getStartIndex();
                    endIndex = token.getStopIndex();
                  
            }


            // AST REWRITE
            // elements: base_variable_with_function_calls
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 1302:6: -> base_variable_with_function_calls
            {
                adaptor.addChild(root_0, stream_base_variable_with_function_calls.nextTree());

            }

            retval.tree = root_0;}
            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1303:5: ( SINGLE_ARROW_T object_property ( ctor_arguments )? -> ^( CALL $variable object_property ( ctor_arguments )? ) )*
            loop124:
            do {
                int alt124=2;
                int LA124_0 = input.LA(1);

                if ( (LA124_0==SINGLE_ARROW_T) ) {
                    alt124=1;
                }


                switch (alt124) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1303:6: SINGLE_ARROW_T object_property ( ctor_arguments )?
            	    {
            	    SINGLE_ARROW_T359=(Token)match(input,SINGLE_ARROW_T,FOLLOW_SINGLE_ARROW_T_in_variable4905); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_SINGLE_ARROW_T.add(SINGLE_ARROW_T359);

            	    pushFollow(FOLLOW_object_property_in_variable4907);
            	    object_property360=object_property();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_object_property.add(object_property360.getTree());
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1303:37: ( ctor_arguments )?
            	    int alt123=2;
            	    int LA123_0 = input.LA(1);

            	    if ( (LA123_0==LEFT_PARETHESIS) ) {
            	        alt123=1;
            	    }
            	    switch (alt123) {
            	        case 1 :
            	            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1303:37: ctor_arguments
            	            {
            	            pushFollow(FOLLOW_ctor_arguments_in_variable4909);
            	            ctor_arguments361=ctor_arguments();

            	            state._fsp--;
            	            if (state.failed) return retval;
            	            if ( state.backtracking==0 ) stream_ctor_arguments.add(ctor_arguments361.getTree());

            	            }
            	            break;

            	    }

            	    if ( state.backtracking==0 ) {

            	            token = (CommonToken)(base_variable_with_function_calls358!=null?((Token)base_variable_with_function_calls358.start):null);
            	            startIndex = token.getStartIndex();
            	            token = (CommonToken)(object_property360!=null?((Token)object_property360.stop):null);
            	            endIndex = token.getStopIndex();
            	            if ((ctor_arguments361!=null?input.toString(ctor_arguments361.start,ctor_arguments361.stop):null) != null) {
            	              endIndex = ((CommonToken)(ctor_arguments361!=null?((Token)ctor_arguments361.stop):null)).getStopIndex();
            	            }
            	          
            	    }


            	    // AST REWRITE
            	    // elements: object_property, variable, ctor_arguments
            	    // token labels: 
            	    // rule labels: retval
            	    // token list labels: 
            	    // rule list labels: 
            	    // wildcard labels: 
            	    if ( state.backtracking==0 ) {
            	    retval.tree = root_0;
            	    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            	    root_0 = (SLAST)adaptor.nil();
            	    // 1313:5: -> ^( CALL $variable object_property ( ctor_arguments )? )
            	    {
            	        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1313:9: ^( CALL $variable object_property ( ctor_arguments )? )
            	        {
            	        SLAST root_1 = (SLAST)adaptor.nil();
            	        root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(CALL, "CALL"), root_1);

            	        adaptor.addChild(root_1, stream_retval.nextTree());
            	        adaptor.addChild(root_1, stream_object_property.nextTree());
            	        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1313:42: ( ctor_arguments )?
            	        if ( stream_ctor_arguments.hasNext() ) {
            	            adaptor.addChild(root_1, stream_ctor_arguments.nextTree());

            	        }
            	        stream_ctor_arguments.reset();

            	        adaptor.addChild(root_0, root_1);
            	        }

            	    }

            	    retval.tree = root_0;}
            	    }
            	    break;

            	default :
            	    break loop124;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "variable"

    public static class base_variable_with_function_calls_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "base_variable_with_function_calls"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1316:1: base_variable_with_function_calls : ( ( fully_qualified_class_name )? reference_variable ( ctor_arguments )? -> ^( VAR_DECL ( fully_qualified_class_name )? reference_variable ( ctor_arguments )? ) | fully_qualified_class_name ctor_arguments -> ^( CALL fully_qualified_class_name ctor_arguments ) );
    public final CompilerAstParser.base_variable_with_function_calls_return base_variable_with_function_calls() throws RecognitionException {
        CompilerAstParser.base_variable_with_function_calls_return retval = new CompilerAstParser.base_variable_with_function_calls_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        CompilerAstParser.fully_qualified_class_name_return fully_qualified_class_name362 = null;

        CompilerAstParser.reference_variable_return reference_variable363 = null;

        CompilerAstParser.ctor_arguments_return ctor_arguments364 = null;

        CompilerAstParser.fully_qualified_class_name_return fully_qualified_class_name365 = null;

        CompilerAstParser.ctor_arguments_return ctor_arguments366 = null;


        RewriteRuleSubtreeStream stream_ctor_arguments=new RewriteRuleSubtreeStream(adaptor,"rule ctor_arguments");
        RewriteRuleSubtreeStream stream_fully_qualified_class_name=new RewriteRuleSubtreeStream(adaptor,"rule fully_qualified_class_name");
        RewriteRuleSubtreeStream stream_reference_variable=new RewriteRuleSubtreeStream(adaptor,"rule reference_variable");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1326:3: ( ( fully_qualified_class_name )? reference_variable ( ctor_arguments )? -> ^( VAR_DECL ( fully_qualified_class_name )? reference_variable ( ctor_arguments )? ) | fully_qualified_class_name ctor_arguments -> ^( CALL fully_qualified_class_name ctor_arguments ) )
            int alt127=2;
            alt127 = dfa127.predict(input);
            switch (alt127) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1326:5: ( fully_qualified_class_name )? reference_variable ( ctor_arguments )?
                    {
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1326:5: ( fully_qualified_class_name )?
                    int alt125=2;
                    int LA125_0 = input.LA(1);

                    if ( (LA125_0==IDENTIFIER) ) {
                        alt125=1;
                    }
                    switch (alt125) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1326:5: fully_qualified_class_name
                            {
                            pushFollow(FOLLOW_fully_qualified_class_name_in_base_variable_with_function_calls4966);
                            fully_qualified_class_name362=fully_qualified_class_name();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_fully_qualified_class_name.add(fully_qualified_class_name362.getTree());

                            }
                            break;

                    }

                    pushFollow(FOLLOW_reference_variable_in_base_variable_with_function_calls4969);
                    reference_variable363=reference_variable();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_reference_variable.add(reference_variable363.getTree());
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1326:52: ( ctor_arguments )?
                    int alt126=2;
                    int LA126_0 = input.LA(1);

                    if ( (LA126_0==LEFT_PARETHESIS) ) {
                        alt126=1;
                    }
                    switch (alt126) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1326:52: ctor_arguments
                            {
                            pushFollow(FOLLOW_ctor_arguments_in_base_variable_with_function_calls4971);
                            ctor_arguments364=ctor_arguments();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_ctor_arguments.add(ctor_arguments364.getTree());

                            }
                            break;

                    }

                    if ( state.backtracking==0 ) {

                            token = (CommonToken)(reference_variable363!=null?((Token)reference_variable363.start):null);
                            startIndex = token.getStartIndex();
                            token = (CommonToken)(reference_variable363!=null?((Token)reference_variable363.stop):null);
                            endIndex = token.getStopIndex();
                          
                    }


                    // AST REWRITE
                    // elements: fully_qualified_class_name, reference_variable, ctor_arguments
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 1333:7: -> ^( VAR_DECL ( fully_qualified_class_name )? reference_variable ( ctor_arguments )? )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1333:11: ^( VAR_DECL ( fully_qualified_class_name )? reference_variable ( ctor_arguments )? )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(VAR_DECL, "VAR_DECL"), root_1);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1333:22: ( fully_qualified_class_name )?
                        if ( stream_fully_qualified_class_name.hasNext() ) {
                            adaptor.addChild(root_1, stream_fully_qualified_class_name.nextTree());

                        }
                        stream_fully_qualified_class_name.reset();
                        adaptor.addChild(root_1, stream_reference_variable.nextTree());
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1333:69: ( ctor_arguments )?
                        if ( stream_ctor_arguments.hasNext() ) {
                            adaptor.addChild(root_1, stream_ctor_arguments.nextTree());

                        }
                        stream_ctor_arguments.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1334:5: fully_qualified_class_name ctor_arguments
                    {
                    pushFollow(FOLLOW_fully_qualified_class_name_in_base_variable_with_function_calls5005);
                    fully_qualified_class_name365=fully_qualified_class_name();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_fully_qualified_class_name.add(fully_qualified_class_name365.getTree());
                    pushFollow(FOLLOW_ctor_arguments_in_base_variable_with_function_calls5007);
                    ctor_arguments366=ctor_arguments();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_ctor_arguments.add(ctor_arguments366.getTree());
                    if ( state.backtracking==0 ) {

                            token = (CommonToken)(fully_qualified_class_name365!=null?((Token)fully_qualified_class_name365.start):null);
                            startIndex = token.getStartIndex();
                            token = (CommonToken)(ctor_arguments366!=null?((Token)ctor_arguments366.stop):null);
                            endIndex = token.getStopIndex();
                          
                    }


                    // AST REWRITE
                    // elements: ctor_arguments, fully_qualified_class_name
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 1341:7: -> ^( CALL fully_qualified_class_name ctor_arguments )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1341:11: ^( CALL fully_qualified_class_name ctor_arguments )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(CALL, "CALL"), root_1);

                        adaptor.addChild(root_1, stream_fully_qualified_class_name.nextTree());
                        adaptor.addChild(root_1, stream_ctor_arguments.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "base_variable_with_function_calls"

    public static class object_property_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "object_property"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1346:1: object_property : ( reference_variable | reference_variable_without_dollar );
    public final CompilerAstParser.object_property_return object_property() throws RecognitionException {
        CompilerAstParser.object_property_return retval = new CompilerAstParser.object_property_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        CompilerAstParser.reference_variable_return reference_variable367 = null;

        CompilerAstParser.reference_variable_without_dollar_return reference_variable_without_dollar368 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1347:3: ( reference_variable | reference_variable_without_dollar )
            int alt128=2;
            int LA128_0 = input.LA(1);

            if ( (LA128_0==DOLLAR_T) ) {
                alt128=1;
            }
            else if ( (LA128_0==IDENTIFIER||LA128_0==LEFT_BRACKET) ) {
                alt128=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 128, 0, input);

                throw nvae;
            }
            switch (alt128) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1347:5: reference_variable
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_reference_variable_in_object_property5050);
                    reference_variable367=reference_variable();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, reference_variable367.getTree());

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1348:5: reference_variable_without_dollar
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_reference_variable_without_dollar_in_object_property5056);
                    reference_variable_without_dollar368=reference_variable_without_dollar();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, reference_variable_without_dollar368.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "object_property"

    public static class reference_variable_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "reference_variable"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1351:1: reference_variable : ( compound_variable -> ^( VAR compound_variable ) ) ( LEFT_OPEN_RECT (e= expression )? RIGHT_OPEN_RECT -> ^( INDEX $reference_variable ( $e)? ) | LEFT_BRACKET e= expression RIGHT_BRACKET -> ^( HASH_INDEX $reference_variable $e) )* ;
    public final CompilerAstParser.reference_variable_return reference_variable() throws RecognitionException {
        CompilerAstParser.reference_variable_return retval = new CompilerAstParser.reference_variable_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token LEFT_OPEN_RECT370=null;
        Token RIGHT_OPEN_RECT371=null;
        Token LEFT_BRACKET372=null;
        Token RIGHT_BRACKET373=null;
        CompilerAstParser.expression_return e = null;

        CompilerAstParser.compound_variable_return compound_variable369 = null;


        SLAST LEFT_OPEN_RECT370_tree=null;
        SLAST RIGHT_OPEN_RECT371_tree=null;
        SLAST LEFT_BRACKET372_tree=null;
        SLAST RIGHT_BRACKET373_tree=null;
        RewriteRuleTokenStream stream_RIGHT_OPEN_RECT=new RewriteRuleTokenStream(adaptor,"token RIGHT_OPEN_RECT");
        RewriteRuleTokenStream stream_LEFT_BRACKET=new RewriteRuleTokenStream(adaptor,"token LEFT_BRACKET");
        RewriteRuleTokenStream stream_LEFT_OPEN_RECT=new RewriteRuleTokenStream(adaptor,"token LEFT_OPEN_RECT");
        RewriteRuleTokenStream stream_RIGHT_BRACKET=new RewriteRuleTokenStream(adaptor,"token RIGHT_BRACKET");
        RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");
        RewriteRuleSubtreeStream stream_compound_variable=new RewriteRuleSubtreeStream(adaptor,"rule compound_variable");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;  

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1361:3: ( ( compound_variable -> ^( VAR compound_variable ) ) ( LEFT_OPEN_RECT (e= expression )? RIGHT_OPEN_RECT -> ^( INDEX $reference_variable ( $e)? ) | LEFT_BRACKET e= expression RIGHT_BRACKET -> ^( HASH_INDEX $reference_variable $e) )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1361:5: ( compound_variable -> ^( VAR compound_variable ) ) ( LEFT_OPEN_RECT (e= expression )? RIGHT_OPEN_RECT -> ^( INDEX $reference_variable ( $e)? ) | LEFT_BRACKET e= expression RIGHT_BRACKET -> ^( HASH_INDEX $reference_variable $e) )*
            {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1361:5: ( compound_variable -> ^( VAR compound_variable ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1361:6: compound_variable
            {
            pushFollow(FOLLOW_compound_variable_in_reference_variable5082);
            compound_variable369=compound_variable();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_compound_variable.add(compound_variable369.getTree());
            if ( state.backtracking==0 ) {

                  token = (CommonToken)(compound_variable369!=null?((Token)compound_variable369.start):null);
                  startIndex = token.getStartIndex();
                  endIndex = token.getStopIndex();
                
            }


            // AST REWRITE
            // elements: compound_variable
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 1367:5: -> ^( VAR compound_variable )
            {
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1367:8: ^( VAR compound_variable )
                {
                SLAST root_1 = (SLAST)adaptor.nil();
                root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(VAR, "VAR"), root_1);

                adaptor.addChild(root_1, stream_compound_variable.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1368:3: ( LEFT_OPEN_RECT (e= expression )? RIGHT_OPEN_RECT -> ^( INDEX $reference_variable ( $e)? ) | LEFT_BRACKET e= expression RIGHT_BRACKET -> ^( HASH_INDEX $reference_variable $e) )*
            loop130:
            do {
                int alt130=3;
                int LA130_0 = input.LA(1);

                if ( (LA130_0==LEFT_OPEN_RECT) ) {
                    alt130=1;
                }
                else if ( (LA130_0==LEFT_BRACKET) ) {
                    alt130=2;
                }


                switch (alt130) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1369:3: LEFT_OPEN_RECT (e= expression )? RIGHT_OPEN_RECT
            	    {
            	    LEFT_OPEN_RECT370=(Token)match(input,LEFT_OPEN_RECT,FOLLOW_LEFT_OPEN_RECT_in_reference_variable5107); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_LEFT_OPEN_RECT.add(LEFT_OPEN_RECT370);

            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1369:19: (e= expression )?
            	    int alt129=2;
            	    int LA129_0 = input.LA(1);

            	    if ( (LA129_0==LEFT_PARETHESIS||LA129_0==IDENTIFIER||(LA129_0>=FUNCTION_T && LA129_0<=REF_T)||LA129_0==STRINGLITERAL||(LA129_0>=PLUS_T && LA129_0<=MINUS_T)||(LA129_0>=UNSET_T && LA129_0<=MINUS_MINUS_T)||(LA129_0>=AT_T && LA129_0<=BACKTRICKLITERAL)||(LA129_0>=DOLLAR_T && LA129_0<=DOUBLELITERRAL)||(LA129_0>=179 && LA129_0<=185)) ) {
            	        alt129=1;
            	    }
            	    switch (alt129) {
            	        case 1 :
            	            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1369:19: e= expression
            	            {
            	            pushFollow(FOLLOW_expression_in_reference_variable5111);
            	            e=expression();

            	            state._fsp--;
            	            if (state.failed) return retval;
            	            if ( state.backtracking==0 ) stream_expression.add(e.getTree());

            	            }
            	            break;

            	    }

            	    RIGHT_OPEN_RECT371=(Token)match(input,RIGHT_OPEN_RECT,FOLLOW_RIGHT_OPEN_RECT_in_reference_variable5114); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_RIGHT_OPEN_RECT.add(RIGHT_OPEN_RECT371);

            	    if ( state.backtracking==0 ) {

            	          endIndex = ((CommonToken)RIGHT_OPEN_RECT371).getStopIndex();
            	        
            	    }


            	    // AST REWRITE
            	    // elements: reference_variable, e
            	    // token labels: 
            	    // rule labels: retval, e
            	    // token list labels: 
            	    // rule list labels: 
            	    // wildcard labels: 
            	    if ( state.backtracking==0 ) {
            	    retval.tree = root_0;
            	    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
            	    RewriteRuleSubtreeStream stream_e=new RewriteRuleSubtreeStream(adaptor,"rule e",e!=null?e.tree:null);

            	    root_0 = (SLAST)adaptor.nil();
            	    // 1373:5: -> ^( INDEX $reference_variable ( $e)? )
            	    {
            	        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1373:9: ^( INDEX $reference_variable ( $e)? )
            	        {
            	        SLAST root_1 = (SLAST)adaptor.nil();
            	        root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(INDEX, "INDEX"), root_1);

            	        adaptor.addChild(root_1, stream_retval.nextTree());
            	        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1373:37: ( $e)?
            	        if ( stream_e.hasNext() ) {
            	            adaptor.addChild(root_1, stream_e.nextTree());

            	        }
            	        stream_e.reset();

            	        adaptor.addChild(root_0, root_1);
            	        }

            	    }

            	    retval.tree = root_0;}
            	    }
            	    break;
            	case 2 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1375:3: LEFT_BRACKET e= expression RIGHT_BRACKET
            	    {
            	    LEFT_BRACKET372=(Token)match(input,LEFT_BRACKET,FOLLOW_LEFT_BRACKET_in_reference_variable5144); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_LEFT_BRACKET.add(LEFT_BRACKET372);

            	    pushFollow(FOLLOW_expression_in_reference_variable5148);
            	    e=expression();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_expression.add(e.getTree());
            	    RIGHT_BRACKET373=(Token)match(input,RIGHT_BRACKET,FOLLOW_RIGHT_BRACKET_in_reference_variable5150); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_RIGHT_BRACKET.add(RIGHT_BRACKET373);

            	    if ( state.backtracking==0 ) {

            	          endIndex = ((CommonToken)RIGHT_BRACKET373).getStopIndex();
            	        
            	    }


            	    // AST REWRITE
            	    // elements: reference_variable, e
            	    // token labels: 
            	    // rule labels: retval, e
            	    // token list labels: 
            	    // rule list labels: 
            	    // wildcard labels: 
            	    if ( state.backtracking==0 ) {
            	    retval.tree = root_0;
            	    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
            	    RewriteRuleSubtreeStream stream_e=new RewriteRuleSubtreeStream(adaptor,"rule e",e!=null?e.tree:null);

            	    root_0 = (SLAST)adaptor.nil();
            	    // 1379:5: -> ^( HASH_INDEX $reference_variable $e)
            	    {
            	        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1379:9: ^( HASH_INDEX $reference_variable $e)
            	        {
            	        SLAST root_1 = (SLAST)adaptor.nil();
            	        root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(HASH_INDEX, "HASH_INDEX"), root_1);

            	        adaptor.addChild(root_1, stream_retval.nextTree());
            	        adaptor.addChild(root_1, stream_e.nextTree());

            	        adaptor.addChild(root_0, root_1);
            	        }

            	    }

            	    retval.tree = root_0;}
            	    }
            	    break;

            	default :
            	    break loop130;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "reference_variable"

    public static class compound_variable_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "compound_variable"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1383:1: compound_variable : ( ( DOLLAR_T )+ IDENTIFIER | ( DOLLAR_T )+ LEFT_BRACKET expression RIGHT_BRACKET );
    public final CompilerAstParser.compound_variable_return compound_variable() throws RecognitionException {
        CompilerAstParser.compound_variable_return retval = new CompilerAstParser.compound_variable_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token DOLLAR_T374=null;
        Token IDENTIFIER375=null;
        Token DOLLAR_T376=null;
        Token LEFT_BRACKET377=null;
        Token RIGHT_BRACKET379=null;
        CompilerAstParser.expression_return expression378 = null;


        SLAST DOLLAR_T374_tree=null;
        SLAST IDENTIFIER375_tree=null;
        SLAST DOLLAR_T376_tree=null;
        SLAST LEFT_BRACKET377_tree=null;
        SLAST RIGHT_BRACKET379_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1384:3: ( ( DOLLAR_T )+ IDENTIFIER | ( DOLLAR_T )+ LEFT_BRACKET expression RIGHT_BRACKET )
            int alt133=2;
            alt133 = dfa133.predict(input);
            switch (alt133) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1384:5: ( DOLLAR_T )+ IDENTIFIER
                    {
                    root_0 = (SLAST)adaptor.nil();

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1384:5: ( DOLLAR_T )+
                    int cnt131=0;
                    loop131:
                    do {
                        int alt131=2;
                        int LA131_0 = input.LA(1);

                        if ( (LA131_0==DOLLAR_T) ) {
                            alt131=1;
                        }


                        switch (alt131) {
                    	case 1 :
                    	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1384:5: DOLLAR_T
                    	    {
                    	    DOLLAR_T374=(Token)match(input,DOLLAR_T,FOLLOW_DOLLAR_T_in_compound_variable5191); if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) {
                    	    DOLLAR_T374_tree = (SLAST)adaptor.create(DOLLAR_T374);
                    	    adaptor.addChild(root_0, DOLLAR_T374_tree);
                    	    }

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt131 >= 1 ) break loop131;
                    	    if (state.backtracking>0) {state.failed=true; return retval;}
                                EarlyExitException eee =
                                    new EarlyExitException(131, input);
                                throw eee;
                        }
                        cnt131++;
                    } while (true);

                    IDENTIFIER375=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_compound_variable5194); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    IDENTIFIER375_tree = (SLAST)adaptor.create(IDENTIFIER375);
                    adaptor.addChild(root_0, IDENTIFIER375_tree);
                    }

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1385:5: ( DOLLAR_T )+ LEFT_BRACKET expression RIGHT_BRACKET
                    {
                    root_0 = (SLAST)adaptor.nil();

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1385:5: ( DOLLAR_T )+
                    int cnt132=0;
                    loop132:
                    do {
                        int alt132=2;
                        int LA132_0 = input.LA(1);

                        if ( (LA132_0==DOLLAR_T) ) {
                            alt132=1;
                        }


                        switch (alt132) {
                    	case 1 :
                    	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1385:5: DOLLAR_T
                    	    {
                    	    DOLLAR_T376=(Token)match(input,DOLLAR_T,FOLLOW_DOLLAR_T_in_compound_variable5201); if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) {
                    	    DOLLAR_T376_tree = (SLAST)adaptor.create(DOLLAR_T376);
                    	    adaptor.addChild(root_0, DOLLAR_T376_tree);
                    	    }

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt132 >= 1 ) break loop132;
                    	    if (state.backtracking>0) {state.failed=true; return retval;}
                                EarlyExitException eee =
                                    new EarlyExitException(132, input);
                                throw eee;
                        }
                        cnt132++;
                    } while (true);

                    LEFT_BRACKET377=(Token)match(input,LEFT_BRACKET,FOLLOW_LEFT_BRACKET_in_compound_variable5204); if (state.failed) return retval;
                    pushFollow(FOLLOW_expression_in_compound_variable5207);
                    expression378=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, expression378.getTree());
                    RIGHT_BRACKET379=(Token)match(input,RIGHT_BRACKET,FOLLOW_RIGHT_BRACKET_in_compound_variable5209); if (state.failed) return retval;

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "compound_variable"

    public static class reference_variable_without_dollar_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "reference_variable_without_dollar"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1388:1: reference_variable_without_dollar : ( compound_variable_without_dollar -> ^( VAR compound_variable_without_dollar ) ) ( LEFT_OPEN_RECT ( expression )? RIGHT_OPEN_RECT -> ^( INDEX $reference_variable_without_dollar ( expression )? ) | LEFT_BRACKET expression RIGHT_BRACKET -> ^( INDEX $reference_variable_without_dollar expression ) )* ;
    public final CompilerAstParser.reference_variable_without_dollar_return reference_variable_without_dollar() throws RecognitionException {
        CompilerAstParser.reference_variable_without_dollar_return retval = new CompilerAstParser.reference_variable_without_dollar_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token LEFT_OPEN_RECT381=null;
        Token RIGHT_OPEN_RECT383=null;
        Token LEFT_BRACKET384=null;
        Token RIGHT_BRACKET386=null;
        CompilerAstParser.compound_variable_without_dollar_return compound_variable_without_dollar380 = null;

        CompilerAstParser.expression_return expression382 = null;

        CompilerAstParser.expression_return expression385 = null;


        SLAST LEFT_OPEN_RECT381_tree=null;
        SLAST RIGHT_OPEN_RECT383_tree=null;
        SLAST LEFT_BRACKET384_tree=null;
        SLAST RIGHT_BRACKET386_tree=null;
        RewriteRuleTokenStream stream_RIGHT_OPEN_RECT=new RewriteRuleTokenStream(adaptor,"token RIGHT_OPEN_RECT");
        RewriteRuleTokenStream stream_LEFT_BRACKET=new RewriteRuleTokenStream(adaptor,"token LEFT_BRACKET");
        RewriteRuleTokenStream stream_LEFT_OPEN_RECT=new RewriteRuleTokenStream(adaptor,"token LEFT_OPEN_RECT");
        RewriteRuleTokenStream stream_RIGHT_BRACKET=new RewriteRuleTokenStream(adaptor,"token RIGHT_BRACKET");
        RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");
        RewriteRuleSubtreeStream stream_compound_variable_without_dollar=new RewriteRuleSubtreeStream(adaptor,"rule compound_variable_without_dollar");

          int startIndex = -1;
          int endIndex = -1;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1397:3: ( ( compound_variable_without_dollar -> ^( VAR compound_variable_without_dollar ) ) ( LEFT_OPEN_RECT ( expression )? RIGHT_OPEN_RECT -> ^( INDEX $reference_variable_without_dollar ( expression )? ) | LEFT_BRACKET expression RIGHT_BRACKET -> ^( INDEX $reference_variable_without_dollar expression ) )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1397:5: ( compound_variable_without_dollar -> ^( VAR compound_variable_without_dollar ) ) ( LEFT_OPEN_RECT ( expression )? RIGHT_OPEN_RECT -> ^( INDEX $reference_variable_without_dollar ( expression )? ) | LEFT_BRACKET expression RIGHT_BRACKET -> ^( INDEX $reference_variable_without_dollar expression ) )*
            {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1397:5: ( compound_variable_without_dollar -> ^( VAR compound_variable_without_dollar ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1397:6: compound_variable_without_dollar
            {
            pushFollow(FOLLOW_compound_variable_without_dollar_in_reference_variable_without_dollar5236);
            compound_variable_without_dollar380=compound_variable_without_dollar();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_compound_variable_without_dollar.add(compound_variable_without_dollar380.getTree());


            // AST REWRITE
            // elements: compound_variable_without_dollar
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 1397:39: -> ^( VAR compound_variable_without_dollar )
            {
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1397:43: ^( VAR compound_variable_without_dollar )
                {
                SLAST root_1 = (SLAST)adaptor.nil();
                root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(VAR, "VAR"), root_1);

                adaptor.addChild(root_1, stream_compound_variable_without_dollar.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1398:3: ( LEFT_OPEN_RECT ( expression )? RIGHT_OPEN_RECT -> ^( INDEX $reference_variable_without_dollar ( expression )? ) | LEFT_BRACKET expression RIGHT_BRACKET -> ^( INDEX $reference_variable_without_dollar expression ) )*
            loop135:
            do {
                int alt135=3;
                int LA135_0 = input.LA(1);

                if ( (LA135_0==LEFT_OPEN_RECT) ) {
                    alt135=1;
                }
                else if ( (LA135_0==LEFT_BRACKET) ) {
                    alt135=2;
                }


                switch (alt135) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1399:3: LEFT_OPEN_RECT ( expression )? RIGHT_OPEN_RECT
            	    {
            	    LEFT_OPEN_RECT381=(Token)match(input,LEFT_OPEN_RECT,FOLLOW_LEFT_OPEN_RECT_in_reference_variable_without_dollar5254); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_LEFT_OPEN_RECT.add(LEFT_OPEN_RECT381);

            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1399:18: ( expression )?
            	    int alt134=2;
            	    int LA134_0 = input.LA(1);

            	    if ( (LA134_0==LEFT_PARETHESIS||LA134_0==IDENTIFIER||(LA134_0>=FUNCTION_T && LA134_0<=REF_T)||LA134_0==STRINGLITERAL||(LA134_0>=PLUS_T && LA134_0<=MINUS_T)||(LA134_0>=UNSET_T && LA134_0<=MINUS_MINUS_T)||(LA134_0>=AT_T && LA134_0<=BACKTRICKLITERAL)||(LA134_0>=DOLLAR_T && LA134_0<=DOUBLELITERRAL)||(LA134_0>=179 && LA134_0<=185)) ) {
            	        alt134=1;
            	    }
            	    switch (alt134) {
            	        case 1 :
            	            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1399:18: expression
            	            {
            	            pushFollow(FOLLOW_expression_in_reference_variable_without_dollar5256);
            	            expression382=expression();

            	            state._fsp--;
            	            if (state.failed) return retval;
            	            if ( state.backtracking==0 ) stream_expression.add(expression382.getTree());

            	            }
            	            break;

            	    }

            	    RIGHT_OPEN_RECT383=(Token)match(input,RIGHT_OPEN_RECT,FOLLOW_RIGHT_OPEN_RECT_in_reference_variable_without_dollar5259); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_RIGHT_OPEN_RECT.add(RIGHT_OPEN_RECT383);



            	    // AST REWRITE
            	    // elements: expression, reference_variable_without_dollar
            	    // token labels: 
            	    // rule labels: retval
            	    // token list labels: 
            	    // rule list labels: 
            	    // wildcard labels: 
            	    if ( state.backtracking==0 ) {
            	    retval.tree = root_0;
            	    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            	    root_0 = (SLAST)adaptor.nil();
            	    // 1399:48: -> ^( INDEX $reference_variable_without_dollar ( expression )? )
            	    {
            	        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1399:52: ^( INDEX $reference_variable_without_dollar ( expression )? )
            	        {
            	        SLAST root_1 = (SLAST)adaptor.nil();
            	        root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(INDEX, "INDEX"), root_1);

            	        adaptor.addChild(root_1, stream_retval.nextTree());
            	        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1399:95: ( expression )?
            	        if ( stream_expression.hasNext() ) {
            	            adaptor.addChild(root_1, stream_expression.nextTree());

            	        }
            	        stream_expression.reset();

            	        adaptor.addChild(root_0, root_1);
            	        }

            	    }

            	    retval.tree = root_0;}
            	    }
            	    break;
            	case 2 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1401:3: LEFT_BRACKET expression RIGHT_BRACKET
            	    {
            	    LEFT_BRACKET384=(Token)match(input,LEFT_BRACKET,FOLLOW_LEFT_BRACKET_in_reference_variable_without_dollar5282); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_LEFT_BRACKET.add(LEFT_BRACKET384);

            	    pushFollow(FOLLOW_expression_in_reference_variable_without_dollar5284);
            	    expression385=expression();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_expression.add(expression385.getTree());
            	    RIGHT_BRACKET386=(Token)match(input,RIGHT_BRACKET,FOLLOW_RIGHT_BRACKET_in_reference_variable_without_dollar5286); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_RIGHT_BRACKET.add(RIGHT_BRACKET386);



            	    // AST REWRITE
            	    // elements: expression, reference_variable_without_dollar
            	    // token labels: 
            	    // rule labels: retval
            	    // token list labels: 
            	    // rule list labels: 
            	    // wildcard labels: 
            	    if ( state.backtracking==0 ) {
            	    retval.tree = root_0;
            	    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            	    root_0 = (SLAST)adaptor.nil();
            	    // 1401:44: -> ^( INDEX $reference_variable_without_dollar expression )
            	    {
            	        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1401:48: ^( INDEX $reference_variable_without_dollar expression )
            	        {
            	        SLAST root_1 = (SLAST)adaptor.nil();
            	        root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(INDEX, "INDEX"), root_1);

            	        adaptor.addChild(root_1, stream_retval.nextTree());
            	        adaptor.addChild(root_1, stream_expression.nextTree());

            	        adaptor.addChild(root_0, root_1);
            	        }

            	    }

            	    retval.tree = root_0;}
            	    }
            	    break;

            	default :
            	    break loop135;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "reference_variable_without_dollar"

    public static class compound_variable_without_dollar_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "compound_variable_without_dollar"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1405:1: compound_variable_without_dollar : ( IDENTIFIER | LEFT_BRACKET expression RIGHT_BRACKET );
    public final CompilerAstParser.compound_variable_without_dollar_return compound_variable_without_dollar() throws RecognitionException {
        CompilerAstParser.compound_variable_without_dollar_return retval = new CompilerAstParser.compound_variable_without_dollar_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token IDENTIFIER387=null;
        Token LEFT_BRACKET388=null;
        Token RIGHT_BRACKET390=null;
        CompilerAstParser.expression_return expression389 = null;


        SLAST IDENTIFIER387_tree=null;
        SLAST LEFT_BRACKET388_tree=null;
        SLAST RIGHT_BRACKET390_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1406:3: ( IDENTIFIER | LEFT_BRACKET expression RIGHT_BRACKET )
            int alt136=2;
            int LA136_0 = input.LA(1);

            if ( (LA136_0==IDENTIFIER) ) {
                alt136=1;
            }
            else if ( (LA136_0==LEFT_BRACKET) ) {
                alt136=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 136, 0, input);

                throw nvae;
            }
            switch (alt136) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1406:5: IDENTIFIER
                    {
                    root_0 = (SLAST)adaptor.nil();

                    IDENTIFIER387=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_compound_variable_without_dollar5319); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    IDENTIFIER387_tree = (SLAST)adaptor.create(IDENTIFIER387);
                    adaptor.addChild(root_0, IDENTIFIER387_tree);
                    }

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1407:5: LEFT_BRACKET expression RIGHT_BRACKET
                    {
                    root_0 = (SLAST)adaptor.nil();

                    LEFT_BRACKET388=(Token)match(input,LEFT_BRACKET,FOLLOW_LEFT_BRACKET_in_compound_variable_without_dollar5325); if (state.failed) return retval;
                    pushFollow(FOLLOW_expression_in_compound_variable_without_dollar5328);
                    expression389=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, expression389.getTree());
                    RIGHT_BRACKET390=(Token)match(input,RIGHT_BRACKET,FOLLOW_RIGHT_BRACKET_in_compound_variable_without_dollar5330); if (state.failed) return retval;

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "compound_variable_without_dollar"

    public static class ctor_arguments_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "ctor_arguments"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1410:1: ctor_arguments : LEFT_PARETHESIS ( expr_list )? RIGHT_PARETHESIS -> ^( ARGU ( expr_list )? ) ;
    public final CompilerAstParser.ctor_arguments_return ctor_arguments() throws RecognitionException {
        CompilerAstParser.ctor_arguments_return retval = new CompilerAstParser.ctor_arguments_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token LEFT_PARETHESIS391=null;
        Token RIGHT_PARETHESIS393=null;
        CompilerAstParser.expr_list_return expr_list392 = null;


        SLAST LEFT_PARETHESIS391_tree=null;
        SLAST RIGHT_PARETHESIS393_tree=null;
        RewriteRuleTokenStream stream_LEFT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token LEFT_PARETHESIS");
        RewriteRuleTokenStream stream_RIGHT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token RIGHT_PARETHESIS");
        RewriteRuleSubtreeStream stream_expr_list=new RewriteRuleSubtreeStream(adaptor,"rule expr_list");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1420:3: ( LEFT_PARETHESIS ( expr_list )? RIGHT_PARETHESIS -> ^( ARGU ( expr_list )? ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1420:6: LEFT_PARETHESIS ( expr_list )? RIGHT_PARETHESIS
            {
            LEFT_PARETHESIS391=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_ctor_arguments5357); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS391);

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1420:22: ( expr_list )?
            int alt137=2;
            int LA137_0 = input.LA(1);

            if ( (LA137_0==LEFT_PARETHESIS||LA137_0==IDENTIFIER||(LA137_0>=FUNCTION_T && LA137_0<=REF_T)||LA137_0==STRINGLITERAL||(LA137_0>=PLUS_T && LA137_0<=MINUS_T)||(LA137_0>=UNSET_T && LA137_0<=MINUS_MINUS_T)||(LA137_0>=AT_T && LA137_0<=BACKTRICKLITERAL)||(LA137_0>=DOLLAR_T && LA137_0<=DOUBLELITERRAL)||(LA137_0>=179 && LA137_0<=185)) ) {
                alt137=1;
            }
            switch (alt137) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1420:22: expr_list
                    {
                    pushFollow(FOLLOW_expr_list_in_ctor_arguments5359);
                    expr_list392=expr_list();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_expr_list.add(expr_list392.getTree());

                    }
                    break;

            }

            RIGHT_PARETHESIS393=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_ctor_arguments5362); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS393);

            if ( state.backtracking==0 ) {

                    token = (CommonToken)LEFT_PARETHESIS391;
                    startIndex = token.getStartIndex();
                    token = (CommonToken)RIGHT_PARETHESIS393;
                    endIndex = token.getStopIndex();
                  
            }


            // AST REWRITE
            // elements: expr_list
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 1427:6: -> ^( ARGU ( expr_list )? )
            {
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1427:10: ^( ARGU ( expr_list )? )
                {
                SLAST root_1 = (SLAST)adaptor.nil();
                root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(ARGU, "ARGU"), root_1);

                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1427:17: ( expr_list )?
                if ( stream_expr_list.hasNext() ) {
                    adaptor.addChild(root_1, stream_expr_list.nextTree());

                }
                stream_expr_list.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "ctor_arguments"

    public static class pure_variable_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "pure_variable"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1430:1: pure_variable : ( REF_T )? ( DOLLAR_T )+ IDENTIFIER -> ^( VAR_DECL ( REF_T )? ( DOLLAR_T )+ IDENTIFIER ) ;
    public final CompilerAstParser.pure_variable_return pure_variable() throws RecognitionException {
        CompilerAstParser.pure_variable_return retval = new CompilerAstParser.pure_variable_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token REF_T394=null;
        Token DOLLAR_T395=null;
        Token IDENTIFIER396=null;

        SLAST REF_T394_tree=null;
        SLAST DOLLAR_T395_tree=null;
        SLAST IDENTIFIER396_tree=null;
        RewriteRuleTokenStream stream_REF_T=new RewriteRuleTokenStream(adaptor,"token REF_T");
        RewriteRuleTokenStream stream_IDENTIFIER=new RewriteRuleTokenStream(adaptor,"token IDENTIFIER");
        RewriteRuleTokenStream stream_DOLLAR_T=new RewriteRuleTokenStream(adaptor,"token DOLLAR_T");


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1440:3: ( ( REF_T )? ( DOLLAR_T )+ IDENTIFIER -> ^( VAR_DECL ( REF_T )? ( DOLLAR_T )+ IDENTIFIER ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1440:5: ( REF_T )? ( DOLLAR_T )+ IDENTIFIER
            {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1440:5: ( REF_T )?
            int alt138=2;
            int LA138_0 = input.LA(1);

            if ( (LA138_0==REF_T) ) {
                alt138=1;
            }
            switch (alt138) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1440:5: REF_T
                    {
                    REF_T394=(Token)match(input,REF_T,FOLLOW_REF_T_in_pure_variable5408); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_REF_T.add(REF_T394);


                    }
                    break;

            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1440:12: ( DOLLAR_T )+
            int cnt139=0;
            loop139:
            do {
                int alt139=2;
                int LA139_0 = input.LA(1);

                if ( (LA139_0==DOLLAR_T) ) {
                    alt139=1;
                }


                switch (alt139) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1440:12: DOLLAR_T
            	    {
            	    DOLLAR_T395=(Token)match(input,DOLLAR_T,FOLLOW_DOLLAR_T_in_pure_variable5411); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_DOLLAR_T.add(DOLLAR_T395);


            	    }
            	    break;

            	default :
            	    if ( cnt139 >= 1 ) break loop139;
            	    if (state.backtracking>0) {state.failed=true; return retval;}
                        EarlyExitException eee =
                            new EarlyExitException(139, input);
                        throw eee;
                }
                cnt139++;
            } while (true);

            IDENTIFIER396=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_pure_variable5414); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER396);

            if ( state.backtracking==0 ) {

                    token = (CommonToken)DOLLAR_T395;
                    if ((REF_T394!=null?REF_T394.getText():null) != null) {
                      token = (CommonToken)REF_T394;
                    }
                    startIndex = token.getStartIndex();
                    token = (CommonToken)IDENTIFIER396;
                    endIndex = token.getStopIndex();
                  
            }


            // AST REWRITE
            // elements: IDENTIFIER, REF_T, DOLLAR_T
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 1450:5: -> ^( VAR_DECL ( REF_T )? ( DOLLAR_T )+ IDENTIFIER )
            {
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1450:9: ^( VAR_DECL ( REF_T )? ( DOLLAR_T )+ IDENTIFIER )
                {
                SLAST root_1 = (SLAST)adaptor.nil();
                root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(VAR_DECL, "VAR_DECL"), root_1);

                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1450:20: ( REF_T )?
                if ( stream_REF_T.hasNext() ) {
                    adaptor.addChild(root_1, stream_REF_T.nextNode());

                }
                stream_REF_T.reset();
                if ( !(stream_DOLLAR_T.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_DOLLAR_T.hasNext() ) {
                    adaptor.addChild(root_1, stream_DOLLAR_T.nextNode());

                }
                stream_DOLLAR_T.reset();
                adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "pure_variable"

    public static class scalar_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "scalar"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1453:1: scalar : constant -> ^( SCALAR constant ) ;
    public final CompilerAstParser.scalar_return scalar() throws RecognitionException {
        CompilerAstParser.scalar_return retval = new CompilerAstParser.scalar_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        CompilerAstParser.constant_return constant397 = null;


        RewriteRuleSubtreeStream stream_constant=new RewriteRuleSubtreeStream(adaptor,"rule constant");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1463:3: ( constant -> ^( SCALAR constant ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1463:5: constant
            {
            pushFollow(FOLLOW_constant_in_scalar5466);
            constant397=constant();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_constant.add(constant397.getTree());
            if ( state.backtracking==0 ) {

                  token = (CommonToken)(constant397!=null?((Token)constant397.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(constant397!=null?((Token)constant397.stop):null);
                  endIndex = token.getStopIndex();
                
            }


            // AST REWRITE
            // elements: constant
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 1470:5: -> ^( SCALAR constant )
            {
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1470:9: ^( SCALAR constant )
                {
                SLAST root_1 = (SLAST)adaptor.nil();
                root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(SCALAR, "SCALAR"), root_1);

                adaptor.addChild(root_1, stream_constant.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST exprToken = retval.tree;
                exprToken.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "scalar"

    public static class constant_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "constant"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1473:1: constant : ( INTLITERAL | FLOATLITERAL | STRINGLITERAL | DOUBLELITERRAL | common_scalar | fully_qualified_class_name );
    public final CompilerAstParser.constant_return constant() throws RecognitionException {
        CompilerAstParser.constant_return retval = new CompilerAstParser.constant_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token INTLITERAL398=null;
        Token FLOATLITERAL399=null;
        Token STRINGLITERAL400=null;
        Token DOUBLELITERRAL401=null;
        CompilerAstParser.common_scalar_return common_scalar402 = null;

        CompilerAstParser.fully_qualified_class_name_return fully_qualified_class_name403 = null;


        SLAST INTLITERAL398_tree=null;
        SLAST FLOATLITERAL399_tree=null;
        SLAST STRINGLITERAL400_tree=null;
        SLAST DOUBLELITERRAL401_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1474:3: ( INTLITERAL | FLOATLITERAL | STRINGLITERAL | DOUBLELITERRAL | common_scalar | fully_qualified_class_name )
            int alt140=6;
            switch ( input.LA(1) ) {
            case INTLITERAL:
                {
                alt140=1;
                }
                break;
            case FLOATLITERAL:
                {
                alt140=2;
                }
                break;
            case STRINGLITERAL:
                {
                alt140=3;
                }
                break;
            case DOUBLELITERRAL:
                {
                alt140=4;
                }
                break;
            case 180:
            case 181:
            case 182:
            case 183:
            case 184:
            case 185:
                {
                alt140=5;
                }
                break;
            case IDENTIFIER:
                {
                alt140=6;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 140, 0, input);

                throw nvae;
            }

            switch (alt140) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1474:5: INTLITERAL
                    {
                    root_0 = (SLAST)adaptor.nil();

                    INTLITERAL398=(Token)match(input,INTLITERAL,FOLLOW_INTLITERAL_in_constant5501); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    INTLITERAL398_tree = (SLAST)adaptor.create(INTLITERAL398);
                    adaptor.addChild(root_0, INTLITERAL398_tree);
                    }

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1475:5: FLOATLITERAL
                    {
                    root_0 = (SLAST)adaptor.nil();

                    FLOATLITERAL399=(Token)match(input,FLOATLITERAL,FOLLOW_FLOATLITERAL_in_constant5510); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    FLOATLITERAL399_tree = (SLAST)adaptor.create(FLOATLITERAL399);
                    adaptor.addChild(root_0, FLOATLITERAL399_tree);
                    }

                    }
                    break;
                case 3 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1476:5: STRINGLITERAL
                    {
                    root_0 = (SLAST)adaptor.nil();

                    STRINGLITERAL400=(Token)match(input,STRINGLITERAL,FOLLOW_STRINGLITERAL_in_constant5518); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    STRINGLITERAL400_tree = (SLAST)adaptor.create(STRINGLITERAL400);
                    adaptor.addChild(root_0, STRINGLITERAL400_tree);
                    }

                    }
                    break;
                case 4 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1477:5: DOUBLELITERRAL
                    {
                    root_0 = (SLAST)adaptor.nil();

                    DOUBLELITERRAL401=(Token)match(input,DOUBLELITERRAL,FOLLOW_DOUBLELITERRAL_in_constant5527); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    DOUBLELITERRAL401_tree = (SLAST)adaptor.create(DOUBLELITERRAL401);
                    adaptor.addChild(root_0, DOUBLELITERRAL401_tree);
                    }

                    }
                    break;
                case 5 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1478:5: common_scalar
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_common_scalar_in_constant5534);
                    common_scalar402=common_scalar();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, common_scalar402.getTree());

                    }
                    break;
                case 6 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1479:5: fully_qualified_class_name
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_fully_qualified_class_name_in_constant5542);
                    fully_qualified_class_name403=fully_qualified_class_name();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, fully_qualified_class_name403.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "constant"

    public static class common_scalar_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "common_scalar"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1482:1: common_scalar : ( '__CLASS__' | '__DIR__' | '__FILE__' | '__FUNCTION__' | '__METHOD__' | '__NAMESPACE__' );
    public final CompilerAstParser.common_scalar_return common_scalar() throws RecognitionException {
        CompilerAstParser.common_scalar_return retval = new CompilerAstParser.common_scalar_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token set404=null;

        SLAST set404_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1483:3: ( '__CLASS__' | '__DIR__' | '__FILE__' | '__FUNCTION__' | '__METHOD__' | '__NAMESPACE__' )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:
            {
            root_0 = (SLAST)adaptor.nil();

            set404=(Token)input.LT(1);
            if ( (input.LA(1)>=180 && input.LA(1)<=185) ) {
                input.consume();
                if ( state.backtracking==0 ) adaptor.addChild(root_0, (SLAST)adaptor.create(set404));
                state.errorRecovery=false;state.failed=false;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                MismatchedSetException mse = new MismatchedSetException(null,input);
                throw mse;
            }


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "common_scalar"

    // $ANTLR start synpred1_CompilerAst
    public final void synpred1_CompilerAst_fragment() throws RecognitionException {   
        CompilerAstParser.expression_return eElseCond = null;

        CompilerAstParser.statement_return s2 = null;


        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:503:53: ( ELSEIF_T LEFT_PARETHESIS eElseCond= expression RIGHT_PARETHESIS s2= statement )
        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:503:53: ELSEIF_T LEFT_PARETHESIS eElseCond= expression RIGHT_PARETHESIS s2= statement
        {
        match(input,ELSEIF_T,FOLLOW_ELSEIF_T_in_synpred1_CompilerAst2079); if (state.failed) return ;
        match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_synpred1_CompilerAst2081); if (state.failed) return ;
        pushFollow(FOLLOW_expression_in_synpred1_CompilerAst2085);
        eElseCond=expression();

        state._fsp--;
        if (state.failed) return ;
        match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_synpred1_CompilerAst2087); if (state.failed) return ;
        pushFollow(FOLLOW_statement_in_synpred1_CompilerAst2091);
        s2=statement();

        state._fsp--;
        if (state.failed) return ;

        }
    }
    // $ANTLR end synpred1_CompilerAst

    // $ANTLR start synpred2_CompilerAst
    public final void synpred2_CompilerAst_fragment() throws RecognitionException {   
        CompilerAstParser.statement_return s3 = null;


        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:504:42: ( ELSE_T s3= statement )
        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:504:42: ELSE_T s3= statement
        {
        match(input,ELSE_T,FOLLOW_ELSE_T_in_synpred2_CompilerAst2117); if (state.failed) return ;
        pushFollow(FOLLOW_statement_in_synpred2_CompilerAst2121);
        s3=statement();

        state._fsp--;
        if (state.failed) return ;

        }
    }
    // $ANTLR end synpred2_CompilerAst

    // Delegated rules

    public final boolean synpred2_CompilerAst() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred2_CompilerAst_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }
    public final boolean synpred1_CompilerAst() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred1_CompilerAst_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }


    protected DFA22 dfa22 = new DFA22(this);
    protected DFA44 dfa44 = new DFA44(this);
    protected DFA45 dfa45 = new DFA45(this);
    protected DFA108 dfa108 = new DFA108(this);
    protected DFA113 dfa113 = new DFA113(this);
    protected DFA127 dfa127 = new DFA127(this);
    protected DFA133 dfa133 = new DFA133(this);
    static final String DFA22_eotS =
        "\56\uffff";
    static final String DFA22_eofS =
        "\56\uffff";
    static final String DFA22_minS =
        "\1\70\1\uffff\1\70\1\62\1\uffff\1\62\1\56\1\57\3\71\1\u0091\1\62"+
        "\1\60\1\62\1\57\2\uffff\1\71\2\62\6\57\3\71\1\u0091\1\62\1\57\1"+
        "\62\2\57\1\71\1\62\10\57";
    static final String DFA22_maxS =
        "\1\u00aa\1\uffff\1\u00aa\1\71\1\uffff\1\62\1\56\1\u00b3\5\u0091"+
        "\1\65\1\u0091\1\121\2\uffff\1\u0091\1\u00b9\1\u00b3\6\120\5\u0091"+
        "\1\120\1\u0091\1\121\1\120\1\u0091\1\u00b9\10\120";
    static final String DFA22_acceptS =
        "\1\uffff\1\1\2\uffff\1\4\13\uffff\1\2\1\3\34\uffff";
    static final String DFA22_specialS =
        "\56\uffff}>";
    static final String[] DFA22_transitionS = {
            "\1\3\1\uffff\1\4\10\uffff\1\2\141\uffff\2\2\1\1\3\2",
            "",
            "\1\3\1\1\11\uffff\1\2\115\uffff\1\1\23\uffff\2\2\1\uffff\3"+
            "\2",
            "\1\6\6\uffff\1\5",
            "",
            "\1\6",
            "\1\7",
            "\1\15\2\uffff\1\10\6\uffff\1\13\1\12\107\uffff\2\11\15\uffff"+
            "\1\14\31\uffff\11\11",
            "\1\13\1\12\24\uffff\1\16\101\uffff\1\14",
            "\1\13\1\12\126\uffff\1\14",
            "\1\13\127\uffff\1\14",
            "\1\14",
            "\1\17\136\uffff\1\14",
            "\1\20\4\uffff\1\21",
            "\1\22\6\uffff\1\13\1\12\126\uffff\1\14",
            "\1\15\40\uffff\1\24\1\23",
            "",
            "",
            "\1\13\1\12\24\uffff\1\16\101\uffff\1\14",
            "\1\32\33\uffff\1\27\103\uffff\1\25\1\26\1\30\37\uffff\6\31",
            "\1\33\6\uffff\1\36\1\35\107\uffff\2\34\15\uffff\1\37\31\uffff"+
            "\11\34",
            "\1\15\40\uffff\1\24",
            "\1\15\40\uffff\1\24",
            "\1\15\40\uffff\1\24",
            "\1\15\40\uffff\1\24",
            "\1\15\40\uffff\1\24",
            "\1\15\37\uffff\1\40\1\24",
            "\1\36\1\35\24\uffff\1\41\101\uffff\1\37",
            "\1\36\1\35\126\uffff\1\37",
            "\1\36\127\uffff\1\37",
            "\1\37",
            "\1\42\136\uffff\1\37",
            "\1\15\2\uffff\1\43\35\uffff\1\24",
            "\1\44\6\uffff\1\36\1\35\126\uffff\1\37",
            "\1\15\40\uffff\1\24\1\45",
            "\1\15\37\uffff\1\40\1\24",
            "\1\36\1\35\24\uffff\1\41\101\uffff\1\37",
            "\1\53\33\uffff\1\50\103\uffff\1\46\1\47\1\51\37\uffff\6\52",
            "\1\15\40\uffff\1\24",
            "\1\15\40\uffff\1\24",
            "\1\15\40\uffff\1\24",
            "\1\15\40\uffff\1\24",
            "\1\15\40\uffff\1\24",
            "\1\15\37\uffff\1\54\1\24",
            "\1\15\2\uffff\1\55\35\uffff\1\24",
            "\1\15\37\uffff\1\54\1\24"
    };

    static final short[] DFA22_eot = DFA.unpackEncodedString(DFA22_eotS);
    static final short[] DFA22_eof = DFA.unpackEncodedString(DFA22_eofS);
    static final char[] DFA22_min = DFA.unpackEncodedStringToUnsignedChars(DFA22_minS);
    static final char[] DFA22_max = DFA.unpackEncodedStringToUnsignedChars(DFA22_maxS);
    static final short[] DFA22_accept = DFA.unpackEncodedString(DFA22_acceptS);
    static final short[] DFA22_special = DFA.unpackEncodedString(DFA22_specialS);
    static final short[][] DFA22_transition;

    static {
        int numStates = DFA22_transitionS.length;
        DFA22_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA22_transition[i] = DFA.unpackEncodedString(DFA22_transitionS[i]);
        }
    }

    class DFA22 extends DFA {

        public DFA22(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 22;
            this.eot = DFA22_eot;
            this.eof = DFA22_eof;
            this.min = DFA22_min;
            this.max = DFA22_max;
            this.accept = DFA22_accept;
            this.special = DFA22_special;
            this.transition = DFA22_transition;
        }
        public String getDescription() {
            return "206:1: class_statement : ( variable_modifiers static_var_list SEMI_COLON -> ^( FIELD_DECL variable_modifiers static_var_list ) | ( modifier )? FUNCTION_T ( REF_T )? IDENTIFIER LEFT_PARETHESIS ( parameter_list )? RIGHT_PARETHESIS SEMI_COLON -> ^( METHOD_DECL ( modifier )? ( REF_T )? IDENTIFIER ( parameter_list )? EMPTYSTATEMENT ) | ( modifier )? FUNCTION_T ( REF_T )? IDENTIFIER LEFT_PARETHESIS ( parameter_list )? RIGHT_PARETHESIS block -> ^( METHOD_DECL ( modifier )? ( REF_T )? IDENTIFIER ( parameter_list )? block ) | CONST_T directive SEMI_COLON -> ^( FIELD_DECL CONST_T directive ) );";
        }
    }
    static final String DFA44_eotS =
        "\72\uffff";
    static final String DFA44_eofS =
        "\1\1\71\uffff";
    static final String DFA44_minS =
        "\1\55\56\uffff\1\0\12\uffff";
    static final String DFA44_maxS =
        "\1\u00b9\56\uffff\1\0\12\uffff";
    static final String DFA44_acceptS =
        "\1\uffff\1\2\67\uffff\1\1";
    static final String DFA44_specialS =
        "\57\uffff\1\0\12\uffff}>";
    static final String[] DFA44_transitionS = {
            "\2\1\1\uffff\3\1\2\uffff\5\1\1\uffff\13\1\2\uffff\7\1\3\uffff"+
            "\1\1\1\57\1\1\1\uffff\4\1\1\uffff\4\1\36\uffff\2\1\3\uffff\6"+
            "\1\1\uffff\5\1\3\uffff\4\1\17\uffff\3\1\14\uffff\7\1",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\1\uffff",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA44_eot = DFA.unpackEncodedString(DFA44_eotS);
    static final short[] DFA44_eof = DFA.unpackEncodedString(DFA44_eofS);
    static final char[] DFA44_min = DFA.unpackEncodedStringToUnsignedChars(DFA44_minS);
    static final char[] DFA44_max = DFA.unpackEncodedStringToUnsignedChars(DFA44_maxS);
    static final short[] DFA44_accept = DFA.unpackEncodedString(DFA44_acceptS);
    static final short[] DFA44_special = DFA.unpackEncodedString(DFA44_specialS);
    static final short[][] DFA44_transition;

    static {
        int numStates = DFA44_transitionS.length;
        DFA44_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA44_transition[i] = DFA.unpackEncodedString(DFA44_transitionS[i]);
        }
    }

    class DFA44 extends DFA {

        public DFA44(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 44;
            this.eot = DFA44_eot;
            this.eof = DFA44_eof;
            this.min = DFA44_min;
            this.max = DFA44_max;
            this.accept = DFA44_accept;
            this.special = DFA44_special;
            this.transition = DFA44_transition;
        }
        public String getDescription() {
            return "()* loopback of 503:20: ( options {k=1; backtrack=true; } : ELSEIF_T LEFT_PARETHESIS eElseCond= expression RIGHT_PARETHESIS s2= statement )*";
        }
        public int specialStateTransition(int s, IntStream _input) throws NoViableAltException {
            TokenStream input = (TokenStream)_input;
        	int _s = s;
            switch ( s ) {
                    case 0 : 
                        int LA44_47 = input.LA(1);

                         
                        int index44_47 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred1_CompilerAst()) ) {s = 57;}

                        else if ( (true) ) {s = 1;}

                         
                        input.seek(index44_47);
                        if ( s>=0 ) return s;
                        break;
            }
            if (state.backtracking>0) {state.failed=true; return -1;}
            NoViableAltException nvae =
                new NoViableAltException(getDescription(), 44, _s, input);
            error(nvae);
            throw nvae;
        }
    }
    static final String DFA45_eotS =
        "\72\uffff";
    static final String DFA45_eofS =
        "\1\2\71\uffff";
    static final String DFA45_minS =
        "\1\55\1\0\70\uffff";
    static final String DFA45_maxS =
        "\1\u00b9\1\0\70\uffff";
    static final String DFA45_acceptS =
        "\2\uffff\1\2\66\uffff\1\1";
    static final String DFA45_specialS =
        "\1\uffff\1\0\70\uffff}>";
    static final String[] DFA45_transitionS = {
            "\2\2\1\uffff\3\2\2\uffff\5\2\1\uffff\13\2\2\uffff\7\2\3\uffff"+
            "\2\2\1\1\1\uffff\4\2\1\uffff\4\2\36\uffff\2\2\3\uffff\6\2\1"+
            "\uffff\5\2\3\uffff\4\2\17\uffff\3\2\14\uffff\7\2",
            "\1\uffff",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA45_eot = DFA.unpackEncodedString(DFA45_eotS);
    static final short[] DFA45_eof = DFA.unpackEncodedString(DFA45_eofS);
    static final char[] DFA45_min = DFA.unpackEncodedStringToUnsignedChars(DFA45_minS);
    static final char[] DFA45_max = DFA.unpackEncodedStringToUnsignedChars(DFA45_maxS);
    static final short[] DFA45_accept = DFA.unpackEncodedString(DFA45_acceptS);
    static final short[] DFA45_special = DFA.unpackEncodedString(DFA45_specialS);
    static final short[][] DFA45_transition;

    static {
        int numStates = DFA45_transitionS.length;
        DFA45_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA45_transition[i] = DFA.unpackEncodedString(DFA45_transitionS[i]);
        }
    }

    class DFA45 extends DFA {

        public DFA45(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 45;
            this.eot = DFA45_eot;
            this.eof = DFA45_eof;
            this.min = DFA45_min;
            this.max = DFA45_max;
            this.accept = DFA45_accept;
            this.special = DFA45_special;
            this.transition = DFA45_transition;
        }
        public String getDescription() {
            return "504:9: ( options {k=1; backtrack=true; } : ELSE_T s3= statement )?";
        }
        public int specialStateTransition(int s, IntStream _input) throws NoViableAltException {
            TokenStream input = (TokenStream)_input;
        	int _s = s;
            switch ( s ) {
                    case 0 : 
                        int LA45_1 = input.LA(1);

                         
                        int index45_1 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred2_CompilerAst()) ) {s = 57;}

                        else if ( (true) ) {s = 2;}

                         
                        input.seek(index45_1);
                        if ( s>=0 ) return s;
                        break;
            }
            if (state.backtracking>0) {state.failed=true; return -1;}
            NoViableAltException nvae =
                new NoViableAltException(getDescription(), 45, _s, input);
            error(nvae);
            throw nvae;
        }
    }
    static final String DFA108_eotS =
        "\20\uffff";
    static final String DFA108_eofS =
        "\20\uffff";
    static final String DFA108_minS =
        "\1\56\1\62\1\56\13\uffff\2\56";
    static final String DFA108_maxS =
        "\2\u00b9\1\u0091\13\uffff\2\u0091";
    static final String DFA108_acceptS =
        "\3\uffff\1\1\1\2\1\3\1\4\1\5\1\6\1\7\1\10\1\11\1\12\1\13\2\uffff";
    static final String DFA108_specialS =
        "\20\uffff}>";
    static final String[] DFA108_transitionS = {
            "\1\5\3\uffff\1\2\5\uffff\1\14\25\uffff\1\4\63\uffff\1\13\1\11"+
            "\5\uffff\1\1\1\6\1\10\1\12\1\15\3\uffff\1\3\3\4\36\uffff\1\7"+
            "\6\4",
            "\1\2\33\uffff\1\4\102\uffff\1\3\3\4\37\uffff\6\4",
            "\1\3\2\4\5\uffff\1\4\2\uffff\1\4\14\uffff\2\4\7\uffff\1\16"+
            "\2\4\3\uffff\1\4\11\uffff\43\4\4\uffff\3\4\7\uffff\1\4\1\3",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\1\3\2\4\1\uffff\1\17\3\uffff\1\4\2\uffff\1\4\14\uffff\2\4"+
            "\10\uffff\2\4\3\uffff\1\4\11\uffff\43\4\4\uffff\3\4\7\uffff"+
            "\1\4\1\3",
            "\1\3\2\4\5\uffff\1\4\2\uffff\1\4\14\uffff\2\4\7\uffff\1\16"+
            "\2\4\3\uffff\1\4\11\uffff\43\4\4\uffff\3\4\7\uffff\1\4\1\3"
    };

    static final short[] DFA108_eot = DFA.unpackEncodedString(DFA108_eotS);
    static final short[] DFA108_eof = DFA.unpackEncodedString(DFA108_eofS);
    static final char[] DFA108_min = DFA.unpackEncodedStringToUnsignedChars(DFA108_minS);
    static final char[] DFA108_max = DFA.unpackEncodedStringToUnsignedChars(DFA108_maxS);
    static final short[] DFA108_accept = DFA.unpackEncodedString(DFA108_acceptS);
    static final short[] DFA108_special = DFA.unpackEncodedString(DFA108_specialS);
    static final short[][] DFA108_transition;

    static {
        int numStates = DFA108_transitionS.length;
        DFA108_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA108_transition[i] = DFA.unpackEncodedString(DFA108_transitionS[i]);
        }
    }

    class DFA108 extends DFA {

        public DFA108(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 108;
            this.eot = DFA108_eot;
            this.eof = DFA108_eof;
            this.min = DFA108_min;
            this.max = DFA108_max;
            this.accept = DFA108_accept;
            this.special = DFA108_special;
            this.transition = DFA108_transition;
        }
        public String getDescription() {
            return "1157:1: atom_expr : ( ( AT_T )? variable | ( AT_T )? scalar | LEFT_PARETHESIS expression RIGHT_PARETHESIS | LIST_T LEFT_PARETHESIS assignment_list RIGHT_PARETHESIS -> ^( LIST_T assignment_list ) | 'array' LEFT_PARETHESIS ( array_pair_list )? RIGHT_PARETHESIS -> ^( ARRAY_DECL ( array_pair_list )? ) | NEW_T class_name_reference -> ^( NEW_T class_name_reference ) | CLONE_T variable -> ^( CLONE_T variable ) | EXIT_T ( LEFT_PARETHESIS ( expression )? RIGHT_PARETHESIS )? -> ^( EXIT_T ( expression )? ) | UNSET_T LEFT_PARETHESIS variable_list RIGHT_PARETHESIS -> ^( UNSET_T variable_list ) | lambda_function_declaration | BACKTRICKLITERAL );";
        }
    }
    static final String DFA113_eotS =
        "\6\uffff";
    static final String DFA113_eofS =
        "\6\uffff";
    static final String DFA113_minS =
        "\1\62\1\56\1\uffff\1\56\1\uffff\1\56";
    static final String DFA113_maxS =
        "\2\u0091\1\uffff\1\u0091\1\uffff\1\u0091";
    static final String DFA113_acceptS =
        "\2\uffff\1\1\1\uffff\1\2\1\uffff";
    static final String DFA113_specialS =
        "\6\uffff}>";
    static final String[] DFA113_transitionS = {
            "\1\1\136\uffff\1\2",
            "\1\2\2\4\5\uffff\1\4\2\uffff\1\4\14\uffff\2\4\7\uffff\1\3\2"+
            "\4\3\uffff\1\4\11\uffff\43\4\4\uffff\3\4\7\uffff\1\4\1\2",
            "",
            "\1\2\2\4\1\uffff\1\5\3\uffff\1\4\2\uffff\1\4\14\uffff\2\4\10"+
            "\uffff\2\4\3\uffff\1\4\11\uffff\43\4\4\uffff\3\4\7\uffff\1\4"+
            "\1\2",
            "",
            "\1\2\2\4\5\uffff\1\4\2\uffff\1\4\14\uffff\2\4\7\uffff\1\3\2"+
            "\4\3\uffff\1\4\11\uffff\43\4\4\uffff\3\4\7\uffff\1\4\1\2"
    };

    static final short[] DFA113_eot = DFA.unpackEncodedString(DFA113_eotS);
    static final short[] DFA113_eof = DFA.unpackEncodedString(DFA113_eofS);
    static final char[] DFA113_min = DFA.unpackEncodedStringToUnsignedChars(DFA113_minS);
    static final char[] DFA113_max = DFA.unpackEncodedStringToUnsignedChars(DFA113_maxS);
    static final short[] DFA113_accept = DFA.unpackEncodedString(DFA113_acceptS);
    static final short[] DFA113_special = DFA.unpackEncodedString(DFA113_specialS);
    static final short[][] DFA113_transition;

    static {
        int numStates = DFA113_transitionS.length;
        DFA113_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA113_transition[i] = DFA.unpackEncodedString(DFA113_transitionS[i]);
        }
    }

    class DFA113 extends DFA {

        public DFA113(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 113;
            this.eot = DFA113_eot;
            this.eof = DFA113_eof;
            this.min = DFA113_min;
            this.max = DFA113_max;
            this.accept = DFA113_accept;
            this.special = DFA113_special;
            this.transition = DFA113_transition;
        }
        public String getDescription() {
            return "1196:1: class_name_reference : ( dynamic_name_reference | fully_qualified_class_name );";
        }
    }
    static final String DFA127_eotS =
        "\6\uffff";
    static final String DFA127_eofS =
        "\6\uffff";
    static final String DFA127_minS =
        "\1\62\1\56\1\uffff\1\56\1\uffff\1\56";
    static final String DFA127_maxS =
        "\2\u0091\1\uffff\1\u0091\1\uffff\1\u0091";
    static final String DFA127_acceptS =
        "\2\uffff\1\1\1\uffff\1\2\1\uffff";
    static final String DFA127_specialS =
        "\6\uffff}>";
    static final String[] DFA127_transitionS = {
            "\1\1\136\uffff\1\2",
            "\1\4\40\uffff\1\3\101\uffff\1\2",
            "",
            "\1\4\3\uffff\1\5\136\uffff\1\2",
            "",
            "\1\4\40\uffff\1\3\101\uffff\1\2"
    };

    static final short[] DFA127_eot = DFA.unpackEncodedString(DFA127_eotS);
    static final short[] DFA127_eof = DFA.unpackEncodedString(DFA127_eofS);
    static final char[] DFA127_min = DFA.unpackEncodedStringToUnsignedChars(DFA127_minS);
    static final char[] DFA127_max = DFA.unpackEncodedStringToUnsignedChars(DFA127_maxS);
    static final short[] DFA127_accept = DFA.unpackEncodedString(DFA127_acceptS);
    static final short[] DFA127_special = DFA.unpackEncodedString(DFA127_specialS);
    static final short[][] DFA127_transition;

    static {
        int numStates = DFA127_transitionS.length;
        DFA127_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA127_transition[i] = DFA.unpackEncodedString(DFA127_transitionS[i]);
        }
    }

    class DFA127 extends DFA {

        public DFA127(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 127;
            this.eot = DFA127_eot;
            this.eof = DFA127_eof;
            this.min = DFA127_min;
            this.max = DFA127_max;
            this.accept = DFA127_accept;
            this.special = DFA127_special;
            this.transition = DFA127_transition;
        }
        public String getDescription() {
            return "1316:1: base_variable_with_function_calls : ( ( fully_qualified_class_name )? reference_variable ( ctor_arguments )? -> ^( VAR_DECL ( fully_qualified_class_name )? reference_variable ( ctor_arguments )? ) | fully_qualified_class_name ctor_arguments -> ^( CALL fully_qualified_class_name ctor_arguments ) );";
        }
    }
    static final String DFA133_eotS =
        "\4\uffff";
    static final String DFA133_eofS =
        "\4\uffff";
    static final String DFA133_minS =
        "\1\u0091\1\62\2\uffff";
    static final String DFA133_maxS =
        "\2\u0091\2\uffff";
    static final String DFA133_acceptS =
        "\2\uffff\1\1\1\2";
    static final String DFA133_specialS =
        "\4\uffff}>";
    static final String[] DFA133_transitionS = {
            "\1\1",
            "\1\2\2\uffff\1\3\133\uffff\1\1",
            "",
            ""
    };

    static final short[] DFA133_eot = DFA.unpackEncodedString(DFA133_eotS);
    static final short[] DFA133_eof = DFA.unpackEncodedString(DFA133_eofS);
    static final char[] DFA133_min = DFA.unpackEncodedStringToUnsignedChars(DFA133_minS);
    static final char[] DFA133_max = DFA.unpackEncodedStringToUnsignedChars(DFA133_maxS);
    static final short[] DFA133_accept = DFA.unpackEncodedString(DFA133_acceptS);
    static final short[] DFA133_special = DFA.unpackEncodedString(DFA133_specialS);
    static final short[][] DFA133_transition;

    static {
        int numStates = DFA133_transitionS.length;
        DFA133_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA133_transition[i] = DFA.unpackEncodedString(DFA133_transitionS[i]);
        }
    }

    class DFA133 extends DFA {

        public DFA133(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 133;
            this.eot = DFA133_eot;
            this.eof = DFA133_eof;
            this.min = DFA133_min;
            this.max = DFA133_max;
            this.accept = DFA133_accept;
            this.special = DFA133_special;
            this.transition = DFA133_transition;
        }
        public String getDescription() {
            return "1383:1: compound_variable : ( ( DOLLAR_T )+ IDENTIFIER | ( DOLLAR_T )+ LEFT_BRACKET expression RIGHT_BRACKET );";
        }
    }
 

    public static final BitSet FOLLOW_SOC_T_in_php_source267 = new BitSet(new long[]{0xFBA7600000000000L,0x6000000000047F3FL,0x03F80070001E3EFCL});
    public static final BitSet FOLLOW_SOC_PHP_T_in_php_source279 = new BitSet(new long[]{0xFBA7600000000000L,0x6000000000047F3FL,0x03F80070001E3EFCL});
    public static final BitSet FOLLOW_top_statement_list_in_php_source294 = new BitSet(new long[]{0x0000200000000000L});
    public static final BitSet FOLLOW_EOC_T_in_php_source303 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_top_statement_in_top_statement_list338 = new BitSet(new long[]{0xFBA7400000000002L,0x6000000000047F3FL,0x03F80070001E3EFCL});
    public static final BitSet FOLLOW_statement_in_top_statement352 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_function_declaration_statement_in_top_statement358 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_class_declaration_statement_in_top_statement364 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_halt_compiler_statement_in_top_statement370 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_inner_statement_in_inner_statement_list386 = new BitSet(new long[]{0xFBA7400000000002L,0x6000000000047F3FL,0x03F80070001E3EFCL});
    public static final BitSet FOLLOW_statement_in_inner_statement403 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_function_declaration_statement_in_inner_statement409 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_class_declaration_statement_in_inner_statement415 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_halt_compiler_statement_in_inner_statement421 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_164_in_halt_compiler_statement436 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_halt_compiler_statement438 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_halt_compiler_statement440 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_SEMI_COLON_in_halt_compiler_statement442 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_class_entr_type_in_class_declaration_statement477 = new BitSet(new long[]{0x0002000000000000L});
    public static final BitSet FOLLOW_CLASS_T_in_class_declaration_statement480 = new BitSet(new long[]{0x0004000000000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_class_declaration_statement482 = new BitSet(new long[]{0x0038000000000000L});
    public static final BitSet FOLLOW_EXTENDS_T_in_class_declaration_statement485 = new BitSet(new long[]{0x0004000000000000L});
    public static final BitSet FOLLOW_fully_qualified_class_name_in_class_declaration_statement487 = new BitSet(new long[]{0x0030000000000000L});
    public static final BitSet FOLLOW_IMPLEMENTS_T_in_class_declaration_statement492 = new BitSet(new long[]{0x0004000000000000L});
    public static final BitSet FOLLOW_fully_qualified_class_name_list_in_class_declaration_statement494 = new BitSet(new long[]{0x0020000000000000L});
    public static final BitSet FOLLOW_LEFT_BRACKET_in_class_declaration_statement504 = new BitSet(new long[]{0x0540000000000000L,0x0000000000000008L,0x000007E000000000L});
    public static final BitSet FOLLOW_class_statement_list_in_class_declaration_statement506 = new BitSet(new long[]{0x0040000000000000L});
    public static final BitSet FOLLOW_RIGHT_BRACKET_in_class_declaration_statement509 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_INTERFACE_T_in_class_declaration_statement570 = new BitSet(new long[]{0x0004000000000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_class_declaration_statement572 = new BitSet(new long[]{0x0038000000000000L});
    public static final BitSet FOLLOW_EXTENDS_T_in_class_declaration_statement575 = new BitSet(new long[]{0x0004000000000000L});
    public static final BitSet FOLLOW_fully_qualified_class_name_list_in_class_declaration_statement577 = new BitSet(new long[]{0x0030000000000000L});
    public static final BitSet FOLLOW_IMPLEMENTS_T_in_class_declaration_statement582 = new BitSet(new long[]{0x0004000000000000L});
    public static final BitSet FOLLOW_fully_qualified_class_name_list_in_class_declaration_statement584 = new BitSet(new long[]{0x0020000000000000L});
    public static final BitSet FOLLOW_LEFT_BRACKET_in_class_declaration_statement594 = new BitSet(new long[]{0x0540000000000000L,0x0000000000000008L,0x000007E000000000L});
    public static final BitSet FOLLOW_class_statement_list_in_class_declaration_statement596 = new BitSet(new long[]{0x0040000000000000L});
    public static final BitSet FOLLOW_RIGHT_BRACKET_in_class_declaration_statement599 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_class_entr_type0 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_class_statement_in_class_statement_list674 = new BitSet(new long[]{0x0500000000000002L,0x0000000000000008L,0x000007E000000000L});
    public static final BitSet FOLLOW_variable_modifiers_in_class_statement701 = new BitSet(new long[]{0x0200000000000000L,0x0000000000000000L,0x0000000000020000L});
    public static final BitSet FOLLOW_static_var_list_in_class_statement703 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_SEMI_COLON_in_class_statement705 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_modifier_in_class_statement725 = new BitSet(new long[]{0x0100000000000000L});
    public static final BitSet FOLLOW_FUNCTION_T_in_class_statement728 = new BitSet(new long[]{0x0204000000000000L});
    public static final BitSet FOLLOW_REF_T_in_class_statement730 = new BitSet(new long[]{0x0004000000000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_class_statement733 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_class_statement735 = new BitSet(new long[]{0x0604800000000000L,0x0000000000000000L,0x000FF8000002000CL});
    public static final BitSet FOLLOW_parameter_list_in_class_statement737 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_class_statement740 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_SEMI_COLON_in_class_statement742 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_modifier_in_class_statement773 = new BitSet(new long[]{0x0100000000000000L});
    public static final BitSet FOLLOW_FUNCTION_T_in_class_statement776 = new BitSet(new long[]{0x0204000000000000L});
    public static final BitSet FOLLOW_REF_T_in_class_statement778 = new BitSet(new long[]{0x0004000000000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_class_statement781 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_class_statement783 = new BitSet(new long[]{0x0604800000000000L,0x0000000000000000L,0x000FF8000002000CL});
    public static final BitSet FOLLOW_parameter_list_in_class_statement785 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_class_statement788 = new BitSet(new long[]{0x0020000000000000L});
    public static final BitSet FOLLOW_block_in_class_statement790 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_CONST_T_in_class_statement821 = new BitSet(new long[]{0x0004000000000000L});
    public static final BitSet FOLLOW_directive_in_class_statement823 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_SEMI_COLON_in_class_statement825 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_FUNCTION_T_in_function_declaration_statement870 = new BitSet(new long[]{0x0204000000000000L});
    public static final BitSet FOLLOW_REF_T_in_function_declaration_statement872 = new BitSet(new long[]{0x0004000000000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_function_declaration_statement875 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_function_declaration_statement877 = new BitSet(new long[]{0x0604800000000000L,0x0000000000000000L,0x000FF8000002000CL});
    public static final BitSet FOLLOW_parameter_list_in_function_declaration_statement879 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_function_declaration_statement882 = new BitSet(new long[]{0x0020000000000000L});
    public static final BitSet FOLLOW_block_in_function_declaration_statement889 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LEFT_BRACKET_in_block935 = new BitSet(new long[]{0xFBE7400000000000L,0x6000000000047F3FL,0x03F80070001E3EFCL});
    public static final BitSet FOLLOW_inner_statement_list_in_block937 = new BitSet(new long[]{0x0040000000000000L});
    public static final BitSet FOLLOW_RIGHT_BRACKET_in_block940 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_topStatement_in_statement987 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_block_in_topStatement1029 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_if_stat_in_topStatement1035 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_WHILE_T_in_topStatement1041 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_topStatement1043 = new BitSet(new long[]{0x0304400000000000L,0x6000000000004000L,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_expression_in_topStatement1045 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_topStatement1047 = new BitSet(new long[]{0xFB25400000000000L,0x6000000000247F3FL,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_while_statement_in_topStatement1049 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_DO_T_in_topStatement1082 = new BitSet(new long[]{0xFB25400000000000L,0x6000000000047F3FL,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_statement_in_topStatement1084 = new BitSet(new long[]{0x0800000000000000L});
    public static final BitSet FOLLOW_WHILE_T_in_topStatement1086 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_topStatement1088 = new BitSet(new long[]{0x0304400000000000L,0x6000000000004000L,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_expression_in_topStatement1090 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_topStatement1092 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_SEMI_COLON_in_topStatement1094 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_FOR_T_in_topStatement1124 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_topStatement1126 = new BitSet(new long[]{0x0305400000000000L,0x6000000000004000L,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_expr_list_in_topStatement1130 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_SEMI_COLON_in_topStatement1133 = new BitSet(new long[]{0x0305400000000000L,0x6000000000004000L,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_expr_list_in_topStatement1137 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_SEMI_COLON_in_topStatement1140 = new BitSet(new long[]{0x0304C00000000000L,0x6000000000004000L,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_expr_list_in_topStatement1144 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_topStatement1147 = new BitSet(new long[]{0xFB25400000000000L,0x6000000000247F3FL,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_for_statement_in_topStatement1149 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_SWITCH_T_in_topStatement1193 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_topStatement1195 = new BitSet(new long[]{0x0304400000000000L,0x6000000000004000L,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_expression_in_topStatement1197 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_topStatement1199 = new BitSet(new long[]{0x0020000000000000L,0x0000000000200000L});
    public static final BitSet FOLLOW_switch_case_list_in_topStatement1201 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_BREAK_T_in_topStatement1230 = new BitSet(new long[]{0x0305400000000000L,0x6000000000004000L,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_expression_in_topStatement1232 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_SEMI_COLON_in_topStatement1235 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_CONTINUE_T_in_topStatement1259 = new BitSet(new long[]{0x0305400000000000L,0x6000000000004000L,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_expression_in_topStatement1261 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_SEMI_COLON_in_topStatement1264 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RETURN_T_in_topStatement1300 = new BitSet(new long[]{0x0305400000000000L,0x6000000000004000L,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_expression_in_topStatement1302 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_SEMI_COLON_in_topStatement1305 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_GLOBAL_T_in_topStatement1344 = new BitSet(new long[]{0x0004000000000000L,0x0000000000000000L,0x0000000000020200L});
    public static final BitSet FOLLOW_variable_list_in_topStatement1346 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_SEMI_COLON_in_topStatement1348 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_STATIC_T_in_topStatement1386 = new BitSet(new long[]{0x0200000000000000L,0x0000000000000000L,0x0000000000020000L});
    public static final BitSet FOLLOW_static_var_list_in_topStatement1388 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_SEMI_COLON_in_topStatement1390 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ECHO_T_in_topStatement1425 = new BitSet(new long[]{0x0304400000000000L,0x6000000000004000L,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_expr_list_in_topStatement1427 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_SEMI_COLON_in_topStatement1429 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_expression_in_topStatement1452 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_SEMI_COLON_in_topStatement1454 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_FOREACH_T_in_topStatement1461 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_topStatement1463 = new BitSet(new long[]{0x0304400000000000L,0x6000000000004000L,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_expression_in_topStatement1465 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000040L});
    public static final BitSet FOLLOW_AS_T_in_topStatement1467 = new BitSet(new long[]{0x0204000000000000L,0x0000000000000000L,0x0000000000020200L});
    public static final BitSet FOLLOW_foreach_variable_in_topStatement1469 = new BitSet(new long[]{0x0000800000000000L,0x0000000000000080L});
    public static final BitSet FOLLOW_ARROW_T_in_topStatement1472 = new BitSet(new long[]{0x0204000000000000L,0x0000000000000000L,0x0000000000020200L});
    public static final BitSet FOLLOW_foreach_variable_in_topStatement1474 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_topStatement1478 = new BitSet(new long[]{0xFB25400000000000L,0x6000000000247F3FL,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_foreach_statement_in_topStatement1488 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_DECLARE_T_in_topStatement1523 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_topStatement1525 = new BitSet(new long[]{0x0004000000000000L});
    public static final BitSet FOLLOW_directive_in_topStatement1527 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_topStatement1529 = new BitSet(new long[]{0xFB25400000000000L,0x6000000000247F3FL,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_declare_statement_in_topStatement1531 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_SEMI_COLON_in_topStatement1557 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_TRY_T_in_topStatement1576 = new BitSet(new long[]{0x0020000000000000L});
    public static final BitSet FOLLOW_LEFT_BRACKET_in_topStatement1578 = new BitSet(new long[]{0xFBA7400000000000L,0x6000000000047F3FL,0x03F80070001E3EFCL});
    public static final BitSet FOLLOW_top_statement_in_topStatement1580 = new BitSet(new long[]{0x0040000000000000L});
    public static final BitSet FOLLOW_RIGHT_BRACKET_in_topStatement1582 = new BitSet(new long[]{0x0000000000000000L,0x0000000004000000L});
    public static final BitSet FOLLOW_catch_branch_in_topStatement1584 = new BitSet(new long[]{0x0000000000000002L,0x0000000004000000L});
    public static final BitSet FOLLOW_THROW_T_in_topStatement1615 = new BitSet(new long[]{0x0304400000000000L,0x6000000000004000L,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_expression_in_topStatement1617 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_SEMI_COLON_in_topStatement1619 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_USE_T_in_topStatement1656 = new BitSet(new long[]{0x0000400000000000L,0x0000000000004000L});
    public static final BitSet FOLLOW_use_filename_in_topStatement1658 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_SEMI_COLON_in_topStatement1660 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_INCLUDE_T_in_topStatement1697 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_topStatement1699 = new BitSet(new long[]{0x0304400000000000L,0x6000000000004000L,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_expression_in_topStatement1701 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_topStatement1703 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_SEMI_COLON_in_topStatement1705 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_INCLUDE_ONCE_T_in_topStatement1728 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_topStatement1730 = new BitSet(new long[]{0x0304400000000000L,0x6000000000004000L,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_expression_in_topStatement1732 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_topStatement1734 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_SEMI_COLON_in_topStatement1736 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_REF_T_in_foreach_variable1776 = new BitSet(new long[]{0x0004000000000000L,0x0000000000000000L,0x0000000000020200L});
    public static final BitSet FOLLOW_variable_in_foreach_variable1779 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_STRINGLITERAL_in_use_filename1794 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_use_filename1800 = new BitSet(new long[]{0x0000000000000000L,0x0000000000004000L});
    public static final BitSet FOLLOW_STRINGLITERAL_in_use_filename1803 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_use_filename1805 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_fully_qualified_class_name_in_fully_qualified_class_name_list1834 = new BitSet(new long[]{0x0000000000000002L,0x0000000000010000L});
    public static final BitSet FOLLOW_COMMA_T_in_fully_qualified_class_name_list1837 = new BitSet(new long[]{0x0004000000000000L});
    public static final BitSet FOLLOW_fully_qualified_class_name_in_fully_qualified_class_name_list1839 = new BitSet(new long[]{0x0000000000000002L,0x0000000000010000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_fully_qualified_class_name1875 = new BitSet(new long[]{0x0000000000000002L,0x0000000000008000L});
    public static final BitSet FOLLOW_DOMAIN_T_in_fully_qualified_class_name1878 = new BitSet(new long[]{0x0004000000000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_fully_qualified_class_name1883 = new BitSet(new long[]{0x0000000000000002L,0x0000000000008000L});
    public static final BitSet FOLLOW_DOMAIN_T_in_fully_qualified_class_name1889 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_static_scalar_element_in_static_array_pair_list1910 = new BitSet(new long[]{0x0000000000000002L,0x0000000000010000L});
    public static final BitSet FOLLOW_COMMA_T_in_static_array_pair_list1913 = new BitSet(new long[]{0x0004000000000000L,0x0000000000004000L,0x03F00000001C0200L});
    public static final BitSet FOLLOW_static_scalar_element_in_static_array_pair_list1915 = new BitSet(new long[]{0x0000000000000002L,0x0000000000010000L});
    public static final BitSet FOLLOW_scalar_in_static_scalar_element1942 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000080L});
    public static final BitSet FOLLOW_ARROW_T_in_static_scalar_element1945 = new BitSet(new long[]{0x0004000000000000L,0x0000000000004000L,0x03F00000001C0200L});
    public static final BitSet FOLLOW_scalar_in_static_scalar_element1948 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_static_var_element_in_static_var_list1965 = new BitSet(new long[]{0x0000000000000002L,0x0000000000010000L});
    public static final BitSet FOLLOW_COMMA_T_in_static_var_list1968 = new BitSet(new long[]{0x0200000000000000L,0x0000000000000000L,0x0000000000020000L});
    public static final BitSet FOLLOW_static_var_element_in_static_var_list1970 = new BitSet(new long[]{0x0000000000000002L,0x0000000000010000L});
    public static final BitSet FOLLOW_pure_variable_in_static_var_element2002 = new BitSet(new long[]{0x0000000000000002L,0x0000000000020000L});
    public static final BitSet FOLLOW_EQUAL_T_in_static_var_element2005 = new BitSet(new long[]{0x0004000000000000L,0x0000000000004000L,0x03F00000001C0200L});
    public static final BitSet FOLLOW_scalar_in_static_var_element2008 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IF_T_in_if_stat2039 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_if_stat2041 = new BitSet(new long[]{0x0304400000000000L,0x6000000000004000L,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_expression_in_if_stat2045 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_if_stat2047 = new BitSet(new long[]{0xFB25400000000000L,0x6000000000247F3FL,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_statement_in_if_stat2063 = new BitSet(new long[]{0x0000000000000002L,0x0000000000180000L});
    public static final BitSet FOLLOW_ELSEIF_T_in_if_stat2079 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_if_stat2081 = new BitSet(new long[]{0x0304400000000000L,0x6000000000004000L,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_expression_in_if_stat2085 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_if_stat2087 = new BitSet(new long[]{0xFB25400000000000L,0x6000000000047F3FL,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_statement_in_if_stat2091 = new BitSet(new long[]{0x0000000000000002L,0x0000000000180000L});
    public static final BitSet FOLLOW_ELSE_T_in_if_stat2117 = new BitSet(new long[]{0xFB25400000000000L,0x6000000000047F3FL,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_statement_in_if_stat2121 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_COLON_T_in_if_stat2187 = new BitSet(new long[]{0xFBA7400000000000L,0x60000000005C7F3FL,0x03F80070001E3EFCL});
    public static final BitSet FOLLOW_inner_statement_list_in_if_stat2189 = new BitSet(new long[]{0x0000000000000000L,0x0000000000580000L});
    public static final BitSet FOLLOW_new_elseif_branch_in_if_stat2192 = new BitSet(new long[]{0x0000000000000000L,0x0000000000580000L});
    public static final BitSet FOLLOW_ELSE_T_in_if_stat2209 = new BitSet(new long[]{0x0000000000000000L,0x0000000000200000L});
    public static final BitSet FOLLOW_COLON_T_in_if_stat2211 = new BitSet(new long[]{0xFB25400000000000L,0x6000000000047F3FL,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_statement_in_if_stat2215 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L});
    public static final BitSet FOLLOW_ENDIF_T_in_if_stat2219 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_SEMI_COLON_in_if_stat2221 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ELSEIF_T_in_new_elseif_branch2292 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_new_elseif_branch2294 = new BitSet(new long[]{0x0304400000000000L,0x6000000000004000L,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_expression_in_new_elseif_branch2296 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_new_elseif_branch2298 = new BitSet(new long[]{0x0000000000000000L,0x0000000000200000L});
    public static final BitSet FOLLOW_COLON_T_in_new_elseif_branch2300 = new BitSet(new long[]{0xFBA7400000000002L,0x6000000000047F3FL,0x03F80070001E3EFCL});
    public static final BitSet FOLLOW_inner_statement_list_in_new_elseif_branch2302 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LEFT_BRACKET_in_switch_case_list2340 = new BitSet(new long[]{0x0001000000000000L,0x0000000003000000L});
    public static final BitSet FOLLOW_SEMI_COLON_in_switch_case_list2342 = new BitSet(new long[]{0x0001000000000000L,0x0000000003000000L});
    public static final BitSet FOLLOW_case_list_in_switch_case_list2345 = new BitSet(new long[]{0x0041000000000000L,0x0000000003000000L});
    public static final BitSet FOLLOW_RIGHT_BRACKET_in_switch_case_list2348 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_COLON_T_in_switch_case_list2370 = new BitSet(new long[]{0x0001000000000000L,0x0000000003000000L});
    public static final BitSet FOLLOW_SEMI_COLON_in_switch_case_list2372 = new BitSet(new long[]{0x0001000000000000L,0x0000000003000000L});
    public static final BitSet FOLLOW_case_list_in_switch_case_list2375 = new BitSet(new long[]{0x0001000000000000L,0x0000000003800000L});
    public static final BitSet FOLLOW_ENDSWITCH_T_in_switch_case_list2378 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_SEMI_COLON_in_switch_case_list2380 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_CASE_T_in_case_list2403 = new BitSet(new long[]{0x0304400000000000L,0x6000000000004000L,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_expression_in_case_list2405 = new BitSet(new long[]{0x0001000000000000L,0x0000000000200000L});
    public static final BitSet FOLLOW_COLON_T_in_case_list2408 = new BitSet(new long[]{0xFBA7400000000002L,0x6000000000047F3FL,0x03F80070001E3EFCL});
    public static final BitSet FOLLOW_SEMI_COLON_in_case_list2412 = new BitSet(new long[]{0xFBA7400000000002L,0x6000000000047F3FL,0x03F80070001E3EFCL});
    public static final BitSet FOLLOW_inner_statement_list_in_case_list2415 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_DEFAULT_T_in_case_list2436 = new BitSet(new long[]{0x0001000000000000L,0x0000000000200000L});
    public static final BitSet FOLLOW_COLON_T_in_case_list2439 = new BitSet(new long[]{0xFBA7400000000002L,0x6000000000047F3FL,0x03F80070001E3EFCL});
    public static final BitSet FOLLOW_SEMI_COLON_in_case_list2443 = new BitSet(new long[]{0xFBA7400000000002L,0x6000000000047F3FL,0x03F80070001E3EFCL});
    public static final BitSet FOLLOW_inner_statement_list_in_case_list2446 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_CATCH_T_in_catch_branch2477 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_catch_branch2479 = new BitSet(new long[]{0x0004000000000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_catch_branch2481 = new BitSet(new long[]{0x0004000000000000L,0x0000000000000000L,0x0000000000020200L});
    public static final BitSet FOLLOW_variable_in_catch_branch2483 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_catch_branch2485 = new BitSet(new long[]{0x0020000000000000L});
    public static final BitSet FOLLOW_block_in_catch_branch2493 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_statement_in_for_statement2522 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_COLON_T_in_for_statement2549 = new BitSet(new long[]{0xFBA7400000000000L,0x6000000008047F3FL,0x03F80070001E3EFCL});
    public static final BitSet FOLLOW_inner_statement_list_in_for_statement2551 = new BitSet(new long[]{0x0000000000000000L,0x0000000008000000L});
    public static final BitSet FOLLOW_ENDFOR_T_in_for_statement2554 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_SEMI_COLON_in_for_statement2556 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_statement_in_while_statement2576 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_COLON_T_in_while_statement2603 = new BitSet(new long[]{0xFBA7400000000000L,0x6000000010047F3FL,0x03F80070001E3EFCL});
    public static final BitSet FOLLOW_inner_statement_list_in_while_statement2605 = new BitSet(new long[]{0x0000000000000000L,0x0000000010000000L});
    public static final BitSet FOLLOW_ENDWHILE_T_in_while_statement2608 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_SEMI_COLON_in_while_statement2610 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_statement_in_foreach_statement2631 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_COLON_T_in_foreach_statement2658 = new BitSet(new long[]{0xFBA7400000000000L,0x6000000020047F3FL,0x03F80070001E3EFCL});
    public static final BitSet FOLLOW_inner_statement_list_in_foreach_statement2660 = new BitSet(new long[]{0x0000000000000000L,0x0000000020000000L});
    public static final BitSet FOLLOW_ENDFOREACH_T_in_foreach_statement2663 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_SEMI_COLON_in_foreach_statement2665 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_statement_in_declare_statement2687 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_COLON_T_in_declare_statement2714 = new BitSet(new long[]{0xFBA7400000000000L,0x6000000040047F3FL,0x03F80070001E3EFCL});
    public static final BitSet FOLLOW_inner_statement_list_in_declare_statement2716 = new BitSet(new long[]{0x0000000000000000L,0x0000000040000000L});
    public static final BitSet FOLLOW_ENDDECLARE_T_in_declare_statement2719 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_SEMI_COLON_in_declare_statement2721 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_parameter_in_parameter_list2743 = new BitSet(new long[]{0x0000000000000002L,0x0000000000010000L});
    public static final BitSet FOLLOW_COMMA_T_in_parameter_list2746 = new BitSet(new long[]{0x0604000000000000L,0x0000000000000000L,0x000FF8000002000CL});
    public static final BitSet FOLLOW_parameter_in_parameter_list2748 = new BitSet(new long[]{0x0000000000000002L,0x0000000000010000L});
    public static final BitSet FOLLOW_parameter_type_in_parameter2779 = new BitSet(new long[]{0x0600000000000000L,0x0000000000000000L,0x0000000000020000L});
    public static final BitSet FOLLOW_CONST_T_in_parameter2782 = new BitSet(new long[]{0x0200000000000000L,0x0000000000000000L,0x0000000000020000L});
    public static final BitSet FOLLOW_pure_variable_in_parameter2785 = new BitSet(new long[]{0x0000000000000002L,0x0000000000020000L});
    public static final BitSet FOLLOW_EQUAL_T_in_parameter2801 = new BitSet(new long[]{0x0004000000000000L,0x0000000000004000L,0x03F00000001C0200L});
    public static final BitSet FOLLOW_scalar_in_parameter2803 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_fully_qualified_class_name_in_parameter_type2843 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_cast_option_in_parameter_type2849 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_variable_in_variable_list2864 = new BitSet(new long[]{0x0000000000000002L,0x0000000000010000L});
    public static final BitSet FOLLOW_COMMA_T_in_variable_list2867 = new BitSet(new long[]{0x0004000000000000L,0x0000000000000000L,0x0000000000020200L});
    public static final BitSet FOLLOW_variable_in_variable_list2869 = new BitSet(new long[]{0x0000000000000002L,0x0000000000010000L});
    public static final BitSet FOLLOW_167_in_variable_modifiers2895 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_modifier_in_variable_modifiers2901 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_modifier2915 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000008L,0x0000076000000000L});
    public static final BitSet FOLLOW_directive_element_in_directive2966 = new BitSet(new long[]{0x0000000000000002L,0x0000000000010000L});
    public static final BitSet FOLLOW_COMMA_T_in_directive2969 = new BitSet(new long[]{0x0004000000000000L});
    public static final BitSet FOLLOW_directive_element_in_directive2971 = new BitSet(new long[]{0x0000000000000002L,0x0000000000010000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_directive_element3005 = new BitSet(new long[]{0x0000000000000000L,0x0000000000020000L});
    public static final BitSet FOLLOW_EQUAL_T_in_directive_element3007 = new BitSet(new long[]{0x0304400000000000L,0x6000000000004000L,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_expression_in_directive_element3009 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_expression_in_expr_list3043 = new BitSet(new long[]{0x0000000000000002L,0x0000000000010000L});
    public static final BitSet FOLLOW_COMMA_T_in_expr_list3046 = new BitSet(new long[]{0x0304400000000000L,0x6000000000004000L,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_expression_in_expr_list3048 = new BitSet(new long[]{0x0000000000000002L,0x0000000000010000L});
    public static final BitSet FOLLOW_logical_text_or_expr_in_expression3083 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_logical_text_xor_expr_in_logical_text_or_expr3126 = new BitSet(new long[]{0x0000000000000002L,0x0000000080000000L});
    public static final BitSet FOLLOW_OR_T_in_logical_text_or_expr3129 = new BitSet(new long[]{0x0304400000000000L,0x6000000000004000L,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_logical_text_xor_expr_in_logical_text_or_expr3134 = new BitSet(new long[]{0x0000000000000002L,0x0000000080000000L});
    public static final BitSet FOLLOW_logical_text_and_expr_in_logical_text_xor_expr3165 = new BitSet(new long[]{0x0000000000000002L,0x0000000100000000L});
    public static final BitSet FOLLOW_XOR_T_in_logical_text_xor_expr3168 = new BitSet(new long[]{0x0304400000000000L,0x6000000000004000L,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_logical_text_and_expr_in_logical_text_xor_expr3173 = new BitSet(new long[]{0x0000000000000002L,0x0000000100000000L});
    public static final BitSet FOLLOW_assignment_expr_in_logical_text_and_expr3204 = new BitSet(new long[]{0x0000000000000002L,0x0000000200000000L});
    public static final BitSet FOLLOW_AND_T_in_logical_text_and_expr3207 = new BitSet(new long[]{0x0304400000000000L,0x6000000000004000L,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_assignment_expr_in_logical_text_and_expr3212 = new BitSet(new long[]{0x0000000000000002L,0x0000000200000000L});
    public static final BitSet FOLLOW_conditional_expr_in_assignment_expr3243 = new BitSet(new long[]{0x0000000000000002L,0x00001FFC00020000L});
    public static final BitSet FOLLOW_assignment_operator_in_assignment_expr3246 = new BitSet(new long[]{0x0304400000000000L,0x6000000000004000L,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_conditional_expr_in_assignment_expr3251 = new BitSet(new long[]{0x0000000000000002L,0x00001FFC00020000L});
    public static final BitSet FOLLOW_set_in_assignment_operator0 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_logical_or_expr_in_conditional_expr3388 = new BitSet(new long[]{0x0000000000000002L,0x0000200000000000L});
    public static final BitSet FOLLOW_QUESTION_T_in_conditional_expr3407 = new BitSet(new long[]{0x0304400000000000L,0x6000000000204000L,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_expression_in_conditional_expr3409 = new BitSet(new long[]{0x0000000000000000L,0x0000000000200000L});
    public static final BitSet FOLLOW_COLON_T_in_conditional_expr3412 = new BitSet(new long[]{0x0304400000000000L,0x6000000000004000L,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_logical_or_expr_in_conditional_expr3416 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_logical_and_expr_in_logical_or_expr3466 = new BitSet(new long[]{0x0000000000000002L,0x0000400000000000L});
    public static final BitSet FOLLOW_LOGICAL_OR_T_in_logical_or_expr3469 = new BitSet(new long[]{0x0304400000000000L,0x6000000000004000L,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_logical_and_expr_in_logical_or_expr3474 = new BitSet(new long[]{0x0000000000000002L,0x0000400000000000L});
    public static final BitSet FOLLOW_bitwise_or_expr_in_logical_and_expr3505 = new BitSet(new long[]{0x0000000000000002L,0x0000800000000000L});
    public static final BitSet FOLLOW_LOGICAL_AND_T_in_logical_and_expr3508 = new BitSet(new long[]{0x0304400000000000L,0x6000000000004000L,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_bitwise_or_expr_in_logical_and_expr3513 = new BitSet(new long[]{0x0000000000000002L,0x0000800000000000L});
    public static final BitSet FOLLOW_bitwise_xor_expr_in_bitwise_or_expr3544 = new BitSet(new long[]{0x0000000000000002L,0x0001000000000000L});
    public static final BitSet FOLLOW_BIT_OR_T_in_bitwise_or_expr3547 = new BitSet(new long[]{0x0304400000000000L,0x6000000000004000L,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_bitwise_xor_expr_in_bitwise_or_expr3552 = new BitSet(new long[]{0x0000000000000002L,0x0001000000000000L});
    public static final BitSet FOLLOW_bitwise_and_expr_in_bitwise_xor_expr3583 = new BitSet(new long[]{0x0000000000000002L,0x0002000000000000L});
    public static final BitSet FOLLOW_POWER_T_in_bitwise_xor_expr3586 = new BitSet(new long[]{0x0304400000000000L,0x6000000000004000L,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_bitwise_and_expr_in_bitwise_xor_expr3591 = new BitSet(new long[]{0x0000000000000002L,0x0002000000000000L});
    public static final BitSet FOLLOW_concat_expr_in_bitwise_and_expr3622 = new BitSet(new long[]{0x0000000000000002L,0x0004000000000000L});
    public static final BitSet FOLLOW_DOT_T_in_bitwise_and_expr3625 = new BitSet(new long[]{0x0304400000000000L,0x6000000000004000L,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_concat_expr_in_bitwise_and_expr3630 = new BitSet(new long[]{0x0000000000000002L,0x0004000000000000L});
    public static final BitSet FOLLOW_equality_expr_in_concat_expr3661 = new BitSet(new long[]{0x0200000000000002L});
    public static final BitSet FOLLOW_REF_T_in_concat_expr3664 = new BitSet(new long[]{0x0304400000000000L,0x6000000000004000L,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_equality_expr_in_concat_expr3669 = new BitSet(new long[]{0x0200000000000002L});
    public static final BitSet FOLLOW_relational_expr_in_equality_expr3700 = new BitSet(new long[]{0x0000000000000002L,0x0078000000000000L});
    public static final BitSet FOLLOW_set_in_equality_expr3703 = new BitSet(new long[]{0x0304400000000000L,0x6000000000004000L,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_relational_expr_in_equality_expr3722 = new BitSet(new long[]{0x0000000000000002L,0x0078000000000000L});
    public static final BitSet FOLLOW_shift_expr_in_relational_expr3753 = new BitSet(new long[]{0x0000000000000002L,0x0780000000000000L});
    public static final BitSet FOLLOW_set_in_relational_expr3756 = new BitSet(new long[]{0x0304400000000000L,0x6000000000004000L,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_shift_expr_in_relational_expr3775 = new BitSet(new long[]{0x0000000000000002L,0x0780000000000000L});
    public static final BitSet FOLLOW_additive_expr_in_shift_expr3806 = new BitSet(new long[]{0x0000000000000002L,0x1800000000000000L});
    public static final BitSet FOLLOW_set_in_shift_expr3809 = new BitSet(new long[]{0x0304400000000000L,0x6000000000004000L,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_additive_expr_in_shift_expr3820 = new BitSet(new long[]{0x0000000000000002L,0x1800000000000000L});
    public static final BitSet FOLLOW_multiplicative_expr_in_additive_expr3851 = new BitSet(new long[]{0x0000000000000002L,0x6000000000000000L});
    public static final BitSet FOLLOW_set_in_additive_expr3854 = new BitSet(new long[]{0x0304400000000000L,0x6000000000004000L,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_multiplicative_expr_in_additive_expr3865 = new BitSet(new long[]{0x0000000000000002L,0x6000000000000000L});
    public static final BitSet FOLLOW_cast_expr_in_multiplicative_expr3896 = new BitSet(new long[]{0x0000000000000002L,0x8000000000000000L,0x0000000000000003L});
    public static final BitSet FOLLOW_set_in_multiplicative_expr3899 = new BitSet(new long[]{0x0304400000000000L,0x6000000000004000L,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_cast_expr_in_multiplicative_expr3914 = new BitSet(new long[]{0x0000000000000002L,0x8000000000000000L,0x0000000000000003L});
    public static final BitSet FOLLOW_unary_expr_in_cast_expr3943 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_cast_expr3950 = new BitSet(new long[]{0x0004000000000000L,0x0000000000000000L,0x000FF8000000000CL});
    public static final BitSet FOLLOW_cast_option_in_cast_expr3952 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_cast_expr3954 = new BitSet(new long[]{0x0304400000000000L,0x6000000000004000L,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_unary_expr_in_cast_expr3958 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_cast_option0 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_unary_expr4078 = new BitSet(new long[]{0x0304400000000000L,0x6000000000004000L,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_prefix_inc_dec_expr_in_unary_expr4101 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_post_inc_dec_expr_in_prefix_inc_dec_expr4129 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_plus_minus_in_prefix_inc_dec_expr4136 = new BitSet(new long[]{0x0304400000000000L,0x6000000000004000L,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_post_inc_dec_expr_in_prefix_inc_dec_expr4140 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_instance_expr_in_post_inc_dec_expr4185 = new BitSet(new long[]{0x0304400000000002L,0x6000000000004000L,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_plus_minus_in_post_inc_dec_expr4195 = new BitSet(new long[]{0x0304400000000002L,0x6000000000004000L,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_set_in_plus_minus0 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_atom_expr_in_instance_expr4264 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000000100L});
    public static final BitSet FOLLOW_INSTANCEOF_T_in_instance_expr4267 = new BitSet(new long[]{0x0004000000000000L,0x0000000000000000L,0x0000000000020200L});
    public static final BitSet FOLLOW_class_name_reference_in_instance_expr4270 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_AT_T_in_atom_expr4302 = new BitSet(new long[]{0x0004000000000000L,0x0000000000000000L,0x0000000000020200L});
    public static final BitSet FOLLOW_variable_in_atom_expr4305 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_AT_T_in_atom_expr4312 = new BitSet(new long[]{0x0004000000000000L,0x0000000000004000L,0x03F00000001C0200L});
    public static final BitSet FOLLOW_scalar_in_atom_expr4315 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_atom_expr4322 = new BitSet(new long[]{0x0304400000000000L,0x6000000000004000L,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_expression_in_atom_expr4324 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_atom_expr4326 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LIST_T_in_atom_expr4333 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_atom_expr4335 = new BitSet(new long[]{0x0004800000000000L,0x0000000000010000L,0x0000000000020600L});
    public static final BitSet FOLLOW_assignment_list_in_atom_expr4337 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_atom_expr4339 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_179_in_atom_expr4359 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_atom_expr4361 = new BitSet(new long[]{0x0304C00000000000L,0x6000000000004000L,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_array_pair_list_in_atom_expr4363 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_atom_expr4366 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NEW_T_in_atom_expr4395 = new BitSet(new long[]{0x0004000000000000L,0x0000000000000000L,0x0000000000020200L});
    public static final BitSet FOLLOW_class_name_reference_in_atom_expr4397 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_CLONE_T_in_atom_expr4414 = new BitSet(new long[]{0x0004000000000000L,0x0000000000000000L,0x0000000000020200L});
    public static final BitSet FOLLOW_variable_in_atom_expr4416 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_EXIT_T_in_atom_expr4438 = new BitSet(new long[]{0x0000400000000002L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_atom_expr4441 = new BitSet(new long[]{0x0304C00000000000L,0x6000000000004000L,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_expression_in_atom_expr4443 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_atom_expr4446 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_UNSET_T_in_atom_expr4466 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_atom_expr4468 = new BitSet(new long[]{0x0004000000000000L,0x0000000000000000L,0x0000000000020200L});
    public static final BitSet FOLLOW_variable_list_in_atom_expr4470 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_atom_expr4472 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_lambda_function_declaration_in_atom_expr4489 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_BACKTRICKLITERAL_in_atom_expr4496 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_FUNCTION_T_in_lambda_function_declaration4511 = new BitSet(new long[]{0x0200400000000000L});
    public static final BitSet FOLLOW_REF_T_in_lambda_function_declaration4513 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_lambda_function_declaration4516 = new BitSet(new long[]{0x0604800000000000L,0x0000000000000000L,0x000FF8000002000CL});
    public static final BitSet FOLLOW_parameter_list_in_lambda_function_declaration4518 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_lambda_function_declaration4521 = new BitSet(new long[]{0x0020000000000000L,0x0000000000000800L});
    public static final BitSet FOLLOW_USE_T_in_lambda_function_declaration4524 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_lambda_function_declaration4526 = new BitSet(new long[]{0x0304C00000000000L,0x6000000000004000L,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_expr_list_in_lambda_function_declaration4528 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_lambda_function_declaration4531 = new BitSet(new long[]{0x0020000000000000L});
    public static final BitSet FOLLOW_block_in_lambda_function_declaration4539 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_dynamic_name_reference_in_class_name_reference4591 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_fully_qualified_class_name_in_class_name_reference4597 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_base_variable_with_function_calls_in_dynamic_name_reference4625 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000004000L});
    public static final BitSet FOLLOW_SINGLE_ARROW_T_in_dynamic_name_reference4650 = new BitSet(new long[]{0x0024000000000000L,0x0000000000000000L,0x0000000000020000L});
    public static final BitSet FOLLOW_object_property_in_dynamic_name_reference4652 = new BitSet(new long[]{0x0000400000000002L,0x0000000000000000L,0x0000000000004000L});
    public static final BitSet FOLLOW_ctor_arguments_in_dynamic_name_reference4654 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000004000L});
    public static final BitSet FOLLOW_assignment_element_in_assignment_list4705 = new BitSet(new long[]{0x0000000000000002L,0x0000000000010000L});
    public static final BitSet FOLLOW_COMMA_T_in_assignment_list4709 = new BitSet(new long[]{0x0004000000000002L,0x0000000000010000L,0x0000000000020600L});
    public static final BitSet FOLLOW_assignment_element_in_assignment_list4711 = new BitSet(new long[]{0x0000000000000002L,0x0000000000010000L});
    public static final BitSet FOLLOW_variable_in_assignment_element4735 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LIST_T_in_assignment_element4741 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_assignment_element4743 = new BitSet(new long[]{0x0004800000000000L,0x0000000000010000L,0x0000000000020600L});
    public static final BitSet FOLLOW_assignment_list_in_assignment_element4745 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_assignment_element4747 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_array_pair_element_in_array_pair_list4784 = new BitSet(new long[]{0x0000000000000002L,0x0000000000010000L});
    public static final BitSet FOLLOW_COMMA_T_in_array_pair_list4787 = new BitSet(new long[]{0x0304400000000000L,0x6000000000004000L,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_array_pair_element_in_array_pair_list4791 = new BitSet(new long[]{0x0000000000000002L,0x0000000000010000L});
    public static final BitSet FOLLOW_COMMA_T_in_array_pair_list4795 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_expression_in_array_pair_element4840 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000080L});
    public static final BitSet FOLLOW_ARROW_T_in_array_pair_element4843 = new BitSet(new long[]{0x0304400000000000L,0x6000000000004000L,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_expression_in_array_pair_element4848 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_base_variable_with_function_calls_in_variable4882 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000004000L});
    public static final BitSet FOLLOW_SINGLE_ARROW_T_in_variable4905 = new BitSet(new long[]{0x0024000000000000L,0x0000000000000000L,0x0000000000020000L});
    public static final BitSet FOLLOW_object_property_in_variable4907 = new BitSet(new long[]{0x0000400000000002L,0x0000000000000000L,0x0000000000004000L});
    public static final BitSet FOLLOW_ctor_arguments_in_variable4909 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000004000L});
    public static final BitSet FOLLOW_fully_qualified_class_name_in_base_variable_with_function_calls4966 = new BitSet(new long[]{0x0004000000000000L,0x0000000000000000L,0x0000000000020000L});
    public static final BitSet FOLLOW_reference_variable_in_base_variable_with_function_calls4969 = new BitSet(new long[]{0x0000400000000002L});
    public static final BitSet FOLLOW_ctor_arguments_in_base_variable_with_function_calls4971 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_fully_qualified_class_name_in_base_variable_with_function_calls5005 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_ctor_arguments_in_base_variable_with_function_calls5007 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_reference_variable_in_object_property5050 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_reference_variable_without_dollar_in_object_property5056 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_compound_variable_in_reference_variable5082 = new BitSet(new long[]{0x0020000000000002L,0x0000000000000000L,0x0000000000008000L});
    public static final BitSet FOLLOW_LEFT_OPEN_RECT_in_reference_variable5107 = new BitSet(new long[]{0x0304400000000000L,0x6000000000004000L,0x03F80000001F3EFCL});
    public static final BitSet FOLLOW_expression_in_reference_variable5111 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000010000L});
    public static final BitSet FOLLOW_RIGHT_OPEN_RECT_in_reference_variable5114 = new BitSet(new long[]{0x0020000000000002L,0x0000000000000000L,0x0000000000008000L});
    public static final BitSet FOLLOW_LEFT_BRACKET_in_reference_variable5144 = new BitSet(new long[]{0x0304400000000000L,0x6000000000004000L,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_expression_in_reference_variable5148 = new BitSet(new long[]{0x0040000000000000L});
    public static final BitSet FOLLOW_RIGHT_BRACKET_in_reference_variable5150 = new BitSet(new long[]{0x0020000000000002L,0x0000000000000000L,0x0000000000008000L});
    public static final BitSet FOLLOW_DOLLAR_T_in_compound_variable5191 = new BitSet(new long[]{0x0004000000000000L,0x0000000000000000L,0x0000000000020000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_compound_variable5194 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_DOLLAR_T_in_compound_variable5201 = new BitSet(new long[]{0x0020000000000000L,0x0000000000000000L,0x0000000000020000L});
    public static final BitSet FOLLOW_LEFT_BRACKET_in_compound_variable5204 = new BitSet(new long[]{0x0304400000000000L,0x6000000000004000L,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_expression_in_compound_variable5207 = new BitSet(new long[]{0x0040000000000000L});
    public static final BitSet FOLLOW_RIGHT_BRACKET_in_compound_variable5209 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_compound_variable_without_dollar_in_reference_variable_without_dollar5236 = new BitSet(new long[]{0x0020000000000002L,0x0000000000000000L,0x0000000000008000L});
    public static final BitSet FOLLOW_LEFT_OPEN_RECT_in_reference_variable_without_dollar5254 = new BitSet(new long[]{0x0304400000000000L,0x6000000000004000L,0x03F80000001F3EFCL});
    public static final BitSet FOLLOW_expression_in_reference_variable_without_dollar5256 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000010000L});
    public static final BitSet FOLLOW_RIGHT_OPEN_RECT_in_reference_variable_without_dollar5259 = new BitSet(new long[]{0x0020000000000002L,0x0000000000000000L,0x0000000000008000L});
    public static final BitSet FOLLOW_LEFT_BRACKET_in_reference_variable_without_dollar5282 = new BitSet(new long[]{0x0304400000000000L,0x6000000000004000L,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_expression_in_reference_variable_without_dollar5284 = new BitSet(new long[]{0x0040000000000000L});
    public static final BitSet FOLLOW_RIGHT_BRACKET_in_reference_variable_without_dollar5286 = new BitSet(new long[]{0x0020000000000002L,0x0000000000000000L,0x0000000000008000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_compound_variable_without_dollar5319 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LEFT_BRACKET_in_compound_variable_without_dollar5325 = new BitSet(new long[]{0x0304400000000000L,0x6000000000004000L,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_expression_in_compound_variable_without_dollar5328 = new BitSet(new long[]{0x0040000000000000L});
    public static final BitSet FOLLOW_RIGHT_BRACKET_in_compound_variable_without_dollar5330 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_ctor_arguments5357 = new BitSet(new long[]{0x0304C00000000000L,0x6000000000004000L,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_expr_list_in_ctor_arguments5359 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_ctor_arguments5362 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_REF_T_in_pure_variable5408 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000020000L});
    public static final BitSet FOLLOW_DOLLAR_T_in_pure_variable5411 = new BitSet(new long[]{0x0004000000000000L,0x0000000000000000L,0x0000000000020000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_pure_variable5414 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_constant_in_scalar5466 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_INTLITERAL_in_constant5501 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_FLOATLITERAL_in_constant5510 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_STRINGLITERAL_in_constant5518 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_DOUBLELITERRAL_in_constant5527 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_common_scalar_in_constant5534 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_fully_qualified_class_name_in_constant5542 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_common_scalar0 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ELSEIF_T_in_synpred1_CompilerAst2079 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_synpred1_CompilerAst2081 = new BitSet(new long[]{0x0304400000000000L,0x6000000000004000L,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_expression_in_synpred1_CompilerAst2085 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_synpred1_CompilerAst2087 = new BitSet(new long[]{0xFB25400000000000L,0x6000000000047F3FL,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_statement_in_synpred1_CompilerAst2091 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ELSE_T_in_synpred2_CompilerAst2117 = new BitSet(new long[]{0xFB25400000000000L,0x6000000000047F3FL,0x03F80000001E3EFCL});
    public static final BitSet FOLLOW_statement_in_synpred2_CompilerAst2121 = new BitSet(new long[]{0x0000000000000002L});

}