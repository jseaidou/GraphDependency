package org.eclipse.php.internal.core.compiler.ast.parser.php5;

public class StdErrReporter implements IErrorReporter {
    public void reportError(String error) {
    	System.out.println("here is the error");
        System.err.println(error);
    }
}
