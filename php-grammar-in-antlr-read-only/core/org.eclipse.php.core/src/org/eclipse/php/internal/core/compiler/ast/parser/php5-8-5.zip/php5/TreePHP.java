// $ANTLR 3.1.3 Mar 17, 2009 19:23:44 /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g 2009-08-05 10:40:46

  package org.eclipse.php.internal.core.compiler.ast.parser.php5;
  
  import org.eclipse.dltk.ast.*;
import org.eclipse.dltk.ast.declarations.*;
import org.eclipse.dltk.ast.expressions.*;
import org.eclipse.dltk.ast.references.*;
import org.eclipse.dltk.ast.statements.*;
import org.eclipse.php.internal.core.compiler.ast.nodes.*;
import org.eclipse.php.internal.core.compiler.ast.parser.*;
import java.util.*;
import org.antlr.runtime.BitSet;


import org.antlr.runtime.*;
import org.antlr.runtime.tree.*;import java.util.Stack;
import java.util.List;
import java.util.ArrayList;


public class TreePHP extends TreeParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "ModuleDeclaration", "ClassDeclaration", "PROG", "CLASS_BODY", "FIELD_DECL", "METHOD_DECL", "TYPE", "PARAMETER", "BLOCK", "VAR_DECL", "STATEMENT", "CONDITION", "LIST", "INDEX", "MEMBERACCESS", "CALL", "ELIST", "EXPR", "ASSIGN", "LIST_DECL", "SCALAR_ELEMENT", "SCALAR_VAR", "CAST", "LABEL", "ITERATE", "USE_DECL", "ARGU", "CALLED_OBJ", "PREFIX", "POSTFIX", "NAMESPACE", "EMPTYSTATEMENT", "SCALAR", "ARRAY_DECL", "PREFIX_EXPR", "POSTFIX_EXPR", "CAST_EXPR", "VAR", "HASH_INDEX", "SOC_T", "SOC_PHP_T", "EOC_T", "LEFT_PARETHESIS", "RIGHT_PARETHESIS", "SEMI_COLON", "CLASS_T", "IDENTIFIER", "EXTENDS_T", "IMPLEMENTS_T", "LEFT_BRACKET", "RIGHT_BRACKET", "INTERFACE_T", "FUNCTION_T", "REF_T", "CONST_T", "WHILE_T", "DO_T", "FOR_T", "SWITCH_T", "BREAK_T", "CONTINUE_T", "RETURN_T", "GLOBAL_T", "STATIC_T", "ECHO_T", "FOREACH_T", "AS_T", "ARROW_T", "DECLARE_T", "TRY_T", "THROW_T", "USE_T", "INCLUDE_T", "INCLUDE_ONCE_T", "STRINGLITERAL", "DOMAIN_T", "COMMA_T", "EQUAL_T", "IF_T", "ELSEIF_T", "ELSE_T", "COLON_T", "ENDIF_T", "ENDSWITCH_T", "CASE_T", "DEFAULT_T", "CATCH_T", "ENDFOR_T", "ENDWHILE_T", "ENDFOREACH_T", "ENDDECLARE_T", "OR_T", "XOR_T", "AND_T", "PLUS_EQ", "MINUS_EQ", "MUL_EQ", "DIV_EQ", "DOT_EQ", "PERCENT_EQ", "BIT_AND_EQ", "BIT_OR_EQ", "POWER_EQ", "LMOVE_EQ", "RMOVE_EQ", "QUESTION_T", "LOGICAL_OR_T", "LOGICAL_AND_T", "BIT_OR_T", "POWER_T", "DOT_T", "EQUAL_EQUAL_T", "NOT_EQUAL_T", "EQUAL_EQUAL_EQUAL_T", "NOT_EQUAL_EQUAL_T", "LT_T", "MT_T", "LE_T", "ME_T", "LSHIFT_T", "RSHIFT_T", "PLUS_T", "MINUS_T", "MUL_T", "DIV_T", "PERCENT_T", "UNSET_T", "CLONE_T", "TILDA_T", "EXC_NOT_T", "PLUS_PLUS_T", "MINUS_MINUS_T", "INSTANCEOF_T", "AT_T", "LIST_T", "NEW_T", "EXIT_T", "BACKTRICKLITERAL", "SINGLE_ARROW_T", "LEFT_OPEN_RECT", "RIGHT_OPEN_RECT", "DOLLAR_T", "INTLITERAL", "FLOATLITERAL", "DOUBLELITERRAL", "IntegerNumber", "LongSuffix", "HexPrefix", "HexDigit", "STATIC", "NonIntegerNumber", "FloatSuffix", "DoubleSuffix", "Exponent", "EscapeSequence", "IdentifierStart", "IdentifierPart", "WS", "COMMENT", "LINE_COMMENT", "'__halt_compiler'", "'abstract'", "'final'", "'var'", "'public'", "'protected'", "'private'", "'bool'", "'boolean'", "'int'", "'float'", "'double'", "'real'", "'string'", "'object'", "'array'", "'__CLASS__'", "'__DIR__'", "'__FILE__'", "'__FUNCTION__'", "'__METHOD__'", "'__NAMESPACE__'"
    };
    public static final int CAST=26;
    public static final int PREFIX=32;
    public static final int RIGHT_OPEN_RECT=144;
    public static final int XOR_T=96;
    public static final int TRY_T=73;
    public static final int POSTFIX=33;
    public static final int LOGICAL_OR_T=110;
    public static final int ENDFOR_T=91;
    public static final int PERCENT_EQ=103;
    public static final int HASH_INDEX=42;
    public static final int INCLUDE_T=76;
    public static final int AS_T=70;
    public static final int VAR_DECL=13;
    public static final int CONDITION=15;
    public static final int DIV_T=128;
    public static final int DOMAIN_T=79;
    public static final int COMMA_T=80;
    public static final int T__167=167;
    public static final int T__168=168;
    public static final int EOF=-1;
    public static final int T__165=165;
    public static final int EQUAL_EQUAL_T=115;
    public static final int STATIC_T=67;
    public static final int T__166=166;
    public static final int STATEMENT=14;
    public static final int DOT_T=114;
    public static final int T__164=164;
    public static final int TYPE=10;
    public static final int ENDIF_T=86;
    public static final int POSTFIX_EXPR=39;
    public static final int CALLED_OBJ=31;
    public static final int EOC_T=45;
    public static final int CAST_EXPR=40;
    public static final int DIV_EQ=101;
    public static final int NOT_EQUAL_EQUAL_T=118;
    public static final int GLOBAL_T=66;
    public static final int ELIST=20;
    public static final int IF_T=82;
    public static final int AT_T=137;
    public static final int NonIntegerNumber=154;
    public static final int FloatSuffix=155;
    public static final int MT_T=120;
    public static final int PARAMETER=11;
    public static final int AND_T=97;
    public static final int ELSE_T=84;
    public static final int SCALAR=36;
    public static final int RIGHT_BRACKET=54;
    public static final int SINGLE_ARROW_T=142;
    public static final int ARGU=30;
    public static final int VAR=41;
    public static final int FOR_T=61;
    public static final int RSHIFT_T=124;
    public static final int COMMENT=162;
    public static final int HexPrefix=151;
    public static final int MINUS_MINUS_T=135;
    public static final int ARROW_T=71;
    public static final int RMOVE_EQ=108;
    public static final int LINE_COMMENT=163;
    public static final int EQUAL_EQUAL_EQUAL_T=117;
    public static final int STATIC=153;
    public static final int CLONE_T=131;
    public static final int WHILE_T=59;
    public static final int ARRAY_DECL=37;
    public static final int MUL_EQ=100;
    public static final int IdentifierStart=159;
    public static final int DECLARE_T=72;
    public static final int SEMI_COLON=48;
    public static final int OR_T=95;
    public static final int INTERFACE_T=55;
    public static final int INTLITERAL=146;
    public static final int THROW_T=74;
    public static final int PLUS_EQ=98;
    public static final int LIST=16;
    public static final int REF_T=57;
    public static final int ENDDECLARE_T=94;
    public static final int PLUS_T=125;
    public static final int NAMESPACE=34;
    public static final int MINUS_EQ=99;
    public static final int LongSuffix=150;
    public static final int ENDFOREACH_T=93;
    public static final int EMPTYSTATEMENT=35;
    public static final int WS=161;
    public static final int DO_T=60;
    public static final int EQUAL_T=81;
    public static final int COLON_T=85;
    public static final int UNSET_T=130;
    public static final int NEW_T=139;
    public static final int USE_T=75;
    public static final int SOC_PHP_T=44;
    public static final int MINUS_T=126;
    public static final int MEMBERACCESS=18;
    public static final int PLUS_PLUS_T=134;
    public static final int CALL=19;
    public static final int SCALAR_ELEMENT=24;
    public static final int POWER_EQ=106;
    public static final int INCLUDE_ONCE_T=77;
    public static final int BIT_AND_EQ=104;
    public static final int EscapeSequence=158;
    public static final int CLASS_T=49;
    public static final int IntegerNumber=149;
    public static final int ECHO_T=68;
    public static final int LEFT_BRACKET=53;
    public static final int DOLLAR_T=145;
    public static final int DOUBLELITERRAL=148;
    public static final int SOC_T=43;
    public static final int METHOD_DECL=9;
    public static final int CATCH_T=90;
    public static final int Exponent=157;
    public static final int LE_T=121;
    public static final int PERCENT_T=129;
    public static final int IMPLEMENTS_T=52;
    public static final int HexDigit=152;
    public static final int DEFAULT_T=89;
    public static final int INDEX=17;
    public static final int PROG=6;
    public static final int EXPR=21;
    public static final int USE_DECL=29;
    public static final int NOT_EQUAL_T=116;
    public static final int POWER_T=113;
    public static final int IDENTIFIER=50;
    public static final int LEFT_OPEN_RECT=143;
    public static final int LMOVE_EQ=107;
    public static final int SCALAR_VAR=25;
    public static final int CONST_T=58;
    public static final int TILDA_T=132;
    public static final int IdentifierPart=160;
    public static final int FUNCTION_T=56;
    public static final int T__184=184;
    public static final int SWITCH_T=62;
    public static final int T__183=183;
    public static final int EXIT_T=140;
    public static final int T__185=185;
    public static final int MUL_T=127;
    public static final int LOGICAL_AND_T=111;
    public static final int QUESTION_T=109;
    public static final int LSHIFT_T=123;
    public static final int BIT_OR_EQ=105;
    public static final int BIT_OR_T=112;
    public static final int T__180=180;
    public static final int INSTANCEOF_T=136;
    public static final int FOREACH_T=69;
    public static final int ELSEIF_T=83;
    public static final int T__182=182;
    public static final int T__181=181;
    public static final int PREFIX_EXPR=38;
    public static final int FIELD_DECL=8;
    public static final int LT_T=119;
    public static final int CLASS_BODY=7;
    public static final int LIST_T=138;
    public static final int LIST_DECL=23;
    public static final int ModuleDeclaration=4;
    public static final int T__175=175;
    public static final int BACKTRICKLITERAL=141;
    public static final int T__174=174;
    public static final int ITERATE=28;
    public static final int T__173=173;
    public static final int T__172=172;
    public static final int RETURN_T=65;
    public static final int LEFT_PARETHESIS=46;
    public static final int T__179=179;
    public static final int T__178=178;
    public static final int T__177=177;
    public static final int T__176=176;
    public static final int ME_T=122;
    public static final int DoubleSuffix=156;
    public static final int LABEL=27;
    public static final int ENDWHILE_T=92;
    public static final int STRINGLITERAL=78;
    public static final int T__171=171;
    public static final int T__170=170;
    public static final int BLOCK=12;
    public static final int RIGHT_PARETHESIS=47;
    public static final int ASSIGN=22;
    public static final int EXC_NOT_T=133;
    public static final int BREAK_T=63;
    public static final int CASE_T=88;
    public static final int CONTINUE_T=64;
    public static final int EXTENDS_T=51;
    public static final int DOT_EQ=102;
    public static final int T__169=169;
    public static final int ClassDeclaration=5;
    public static final int FLOATLITERAL=147;
    public static final int ENDSWITCH_T=87;

    // delegates
    // delegators


        public TreePHP(TreeNodeStream input) {
            this(input, new RecognizerSharedState());
        }
        public TreePHP(TreeNodeStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        
    protected TreeAdaptor adaptor = new CommonTreeAdaptor();

    public void setTreeAdaptor(TreeAdaptor adaptor) {
        this.adaptor = adaptor;
    }
    public TreeAdaptor getTreeAdaptor() {
        return adaptor;
    }

    public String[] getTokenNames() { return TreePHP.tokenNames; }
    public String getGrammarFileName() { return "/home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g"; }


      ModuleDeclaration program;
      
      AbstractASTParser parser;
      
      boolean inExprList = false;
      
      boolean inClassStatementList = false;
      
      boolean inVarList = false;
        
      public TreePHP(TreeNodeStream input, AbstractASTParser parser) {
         this(input, new RecognizerSharedState());
         this.parser = parser;
      }
       
      public ModuleDeclaration getModuleDeclaration() {
        return program;
      }
      
      class ModifierDocPair {
        public int modifier;
        public PHPDocBlock doc;
        
        public ModifierDocPair(int modifier, PHPDocBlock doc) {
          this.modifier = modifier;
          this.doc = doc;
        }
      }
      
      public Expression createDispatch(Expression dispatcher, Expression property) {

        if (property.getKind() == ASTNodeKinds.REFLECTION_CALL_EXPRESSION) {
          ((ReflectionCallExpression) property).setReceiver (dispatcher);
          dispatcher = property;
        } else if (property.getKind() == ASTNodeKinds.METHOD_INVOCATION) {
          PHPCallExpression callExpression = (PHPCallExpression) property;
          dispatcher = new PHPCallExpression(dispatcher.sourceStart(), callExpression.sourceEnd(), dispatcher, callExpression.getCallName(), callExpression.getArgs());
        } else {
          dispatcher =  new FieldAccess(dispatcher.sourceStart(), property.sourceEnd(), dispatcher, property);
        }

        return dispatcher;
      }
      
        private List errors = new LinkedList();
        public void displayRecognitionError(String[] tokenNames,
                                            RecognitionException e) {
            String hdr = getErrorHeader(e);
            String msg = getErrorMessage(e, tokenNames);
            errors.add(hdr + " " + msg);
        }
        public List<String> getErrors() {
            return errors;
        }


    public static class php_source_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "php_source"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:84:1: php_source : ^( ModuleDeclaration ( top_statement_list )? ) ;
    public final TreePHP.php_source_return php_source() throws RecognitionException {
        TreePHP.php_source_return retval = new TreePHP.php_source_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST ModuleDeclaration1=null;
        TreePHP.top_statement_list_return top_statement_list2 = null;


        SLAST ModuleDeclaration1_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:85:3: ( ^( ModuleDeclaration ( top_statement_list )? ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:85:6: ^( ModuleDeclaration ( top_statement_list )? )
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_1 = _last;
            SLAST _first_1 = null;
            SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            ModuleDeclaration1=(SLAST)match(input,ModuleDeclaration,FOLLOW_ModuleDeclaration_in_php_source58); 
            ModuleDeclaration1_tree = (SLAST)adaptor.dupNode(ModuleDeclaration1);

            root_1 = (SLAST)adaptor.becomeRoot(ModuleDeclaration1_tree, root_1);



            if ( input.LA(1)==Token.DOWN ) {
                match(input, Token.DOWN, null); 
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:85:26: ( top_statement_list )?
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( (LA1_0==METHOD_DECL||LA1_0==STATEMENT||LA1_0==CLASS_T||LA1_0==INTERFACE_T||LA1_0==164) ) {
                    alt1=1;
                }
                switch (alt1) {
                    case 1 :
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:85:26: top_statement_list
                        {
                        _last = (SLAST)input.LT(1);
                        pushFollow(FOLLOW_top_statement_list_in_php_source60);
                        top_statement_list2=top_statement_list();

                        state._fsp--;

                        adaptor.addChild(root_1, top_statement_list2.getTree());

                        }
                        break;

                }


                match(input, Token.UP, null); 
            }adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


                ModuleDeclaration RESULT = null;
                int startIndex = ModuleDeclaration1.startIndex;
                int endIndex = ModuleDeclaration1.endIndex + 2;
             
                PHPModuleDeclaration program = parser.getModuleDeclaration();
            	  program.setStart(startIndex);
            	  program.setEnd(endIndex);
            	  RESULT = program;
            	  
            	  System.out.println("module: \n" + RESULT);
              

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "php_source"

    public static class top_statement_list_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "top_statement_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:100:1: top_statement_list : ( top_statement )+ ;
    public final TreePHP.top_statement_list_return top_statement_list() throws RecognitionException {
        TreePHP.top_statement_list_return retval = new TreePHP.top_statement_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.top_statement_return top_statement3 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:101:3: ( ( top_statement )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:101:5: ( top_statement )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:101:5: ( top_statement )+
            int cnt2=0;
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( (LA2_0==METHOD_DECL||LA2_0==STATEMENT||LA2_0==CLASS_T||LA2_0==INTERFACE_T||LA2_0==164) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:101:5: top_statement
            	    {
            	    _last = (SLAST)input.LT(1);
            	    pushFollow(FOLLOW_top_statement_in_top_statement_list79);
            	    top_statement3=top_statement();

            	    state._fsp--;

            	    adaptor.addChild(root_0, top_statement3.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt2 >= 1 ) break loop2;
                        EarlyExitException eee =
                            new EarlyExitException(2, input);
                        throw eee;
                }
                cnt2++;
            } while (true);


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "top_statement_list"

    public static class top_statement_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "top_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:104:1: top_statement : ( statement | function_declaration_statement | class_declaration_statement | halt_compiler_statement );
    public final TreePHP.top_statement_return top_statement() throws RecognitionException {
        TreePHP.top_statement_return retval = new TreePHP.top_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.statement_return statement4 = null;

        TreePHP.function_declaration_statement_return function_declaration_statement5 = null;

        TreePHP.class_declaration_statement_return class_declaration_statement6 = null;

        TreePHP.halt_compiler_statement_return halt_compiler_statement7 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:105:3: ( statement | function_declaration_statement | class_declaration_statement | halt_compiler_statement )
            int alt3=4;
            switch ( input.LA(1) ) {
            case STATEMENT:
                {
                alt3=1;
                }
                break;
            case METHOD_DECL:
                {
                alt3=2;
                }
                break;
            case CLASS_T:
            case INTERFACE_T:
                {
                alt3=3;
                }
                break;
            case 164:
                {
                alt3=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 3, 0, input);

                throw nvae;
            }

            switch (alt3) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:105:5: statement
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_statement_in_top_statement93);
                    statement4=statement();

                    state._fsp--;

                    adaptor.addChild(root_0, statement4.getTree());

                        Statement stat = (statement4!=null?statement4.stat:null);
                        parser.addStatement(stat);
                      

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:110:5: function_declaration_statement
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_function_declaration_statement_in_top_statement103);
                    function_declaration_statement5=function_declaration_statement();

                    state._fsp--;

                    adaptor.addChild(root_0, function_declaration_statement5.getTree());

                        parser.addStatement((function_declaration_statement5!=null?function_declaration_statement5.stat:null));
                      

                    }
                    break;
                case 3 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:114:5: class_declaration_statement
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_class_declaration_statement_in_top_statement113);
                    class_declaration_statement6=class_declaration_statement();

                    state._fsp--;

                    adaptor.addChild(root_0, class_declaration_statement6.getTree());

                        ClassDeclaration classDeclaration = (class_declaration_statement6!=null?class_declaration_statement6.classDeclaration:null);
                        parser.addDeclarationStatement(classDeclaration);
                        parser.declarations.push(classDeclaration);
                        parser.addStatement(classDeclaration);
                      

                    }
                    break;
                case 4 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:121:5: halt_compiler_statement
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_halt_compiler_statement_in_top_statement123);
                    halt_compiler_statement7=halt_compiler_statement();

                    state._fsp--;

                    adaptor.addChild(root_0, halt_compiler_statement7.getTree());

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "top_statement"

    protected static class inner_statement_list_scope {
        List list;
    }
    protected Stack inner_statement_list_stack = new Stack();

    public static class inner_statement_list_return extends TreeRuleReturnScope {
        public List innerStatementList;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "inner_statement_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:124:1: inner_statement_list returns [List innerStatementList] : ( inner_statement )+ ;
    public final TreePHP.inner_statement_list_return inner_statement_list() throws RecognitionException {
        inner_statement_list_stack.push(new inner_statement_list_scope());
        TreePHP.inner_statement_list_return retval = new TreePHP.inner_statement_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.inner_statement_return inner_statement8 = null;




          ((inner_statement_list_scope)inner_statement_list_stack.peek()).list = new LinkedList();

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:131:3: ( ( inner_statement )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:131:5: ( inner_statement )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:131:5: ( inner_statement )+
            int cnt4=0;
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( (LA4_0==METHOD_DECL||LA4_0==STATEMENT||LA4_0==CLASS_T||LA4_0==INTERFACE_T||LA4_0==164) ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:131:6: inner_statement
            	    {
            	    _last = (SLAST)input.LT(1);
            	    pushFollow(FOLLOW_inner_statement_in_inner_statement_list150);
            	    inner_statement8=inner_statement();

            	    state._fsp--;

            	    adaptor.addChild(root_0, inner_statement8.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt4 >= 1 ) break loop4;
                        EarlyExitException eee =
                            new EarlyExitException(4, input);
                        throw eee;
                }
                cnt4++;
            } while (true);


                retval.innerStatementList = ((inner_statement_list_scope)inner_statement_list_stack.peek()).list;
              

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
            inner_statement_list_stack.pop();
        }
        return retval;
    }
    // $ANTLR end "inner_statement_list"

    public static class inner_statement_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "inner_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:137:1: inner_statement : ( statement | function_declaration_statement | class_declaration_statement | halt_compiler_statement );
    public final TreePHP.inner_statement_return inner_statement() throws RecognitionException {
        TreePHP.inner_statement_return retval = new TreePHP.inner_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.statement_return statement9 = null;

        TreePHP.function_declaration_statement_return function_declaration_statement10 = null;

        TreePHP.class_declaration_statement_return class_declaration_statement11 = null;

        TreePHP.halt_compiler_statement_return halt_compiler_statement12 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:138:3: ( statement | function_declaration_statement | class_declaration_statement | halt_compiler_statement )
            int alt5=4;
            switch ( input.LA(1) ) {
            case STATEMENT:
                {
                alt5=1;
                }
                break;
            case METHOD_DECL:
                {
                alt5=2;
                }
                break;
            case CLASS_T:
            case INTERFACE_T:
                {
                alt5=3;
                }
                break;
            case 164:
                {
                alt5=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 5, 0, input);

                throw nvae;
            }

            switch (alt5) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:138:5: statement
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_statement_in_inner_statement172);
                    statement9=statement();

                    state._fsp--;

                    adaptor.addChild(root_0, statement9.getTree());

                        if ((statement9!=null?statement9.stat:null) != null) {
                          ((inner_statement_list_scope)inner_statement_list_stack.peek()).list.add((statement9!=null?statement9.stat:null));
                          System.out.println("inner state: " + (statement9!=null?statement9.stat:null));
                        }
                      

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:145:5: function_declaration_statement
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_function_declaration_statement_in_inner_statement182);
                    function_declaration_statement10=function_declaration_statement();

                    state._fsp--;

                    adaptor.addChild(root_0, function_declaration_statement10.getTree());

                        if ((function_declaration_statement10!=null?function_declaration_statement10.stat:null) != null) {
                          ((inner_statement_list_scope)inner_statement_list_stack.peek()).list.add((function_declaration_statement10!=null?function_declaration_statement10.stat:null));
                        }  
                      

                    }
                    break;
                case 3 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:151:5: class_declaration_statement
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_class_declaration_statement_in_inner_statement192);
                    class_declaration_statement11=class_declaration_statement();

                    state._fsp--;

                    adaptor.addChild(root_0, class_declaration_statement11.getTree());

                    }
                    break;
                case 4 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:152:5: halt_compiler_statement
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_halt_compiler_statement_in_inner_statement198);
                    halt_compiler_statement12=halt_compiler_statement();

                    state._fsp--;

                    adaptor.addChild(root_0, halt_compiler_statement12.getTree());

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "inner_statement"

    public static class halt_compiler_statement_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "halt_compiler_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:155:1: halt_compiler_statement : '__halt_compiler' ;
    public final TreePHP.halt_compiler_statement_return halt_compiler_statement() throws RecognitionException {
        TreePHP.halt_compiler_statement_return retval = new TreePHP.halt_compiler_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST string_literal13=null;

        SLAST string_literal13_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:156:3: ( '__halt_compiler' )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:156:5: '__halt_compiler'
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            string_literal13=(SLAST)match(input,164,FOLLOW_164_in_halt_compiler_statement213); 
            string_literal13_tree = (SLAST)adaptor.dupNode(string_literal13);

            adaptor.addChild(root_0, string_literal13_tree);


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "halt_compiler_statement"

    public static class class_declaration_statement_return extends TreeRuleReturnScope {
        public ClassDeclaration classDeclaration;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "class_declaration_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:159:1: class_declaration_statement returns [ClassDeclaration classDeclaration] : ( ^( CLASS_T ( class_entr_type )? IDENTIFIER ( ^( EXTENDS_T fully_qualified_class_name ) )? ( ^( IMPLEMENTS_T fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? ) | ^( INTERFACE_T IDENTIFIER ( ^( EXTENDS_T fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? ) );
    public final TreePHP.class_declaration_statement_return class_declaration_statement() throws RecognitionException {
        TreePHP.class_declaration_statement_return retval = new TreePHP.class_declaration_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST CLASS_T14=null;
        SLAST IDENTIFIER16=null;
        SLAST EXTENDS_T17=null;
        SLAST IMPLEMENTS_T19=null;
        SLAST CLASS_BODY21=null;
        SLAST INTERFACE_T23=null;
        SLAST IDENTIFIER24=null;
        SLAST EXTENDS_T25=null;
        SLAST CLASS_BODY27=null;
        TreePHP.class_entr_type_return class_entr_type15 = null;

        TreePHP.fully_qualified_class_name_return fully_qualified_class_name18 = null;

        TreePHP.fully_qualified_class_name_list_return fully_qualified_class_name_list20 = null;

        TreePHP.class_statement_list_return class_statement_list22 = null;

        TreePHP.fully_qualified_class_name_list_return fully_qualified_class_name_list26 = null;

        TreePHP.class_statement_list_return class_statement_list28 = null;


        SLAST CLASS_T14_tree=null;
        SLAST IDENTIFIER16_tree=null;
        SLAST EXTENDS_T17_tree=null;
        SLAST IMPLEMENTS_T19_tree=null;
        SLAST CLASS_BODY21_tree=null;
        SLAST INTERFACE_T23_tree=null;
        SLAST IDENTIFIER24_tree=null;
        SLAST EXTENDS_T25_tree=null;
        SLAST CLASS_BODY27_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:160:3: ( ^( CLASS_T ( class_entr_type )? IDENTIFIER ( ^( EXTENDS_T fully_qualified_class_name ) )? ( ^( IMPLEMENTS_T fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? ) | ^( INTERFACE_T IDENTIFIER ( ^( EXTENDS_T fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? ) )
            int alt12=2;
            int LA12_0 = input.LA(1);

            if ( (LA12_0==CLASS_T) ) {
                alt12=1;
            }
            else if ( (LA12_0==INTERFACE_T) ) {
                alt12=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 12, 0, input);

                throw nvae;
            }
            switch (alt12) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:160:5: ^( CLASS_T ( class_entr_type )? IDENTIFIER ( ^( EXTENDS_T fully_qualified_class_name ) )? ( ^( IMPLEMENTS_T fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    CLASS_T14=(SLAST)match(input,CLASS_T,FOLLOW_CLASS_T_in_class_declaration_statement233); 
                    CLASS_T14_tree = (SLAST)adaptor.dupNode(CLASS_T14);

                    root_1 = (SLAST)adaptor.becomeRoot(CLASS_T14_tree, root_1);



                    match(input, Token.DOWN, null); 
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:160:15: ( class_entr_type )?
                    int alt6=2;
                    int LA6_0 = input.LA(1);

                    if ( ((LA6_0>=165 && LA6_0<=166)) ) {
                        alt6=1;
                    }
                    switch (alt6) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:160:15: class_entr_type
                            {
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_class_entr_type_in_class_declaration_statement235);
                            class_entr_type15=class_entr_type();

                            state._fsp--;

                            adaptor.addChild(root_1, class_entr_type15.getTree());

                            }
                            break;

                    }

                    _last = (SLAST)input.LT(1);
                    IDENTIFIER16=(SLAST)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_class_declaration_statement238); 
                    IDENTIFIER16_tree = (SLAST)adaptor.dupNode(IDENTIFIER16);

                    adaptor.addChild(root_1, IDENTIFIER16_tree);


                          TreePHP.ModifierDocPair modifier = new ModifierDocPair(Modifiers.AccDefault, null);
                          int startIndex = CLASS_T14.startIndex;
                          int endIndex = CLASS_T14.endIndex + 1;
                          if ((class_entr_type15!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(class_entr_type15.start),
                      input.getTreeAdaptor().getTokenStopIndex(class_entr_type15.start))):null) != null) {
                              if ((class_entr_type15!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(class_entr_type15.start),
                      input.getTreeAdaptor().getTokenStopIndex(class_entr_type15.start))):null).equals("abstract")) {
                                modifier = new ModifierDocPair(Modifiers.AccAbstract, null);
                              }
                          }
                          
                          CommonToken token = (CommonToken)IDENTIFIER16.token;
                          int classNameLeft = token.getStartIndex();
                          int classNameRight = token.getStopIndex() + 1;
                          String className = (IDENTIFIER16!=null?IDENTIFIER16.getText():null);
                          
                          retval.classDeclaration = new ClassDeclaration(startIndex ,endIndex, classNameLeft, classNameRight, modifier.modifier, className, null, null, new Block(classNameRight,classNameRight,null), null);
                          parser.addDeclarationStatement(retval.classDeclaration);
                          parser.declarations.push(retval.classDeclaration);
                      
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:181:4: ( ^( EXTENDS_T fully_qualified_class_name ) )?
                    int alt7=2;
                    int LA7_0 = input.LA(1);

                    if ( (LA7_0==EXTENDS_T) ) {
                        alt7=1;
                    }
                    switch (alt7) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:181:5: ^( EXTENDS_T fully_qualified_class_name )
                            {
                            _last = (SLAST)input.LT(1);
                            {
                            SLAST _save_last_2 = _last;
                            SLAST _first_2 = null;
                            SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                            EXTENDS_T17=(SLAST)match(input,EXTENDS_T,FOLLOW_EXTENDS_T_in_class_declaration_statement252); 
                            EXTENDS_T17_tree = (SLAST)adaptor.dupNode(EXTENDS_T17);

                            root_2 = (SLAST)adaptor.becomeRoot(EXTENDS_T17_tree, root_2);



                            match(input, Token.DOWN, null); 
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_fully_qualified_class_name_in_class_declaration_statement254);
                            fully_qualified_class_name18=fully_qualified_class_name();

                            state._fsp--;

                            adaptor.addChild(root_2, fully_qualified_class_name18.getTree());

                            match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
                            }


                            }
                            break;

                    }

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:181:47: ( ^( IMPLEMENTS_T fully_qualified_class_name_list ) )?
                    int alt8=2;
                    int LA8_0 = input.LA(1);

                    if ( (LA8_0==IMPLEMENTS_T) ) {
                        alt8=1;
                    }
                    switch (alt8) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:181:48: ^( IMPLEMENTS_T fully_qualified_class_name_list )
                            {
                            _last = (SLAST)input.LT(1);
                            {
                            SLAST _save_last_2 = _last;
                            SLAST _first_2 = null;
                            SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                            IMPLEMENTS_T19=(SLAST)match(input,IMPLEMENTS_T,FOLLOW_IMPLEMENTS_T_in_class_declaration_statement261); 
                            IMPLEMENTS_T19_tree = (SLAST)adaptor.dupNode(IMPLEMENTS_T19);

                            root_2 = (SLAST)adaptor.becomeRoot(IMPLEMENTS_T19_tree, root_2);



                            match(input, Token.DOWN, null); 
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_fully_qualified_class_name_list_in_class_declaration_statement263);
                            fully_qualified_class_name_list20=fully_qualified_class_name_list();

                            state._fsp--;

                            adaptor.addChild(root_2, fully_qualified_class_name_list20.getTree());

                            match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
                            }


                            }
                            break;

                    }

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:182:7: ( ^( CLASS_BODY class_statement_list ) )?
                    int alt9=2;
                    int LA9_0 = input.LA(1);

                    if ( (LA9_0==CLASS_BODY) ) {
                        alt9=1;
                    }
                    switch (alt9) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:182:8: ^( CLASS_BODY class_statement_list )
                            {
                            _last = (SLAST)input.LT(1);
                            {
                            SLAST _save_last_2 = _last;
                            SLAST _first_2 = null;
                            SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                            CLASS_BODY21=(SLAST)match(input,CLASS_BODY,FOLLOW_CLASS_BODY_in_class_declaration_statement276); 
                            CLASS_BODY21_tree = (SLAST)adaptor.dupNode(CLASS_BODY21);

                            root_2 = (SLAST)adaptor.becomeRoot(CLASS_BODY21_tree, root_2);



                            match(input, Token.DOWN, null); 
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_class_statement_list_in_class_declaration_statement278);
                            class_statement_list22=class_statement_list();

                            state._fsp--;

                            adaptor.addChild(root_2, class_statement_list22.getTree());

                            match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
                            }


                            }
                            break;

                    }


                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                          
                          TreePHP.ModifierDocPair modifier = new ModifierDocPair(Modifiers.AccDefault, null);
                          int startIndex = CLASS_T14.startIndex;
                          int endIndex = CLASS_T14.endIndex + 1;
                          if ((class_entr_type15!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(class_entr_type15.start),
                      input.getTreeAdaptor().getTokenStopIndex(class_entr_type15.start))):null) != null) {
                              if ((class_entr_type15!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(class_entr_type15.start),
                      input.getTreeAdaptor().getTokenStopIndex(class_entr_type15.start))):null).equals("abstract")) {
                                modifier = new ModifierDocPair(Modifiers.AccAbstract, null);
                              }
                          }
                          
                          CommonToken token = (CommonToken)IDENTIFIER16.token;
                          int classNameLeft = token.getStartIndex();
                          int classNameRight = token.getStopIndex() + 1;
                          String className = (IDENTIFIER16!=null?IDENTIFIER16.getText():null);
                          
                    //      retval.classDeclaration = new ClassDeclaration(startIndex ,endIndex, classNameLeft, classNameRight, modifier.modifier, className, null, null, new Block(classNameRight,classNameRight,null), null);
                    //      parser.addDeclarationStatement(retval.classDeclaration);
                    //      parser.declarations.push(retval.classDeclaration);
                          
                          TypeReference superClass = null;
                          int superClassLeft = 0;
                          int superClassRight = 0;
                          if ((fully_qualified_class_name18!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(fully_qualified_class_name18.start),
                      input.getTreeAdaptor().getTokenStopIndex(fully_qualified_class_name18.start))):null) != null) {
                              superClassLeft = ((CommonToken)(fully_qualified_class_name18!=null?((SLAST)fully_qualified_class_name18.tree):null).token).getStartIndex();
                              superClassRight = ((CommonToken)(fully_qualified_class_name18!=null?((SLAST)fully_qualified_class_name18.tree):null).token).getStopIndex() + 1;
                              superClass = (fully_qualified_class_name18!=null?fully_qualified_class_name18.type:null);
                          }
                          
                          List interfaces = null;
                          int interfacesLeft = 0;
                          int interfacesRight = 0;
                          if ((fully_qualified_class_name_list20!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(fully_qualified_class_name_list20.start),
                      input.getTreeAdaptor().getTokenStopIndex(fully_qualified_class_name_list20.start))):null) != null) {
                              interfacesLeft = ((CommonToken)(fully_qualified_class_name_list20!=null?((SLAST)fully_qualified_class_name_list20.tree):null).token).getStartIndex();
                              interfacesRight = ((CommonToken)(fully_qualified_class_name_list20!=null?((SLAST)fully_qualified_class_name_list20.tree):null).token).getStopIndex() + 1;
                          }
                          
                          retval.classDeclaration = (ClassDeclaration)parser.declarations.peek();
                    		  if (superClass != null) {
                    		    retval.classDeclaration.setSuperClass(superClass);
                    		  }
                    		  if (interfaces != null) {
                    		    retval.classDeclaration.setInterfaceList(interfaces);
                    		  }
                        
                          int blockEndLeft = 0;
                          int blockEndRight = 1;
                        
                          retval.classDeclaration = (ClassDeclaration)parser.declarations.pop();
                          if ((class_statement_list22!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(class_statement_list22.start),
                      input.getTreeAdaptor().getTokenStopIndex(class_statement_list22.start))):null) != null) {
                    		      retval.classDeclaration.getBody().setStart(blockEndLeft);
                    		      retval.classDeclaration.getBody().setEnd(blockEndRight);
                    		  }
                        

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:237:5: ^( INTERFACE_T IDENTIFIER ( ^( EXTENDS_T fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    INTERFACE_T23=(SLAST)match(input,INTERFACE_T,FOLLOW_INTERFACE_T_in_class_declaration_statement295); 
                    INTERFACE_T23_tree = (SLAST)adaptor.dupNode(INTERFACE_T23);

                    root_1 = (SLAST)adaptor.becomeRoot(INTERFACE_T23_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    IDENTIFIER24=(SLAST)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_class_declaration_statement297); 
                    IDENTIFIER24_tree = (SLAST)adaptor.dupNode(IDENTIFIER24);

                    adaptor.addChild(root_1, IDENTIFIER24_tree);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:237:30: ( ^( EXTENDS_T fully_qualified_class_name_list ) )?
                    int alt10=2;
                    int LA10_0 = input.LA(1);

                    if ( (LA10_0==EXTENDS_T) ) {
                        alt10=1;
                    }
                    switch (alt10) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:237:31: ^( EXTENDS_T fully_qualified_class_name_list )
                            {
                            _last = (SLAST)input.LT(1);
                            {
                            SLAST _save_last_2 = _last;
                            SLAST _first_2 = null;
                            SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                            EXTENDS_T25=(SLAST)match(input,EXTENDS_T,FOLLOW_EXTENDS_T_in_class_declaration_statement301); 
                            EXTENDS_T25_tree = (SLAST)adaptor.dupNode(EXTENDS_T25);

                            root_2 = (SLAST)adaptor.becomeRoot(EXTENDS_T25_tree, root_2);



                            match(input, Token.DOWN, null); 
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_fully_qualified_class_name_list_in_class_declaration_statement303);
                            fully_qualified_class_name_list26=fully_qualified_class_name_list();

                            state._fsp--;

                            adaptor.addChild(root_2, fully_qualified_class_name_list26.getTree());

                            match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
                            }


                            }
                            break;

                    }


                          
                        
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:241:7: ( ^( CLASS_BODY class_statement_list ) )?
                    int alt11=2;
                    int LA11_0 = input.LA(1);

                    if ( (LA11_0==CLASS_BODY) ) {
                        alt11=1;
                    }
                    switch (alt11) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:241:8: ^( CLASS_BODY class_statement_list )
                            {
                            _last = (SLAST)input.LT(1);
                            {
                            SLAST _save_last_2 = _last;
                            SLAST _first_2 = null;
                            SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                            CLASS_BODY27=(SLAST)match(input,CLASS_BODY,FOLLOW_CLASS_BODY_in_class_declaration_statement322); 
                            CLASS_BODY27_tree = (SLAST)adaptor.dupNode(CLASS_BODY27);

                            root_2 = (SLAST)adaptor.becomeRoot(CLASS_BODY27_tree, root_2);



                            match(input, Token.DOWN, null); 
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_class_statement_list_in_class_declaration_statement324);
                            class_statement_list28=class_statement_list();

                            state._fsp--;

                            adaptor.addChild(root_2, class_statement_list28.getTree());

                            match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
                            }


                            }
                            break;

                    }


                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                       
                       

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "class_declaration_statement"

    public static class class_entr_type_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "class_entr_type"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:248:1: class_entr_type : ( 'abstract' | 'final' );
    public final TreePHP.class_entr_type_return class_entr_type() throws RecognitionException {
        TreePHP.class_entr_type_return retval = new TreePHP.class_entr_type_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST set29=null;

        SLAST set29_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:249:3: ( 'abstract' | 'final' )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            set29=(SLAST)input.LT(1);
            if ( (input.LA(1)>=165 && input.LA(1)<=166) ) {
                input.consume();

                set29_tree = (SLAST)adaptor.dupNode(set29);

                adaptor.addChild(root_0, set29_tree);

                state.errorRecovery=false;
            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                throw mse;
            }

             

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "class_entr_type"

    public static class class_statement_list_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "class_statement_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:253:1: class_statement_list : ( class_statement )+ ;
    public final TreePHP.class_statement_list_return class_statement_list() throws RecognitionException {
        TreePHP.class_statement_list_return retval = new TreePHP.class_statement_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.class_statement_return class_statement30 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:254:3: ( ( class_statement )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:254:5: ( class_statement )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:254:5: ( class_statement )+
            int cnt13=0;
            loop13:
            do {
                int alt13=2;
                int LA13_0 = input.LA(1);

                if ( ((LA13_0>=FIELD_DECL && LA13_0<=METHOD_DECL)) ) {
                    alt13=1;
                }


                switch (alt13) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:254:5: class_statement
            	    {
            	    _last = (SLAST)input.LT(1);
            	    pushFollow(FOLLOW_class_statement_in_class_statement_list373);
            	    class_statement30=class_statement();

            	    state._fsp--;

            	    adaptor.addChild(root_0, class_statement30.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt13 >= 1 ) break loop13;
                        EarlyExitException eee =
                            new EarlyExitException(13, input);
                        throw eee;
                }
                cnt13++;
            } while (true);


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "class_statement_list"

    protected static class class_statement_scope {
        List constList;
        List varList;
    }
    protected Stack class_statement_stack = new Stack();

    public static class class_statement_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "class_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:257:1: class_statement : ( ^( FIELD_DECL variable_modifiers ( static_var_element )+ ) | ^( METHOD_DECL modifier ( REF_T )? IDENTIFIER ( parameter_list )? ( block | EMPTYSTATEMENT ) ) | ^( FIELD_DECL CONST_T ( directive )+ ) );
    public final TreePHP.class_statement_return class_statement() throws RecognitionException {
        class_statement_stack.push(new class_statement_scope());
        TreePHP.class_statement_return retval = new TreePHP.class_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST FIELD_DECL31=null;
        SLAST METHOD_DECL34=null;
        SLAST REF_T36=null;
        SLAST IDENTIFIER37=null;
        SLAST EMPTYSTATEMENT40=null;
        SLAST FIELD_DECL41=null;
        SLAST CONST_T42=null;
        TreePHP.variable_modifiers_return variable_modifiers32 = null;

        TreePHP.static_var_element_return static_var_element33 = null;

        TreePHP.modifier_return modifier35 = null;

        TreePHP.parameter_list_return parameter_list38 = null;

        TreePHP.block_return block39 = null;

        TreePHP.directive_return directive43 = null;


        SLAST FIELD_DECL31_tree=null;
        SLAST METHOD_DECL34_tree=null;
        SLAST REF_T36_tree=null;
        SLAST IDENTIFIER37_tree=null;
        SLAST EMPTYSTATEMENT40_tree=null;
        SLAST FIELD_DECL41_tree=null;
        SLAST CONST_T42_tree=null;


          ((class_statement_scope)class_statement_stack.peek()).constList = new LinkedList();
          ((class_statement_scope)class_statement_stack.peek()).varList = new LinkedList();

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:266:3: ( ^( FIELD_DECL variable_modifiers ( static_var_element )+ ) | ^( METHOD_DECL modifier ( REF_T )? IDENTIFIER ( parameter_list )? ( block | EMPTYSTATEMENT ) ) | ^( FIELD_DECL CONST_T ( directive )+ ) )
            int alt19=3;
            int LA19_0 = input.LA(1);

            if ( (LA19_0==FIELD_DECL) ) {
                int LA19_1 = input.LA(2);

                if ( (LA19_1==DOWN) ) {
                    int LA19_3 = input.LA(3);

                    if ( (LA19_3==VAR_DECL||LA19_3==STATIC_T||LA19_3==EQUAL_T||(LA19_3>=165 && LA19_3<=170)) ) {
                        alt19=1;
                    }
                    else if ( (LA19_3==CONST_T) ) {
                        alt19=3;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 19, 3, input);

                        throw nvae;
                    }
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 19, 1, input);

                    throw nvae;
                }
            }
            else if ( (LA19_0==METHOD_DECL) ) {
                alt19=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 19, 0, input);

                throw nvae;
            }
            switch (alt19) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:266:5: ^( FIELD_DECL variable_modifiers ( static_var_element )+ )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    FIELD_DECL31=(SLAST)match(input,FIELD_DECL,FOLLOW_FIELD_DECL_in_class_statement398); 
                    FIELD_DECL31_tree = (SLAST)adaptor.dupNode(FIELD_DECL31);

                    root_1 = (SLAST)adaptor.becomeRoot(FIELD_DECL31_tree, root_1);


                    inClassStatementList = true;

                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_variable_modifiers_in_class_statement402);
                    variable_modifiers32=variable_modifiers();

                    state._fsp--;

                    adaptor.addChild(root_1, variable_modifiers32.getTree());
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:266:68: ( static_var_element )+
                    int cnt14=0;
                    loop14:
                    do {
                        int alt14=2;
                        int LA14_0 = input.LA(1);

                        if ( (LA14_0==VAR_DECL||LA14_0==EQUAL_T) ) {
                            alt14=1;
                        }


                        switch (alt14) {
                    	case 1 :
                    	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:266:68: static_var_element
                    	    {
                    	    _last = (SLAST)input.LT(1);
                    	    pushFollow(FOLLOW_static_var_element_in_class_statement404);
                    	    static_var_element33=static_var_element();

                    	    state._fsp--;

                    	    adaptor.addChild(root_1, static_var_element33.getTree());

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt14 >= 1 ) break loop14;
                                EarlyExitException eee =
                                    new EarlyExitException(14, input);
                                throw eee;
                        }
                        cnt14++;
                    } while (true);

                    inClassStatementList = false;

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        ModifierDocPair modifier = new ModifierDocPair(Modifiers.AccDefault, null);
                        int modifierLeft = ((CommonToken)(variable_modifiers32!=null?((SLAST)variable_modifiers32.tree):null).token).getStartIndex();
                        if ((variable_modifiers32!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(variable_modifiers32.start),
                      input.getTreeAdaptor().getTokenStopIndex(variable_modifiers32.start))):null).equals("var")) {
                          modifier = new ModifierDocPair(Modifiers.AccPublic, null);
                        }
                        
                        Iterator iter = ((class_statement_scope)class_statement_stack.peek()).varList.iterator();
                        while (iter.hasNext()) {
                    	    ASTNode[] decl = (ASTNode[])iter.next();
                    	    if (decl != null) {
                    		    VariableReference variable = (VariableReference)decl[0];
                    		    Expression initializer = (Expression)decl[1];
                    		    int start = variable.sourceStart();
                    		    int end = (initializer == null ? variable.sourceEnd() : initializer.sourceEnd());
                    		    parser.addDeclarationStatement(new PHPFieldDeclaration(variable, initializer, start, end, modifier.modifier, modifierLeft, modifier.doc));
                    		  }
                    		}
                      

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:286:5: ^( METHOD_DECL modifier ( REF_T )? IDENTIFIER ( parameter_list )? ( block | EMPTYSTATEMENT ) )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    METHOD_DECL34=(SLAST)match(input,METHOD_DECL,FOLLOW_METHOD_DECL_in_class_statement419); 
                    METHOD_DECL34_tree = (SLAST)adaptor.dupNode(METHOD_DECL34);

                    root_1 = (SLAST)adaptor.becomeRoot(METHOD_DECL34_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_modifier_in_class_statement421);
                    modifier35=modifier();

                    state._fsp--;

                    adaptor.addChild(root_1, modifier35.getTree());
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:286:28: ( REF_T )?
                    int alt15=2;
                    int LA15_0 = input.LA(1);

                    if ( (LA15_0==REF_T) ) {
                        alt15=1;
                    }
                    switch (alt15) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:286:28: REF_T
                            {
                            _last = (SLAST)input.LT(1);
                            REF_T36=(SLAST)match(input,REF_T,FOLLOW_REF_T_in_class_statement423); 
                            REF_T36_tree = (SLAST)adaptor.dupNode(REF_T36);

                            adaptor.addChild(root_1, REF_T36_tree);


                            }
                            break;

                    }

                    _last = (SLAST)input.LT(1);
                    IDENTIFIER37=(SLAST)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_class_statement426); 
                    IDENTIFIER37_tree = (SLAST)adaptor.dupNode(IDENTIFIER37);

                    adaptor.addChild(root_1, IDENTIFIER37_tree);


                          ModifierDocPair modifier = (modifier35!=null?modifier35.modifierVar:null);
                          PHPDocBlock start = null;
                          Boolean isReference = false;
                          if ((REF_T36!=null?REF_T36.getText():null) != null) {
                             isReference = true;
                          }
                          int functionNameLeft = ((CommonToken)IDENTIFIER37.token).getStartIndex();
                          int functionNameRight = ((CommonToken)IDENTIFIER37.token).getStopIndex() + 1;
                          String functionName = (IDENTIFIER37!=null?IDENTIFIER37.getText():null);
                      
                          int startIndex = METHOD_DECL34.startIndex;
                          int endIndex = METHOD_DECL34.endIndex + 1;
                          int modifierValue = modifier == null ? Modifiers.AccPublic : modifier.modifier;
                          
                          PHPDocBlock docBlock = start;
                          if (modifier != null && modifier.doc != null) {
                            docBlock = modifier.doc;
                          }
                          PHPMethodDeclaration methodDeclaration = new PHPMethodDeclaration(startIndex, endIndex, functionNameLeft, functionNameRight, functionName, modifierValue, null, new Block(functionNameLeft, functionNameRight, null), isReference.booleanValue(), docBlock);
                          parser.addDeclarationStatement(methodDeclaration);
                          parser.declarations.push(methodDeclaration);
                        
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:310:7: ( parameter_list )?
                    int alt16=2;
                    int LA16_0 = input.LA(1);

                    if ( (LA16_0==PARAMETER) ) {
                        alt16=1;
                    }
                    switch (alt16) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:310:7: parameter_list
                            {
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_parameter_list_in_class_statement440);
                            parameter_list38=parameter_list();

                            state._fsp--;

                            adaptor.addChild(root_1, parameter_list38.getTree());

                            }
                            break;

                    }


                            if ((parameter_list38!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(parameter_list38.start),
                      input.getTreeAdaptor().getTokenStopIndex(parameter_list38.start))):null) != null) {
                              PHPMethodDeclaration functionDeclaration = (PHPMethodDeclaration)parser.declarations.peek();
                    				  functionDeclaration.acceptArguments((parameter_list38!=null?parameter_list38.parameterList:null));
                            }
                          
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:317:5: ( block | EMPTYSTATEMENT )
                    int alt17=2;
                    int LA17_0 = input.LA(1);

                    if ( (LA17_0==BLOCK) ) {
                        alt17=1;
                    }
                    else if ( (LA17_0==EMPTYSTATEMENT) ) {
                        alt17=2;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 17, 0, input);

                        throw nvae;
                    }
                    switch (alt17) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:317:6: block
                            {
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_block_in_class_statement456);
                            block39=block();

                            state._fsp--;

                            adaptor.addChild(root_1, block39.getTree());

                                    startIndex = ((CommonToken)(block39!=null?((SLAST)block39.tree):null).token).getStartIndex();
                            		    endIndex = ((CommonToken)(block39!=null?((SLAST)block39.tree):null).token).getStopIndex() + 1;
                            		    
                            		    methodDeclaration = (PHPMethodDeclaration)parser.declarations.peek();
                            			  methodDeclaration.getBody().setStart(startIndex);
                            			  methodDeclaration.getBody().setEnd(endIndex);
                            			  methodDeclaration.getBody().getStatements().clear();
                            			  methodDeclaration.getBody().acceptStatements((block39!=null?block39.statList:null));
                            			  
                            			  methodDeclaration = (PHPMethodDeclaration)parser.declarations.pop();
                            //			  if(body instanceof ASTError) {
                            //			    parser.reportError(new ASTError(methodDeclaration.sourceEnd() - 1, methodDeclaration.sourceEnd()), "syntax error, unfinished method declaration");
                            //			  }
                            			  TypeDeclaration type = (TypeDeclaration)parser.declarations.peek();
                            			  methodDeclaration.setDeclaringTypeName(type.getName()); 
                                 

                            }
                            break;
                        case 2 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:336:5: EMPTYSTATEMENT
                            {
                            _last = (SLAST)input.LT(1);
                            EMPTYSTATEMENT40=(SLAST)match(input,EMPTYSTATEMENT,FOLLOW_EMPTYSTATEMENT_in_class_statement475); 
                            EMPTYSTATEMENT40_tree = (SLAST)adaptor.dupNode(EMPTYSTATEMENT40);

                            adaptor.addChild(root_1, EMPTYSTATEMENT40_tree);

                               
                                    startIndex = ((CommonToken)EMPTYSTATEMENT40.token).getStartIndex();
                                    endIndex = ((CommonToken)EMPTYSTATEMENT40.token).getStopIndex() + 1;
                                    
                                    methodDeclaration = (PHPMethodDeclaration)parser.declarations.peek();
                                    methodDeclaration.getBody().setStart(startIndex);
                                    methodDeclaration.getBody().setEnd(endIndex);
                                    methodDeclaration.getBody().getStatements().clear();
                                    methodDeclaration.getBody().acceptStatements(new LinkedList());
                                    
                                    methodDeclaration = (PHPMethodDeclaration)parser.declarations.pop();
                            //        if(body instanceof ASTError) {
                            //          parser.reportError(new ASTError(methodDeclaration.sourceEnd() - 1, methodDeclaration.sourceEnd()), "syntax error, unfinished method declaration");
                            //        }
                                    TypeDeclaration type = (TypeDeclaration)parser.declarations.peek();
                                    methodDeclaration.setDeclaringTypeName(type.getName()); 
                                 

                            }
                            break;

                    }


                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 3 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:355:5: ^( FIELD_DECL CONST_T ( directive )+ )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    FIELD_DECL41=(SLAST)match(input,FIELD_DECL,FOLLOW_FIELD_DECL_in_class_statement498); 
                    FIELD_DECL41_tree = (SLAST)adaptor.dupNode(FIELD_DECL41);

                    root_1 = (SLAST)adaptor.becomeRoot(FIELD_DECL41_tree, root_1);


                    inClassStatementList = true;

                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    CONST_T42=(SLAST)match(input,CONST_T,FOLLOW_CONST_T_in_class_statement502); 
                    CONST_T42_tree = (SLAST)adaptor.dupNode(CONST_T42);

                    adaptor.addChild(root_1, CONST_T42_tree);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:355:57: ( directive )+
                    int cnt18=0;
                    loop18:
                    do {
                        int alt18=2;
                        int LA18_0 = input.LA(1);

                        if ( (LA18_0==EQUAL_T) ) {
                            alt18=1;
                        }


                        switch (alt18) {
                    	case 1 :
                    	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:355:57: directive
                    	    {
                    	    _last = (SLAST)input.LT(1);
                    	    pushFollow(FOLLOW_directive_in_class_statement504);
                    	    directive43=directive();

                    	    state._fsp--;

                    	    adaptor.addChild(root_1, directive43.getTree());

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt18 >= 1 ) break loop18;
                                EarlyExitException eee =
                                    new EarlyExitException(18, input);
                                throw eee;
                        }
                        cnt18++;
                    } while (true);

                    inClassStatementList = false;

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        Iterator iter = ((class_statement_scope)class_statement_stack.peek()).constList.iterator();
                        while (iter.hasNext()) {
                          ASTNode[] decl = (ASTNode[])iter.next();
                    	    if (decl != null) {
                    		    ConstantReference constant = (ConstantReference)decl[0];
                    		    Expression initializer = (Expression)decl[1];
                    		    int decListLeft = ((CommonToken)(directive43!=null?((SLAST)directive43.tree):null).token).getStartIndex();
                    		      
                    		    PHPDocBlock docBlock = null;
                    		    if (decl.length == 3) {
                    		      docBlock = (PHPDocBlock)decl[2];
                    		    }
                    		    int start = constant.sourceStart();
                    		    int end = (initializer == null ? constant.sourceEnd() : initializer.sourceEnd());
                    		    parser.addDeclarationStatement(new ConstantDeclaration(constant, initializer, decListLeft, end, docBlock));
                    		  }
                    		}
                      

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
            class_statement_stack.pop();
        }
        return retval;
    }
    // $ANTLR end "class_statement"

    public static class function_declaration_statement_return extends TreeRuleReturnScope {
        public Statement stat;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "function_declaration_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:377:1: function_declaration_statement returns [Statement stat] : ^( METHOD_DECL ( REF_T )? IDENTIFIER ( parameter_list )? block ) ;
    public final TreePHP.function_declaration_statement_return function_declaration_statement() throws RecognitionException {
        TreePHP.function_declaration_statement_return retval = new TreePHP.function_declaration_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST METHOD_DECL44=null;
        SLAST REF_T45=null;
        SLAST IDENTIFIER46=null;
        TreePHP.parameter_list_return parameter_list47 = null;

        TreePHP.block_return block48 = null;


        SLAST METHOD_DECL44_tree=null;
        SLAST REF_T45_tree=null;
        SLAST IDENTIFIER46_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:378:3: ( ^( METHOD_DECL ( REF_T )? IDENTIFIER ( parameter_list )? block ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:378:5: ^( METHOD_DECL ( REF_T )? IDENTIFIER ( parameter_list )? block )
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_1 = _last;
            SLAST _first_1 = null;
            SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            METHOD_DECL44=(SLAST)match(input,METHOD_DECL,FOLLOW_METHOD_DECL_in_function_declaration_statement530); 
            METHOD_DECL44_tree = (SLAST)adaptor.dupNode(METHOD_DECL44);

            root_1 = (SLAST)adaptor.becomeRoot(METHOD_DECL44_tree, root_1);



            match(input, Token.DOWN, null); 
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:378:19: ( REF_T )?
            int alt20=2;
            int LA20_0 = input.LA(1);

            if ( (LA20_0==REF_T) ) {
                alt20=1;
            }
            switch (alt20) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:378:19: REF_T
                    {
                    _last = (SLAST)input.LT(1);
                    REF_T45=(SLAST)match(input,REF_T,FOLLOW_REF_T_in_function_declaration_statement532); 
                    REF_T45_tree = (SLAST)adaptor.dupNode(REF_T45);

                    adaptor.addChild(root_1, REF_T45_tree);


                    }
                    break;

            }

            _last = (SLAST)input.LT(1);
            IDENTIFIER46=(SLAST)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_function_declaration_statement535); 
            IDENTIFIER46_tree = (SLAST)adaptor.dupNode(IDENTIFIER46);

            adaptor.addChild(root_1, IDENTIFIER46_tree);


                Boolean isReference = false;
                if ((REF_T45!=null?REF_T45.getText():null) != null) {
                   isReference = true;
                }
                int functionNameLeft = ((CommonToken)IDENTIFIER46.token).getStartIndex();
                int functionNameRight = ((CommonToken)IDENTIFIER46.token).getStopIndex() + 1;
                String functionName = (IDENTIFIER46!=null?IDENTIFIER46.getText():null);
              
                int startIndex = METHOD_DECL44.startIndex;
                int endIndex = METHOD_DECL44.endIndex + 1;
                int modifierValue = Modifiers.AccDefault;
                  
                PHPDocBlock docBlock = null;
                
                PHPMethodDeclaration methodDeclaration = new PHPMethodDeclaration(startIndex, endIndex, functionNameLeft, functionNameRight, functionName, modifierValue, null, new Block(functionNameLeft, functionNameRight, null), isReference.booleanValue(), docBlock);
                parser.addDeclarationStatement(methodDeclaration);
                parser.declarations.push(methodDeclaration);
              
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:398:4: ( parameter_list )?
            int alt21=2;
            int LA21_0 = input.LA(1);

            if ( (LA21_0==PARAMETER) ) {
                alt21=1;
            }
            switch (alt21) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:398:4: parameter_list
                    {
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_parameter_list_in_function_declaration_statement544);
                    parameter_list47=parameter_list();

                    state._fsp--;

                    adaptor.addChild(root_1, parameter_list47.getTree());

                    }
                    break;

            }


                  if ((parameter_list47!=null?(input.getTokenStream().toString(
              input.getTreeAdaptor().getTokenStartIndex(parameter_list47.start),
              input.getTreeAdaptor().getTokenStopIndex(parameter_list47.start))):null) != null) {
                    PHPMethodDeclaration functionDeclaration = (PHPMethodDeclaration)parser.declarations.peek();
                    functionDeclaration.acceptArguments((parameter_list47!=null?parameter_list47.parameterList:null));
                  }
               
            _last = (SLAST)input.LT(1);
            pushFollow(FOLLOW_block_in_function_declaration_statement557);
            block48=block();

            state._fsp--;

            adaptor.addChild(root_1, block48.getTree());

                startIndex = ((CommonToken)(block48!=null?((SLAST)block48.tree):null).token).getStartIndex();
                endIndex = ((CommonToken)(block48!=null?((SLAST)block48.tree):null).token).getStopIndex() + 1;
                    
                methodDeclaration = (PHPMethodDeclaration)parser.declarations.peek();
                methodDeclaration.getBody().setStart(startIndex);
                methodDeclaration.getBody().setEnd(endIndex);
                methodDeclaration.getBody().getStatements().clear();
                methodDeclaration.getBody().acceptStatements((block48!=null?block48.statList:null));
                    
                methodDeclaration = (PHPMethodDeclaration)parser.declarations.pop();
            //        if(body instanceof ASTError) {
            //          parser.reportError(new ASTError(methodDeclaration.sourceEnd() - 1, methodDeclaration.sourceEnd()), "syntax error, unfinished method declaration");
            //        }
            //    TypeDeclaration type = (TypeDeclaration)parser.declarations.peek();
            //    methodDeclaration.setDeclaringTypeName(type.getName());
                retval.stat = methodDeclaration;
                System.out.println("here" + retval.stat);
              

            match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "function_declaration_statement"

    public static class block_return extends TreeRuleReturnScope {
        public Statement stat;
        public List statList;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "block"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:430:1: block returns [Statement stat, List statList] : ^( BLOCK ( inner_statement_list )? ) ;
    public final TreePHP.block_return block() throws RecognitionException {
        TreePHP.block_return retval = new TreePHP.block_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST BLOCK49=null;
        TreePHP.inner_statement_list_return inner_statement_list50 = null;


        SLAST BLOCK49_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:431:3: ( ^( BLOCK ( inner_statement_list )? ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:431:5: ^( BLOCK ( inner_statement_list )? )
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_1 = _last;
            SLAST _first_1 = null;
            SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            BLOCK49=(SLAST)match(input,BLOCK,FOLLOW_BLOCK_in_block592); 
            BLOCK49_tree = (SLAST)adaptor.dupNode(BLOCK49);

            root_1 = (SLAST)adaptor.becomeRoot(BLOCK49_tree, root_1);



            if ( input.LA(1)==Token.DOWN ) {
                match(input, Token.DOWN, null); 
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:431:13: ( inner_statement_list )?
                int alt22=2;
                int LA22_0 = input.LA(1);

                if ( (LA22_0==METHOD_DECL||LA22_0==STATEMENT||LA22_0==CLASS_T||LA22_0==INTERFACE_T||LA22_0==164) ) {
                    alt22=1;
                }
                switch (alt22) {
                    case 1 :
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:431:13: inner_statement_list
                        {
                        _last = (SLAST)input.LT(1);
                        pushFollow(FOLLOW_inner_statement_list_in_block594);
                        inner_statement_list50=inner_statement_list();

                        state._fsp--;

                        adaptor.addChild(root_1, inner_statement_list50.getTree());

                        }
                        break;

                }


                match(input, Token.UP, null); 
            }adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


                  int startIndex = -1;
                  int endIndex = -1;
                  Block block = new Block(startIndex, endIndex, new LinkedList());
                  if ((inner_statement_list50!=null?inner_statement_list50.innerStatementList:null) != null) {
                    block.getStatements().clear();
                    block.acceptStatements((inner_statement_list50!=null?inner_statement_list50.innerStatementList:null));
                    retval.statList = (inner_statement_list50!=null?inner_statement_list50.innerStatementList:null);
                  }
                  else {
                    retval.statList = new LinkedList();
                  }
                  retval.stat = block;
                

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "block"

    public static class statement_return extends TreeRuleReturnScope {
        public Statement stat;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:448:1: statement returns [Statement stat] : ^( STATEMENT topStatement ) ;
    public final TreePHP.statement_return statement() throws RecognitionException {
        TreePHP.statement_return retval = new TreePHP.statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST STATEMENT51=null;
        TreePHP.topStatement_return topStatement52 = null;


        SLAST STATEMENT51_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:449:3: ( ^( STATEMENT topStatement ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:449:5: ^( STATEMENT topStatement )
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_1 = _last;
            SLAST _first_1 = null;
            SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            STATEMENT51=(SLAST)match(input,STATEMENT,FOLLOW_STATEMENT_in_statement623); 
            STATEMENT51_tree = (SLAST)adaptor.dupNode(STATEMENT51);

            root_1 = (SLAST)adaptor.becomeRoot(STATEMENT51_tree, root_1);



            match(input, Token.DOWN, null); 
            _last = (SLAST)input.LT(1);
            pushFollow(FOLLOW_topStatement_in_statement625);
            topStatement52=topStatement();

            state._fsp--;

            adaptor.addChild(root_1, topStatement52.getTree());

            match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


                if ((topStatement52!=null?topStatement52.expr:null) != null) {
            	    int startIndex = STATEMENT51.startIndex;
            	    int endIndex = STATEMENT51.endIndex + 1;
            	    retval.stat = new ExpressionStatement(startIndex, endIndex, (topStatement52!=null?topStatement52.expr:null));
            	    System.out.println("retval.stat:" + retval.stat);
                }
                else {
                  retval.stat = (topStatement52!=null?topStatement52.stat:null);
                }
              

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "statement"

    protected static class topStatement_scope {
        List declareKey;
        List declareValue;
    }
    protected Stack topStatement_stack = new Stack();

    public static class topStatement_return extends TreeRuleReturnScope {
        public Expression expr;
        public Statement stat;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "topStatement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:463:1: topStatement returns [Expression expr, Statement stat] : ( block | if_stat | ^( WHILE_T ^( CONDITION e= expression ) while_statement ) | ^( DO_T ^( CONDITION e= expression ) statement ) | ^( FOR_T (e1= expr_list )? ^( CONDITION (e2= expr_list )? ) ^( ITERATE (e3= expr_list )? ) s1= for_statement ) | ^( SWITCH_T ^( CONDITION expression ) switch_case_list ) | ^( BREAK_T ( expression )? ) | ^( CONTINUE_T (e= expression )? ) | ^( RETURN_T (e= expression )? ) | ^( GLOBAL_T variable_list ) | ^( STATIC_T static_var_list ) | ^( ECHO_T expr_list ) | ^( EMPTYSTATEMENT SEMI_COLON ) | expression | ^( FOREACH_T ^( AS_T e= expression v1= foreach_variable (v2= foreach_variable )? ) foreach_statement ) | ^( DECLARE_T directive declare_statement ) | ^( TRY_T ^( BLOCK top_statement ) ( catch_branch )+ ) | ^( THROW_T expression ) | ^( USE_T use_filename ) | ^( INCLUDE_T e= expression ) | ^( INCLUDE_ONCE_T e= expression ) );
    public final TreePHP.topStatement_return topStatement() throws RecognitionException {
        topStatement_stack.push(new topStatement_scope());
        TreePHP.topStatement_return retval = new TreePHP.topStatement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST WHILE_T55=null;
        SLAST CONDITION56=null;
        SLAST DO_T58=null;
        SLAST CONDITION59=null;
        SLAST FOR_T61=null;
        SLAST CONDITION62=null;
        SLAST ITERATE63=null;
        SLAST SWITCH_T64=null;
        SLAST CONDITION65=null;
        SLAST BREAK_T68=null;
        SLAST CONTINUE_T70=null;
        SLAST RETURN_T71=null;
        SLAST GLOBAL_T72=null;
        SLAST STATIC_T74=null;
        SLAST ECHO_T76=null;
        SLAST EMPTYSTATEMENT78=null;
        SLAST SEMI_COLON79=null;
        SLAST FOREACH_T81=null;
        SLAST AS_T82=null;
        SLAST DECLARE_T84=null;
        SLAST TRY_T87=null;
        SLAST BLOCK88=null;
        SLAST THROW_T91=null;
        SLAST USE_T93=null;
        SLAST INCLUDE_T95=null;
        SLAST INCLUDE_ONCE_T96=null;
        TreePHP.expression_return e = null;

        TreePHP.expr_list_return e1 = null;

        TreePHP.expr_list_return e2 = null;

        TreePHP.expr_list_return e3 = null;

        TreePHP.for_statement_return s1 = null;

        TreePHP.foreach_variable_return v1 = null;

        TreePHP.foreach_variable_return v2 = null;

        TreePHP.block_return block53 = null;

        TreePHP.if_stat_return if_stat54 = null;

        TreePHP.while_statement_return while_statement57 = null;

        TreePHP.statement_return statement60 = null;

        TreePHP.expression_return expression66 = null;

        TreePHP.switch_case_list_return switch_case_list67 = null;

        TreePHP.expression_return expression69 = null;

        TreePHP.variable_list_return variable_list73 = null;

        TreePHP.static_var_list_return static_var_list75 = null;

        TreePHP.expr_list_return expr_list77 = null;

        TreePHP.expression_return expression80 = null;

        TreePHP.foreach_statement_return foreach_statement83 = null;

        TreePHP.directive_return directive85 = null;

        TreePHP.declare_statement_return declare_statement86 = null;

        TreePHP.top_statement_return top_statement89 = null;

        TreePHP.catch_branch_return catch_branch90 = null;

        TreePHP.expression_return expression92 = null;

        TreePHP.use_filename_return use_filename94 = null;


        SLAST WHILE_T55_tree=null;
        SLAST CONDITION56_tree=null;
        SLAST DO_T58_tree=null;
        SLAST CONDITION59_tree=null;
        SLAST FOR_T61_tree=null;
        SLAST CONDITION62_tree=null;
        SLAST ITERATE63_tree=null;
        SLAST SWITCH_T64_tree=null;
        SLAST CONDITION65_tree=null;
        SLAST BREAK_T68_tree=null;
        SLAST CONTINUE_T70_tree=null;
        SLAST RETURN_T71_tree=null;
        SLAST GLOBAL_T72_tree=null;
        SLAST STATIC_T74_tree=null;
        SLAST ECHO_T76_tree=null;
        SLAST EMPTYSTATEMENT78_tree=null;
        SLAST SEMI_COLON79_tree=null;
        SLAST FOREACH_T81_tree=null;
        SLAST AS_T82_tree=null;
        SLAST DECLARE_T84_tree=null;
        SLAST TRY_T87_tree=null;
        SLAST BLOCK88_tree=null;
        SLAST THROW_T91_tree=null;
        SLAST USE_T93_tree=null;
        SLAST INCLUDE_T95_tree=null;
        SLAST INCLUDE_ONCE_T96_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:468:3: ( block | if_stat | ^( WHILE_T ^( CONDITION e= expression ) while_statement ) | ^( DO_T ^( CONDITION e= expression ) statement ) | ^( FOR_T (e1= expr_list )? ^( CONDITION (e2= expr_list )? ) ^( ITERATE (e3= expr_list )? ) s1= for_statement ) | ^( SWITCH_T ^( CONDITION expression ) switch_case_list ) | ^( BREAK_T ( expression )? ) | ^( CONTINUE_T (e= expression )? ) | ^( RETURN_T (e= expression )? ) | ^( GLOBAL_T variable_list ) | ^( STATIC_T static_var_list ) | ^( ECHO_T expr_list ) | ^( EMPTYSTATEMENT SEMI_COLON ) | expression | ^( FOREACH_T ^( AS_T e= expression v1= foreach_variable (v2= foreach_variable )? ) foreach_statement ) | ^( DECLARE_T directive declare_statement ) | ^( TRY_T ^( BLOCK top_statement ) ( catch_branch )+ ) | ^( THROW_T expression ) | ^( USE_T use_filename ) | ^( INCLUDE_T e= expression ) | ^( INCLUDE_ONCE_T e= expression ) )
            int alt31=21;
            switch ( input.LA(1) ) {
            case BLOCK:
                {
                alt31=1;
                }
                break;
            case IF_T:
                {
                alt31=2;
                }
                break;
            case WHILE_T:
                {
                alt31=3;
                }
                break;
            case DO_T:
                {
                alt31=4;
                }
                break;
            case FOR_T:
                {
                alt31=5;
                }
                break;
            case SWITCH_T:
                {
                alt31=6;
                }
                break;
            case BREAK_T:
                {
                alt31=7;
                }
                break;
            case CONTINUE_T:
                {
                alt31=8;
                }
                break;
            case RETURN_T:
                {
                alt31=9;
                }
                break;
            case GLOBAL_T:
                {
                alt31=10;
                }
                break;
            case STATIC_T:
                {
                alt31=11;
                }
                break;
            case ECHO_T:
                {
                alt31=12;
                }
                break;
            case EMPTYSTATEMENT:
                {
                alt31=13;
                }
                break;
            case METHOD_DECL:
            case VAR_DECL:
            case CALL:
            case EXPR:
            case SCALAR:
            case ARRAY_DECL:
            case PREFIX_EXPR:
            case POSTFIX_EXPR:
            case CAST_EXPR:
            case REF_T:
            case EQUAL_T:
            case OR_T:
            case XOR_T:
            case AND_T:
            case PLUS_EQ:
            case MINUS_EQ:
            case MUL_EQ:
            case DIV_EQ:
            case DOT_EQ:
            case PERCENT_EQ:
            case BIT_AND_EQ:
            case BIT_OR_EQ:
            case POWER_EQ:
            case LMOVE_EQ:
            case RMOVE_EQ:
            case QUESTION_T:
            case LOGICAL_OR_T:
            case LOGICAL_AND_T:
            case BIT_OR_T:
            case POWER_T:
            case DOT_T:
            case EQUAL_EQUAL_T:
            case NOT_EQUAL_T:
            case EQUAL_EQUAL_EQUAL_T:
            case NOT_EQUAL_EQUAL_T:
            case LT_T:
            case MT_T:
            case LE_T:
            case ME_T:
            case LSHIFT_T:
            case RSHIFT_T:
            case PLUS_T:
            case MINUS_T:
            case MUL_T:
            case DIV_T:
            case PERCENT_T:
            case UNSET_T:
            case CLONE_T:
            case TILDA_T:
            case EXC_NOT_T:
            case INSTANCEOF_T:
            case AT_T:
            case LIST_T:
            case NEW_T:
            case EXIT_T:
            case BACKTRICKLITERAL:
                {
                alt31=14;
                }
                break;
            case FOREACH_T:
                {
                alt31=15;
                }
                break;
            case DECLARE_T:
                {
                alt31=16;
                }
                break;
            case TRY_T:
                {
                alt31=17;
                }
                break;
            case THROW_T:
                {
                alt31=18;
                }
                break;
            case USE_T:
                {
                alt31=19;
                }
                break;
            case INCLUDE_T:
                {
                alt31=20;
                }
                break;
            case INCLUDE_ONCE_T:
                {
                alt31=21;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 31, 0, input);

                throw nvae;
            }

            switch (alt31) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:468:5: block
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_block_in_topStatement651);
                    block53=block();

                    state._fsp--;

                    adaptor.addChild(root_0, block53.getTree());

                        retval.stat = (block53!=null?block53.stat:null);
                      

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:472:5: if_stat
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_if_stat_in_topStatement662);
                    if_stat54=if_stat();

                    state._fsp--;

                    adaptor.addChild(root_0, if_stat54.getTree());

                        retval.stat = (if_stat54!=null?if_stat54.stat:null);
                      

                    }
                    break;
                case 3 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:476:5: ^( WHILE_T ^( CONDITION e= expression ) while_statement )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    WHILE_T55=(SLAST)match(input,WHILE_T,FOLLOW_WHILE_T_in_topStatement673); 
                    WHILE_T55_tree = (SLAST)adaptor.dupNode(WHILE_T55);

                    root_1 = (SLAST)adaptor.becomeRoot(WHILE_T55_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_2 = _last;
                    SLAST _first_2 = null;
                    SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    CONDITION56=(SLAST)match(input,CONDITION,FOLLOW_CONDITION_in_topStatement676); 
                    CONDITION56_tree = (SLAST)adaptor.dupNode(CONDITION56);

                    root_2 = (SLAST)adaptor.becomeRoot(CONDITION56_tree, root_2);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_topStatement680);
                    e=expression();

                    state._fsp--;

                    adaptor.addChild(root_2, e.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
                    }

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_while_statement_in_topStatement683);
                    while_statement57=while_statement();

                    state._fsp--;

                    adaptor.addChild(root_1, while_statement57.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = WHILE_T55.startIndex;
                        int endIndex = WHILE_T55.endIndex + 1;
                        retval.stat = new WhileStatement(startIndex, endIndex, (e!=null?e.expr:null), (while_statement57!=null?while_statement57.block:null));   
                      

                    }
                    break;
                case 4 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:483:5: ^( DO_T ^( CONDITION e= expression ) statement )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    DO_T58=(SLAST)match(input,DO_T,FOLLOW_DO_T_in_topStatement698); 
                    DO_T58_tree = (SLAST)adaptor.dupNode(DO_T58);

                    root_1 = (SLAST)adaptor.becomeRoot(DO_T58_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_2 = _last;
                    SLAST _first_2 = null;
                    SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    CONDITION59=(SLAST)match(input,CONDITION,FOLLOW_CONDITION_in_topStatement701); 
                    CONDITION59_tree = (SLAST)adaptor.dupNode(CONDITION59);

                    root_2 = (SLAST)adaptor.becomeRoot(CONDITION59_tree, root_2);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_topStatement705);
                    e=expression();

                    state._fsp--;

                    adaptor.addChild(root_2, e.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
                    }

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_statement_in_topStatement708);
                    statement60=statement();

                    state._fsp--;

                    adaptor.addChild(root_1, statement60.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = DO_T58.startIndex;
                        int endIndex = DO_T58.endIndex + 1;
                        retval.stat = new DoStatement(startIndex, endIndex, (e!=null?e.expr:null), (statement60!=null?statement60.stat:null));      
                      

                    }
                    break;
                case 5 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:489:5: ^( FOR_T (e1= expr_list )? ^( CONDITION (e2= expr_list )? ) ^( ITERATE (e3= expr_list )? ) s1= for_statement )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    FOR_T61=(SLAST)match(input,FOR_T,FOLLOW_FOR_T_in_topStatement720); 
                    FOR_T61_tree = (SLAST)adaptor.dupNode(FOR_T61);

                    root_1 = (SLAST)adaptor.becomeRoot(FOR_T61_tree, root_1);



                    match(input, Token.DOWN, null); 
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:489:15: (e1= expr_list )?
                    int alt23=2;
                    int LA23_0 = input.LA(1);

                    if ( (LA23_0==METHOD_DECL||LA23_0==VAR_DECL||LA23_0==CALL||LA23_0==EXPR||(LA23_0>=SCALAR && LA23_0<=CAST_EXPR)||LA23_0==REF_T||LA23_0==EQUAL_T||(LA23_0>=OR_T && LA23_0<=EXC_NOT_T)||(LA23_0>=INSTANCEOF_T && LA23_0<=BACKTRICKLITERAL)) ) {
                        alt23=1;
                    }
                    switch (alt23) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:489:15: e1= expr_list
                            {
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_expr_list_in_topStatement724);
                            e1=expr_list();

                            state._fsp--;

                            adaptor.addChild(root_1, e1.getTree());

                            }
                            break;

                    }

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_2 = _last;
                    SLAST _first_2 = null;
                    SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    CONDITION62=(SLAST)match(input,CONDITION,FOLLOW_CONDITION_in_topStatement728); 
                    CONDITION62_tree = (SLAST)adaptor.dupNode(CONDITION62);

                    root_2 = (SLAST)adaptor.becomeRoot(CONDITION62_tree, root_2);



                    if ( input.LA(1)==Token.DOWN ) {
                        match(input, Token.DOWN, null); 
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:489:41: (e2= expr_list )?
                        int alt24=2;
                        int LA24_0 = input.LA(1);

                        if ( (LA24_0==METHOD_DECL||LA24_0==VAR_DECL||LA24_0==CALL||LA24_0==EXPR||(LA24_0>=SCALAR && LA24_0<=CAST_EXPR)||LA24_0==REF_T||LA24_0==EQUAL_T||(LA24_0>=OR_T && LA24_0<=EXC_NOT_T)||(LA24_0>=INSTANCEOF_T && LA24_0<=BACKTRICKLITERAL)) ) {
                            alt24=1;
                        }
                        switch (alt24) {
                            case 1 :
                                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:489:41: e2= expr_list
                                {
                                _last = (SLAST)input.LT(1);
                                pushFollow(FOLLOW_expr_list_in_topStatement732);
                                e2=expr_list();

                                state._fsp--;

                                adaptor.addChild(root_2, e2.getTree());

                                }
                                break;

                        }


                        match(input, Token.UP, null); 
                    }adaptor.addChild(root_1, root_2);_last = _save_last_2;
                    }

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_2 = _last;
                    SLAST _first_2 = null;
                    SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    ITERATE63=(SLAST)match(input,ITERATE,FOLLOW_ITERATE_in_topStatement737); 
                    ITERATE63_tree = (SLAST)adaptor.dupNode(ITERATE63);

                    root_2 = (SLAST)adaptor.becomeRoot(ITERATE63_tree, root_2);



                    if ( input.LA(1)==Token.DOWN ) {
                        match(input, Token.DOWN, null); 
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:489:66: (e3= expr_list )?
                        int alt25=2;
                        int LA25_0 = input.LA(1);

                        if ( (LA25_0==METHOD_DECL||LA25_0==VAR_DECL||LA25_0==CALL||LA25_0==EXPR||(LA25_0>=SCALAR && LA25_0<=CAST_EXPR)||LA25_0==REF_T||LA25_0==EQUAL_T||(LA25_0>=OR_T && LA25_0<=EXC_NOT_T)||(LA25_0>=INSTANCEOF_T && LA25_0<=BACKTRICKLITERAL)) ) {
                            alt25=1;
                        }
                        switch (alt25) {
                            case 1 :
                                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:489:66: e3= expr_list
                                {
                                _last = (SLAST)input.LT(1);
                                pushFollow(FOLLOW_expr_list_in_topStatement741);
                                e3=expr_list();

                                state._fsp--;

                                adaptor.addChild(root_2, e3.getTree());

                                }
                                break;

                        }


                        match(input, Token.UP, null); 
                    }adaptor.addChild(root_1, root_2);_last = _save_last_2;
                    }

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_for_statement_in_topStatement747);
                    s1=for_statement();

                    state._fsp--;

                    adaptor.addChild(root_1, s1.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        List initList = new LinkedList(),
                            condList = new LinkedList(),
                            changeList = new LinkedList();
                        if ((e1!=null?e1.exprList:null) != null) initList = (e1!=null?e1.exprList:null);
                        if ((e2!=null?e2.exprList:null) != null) condList = (e2!=null?e2.exprList:null);
                        if ((e3!=null?e3.exprList:null) != null) changeList = (e3!=null?e3.exprList:null);
                        int startIndex = FOR_T61.startIndex;
                        int endIndex = FOR_T61.endIndex + 1;
                        retval.stat = new ForStatement(startIndex, endIndex, initList, condList, changeList, (s1!=null?s1.block:null));
                      

                    }
                    break;
                case 6 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:501:5: ^( SWITCH_T ^( CONDITION expression ) switch_case_list )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    SWITCH_T64=(SLAST)match(input,SWITCH_T,FOLLOW_SWITCH_T_in_topStatement759); 
                    SWITCH_T64_tree = (SLAST)adaptor.dupNode(SWITCH_T64);

                    root_1 = (SLAST)adaptor.becomeRoot(SWITCH_T64_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_2 = _last;
                    SLAST _first_2 = null;
                    SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    CONDITION65=(SLAST)match(input,CONDITION,FOLLOW_CONDITION_in_topStatement762); 
                    CONDITION65_tree = (SLAST)adaptor.dupNode(CONDITION65);

                    root_2 = (SLAST)adaptor.becomeRoot(CONDITION65_tree, root_2);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_topStatement764);
                    expression66=expression();

                    state._fsp--;

                    adaptor.addChild(root_2, expression66.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
                    }

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_switch_case_list_in_topStatement767);
                    switch_case_list67=switch_case_list();

                    state._fsp--;

                    adaptor.addChild(root_1, switch_case_list67.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 7 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:502:5: ^( BREAK_T ( expression )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    BREAK_T68=(SLAST)match(input,BREAK_T,FOLLOW_BREAK_T_in_topStatement775); 
                    BREAK_T68_tree = (SLAST)adaptor.dupNode(BREAK_T68);

                    root_1 = (SLAST)adaptor.becomeRoot(BREAK_T68_tree, root_1);



                    if ( input.LA(1)==Token.DOWN ) {
                        match(input, Token.DOWN, null); 
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:502:15: ( expression )?
                        int alt26=2;
                        int LA26_0 = input.LA(1);

                        if ( (LA26_0==METHOD_DECL||LA26_0==VAR_DECL||LA26_0==CALL||LA26_0==EXPR||(LA26_0>=SCALAR && LA26_0<=CAST_EXPR)||LA26_0==REF_T||LA26_0==EQUAL_T||(LA26_0>=OR_T && LA26_0<=EXC_NOT_T)||(LA26_0>=INSTANCEOF_T && LA26_0<=BACKTRICKLITERAL)) ) {
                            alt26=1;
                        }
                        switch (alt26) {
                            case 1 :
                                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:502:15: expression
                                {
                                _last = (SLAST)input.LT(1);
                                pushFollow(FOLLOW_expression_in_topStatement777);
                                expression69=expression();

                                state._fsp--;

                                adaptor.addChild(root_1, expression69.getTree());

                                }
                                break;

                        }


                        match(input, Token.UP, null); 
                    }adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = BREAK_T68.startIndex;
                        int endIndex = BREAK_T68.endIndex + 1;
                        retval.stat = new BreakStatement(startIndex, endIndex);
                      

                    }
                    break;
                case 8 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:508:5: ^( CONTINUE_T (e= expression )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    CONTINUE_T70=(SLAST)match(input,CONTINUE_T,FOLLOW_CONTINUE_T_in_topStatement790); 
                    CONTINUE_T70_tree = (SLAST)adaptor.dupNode(CONTINUE_T70);

                    root_1 = (SLAST)adaptor.becomeRoot(CONTINUE_T70_tree, root_1);



                    if ( input.LA(1)==Token.DOWN ) {
                        match(input, Token.DOWN, null); 
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:508:19: (e= expression )?
                        int alt27=2;
                        int LA27_0 = input.LA(1);

                        if ( (LA27_0==METHOD_DECL||LA27_0==VAR_DECL||LA27_0==CALL||LA27_0==EXPR||(LA27_0>=SCALAR && LA27_0<=CAST_EXPR)||LA27_0==REF_T||LA27_0==EQUAL_T||(LA27_0>=OR_T && LA27_0<=EXC_NOT_T)||(LA27_0>=INSTANCEOF_T && LA27_0<=BACKTRICKLITERAL)) ) {
                            alt27=1;
                        }
                        switch (alt27) {
                            case 1 :
                                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:508:19: e= expression
                                {
                                _last = (SLAST)input.LT(1);
                                pushFollow(FOLLOW_expression_in_topStatement794);
                                e=expression();

                                state._fsp--;

                                adaptor.addChild(root_1, e.getTree());

                                }
                                break;

                        }


                        match(input, Token.UP, null); 
                    }adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = CONTINUE_T70.startIndex;
                        int endIndex = CONTINUE_T70.endIndex + 1;
                        retval.stat = new ContinueStatement(startIndex, endIndex);
                        if ((e!=null?e.expr:null) != null) {
                          retval.stat = new ContinueStatement(startIndex, endIndex, (e!=null?e.expr:null));
                        }
                      

                    }
                    break;
                case 9 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:517:5: ^( RETURN_T (e= expression )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    RETURN_T71=(SLAST)match(input,RETURN_T,FOLLOW_RETURN_T_in_topStatement807); 
                    RETURN_T71_tree = (SLAST)adaptor.dupNode(RETURN_T71);

                    root_1 = (SLAST)adaptor.becomeRoot(RETURN_T71_tree, root_1);



                    if ( input.LA(1)==Token.DOWN ) {
                        match(input, Token.DOWN, null); 
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:517:17: (e= expression )?
                        int alt28=2;
                        int LA28_0 = input.LA(1);

                        if ( (LA28_0==METHOD_DECL||LA28_0==VAR_DECL||LA28_0==CALL||LA28_0==EXPR||(LA28_0>=SCALAR && LA28_0<=CAST_EXPR)||LA28_0==REF_T||LA28_0==EQUAL_T||(LA28_0>=OR_T && LA28_0<=EXC_NOT_T)||(LA28_0>=INSTANCEOF_T && LA28_0<=BACKTRICKLITERAL)) ) {
                            alt28=1;
                        }
                        switch (alt28) {
                            case 1 :
                                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:517:17: e= expression
                                {
                                _last = (SLAST)input.LT(1);
                                pushFollow(FOLLOW_expression_in_topStatement811);
                                e=expression();

                                state._fsp--;

                                adaptor.addChild(root_1, e.getTree());

                                }
                                break;

                        }


                        match(input, Token.UP, null); 
                    }adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = RETURN_T71.startIndex;
                        int endIndex = RETURN_T71.endIndex + 1;
                        retval.stat = new ReturnStatement(startIndex, endIndex);
                        if ((e!=null?e.expr:null) != null) {
                          retval.stat = new ReturnStatement(startIndex, endIndex, (e!=null?e.expr:null));
                        }
                      

                    }
                    break;
                case 10 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:526:5: ^( GLOBAL_T variable_list )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    GLOBAL_T72=(SLAST)match(input,GLOBAL_T,FOLLOW_GLOBAL_T_in_topStatement824); 
                    GLOBAL_T72_tree = (SLAST)adaptor.dupNode(GLOBAL_T72);

                    root_1 = (SLAST)adaptor.becomeRoot(GLOBAL_T72_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_variable_list_in_topStatement826);
                    variable_list73=variable_list();

                    state._fsp--;

                    adaptor.addChild(root_1, variable_list73.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = GLOBAL_T72.startIndex;
                        int endIndex = GLOBAL_T72.endIndex + 1;
                        retval.stat = new GlobalStatement(startIndex, endIndex, (variable_list73!=null?variable_list73.variableList:null));
                      

                    }
                    break;
                case 11 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:532:5: ^( STATIC_T static_var_list )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    STATIC_T74=(SLAST)match(input,STATIC_T,FOLLOW_STATIC_T_in_topStatement838); 
                    STATIC_T74_tree = (SLAST)adaptor.dupNode(STATIC_T74);

                    root_1 = (SLAST)adaptor.becomeRoot(STATIC_T74_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_static_var_list_in_topStatement840);
                    static_var_list75=static_var_list();

                    state._fsp--;

                    adaptor.addChild(root_1, static_var_list75.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = STATIC_T74.startIndex;
                        int endIndex = STATIC_T74.endIndex + 1;
                        retval.stat = new StaticStatement(startIndex, endIndex, (static_var_list75!=null?static_var_list75.staticVarList:null));
                      

                    }
                    break;
                case 12 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:538:5: ^( ECHO_T expr_list )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    ECHO_T76=(SLAST)match(input,ECHO_T,FOLLOW_ECHO_T_in_topStatement852); 
                    ECHO_T76_tree = (SLAST)adaptor.dupNode(ECHO_T76);

                    root_1 = (SLAST)adaptor.becomeRoot(ECHO_T76_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expr_list_in_topStatement854);
                    expr_list77=expr_list();

                    state._fsp--;

                    adaptor.addChild(root_1, expr_list77.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = ECHO_T76.startIndex;
                        int endIndex = ECHO_T76.endIndex + 1;
                        retval.stat = new EchoStatement(startIndex, endIndex, (expr_list77!=null?expr_list77.exprList:null)); 
                      

                    }
                    break;
                case 13 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:544:5: ^( EMPTYSTATEMENT SEMI_COLON )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    EMPTYSTATEMENT78=(SLAST)match(input,EMPTYSTATEMENT,FOLLOW_EMPTYSTATEMENT_in_topStatement866); 
                    EMPTYSTATEMENT78_tree = (SLAST)adaptor.dupNode(EMPTYSTATEMENT78);

                    root_1 = (SLAST)adaptor.becomeRoot(EMPTYSTATEMENT78_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    SEMI_COLON79=(SLAST)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_topStatement868); 
                    SEMI_COLON79_tree = (SLAST)adaptor.dupNode(SEMI_COLON79);

                    adaptor.addChild(root_1, SEMI_COLON79_tree);


                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = EMPTYSTATEMENT78.startIndex;
                        int endIndex = EMPTYSTATEMENT78.endIndex + 1;
                        retval.stat = new EmptyStatement(startIndex, endIndex); 
                      

                    }
                    break;
                case 14 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:550:5: expression
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_topStatement879);
                    expression80=expression();

                    state._fsp--;

                    adaptor.addChild(root_0, expression80.getTree());

                         retval.expr = (expression80!=null?expression80.expr:null);
                      

                    }
                    break;
                case 15 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:554:5: ^( FOREACH_T ^( AS_T e= expression v1= foreach_variable (v2= foreach_variable )? ) foreach_statement )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    FOREACH_T81=(SLAST)match(input,FOREACH_T,FOLLOW_FOREACH_T_in_topStatement890); 
                    FOREACH_T81_tree = (SLAST)adaptor.dupNode(FOREACH_T81);

                    root_1 = (SLAST)adaptor.becomeRoot(FOREACH_T81_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_2 = _last;
                    SLAST _first_2 = null;
                    SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    AS_T82=(SLAST)match(input,AS_T,FOLLOW_AS_T_in_topStatement893); 
                    AS_T82_tree = (SLAST)adaptor.dupNode(AS_T82);

                    root_2 = (SLAST)adaptor.becomeRoot(AS_T82_tree, root_2);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_topStatement897);
                    e=expression();

                    state._fsp--;

                    adaptor.addChild(root_2, e.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_foreach_variable_in_topStatement901);
                    v1=foreach_variable();

                    state._fsp--;

                    adaptor.addChild(root_2, v1.getTree());
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:554:59: (v2= foreach_variable )?
                    int alt29=2;
                    int LA29_0 = input.LA(1);

                    if ( (LA29_0==VAR_DECL||LA29_0==CALL||LA29_0==REF_T) ) {
                        alt29=1;
                    }
                    switch (alt29) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:554:59: v2= foreach_variable
                            {
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_foreach_variable_in_topStatement905);
                            v2=foreach_variable();

                            state._fsp--;

                            adaptor.addChild(root_2, v2.getTree());

                            }
                            break;

                    }


                    match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
                    }

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_foreach_statement_in_topStatement909);
                    foreach_statement83=foreach_statement();

                    state._fsp--;

                    adaptor.addChild(root_1, foreach_statement83.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = FOREACH_T81.startIndex;
                        int endIndex = FOREACH_T81.endIndex + 1;
                        
                        if ((v2!=null?v2.expr:null) == null) {
                          retval.stat = new ForEachStatement(startIndex, endIndex, (e!=null?e.expr:null), (v1!=null?v1.expr:null), (foreach_statement83!=null?foreach_statement83.block:null));
                        }
                        else {
                          retval.stat = new ForEachStatement(startIndex, endIndex, (e!=null?e.expr:null), (v1!=null?v1.expr:null), (v2!=null?v2.expr:null), (foreach_statement83!=null?foreach_statement83.block:null));
                        }
                      

                    }
                    break;
                case 16 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:566:5: ^( DECLARE_T directive declare_statement )
                    {
                    root_0 = (SLAST)adaptor.nil();


                    	    ((topStatement_scope)topStatement_stack.peek()).declareKey = new LinkedList();
                    	    ((topStatement_scope)topStatement_stack.peek()).declareValue = new LinkedList();
                        
                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    DECLARE_T84=(SLAST)match(input,DECLARE_T,FOLLOW_DECLARE_T_in_topStatement928); 
                    DECLARE_T84_tree = (SLAST)adaptor.dupNode(DECLARE_T84);

                    root_1 = (SLAST)adaptor.becomeRoot(DECLARE_T84_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_directive_in_topStatement930);
                    directive85=directive();

                    state._fsp--;

                    adaptor.addChild(root_1, directive85.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_declare_statement_in_topStatement932);
                    declare_statement86=declare_statement();

                    state._fsp--;

                    adaptor.addChild(root_1, declare_statement86.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    	    int startIndex = DECLARE_T84.startIndex;
                    	    int endIndex = DECLARE_T84.endIndex + 1;
                    	    DeclareStatement declare = new DeclareStatement(startIndex, endIndex, ((topStatement_scope)topStatement_stack.peek()).declareKey, ((topStatement_scope)topStatement_stack.peek()).declareValue, (declare_statement86!=null?declare_statement86.block:null));
                    	    retval.stat = declare;
                    	  

                    }
                    break;
                case 17 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:577:5: ^( TRY_T ^( BLOCK top_statement ) ( catch_branch )+ )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    TRY_T87=(SLAST)match(input,TRY_T,FOLLOW_TRY_T_in_topStatement945); 
                    TRY_T87_tree = (SLAST)adaptor.dupNode(TRY_T87);

                    root_1 = (SLAST)adaptor.becomeRoot(TRY_T87_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_2 = _last;
                    SLAST _first_2 = null;
                    SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    BLOCK88=(SLAST)match(input,BLOCK,FOLLOW_BLOCK_in_topStatement948); 
                    BLOCK88_tree = (SLAST)adaptor.dupNode(BLOCK88);

                    root_2 = (SLAST)adaptor.becomeRoot(BLOCK88_tree, root_2);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_top_statement_in_topStatement950);
                    top_statement89=top_statement();

                    state._fsp--;

                    adaptor.addChild(root_2, top_statement89.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
                    }

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:577:36: ( catch_branch )+
                    int cnt30=0;
                    loop30:
                    do {
                        int alt30=2;
                        int LA30_0 = input.LA(1);

                        if ( (LA30_0==CATCH_T) ) {
                            alt30=1;
                        }


                        switch (alt30) {
                    	case 1 :
                    	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:577:36: catch_branch
                    	    {
                    	    _last = (SLAST)input.LT(1);
                    	    pushFollow(FOLLOW_catch_branch_in_topStatement953);
                    	    catch_branch90=catch_branch();

                    	    state._fsp--;

                    	    adaptor.addChild(root_1, catch_branch90.getTree());

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt30 >= 1 ) break loop30;
                                EarlyExitException eee =
                                    new EarlyExitException(30, input);
                                throw eee;
                        }
                        cnt30++;
                    } while (true);


                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 18 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:578:5: ^( THROW_T expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    THROW_T91=(SLAST)match(input,THROW_T,FOLLOW_THROW_T_in_topStatement962); 
                    THROW_T91_tree = (SLAST)adaptor.dupNode(THROW_T91);

                    root_1 = (SLAST)adaptor.becomeRoot(THROW_T91_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_topStatement964);
                    expression92=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression92.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 19 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:579:5: ^( USE_T use_filename )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    USE_T93=(SLAST)match(input,USE_T,FOLLOW_USE_T_in_topStatement972); 
                    USE_T93_tree = (SLAST)adaptor.dupNode(USE_T93);

                    root_1 = (SLAST)adaptor.becomeRoot(USE_T93_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_use_filename_in_topStatement974);
                    use_filename94=use_filename();

                    state._fsp--;

                    adaptor.addChild(root_1, use_filename94.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 20 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:580:5: ^( INCLUDE_T e= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    INCLUDE_T95=(SLAST)match(input,INCLUDE_T,FOLLOW_INCLUDE_T_in_topStatement982); 
                    INCLUDE_T95_tree = (SLAST)adaptor.dupNode(INCLUDE_T95);

                    root_1 = (SLAST)adaptor.becomeRoot(INCLUDE_T95_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_topStatement986);
                    e=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = INCLUDE_T95.startIndex;
                        int endIndex = INCLUDE_T95.endIndex + 1;
                        retval.expr = new Include(startIndex, endIndex, (e!=null?e.expr:null), Include.IT_INCLUDE);
                      

                    }
                    break;
                case 21 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:586:5: ^( INCLUDE_ONCE_T e= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    INCLUDE_ONCE_T96=(SLAST)match(input,INCLUDE_ONCE_T,FOLLOW_INCLUDE_ONCE_T_in_topStatement999); 
                    INCLUDE_ONCE_T96_tree = (SLAST)adaptor.dupNode(INCLUDE_ONCE_T96);

                    root_1 = (SLAST)adaptor.becomeRoot(INCLUDE_ONCE_T96_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_topStatement1003);
                    e=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = INCLUDE_ONCE_T96.startIndex;
                        int endIndex = INCLUDE_ONCE_T96.endIndex + 1;
                        retval.expr = new Include(startIndex, endIndex, (e!=null?e.expr:null), Include.IT_INCLUDE_ONCE);
                        System.out.println("include:" + retval.expr);
                      

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
            topStatement_stack.pop();
        }
        return retval;
    }
    // $ANTLR end "topStatement"

    public static class foreach_variable_return extends TreeRuleReturnScope {
        public Expression expr;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "foreach_variable"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:598:1: foreach_variable returns [Expression expr] : ( REF_T )? variable ;
    public final TreePHP.foreach_variable_return foreach_variable() throws RecognitionException {
        TreePHP.foreach_variable_return retval = new TreePHP.foreach_variable_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST REF_T97=null;
        TreePHP.variable_return variable98 = null;


        SLAST REF_T97_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:604:3: ( ( REF_T )? variable )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:604:5: ( REF_T )? variable
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:604:5: ( REF_T )?
            int alt32=2;
            int LA32_0 = input.LA(1);

            if ( (LA32_0==REF_T) ) {
                alt32=1;
            }
            switch (alt32) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:604:5: REF_T
                    {
                    _last = (SLAST)input.LT(1);
                    REF_T97=(SLAST)match(input,REF_T,FOLLOW_REF_T_in_foreach_variable1034); 
                    REF_T97_tree = (SLAST)adaptor.dupNode(REF_T97);

                    adaptor.addChild(root_0, REF_T97_tree);


                    }
                    break;

            }

            _last = (SLAST)input.LT(1);
            pushFollow(FOLLOW_variable_in_foreach_variable1037);
            variable98=variable();

            state._fsp--;

            adaptor.addChild(root_0, variable98.getTree());

                retval.expr = (variable98!=null?variable98.var:null);
              

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "foreach_variable"

    public static class use_filename_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "use_filename"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:610:1: use_filename : STRINGLITERAL ;
    public final TreePHP.use_filename_return use_filename() throws RecognitionException {
        TreePHP.use_filename_return retval = new TreePHP.use_filename_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST STRINGLITERAL99=null;

        SLAST STRINGLITERAL99_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:611:3: ( STRINGLITERAL )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:611:5: STRINGLITERAL
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            STRINGLITERAL99=(SLAST)match(input,STRINGLITERAL,FOLLOW_STRINGLITERAL_in_use_filename1056); 
            STRINGLITERAL99_tree = (SLAST)adaptor.dupNode(STRINGLITERAL99);

            adaptor.addChild(root_0, STRINGLITERAL99_tree);


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "use_filename"

    protected static class variable_list_scope {
        List varList;
    }
    protected Stack variable_list_stack = new Stack();

    public static class variable_list_return extends TreeRuleReturnScope {
        public List variableList;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "variable_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:614:1: variable_list returns [List variableList] : ( variable )+ ;
    public final TreePHP.variable_list_return variable_list() throws RecognitionException {
        variable_list_stack.push(new variable_list_scope());
        TreePHP.variable_list_return retval = new TreePHP.variable_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.variable_return variable100 = null;




          ((variable_list_scope)variable_list_stack.peek()).varList = new LinkedList();
          inVarList = true;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:622:3: ( ( variable )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:622:5: ( variable )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:622:5: ( variable )+
            int cnt33=0;
            loop33:
            do {
                int alt33=2;
                int LA33_0 = input.LA(1);

                if ( (LA33_0==VAR_DECL||LA33_0==CALL) ) {
                    alt33=1;
                }


                switch (alt33) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:622:5: variable
            	    {
            	    _last = (SLAST)input.LT(1);
            	    pushFollow(FOLLOW_variable_in_variable_list1084);
            	    variable100=variable();

            	    state._fsp--;

            	    adaptor.addChild(root_0, variable100.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt33 >= 1 ) break loop33;
                        EarlyExitException eee =
                            new EarlyExitException(33, input);
                        throw eee;
                }
                cnt33++;
            } while (true);


                retval.variableList = ((variable_list_scope)variable_list_stack.peek()).varList;
                inVarList = false;
              

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
            variable_list_stack.pop();
        }
        return retval;
    }
    // $ANTLR end "variable_list"

    public static class fully_qualified_class_name_list_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "fully_qualified_class_name_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:634:1: fully_qualified_class_name_list : ( fully_qualified_class_name )+ ;
    public final TreePHP.fully_qualified_class_name_list_return fully_qualified_class_name_list() throws RecognitionException {
        TreePHP.fully_qualified_class_name_list_return retval = new TreePHP.fully_qualified_class_name_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.fully_qualified_class_name_return fully_qualified_class_name101 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:635:3: ( ( fully_qualified_class_name )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:635:5: ( fully_qualified_class_name )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:635:5: ( fully_qualified_class_name )+
            int cnt34=0;
            loop34:
            do {
                int alt34=2;
                int LA34_0 = input.LA(1);

                if ( (LA34_0==IDENTIFIER||LA34_0==DOMAIN_T) ) {
                    alt34=1;
                }


                switch (alt34) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:635:5: fully_qualified_class_name
            	    {
            	    _last = (SLAST)input.LT(1);
            	    pushFollow(FOLLOW_fully_qualified_class_name_in_fully_qualified_class_name_list1109);
            	    fully_qualified_class_name101=fully_qualified_class_name();

            	    state._fsp--;

            	    adaptor.addChild(root_0, fully_qualified_class_name101.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt34 >= 1 ) break loop34;
                        EarlyExitException eee =
                            new EarlyExitException(34, input);
                        throw eee;
                }
                cnt34++;
            } while (true);


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "fully_qualified_class_name_list"

    public static class fully_qualified_class_name_return extends TreeRuleReturnScope {
        public String name;
        public TypeReference type;
        public StaticConstantAccess constant;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "fully_qualified_class_name"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:638:1: fully_qualified_class_name returns [String name, TypeReference type, StaticConstantAccess constant] : ( ^(d= DOMAIN_T f= fully_qualified_class_name IDENTIFIER ) ( DOMAIN_T )? | IDENTIFIER ( DOMAIN_T )? );
    public final TreePHP.fully_qualified_class_name_return fully_qualified_class_name() throws RecognitionException {
        TreePHP.fully_qualified_class_name_return retval = new TreePHP.fully_qualified_class_name_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST d=null;
        SLAST IDENTIFIER102=null;
        SLAST DOMAIN_T103=null;
        SLAST IDENTIFIER104=null;
        SLAST DOMAIN_T105=null;
        TreePHP.fully_qualified_class_name_return f = null;


        SLAST d_tree=null;
        SLAST IDENTIFIER102_tree=null;
        SLAST DOMAIN_T103_tree=null;
        SLAST IDENTIFIER104_tree=null;
        SLAST DOMAIN_T105_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:639:3: ( ^(d= DOMAIN_T f= fully_qualified_class_name IDENTIFIER ) ( DOMAIN_T )? | IDENTIFIER ( DOMAIN_T )? )
            int alt37=2;
            int LA37_0 = input.LA(1);

            if ( (LA37_0==DOMAIN_T) ) {
                alt37=1;
            }
            else if ( (LA37_0==IDENTIFIER) ) {
                alt37=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 37, 0, input);

                throw nvae;
            }
            switch (alt37) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:639:5: ^(d= DOMAIN_T f= fully_qualified_class_name IDENTIFIER ) ( DOMAIN_T )?
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    d=(SLAST)match(input,DOMAIN_T,FOLLOW_DOMAIN_T_in_fully_qualified_class_name1132); 
                    d_tree = (SLAST)adaptor.dupNode(d);

                    root_1 = (SLAST)adaptor.becomeRoot(d_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_fully_qualified_class_name_in_fully_qualified_class_name1136);
                    f=fully_qualified_class_name();

                    state._fsp--;

                    adaptor.addChild(root_1, f.getTree());
                    _last = (SLAST)input.LT(1);
                    IDENTIFIER102=(SLAST)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_fully_qualified_class_name1138); 
                    IDENTIFIER102_tree = (SLAST)adaptor.dupNode(IDENTIFIER102);

                    adaptor.addChild(root_1, IDENTIFIER102_tree);


                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:639:59: ( DOMAIN_T )?
                    int alt35=2;
                    int LA35_0 = input.LA(1);

                    if ( (LA35_0==DOMAIN_T) ) {
                        int LA35_1 = input.LA(2);

                        if ( (LA35_1==UP||LA35_1==INDEX||LA35_1==ARGU||(LA35_1>=VAR && LA35_1<=HASH_INDEX)||LA35_1==IDENTIFIER||LA35_1==DOMAIN_T) ) {
                            alt35=1;
                        }
                    }
                    switch (alt35) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:639:59: DOMAIN_T
                            {
                            _last = (SLAST)input.LT(1);
                            DOMAIN_T103=(SLAST)match(input,DOMAIN_T,FOLLOW_DOMAIN_T_in_fully_qualified_class_name1141); 
                            DOMAIN_T103_tree = (SLAST)adaptor.dupNode(DOMAIN_T103);

                            adaptor.addChild(root_0, DOMAIN_T103_tree);


                            }
                            break;

                    }


                        int startIndex = d.startIndex;
                        int endIndex = d.endIndex + 1;
                        String className = null;
                        TypeReference type = null;
                        if ((f!=null?f.name:null) != null) {
                          className = (f!=null?f.name:null);
                          int typeLeft = ((CommonToken)(f!=null?((SLAST)f.tree):null).token).getStartIndex();
                          int typeRight = ((CommonToken)(f!=null?((SLAST)f.tree):null).token).getStopIndex() + 1;
                          type = new TypeReference(typeLeft, typeRight, className);
                        }
                        else {
                          type = retval.type;
                        }
                          
                        CommonToken token = (CommonToken)IDENTIFIER102.token;
                        int varLeft = token.getStartIndex();
                        int varRight = token.getStopIndex() + 1;
                        ConstantReference constRef = new ConstantReference(varLeft, varRight, (IDENTIFIER102!=null?IDENTIFIER102.getText():null));
                        retval.constant = new StaticConstantAccess(startIndex, endIndex, type, constRef);
                      

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:661:5: IDENTIFIER ( DOMAIN_T )?
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    IDENTIFIER104=(SLAST)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_fully_qualified_class_name1152); 
                    IDENTIFIER104_tree = (SLAST)adaptor.dupNode(IDENTIFIER104);

                    adaptor.addChild(root_0, IDENTIFIER104_tree);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:661:16: ( DOMAIN_T )?
                    int alt36=2;
                    int LA36_0 = input.LA(1);

                    if ( (LA36_0==DOMAIN_T) ) {
                        int LA36_1 = input.LA(2);

                        if ( (LA36_1==UP||LA36_1==INDEX||LA36_1==ARGU||(LA36_1>=VAR && LA36_1<=HASH_INDEX)||LA36_1==IDENTIFIER||LA36_1==DOMAIN_T) ) {
                            alt36=1;
                        }
                    }
                    switch (alt36) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:661:16: DOMAIN_T
                            {
                            _last = (SLAST)input.LT(1);
                            DOMAIN_T105=(SLAST)match(input,DOMAIN_T,FOLLOW_DOMAIN_T_in_fully_qualified_class_name1154); 
                            DOMAIN_T105_tree = (SLAST)adaptor.dupNode(DOMAIN_T105);

                            adaptor.addChild(root_0, DOMAIN_T105_tree);


                            }
                            break;

                    }


                        retval.name = (IDENTIFIER104!=null?IDENTIFIER104.getText():null);
                        int typeLeft = ((CommonToken)IDENTIFIER104.token).getStartIndex();
                        int typeRight = ((CommonToken)IDENTIFIER104.token).getStopIndex() + 1;
                        if ((DOMAIN_T105!=null?DOMAIN_T105.getText():null) != null) {
                          typeRight = ((CommonToken)DOMAIN_T105.token).getStopIndex() + 1;
                        }
                        retval.type = new TypeReference(typeLeft, typeRight, (IDENTIFIER104!=null?IDENTIFIER104.getText():null));
                      

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "fully_qualified_class_name"

    public static class static_array_pair_list_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "static_array_pair_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:673:1: static_array_pair_list : ( ^( SCALAR_ELEMENT static_scalar_element ) )+ ;
    public final TreePHP.static_array_pair_list_return static_array_pair_list() throws RecognitionException {
        TreePHP.static_array_pair_list_return retval = new TreePHP.static_array_pair_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST SCALAR_ELEMENT106=null;
        TreePHP.static_scalar_element_return static_scalar_element107 = null;


        SLAST SCALAR_ELEMENT106_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:674:3: ( ( ^( SCALAR_ELEMENT static_scalar_element ) )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:674:5: ( ^( SCALAR_ELEMENT static_scalar_element ) )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:674:5: ( ^( SCALAR_ELEMENT static_scalar_element ) )+
            int cnt38=0;
            loop38:
            do {
                int alt38=2;
                int LA38_0 = input.LA(1);

                if ( (LA38_0==SCALAR_ELEMENT) ) {
                    alt38=1;
                }


                switch (alt38) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:674:6: ^( SCALAR_ELEMENT static_scalar_element )
            	    {
            	    _last = (SLAST)input.LT(1);
            	    {
            	    SLAST _save_last_1 = _last;
            	    SLAST _first_1 = null;
            	    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            	    SCALAR_ELEMENT106=(SLAST)match(input,SCALAR_ELEMENT,FOLLOW_SCALAR_ELEMENT_in_static_array_pair_list1176); 
            	    SCALAR_ELEMENT106_tree = (SLAST)adaptor.dupNode(SCALAR_ELEMENT106);

            	    root_1 = (SLAST)adaptor.becomeRoot(SCALAR_ELEMENT106_tree, root_1);



            	    match(input, Token.DOWN, null); 
            	    _last = (SLAST)input.LT(1);
            	    pushFollow(FOLLOW_static_scalar_element_in_static_array_pair_list1178);
            	    static_scalar_element107=static_scalar_element();

            	    state._fsp--;

            	    adaptor.addChild(root_1, static_scalar_element107.getTree());

            	    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt38 >= 1 ) break loop38;
                        EarlyExitException eee =
                            new EarlyExitException(38, input);
                        throw eee;
                }
                cnt38++;
            } while (true);


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "static_array_pair_list"

    public static class static_scalar_element_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "static_scalar_element"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:677:1: static_scalar_element : scalar ( ARROW_T scalar )? ;
    public final TreePHP.static_scalar_element_return static_scalar_element() throws RecognitionException {
        TreePHP.static_scalar_element_return retval = new TreePHP.static_scalar_element_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST ARROW_T109=null;
        TreePHP.scalar_return scalar108 = null;

        TreePHP.scalar_return scalar110 = null;


        SLAST ARROW_T109_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:678:3: ( scalar ( ARROW_T scalar )? )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:678:5: scalar ( ARROW_T scalar )?
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            pushFollow(FOLLOW_scalar_in_static_scalar_element1195);
            scalar108=scalar();

            state._fsp--;

            adaptor.addChild(root_0, scalar108.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:678:12: ( ARROW_T scalar )?
            int alt39=2;
            int LA39_0 = input.LA(1);

            if ( (LA39_0==ARROW_T) ) {
                alt39=1;
            }
            switch (alt39) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:678:13: ARROW_T scalar
                    {
                    _last = (SLAST)input.LT(1);
                    ARROW_T109=(SLAST)match(input,ARROW_T,FOLLOW_ARROW_T_in_static_scalar_element1198); 
                    ARROW_T109_tree = (SLAST)adaptor.dupNode(ARROW_T109);

                    root_0 = (SLAST)adaptor.becomeRoot(ARROW_T109_tree, root_0);

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_scalar_in_static_scalar_element1201);
                    scalar110=scalar();

                    state._fsp--;

                    adaptor.addChild(root_0, scalar110.getTree());

                    }
                    break;

            }


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "static_scalar_element"

    protected static class static_var_list_scope {
        List varList;
    }
    protected Stack static_var_list_stack = new Stack();

    public static class static_var_list_return extends TreeRuleReturnScope {
        public List staticVarList;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "static_var_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:681:1: static_var_list returns [List staticVarList] : ( static_var_element )+ ;
    public final TreePHP.static_var_list_return static_var_list() throws RecognitionException {
        static_var_list_stack.push(new static_var_list_scope());
        TreePHP.static_var_list_return retval = new TreePHP.static_var_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.static_var_element_return static_var_element111 = null;




          ((static_var_list_scope)static_var_list_stack.peek()).varList = new LinkedList();

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:688:3: ( ( static_var_element )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:688:5: ( static_var_element )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:688:5: ( static_var_element )+
            int cnt40=0;
            loop40:
            do {
                int alt40=2;
                int LA40_0 = input.LA(1);

                if ( (LA40_0==VAR_DECL||LA40_0==EQUAL_T) ) {
                    alt40=1;
                }


                switch (alt40) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:688:5: static_var_element
            	    {
            	    _last = (SLAST)input.LT(1);
            	    pushFollow(FOLLOW_static_var_element_in_static_var_list1231);
            	    static_var_element111=static_var_element();

            	    state._fsp--;

            	    adaptor.addChild(root_0, static_var_element111.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt40 >= 1 ) break loop40;
                        EarlyExitException eee =
                            new EarlyExitException(40, input);
                        throw eee;
                }
                cnt40++;
            } while (true);


                retval.staticVarList = ((static_var_list_scope)static_var_list_stack.peek()).varList;
              

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
            static_var_list_stack.pop();
        }
        return retval;
    }
    // $ANTLR end "static_var_list"

    public static class static_var_element_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "static_var_element"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:694:1: static_var_element : ( pure_variable | ^( EQUAL_T pure_variable scalar ) );
    public final TreePHP.static_var_element_return static_var_element() throws RecognitionException {
        TreePHP.static_var_element_return retval = new TreePHP.static_var_element_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST EQUAL_T113=null;
        TreePHP.pure_variable_return pure_variable112 = null;

        TreePHP.pure_variable_return pure_variable114 = null;

        TreePHP.scalar_return scalar115 = null;


        SLAST EQUAL_T113_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:695:3: ( pure_variable | ^( EQUAL_T pure_variable scalar ) )
            int alt41=2;
            int LA41_0 = input.LA(1);

            if ( (LA41_0==VAR_DECL) ) {
                alt41=1;
            }
            else if ( (LA41_0==EQUAL_T) ) {
                alt41=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 41, 0, input);

                throw nvae;
            }
            switch (alt41) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:695:5: pure_variable
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_pure_variable_in_static_var_element1249);
                    pure_variable112=pure_variable();

                    state._fsp--;

                    adaptor.addChild(root_0, pure_variable112.getTree());

                        int varNameLeft = ((CommonToken)(pure_variable112!=null?((SLAST)pure_variable112.tree):null).token).getStartIndex();
                        int varNameRight = ((CommonToken)(pure_variable112!=null?((SLAST)pure_variable112.tree):null).token).getStopIndex() + 1;
                        String varName = (pure_variable112!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(pure_variable112.start),
                      input.getTreeAdaptor().getTokenStopIndex(pure_variable112.start))):null);
                        VariableReference varId = new VariableReference(varNameLeft, varNameRight, varName);
                        
                        if (inClassStatementList) {
                          Object obj = new ASTNode[] {varId, null};
                          ((class_statement_scope)class_statement_stack.peek()).varList.add(obj);
                        }
                        else {
                          ((static_var_list_scope)static_var_list_stack.peek()).varList.add(varId);
                        }
                      

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:710:5: ^( EQUAL_T pure_variable scalar )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    EQUAL_T113=(SLAST)match(input,EQUAL_T,FOLLOW_EQUAL_T_in_static_var_element1260); 
                    EQUAL_T113_tree = (SLAST)adaptor.dupNode(EQUAL_T113);

                    root_1 = (SLAST)adaptor.becomeRoot(EQUAL_T113_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_pure_variable_in_static_var_element1262);
                    pure_variable114=pure_variable();

                    state._fsp--;

                    adaptor.addChild(root_1, pure_variable114.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_scalar_in_static_var_element1264);
                    scalar115=scalar();

                    state._fsp--;

                    adaptor.addChild(root_1, scalar115.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int varNameLeft = ((CommonToken)(pure_variable114!=null?((SLAST)pure_variable114.tree):null).token).getStartIndex();
                        int varNameRight = ((CommonToken)(pure_variable114!=null?((SLAST)pure_variable114.tree):null).token).getStopIndex() + 1;
                        String varName = (pure_variable114!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(pure_variable114.start),
                      input.getTreeAdaptor().getTokenStopIndex(pure_variable114.start))):null);
                        Expression expr = (scalar115!=null?scalar115.expr:null);
                        
                        VariableReference varId = new VariableReference(varNameLeft, varNameRight, varName);

                        if (inClassStatementList) {
                          Object obj = new ASTNode[] {varId, expr};
                          ((class_statement_scope)class_statement_stack.peek()).varList.add(obj);
                        }
                        else {
                          ((static_var_list_scope)static_var_list_stack.peek()).varList.add(varId);
                        }
                      

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "static_var_element"

    protected static class if_stat_scope {
        List conditionList;
        List statementList;
        List tokenList;
    }
    protected Stack if_stat_stack = new Stack();

    public static class if_stat_return extends TreeRuleReturnScope {
        public Statement stat;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "if_stat"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:729:1: if_stat returns [Statement stat] : ^( IF_T ^( CONDITION expression ) ( ( inner_statement_list )? ( else_if_stat )* ( ^( ELSE_T statement ) )? ) ) ;
    public final TreePHP.if_stat_return if_stat() throws RecognitionException {
        if_stat_stack.push(new if_stat_scope());
        TreePHP.if_stat_return retval = new TreePHP.if_stat_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST IF_T116=null;
        SLAST CONDITION117=null;
        SLAST ELSE_T121=null;
        TreePHP.expression_return expression118 = null;

        TreePHP.inner_statement_list_return inner_statement_list119 = null;

        TreePHP.else_if_stat_return else_if_stat120 = null;

        TreePHP.statement_return statement122 = null;


        SLAST IF_T116_tree=null;
        SLAST CONDITION117_tree=null;
        SLAST ELSE_T121_tree=null;


          ((if_stat_scope)if_stat_stack.peek()).conditionList = new LinkedList();
          ((if_stat_scope)if_stat_stack.peek()).statementList = new LinkedList();
          ((if_stat_scope)if_stat_stack.peek()).tokenList = new LinkedList();

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:740:3: ( ^( IF_T ^( CONDITION expression ) ( ( inner_statement_list )? ( else_if_stat )* ( ^( ELSE_T statement ) )? ) ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:740:5: ^( IF_T ^( CONDITION expression ) ( ( inner_statement_list )? ( else_if_stat )* ( ^( ELSE_T statement ) )? ) )
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_1 = _last;
            SLAST _first_1 = null;
            SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            IF_T116=(SLAST)match(input,IF_T,FOLLOW_IF_T_in_if_stat1298); 
            IF_T116_tree = (SLAST)adaptor.dupNode(IF_T116);

            root_1 = (SLAST)adaptor.becomeRoot(IF_T116_tree, root_1);



            match(input, Token.DOWN, null); 
            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_2 = _last;
            SLAST _first_2 = null;
            SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            CONDITION117=(SLAST)match(input,CONDITION,FOLLOW_CONDITION_in_if_stat1301); 
            CONDITION117_tree = (SLAST)adaptor.dupNode(CONDITION117);

            root_2 = (SLAST)adaptor.becomeRoot(CONDITION117_tree, root_2);



            match(input, Token.DOWN, null); 
            _last = (SLAST)input.LT(1);
            pushFollow(FOLLOW_expression_in_if_stat1303);
            expression118=expression();

            state._fsp--;

            adaptor.addChild(root_2, expression118.getTree());

            match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:741:5: ( ( inner_statement_list )? ( else_if_stat )* ( ^( ELSE_T statement ) )? )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:742:7: ( inner_statement_list )? ( else_if_stat )* ( ^( ELSE_T statement ) )?
            {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:742:7: ( inner_statement_list )?
            int alt42=2;
            int LA42_0 = input.LA(1);

            if ( (LA42_0==METHOD_DECL||LA42_0==STATEMENT||LA42_0==CLASS_T||LA42_0==INTERFACE_T||LA42_0==164) ) {
                alt42=1;
            }
            switch (alt42) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:742:7: inner_statement_list
                    {
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_inner_statement_list_in_if_stat1319);
                    inner_statement_list119=inner_statement_list();

                    state._fsp--;

                    adaptor.addChild(root_1, inner_statement_list119.getTree());

                    }
                    break;

            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:743:7: ( else_if_stat )*
            loop43:
            do {
                int alt43=2;
                int LA43_0 = input.LA(1);

                if ( (LA43_0==ELSEIF_T) ) {
                    alt43=1;
                }


                switch (alt43) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:743:7: else_if_stat
            	    {
            	    _last = (SLAST)input.LT(1);
            	    pushFollow(FOLLOW_else_if_stat_in_if_stat1328);
            	    else_if_stat120=else_if_stat();

            	    state._fsp--;

            	    adaptor.addChild(root_1, else_if_stat120.getTree());

            	    }
            	    break;

            	default :
            	    break loop43;
                }
            } while (true);

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:743:21: ( ^( ELSE_T statement ) )?
            int alt44=2;
            int LA44_0 = input.LA(1);

            if ( (LA44_0==ELSE_T) ) {
                alt44=1;
            }
            switch (alt44) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:743:22: ^( ELSE_T statement )
                    {
                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_2 = _last;
                    SLAST _first_2 = null;
                    SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    ELSE_T121=(SLAST)match(input,ELSE_T,FOLLOW_ELSE_T_in_if_stat1333); 
                    ELSE_T121_tree = (SLAST)adaptor.dupNode(ELSE_T121);

                    root_2 = (SLAST)adaptor.becomeRoot(ELSE_T121_tree, root_2);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_statement_in_if_stat1335);
                    statement122=statement();

                    state._fsp--;

                    adaptor.addChild(root_2, statement122.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
                    }


                    }
                    break;

            }


            }


            match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


                  int startIndex = IF_T116.startIndex;
                  int endIndex = IF_T116.endIndex + 1;
                  Expression innerCondition = null; 
                  Statement trueStatement = null;
                  Statement falseStatement = (statement122!=null?statement122.stat:null);
                  Iterator iterCond = ((if_stat_scope)if_stat_stack.peek()).conditionList.iterator(),
                          iterIfTrueStat = ((if_stat_scope)if_stat_stack.peek()).statementList.iterator(),
                          iterTokenList = ((if_stat_scope)if_stat_stack.peek()).tokenList.iterator();
                  while (iterCond.hasNext()) {
                     innerCondition = (Expression)iterCond.next();
                     trueStatement = (Statement)iterIfTrueStat.next();
                     int start = (Integer)iterTokenList.next();
                     falseStatement = new IfStatement(start, 999, innerCondition, trueStatement, falseStatement);
                  }
                  
                  int sid = ((CommonToken)(inner_statement_list119!=null?((SLAST)inner_statement_list119.tree):null).token).getStartIndex();
                  int eid = ((CommonToken)(inner_statement_list119!=null?((SLAST)inner_statement_list119.tree):null).token).getStopIndex() + 1;
                  Block block = new Block(sid, eid, new LinkedList());
                  if ((inner_statement_list119!=null?inner_statement_list119.innerStatementList:null) != null) {
                    block.getStatements().clear();
                    block.acceptStatements((inner_statement_list119!=null?inner_statement_list119.innerStatementList:null));
                  }
                  retval.stat = new IfStatement(startIndex, endIndex, (expression118!=null?expression118.expr:null), block, falseStatement);  
                

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
            if_stat_stack.pop();
        }
        return retval;
    }
    // $ANTLR end "if_stat"

    public static class else_if_stat_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "else_if_stat"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:772:1: else_if_stat : ^( ELSEIF_T ^( CONDITION expression ) ( inner_statement_list )? ) ;
    public final TreePHP.else_if_stat_return else_if_stat() throws RecognitionException {
        TreePHP.else_if_stat_return retval = new TreePHP.else_if_stat_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST ELSEIF_T123=null;
        SLAST CONDITION124=null;
        TreePHP.expression_return expression125 = null;

        TreePHP.inner_statement_list_return inner_statement_list126 = null;


        SLAST ELSEIF_T123_tree=null;
        SLAST CONDITION124_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:773:3: ( ^( ELSEIF_T ^( CONDITION expression ) ( inner_statement_list )? ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:773:5: ^( ELSEIF_T ^( CONDITION expression ) ( inner_statement_list )? )
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_1 = _last;
            SLAST _first_1 = null;
            SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            ELSEIF_T123=(SLAST)match(input,ELSEIF_T,FOLLOW_ELSEIF_T_in_else_if_stat1365); 
            ELSEIF_T123_tree = (SLAST)adaptor.dupNode(ELSEIF_T123);

            root_1 = (SLAST)adaptor.becomeRoot(ELSEIF_T123_tree, root_1);



            match(input, Token.DOWN, null); 
            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_2 = _last;
            SLAST _first_2 = null;
            SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            CONDITION124=(SLAST)match(input,CONDITION,FOLLOW_CONDITION_in_else_if_stat1368); 
            CONDITION124_tree = (SLAST)adaptor.dupNode(CONDITION124);

            root_2 = (SLAST)adaptor.becomeRoot(CONDITION124_tree, root_2);



            match(input, Token.DOWN, null); 
            _last = (SLAST)input.LT(1);
            pushFollow(FOLLOW_expression_in_else_if_stat1370);
            expression125=expression();

            state._fsp--;

            adaptor.addChild(root_2, expression125.getTree());

            match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:773:40: ( inner_statement_list )?
            int alt45=2;
            int LA45_0 = input.LA(1);

            if ( (LA45_0==METHOD_DECL||LA45_0==STATEMENT||LA45_0==CLASS_T||LA45_0==INTERFACE_T||LA45_0==164) ) {
                alt45=1;
            }
            switch (alt45) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:773:40: inner_statement_list
                    {
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_inner_statement_list_in_else_if_stat1373);
                    inner_statement_list126=inner_statement_list();

                    state._fsp--;

                    adaptor.addChild(root_1, inner_statement_list126.getTree());

                    }
                    break;

            }


            match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


                int startIndex = ELSEIF_T123.startIndex;
                ((if_stat_scope)if_stat_stack.peek()).conditionList.add((expression125!=null?expression125.expr:null));
                
                Block block = new Block(999, 999, new LinkedList());
                if ((inner_statement_list126!=null?inner_statement_list126.innerStatementList:null) != null) {
                  block.getStatements().clear();
                  block.acceptStatements((inner_statement_list126!=null?inner_statement_list126.innerStatementList:null));
                }
                ((if_stat_scope)if_stat_stack.peek()).statementList.add(block);
                ((if_stat_scope)if_stat_stack.peek()).tokenList.add(startIndex);
              

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "else_if_stat"

    public static class switch_case_list_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "switch_case_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:789:1: switch_case_list : ( case_list )+ ;
    public final TreePHP.switch_case_list_return switch_case_list() throws RecognitionException {
        TreePHP.switch_case_list_return retval = new TreePHP.switch_case_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.case_list_return case_list127 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:790:3: ( ( case_list )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:790:5: ( case_list )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:790:5: ( case_list )+
            int cnt46=0;
            loop46:
            do {
                int alt46=2;
                int LA46_0 = input.LA(1);

                if ( ((LA46_0>=CASE_T && LA46_0<=DEFAULT_T)) ) {
                    alt46=1;
                }


                switch (alt46) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:790:5: case_list
            	    {
            	    _last = (SLAST)input.LT(1);
            	    pushFollow(FOLLOW_case_list_in_switch_case_list1394);
            	    case_list127=case_list();

            	    state._fsp--;

            	    adaptor.addChild(root_0, case_list127.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt46 >= 1 ) break loop46;
                        EarlyExitException eee =
                            new EarlyExitException(46, input);
                        throw eee;
                }
                cnt46++;
            } while (true);


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "switch_case_list"

    public static class case_list_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "case_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:793:1: case_list : ( ^( CASE_T expression ( inner_statement_list )? ) | ^( DEFAULT_T ( inner_statement_list )? ) );
    public final TreePHP.case_list_return case_list() throws RecognitionException {
        TreePHP.case_list_return retval = new TreePHP.case_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST CASE_T128=null;
        SLAST DEFAULT_T131=null;
        TreePHP.expression_return expression129 = null;

        TreePHP.inner_statement_list_return inner_statement_list130 = null;

        TreePHP.inner_statement_list_return inner_statement_list132 = null;


        SLAST CASE_T128_tree=null;
        SLAST DEFAULT_T131_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:794:3: ( ^( CASE_T expression ( inner_statement_list )? ) | ^( DEFAULT_T ( inner_statement_list )? ) )
            int alt49=2;
            int LA49_0 = input.LA(1);

            if ( (LA49_0==CASE_T) ) {
                alt49=1;
            }
            else if ( (LA49_0==DEFAULT_T) ) {
                alt49=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 49, 0, input);

                throw nvae;
            }
            switch (alt49) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:794:5: ^( CASE_T expression ( inner_statement_list )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    CASE_T128=(SLAST)match(input,CASE_T,FOLLOW_CASE_T_in_case_list1409); 
                    CASE_T128_tree = (SLAST)adaptor.dupNode(CASE_T128);

                    root_1 = (SLAST)adaptor.becomeRoot(CASE_T128_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_case_list1411);
                    expression129=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression129.getTree());
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:794:25: ( inner_statement_list )?
                    int alt47=2;
                    int LA47_0 = input.LA(1);

                    if ( (LA47_0==METHOD_DECL||LA47_0==STATEMENT||LA47_0==CLASS_T||LA47_0==INTERFACE_T||LA47_0==164) ) {
                        alt47=1;
                    }
                    switch (alt47) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:794:25: inner_statement_list
                            {
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_inner_statement_list_in_case_list1413);
                            inner_statement_list130=inner_statement_list();

                            state._fsp--;

                            adaptor.addChild(root_1, inner_statement_list130.getTree());

                            }
                            break;

                    }


                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:795:5: ^( DEFAULT_T ( inner_statement_list )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    DEFAULT_T131=(SLAST)match(input,DEFAULT_T,FOLLOW_DEFAULT_T_in_case_list1422); 
                    DEFAULT_T131_tree = (SLAST)adaptor.dupNode(DEFAULT_T131);

                    root_1 = (SLAST)adaptor.becomeRoot(DEFAULT_T131_tree, root_1);



                    if ( input.LA(1)==Token.DOWN ) {
                        match(input, Token.DOWN, null); 
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:795:17: ( inner_statement_list )?
                        int alt48=2;
                        int LA48_0 = input.LA(1);

                        if ( (LA48_0==METHOD_DECL||LA48_0==STATEMENT||LA48_0==CLASS_T||LA48_0==INTERFACE_T||LA48_0==164) ) {
                            alt48=1;
                        }
                        switch (alt48) {
                            case 1 :
                                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:795:17: inner_statement_list
                                {
                                _last = (SLAST)input.LT(1);
                                pushFollow(FOLLOW_inner_statement_list_in_case_list1424);
                                inner_statement_list132=inner_statement_list();

                                state._fsp--;

                                adaptor.addChild(root_1, inner_statement_list132.getTree());

                                }
                                break;

                        }


                        match(input, Token.UP, null); 
                    }adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "case_list"

    public static class catch_branch_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "catch_branch"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:798:1: catch_branch : ^( CATCH_T IDENTIFIER variable block ) ;
    public final TreePHP.catch_branch_return catch_branch() throws RecognitionException {
        TreePHP.catch_branch_return retval = new TreePHP.catch_branch_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST CATCH_T133=null;
        SLAST IDENTIFIER134=null;
        TreePHP.variable_return variable135 = null;

        TreePHP.block_return block136 = null;


        SLAST CATCH_T133_tree=null;
        SLAST IDENTIFIER134_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:799:3: ( ^( CATCH_T IDENTIFIER variable block ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:799:5: ^( CATCH_T IDENTIFIER variable block )
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_1 = _last;
            SLAST _first_1 = null;
            SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            CATCH_T133=(SLAST)match(input,CATCH_T,FOLLOW_CATCH_T_in_catch_branch1441); 
            CATCH_T133_tree = (SLAST)adaptor.dupNode(CATCH_T133);

            root_1 = (SLAST)adaptor.becomeRoot(CATCH_T133_tree, root_1);



            match(input, Token.DOWN, null); 
            _last = (SLAST)input.LT(1);
            IDENTIFIER134=(SLAST)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_catch_branch1443); 
            IDENTIFIER134_tree = (SLAST)adaptor.dupNode(IDENTIFIER134);

            adaptor.addChild(root_1, IDENTIFIER134_tree);

            _last = (SLAST)input.LT(1);
            pushFollow(FOLLOW_variable_in_catch_branch1445);
            variable135=variable();

            state._fsp--;

            adaptor.addChild(root_1, variable135.getTree());
            _last = (SLAST)input.LT(1);
            pushFollow(FOLLOW_block_in_catch_branch1447);
            block136=block();

            state._fsp--;

            adaptor.addChild(root_1, block136.getTree());

            match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "catch_branch"

    public static class for_statement_return extends TreeRuleReturnScope {
        public Statement block;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "for_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:802:1: for_statement returns [Statement block] : ( inner_statement_list )? ;
    public final TreePHP.for_statement_return for_statement() throws RecognitionException {
        TreePHP.for_statement_return retval = new TreePHP.for_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.inner_statement_list_return inner_statement_list137 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:803:2: ( ( inner_statement_list )? )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:803:4: ( inner_statement_list )?
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:803:4: ( inner_statement_list )?
            int alt50=2;
            int LA50_0 = input.LA(1);

            if ( (LA50_0==METHOD_DECL||LA50_0==STATEMENT||LA50_0==CLASS_T||LA50_0==INTERFACE_T||LA50_0==164) ) {
                alt50=1;
            }
            switch (alt50) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:803:4: inner_statement_list
                    {
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_inner_statement_list_in_for_statement1464);
                    inner_statement_list137=inner_statement_list();

                    state._fsp--;

                    adaptor.addChild(root_0, inner_statement_list137.getTree());

                    }
                    break;

            }


                  int startIndex = -1;
                  int endIndex = -1;
                  Block block = new Block(startIndex, endIndex, new LinkedList());
                  if ((inner_statement_list137!=null?inner_statement_list137.innerStatementList:null) != null) {
                    block.getStatements().clear();
                    block.acceptStatements((inner_statement_list137!=null?inner_statement_list137.innerStatementList:null));
                  }

                  retval.block = block;
                  System.out.println("what block" + block);
                

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "for_statement"

    public static class while_statement_return extends TreeRuleReturnScope {
        public Statement block;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "while_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:818:1: while_statement returns [Statement block] : ( inner_statement_list )? ;
    public final TreePHP.while_statement_return while_statement() throws RecognitionException {
        TreePHP.while_statement_return retval = new TreePHP.while_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.inner_statement_list_return inner_statement_list138 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:819:3: ( ( inner_statement_list )? )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:819:5: ( inner_statement_list )?
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:819:5: ( inner_statement_list )?
            int alt51=2;
            int LA51_0 = input.LA(1);

            if ( (LA51_0==METHOD_DECL||LA51_0==STATEMENT||LA51_0==CLASS_T||LA51_0==INTERFACE_T||LA51_0==164) ) {
                alt51=1;
            }
            switch (alt51) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:819:5: inner_statement_list
                    {
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_inner_statement_list_in_while_statement1487);
                    inner_statement_list138=inner_statement_list();

                    state._fsp--;

                    adaptor.addChild(root_0, inner_statement_list138.getTree());

                    }
                    break;

            }


                  int startIndex = -1;
                  int endIndex = -1;
                  Block block = new Block(startIndex, endIndex, new LinkedList());
                  if ((inner_statement_list138!=null?inner_statement_list138.innerStatementList:null) != null) {
                    block.getStatements().clear();
                    block.acceptStatements((inner_statement_list138!=null?inner_statement_list138.innerStatementList:null));
                  }
                  retval.block = block;
                

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "while_statement"

    public static class foreach_statement_return extends TreeRuleReturnScope {
        public Statement block;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "foreach_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:832:1: foreach_statement returns [Statement block] : ( inner_statement_list )? ;
    public final TreePHP.foreach_statement_return foreach_statement() throws RecognitionException {
        TreePHP.foreach_statement_return retval = new TreePHP.foreach_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.inner_statement_list_return inner_statement_list139 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:833:3: ( ( inner_statement_list )? )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:833:5: ( inner_statement_list )?
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:833:5: ( inner_statement_list )?
            int alt52=2;
            int LA52_0 = input.LA(1);

            if ( (LA52_0==METHOD_DECL||LA52_0==STATEMENT||LA52_0==CLASS_T||LA52_0==INTERFACE_T||LA52_0==164) ) {
                alt52=1;
            }
            switch (alt52) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:833:5: inner_statement_list
                    {
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_inner_statement_list_in_foreach_statement1512);
                    inner_statement_list139=inner_statement_list();

                    state._fsp--;

                    adaptor.addChild(root_0, inner_statement_list139.getTree());

                    }
                    break;

            }


                  int startIndex = -1;
                  int endIndex = -1;
                  Block block = new Block(startIndex, endIndex, new LinkedList());
                  if ((inner_statement_list139!=null?inner_statement_list139.innerStatementList:null) != null) {
                    block.getStatements().clear();
                    block.acceptStatements((inner_statement_list139!=null?inner_statement_list139.innerStatementList:null));
                  }
                  retval.block = block;
                

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "foreach_statement"

    public static class declare_statement_return extends TreeRuleReturnScope {
        public Statement block;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "declare_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:846:1: declare_statement returns [Statement block] : ( inner_statement_list )? ;
    public final TreePHP.declare_statement_return declare_statement() throws RecognitionException {
        TreePHP.declare_statement_return retval = new TreePHP.declare_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.inner_statement_list_return inner_statement_list140 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:847:3: ( ( inner_statement_list )? )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:848:3: ( inner_statement_list )?
            {
            root_0 = (SLAST)adaptor.nil();


                System.out.println("declare ssssssssstat");
              
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:852:3: ( inner_statement_list )?
            int alt53=2;
            int LA53_0 = input.LA(1);

            if ( (LA53_0==METHOD_DECL||LA53_0==STATEMENT||LA53_0==CLASS_T||LA53_0==INTERFACE_T||LA53_0==164) ) {
                alt53=1;
            }
            switch (alt53) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:852:3: inner_statement_list
                    {
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_inner_statement_list_in_declare_statement1548);
                    inner_statement_list140=inner_statement_list();

                    state._fsp--;

                    adaptor.addChild(root_0, inner_statement_list140.getTree());

                    }
                    break;

            }


                  System.out.println("declare stat");
                  int startIndex = -1;
                  int endIndex = -1;
                  Block block = new Block(startIndex, endIndex, new LinkedList());
                  if ((inner_statement_list140!=null?inner_statement_list140.innerStatementList:null) != null) {
            			  block.getStatements().clear();
            			  block.acceptStatements((inner_statement_list140!=null?inner_statement_list140.innerStatementList:null));
            			}
            			retval.block = block;
                

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "declare_statement"

    protected static class parameter_list_scope {
        List paramList;
    }
    protected Stack parameter_list_stack = new Stack();

    public static class parameter_list_return extends TreeRuleReturnScope {
        public List parameterList;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "parameter_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:866:1: parameter_list returns [List parameterList] : ( parameter )+ ;
    public final TreePHP.parameter_list_return parameter_list() throws RecognitionException {
        parameter_list_stack.push(new parameter_list_scope());
        TreePHP.parameter_list_return retval = new TreePHP.parameter_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.parameter_return parameter141 = null;




          ((parameter_list_scope)parameter_list_stack.peek()).paramList = new LinkedList();

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:873:3: ( ( parameter )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:873:5: ( parameter )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:873:5: ( parameter )+
            int cnt54=0;
            loop54:
            do {
                int alt54=2;
                int LA54_0 = input.LA(1);

                if ( (LA54_0==PARAMETER) ) {
                    alt54=1;
                }


                switch (alt54) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:873:5: parameter
            	    {
            	    _last = (SLAST)input.LT(1);
            	    pushFollow(FOLLOW_parameter_in_parameter_list1583);
            	    parameter141=parameter();

            	    state._fsp--;

            	    adaptor.addChild(root_0, parameter141.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt54 >= 1 ) break loop54;
                        EarlyExitException eee =
                            new EarlyExitException(54, input);
                        throw eee;
                }
                cnt54++;
            } while (true);


                retval.parameterList = ((parameter_list_scope)parameter_list_stack.peek()).paramList;
              

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
            parameter_list_stack.pop();
        }
        return retval;
    }
    // $ANTLR end "parameter_list"

    public static class parameter_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "parameter"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:879:1: parameter : ^( PARAMETER ( ^( TYPE parameter_type ) )? ( CONST_T )? pure_variable ( scalar )? ) ;
    public final TreePHP.parameter_return parameter() throws RecognitionException {
        TreePHP.parameter_return retval = new TreePHP.parameter_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST PARAMETER142=null;
        SLAST TYPE143=null;
        SLAST CONST_T145=null;
        TreePHP.parameter_type_return parameter_type144 = null;

        TreePHP.pure_variable_return pure_variable146 = null;

        TreePHP.scalar_return scalar147 = null;


        SLAST PARAMETER142_tree=null;
        SLAST TYPE143_tree=null;
        SLAST CONST_T145_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:880:3: ( ^( PARAMETER ( ^( TYPE parameter_type ) )? ( CONST_T )? pure_variable ( scalar )? ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:880:5: ^( PARAMETER ( ^( TYPE parameter_type ) )? ( CONST_T )? pure_variable ( scalar )? )
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_1 = _last;
            SLAST _first_1 = null;
            SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            PARAMETER142=(SLAST)match(input,PARAMETER,FOLLOW_PARAMETER_in_parameter1604); 
            PARAMETER142_tree = (SLAST)adaptor.dupNode(PARAMETER142);

            root_1 = (SLAST)adaptor.becomeRoot(PARAMETER142_tree, root_1);



            match(input, Token.DOWN, null); 
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:880:17: ( ^( TYPE parameter_type ) )?
            int alt55=2;
            int LA55_0 = input.LA(1);

            if ( (LA55_0==TYPE) ) {
                alt55=1;
            }
            switch (alt55) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:880:18: ^( TYPE parameter_type )
                    {
                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_2 = _last;
                    SLAST _first_2 = null;
                    SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    TYPE143=(SLAST)match(input,TYPE,FOLLOW_TYPE_in_parameter1608); 
                    TYPE143_tree = (SLAST)adaptor.dupNode(TYPE143);

                    root_2 = (SLAST)adaptor.becomeRoot(TYPE143_tree, root_2);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_parameter_type_in_parameter1610);
                    parameter_type144=parameter_type();

                    state._fsp--;

                    adaptor.addChild(root_2, parameter_type144.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
                    }


                    }
                    break;

            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:880:43: ( CONST_T )?
            int alt56=2;
            int LA56_0 = input.LA(1);

            if ( (LA56_0==CONST_T) ) {
                alt56=1;
            }
            switch (alt56) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:880:43: CONST_T
                    {
                    _last = (SLAST)input.LT(1);
                    CONST_T145=(SLAST)match(input,CONST_T,FOLLOW_CONST_T_in_parameter1615); 
                    CONST_T145_tree = (SLAST)adaptor.dupNode(CONST_T145);

                    adaptor.addChild(root_1, CONST_T145_tree);


                    }
                    break;

            }

            _last = (SLAST)input.LT(1);
            pushFollow(FOLLOW_pure_variable_in_parameter1618);
            pure_variable146=pure_variable();

            state._fsp--;

            adaptor.addChild(root_1, pure_variable146.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:880:66: ( scalar )?
            int alt57=2;
            int LA57_0 = input.LA(1);

            if ( (LA57_0==SCALAR) ) {
                alt57=1;
            }
            switch (alt57) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:880:66: scalar
                    {
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_scalar_in_parameter1620);
                    scalar147=scalar();

                    state._fsp--;

                    adaptor.addChild(root_1, scalar147.getTree());

                    }
                    break;

            }


            match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


                FormalParameter RESULT = null;
                TypeReference classType = (parameter_type144!=null?parameter_type144.type:null);
                int varLeft = ((CommonToken)(pure_variable146!=null?((SLAST)pure_variable146.tree):null).token).getStartIndex();
                int varRight = ((CommonToken)(pure_variable146!=null?((SLAST)pure_variable146.tree):null).token).getStopIndex() + 1;
                String varName = (pure_variable146!=null?(input.getTokenStream().toString(
              input.getTreeAdaptor().getTokenStartIndex(pure_variable146.start),
              input.getTreeAdaptor().getTokenStopIndex(pure_variable146.start))):null);
                
                int startIndex = PARAMETER142.startIndex;
                int endIndex = PARAMETER142.endIndex + 1;
                VariableReference var = new VariableReference(varLeft, varRight, varName, PHPVariableKind.LOCAL);
                
                if ((scalar147!=null?scalar147.expr:null) == null) {
                  ((parameter_list_scope)parameter_list_stack.peek()).paramList.add(new FormalParameter(startIndex, endIndex, classType, var));
                }
                else {
                  ((parameter_list_scope)parameter_list_stack.peek()).paramList.add(new FormalParameter(startIndex, endIndex, classType, var, (scalar147!=null?scalar147.expr:null)));
                }
              

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "parameter"

    public static class parameter_type_return extends TreeRuleReturnScope {
        public TypeReference type;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "parameter_type"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:901:1: parameter_type returns [TypeReference type] : ( fully_qualified_class_name | cast_option );
    public final TreePHP.parameter_type_return parameter_type() throws RecognitionException {
        TreePHP.parameter_type_return retval = new TreePHP.parameter_type_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.fully_qualified_class_name_return fully_qualified_class_name148 = null;

        TreePHP.cast_option_return cast_option149 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:902:3: ( fully_qualified_class_name | cast_option )
            int alt58=2;
            int LA58_0 = input.LA(1);

            if ( (LA58_0==IDENTIFIER||LA58_0==DOMAIN_T) ) {
                alt58=1;
            }
            else if ( ((LA58_0>=UNSET_T && LA58_0<=CLONE_T)||(LA58_0>=171 && LA58_0<=179)) ) {
                alt58=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 58, 0, input);

                throw nvae;
            }
            switch (alt58) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:902:5: fully_qualified_class_name
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_fully_qualified_class_name_in_parameter_type1645);
                    fully_qualified_class_name148=fully_qualified_class_name();

                    state._fsp--;

                    adaptor.addChild(root_0, fully_qualified_class_name148.getTree());

                        retval.type = (fully_qualified_class_name148!=null?fully_qualified_class_name148.type:null);
                      

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:906:5: cast_option
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_cast_option_in_parameter_type1655);
                    cast_option149=cast_option();

                    state._fsp--;

                    adaptor.addChild(root_0, cast_option149.getTree());

                        int startIndex = ((CommonToken)(cast_option149!=null?((SLAST)cast_option149.tree):null).token).getStartIndex();
                        int endIndex = ((CommonToken)(cast_option149!=null?((SLAST)cast_option149.tree):null).token).getStopIndex() + 1;
                        retval.type = new TypeReference(startIndex, endIndex, (cast_option149!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(cast_option149.start),
                      input.getTreeAdaptor().getTokenStopIndex(cast_option149.start))):null));
                      

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "parameter_type"

    public static class variable_modifiers_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "variable_modifiers"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:914:1: variable_modifiers : ( 'var' | modifier );
    public final TreePHP.variable_modifiers_return variable_modifiers() throws RecognitionException {
        TreePHP.variable_modifiers_return retval = new TreePHP.variable_modifiers_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST string_literal150=null;
        TreePHP.modifier_return modifier151 = null;


        SLAST string_literal150_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:915:3: ( 'var' | modifier )
            int alt59=2;
            int LA59_0 = input.LA(1);

            if ( (LA59_0==167) ) {
                alt59=1;
            }
            else if ( (LA59_0==VAR_DECL||LA59_0==IDENTIFIER||LA59_0==REF_T||LA59_0==STATIC_T||LA59_0==EQUAL_T||(LA59_0>=165 && LA59_0<=166)||(LA59_0>=168 && LA59_0<=170)) ) {
                alt59=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 59, 0, input);

                throw nvae;
            }
            switch (alt59) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:915:5: 'var'
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    string_literal150=(SLAST)match(input,167,FOLLOW_167_in_variable_modifiers1673); 
                    string_literal150_tree = (SLAST)adaptor.dupNode(string_literal150);

                    adaptor.addChild(root_0, string_literal150_tree);


                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:916:5: modifier
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_modifier_in_variable_modifiers1679);
                    modifier151=modifier();

                    state._fsp--;

                    adaptor.addChild(root_0, modifier151.getTree());

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "variable_modifiers"

    public static class modifier_return extends TreeRuleReturnScope {
        public ModifierDocPair modifierVar;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "modifier"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:919:1: modifier returns [ModifierDocPair modifierVar] : ( 'public' | 'protected' | 'private' | 'static' | 'abstract' | 'final' )* ;
    public final TreePHP.modifier_return modifier() throws RecognitionException {
        TreePHP.modifier_return retval = new TreePHP.modifier_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST string_literal152=null;
        SLAST string_literal153=null;
        SLAST string_literal154=null;
        SLAST string_literal155=null;
        SLAST string_literal156=null;
        SLAST string_literal157=null;

        SLAST string_literal152_tree=null;
        SLAST string_literal153_tree=null;
        SLAST string_literal154_tree=null;
        SLAST string_literal155_tree=null;
        SLAST string_literal156_tree=null;
        SLAST string_literal157_tree=null;


          ModifierDocPair m;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:923:3: ( ( 'public' | 'protected' | 'private' | 'static' | 'abstract' | 'final' )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:923:5: ( 'public' | 'protected' | 'private' | 'static' | 'abstract' | 'final' )*
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:923:5: ( 'public' | 'protected' | 'private' | 'static' | 'abstract' | 'final' )*
            loop60:
            do {
                int alt60=7;
                switch ( input.LA(1) ) {
                case 168:
                    {
                    alt60=1;
                    }
                    break;
                case 169:
                    {
                    alt60=2;
                    }
                    break;
                case 170:
                    {
                    alt60=3;
                    }
                    break;
                case STATIC_T:
                    {
                    alt60=4;
                    }
                    break;
                case 165:
                    {
                    alt60=5;
                    }
                    break;
                case 166:
                    {
                    alt60=6;
                    }
                    break;

                }

                switch (alt60) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:923:6: 'public'
            	    {
            	    _last = (SLAST)input.LT(1);
            	    string_literal152=(SLAST)match(input,168,FOLLOW_168_in_modifier1703); 
            	    string_literal152_tree = (SLAST)adaptor.dupNode(string_literal152);

            	    adaptor.addChild(root_0, string_literal152_tree);

            	    m = new ModifierDocPair(Modifiers.AccPublic, null);

            	    }
            	    break;
            	case 2 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:924:5: 'protected'
            	    {
            	    _last = (SLAST)input.LT(1);
            	    string_literal153=(SLAST)match(input,169,FOLLOW_169_in_modifier1711); 
            	    string_literal153_tree = (SLAST)adaptor.dupNode(string_literal153);

            	    adaptor.addChild(root_0, string_literal153_tree);

            	    m = new ModifierDocPair(Modifiers.AccProtected, null);

            	    }
            	    break;
            	case 3 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:925:5: 'private'
            	    {
            	    _last = (SLAST)input.LT(1);
            	    string_literal154=(SLAST)match(input,170,FOLLOW_170_in_modifier1719); 
            	    string_literal154_tree = (SLAST)adaptor.dupNode(string_literal154);

            	    adaptor.addChild(root_0, string_literal154_tree);

            	    m = new ModifierDocPair(Modifiers.AccPrivate, null);

            	    }
            	    break;
            	case 4 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:926:5: 'static'
            	    {
            	    _last = (SLAST)input.LT(1);
            	    string_literal155=(SLAST)match(input,STATIC_T,FOLLOW_STATIC_T_in_modifier1727); 
            	    string_literal155_tree = (SLAST)adaptor.dupNode(string_literal155);

            	    adaptor.addChild(root_0, string_literal155_tree);

            	    m = new ModifierDocPair(Modifiers.AccStatic, null);

            	    }
            	    break;
            	case 5 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:927:5: 'abstract'
            	    {
            	    _last = (SLAST)input.LT(1);
            	    string_literal156=(SLAST)match(input,165,FOLLOW_165_in_modifier1736); 
            	    string_literal156_tree = (SLAST)adaptor.dupNode(string_literal156);

            	    adaptor.addChild(root_0, string_literal156_tree);

            	    m = new ModifierDocPair(Modifiers.AccAbstract, null);

            	    }
            	    break;
            	case 6 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:928:5: 'final'
            	    {
            	    _last = (SLAST)input.LT(1);
            	    string_literal157=(SLAST)match(input,166,FOLLOW_166_in_modifier1745); 
            	    string_literal157_tree = (SLAST)adaptor.dupNode(string_literal157);

            	    adaptor.addChild(root_0, string_literal157_tree);

            	    m = new ModifierDocPair(Modifiers.AccFinal, null);

            	    }
            	    break;

            	default :
            	    break loop60;
                }
            } while (true);


                retval.modifierVar = m;
                System.out.println("modifier:" + m);
              

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "modifier"

    public static class directive_return extends TreeRuleReturnScope {
        public Object astNode;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "directive"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:936:1: directive returns [Object astNode] : ^( EQUAL_T IDENTIFIER expression ) ;
    public final TreePHP.directive_return directive() throws RecognitionException {
        TreePHP.directive_return retval = new TreePHP.directive_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST EQUAL_T158=null;
        SLAST IDENTIFIER159=null;
        TreePHP.expression_return expression160 = null;


        SLAST EQUAL_T158_tree=null;
        SLAST IDENTIFIER159_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:937:3: ( ^( EQUAL_T IDENTIFIER expression ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:937:5: ^( EQUAL_T IDENTIFIER expression )
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_1 = _last;
            SLAST _first_1 = null;
            SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            EQUAL_T158=(SLAST)match(input,EQUAL_T,FOLLOW_EQUAL_T_in_directive1777); 
            EQUAL_T158_tree = (SLAST)adaptor.dupNode(EQUAL_T158);

            root_1 = (SLAST)adaptor.becomeRoot(EQUAL_T158_tree, root_1);



            match(input, Token.DOWN, null); 
            _last = (SLAST)input.LT(1);
            IDENTIFIER159=(SLAST)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_directive1779); 
            IDENTIFIER159_tree = (SLAST)adaptor.dupNode(IDENTIFIER159);

            adaptor.addChild(root_1, IDENTIFIER159_tree);

            _last = (SLAST)input.LT(1);
            pushFollow(FOLLOW_expression_in_directive1781);
            expression160=expression();

            state._fsp--;

            adaptor.addChild(root_1, expression160.getTree());

            match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


                if (inClassStatementList) {
            	    int constNameleft = ((CommonToken)IDENTIFIER159.token).getStartIndex();
            	    int constNameright = ((CommonToken)IDENTIFIER159.token).getStopIndex() + 1;
            	    String constName = (IDENTIFIER159!=null?IDENTIFIER159.getText():null);
            	    int exprLeft = ((CommonToken)((expression160!=null?((SLAST)expression160.tree):null).token)).getStartIndex();
            	    int exprRight = ((CommonToken)((expression160!=null?((SLAST)expression160.tree):null).token)).getStopIndex() + 1;
            	    Expression expr = (expression160!=null?expression160.expr:null);
            	    
            	    ConstantReference constId = new ConstantReference(constNameleft, constNameright, constName);
            	    Object obj = new ASTNode[]{constId, expr};
            	    ((class_statement_scope)class_statement_stack.peek()).constList.add(obj);
            	  }
            	  else {
            	    System.out.println("id: " + (IDENTIFIER159!=null?IDENTIFIER159.getText():null));
                  ((topStatement_scope)topStatement_stack.peek()).declareKey.add((IDENTIFIER159!=null?IDENTIFIER159.getText():null));
                  ((topStatement_scope)topStatement_stack.peek()).declareValue.add((expression160!=null?expression160.expr:null));
                  System.out.println("OVER");
                }
              

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "directive"

    protected static class expr_list_scope {
        List list;
    }
    protected Stack expr_list_stack = new Stack();

    public static class expr_list_return extends TreeRuleReturnScope {
        public List exprList;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "expr_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:960:1: expr_list returns [List exprList] : ( expression )+ ;
    public final TreePHP.expr_list_return expr_list() throws RecognitionException {
        expr_list_stack.push(new expr_list_scope());
        TreePHP.expr_list_return retval = new TreePHP.expr_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.expression_return expression161 = null;




          ((expr_list_scope)expr_list_stack.peek()).list = new LinkedList();
          inExprList = true;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:971:2: ( ( expression )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:971:4: ( expression )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:971:4: ( expression )+
            int cnt61=0;
            loop61:
            do {
                int alt61=2;
                int LA61_0 = input.LA(1);

                if ( (LA61_0==METHOD_DECL||LA61_0==VAR_DECL||LA61_0==CALL||LA61_0==EXPR||(LA61_0>=SCALAR && LA61_0<=CAST_EXPR)||LA61_0==REF_T||LA61_0==EQUAL_T||(LA61_0>=OR_T && LA61_0<=EXC_NOT_T)||(LA61_0>=INSTANCEOF_T && LA61_0<=BACKTRICKLITERAL)) ) {
                    alt61=1;
                }


                switch (alt61) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:971:4: expression
            	    {
            	    _last = (SLAST)input.LT(1);
            	    pushFollow(FOLLOW_expression_in_expr_list1818);
            	    expression161=expression();

            	    state._fsp--;

            	    adaptor.addChild(root_0, expression161.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt61 >= 1 ) break loop61;
                        EarlyExitException eee =
                            new EarlyExitException(61, input);
                        throw eee;
                }
                cnt61++;
            } while (true);


              retval.exprList = ((expr_list_scope)expr_list_stack.peek()).list;
             

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);


              inExprList = false;

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
            expr_list_stack.pop();
        }
        return retval;
    }
    // $ANTLR end "expr_list"

    public static class expression_return extends TreeRuleReturnScope {
        public Expression expr;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "expression"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:977:1: expression returns [Expression expr] : ( ^( EXPR etop= expression ) | ^( OR_T e1= expression e2= expression ) | ^( XOR_T e1= expression e2= expression ) | ^( AND_T e1= expression e2= expression ) | ^( EQUAL_T e1= expression e2= expression ) | ^( PLUS_EQ e1= expression e2= expression ) | ^( MINUS_EQ e1= expression e2= expression ) | ^( MUL_EQ e1= expression e2= expression ) | ^( DIV_EQ e1= expression e2= expression ) | ^( DOT_EQ e1= expression e2= expression ) | ^( PERCENT_EQ e1= expression e2= expression ) | ^( BIT_AND_EQ e1= expression e2= expression ) | ^( BIT_OR_EQ e1= expression e2= expression ) | ^( POWER_EQ e1= expression e2= expression ) | ^( LMOVE_EQ e1= expression e2= expression ) | ^( RMOVE_EQ e1= expression e2= expression ) | ^( QUESTION_T e1= expression ^( COLON_T e2= expression e3= expression ) ) | ^( LOGICAL_OR_T e1= expression e2= expression ) | ^( LOGICAL_AND_T e1= expression e2= expression ) | ^( BIT_OR_T e1= expression e2= expression ) | ^( POWER_T expression expression ) | ^( REF_T e1= expression (e2= expression )? ) | ^( DOT_T e1= expression e2= expression ) | ^( EQUAL_EQUAL_T e1= expression e2= expression ) | ^( NOT_EQUAL_T e1= expression e2= expression ) | ^( EQUAL_EQUAL_EQUAL_T e1= expression e2= expression ) | ^( NOT_EQUAL_EQUAL_T e1= expression e2= expression ) | ^( LT_T e1= expression e2= expression ) | ^( MT_T e1= expression e2= expression ) | ^( LE_T e1= expression e2= expression ) | ^( ME_T expression expression ) | ^( LSHIFT_T e1= expression e2= expression ) | ^( RSHIFT_T e1= expression e2= expression ) | ^( PLUS_T e1= expression (e2= expression )? ) | ^( MINUS_T e1= expression (e2= expression )? ) | ^( MUL_T e1= expression e2= expression ) | ^( DIV_T e1= expression e2= expression ) | ^( PERCENT_T e1= expression e2= expression ) | ^( CAST_EXPR cast_option e= expression ) | ^( TILDA_T e= expression ) | ^( EXC_NOT_T expression ) | ^( POSTFIX_EXPR e= expression plus_minus ) | ^( PREFIX_EXPR ( plus_minus )+ e= expression ) | ^( INSTANCEOF_T e= expression class_name_reference ) | ( AT_T )? variable | ( AT_T )? scalar | list_decl | ^( ARRAY_DECL ( array_pair_list )? ) | ^( NEW_T class_name_reference ) | ^( CLONE_T variable ) | ^( EXIT_T ( expression )? ) | ^( UNSET_T variable ) | lambda_function_declaration | BACKTRICKLITERAL );
    public final TreePHP.expression_return expression() throws RecognitionException {
        TreePHP.expression_return retval = new TreePHP.expression_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST EXPR162=null;
        SLAST OR_T163=null;
        SLAST XOR_T164=null;
        SLAST AND_T165=null;
        SLAST EQUAL_T166=null;
        SLAST PLUS_EQ167=null;
        SLAST MINUS_EQ168=null;
        SLAST MUL_EQ169=null;
        SLAST DIV_EQ170=null;
        SLAST DOT_EQ171=null;
        SLAST PERCENT_EQ172=null;
        SLAST BIT_AND_EQ173=null;
        SLAST BIT_OR_EQ174=null;
        SLAST POWER_EQ175=null;
        SLAST LMOVE_EQ176=null;
        SLAST RMOVE_EQ177=null;
        SLAST QUESTION_T178=null;
        SLAST COLON_T179=null;
        SLAST LOGICAL_OR_T180=null;
        SLAST LOGICAL_AND_T181=null;
        SLAST BIT_OR_T182=null;
        SLAST POWER_T183=null;
        SLAST REF_T186=null;
        SLAST DOT_T187=null;
        SLAST EQUAL_EQUAL_T188=null;
        SLAST NOT_EQUAL_T189=null;
        SLAST EQUAL_EQUAL_EQUAL_T190=null;
        SLAST NOT_EQUAL_EQUAL_T191=null;
        SLAST LT_T192=null;
        SLAST MT_T193=null;
        SLAST LE_T194=null;
        SLAST ME_T195=null;
        SLAST LSHIFT_T198=null;
        SLAST RSHIFT_T199=null;
        SLAST PLUS_T200=null;
        SLAST MINUS_T201=null;
        SLAST MUL_T202=null;
        SLAST DIV_T203=null;
        SLAST PERCENT_T204=null;
        SLAST CAST_EXPR205=null;
        SLAST TILDA_T207=null;
        SLAST EXC_NOT_T208=null;
        SLAST POSTFIX_EXPR210=null;
        SLAST PREFIX_EXPR212=null;
        SLAST INSTANCEOF_T214=null;
        SLAST AT_T216=null;
        SLAST AT_T218=null;
        SLAST ARRAY_DECL221=null;
        SLAST NEW_T223=null;
        SLAST CLONE_T225=null;
        SLAST EXIT_T227=null;
        SLAST UNSET_T229=null;
        SLAST BACKTRICKLITERAL232=null;
        TreePHP.expression_return etop = null;

        TreePHP.expression_return e1 = null;

        TreePHP.expression_return e2 = null;

        TreePHP.expression_return e3 = null;

        TreePHP.expression_return e = null;

        TreePHP.expression_return expression184 = null;

        TreePHP.expression_return expression185 = null;

        TreePHP.expression_return expression196 = null;

        TreePHP.expression_return expression197 = null;

        TreePHP.cast_option_return cast_option206 = null;

        TreePHP.expression_return expression209 = null;

        TreePHP.plus_minus_return plus_minus211 = null;

        TreePHP.plus_minus_return plus_minus213 = null;

        TreePHP.class_name_reference_return class_name_reference215 = null;

        TreePHP.variable_return variable217 = null;

        TreePHP.scalar_return scalar219 = null;

        TreePHP.list_decl_return list_decl220 = null;

        TreePHP.array_pair_list_return array_pair_list222 = null;

        TreePHP.class_name_reference_return class_name_reference224 = null;

        TreePHP.variable_return variable226 = null;

        TreePHP.expression_return expression228 = null;

        TreePHP.variable_return variable230 = null;

        TreePHP.lambda_function_declaration_return lambda_function_declaration231 = null;


        SLAST EXPR162_tree=null;
        SLAST OR_T163_tree=null;
        SLAST XOR_T164_tree=null;
        SLAST AND_T165_tree=null;
        SLAST EQUAL_T166_tree=null;
        SLAST PLUS_EQ167_tree=null;
        SLAST MINUS_EQ168_tree=null;
        SLAST MUL_EQ169_tree=null;
        SLAST DIV_EQ170_tree=null;
        SLAST DOT_EQ171_tree=null;
        SLAST PERCENT_EQ172_tree=null;
        SLAST BIT_AND_EQ173_tree=null;
        SLAST BIT_OR_EQ174_tree=null;
        SLAST POWER_EQ175_tree=null;
        SLAST LMOVE_EQ176_tree=null;
        SLAST RMOVE_EQ177_tree=null;
        SLAST QUESTION_T178_tree=null;
        SLAST COLON_T179_tree=null;
        SLAST LOGICAL_OR_T180_tree=null;
        SLAST LOGICAL_AND_T181_tree=null;
        SLAST BIT_OR_T182_tree=null;
        SLAST POWER_T183_tree=null;
        SLAST REF_T186_tree=null;
        SLAST DOT_T187_tree=null;
        SLAST EQUAL_EQUAL_T188_tree=null;
        SLAST NOT_EQUAL_T189_tree=null;
        SLAST EQUAL_EQUAL_EQUAL_T190_tree=null;
        SLAST NOT_EQUAL_EQUAL_T191_tree=null;
        SLAST LT_T192_tree=null;
        SLAST MT_T193_tree=null;
        SLAST LE_T194_tree=null;
        SLAST ME_T195_tree=null;
        SLAST LSHIFT_T198_tree=null;
        SLAST RSHIFT_T199_tree=null;
        SLAST PLUS_T200_tree=null;
        SLAST MINUS_T201_tree=null;
        SLAST MUL_T202_tree=null;
        SLAST DIV_T203_tree=null;
        SLAST PERCENT_T204_tree=null;
        SLAST CAST_EXPR205_tree=null;
        SLAST TILDA_T207_tree=null;
        SLAST EXC_NOT_T208_tree=null;
        SLAST POSTFIX_EXPR210_tree=null;
        SLAST PREFIX_EXPR212_tree=null;
        SLAST INSTANCEOF_T214_tree=null;
        SLAST AT_T216_tree=null;
        SLAST AT_T218_tree=null;
        SLAST ARRAY_DECL221_tree=null;
        SLAST NEW_T223_tree=null;
        SLAST CLONE_T225_tree=null;
        SLAST EXIT_T227_tree=null;
        SLAST UNSET_T229_tree=null;
        SLAST BACKTRICKLITERAL232_tree=null;


          SLAST ast = null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:986:3: ( ^( EXPR etop= expression ) | ^( OR_T e1= expression e2= expression ) | ^( XOR_T e1= expression e2= expression ) | ^( AND_T e1= expression e2= expression ) | ^( EQUAL_T e1= expression e2= expression ) | ^( PLUS_EQ e1= expression e2= expression ) | ^( MINUS_EQ e1= expression e2= expression ) | ^( MUL_EQ e1= expression e2= expression ) | ^( DIV_EQ e1= expression e2= expression ) | ^( DOT_EQ e1= expression e2= expression ) | ^( PERCENT_EQ e1= expression e2= expression ) | ^( BIT_AND_EQ e1= expression e2= expression ) | ^( BIT_OR_EQ e1= expression e2= expression ) | ^( POWER_EQ e1= expression e2= expression ) | ^( LMOVE_EQ e1= expression e2= expression ) | ^( RMOVE_EQ e1= expression e2= expression ) | ^( QUESTION_T e1= expression ^( COLON_T e2= expression e3= expression ) ) | ^( LOGICAL_OR_T e1= expression e2= expression ) | ^( LOGICAL_AND_T e1= expression e2= expression ) | ^( BIT_OR_T e1= expression e2= expression ) | ^( POWER_T expression expression ) | ^( REF_T e1= expression (e2= expression )? ) | ^( DOT_T e1= expression e2= expression ) | ^( EQUAL_EQUAL_T e1= expression e2= expression ) | ^( NOT_EQUAL_T e1= expression e2= expression ) | ^( EQUAL_EQUAL_EQUAL_T e1= expression e2= expression ) | ^( NOT_EQUAL_EQUAL_T e1= expression e2= expression ) | ^( LT_T e1= expression e2= expression ) | ^( MT_T e1= expression e2= expression ) | ^( LE_T e1= expression e2= expression ) | ^( ME_T expression expression ) | ^( LSHIFT_T e1= expression e2= expression ) | ^( RSHIFT_T e1= expression e2= expression ) | ^( PLUS_T e1= expression (e2= expression )? ) | ^( MINUS_T e1= expression (e2= expression )? ) | ^( MUL_T e1= expression e2= expression ) | ^( DIV_T e1= expression e2= expression ) | ^( PERCENT_T e1= expression e2= expression ) | ^( CAST_EXPR cast_option e= expression ) | ^( TILDA_T e= expression ) | ^( EXC_NOT_T expression ) | ^( POSTFIX_EXPR e= expression plus_minus ) | ^( PREFIX_EXPR ( plus_minus )+ e= expression ) | ^( INSTANCEOF_T e= expression class_name_reference ) | ( AT_T )? variable | ( AT_T )? scalar | list_decl | ^( ARRAY_DECL ( array_pair_list )? ) | ^( NEW_T class_name_reference ) | ^( CLONE_T variable ) | ^( EXIT_T ( expression )? ) | ^( UNSET_T variable ) | lambda_function_declaration | BACKTRICKLITERAL )
            int alt70=54;
            alt70 = dfa70.predict(input);
            switch (alt70) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:986:5: ^( EXPR etop= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    EXPR162=(SLAST)match(input,EXPR,FOLLOW_EXPR_in_expression1852); 
                    EXPR162_tree = (SLAST)adaptor.dupNode(EXPR162);

                    root_1 = (SLAST)adaptor.becomeRoot(EXPR162_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1856);
                    etop=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, etop.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        retval.expr = (etop!=null?etop.expr:null);
                        ast = (etop!=null?((SLAST)etop.tree):null);
                        if (inExprList) {
                          ((expr_list_scope)expr_list_stack.peek()).list.add(retval.expr);
                        }
                      

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:994:5: ^( OR_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    OR_T163=(SLAST)match(input,OR_T,FOLLOW_OR_T_in_expression1868); 
                    OR_T163_tree = (SLAST)adaptor.dupNode(OR_T163);

                    root_1 = (SLAST)adaptor.becomeRoot(OR_T163_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1872);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1876);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = OR_T163.startIndex;
                        int endIndex = OR_T163.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1 , InfixExpression.OP_STRING_OR, expr2); 
                      

                    }
                    break;
                case 3 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1002:5: ^( XOR_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    XOR_T164=(SLAST)match(input,XOR_T,FOLLOW_XOR_T_in_expression1888); 
                    XOR_T164_tree = (SLAST)adaptor.dupNode(XOR_T164);

                    root_1 = (SLAST)adaptor.becomeRoot(XOR_T164_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1892);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1896);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = XOR_T164.startIndex;
                        int endIndex = XOR_T164.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1 , InfixExpression.OP_STRING_XOR, expr2);
                      

                    }
                    break;
                case 4 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1010:5: ^( AND_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    AND_T165=(SLAST)match(input,AND_T,FOLLOW_AND_T_in_expression1908); 
                    AND_T165_tree = (SLAST)adaptor.dupNode(AND_T165);

                    root_1 = (SLAST)adaptor.becomeRoot(AND_T165_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1912);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1916);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = AND_T165.startIndex;
                        int endIndex = AND_T165.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1 , InfixExpression.OP_STRING_AND, expr2);
                      

                    }
                    break;
                case 5 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1018:5: ^( EQUAL_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    EQUAL_T166=(SLAST)match(input,EQUAL_T,FOLLOW_EQUAL_T_in_expression1928); 
                    EQUAL_T166_tree = (SLAST)adaptor.dupNode(EQUAL_T166);

                    root_1 = (SLAST)adaptor.becomeRoot(EQUAL_T166_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1932);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1936);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = EQUAL_T166.startIndex;
                        int endIndex = EQUAL_T166.endIndex + 1;
                        Expression var = (e1!=null?e1.expr:null);
                        Expression expr = (e2!=null?e2.expr:null);
                        retval.expr = new Assignment(startIndex, endIndex, var, Assignment.OP_EQUAL, expr);
                      

                    }
                    break;
                case 6 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1026:5: ^( PLUS_EQ e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    PLUS_EQ167=(SLAST)match(input,PLUS_EQ,FOLLOW_PLUS_EQ_in_expression1949); 
                    PLUS_EQ167_tree = (SLAST)adaptor.dupNode(PLUS_EQ167);

                    root_1 = (SLAST)adaptor.becomeRoot(PLUS_EQ167_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1953);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1957);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = PLUS_EQ167.startIndex;
                        int endIndex = PLUS_EQ167.endIndex + 1;
                        Expression var = (e1!=null?e1.expr:null);
                        Expression expr = (e2!=null?e2.expr:null);
                        retval.expr = new Assignment(startIndex, endIndex, var, Assignment.OP_PLUS_EQUAL, expr);
                      

                    }
                    break;
                case 7 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1034:5: ^( MINUS_EQ e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    MINUS_EQ168=(SLAST)match(input,MINUS_EQ,FOLLOW_MINUS_EQ_in_expression1969); 
                    MINUS_EQ168_tree = (SLAST)adaptor.dupNode(MINUS_EQ168);

                    root_1 = (SLAST)adaptor.becomeRoot(MINUS_EQ168_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1973);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1977);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = MINUS_EQ168.startIndex;
                        int endIndex = MINUS_EQ168.endIndex + 1;
                        Expression var = (e1!=null?e1.expr:null);
                        Expression expr = (e2!=null?e2.expr:null);
                        retval.expr = new Assignment(startIndex, endIndex, var, Assignment.OP_MINUS_EQUAL, expr);
                      

                    }
                    break;
                case 8 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1042:5: ^( MUL_EQ e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    MUL_EQ169=(SLAST)match(input,MUL_EQ,FOLLOW_MUL_EQ_in_expression1989); 
                    MUL_EQ169_tree = (SLAST)adaptor.dupNode(MUL_EQ169);

                    root_1 = (SLAST)adaptor.becomeRoot(MUL_EQ169_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1993);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1997);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = MUL_EQ169.startIndex;
                        int endIndex = MUL_EQ169.endIndex + 1;
                        Expression var = (e1!=null?e1.expr:null);
                        Expression expr = (e2!=null?e2.expr:null);
                        retval.expr = new Assignment(startIndex, endIndex, var, Assignment.OP_MUL_EQUAL, expr);
                      

                    }
                    break;
                case 9 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1050:5: ^( DIV_EQ e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    DIV_EQ170=(SLAST)match(input,DIV_EQ,FOLLOW_DIV_EQ_in_expression2009); 
                    DIV_EQ170_tree = (SLAST)adaptor.dupNode(DIV_EQ170);

                    root_1 = (SLAST)adaptor.becomeRoot(DIV_EQ170_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2013);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2017);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = DIV_EQ170.startIndex;
                        int endIndex = DIV_EQ170.endIndex + 1;
                        Expression var = (e1!=null?e1.expr:null);
                        Expression expr = (e2!=null?e2.expr:null);
                        retval.expr = new Assignment(startIndex, endIndex, var, Assignment.OP_DIV_EQUAL, expr);
                      

                    }
                    break;
                case 10 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1058:5: ^( DOT_EQ e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    DOT_EQ171=(SLAST)match(input,DOT_EQ,FOLLOW_DOT_EQ_in_expression2029); 
                    DOT_EQ171_tree = (SLAST)adaptor.dupNode(DOT_EQ171);

                    root_1 = (SLAST)adaptor.becomeRoot(DOT_EQ171_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2033);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2037);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = DOT_EQ171.startIndex;
                        int endIndex = DOT_EQ171.endIndex + 1;
                        Expression var = (e1!=null?e1.expr:null);
                        Expression expr = (e2!=null?e2.expr:null);
                        retval.expr = new Assignment(startIndex, endIndex, var, Assignment.OP_CONCAT_EQUAL, expr);
                      

                    }
                    break;
                case 11 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1066:5: ^( PERCENT_EQ e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    PERCENT_EQ172=(SLAST)match(input,PERCENT_EQ,FOLLOW_PERCENT_EQ_in_expression2049); 
                    PERCENT_EQ172_tree = (SLAST)adaptor.dupNode(PERCENT_EQ172);

                    root_1 = (SLAST)adaptor.becomeRoot(PERCENT_EQ172_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2053);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2057);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = PERCENT_EQ172.startIndex;
                        int endIndex = PERCENT_EQ172.endIndex + 1;
                        Expression var = (e1!=null?e1.expr:null);
                        Expression expr = (e2!=null?e2.expr:null);
                        retval.expr = new Assignment(startIndex, endIndex, var, Assignment.OP_MOD_EQUAL, expr);
                      

                    }
                    break;
                case 12 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1074:5: ^( BIT_AND_EQ e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    BIT_AND_EQ173=(SLAST)match(input,BIT_AND_EQ,FOLLOW_BIT_AND_EQ_in_expression2069); 
                    BIT_AND_EQ173_tree = (SLAST)adaptor.dupNode(BIT_AND_EQ173);

                    root_1 = (SLAST)adaptor.becomeRoot(BIT_AND_EQ173_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2073);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2077);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = BIT_AND_EQ173.startIndex;
                        int endIndex = BIT_AND_EQ173.endIndex + 1;
                        Expression var = (e1!=null?e1.expr:null);
                        Expression expr = (e2!=null?e2.expr:null);
                        retval.expr = new Assignment(startIndex, endIndex, var, Assignment.OP_AND_EQUAL, expr);
                      

                    }
                    break;
                case 13 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1082:5: ^( BIT_OR_EQ e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    BIT_OR_EQ174=(SLAST)match(input,BIT_OR_EQ,FOLLOW_BIT_OR_EQ_in_expression2089); 
                    BIT_OR_EQ174_tree = (SLAST)adaptor.dupNode(BIT_OR_EQ174);

                    root_1 = (SLAST)adaptor.becomeRoot(BIT_OR_EQ174_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2093);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2097);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = BIT_OR_EQ174.startIndex;
                        int endIndex = BIT_OR_EQ174.endIndex + 1;
                        Expression var = (e1!=null?e1.expr:null);
                        Expression expr = (e2!=null?e2.expr:null);
                        retval.expr = new Assignment(startIndex, endIndex, var, Assignment.OP_OR_EQUAL, expr);
                      

                    }
                    break;
                case 14 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1090:5: ^( POWER_EQ e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    POWER_EQ175=(SLAST)match(input,POWER_EQ,FOLLOW_POWER_EQ_in_expression2109); 
                    POWER_EQ175_tree = (SLAST)adaptor.dupNode(POWER_EQ175);

                    root_1 = (SLAST)adaptor.becomeRoot(POWER_EQ175_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2113);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2117);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = POWER_EQ175.startIndex;
                        int endIndex = POWER_EQ175.endIndex + 1;
                        Expression var = (e1!=null?e1.expr:null);
                        Expression expr = (e2!=null?e2.expr:null);
                        retval.expr = new Assignment(startIndex, endIndex, var, Assignment.OP_XOR_EQUAL, expr);
                      

                    }
                    break;
                case 15 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1098:5: ^( LMOVE_EQ e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    LMOVE_EQ176=(SLAST)match(input,LMOVE_EQ,FOLLOW_LMOVE_EQ_in_expression2129); 
                    LMOVE_EQ176_tree = (SLAST)adaptor.dupNode(LMOVE_EQ176);

                    root_1 = (SLAST)adaptor.becomeRoot(LMOVE_EQ176_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2133);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2137);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = LMOVE_EQ176.startIndex;
                        int endIndex = LMOVE_EQ176.endIndex + 1;
                        Expression var = (e1!=null?e1.expr:null);
                        Expression expr = (e2!=null?e2.expr:null);
                        retval.expr = new Assignment(startIndex, endIndex, var, Assignment.OP_SL_EQUAL, expr);
                      

                    }
                    break;
                case 16 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1106:5: ^( RMOVE_EQ e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    RMOVE_EQ177=(SLAST)match(input,RMOVE_EQ,FOLLOW_RMOVE_EQ_in_expression2149); 
                    RMOVE_EQ177_tree = (SLAST)adaptor.dupNode(RMOVE_EQ177);

                    root_1 = (SLAST)adaptor.becomeRoot(RMOVE_EQ177_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2153);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2157);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = RMOVE_EQ177.startIndex;
                        int endIndex = RMOVE_EQ177.endIndex + 1;
                        Expression var = (e1!=null?e1.expr:null);
                        Expression expr = (e2!=null?e2.expr:null);
                        retval.expr = new Assignment(startIndex, endIndex, var, Assignment.OP_SR_EQUAL, expr);
                      

                    }
                    break;
                case 17 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1114:5: ^( QUESTION_T e1= expression ^( COLON_T e2= expression e3= expression ) )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    QUESTION_T178=(SLAST)match(input,QUESTION_T,FOLLOW_QUESTION_T_in_expression2169); 
                    QUESTION_T178_tree = (SLAST)adaptor.dupNode(QUESTION_T178);

                    root_1 = (SLAST)adaptor.becomeRoot(QUESTION_T178_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2173);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_2 = _last;
                    SLAST _first_2 = null;
                    SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    COLON_T179=(SLAST)match(input,COLON_T,FOLLOW_COLON_T_in_expression2176); 
                    COLON_T179_tree = (SLAST)adaptor.dupNode(COLON_T179);

                    root_2 = (SLAST)adaptor.becomeRoot(COLON_T179_tree, root_2);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2180);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_2, e2.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2184);
                    e3=expression();

                    state._fsp--;

                    adaptor.addChild(root_2, e3.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
                    }


                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = QUESTION_T178.startIndex;
                        int endIndex = QUESTION_T178.endIndex + 1;
                        retval.expr = new ConditionalExpression(startIndex, endIndex, (e1!=null?e1.expr:null), (e2!=null?e2.expr:null), (e3!=null?e3.expr:null)); 
                      

                    }
                    break;
                case 18 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1120:5: ^( LOGICAL_OR_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    LOGICAL_OR_T180=(SLAST)match(input,LOGICAL_OR_T,FOLLOW_LOGICAL_OR_T_in_expression2199); 
                    LOGICAL_OR_T180_tree = (SLAST)adaptor.dupNode(LOGICAL_OR_T180);

                    root_1 = (SLAST)adaptor.becomeRoot(LOGICAL_OR_T180_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2203);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2207);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = LOGICAL_OR_T180.startIndex;
                        int endIndex = LOGICAL_OR_T180.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1 , InfixExpression.OP_BOOL_OR, expr2); 
                      

                    }
                    break;
                case 19 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1128:5: ^( LOGICAL_AND_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    LOGICAL_AND_T181=(SLAST)match(input,LOGICAL_AND_T,FOLLOW_LOGICAL_AND_T_in_expression2219); 
                    LOGICAL_AND_T181_tree = (SLAST)adaptor.dupNode(LOGICAL_AND_T181);

                    root_1 = (SLAST)adaptor.becomeRoot(LOGICAL_AND_T181_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2223);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2227);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = LOGICAL_AND_T181.startIndex;
                        int endIndex = LOGICAL_AND_T181.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1 , InfixExpression.OP_BOOL_AND, expr2);
                      

                    }
                    break;
                case 20 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1136:5: ^( BIT_OR_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    BIT_OR_T182=(SLAST)match(input,BIT_OR_T,FOLLOW_BIT_OR_T_in_expression2239); 
                    BIT_OR_T182_tree = (SLAST)adaptor.dupNode(BIT_OR_T182);

                    root_1 = (SLAST)adaptor.becomeRoot(BIT_OR_T182_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2243);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2247);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = BIT_OR_T182.startIndex;
                        int endIndex = BIT_OR_T182.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1 , InfixExpression.OP_OR, expr2); 
                      

                    }
                    break;
                case 21 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1144:5: ^( POWER_T expression expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    POWER_T183=(SLAST)match(input,POWER_T,FOLLOW_POWER_T_in_expression2259); 
                    POWER_T183_tree = (SLAST)adaptor.dupNode(POWER_T183);

                    root_1 = (SLAST)adaptor.becomeRoot(POWER_T183_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2261);
                    expression184=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression184.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2263);
                    expression185=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression185.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = POWER_T183.startIndex;
                        int endIndex = POWER_T183.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1 , InfixExpression.OP_XOR, expr2); 
                      

                    }
                    break;
                case 22 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1152:5: ^( REF_T e1= expression (e2= expression )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    REF_T186=(SLAST)match(input,REF_T,FOLLOW_REF_T_in_expression2275); 
                    REF_T186_tree = (SLAST)adaptor.dupNode(REF_T186);

                    root_1 = (SLAST)adaptor.becomeRoot(REF_T186_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2279);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1152:29: (e2= expression )?
                    int alt62=2;
                    int LA62_0 = input.LA(1);

                    if ( (LA62_0==METHOD_DECL||LA62_0==VAR_DECL||LA62_0==CALL||LA62_0==EXPR||(LA62_0>=SCALAR && LA62_0<=CAST_EXPR)||LA62_0==REF_T||LA62_0==EQUAL_T||(LA62_0>=OR_T && LA62_0<=EXC_NOT_T)||(LA62_0>=INSTANCEOF_T && LA62_0<=BACKTRICKLITERAL)) ) {
                        alt62=1;
                    }
                    switch (alt62) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1152:29: e2= expression
                            {
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_expression_in_expression2283);
                            e2=expression();

                            state._fsp--;

                            adaptor.addChild(root_1, e2.getTree());

                            }
                            break;

                    }


                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = REF_T186.startIndex;
                        int endIndex = REF_T186.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        if (expr2 != null) {
                          retval.expr = new InfixExpression(startIndex, endIndex, expr1 , InfixExpression.OP_AND, expr2);
                        }
                        else {
                          retval.expr = new ReferenceExpression(startIndex, endIndex, expr1);
                        }
                      

                    }
                    break;
                case 23 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1165:5: ^( DOT_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    DOT_T187=(SLAST)match(input,DOT_T,FOLLOW_DOT_T_in_expression2296); 
                    DOT_T187_tree = (SLAST)adaptor.dupNode(DOT_T187);

                    root_1 = (SLAST)adaptor.becomeRoot(DOT_T187_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2300);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2304);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = DOT_T187.startIndex;
                        int endIndex = DOT_T187.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1 , InfixExpression.OP_CONCAT, expr2); 
                      

                    }
                    break;
                case 24 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1173:5: ^( EQUAL_EQUAL_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    EQUAL_EQUAL_T188=(SLAST)match(input,EQUAL_EQUAL_T,FOLLOW_EQUAL_EQUAL_T_in_expression2316); 
                    EQUAL_EQUAL_T188_tree = (SLAST)adaptor.dupNode(EQUAL_EQUAL_T188);

                    root_1 = (SLAST)adaptor.becomeRoot(EQUAL_EQUAL_T188_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2320);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2324);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = EQUAL_EQUAL_T188.startIndex;
                        int endIndex = EQUAL_EQUAL_T188.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1 , InfixExpression.OP_IS_EQUAL, expr2);
                      

                    }
                    break;
                case 25 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1181:5: ^( NOT_EQUAL_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    NOT_EQUAL_T189=(SLAST)match(input,NOT_EQUAL_T,FOLLOW_NOT_EQUAL_T_in_expression2336); 
                    NOT_EQUAL_T189_tree = (SLAST)adaptor.dupNode(NOT_EQUAL_T189);

                    root_1 = (SLAST)adaptor.becomeRoot(NOT_EQUAL_T189_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2340);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2344);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = NOT_EQUAL_T189.startIndex;
                        int endIndex = NOT_EQUAL_T189.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1 , InfixExpression.OP_IS_NOT_EQUAL, expr2);
                      

                    }
                    break;
                case 26 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1189:5: ^( EQUAL_EQUAL_EQUAL_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    EQUAL_EQUAL_EQUAL_T190=(SLAST)match(input,EQUAL_EQUAL_EQUAL_T,FOLLOW_EQUAL_EQUAL_EQUAL_T_in_expression2356); 
                    EQUAL_EQUAL_EQUAL_T190_tree = (SLAST)adaptor.dupNode(EQUAL_EQUAL_EQUAL_T190);

                    root_1 = (SLAST)adaptor.becomeRoot(EQUAL_EQUAL_EQUAL_T190_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2360);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2364);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = EQUAL_EQUAL_EQUAL_T190.startIndex;
                        int endIndex = EQUAL_EQUAL_EQUAL_T190.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1 , InfixExpression.OP_IS_IDENTICAL, expr2);
                      

                    }
                    break;
                case 27 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1197:5: ^( NOT_EQUAL_EQUAL_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    NOT_EQUAL_EQUAL_T191=(SLAST)match(input,NOT_EQUAL_EQUAL_T,FOLLOW_NOT_EQUAL_EQUAL_T_in_expression2376); 
                    NOT_EQUAL_EQUAL_T191_tree = (SLAST)adaptor.dupNode(NOT_EQUAL_EQUAL_T191);

                    root_1 = (SLAST)adaptor.becomeRoot(NOT_EQUAL_EQUAL_T191_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2380);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2384);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = NOT_EQUAL_EQUAL_T191.startIndex;
                        int endIndex = NOT_EQUAL_EQUAL_T191.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1 , InfixExpression.OP_IS_NOT_IDENTICAL, expr2);
                      

                    }
                    break;
                case 28 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1205:5: ^( LT_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    LT_T192=(SLAST)match(input,LT_T,FOLLOW_LT_T_in_expression2396); 
                    LT_T192_tree = (SLAST)adaptor.dupNode(LT_T192);

                    root_1 = (SLAST)adaptor.becomeRoot(LT_T192_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2400);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2404);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = LT_T192.startIndex;
                        int endIndex = LT_T192.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1 , InfixExpression.OP_RGREATER, expr2); 
                      

                    }
                    break;
                case 29 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1213:5: ^( MT_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    MT_T193=(SLAST)match(input,MT_T,FOLLOW_MT_T_in_expression2416); 
                    MT_T193_tree = (SLAST)adaptor.dupNode(MT_T193);

                    root_1 = (SLAST)adaptor.becomeRoot(MT_T193_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2420);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2424);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = MT_T193.startIndex;
                        int endIndex = MT_T193.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1 , InfixExpression.OP_LGREATER, expr2); 
                      

                    }
                    break;
                case 30 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1221:5: ^( LE_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    LE_T194=(SLAST)match(input,LE_T,FOLLOW_LE_T_in_expression2436); 
                    LE_T194_tree = (SLAST)adaptor.dupNode(LE_T194);

                    root_1 = (SLAST)adaptor.becomeRoot(LE_T194_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2440);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2444);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = LE_T194.startIndex;
                        int endIndex = LE_T194.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1 , InfixExpression.OP_IS_SMALLER_OR_EQUAL, expr2); 
                      

                    }
                    break;
                case 31 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1229:5: ^( ME_T expression expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    ME_T195=(SLAST)match(input,ME_T,FOLLOW_ME_T_in_expression2456); 
                    ME_T195_tree = (SLAST)adaptor.dupNode(ME_T195);

                    root_1 = (SLAST)adaptor.becomeRoot(ME_T195_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2458);
                    expression196=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression196.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2460);
                    expression197=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression197.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = ME_T195.startIndex;
                        int endIndex = ME_T195.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1 , InfixExpression.OP_IS_GREATER_OR_EQUAL, expr2); 
                      

                    }
                    break;
                case 32 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1237:5: ^( LSHIFT_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    LSHIFT_T198=(SLAST)match(input,LSHIFT_T,FOLLOW_LSHIFT_T_in_expression2472); 
                    LSHIFT_T198_tree = (SLAST)adaptor.dupNode(LSHIFT_T198);

                    root_1 = (SLAST)adaptor.becomeRoot(LSHIFT_T198_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2476);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2480);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = LSHIFT_T198.startIndex;
                        int endIndex = LSHIFT_T198.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1, InfixExpression.OP_SL, expr2); 
                      

                    }
                    break;
                case 33 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1245:5: ^( RSHIFT_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    RSHIFT_T199=(SLAST)match(input,RSHIFT_T,FOLLOW_RSHIFT_T_in_expression2492); 
                    RSHIFT_T199_tree = (SLAST)adaptor.dupNode(RSHIFT_T199);

                    root_1 = (SLAST)adaptor.becomeRoot(RSHIFT_T199_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2496);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2500);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = RSHIFT_T199.startIndex;
                        int endIndex = RSHIFT_T199.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1, InfixExpression.OP_SR, expr2); 
                      

                    }
                    break;
                case 34 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1253:5: ^( PLUS_T e1= expression (e2= expression )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    PLUS_T200=(SLAST)match(input,PLUS_T,FOLLOW_PLUS_T_in_expression2512); 
                    PLUS_T200_tree = (SLAST)adaptor.dupNode(PLUS_T200);

                    root_1 = (SLAST)adaptor.becomeRoot(PLUS_T200_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2516);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1253:30: (e2= expression )?
                    int alt63=2;
                    int LA63_0 = input.LA(1);

                    if ( (LA63_0==METHOD_DECL||LA63_0==VAR_DECL||LA63_0==CALL||LA63_0==EXPR||(LA63_0>=SCALAR && LA63_0<=CAST_EXPR)||LA63_0==REF_T||LA63_0==EQUAL_T||(LA63_0>=OR_T && LA63_0<=EXC_NOT_T)||(LA63_0>=INSTANCEOF_T && LA63_0<=BACKTRICKLITERAL)) ) {
                        alt63=1;
                    }
                    switch (alt63) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1253:30: e2= expression
                            {
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_expression_in_expression2520);
                            e2=expression();

                            state._fsp--;

                            adaptor.addChild(root_1, e2.getTree());

                            }
                            break;

                    }


                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = PLUS_T200.startIndex;
                        int endIndex = PLUS_T200.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        if (expr2 != null) {
                          retval.expr = new InfixExpression(startIndex, endIndex, expr1, InfixExpression.OP_PLUS, expr2);
                        }
                        else {
                          retval.expr = new UnaryOperation(startIndex, endIndex, (e1!=null?e1.expr:null) , UnaryOperation.OP_PLUS);
                        }
                      

                    }
                    break;
                case 35 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1266:5: ^( MINUS_T e1= expression (e2= expression )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    MINUS_T201=(SLAST)match(input,MINUS_T,FOLLOW_MINUS_T_in_expression2533); 
                    MINUS_T201_tree = (SLAST)adaptor.dupNode(MINUS_T201);

                    root_1 = (SLAST)adaptor.becomeRoot(MINUS_T201_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2537);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1266:31: (e2= expression )?
                    int alt64=2;
                    int LA64_0 = input.LA(1);

                    if ( (LA64_0==METHOD_DECL||LA64_0==VAR_DECL||LA64_0==CALL||LA64_0==EXPR||(LA64_0>=SCALAR && LA64_0<=CAST_EXPR)||LA64_0==REF_T||LA64_0==EQUAL_T||(LA64_0>=OR_T && LA64_0<=EXC_NOT_T)||(LA64_0>=INSTANCEOF_T && LA64_0<=BACKTRICKLITERAL)) ) {
                        alt64=1;
                    }
                    switch (alt64) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1266:31: e2= expression
                            {
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_expression_in_expression2541);
                            e2=expression();

                            state._fsp--;

                            adaptor.addChild(root_1, e2.getTree());

                            }
                            break;

                    }


                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = MINUS_T201.startIndex;
                        int endIndex = MINUS_T201.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        if (expr2 != null) {
                          retval.expr = new InfixExpression(startIndex, endIndex, expr1, InfixExpression.OP_MINUS, expr2);
                        }
                        else {
                          retval.expr = new UnaryOperation(startIndex, endIndex, (e1!=null?e1.expr:null) , UnaryOperation.OP_MINUS);
                        }
                      

                    }
                    break;
                case 36 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1279:5: ^( MUL_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    MUL_T202=(SLAST)match(input,MUL_T,FOLLOW_MUL_T_in_expression2554); 
                    MUL_T202_tree = (SLAST)adaptor.dupNode(MUL_T202);

                    root_1 = (SLAST)adaptor.becomeRoot(MUL_T202_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2558);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2562);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = MUL_T202.startIndex;
                        int endIndex = MUL_T202.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1, InfixExpression.OP_MUL, expr2);
                      

                    }
                    break;
                case 37 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1287:5: ^( DIV_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    DIV_T203=(SLAST)match(input,DIV_T,FOLLOW_DIV_T_in_expression2574); 
                    DIV_T203_tree = (SLAST)adaptor.dupNode(DIV_T203);

                    root_1 = (SLAST)adaptor.becomeRoot(DIV_T203_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2578);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2582);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = DIV_T203.startIndex;
                        int endIndex = DIV_T203.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1, InfixExpression.OP_DIV, expr2);
                      

                    }
                    break;
                case 38 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1295:5: ^( PERCENT_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    PERCENT_T204=(SLAST)match(input,PERCENT_T,FOLLOW_PERCENT_T_in_expression2594); 
                    PERCENT_T204_tree = (SLAST)adaptor.dupNode(PERCENT_T204);

                    root_1 = (SLAST)adaptor.becomeRoot(PERCENT_T204_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2598);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2602);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = PERCENT_T204.startIndex;
                        int endIndex = PERCENT_T204.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1, InfixExpression.OP_MOD, expr2);
                      

                    }
                    break;
                case 39 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1303:5: ^( CAST_EXPR cast_option e= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    CAST_EXPR205=(SLAST)match(input,CAST_EXPR,FOLLOW_CAST_EXPR_in_expression2614); 
                    CAST_EXPR205_tree = (SLAST)adaptor.dupNode(CAST_EXPR205);

                    root_1 = (SLAST)adaptor.becomeRoot(CAST_EXPR205_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_cast_option_in_expression2616);
                    cast_option206=cast_option();

                    state._fsp--;

                    adaptor.addChild(root_1, cast_option206.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2620);
                    e=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int result = (cast_option206!=null?cast_option206.castOption:0);
                        int startIndex = CAST_EXPR205.startIndex;
                        int endIndex = CAST_EXPR205.endIndex + 1;
                        Expression expr = (e!=null?e.expr:null);
                        switch(result) {
                          case 1:
                          case 2:
                            retval.expr = new CastExpression(startIndex, endIndex, expr, CastExpression.TYPE_BOOL);
                            break;
                          case 3:
                            retval.expr = new CastExpression(startIndex, endIndex, expr, CastExpression.TYPE_INT);
                            break;
                          case 6:
                            retval.expr = new CastExpression(startIndex, endIndex, expr, CastExpression.TYPE_ARRAY);
                            break;
                          case 7:
                            retval.expr = new CastExpression(startIndex, endIndex, expr, CastExpression.TYPE_OBJECT);
                            break;
                          case 8:
                            retval.expr = new CastExpression(startIndex, endIndex, expr, CastExpression.TYPE_REAL);
                            break;
                          case 9:
                            retval.expr = new CastExpression(startIndex, endIndex, expr, CastExpression.TYPE_STRING);
                            break;
                          case 10:
                            retval.expr = new CastExpression(startIndex, endIndex, expr, CastExpression.TYPE_UNSET);
                            break;
                          default:
                            retval.expr = new CastExpression(startIndex, endIndex, expr, CastExpression.TYPE_OBJECT);
                            break;
                        }
                      

                    }
                    break;
                case 40 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1337:5: ^( TILDA_T e= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    TILDA_T207=(SLAST)match(input,TILDA_T,FOLLOW_TILDA_T_in_expression2632); 
                    TILDA_T207_tree = (SLAST)adaptor.dupNode(TILDA_T207);

                    root_1 = (SLAST)adaptor.becomeRoot(TILDA_T207_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2636);
                    e=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                          int startIndex = TILDA_T207.startIndex;
                          int endIndex = TILDA_T207.endIndex + 1;
                          retval.expr = new UnaryOperation(startIndex, endIndex, (e!=null?e.expr:null) , UnaryOperation.OP_TILDA);
                      

                    }
                    break;
                case 41 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1343:5: ^( EXC_NOT_T expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    EXC_NOT_T208=(SLAST)match(input,EXC_NOT_T,FOLLOW_EXC_NOT_T_in_expression2648); 
                    EXC_NOT_T208_tree = (SLAST)adaptor.dupNode(EXC_NOT_T208);

                    root_1 = (SLAST)adaptor.becomeRoot(EXC_NOT_T208_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2650);
                    expression209=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression209.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                          int startIndex = EXC_NOT_T208.startIndex;
                          int endIndex = EXC_NOT_T208.endIndex + 1;
                          retval.expr = new UnaryOperation(startIndex, endIndex, (e!=null?e.expr:null) , UnaryOperation.OP_NOT);
                      

                    }
                    break;
                case 42 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1349:5: ^( POSTFIX_EXPR e= expression plus_minus )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    POSTFIX_EXPR210=(SLAST)match(input,POSTFIX_EXPR,FOLLOW_POSTFIX_EXPR_in_expression2662); 
                    POSTFIX_EXPR210_tree = (SLAST)adaptor.dupNode(POSTFIX_EXPR210);

                    root_1 = (SLAST)adaptor.becomeRoot(POSTFIX_EXPR210_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2666);
                    e=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_plus_minus_in_expression2668);
                    plus_minus211=plus_minus();

                    state._fsp--;

                    adaptor.addChild(root_1, plus_minus211.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                          int startIndex = POSTFIX_EXPR210.startIndex;
                          int endIndex = POSTFIX_EXPR210.endIndex + 1;
                          if ((plus_minus211!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(plus_minus211.start),
                      input.getTreeAdaptor().getTokenStopIndex(plus_minus211.start))):null).equals("++")) {
                            retval.expr = new PostfixExpression(startIndex, endIndex, (e!=null?e.expr:null) , PostfixExpression.OP_INC);
                          }
                          else {
                            retval.expr = new PostfixExpression(startIndex, endIndex, (e!=null?e.expr:null) , PostfixExpression.OP_DEC);
                          } 
                      

                    }
                    break;
                case 43 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1360:5: ^( PREFIX_EXPR ( plus_minus )+ e= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    PREFIX_EXPR212=(SLAST)match(input,PREFIX_EXPR,FOLLOW_PREFIX_EXPR_in_expression2680); 
                    PREFIX_EXPR212_tree = (SLAST)adaptor.dupNode(PREFIX_EXPR212);

                    root_1 = (SLAST)adaptor.becomeRoot(PREFIX_EXPR212_tree, root_1);



                    match(input, Token.DOWN, null); 
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1360:19: ( plus_minus )+
                    int cnt65=0;
                    loop65:
                    do {
                        int alt65=2;
                        int LA65_0 = input.LA(1);

                        if ( ((LA65_0>=PLUS_PLUS_T && LA65_0<=MINUS_MINUS_T)) ) {
                            alt65=1;
                        }


                        switch (alt65) {
                    	case 1 :
                    	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1360:19: plus_minus
                    	    {
                    	    _last = (SLAST)input.LT(1);
                    	    pushFollow(FOLLOW_plus_minus_in_expression2682);
                    	    plus_minus213=plus_minus();

                    	    state._fsp--;

                    	    adaptor.addChild(root_1, plus_minus213.getTree());

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt65 >= 1 ) break loop65;
                                EarlyExitException eee =
                                    new EarlyExitException(65, input);
                                throw eee;
                        }
                        cnt65++;
                    } while (true);

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2687);
                    e=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                          int startIndex = PREFIX_EXPR212.startIndex;
                          int endIndex = PREFIX_EXPR212.endIndex + 1;
                          if ((plus_minus213!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(plus_minus213.start),
                      input.getTreeAdaptor().getTokenStopIndex(plus_minus213.start))):null).equals("++")) {
                            retval.expr = new PrefixExpression(startIndex, endIndex, (e!=null?e.expr:null), PrefixExpression.OP_INC);
                          }
                          else {
                            retval.expr = new PrefixExpression(startIndex, endIndex, (e!=null?e.expr:null), PrefixExpression.OP_DEC);
                          }
                      

                    }
                    break;
                case 44 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1371:5: ^( INSTANCEOF_T e= expression class_name_reference )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    INSTANCEOF_T214=(SLAST)match(input,INSTANCEOF_T,FOLLOW_INSTANCEOF_T_in_expression2699); 
                    INSTANCEOF_T214_tree = (SLAST)adaptor.dupNode(INSTANCEOF_T214);

                    root_1 = (SLAST)adaptor.becomeRoot(INSTANCEOF_T214_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2703);
                    e=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_class_name_reference_in_expression2705);
                    class_name_reference215=class_name_reference();

                    state._fsp--;

                    adaptor.addChild(root_1, class_name_reference215.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = INSTANCEOF_T214.startIndex;
                        int endIndex = INSTANCEOF_T214.endIndex + 1;
                        retval.expr = new InstanceOfExpression(startIndex, endIndex, (e!=null?e.expr:null), (class_name_reference215!=null?class_name_reference215.var:null)); 
                      

                    }
                    break;
                case 45 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1377:5: ( AT_T )? variable
                    {
                    root_0 = (SLAST)adaptor.nil();

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1377:5: ( AT_T )?
                    int alt66=2;
                    int LA66_0 = input.LA(1);

                    if ( (LA66_0==AT_T) ) {
                        alt66=1;
                    }
                    switch (alt66) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1377:5: AT_T
                            {
                            _last = (SLAST)input.LT(1);
                            AT_T216=(SLAST)match(input,AT_T,FOLLOW_AT_T_in_expression2716); 
                            AT_T216_tree = (SLAST)adaptor.dupNode(AT_T216);

                            adaptor.addChild(root_0, AT_T216_tree);


                            }
                            break;

                    }

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_variable_in_expression2719);
                    variable217=variable();

                    state._fsp--;

                    adaptor.addChild(root_0, variable217.getTree());

                        retval.expr = (variable217!=null?variable217.var:null);
                      

                    }
                    break;
                case 46 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1381:5: ( AT_T )? scalar
                    {
                    root_0 = (SLAST)adaptor.nil();

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1381:5: ( AT_T )?
                    int alt67=2;
                    int LA67_0 = input.LA(1);

                    if ( (LA67_0==AT_T) ) {
                        alt67=1;
                    }
                    switch (alt67) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1381:5: AT_T
                            {
                            _last = (SLAST)input.LT(1);
                            AT_T218=(SLAST)match(input,AT_T,FOLLOW_AT_T_in_expression2729); 
                            AT_T218_tree = (SLAST)adaptor.dupNode(AT_T218);

                            adaptor.addChild(root_0, AT_T218_tree);


                            }
                            break;

                    }

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_scalar_in_expression2732);
                    scalar219=scalar();

                    state._fsp--;

                    adaptor.addChild(root_0, scalar219.getTree());

                        retval.expr = (scalar219!=null?scalar219.expr:null);
                        ast = (scalar219!=null?((SLAST)scalar219.tree):null);
                      

                    }
                    break;
                case 47 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1386:5: list_decl
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_list_decl_in_expression2742);
                    list_decl220=list_decl();

                    state._fsp--;

                    adaptor.addChild(root_0, list_decl220.getTree());

                        retval.expr = (list_decl220!=null?list_decl220.expr:null);
                      

                    }
                    break;
                case 48 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1390:5: ^( ARRAY_DECL ( array_pair_list )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    ARRAY_DECL221=(SLAST)match(input,ARRAY_DECL,FOLLOW_ARRAY_DECL_in_expression2753); 
                    ARRAY_DECL221_tree = (SLAST)adaptor.dupNode(ARRAY_DECL221);

                    root_1 = (SLAST)adaptor.becomeRoot(ARRAY_DECL221_tree, root_1);



                    if ( input.LA(1)==Token.DOWN ) {
                        match(input, Token.DOWN, null); 
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1390:18: ( array_pair_list )?
                        int alt68=2;
                        int LA68_0 = input.LA(1);

                        if ( (LA68_0==METHOD_DECL||LA68_0==VAR_DECL||LA68_0==CALL||LA68_0==EXPR||(LA68_0>=SCALAR && LA68_0<=CAST_EXPR)||LA68_0==REF_T||LA68_0==ARROW_T||LA68_0==EQUAL_T||(LA68_0>=OR_T && LA68_0<=EXC_NOT_T)||(LA68_0>=INSTANCEOF_T && LA68_0<=BACKTRICKLITERAL)) ) {
                            alt68=1;
                        }
                        switch (alt68) {
                            case 1 :
                                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1390:18: array_pair_list
                                {
                                _last = (SLAST)input.LT(1);
                                pushFollow(FOLLOW_array_pair_list_in_expression2755);
                                array_pair_list222=array_pair_list();

                                state._fsp--;

                                adaptor.addChild(root_1, array_pair_list222.getTree());

                                }
                                break;

                        }


                        match(input, Token.UP, null); 
                    }adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = ARRAY_DECL221.startIndex;
                        int endIndex = ARRAY_DECL221.endIndex + 1;
                        if ((array_pair_list222!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(array_pair_list222.start),
                      input.getTreeAdaptor().getTokenStopIndex(array_pair_list222.start))):null) != null) {
                           retval.expr = new ArrayCreation(startIndex, endIndex, (array_pair_list222!=null?array_pair_list222.arrayList:null));
                        }
                        else {
                           retval.expr = new ArrayCreation(startIndex, endIndex, new LinkedList());
                        }
                      

                    }
                    break;
                case 49 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1401:5: ^( NEW_T class_name_reference )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    NEW_T223=(SLAST)match(input,NEW_T,FOLLOW_NEW_T_in_expression2768); 
                    NEW_T223_tree = (SLAST)adaptor.dupNode(NEW_T223);

                    root_1 = (SLAST)adaptor.becomeRoot(NEW_T223_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_class_name_reference_in_expression2770);
                    class_name_reference224=class_name_reference();

                    state._fsp--;

                    adaptor.addChild(root_1, class_name_reference224.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = NEW_T223.startIndex;
                        int endIndex = NEW_T223.endIndex + 1;
                        Expression className = (class_name_reference224!=null?class_name_reference224.var:null);
                        PHPCallArgumentsList ctor = (class_name_reference224!=null?class_name_reference224.parameterList:null);
                        if (ctor == null) {
                          ctor = new PHPCallArgumentsList();
                        }
                        
                        ClassInstanceCreation classInstanceCreation = new ClassInstanceCreation(startIndex, endIndex, className, ctor);
                        retval.expr = classInstanceCreation;
                      

                    }
                    break;
                case 50 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1415:5: ^( CLONE_T variable )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    CLONE_T225=(SLAST)match(input,CLONE_T,FOLLOW_CLONE_T_in_expression2785); 
                    CLONE_T225_tree = (SLAST)adaptor.dupNode(CLONE_T225);

                    root_1 = (SLAST)adaptor.becomeRoot(CLONE_T225_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_variable_in_expression2787);
                    variable226=variable();

                    state._fsp--;

                    adaptor.addChild(root_1, variable226.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = CLONE_T225.startIndex;
                        int endIndex = CLONE_T225.endIndex + 1;
                        retval.expr = new CloneExpression(startIndex, endIndex, (variable226!=null?variable226.var:null));
                      

                    }
                    break;
                case 51 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1421:5: ^( EXIT_T ( expression )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    EXIT_T227=(SLAST)match(input,EXIT_T,FOLLOW_EXIT_T_in_expression2799); 
                    EXIT_T227_tree = (SLAST)adaptor.dupNode(EXIT_T227);

                    root_1 = (SLAST)adaptor.becomeRoot(EXIT_T227_tree, root_1);



                    if ( input.LA(1)==Token.DOWN ) {
                        match(input, Token.DOWN, null); 
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1421:14: ( expression )?
                        int alt69=2;
                        int LA69_0 = input.LA(1);

                        if ( (LA69_0==METHOD_DECL||LA69_0==VAR_DECL||LA69_0==CALL||LA69_0==EXPR||(LA69_0>=SCALAR && LA69_0<=CAST_EXPR)||LA69_0==REF_T||LA69_0==EQUAL_T||(LA69_0>=OR_T && LA69_0<=EXC_NOT_T)||(LA69_0>=INSTANCEOF_T && LA69_0<=BACKTRICKLITERAL)) ) {
                            alt69=1;
                        }
                        switch (alt69) {
                            case 1 :
                                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1421:14: expression
                                {
                                _last = (SLAST)input.LT(1);
                                pushFollow(FOLLOW_expression_in_expression2801);
                                expression228=expression();

                                state._fsp--;

                                adaptor.addChild(root_1, expression228.getTree());

                                }
                                break;

                        }


                        match(input, Token.UP, null); 
                    }adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 52 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1422:5: ^( UNSET_T variable )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    UNSET_T229=(SLAST)match(input,UNSET_T,FOLLOW_UNSET_T_in_expression2810); 
                    UNSET_T229_tree = (SLAST)adaptor.dupNode(UNSET_T229);

                    root_1 = (SLAST)adaptor.becomeRoot(UNSET_T229_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_variable_in_expression2812);
                    variable230=variable();

                    state._fsp--;

                    adaptor.addChild(root_1, variable230.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 53 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1423:5: lambda_function_declaration
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_lambda_function_declaration_in_expression2819);
                    lambda_function_declaration231=lambda_function_declaration();

                    state._fsp--;

                    adaptor.addChild(root_0, lambda_function_declaration231.getTree());

                    }
                    break;
                case 54 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1424:5: BACKTRICKLITERAL
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    BACKTRICKLITERAL232=(SLAST)match(input,BACKTRICKLITERAL,FOLLOW_BACKTRICKLITERAL_in_expression2825); 
                    BACKTRICKLITERAL232_tree = (SLAST)adaptor.dupNode(BACKTRICKLITERAL232);

                    adaptor.addChild(root_0, BACKTRICKLITERAL232_tree);


                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);


              if (ast != null) {
                retval.tree = ast;
              }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "expression"

    public static class plus_minus_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "plus_minus"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1428:1: plus_minus : ( PLUS_PLUS_T | MINUS_MINUS_T );
    public final TreePHP.plus_minus_return plus_minus() throws RecognitionException {
        TreePHP.plus_minus_return retval = new TreePHP.plus_minus_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST set233=null;

        SLAST set233_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1429:3: ( PLUS_PLUS_T | MINUS_MINUS_T )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            set233=(SLAST)input.LT(1);
            if ( (input.LA(1)>=PLUS_PLUS_T && input.LA(1)<=MINUS_MINUS_T) ) {
                input.consume();

                set233_tree = (SLAST)adaptor.dupNode(set233);

                adaptor.addChild(root_0, set233_tree);

                state.errorRecovery=false;
            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                throw mse;
            }

             

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "plus_minus"

    public static class cast_option_return extends TreeRuleReturnScope {
        public int castOption;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "cast_option"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1433:1: cast_option returns [int castOption] : ( 'bool' | 'boolean' | 'int' | 'float' | 'double' | 'array' | 'object' | 'real' | 'string' | UNSET_T | CLONE_T );
    public final TreePHP.cast_option_return cast_option() throws RecognitionException {
        TreePHP.cast_option_return retval = new TreePHP.cast_option_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST string_literal234=null;
        SLAST string_literal235=null;
        SLAST string_literal236=null;
        SLAST string_literal237=null;
        SLAST string_literal238=null;
        SLAST string_literal239=null;
        SLAST string_literal240=null;
        SLAST string_literal241=null;
        SLAST string_literal242=null;
        SLAST UNSET_T243=null;
        SLAST CLONE_T244=null;

        SLAST string_literal234_tree=null;
        SLAST string_literal235_tree=null;
        SLAST string_literal236_tree=null;
        SLAST string_literal237_tree=null;
        SLAST string_literal238_tree=null;
        SLAST string_literal239_tree=null;
        SLAST string_literal240_tree=null;
        SLAST string_literal241_tree=null;
        SLAST string_literal242_tree=null;
        SLAST UNSET_T243_tree=null;
        SLAST CLONE_T244_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1434:3: ( 'bool' | 'boolean' | 'int' | 'float' | 'double' | 'array' | 'object' | 'real' | 'string' | UNSET_T | CLONE_T )
            int alt71=11;
            switch ( input.LA(1) ) {
            case 171:
                {
                alt71=1;
                }
                break;
            case 172:
                {
                alt71=2;
                }
                break;
            case 173:
                {
                alt71=3;
                }
                break;
            case 174:
                {
                alt71=4;
                }
                break;
            case 175:
                {
                alt71=5;
                }
                break;
            case 179:
                {
                alt71=6;
                }
                break;
            case 178:
                {
                alt71=7;
                }
                break;
            case 176:
                {
                alt71=8;
                }
                break;
            case 177:
                {
                alt71=9;
                }
                break;
            case UNSET_T:
                {
                alt71=10;
                }
                break;
            case CLONE_T:
                {
                alt71=11;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 71, 0, input);

                throw nvae;
            }

            switch (alt71) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1434:5: 'bool'
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    string_literal234=(SLAST)match(input,171,FOLLOW_171_in_cast_option2864); 
                    string_literal234_tree = (SLAST)adaptor.dupNode(string_literal234);

                    adaptor.addChild(root_0, string_literal234_tree);

                    retval.castOption = 1;

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1435:5: 'boolean'
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    string_literal235=(SLAST)match(input,172,FOLLOW_172_in_cast_option2875); 
                    string_literal235_tree = (SLAST)adaptor.dupNode(string_literal235);

                    adaptor.addChild(root_0, string_literal235_tree);

                    retval.castOption = 2;

                    }
                    break;
                case 3 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1436:5: 'int'
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    string_literal236=(SLAST)match(input,173,FOLLOW_173_in_cast_option2883); 
                    string_literal236_tree = (SLAST)adaptor.dupNode(string_literal236);

                    adaptor.addChild(root_0, string_literal236_tree);

                    retval.castOption = 3;

                    }
                    break;
                case 4 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1437:5: 'float'
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    string_literal237=(SLAST)match(input,174,FOLLOW_174_in_cast_option2895); 
                    string_literal237_tree = (SLAST)adaptor.dupNode(string_literal237);

                    adaptor.addChild(root_0, string_literal237_tree);

                    retval.castOption = 4;

                    }
                    break;
                case 5 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1438:5: 'double'
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    string_literal238=(SLAST)match(input,175,FOLLOW_175_in_cast_option2905); 
                    string_literal238_tree = (SLAST)adaptor.dupNode(string_literal238);

                    adaptor.addChild(root_0, string_literal238_tree);

                    retval.castOption = 5;

                    }
                    break;
                case 6 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1439:5: 'array'
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    string_literal239=(SLAST)match(input,179,FOLLOW_179_in_cast_option2914); 
                    string_literal239_tree = (SLAST)adaptor.dupNode(string_literal239);

                    adaptor.addChild(root_0, string_literal239_tree);

                    retval.castOption = 6;

                    }
                    break;
                case 7 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1440:5: 'object'
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    string_literal240=(SLAST)match(input,178,FOLLOW_178_in_cast_option2924); 
                    string_literal240_tree = (SLAST)adaptor.dupNode(string_literal240);

                    adaptor.addChild(root_0, string_literal240_tree);

                    retval.castOption = 7;

                    }
                    break;
                case 8 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1441:5: 'real'
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    string_literal241=(SLAST)match(input,176,FOLLOW_176_in_cast_option2933); 
                    string_literal241_tree = (SLAST)adaptor.dupNode(string_literal241);

                    adaptor.addChild(root_0, string_literal241_tree);

                    retval.castOption = 8;

                    }
                    break;
                case 9 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1442:5: 'string'
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    string_literal242=(SLAST)match(input,177,FOLLOW_177_in_cast_option2944); 
                    string_literal242_tree = (SLAST)adaptor.dupNode(string_literal242);

                    adaptor.addChild(root_0, string_literal242_tree);

                    retval.castOption = 9;

                    }
                    break;
                case 10 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1443:5: UNSET_T
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    UNSET_T243=(SLAST)match(input,UNSET_T,FOLLOW_UNSET_T_in_cast_option2953); 
                    UNSET_T243_tree = (SLAST)adaptor.dupNode(UNSET_T243);

                    adaptor.addChild(root_0, UNSET_T243_tree);

                    retval.castOption = 10;

                    }
                    break;
                case 11 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1444:5: CLONE_T
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    CLONE_T244=(SLAST)match(input,CLONE_T,FOLLOW_CLONE_T_in_cast_option2963); 
                    CLONE_T244_tree = (SLAST)adaptor.dupNode(CLONE_T244);

                    adaptor.addChild(root_0, CLONE_T244_tree);

                    retval.castOption = 11;

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "cast_option"

    public static class lambda_function_declaration_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "lambda_function_declaration"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1447:1: lambda_function_declaration : ^( METHOD_DECL ( REF_T )? ( parameter_list )? ( ^( USE_T ( expr_list )? ) )? block ) ;
    public final TreePHP.lambda_function_declaration_return lambda_function_declaration() throws RecognitionException {
        TreePHP.lambda_function_declaration_return retval = new TreePHP.lambda_function_declaration_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST METHOD_DECL245=null;
        SLAST REF_T246=null;
        SLAST USE_T248=null;
        TreePHP.parameter_list_return parameter_list247 = null;

        TreePHP.expr_list_return expr_list249 = null;

        TreePHP.block_return block250 = null;


        SLAST METHOD_DECL245_tree=null;
        SLAST REF_T246_tree=null;
        SLAST USE_T248_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1448:3: ( ^( METHOD_DECL ( REF_T )? ( parameter_list )? ( ^( USE_T ( expr_list )? ) )? block ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1448:5: ^( METHOD_DECL ( REF_T )? ( parameter_list )? ( ^( USE_T ( expr_list )? ) )? block )
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_1 = _last;
            SLAST _first_1 = null;
            SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            METHOD_DECL245=(SLAST)match(input,METHOD_DECL,FOLLOW_METHOD_DECL_in_lambda_function_declaration2982); 
            METHOD_DECL245_tree = (SLAST)adaptor.dupNode(METHOD_DECL245);

            root_1 = (SLAST)adaptor.becomeRoot(METHOD_DECL245_tree, root_1);



            match(input, Token.DOWN, null); 
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1448:19: ( REF_T )?
            int alt72=2;
            int LA72_0 = input.LA(1);

            if ( (LA72_0==REF_T) ) {
                alt72=1;
            }
            switch (alt72) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1448:19: REF_T
                    {
                    _last = (SLAST)input.LT(1);
                    REF_T246=(SLAST)match(input,REF_T,FOLLOW_REF_T_in_lambda_function_declaration2984); 
                    REF_T246_tree = (SLAST)adaptor.dupNode(REF_T246);

                    adaptor.addChild(root_1, REF_T246_tree);


                    }
                    break;

            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1448:26: ( parameter_list )?
            int alt73=2;
            int LA73_0 = input.LA(1);

            if ( (LA73_0==PARAMETER) ) {
                alt73=1;
            }
            switch (alt73) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1448:26: parameter_list
                    {
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_parameter_list_in_lambda_function_declaration2987);
                    parameter_list247=parameter_list();

                    state._fsp--;

                    adaptor.addChild(root_1, parameter_list247.getTree());

                    }
                    break;

            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1448:42: ( ^( USE_T ( expr_list )? ) )?
            int alt75=2;
            int LA75_0 = input.LA(1);

            if ( (LA75_0==USE_T) ) {
                alt75=1;
            }
            switch (alt75) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1448:43: ^( USE_T ( expr_list )? )
                    {
                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_2 = _last;
                    SLAST _first_2 = null;
                    SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    USE_T248=(SLAST)match(input,USE_T,FOLLOW_USE_T_in_lambda_function_declaration2992); 
                    USE_T248_tree = (SLAST)adaptor.dupNode(USE_T248);

                    root_2 = (SLAST)adaptor.becomeRoot(USE_T248_tree, root_2);



                    if ( input.LA(1)==Token.DOWN ) {
                        match(input, Token.DOWN, null); 
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1448:51: ( expr_list )?
                        int alt74=2;
                        int LA74_0 = input.LA(1);

                        if ( (LA74_0==METHOD_DECL||LA74_0==VAR_DECL||LA74_0==CALL||LA74_0==EXPR||(LA74_0>=SCALAR && LA74_0<=CAST_EXPR)||LA74_0==REF_T||LA74_0==EQUAL_T||(LA74_0>=OR_T && LA74_0<=EXC_NOT_T)||(LA74_0>=INSTANCEOF_T && LA74_0<=BACKTRICKLITERAL)) ) {
                            alt74=1;
                        }
                        switch (alt74) {
                            case 1 :
                                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1448:51: expr_list
                                {
                                _last = (SLAST)input.LT(1);
                                pushFollow(FOLLOW_expr_list_in_lambda_function_declaration2994);
                                expr_list249=expr_list();

                                state._fsp--;

                                adaptor.addChild(root_2, expr_list249.getTree());

                                }
                                break;

                        }


                        match(input, Token.UP, null); 
                    }adaptor.addChild(root_1, root_2);_last = _save_last_2;
                    }


                    }
                    break;

            }

            _last = (SLAST)input.LT(1);
            pushFollow(FOLLOW_block_in_lambda_function_declaration3006);
            block250=block();

            state._fsp--;

            adaptor.addChild(root_1, block250.getTree());

            match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "lambda_function_declaration"

    protected static class class_name_reference_scope {
        List list;
        List argList;
    }
    protected Stack class_name_reference_stack = new Stack();

    public static class class_name_reference_return extends TreeRuleReturnScope {
        public Expression var;
        public Expression expr;
        public PHPCallArgumentsList parameterList;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "class_name_reference"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1452:1: class_name_reference returns [Expression var, Expression expr, PHPCallArgumentsList parameterList] : ( dynamic_name_reference | fully_qualified_class_name );
    public final TreePHP.class_name_reference_return class_name_reference() throws RecognitionException {
        class_name_reference_stack.push(new class_name_reference_scope());
        TreePHP.class_name_reference_return retval = new TreePHP.class_name_reference_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.dynamic_name_reference_return dynamic_name_reference251 = null;

        TreePHP.fully_qualified_class_name_return fully_qualified_class_name252 = null;




          ((class_name_reference_scope)class_name_reference_stack.peek()).list = new LinkedList();
          ((class_name_reference_scope)class_name_reference_stack.peek()).argList = new LinkedList();

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1461:3: ( dynamic_name_reference | fully_qualified_class_name )
            int alt76=2;
            int LA76_0 = input.LA(1);

            if ( (LA76_0==VAR_DECL||LA76_0==CALL) ) {
                alt76=1;
            }
            else if ( (LA76_0==IDENTIFIER||LA76_0==DOMAIN_T) ) {
                alt76=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 76, 0, input);

                throw nvae;
            }
            switch (alt76) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1461:5: dynamic_name_reference
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_dynamic_name_reference_in_class_name_reference3039);
                    dynamic_name_reference251=dynamic_name_reference();

                    state._fsp--;

                    adaptor.addChild(root_0, dynamic_name_reference251.getTree());

                        retval.var = (dynamic_name_reference251!=null?dynamic_name_reference251.var:null);
                        retval.parameterList = (dynamic_name_reference251!=null?dynamic_name_reference251.parameterList:null);
                        retval.expr = (dynamic_name_reference251!=null?dynamic_name_reference251.expr:null);
                        
                        Expression dispatcher = retval.var;
                        Iterator iter = ((class_name_reference_scope)class_name_reference_stack.peek()).list.iterator();
                        while (iter.hasNext()) {
                          Expression property = (Expression)iter.next();
                          dispatcher = createDispatch(dispatcher, property);
                        }
                        retval.var = dispatcher;
                      

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1475:5: fully_qualified_class_name
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_fully_qualified_class_name_in_class_name_reference3050);
                    fully_qualified_class_name252=fully_qualified_class_name();

                    state._fsp--;

                    adaptor.addChild(root_0, fully_qualified_class_name252.getTree());

                        retval.var = (fully_qualified_class_name252!=null?fully_qualified_class_name252.type:null);
                      

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
            class_name_reference_stack.pop();
        }
        return retval;
    }
    // $ANTLR end "class_name_reference"

    public static class dynamic_name_reference_return extends TreeRuleReturnScope {
        public Expression var;
        public PHPCallArgumentsList parameterList;
        public Expression expr;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "dynamic_name_reference"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1481:1: dynamic_name_reference returns [Expression var, PHPCallArgumentsList parameterList, Expression expr] : ( base_variable_with_function_calls | ^( CALL v1= dynamic_name_reference obj= object_property ( ctor_arguments )? ) );
    public final TreePHP.dynamic_name_reference_return dynamic_name_reference() throws RecognitionException {
        TreePHP.dynamic_name_reference_return retval = new TreePHP.dynamic_name_reference_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST CALL254=null;
        TreePHP.dynamic_name_reference_return v1 = null;

        TreePHP.object_property_return obj = null;

        TreePHP.base_variable_with_function_calls_return base_variable_with_function_calls253 = null;

        TreePHP.ctor_arguments_return ctor_arguments255 = null;


        SLAST CALL254_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1482:3: ( base_variable_with_function_calls | ^( CALL v1= dynamic_name_reference obj= object_property ( ctor_arguments )? ) )
            int alt78=2;
            int LA78_0 = input.LA(1);

            if ( (LA78_0==VAR_DECL) ) {
                alt78=1;
            }
            else if ( (LA78_0==CALL) ) {
                int LA78_2 = input.LA(2);

                if ( (LA78_2==DOWN) ) {
                    int LA78_3 = input.LA(3);

                    if ( (LA78_3==VAR_DECL||LA78_3==CALL) ) {
                        alt78=2;
                    }
                    else if ( (LA78_3==IDENTIFIER||LA78_3==DOMAIN_T) ) {
                        alt78=1;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 78, 3, input);

                        throw nvae;
                    }
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 78, 2, input);

                    throw nvae;
                }
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 78, 0, input);

                throw nvae;
            }
            switch (alt78) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1482:5: base_variable_with_function_calls
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_base_variable_with_function_calls_in_dynamic_name_reference3073);
                    base_variable_with_function_calls253=base_variable_with_function_calls();

                    state._fsp--;

                    adaptor.addChild(root_0, base_variable_with_function_calls253.getTree());

                         retval.expr = (base_variable_with_function_calls253!=null?base_variable_with_function_calls253.var:null);
                         retval.var = (base_variable_with_function_calls253!=null?base_variable_with_function_calls253.var:null);
                         retval.parameterList = (base_variable_with_function_calls253!=null?base_variable_with_function_calls253.parameterList:null);
                      

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1488:5: ^( CALL v1= dynamic_name_reference obj= object_property ( ctor_arguments )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    CALL254=(SLAST)match(input,CALL,FOLLOW_CALL_in_dynamic_name_reference3085); 
                    CALL254_tree = (SLAST)adaptor.dupNode(CALL254);

                    root_1 = (SLAST)adaptor.becomeRoot(CALL254_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_dynamic_name_reference_in_dynamic_name_reference3089);
                    v1=dynamic_name_reference();

                    state._fsp--;

                    adaptor.addChild(root_1, v1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_object_property_in_dynamic_name_reference3093);
                    obj=object_property();

                    state._fsp--;

                    adaptor.addChild(root_1, obj.getTree());
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1488:58: ( ctor_arguments )?
                    int alt77=2;
                    int LA77_0 = input.LA(1);

                    if ( (LA77_0==ARGU) ) {
                        alt77=1;
                    }
                    switch (alt77) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1488:58: ctor_arguments
                            {
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_ctor_arguments_in_dynamic_name_reference3095);
                            ctor_arguments255=ctor_arguments();

                            state._fsp--;

                            adaptor.addChild(root_1, ctor_arguments255.getTree());

                            }
                            break;

                    }


                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                          retval.var = (v1!=null?v1.expr:null);
                          retval.expr = (v1!=null?v1.var:null);
                          
                          ((class_name_reference_scope)class_name_reference_stack.peek()).list.add((obj!=null?obj.expr:null));
                          
                          System.out.println("ctor:");
                          if ((ctor_arguments255!=null?ctor_arguments255.argumentList:null) != null) {
                            retval.parameterList = (ctor_arguments255!=null?ctor_arguments255.argumentList:null);
                          }
                          else if ((v1!=null?v1.parameterList:null) != null) {
                            retval.parameterList = (ctor_arguments255!=null?ctor_arguments255.argumentList:null);
                          }
                      

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "dynamic_name_reference"

    public static class list_decl_return extends TreeRuleReturnScope {
        public Expression expr;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "list_decl"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1505:1: list_decl returns [Expression expr] : ^( LIST_T ( assignment_list )? ) ;
    public final TreePHP.list_decl_return list_decl() throws RecognitionException {
        TreePHP.list_decl_return retval = new TreePHP.list_decl_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST LIST_T256=null;
        TreePHP.assignment_list_return assignment_list257 = null;


        SLAST LIST_T256_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1506:3: ( ^( LIST_T ( assignment_list )? ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1506:5: ^( LIST_T ( assignment_list )? )
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_1 = _last;
            SLAST _first_1 = null;
            SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            LIST_T256=(SLAST)match(input,LIST_T,FOLLOW_LIST_T_in_list_decl3119); 
            LIST_T256_tree = (SLAST)adaptor.dupNode(LIST_T256);

            root_1 = (SLAST)adaptor.becomeRoot(LIST_T256_tree, root_1);



            if ( input.LA(1)==Token.DOWN ) {
                match(input, Token.DOWN, null); 
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1506:14: ( assignment_list )?
                int alt79=2;
                int LA79_0 = input.LA(1);

                if ( (LA79_0==VAR_DECL||LA79_0==CALL||LA79_0==LIST_T) ) {
                    alt79=1;
                }
                switch (alt79) {
                    case 1 :
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1506:14: assignment_list
                        {
                        _last = (SLAST)input.LT(1);
                        pushFollow(FOLLOW_assignment_list_in_list_decl3121);
                        assignment_list257=assignment_list();

                        state._fsp--;

                        adaptor.addChild(root_1, assignment_list257.getTree());

                        }
                        break;

                }


                match(input, Token.UP, null); 
            }adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


                int startIndex = (LIST_T256).startIndex;
                int endIndex = LIST_T256.endIndex;
                retval.expr = new ListVariable(startIndex, endIndex, (assignment_list257!=null?assignment_list257.assignList:null));
                System.out.println("list var: " + retval.expr);
              

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "list_decl"

    protected static class assignment_list_scope {
        List list;
    }
    protected Stack assignment_list_stack = new Stack();

    public static class assignment_list_return extends TreeRuleReturnScope {
        public List assignList;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "assignment_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1515:1: assignment_list returns [List assignList] : ( assignment_element )+ ;
    public final TreePHP.assignment_list_return assignment_list() throws RecognitionException {
        assignment_list_stack.push(new assignment_list_scope());
        TreePHP.assignment_list_return retval = new TreePHP.assignment_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.assignment_element_return assignment_element258 = null;




          ((assignment_list_scope)assignment_list_stack.peek()).list = new LinkedList();

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1522:3: ( ( assignment_element )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1522:5: ( assignment_element )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1522:5: ( assignment_element )+
            int cnt80=0;
            loop80:
            do {
                int alt80=2;
                int LA80_0 = input.LA(1);

                if ( (LA80_0==VAR_DECL||LA80_0==CALL||LA80_0==LIST_T) ) {
                    alt80=1;
                }


                switch (alt80) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1522:5: assignment_element
            	    {
            	    _last = (SLAST)input.LT(1);
            	    pushFollow(FOLLOW_assignment_element_in_assignment_list3153);
            	    assignment_element258=assignment_element();

            	    state._fsp--;

            	    adaptor.addChild(root_0, assignment_element258.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt80 >= 1 ) break loop80;
                        EarlyExitException eee =
                            new EarlyExitException(80, input);
                        throw eee;
                }
                cnt80++;
            } while (true);


                retval.assignList = ((assignment_list_scope)assignment_list_stack.peek()).list;
              

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
            assignment_list_stack.pop();
        }
        return retval;
    }
    // $ANTLR end "assignment_list"

    public static class assignment_element_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "assignment_element"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1528:1: assignment_element : ( variable | list_decl );
    public final TreePHP.assignment_element_return assignment_element() throws RecognitionException {
        TreePHP.assignment_element_return retval = new TreePHP.assignment_element_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.variable_return variable259 = null;

        TreePHP.list_decl_return list_decl260 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1529:3: ( variable | list_decl )
            int alt81=2;
            int LA81_0 = input.LA(1);

            if ( (LA81_0==VAR_DECL||LA81_0==CALL) ) {
                alt81=1;
            }
            else if ( (LA81_0==LIST_T) ) {
                alt81=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 81, 0, input);

                throw nvae;
            }
            switch (alt81) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1529:5: variable
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_variable_in_assignment_element3171);
                    variable259=variable();

                    state._fsp--;

                    adaptor.addChild(root_0, variable259.getTree());

                        System.out.println("var: " + (variable259!=null?variable259.var:null));
                        ((assignment_list_scope)assignment_list_stack.peek()).list.add((variable259!=null?variable259.var:null));
                      

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1534:5: list_decl
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_list_decl_in_assignment_element3181);
                    list_decl260=list_decl();

                    state._fsp--;

                    adaptor.addChild(root_0, list_decl260.getTree());

                        ((assignment_list_scope)assignment_list_stack.peek()).list.add((list_decl260!=null?list_decl260.expr:null));
                      

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "assignment_element"

    protected static class array_pair_list_scope {
        List list;
    }
    protected Stack array_pair_list_stack = new Stack();

    public static class array_pair_list_return extends TreeRuleReturnScope {
        public List arrayList;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "array_pair_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1540:1: array_pair_list returns [List arrayList] : ( array_pair_element )+ ;
    public final TreePHP.array_pair_list_return array_pair_list() throws RecognitionException {
        array_pair_list_stack.push(new array_pair_list_scope());
        TreePHP.array_pair_list_return retval = new TreePHP.array_pair_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.array_pair_element_return array_pair_element261 = null;




          ((array_pair_list_scope)array_pair_list_stack.peek()).list = new LinkedList();

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1547:3: ( ( array_pair_element )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1547:5: ( array_pair_element )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1547:5: ( array_pair_element )+
            int cnt82=0;
            loop82:
            do {
                int alt82=2;
                int LA82_0 = input.LA(1);

                if ( (LA82_0==METHOD_DECL||LA82_0==VAR_DECL||LA82_0==CALL||LA82_0==EXPR||(LA82_0>=SCALAR && LA82_0<=CAST_EXPR)||LA82_0==REF_T||LA82_0==ARROW_T||LA82_0==EQUAL_T||(LA82_0>=OR_T && LA82_0<=EXC_NOT_T)||(LA82_0>=INSTANCEOF_T && LA82_0<=BACKTRICKLITERAL)) ) {
                    alt82=1;
                }


                switch (alt82) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1547:5: array_pair_element
            	    {
            	    _last = (SLAST)input.LT(1);
            	    pushFollow(FOLLOW_array_pair_element_in_array_pair_list3213);
            	    array_pair_element261=array_pair_element();

            	    state._fsp--;

            	    adaptor.addChild(root_0, array_pair_element261.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt82 >= 1 ) break loop82;
                        EarlyExitException eee =
                            new EarlyExitException(82, input);
                        throw eee;
                }
                cnt82++;
            } while (true);


                retval.arrayList = ((array_pair_list_scope)array_pair_list_stack.peek()).list;
              

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
            array_pair_list_stack.pop();
        }
        return retval;
    }
    // $ANTLR end "array_pair_list"

    public static class array_pair_element_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "array_pair_element"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1553:1: array_pair_element : ( ^( ARROW_T e1= expression e2= expression ) | expression );
    public final TreePHP.array_pair_element_return array_pair_element() throws RecognitionException {
        TreePHP.array_pair_element_return retval = new TreePHP.array_pair_element_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST ARROW_T262=null;
        TreePHP.expression_return e1 = null;

        TreePHP.expression_return e2 = null;

        TreePHP.expression_return expression263 = null;


        SLAST ARROW_T262_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1554:3: ( ^( ARROW_T e1= expression e2= expression ) | expression )
            int alt83=2;
            int LA83_0 = input.LA(1);

            if ( (LA83_0==ARROW_T) ) {
                alt83=1;
            }
            else if ( (LA83_0==METHOD_DECL||LA83_0==VAR_DECL||LA83_0==CALL||LA83_0==EXPR||(LA83_0>=SCALAR && LA83_0<=CAST_EXPR)||LA83_0==REF_T||LA83_0==EQUAL_T||(LA83_0>=OR_T && LA83_0<=EXC_NOT_T)||(LA83_0>=INSTANCEOF_T && LA83_0<=BACKTRICKLITERAL)) ) {
                alt83=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 83, 0, input);

                throw nvae;
            }
            switch (alt83) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1554:5: ^( ARROW_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    ARROW_T262=(SLAST)match(input,ARROW_T,FOLLOW_ARROW_T_in_array_pair_element3234); 
                    ARROW_T262_tree = (SLAST)adaptor.dupNode(ARROW_T262);

                    root_1 = (SLAST)adaptor.becomeRoot(ARROW_T262_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_array_pair_element3238);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_array_pair_element3242);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = ((CommonToken)(e1!=null?((SLAST)e1.tree):null).token).getStartIndex();
                        int endIndex = ((CommonToken)(e2!=null?((SLAST)e2.tree):null).token).getStopIndex() + 1;
                        Expression key = (e1!=null?e1.expr:null);
                        Expression value = (e2!=null?e2.expr:null); 
                        ArrayElement element = new ArrayElement(startIndex, endIndex, key, value);
                        ((array_pair_list_scope)array_pair_list_stack.peek()).list.add(element);
                      

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1563:5: expression
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_array_pair_element3253);
                    expression263=expression();

                    state._fsp--;

                    adaptor.addChild(root_0, expression263.getTree());

                        int startIndex = ((CommonToken)(expression263!=null?((SLAST)expression263.tree):null).token).getStartIndex();
                        int endIndex = ((CommonToken)(expression263!=null?((SLAST)expression263.tree):null).token).getStopIndex() + 1;
                        Expression expr = (expression263!=null?expression263.expr:null);
                        ArrayElement element = new ArrayElement(startIndex, endIndex, expr);
                        ((array_pair_list_scope)array_pair_list_stack.peek()).list.add(element);
                      

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "array_pair_element"

    protected static class variable_scope {
        List list;
    }
    protected Stack variable_stack = new Stack();

    public static class variable_return extends TreeRuleReturnScope {
        public Expression expr;
        public Expression var;
        public PHPCallArgumentsList parameterList;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "variable"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1573:1: variable returns [Expression expr, Expression var, PHPCallArgumentsList parameterList] : variable_temp ;
    public final TreePHP.variable_return variable() throws RecognitionException {
        variable_stack.push(new variable_scope());
        TreePHP.variable_return retval = new TreePHP.variable_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.variable_temp_return variable_temp264 = null;




          ((variable_scope)variable_stack.peek()).list = new LinkedList();

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1580:3: ( variable_temp )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1580:5: variable_temp
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            pushFollow(FOLLOW_variable_temp_in_variable3288);
            variable_temp264=variable_temp();

            state._fsp--;

            adaptor.addChild(root_0, variable_temp264.getTree());

            //    retval.var = (variable_temp264!=null?variable_temp264.var:null);
            //    SimpleReference ref = new SimpleReference(99, 99, "ok");
            //    
            //    Expression var = (variable_temp264!=null?variable_temp264.expr:null);
            //    Expression memberProperty = (Expression)ref;
            //    
            //    PHPCallArgumentsList paramsList = new PHPCallArgumentsList();
            //    if ((variable_temp264!=null?variable_temp264.parameterList:null) != null) {
            //       paramsList = (variable_temp264!=null?variable_temp264.parameterList:null);
            //    }
            //    
            //    Iterator iter = ((variable_scope)variable_stack.peek()).list.iterator();
            //    while (iter.hasNext()) {
            //       Expression firstVarProperty = (Expression)iter.next();
            //	     if (paramsList == null) {
            //	        firstVarProperty = ref;
            //	     } else {
            //	       if (memberProperty.getClass().equals(SimpleReference.class)) {
            //	          firstVarProperty = new PHPCallExpression(99, 999, null, (SimpleReference)memberProperty, paramsList);
            //	       } else {
            //	          firstVarProperty = new ReflectionCallExpression(99, 999, null, memberProperty, paramsList);
            //	       }
            //	     }
            //	     iter.next();
            //    }
                
                Iterator iter = ((variable_scope)variable_stack.peek()).list.iterator();
                Expression dispatcher = (variable_temp264!=null?variable_temp264.var:null);
                iter = ((variable_scope)variable_stack.peek()).list.iterator();
                while (iter.hasNext()) {
                  Expression property = (Expression)iter.next();
                  dispatcher = createDispatch(dispatcher, property);
                }
                retval.expr = dispatcher;
                retval.var = dispatcher;
                System.out.println(retval.expr);
                if (inVarList) {
                  ((variable_list_scope)variable_list_stack.peek()).varList.add(retval.var);
                }
              

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
            variable_stack.pop();
        }
        return retval;
    }
    // $ANTLR end "variable"

    public static class variable_temp_return extends TreeRuleReturnScope {
        public Expression expr;
        public Expression var;
        public PHPCallArgumentsList parameterList;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "variable_temp"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1625:1: variable_temp returns [Expression expr, Expression var, PHPCallArgumentsList parameterList] : ( base_variable_with_function_calls | ^( CALL v1= variable_temp obj= object_property ( ctor_arguments )? ) );
    public final TreePHP.variable_temp_return variable_temp() throws RecognitionException {
        TreePHP.variable_temp_return retval = new TreePHP.variable_temp_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST CALL266=null;
        TreePHP.variable_temp_return v1 = null;

        TreePHP.object_property_return obj = null;

        TreePHP.base_variable_with_function_calls_return base_variable_with_function_calls265 = null;

        TreePHP.ctor_arguments_return ctor_arguments267 = null;


        SLAST CALL266_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1626:3: ( base_variable_with_function_calls | ^( CALL v1= variable_temp obj= object_property ( ctor_arguments )? ) )
            int alt85=2;
            int LA85_0 = input.LA(1);

            if ( (LA85_0==VAR_DECL) ) {
                alt85=1;
            }
            else if ( (LA85_0==CALL) ) {
                int LA85_2 = input.LA(2);

                if ( (LA85_2==DOWN) ) {
                    int LA85_3 = input.LA(3);

                    if ( (LA85_3==VAR_DECL||LA85_3==CALL) ) {
                        alt85=2;
                    }
                    else if ( (LA85_3==IDENTIFIER||LA85_3==DOMAIN_T) ) {
                        alt85=1;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 85, 3, input);

                        throw nvae;
                    }
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 85, 2, input);

                    throw nvae;
                }
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 85, 0, input);

                throw nvae;
            }
            switch (alt85) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1626:5: base_variable_with_function_calls
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_base_variable_with_function_calls_in_variable_temp3312);
                    base_variable_with_function_calls265=base_variable_with_function_calls();

                    state._fsp--;

                    adaptor.addChild(root_0, base_variable_with_function_calls265.getTree());

                         retval.expr = (base_variable_with_function_calls265!=null?base_variable_with_function_calls265.expr:null);
                         retval.var = (base_variable_with_function_calls265!=null?base_variable_with_function_calls265.var:null);
                         
                         retval.parameterList = (base_variable_with_function_calls265!=null?base_variable_with_function_calls265.parameterList:null);
                      

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1633:5: ^( CALL v1= variable_temp obj= object_property ( ctor_arguments )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    CALL266=(SLAST)match(input,CALL,FOLLOW_CALL_in_variable_temp3324); 
                    CALL266_tree = (SLAST)adaptor.dupNode(CALL266);

                    root_1 = (SLAST)adaptor.becomeRoot(CALL266_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_variable_temp_in_variable_temp3328);
                    v1=variable_temp();

                    state._fsp--;

                    adaptor.addChild(root_1, v1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_object_property_in_variable_temp3332);
                    obj=object_property();

                    state._fsp--;

                    adaptor.addChild(root_1, obj.getTree());
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1633:49: ( ctor_arguments )?
                    int alt84=2;
                    int LA84_0 = input.LA(1);

                    if ( (LA84_0==ARGU) ) {
                        alt84=1;
                    }
                    switch (alt84) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1633:49: ctor_arguments
                            {
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_ctor_arguments_in_variable_temp3334);
                            ctor_arguments267=ctor_arguments();

                            state._fsp--;

                            adaptor.addChild(root_1, ctor_arguments267.getTree());

                            }
                            break;

                    }


                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                          retval.var = (v1!=null?v1.var:null);
                          retval.expr = (v1!=null?v1.expr:null);
                          
                    //      System.out.println("$$retval.var: " + retval.var);
                          int objLeft = ((CommonToken)(obj!=null?((SLAST)obj.tree):null).token).getStartIndex();
                          int objRight = ((CommonToken)(obj!=null?((SLAST)obj.tree):null).token).getStopIndex() + 1;

                          Expression firstVarProperty = null;
                          if ((ctor_arguments267!=null?ctor_arguments267.argumentList:null) == null) {
                            firstVarProperty = (obj!=null?obj.expr:null);
                          }
                          else {
                            int paramListLeft = ((CommonToken)(ctor_arguments267!=null?((SLAST)ctor_arguments267.tree):null).token).getStartIndex();
                            int paramListRight = ((CommonToken)(ctor_arguments267!=null?((SLAST)ctor_arguments267.tree):null).token).getStopIndex() + 1;
                            if ((obj!=null?obj.simpleRef:null).getClass().equals(SimpleReference.class)) {
                    		      firstVarProperty = new PHPCallExpression(objLeft, paramListRight, null, (obj!=null?obj.simpleRef:null), (ctor_arguments267!=null?ctor_arguments267.argumentList:null));
                    		    } else {
                    		      firstVarProperty = new ReflectionCallExpression(objLeft, paramListRight, null, (SimpleReference)(obj!=null?obj.simpleRef:null), (ctor_arguments267!=null?ctor_arguments267.argumentList:null));
                    		    }
                          }
                          
                          ((variable_scope)variable_stack.peek()).list.add(firstVarProperty);
                      

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "variable_temp"

    public static class base_variable_with_function_calls_return extends TreeRuleReturnScope {
        public Expression expr;
        public Expression var;
        public PHPCallArgumentsList parameterList;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "base_variable_with_function_calls"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1660:1: base_variable_with_function_calls returns [Expression expr, Expression var, PHPCallArgumentsList parameterList] : ( ^( VAR_DECL ( fully_qualified_class_name )? obj= object_property ( ctor_arguments )? ) | ^( CALL fully_qualified_class_name ctor_arguments ) );
    public final TreePHP.base_variable_with_function_calls_return base_variable_with_function_calls() throws RecognitionException {
        TreePHP.base_variable_with_function_calls_return retval = new TreePHP.base_variable_with_function_calls_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST VAR_DECL268=null;
        SLAST CALL271=null;
        TreePHP.object_property_return obj = null;

        TreePHP.fully_qualified_class_name_return fully_qualified_class_name269 = null;

        TreePHP.ctor_arguments_return ctor_arguments270 = null;

        TreePHP.fully_qualified_class_name_return fully_qualified_class_name272 = null;

        TreePHP.ctor_arguments_return ctor_arguments273 = null;


        SLAST VAR_DECL268_tree=null;
        SLAST CALL271_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1661:3: ( ^( VAR_DECL ( fully_qualified_class_name )? obj= object_property ( ctor_arguments )? ) | ^( CALL fully_qualified_class_name ctor_arguments ) )
            int alt88=2;
            int LA88_0 = input.LA(1);

            if ( (LA88_0==VAR_DECL) ) {
                alt88=1;
            }
            else if ( (LA88_0==CALL) ) {
                alt88=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 88, 0, input);

                throw nvae;
            }
            switch (alt88) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1661:5: ^( VAR_DECL ( fully_qualified_class_name )? obj= object_property ( ctor_arguments )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    VAR_DECL268=(SLAST)match(input,VAR_DECL,FOLLOW_VAR_DECL_in_base_variable_with_function_calls3360); 
                    VAR_DECL268_tree = (SLAST)adaptor.dupNode(VAR_DECL268);

                    root_1 = (SLAST)adaptor.becomeRoot(VAR_DECL268_tree, root_1);



                    match(input, Token.DOWN, null); 
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1661:16: ( fully_qualified_class_name )?
                    int alt86=2;
                    int LA86_0 = input.LA(1);

                    if ( (LA86_0==IDENTIFIER||LA86_0==DOMAIN_T) ) {
                        alt86=1;
                    }
                    switch (alt86) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1661:16: fully_qualified_class_name
                            {
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_fully_qualified_class_name_in_base_variable_with_function_calls3362);
                            fully_qualified_class_name269=fully_qualified_class_name();

                            state._fsp--;

                            adaptor.addChild(root_1, fully_qualified_class_name269.getTree());

                            }
                            break;

                    }

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_object_property_in_base_variable_with_function_calls3367);
                    obj=object_property();

                    state._fsp--;

                    adaptor.addChild(root_1, obj.getTree());
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1661:64: ( ctor_arguments )?
                    int alt87=2;
                    int LA87_0 = input.LA(1);

                    if ( (LA87_0==ARGU) ) {
                        alt87=1;
                    }
                    switch (alt87) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1661:64: ctor_arguments
                            {
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_ctor_arguments_in_base_variable_with_function_calls3369);
                            ctor_arguments270=ctor_arguments();

                            state._fsp--;

                            adaptor.addChild(root_1, ctor_arguments270.getTree());

                            }
                            break;

                    }


                        int startIndex = VAR_DECL268.startIndex;
                        int endIndex = ((CommonToken)(obj!=null?((SLAST)obj.tree):null).token).getStopIndex() + 1;
                        retval.var = (obj!=null?obj.expr:null);
                        if ((fully_qualified_class_name269!=null?fully_qualified_class_name269.type:null) != null) {
                            retval.var = new StaticFieldAccess(startIndex, endIndex, (fully_qualified_class_name269!=null?fully_qualified_class_name269.type:null), (obj!=null?obj.expr:null));
                        }
                        
                        retval.expr = retval.var;
                      
                        if ((ctor_arguments270!=null?ctor_arguments270.argumentList:null) != null) {
                          PHPCallArgumentsList parameters = (ctor_arguments270!=null?ctor_arguments270.argumentList:null);
                      //    parameters.addNode(retval.var);
                          retval.parameterList = parameters;
                          retval.var = new ReflectionCallExpression(startIndex, endIndex, null, (obj!=null?obj.expr:null), parameters); 
                          System.out.println("var:" + retval.var);
                        }
                        else {
                          retval.parameterList = new PHPCallArgumentsList();
                        }
                      

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1684:5: ^( CALL fully_qualified_class_name ctor_arguments )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    CALL271=(SLAST)match(input,CALL,FOLLOW_CALL_in_base_variable_with_function_calls3390); 
                    CALL271_tree = (SLAST)adaptor.dupNode(CALL271);

                    root_1 = (SLAST)adaptor.becomeRoot(CALL271_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_fully_qualified_class_name_in_base_variable_with_function_calls3392);
                    fully_qualified_class_name272=fully_qualified_class_name();

                    state._fsp--;

                    adaptor.addChild(root_1, fully_qualified_class_name272.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_ctor_arguments_in_base_variable_with_function_calls3394);
                    ctor_arguments273=ctor_arguments();

                    state._fsp--;

                    adaptor.addChild(root_1, ctor_arguments273.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = CALL271.startIndex;
                        int endIndex = CALL271.endIndex + 1;
                        int functionNameLeft= ((CommonToken)(fully_qualified_class_name272!=null?((SLAST)fully_qualified_class_name272.tree):null).token).getStartIndex();
                        int functionNameRight= ((CommonToken)(fully_qualified_class_name272!=null?((SLAST)fully_qualified_class_name272.tree):null).token).getStopIndex() + 1;
                        String functionName = (fully_qualified_class_name272!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(fully_qualified_class_name272.start),
                      input.getTreeAdaptor().getTokenStopIndex(fully_qualified_class_name272.start))):null);
                        PHPCallArgumentsList parameters = (ctor_arguments273!=null?ctor_arguments273.argumentList:null);
                        SimpleReference name = new SimpleReference(functionNameLeft, functionNameRight, functionName);
                        retval.var = new PHPCallExpression(startIndex, endIndex, null, name, parameters);
                    //    retval.var = (Expression)(fully_qualified_class_name272!=null?fully_qualified_class_name272.type:null);
                        retval.parameterList = parameters;
                      

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "base_variable_with_function_calls"

    public static class object_property_return extends TreeRuleReturnScope {
        public String str;
        public Expression expr;
        public SimpleReference simpleRef;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "object_property"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1701:1: object_property returns [String str, Expression expr, SimpleReference simpleRef] : ( ^( VAR ( DOLLAR_T )* IDENTIFIER ) | ^( VAR ( DOLLAR_T )* expression ) | ^( INDEX obj= object_property ( expression )? ) | ^( HASH_INDEX obj= object_property ( expression )? ) );
    public final TreePHP.object_property_return object_property() throws RecognitionException {
        TreePHP.object_property_return retval = new TreePHP.object_property_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST VAR274=null;
        SLAST DOLLAR_T275=null;
        SLAST IDENTIFIER276=null;
        SLAST VAR277=null;
        SLAST DOLLAR_T278=null;
        SLAST INDEX280=null;
        SLAST HASH_INDEX282=null;
        TreePHP.object_property_return obj = null;

        TreePHP.expression_return expression279 = null;

        TreePHP.expression_return expression281 = null;

        TreePHP.expression_return expression283 = null;


        SLAST VAR274_tree=null;
        SLAST DOLLAR_T275_tree=null;
        SLAST IDENTIFIER276_tree=null;
        SLAST VAR277_tree=null;
        SLAST DOLLAR_T278_tree=null;
        SLAST INDEX280_tree=null;
        SLAST HASH_INDEX282_tree=null;


          SLAST ast = null;
          int startIndex = -1;
          int endIndex = -1;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1713:3: ( ^( VAR ( DOLLAR_T )* IDENTIFIER ) | ^( VAR ( DOLLAR_T )* expression ) | ^( INDEX obj= object_property ( expression )? ) | ^( HASH_INDEX obj= object_property ( expression )? ) )
            int alt93=4;
            alt93 = dfa93.predict(input);
            switch (alt93) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1713:5: ^( VAR ( DOLLAR_T )* IDENTIFIER )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    VAR274=(SLAST)match(input,VAR,FOLLOW_VAR_in_object_property3433); 
                    VAR274_tree = (SLAST)adaptor.dupNode(VAR274);

                    root_1 = (SLAST)adaptor.becomeRoot(VAR274_tree, root_1);



                    match(input, Token.DOWN, null); 
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1713:11: ( DOLLAR_T )*
                    loop89:
                    do {
                        int alt89=2;
                        int LA89_0 = input.LA(1);

                        if ( (LA89_0==DOLLAR_T) ) {
                            alt89=1;
                        }


                        switch (alt89) {
                    	case 1 :
                    	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1713:11: DOLLAR_T
                    	    {
                    	    _last = (SLAST)input.LT(1);
                    	    DOLLAR_T275=(SLAST)match(input,DOLLAR_T,FOLLOW_DOLLAR_T_in_object_property3435); 
                    	    DOLLAR_T275_tree = (SLAST)adaptor.dupNode(DOLLAR_T275);

                    	    adaptor.addChild(root_1, DOLLAR_T275_tree);


                    	    }
                    	    break;

                    	default :
                    	    break loop89;
                        }
                    } while (true);

                    _last = (SLAST)input.LT(1);
                    IDENTIFIER276=(SLAST)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_object_property3438); 
                    IDENTIFIER276_tree = (SLAST)adaptor.dupNode(IDENTIFIER276);

                    adaptor.addChild(root_1, IDENTIFIER276_tree);


                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                            retval.str = (IDENTIFIER276!=null?IDENTIFIER276.getText():null);
                            startIndex = ((CommonToken)IDENTIFIER276.token).getStartIndex();
                            endIndex = ((CommonToken)IDENTIFIER276.token).getStopIndex() + 1;
                            if ((DOLLAR_T275!=null?DOLLAR_T275.getText():null) != null) {
                                retval.str = (DOLLAR_T275!=null?DOLLAR_T275.getText():null) + (IDENTIFIER276!=null?IDENTIFIER276.getText():null);
                                startIndex = ((CommonToken)DOLLAR_T275.token).getStartIndex();
                            }
                            VariableReference variableRef = new VariableReference(startIndex, endIndex, retval.str ,PHPVariableKind.LOCAL);
                            retval.expr = variableRef;
                            
                            retval.simpleRef = new SimpleReference(startIndex, endIndex, retval.str);
                            ast = VAR274_tree;
                    //        (((SLAST)retval.tree).token).setStartIndex(startInndex);
                        

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1729:5: ^( VAR ( DOLLAR_T )* expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    VAR277=(SLAST)match(input,VAR,FOLLOW_VAR_in_object_property3452); 
                    VAR277_tree = (SLAST)adaptor.dupNode(VAR277);

                    root_1 = (SLAST)adaptor.becomeRoot(VAR277_tree, root_1);



                    match(input, Token.DOWN, null); 
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1729:11: ( DOLLAR_T )*
                    loop90:
                    do {
                        int alt90=2;
                        int LA90_0 = input.LA(1);

                        if ( (LA90_0==DOLLAR_T) ) {
                            alt90=1;
                        }


                        switch (alt90) {
                    	case 1 :
                    	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1729:11: DOLLAR_T
                    	    {
                    	    _last = (SLAST)input.LT(1);
                    	    DOLLAR_T278=(SLAST)match(input,DOLLAR_T,FOLLOW_DOLLAR_T_in_object_property3454); 
                    	    DOLLAR_T278_tree = (SLAST)adaptor.dupNode(DOLLAR_T278);

                    	    adaptor.addChild(root_1, DOLLAR_T278_tree);


                    	    }
                    	    break;

                    	default :
                    	    break loop90;
                        }
                    } while (true);

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_object_property3457);
                    expression279=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression279.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        startIndex = VAR277.startIndex;
                        endIndex = VAR277.endIndex + 1;
                        retval.expr = new ReflectionVariableReference(startIndex, endIndex, (expression279!=null?expression279.expr:null));
                        System.out.println("**" + retval.expr);
                      

                    }
                    break;
                case 3 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1736:5: ^( INDEX obj= object_property ( expression )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    INDEX280=(SLAST)match(input,INDEX,FOLLOW_INDEX_in_object_property3469); 
                    INDEX280_tree = (SLAST)adaptor.dupNode(INDEX280);

                    root_1 = (SLAST)adaptor.becomeRoot(INDEX280_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_object_property_in_object_property3473);
                    obj=object_property();

                    state._fsp--;

                    adaptor.addChild(root_1, obj.getTree());
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1736:33: ( expression )?
                    int alt91=2;
                    int LA91_0 = input.LA(1);

                    if ( (LA91_0==METHOD_DECL||LA91_0==VAR_DECL||LA91_0==CALL||LA91_0==EXPR||(LA91_0>=SCALAR && LA91_0<=CAST_EXPR)||LA91_0==REF_T||LA91_0==EQUAL_T||(LA91_0>=OR_T && LA91_0<=EXC_NOT_T)||(LA91_0>=INSTANCEOF_T && LA91_0<=BACKTRICKLITERAL)) ) {
                        alt91=1;
                    }
                    switch (alt91) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1736:33: expression
                            {
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_expression_in_object_property3475);
                            expression281=expression();

                            state._fsp--;

                            adaptor.addChild(root_1, expression281.getTree());

                            }
                            break;

                    }


                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        startIndex = INDEX280.startIndex;
                        endIndex = INDEX280.endIndex + 1;
                       
                        if (startIndex == 0 && (expression281!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(expression281.start),
                      input.getTreeAdaptor().getTokenStopIndex(expression281.start))):null) != null) {
                           startIndex = (obj!=null?((SLAST)obj.tree):null).startIndex;
                           endIndex = (obj!=null?((SLAST)obj.tree):null).endIndex + (expression281!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(expression281.start),
                      input.getTreeAdaptor().getTokenStopIndex(expression281.start))):null).length();
                        }
                        Expression varName = (obj!=null?obj.expr:null);
                        Expression index = (expression281!=null?expression281.expr:null);
                        if ((expression281!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(expression281.start),
                      input.getTreeAdaptor().getTokenStopIndex(expression281.start))):null) != null) {
                    	    if(varName.getKind() == ExpressionConstants.E_IDENTIFIER) {
                    	       retval.expr = new ArrayVariableReference(startIndex, endIndex, ((SimpleReference)varName).getName(), index, ArrayVariableReference.VARIABLE_ARRAY);
                    	    } else {
                    	       retval.expr = new ReflectionArrayVariableReference(startIndex, endIndex, varName, index, ReflectionArrayVariableReference.VARIABLE_ARRAY);
                    	    }
                    	  }
                    	  else {
                    	     retval.expr = new ArrayVariableReference(startIndex, endIndex, ((SimpleReference)varName).getName(), index, ArrayVariableReference.VARIABLE_ARRAY);
                    	  }
                        ast = INDEX280_tree;
                      

                    }
                    break;
                case 4 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1759:5: ^( HASH_INDEX obj= object_property ( expression )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    HASH_INDEX282=(SLAST)match(input,HASH_INDEX,FOLLOW_HASH_INDEX_in_object_property3488); 
                    HASH_INDEX282_tree = (SLAST)adaptor.dupNode(HASH_INDEX282);

                    root_1 = (SLAST)adaptor.becomeRoot(HASH_INDEX282_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_object_property_in_object_property3492);
                    obj=object_property();

                    state._fsp--;

                    adaptor.addChild(root_1, obj.getTree());
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1759:38: ( expression )?
                    int alt92=2;
                    int LA92_0 = input.LA(1);

                    if ( (LA92_0==METHOD_DECL||LA92_0==VAR_DECL||LA92_0==CALL||LA92_0==EXPR||(LA92_0>=SCALAR && LA92_0<=CAST_EXPR)||LA92_0==REF_T||LA92_0==EQUAL_T||(LA92_0>=OR_T && LA92_0<=EXC_NOT_T)||(LA92_0>=INSTANCEOF_T && LA92_0<=BACKTRICKLITERAL)) ) {
                        alt92=1;
                    }
                    switch (alt92) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1759:38: expression
                            {
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_expression_in_object_property3494);
                            expression283=expression();

                            state._fsp--;

                            adaptor.addChild(root_1, expression283.getTree());

                            }
                            break;

                    }


                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        startIndex = HASH_INDEX282.startIndex;
                        endIndex = HASH_INDEX282.endIndex + 1;
                       
                        if (startIndex == 0 && (expression283!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(expression283.start),
                      input.getTreeAdaptor().getTokenStopIndex(expression283.start))):null) != null) {
                           startIndex = (obj!=null?((SLAST)obj.tree):null).startIndex;
                           endIndex = (obj!=null?((SLAST)obj.tree):null).endIndex + (expression283!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(expression283.start),
                      input.getTreeAdaptor().getTokenStopIndex(expression283.start))):null).length();
                        }
                        Expression varName = (obj!=null?obj.expr:null);
                        Expression index = (expression283!=null?expression283.expr:null);
                        if ((expression283!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(expression283.start),
                      input.getTreeAdaptor().getTokenStopIndex(expression283.start))):null) != null) {
                          if(varName.getKind() == ExpressionConstants.E_IDENTIFIER) {
                             retval.expr = new ArrayVariableReference(startIndex, endIndex, ((SimpleReference)varName).getName(), index, ArrayVariableReference.VARIABLE_HASHTABLE);
                          } else {
                             retval.expr = new ReflectionArrayVariableReference(startIndex, endIndex, varName, index, ReflectionArrayVariableReference.VARIABLE_HASHTABLE);
                          }
                        }
                        else {
                           retval.expr = new ArrayVariableReference(startIndex, endIndex, ((SimpleReference)varName).getName(), index, ArrayVariableReference.VARIABLE_HASHTABLE);
                        }
                        ast = HASH_INDEX282_tree;
                      

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);


              if (ast != null) {
                retval.tree = ast;
              }
              ((SLAST)retval.tree).setIndex(startIndex, endIndex);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "object_property"

    public static class ctor_arguments_return extends TreeRuleReturnScope {
        public PHPCallArgumentsList argumentList;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "ctor_arguments"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1784:1: ctor_arguments returns [PHPCallArgumentsList argumentList] : ^( ARGU ( expr_list )? ) ;
    public final TreePHP.ctor_arguments_return ctor_arguments() throws RecognitionException {
        TreePHP.ctor_arguments_return retval = new TreePHP.ctor_arguments_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST ARGU284=null;
        TreePHP.expr_list_return expr_list285 = null;


        SLAST ARGU284_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1785:3: ( ^( ARGU ( expr_list )? ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1785:6: ^( ARGU ( expr_list )? )
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_1 = _last;
            SLAST _first_1 = null;
            SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            ARGU284=(SLAST)match(input,ARGU,FOLLOW_ARGU_in_ctor_arguments3523); 
            ARGU284_tree = (SLAST)adaptor.dupNode(ARGU284);

            root_1 = (SLAST)adaptor.becomeRoot(ARGU284_tree, root_1);



            if ( input.LA(1)==Token.DOWN ) {
                match(input, Token.DOWN, null); 
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1785:13: ( expr_list )?
                int alt94=2;
                int LA94_0 = input.LA(1);

                if ( (LA94_0==METHOD_DECL||LA94_0==VAR_DECL||LA94_0==CALL||LA94_0==EXPR||(LA94_0>=SCALAR && LA94_0<=CAST_EXPR)||LA94_0==REF_T||LA94_0==EQUAL_T||(LA94_0>=OR_T && LA94_0<=EXC_NOT_T)||(LA94_0>=INSTANCEOF_T && LA94_0<=BACKTRICKLITERAL)) ) {
                    alt94=1;
                }
                switch (alt94) {
                    case 1 :
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1785:13: expr_list
                        {
                        _last = (SLAST)input.LT(1);
                        pushFollow(FOLLOW_expr_list_in_ctor_arguments3525);
                        expr_list285=expr_list();

                        state._fsp--;

                        adaptor.addChild(root_1, expr_list285.getTree());

                        }
                        break;

                }


                match(input, Token.UP, null); 
            }adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


                int startIndex = ARGU284.startIndex;
                int endIndex = ARGU284.endIndex + 1;

            	  retval.argumentList = new PHPCallArgumentsList();
            	  retval.argumentList.setStart(startIndex);
            	  retval.argumentList.setEnd(endIndex);
            	  
            	  if ((expr_list285!=null?expr_list285.exprList:null) != null) {
            	    Iterator iter = (expr_list285!=null?expr_list285.exprList:null).iterator();
            	    while (iter.hasNext()) {
            	      retval.argumentList.addNode((Expression)iter.next());
            	    }
            	  }
              

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "ctor_arguments"

    public static class pure_variable_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "pure_variable"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1803:1: pure_variable : ^( VAR_DECL ( REF_T )? ( DOLLAR_T )+ IDENTIFIER ) ;
    public final TreePHP.pure_variable_return pure_variable() throws RecognitionException {
        TreePHP.pure_variable_return retval = new TreePHP.pure_variable_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST VAR_DECL286=null;
        SLAST REF_T287=null;
        SLAST DOLLAR_T288=null;
        SLAST IDENTIFIER289=null;

        SLAST VAR_DECL286_tree=null;
        SLAST REF_T287_tree=null;
        SLAST DOLLAR_T288_tree=null;
        SLAST IDENTIFIER289_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1804:3: ( ^( VAR_DECL ( REF_T )? ( DOLLAR_T )+ IDENTIFIER ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1804:5: ^( VAR_DECL ( REF_T )? ( DOLLAR_T )+ IDENTIFIER )
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_1 = _last;
            SLAST _first_1 = null;
            SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            VAR_DECL286=(SLAST)match(input,VAR_DECL,FOLLOW_VAR_DECL_in_pure_variable3547); 
            VAR_DECL286_tree = (SLAST)adaptor.dupNode(VAR_DECL286);

            root_1 = (SLAST)adaptor.becomeRoot(VAR_DECL286_tree, root_1);



            match(input, Token.DOWN, null); 
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1804:16: ( REF_T )?
            int alt95=2;
            int LA95_0 = input.LA(1);

            if ( (LA95_0==REF_T) ) {
                alt95=1;
            }
            switch (alt95) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1804:16: REF_T
                    {
                    _last = (SLAST)input.LT(1);
                    REF_T287=(SLAST)match(input,REF_T,FOLLOW_REF_T_in_pure_variable3549); 
                    REF_T287_tree = (SLAST)adaptor.dupNode(REF_T287);

                    adaptor.addChild(root_1, REF_T287_tree);


                    }
                    break;

            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1804:23: ( DOLLAR_T )+
            int cnt96=0;
            loop96:
            do {
                int alt96=2;
                int LA96_0 = input.LA(1);

                if ( (LA96_0==DOLLAR_T) ) {
                    alt96=1;
                }


                switch (alt96) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1804:23: DOLLAR_T
            	    {
            	    _last = (SLAST)input.LT(1);
            	    DOLLAR_T288=(SLAST)match(input,DOLLAR_T,FOLLOW_DOLLAR_T_in_pure_variable3552); 
            	    DOLLAR_T288_tree = (SLAST)adaptor.dupNode(DOLLAR_T288);

            	    adaptor.addChild(root_1, DOLLAR_T288_tree);


            	    }
            	    break;

            	default :
            	    if ( cnt96 >= 1 ) break loop96;
                        EarlyExitException eee =
                            new EarlyExitException(96, input);
                        throw eee;
                }
                cnt96++;
            } while (true);

            _last = (SLAST)input.LT(1);
            IDENTIFIER289=(SLAST)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_pure_variable3555); 
            IDENTIFIER289_tree = (SLAST)adaptor.dupNode(IDENTIFIER289);

            adaptor.addChild(root_1, IDENTIFIER289_tree);


            match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "pure_variable"

    public static class scalar_return extends TreeRuleReturnScope {
        public Expression expr;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "scalar"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1807:1: scalar returns [Expression expr] : ^( SCALAR constant ) ;
    public final TreePHP.scalar_return scalar() throws RecognitionException {
        TreePHP.scalar_return retval = new TreePHP.scalar_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST SCALAR290=null;
        TreePHP.constant_return constant291 = null;


        SLAST SCALAR290_tree=null;


          SLAST ast = null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1814:3: ( ^( SCALAR constant ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1814:5: ^( SCALAR constant )
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_1 = _last;
            SLAST _first_1 = null;
            SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            SCALAR290=(SLAST)match(input,SCALAR,FOLLOW_SCALAR_in_scalar3586); 
            SCALAR290_tree = (SLAST)adaptor.dupNode(SCALAR290);

            root_1 = (SLAST)adaptor.becomeRoot(SCALAR290_tree, root_1);



            match(input, Token.DOWN, null); 
            _last = (SLAST)input.LT(1);
            pushFollow(FOLLOW_constant_in_scalar3588);
            constant291=constant();

            state._fsp--;

            adaptor.addChild(root_1, constant291.getTree());

            match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


                if ((constant291!=null?constant291.expr:null) != null ) {
                  retval.expr = (constant291!=null?constant291.expr:null);
                }
                else {
                  retval.expr = (constant291!=null?constant291.scalar:null);
                }
                ast = (constant291!=null?((SLAST)constant291.tree):null);
              

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);


              retval.tree = ast;

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "scalar"

    public static class constant_return extends TreeRuleReturnScope {
        public Scalar scalar;
        public Expression expr;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "constant"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1826:1: constant returns [Scalar scalar, Expression expr] : ( INTLITERAL | FLOATLITERAL | STRINGLITERAL | DOUBLELITERRAL | common_scalar | IDENTIFIER | fully_qualified_class_name );
    public final TreePHP.constant_return constant() throws RecognitionException {
        TreePHP.constant_return retval = new TreePHP.constant_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST INTLITERAL292=null;
        SLAST FLOATLITERAL293=null;
        SLAST STRINGLITERAL294=null;
        SLAST DOUBLELITERRAL295=null;
        SLAST IDENTIFIER297=null;
        TreePHP.common_scalar_return common_scalar296 = null;

        TreePHP.fully_qualified_class_name_return fully_qualified_class_name298 = null;


        SLAST INTLITERAL292_tree=null;
        SLAST FLOATLITERAL293_tree=null;
        SLAST STRINGLITERAL294_tree=null;
        SLAST DOUBLELITERRAL295_tree=null;
        SLAST IDENTIFIER297_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1827:3: ( INTLITERAL | FLOATLITERAL | STRINGLITERAL | DOUBLELITERRAL | common_scalar | IDENTIFIER | fully_qualified_class_name )
            int alt97=7;
            switch ( input.LA(1) ) {
            case INTLITERAL:
                {
                alt97=1;
                }
                break;
            case FLOATLITERAL:
                {
                alt97=2;
                }
                break;
            case STRINGLITERAL:
                {
                alt97=3;
                }
                break;
            case DOUBLELITERRAL:
                {
                alt97=4;
                }
                break;
            case 180:
            case 181:
            case 182:
            case 183:
            case 184:
            case 185:
                {
                alt97=5;
                }
                break;
            case IDENTIFIER:
                {
                alt97=6;
                }
                break;
            case DOMAIN_T:
                {
                alt97=7;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 97, 0, input);

                throw nvae;
            }

            switch (alt97) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1827:7: INTLITERAL
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    INTLITERAL292=(SLAST)match(input,INTLITERAL,FOLLOW_INTLITERAL_in_constant3614); 
                    INTLITERAL292_tree = (SLAST)adaptor.dupNode(INTLITERAL292);

                    adaptor.addChild(root_0, INTLITERAL292_tree);


                        CommonToken token = (CommonToken)INTLITERAL292.token;
                        int startIndex = token.getStartIndex();
                        int endIndex = token.getStopIndex() + 1;
                        retval.scalar = new Scalar(startIndex, endIndex, (INTLITERAL292!=null?INTLITERAL292.getText():null), Scalar.TYPE_INT);
                      

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1834:7: FLOATLITERAL
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    FLOATLITERAL293=(SLAST)match(input,FLOATLITERAL,FOLLOW_FLOATLITERAL_in_constant3626); 
                    FLOATLITERAL293_tree = (SLAST)adaptor.dupNode(FLOATLITERAL293);

                    adaptor.addChild(root_0, FLOATLITERAL293_tree);


                    }
                    break;
                case 3 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1835:7: STRINGLITERAL
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    STRINGLITERAL294=(SLAST)match(input,STRINGLITERAL,FOLLOW_STRINGLITERAL_in_constant3634); 
                    STRINGLITERAL294_tree = (SLAST)adaptor.dupNode(STRINGLITERAL294);

                    adaptor.addChild(root_0, STRINGLITERAL294_tree);


                        CommonToken token = (CommonToken)STRINGLITERAL294.token;
                        int startIndex = token.getStartIndex();
                        int endIndex = token.getStopIndex() + 1;
                        retval.scalar = new Scalar(startIndex, endIndex, (STRINGLITERAL294!=null?STRINGLITERAL294.getText():null), Scalar.TYPE_STRING);
                      

                    }
                    break;
                case 4 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1842:7: DOUBLELITERRAL
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    DOUBLELITERRAL295=(SLAST)match(input,DOUBLELITERRAL,FOLLOW_DOUBLELITERRAL_in_constant3646); 
                    DOUBLELITERRAL295_tree = (SLAST)adaptor.dupNode(DOUBLELITERRAL295);

                    adaptor.addChild(root_0, DOUBLELITERRAL295_tree);


                    }
                    break;
                case 5 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1843:7: common_scalar
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_common_scalar_in_constant3654);
                    common_scalar296=common_scalar();

                    state._fsp--;

                    adaptor.addChild(root_0, common_scalar296.getTree());

                          CommonToken token = (CommonToken)(common_scalar296!=null?((SLAST)common_scalar296.tree):null).token;
                          int startIndex = token.getStartIndex();
                          int endIndex = token.getStopIndex() + 1;
                          retval.scalar = new Scalar(startIndex, endIndex, (common_scalar296!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(common_scalar296.start),
                      input.getTreeAdaptor().getTokenStopIndex(common_scalar296.start))):null), Scalar.TYPE_SYSTEM);
                      

                    }
                    break;
                case 6 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1850:7: IDENTIFIER
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    IDENTIFIER297=(SLAST)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_constant3666); 
                    IDENTIFIER297_tree = (SLAST)adaptor.dupNode(IDENTIFIER297);

                    adaptor.addChild(root_0, IDENTIFIER297_tree);


                          CommonToken token = (CommonToken)IDENTIFIER297.token;
                    	    int startIndex = token.getStartIndex();
                    	    int endIndex = token.getStopIndex() + 1;
                    	    retval.scalar = new Scalar(startIndex, endIndex, (IDENTIFIER297!=null?IDENTIFIER297.getText():null), Scalar.TYPE_STRING);
                      

                    }
                    break;
                case 7 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1857:7: fully_qualified_class_name
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_fully_qualified_class_name_in_constant3678);
                    fully_qualified_class_name298=fully_qualified_class_name();

                    state._fsp--;

                    adaptor.addChild(root_0, fully_qualified_class_name298.getTree());

                     //   retval.expr = (fully_qualified_class_name298!=null?fully_qualified_class_name298.constant:null);
                          retval.expr = (fully_qualified_class_name298!=null?fully_qualified_class_name298.type:null);
                      

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "constant"

    public static class common_scalar_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "common_scalar"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1864:1: common_scalar : ( '__CLASS__' | '__DIR__' | '__FILE__' | '__FUNCTION__' | '__METHOD__' | '__NAMESPACE__' );
    public final TreePHP.common_scalar_return common_scalar() throws RecognitionException {
        TreePHP.common_scalar_return retval = new TreePHP.common_scalar_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST set299=null;

        SLAST set299_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1865:3: ( '__CLASS__' | '__DIR__' | '__FILE__' | '__FUNCTION__' | '__METHOD__' | '__NAMESPACE__' )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            set299=(SLAST)input.LT(1);
            if ( (input.LA(1)>=180 && input.LA(1)<=185) ) {
                input.consume();

                set299_tree = (SLAST)adaptor.dupNode(set299);

                adaptor.addChild(root_0, set299_tree);

                state.errorRecovery=false;
            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                throw mse;
            }

             

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "common_scalar"

    // Delegated rules


    protected DFA70 dfa70 = new DFA70(this);
    protected DFA93 dfa93 = new DFA93(this);
    static final String DFA70_eotS =
        "\70\uffff";
    static final String DFA70_eofS =
        "\70\uffff";
    static final String DFA70_minS =
        "\1\11\54\uffff\1\15\12\uffff";
    static final String DFA70_maxS =
        "\1\u008d\54\uffff\1\44\12\uffff";
    static final String DFA70_acceptS =
        "\1\uffff\1\1\1\2\1\3\1\4\1\5\1\6\1\7\1\10\1\11\1\12\1\13\1\14\1"+
        "\15\1\16\1\17\1\20\1\21\1\22\1\23\1\24\1\25\1\26\1\27\1\30\1\31"+
        "\1\32\1\33\1\34\1\35\1\36\1\37\1\40\1\41\1\42\1\43\1\44\1\45\1\46"+
        "\1\47\1\50\1\51\1\52\1\53\1\54\1\uffff\1\55\1\56\1\57\1\60\1\61"+
        "\1\62\1\63\1\64\1\65\1\66";
    static final String DFA70_specialS =
        "\70\uffff}>";
    static final String[] DFA70_transitionS = {
            "\1\66\3\uffff\1\56\5\uffff\1\56\1\uffff\1\1\16\uffff\1\57\1"+
            "\61\1\53\1\52\1\47\20\uffff\1\26\27\uffff\1\5\15\uffff\1\2\1"+
            "\3\1\4\1\6\1\7\1\10\1\11\1\12\1\13\1\14\1\15\1\16\1\17\1\20"+
            "\1\21\1\22\1\23\1\24\1\25\1\27\1\30\1\31\1\32\1\33\1\34\1\35"+
            "\1\36\1\37\1\40\1\41\1\42\1\43\1\44\1\45\1\46\1\65\1\63\1\50"+
            "\1\51\2\uffff\1\54\1\55\1\60\1\62\1\64\1\67",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\1\56\5\uffff\1\56\20\uffff\1\57",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA70_eot = DFA.unpackEncodedString(DFA70_eotS);
    static final short[] DFA70_eof = DFA.unpackEncodedString(DFA70_eofS);
    static final char[] DFA70_min = DFA.unpackEncodedStringToUnsignedChars(DFA70_minS);
    static final char[] DFA70_max = DFA.unpackEncodedStringToUnsignedChars(DFA70_maxS);
    static final short[] DFA70_accept = DFA.unpackEncodedString(DFA70_acceptS);
    static final short[] DFA70_special = DFA.unpackEncodedString(DFA70_specialS);
    static final short[][] DFA70_transition;

    static {
        int numStates = DFA70_transitionS.length;
        DFA70_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA70_transition[i] = DFA.unpackEncodedString(DFA70_transitionS[i]);
        }
    }

    class DFA70 extends DFA {

        public DFA70(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 70;
            this.eot = DFA70_eot;
            this.eof = DFA70_eof;
            this.min = DFA70_min;
            this.max = DFA70_max;
            this.accept = DFA70_accept;
            this.special = DFA70_special;
            this.transition = DFA70_transition;
        }
        public String getDescription() {
            return "977:1: expression returns [Expression expr] : ( ^( EXPR etop= expression ) | ^( OR_T e1= expression e2= expression ) | ^( XOR_T e1= expression e2= expression ) | ^( AND_T e1= expression e2= expression ) | ^( EQUAL_T e1= expression e2= expression ) | ^( PLUS_EQ e1= expression e2= expression ) | ^( MINUS_EQ e1= expression e2= expression ) | ^( MUL_EQ e1= expression e2= expression ) | ^( DIV_EQ e1= expression e2= expression ) | ^( DOT_EQ e1= expression e2= expression ) | ^( PERCENT_EQ e1= expression e2= expression ) | ^( BIT_AND_EQ e1= expression e2= expression ) | ^( BIT_OR_EQ e1= expression e2= expression ) | ^( POWER_EQ e1= expression e2= expression ) | ^( LMOVE_EQ e1= expression e2= expression ) | ^( RMOVE_EQ e1= expression e2= expression ) | ^( QUESTION_T e1= expression ^( COLON_T e2= expression e3= expression ) ) | ^( LOGICAL_OR_T e1= expression e2= expression ) | ^( LOGICAL_AND_T e1= expression e2= expression ) | ^( BIT_OR_T e1= expression e2= expression ) | ^( POWER_T expression expression ) | ^( REF_T e1= expression (e2= expression )? ) | ^( DOT_T e1= expression e2= expression ) | ^( EQUAL_EQUAL_T e1= expression e2= expression ) | ^( NOT_EQUAL_T e1= expression e2= expression ) | ^( EQUAL_EQUAL_EQUAL_T e1= expression e2= expression ) | ^( NOT_EQUAL_EQUAL_T e1= expression e2= expression ) | ^( LT_T e1= expression e2= expression ) | ^( MT_T e1= expression e2= expression ) | ^( LE_T e1= expression e2= expression ) | ^( ME_T expression expression ) | ^( LSHIFT_T e1= expression e2= expression ) | ^( RSHIFT_T e1= expression e2= expression ) | ^( PLUS_T e1= expression (e2= expression )? ) | ^( MINUS_T e1= expression (e2= expression )? ) | ^( MUL_T e1= expression e2= expression ) | ^( DIV_T e1= expression e2= expression ) | ^( PERCENT_T e1= expression e2= expression ) | ^( CAST_EXPR cast_option e= expression ) | ^( TILDA_T e= expression ) | ^( EXC_NOT_T expression ) | ^( POSTFIX_EXPR e= expression plus_minus ) | ^( PREFIX_EXPR ( plus_minus )+ e= expression ) | ^( INSTANCEOF_T e= expression class_name_reference ) | ( AT_T )? variable | ( AT_T )? scalar | list_decl | ^( ARRAY_DECL ( array_pair_list )? ) | ^( NEW_T class_name_reference ) | ^( CLONE_T variable ) | ^( EXIT_T ( expression )? ) | ^( UNSET_T variable ) | lambda_function_declaration | BACKTRICKLITERAL );";
        }
    }
    static final String DFA93_eotS =
        "\10\uffff";
    static final String DFA93_eofS =
        "\10\uffff";
    static final String DFA93_minS =
        "\1\21\1\2\2\uffff\2\11\2\uffff";
    static final String DFA93_maxS =
        "\1\52\1\2\2\uffff\2\u0091\2\uffff";
    static final String DFA93_acceptS =
        "\2\uffff\1\3\1\4\2\uffff\1\1\1\2";
    static final String DFA93_specialS =
        "\10\uffff}>";
    static final String[] DFA93_transitionS = {
            "\1\2\27\uffff\1\1\1\3",
            "\1\4",
            "",
            "",
            "\1\7\3\uffff\1\7\5\uffff\1\7\1\uffff\1\7\16\uffff\5\7\11\uffff"+
            "\1\6\6\uffff\1\7\27\uffff\1\7\15\uffff\47\7\2\uffff\6\7\3\uffff"+
            "\1\5",
            "\1\7\3\uffff\1\7\5\uffff\1\7\1\uffff\1\7\16\uffff\5\7\11\uffff"+
            "\1\6\6\uffff\1\7\27\uffff\1\7\15\uffff\47\7\2\uffff\6\7\3\uffff"+
            "\1\5",
            "",
            ""
    };

    static final short[] DFA93_eot = DFA.unpackEncodedString(DFA93_eotS);
    static final short[] DFA93_eof = DFA.unpackEncodedString(DFA93_eofS);
    static final char[] DFA93_min = DFA.unpackEncodedStringToUnsignedChars(DFA93_minS);
    static final char[] DFA93_max = DFA.unpackEncodedStringToUnsignedChars(DFA93_maxS);
    static final short[] DFA93_accept = DFA.unpackEncodedString(DFA93_acceptS);
    static final short[] DFA93_special = DFA.unpackEncodedString(DFA93_specialS);
    static final short[][] DFA93_transition;

    static {
        int numStates = DFA93_transitionS.length;
        DFA93_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA93_transition[i] = DFA.unpackEncodedString(DFA93_transitionS[i]);
        }
    }

    class DFA93 extends DFA {

        public DFA93(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 93;
            this.eot = DFA93_eot;
            this.eof = DFA93_eof;
            this.min = DFA93_min;
            this.max = DFA93_max;
            this.accept = DFA93_accept;
            this.special = DFA93_special;
            this.transition = DFA93_transition;
        }
        public String getDescription() {
            return "1701:1: object_property returns [String str, Expression expr, SimpleReference simpleRef] : ( ^( VAR ( DOLLAR_T )* IDENTIFIER ) | ^( VAR ( DOLLAR_T )* expression ) | ^( INDEX obj= object_property ( expression )? ) | ^( HASH_INDEX obj= object_property ( expression )? ) );";
        }
    }
 

    public static final BitSet FOLLOW_ModuleDeclaration_in_php_source58 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_top_statement_list_in_php_source60 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_top_statement_in_top_statement_list79 = new BitSet(new long[]{0x0082000000004202L,0x0000000000000000L,0x0000001000000000L});
    public static final BitSet FOLLOW_statement_in_top_statement93 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_function_declaration_statement_in_top_statement103 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_class_declaration_statement_in_top_statement113 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_halt_compiler_statement_in_top_statement123 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_inner_statement_in_inner_statement_list150 = new BitSet(new long[]{0x0082000000004202L,0x0000000000000000L,0x0000001000000000L});
    public static final BitSet FOLLOW_statement_in_inner_statement172 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_function_declaration_statement_in_inner_statement182 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_class_declaration_statement_in_inner_statement192 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_halt_compiler_statement_in_inner_statement198 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_164_in_halt_compiler_statement213 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_CLASS_T_in_class_declaration_statement233 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_class_entr_type_in_class_declaration_statement235 = new BitSet(new long[]{0x0004000000000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_class_declaration_statement238 = new BitSet(new long[]{0x0018000000000088L});
    public static final BitSet FOLLOW_EXTENDS_T_in_class_declaration_statement252 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_fully_qualified_class_name_in_class_declaration_statement254 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_IMPLEMENTS_T_in_class_declaration_statement261 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_fully_qualified_class_name_list_in_class_declaration_statement263 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_CLASS_BODY_in_class_declaration_statement276 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_class_statement_list_in_class_declaration_statement278 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_INTERFACE_T_in_class_declaration_statement295 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_IDENTIFIER_in_class_declaration_statement297 = new BitSet(new long[]{0x0008000000000088L});
    public static final BitSet FOLLOW_EXTENDS_T_in_class_declaration_statement301 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_fully_qualified_class_name_list_in_class_declaration_statement303 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_CLASS_BODY_in_class_declaration_statement322 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_class_statement_list_in_class_declaration_statement324 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_set_in_class_entr_type0 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_class_statement_in_class_statement_list373 = new BitSet(new long[]{0x0000000000000302L});
    public static final BitSet FOLLOW_FIELD_DECL_in_class_statement398 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_variable_modifiers_in_class_statement402 = new BitSet(new long[]{0x0000000000002000L,0x0000000000020000L});
    public static final BitSet FOLLOW_static_var_element_in_class_statement404 = new BitSet(new long[]{0x0000000000002008L,0x0000000000020000L});
    public static final BitSet FOLLOW_METHOD_DECL_in_class_statement419 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_modifier_in_class_statement421 = new BitSet(new long[]{0x0204000000000000L});
    public static final BitSet FOLLOW_REF_T_in_class_statement423 = new BitSet(new long[]{0x0004000000000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_class_statement426 = new BitSet(new long[]{0x0000000800001800L});
    public static final BitSet FOLLOW_parameter_list_in_class_statement440 = new BitSet(new long[]{0x0000000800001000L});
    public static final BitSet FOLLOW_block_in_class_statement456 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_EMPTYSTATEMENT_in_class_statement475 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_FIELD_DECL_in_class_statement498 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_CONST_T_in_class_statement502 = new BitSet(new long[]{0x0000000000000000L,0x0000000000020000L});
    public static final BitSet FOLLOW_directive_in_class_statement504 = new BitSet(new long[]{0x0000000000000008L,0x0000000000020000L});
    public static final BitSet FOLLOW_METHOD_DECL_in_function_declaration_statement530 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_REF_T_in_function_declaration_statement532 = new BitSet(new long[]{0x0004000000000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_function_declaration_statement535 = new BitSet(new long[]{0x0000000000001800L});
    public static final BitSet FOLLOW_parameter_list_in_function_declaration_statement544 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_block_in_function_declaration_statement557 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_BLOCK_in_block592 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_inner_statement_list_in_block594 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_STATEMENT_in_statement623 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_topStatement_in_statement625 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_block_in_topStatement651 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_if_stat_in_topStatement662 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_WHILE_T_in_topStatement673 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_CONDITION_in_topStatement676 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_topStatement680 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_while_statement_in_topStatement683 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_DO_T_in_topStatement698 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_CONDITION_in_topStatement701 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_topStatement705 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_statement_in_topStatement708 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_FOR_T_in_topStatement720 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_list_in_topStatement724 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_CONDITION_in_topStatement728 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_list_in_topStatement732 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_ITERATE_in_topStatement737 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_list_in_topStatement741 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_for_statement_in_topStatement747 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_SWITCH_T_in_topStatement759 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_CONDITION_in_topStatement762 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_topStatement764 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_switch_case_list_in_topStatement767 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_BREAK_T_in_topStatement775 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_topStatement777 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_CONTINUE_T_in_topStatement790 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_topStatement794 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_RETURN_T_in_topStatement807 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_topStatement811 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_GLOBAL_T_in_topStatement824 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_variable_list_in_topStatement826 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_STATIC_T_in_topStatement838 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_static_var_list_in_topStatement840 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_ECHO_T_in_topStatement852 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_list_in_topStatement854 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_EMPTYSTATEMENT_in_topStatement866 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_SEMI_COLON_in_topStatement868 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_expression_in_topStatement879 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_FOREACH_T_in_topStatement890 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_AS_T_in_topStatement893 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_topStatement897 = new BitSet(new long[]{0x0200000000082000L});
    public static final BitSet FOLLOW_foreach_variable_in_topStatement901 = new BitSet(new long[]{0x0200000000082008L});
    public static final BitSet FOLLOW_foreach_variable_in_topStatement905 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_foreach_statement_in_topStatement909 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_DECLARE_T_in_topStatement928 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_directive_in_topStatement930 = new BitSet(new long[]{0x0082000000004208L,0x0000000000000000L,0x0000001000000000L});
    public static final BitSet FOLLOW_declare_statement_in_topStatement932 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_TRY_T_in_topStatement945 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_BLOCK_in_topStatement948 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_top_statement_in_topStatement950 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_catch_branch_in_topStatement953 = new BitSet(new long[]{0x0000000000000008L,0x0000000004000000L});
    public static final BitSet FOLLOW_THROW_T_in_topStatement962 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_topStatement964 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_USE_T_in_topStatement972 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_use_filename_in_topStatement974 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_INCLUDE_T_in_topStatement982 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_topStatement986 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_INCLUDE_ONCE_T_in_topStatement999 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_topStatement1003 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_REF_T_in_foreach_variable1034 = new BitSet(new long[]{0x0200000000082000L});
    public static final BitSet FOLLOW_variable_in_foreach_variable1037 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_STRINGLITERAL_in_use_filename1056 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_variable_in_variable_list1084 = new BitSet(new long[]{0x0200000000082002L});
    public static final BitSet FOLLOW_fully_qualified_class_name_in_fully_qualified_class_name_list1109 = new BitSet(new long[]{0x0004000000000002L,0x0000000000008000L});
    public static final BitSet FOLLOW_DOMAIN_T_in_fully_qualified_class_name1132 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_fully_qualified_class_name_in_fully_qualified_class_name1136 = new BitSet(new long[]{0x0004000000000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_fully_qualified_class_name1138 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_DOMAIN_T_in_fully_qualified_class_name1141 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IDENTIFIER_in_fully_qualified_class_name1152 = new BitSet(new long[]{0x0000000000000002L,0x0000000000008000L});
    public static final BitSet FOLLOW_DOMAIN_T_in_fully_qualified_class_name1154 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_SCALAR_ELEMENT_in_static_array_pair_list1176 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_static_scalar_element_in_static_array_pair_list1178 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_scalar_in_static_scalar_element1195 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000080L});
    public static final BitSet FOLLOW_ARROW_T_in_static_scalar_element1198 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_scalar_in_static_scalar_element1201 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_static_var_element_in_static_var_list1231 = new BitSet(new long[]{0x0000000000002002L,0x0000000000020000L});
    public static final BitSet FOLLOW_pure_variable_in_static_var_element1249 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_EQUAL_T_in_static_var_element1260 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_pure_variable_in_static_var_element1262 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_scalar_in_static_var_element1264 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_IF_T_in_if_stat1298 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_CONDITION_in_if_stat1301 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_if_stat1303 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_inner_statement_list_in_if_stat1319 = new BitSet(new long[]{0x0000000000000008L,0x0000000000180000L});
    public static final BitSet FOLLOW_else_if_stat_in_if_stat1328 = new BitSet(new long[]{0x0000000000000008L,0x0000000000180000L});
    public static final BitSet FOLLOW_ELSE_T_in_if_stat1333 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_statement_in_if_stat1335 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_ELSEIF_T_in_else_if_stat1365 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_CONDITION_in_else_if_stat1368 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_else_if_stat1370 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_inner_statement_list_in_else_if_stat1373 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_case_list_in_switch_case_list1394 = new BitSet(new long[]{0x0000000000000002L,0x0000000003000000L});
    public static final BitSet FOLLOW_CASE_T_in_case_list1409 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_case_list1411 = new BitSet(new long[]{0x0082000000004208L,0x0000000000000000L,0x0000001000000000L});
    public static final BitSet FOLLOW_inner_statement_list_in_case_list1413 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_DEFAULT_T_in_case_list1422 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_inner_statement_list_in_case_list1424 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_CATCH_T_in_catch_branch1441 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_IDENTIFIER_in_catch_branch1443 = new BitSet(new long[]{0x0200000000082000L});
    public static final BitSet FOLLOW_variable_in_catch_branch1445 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_block_in_catch_branch1447 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_inner_statement_list_in_for_statement1464 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_inner_statement_list_in_while_statement1487 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_inner_statement_list_in_foreach_statement1512 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_inner_statement_list_in_declare_statement1548 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_parameter_in_parameter_list1583 = new BitSet(new long[]{0x0000000000000802L});
    public static final BitSet FOLLOW_PARAMETER_in_parameter1604 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_TYPE_in_parameter1608 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_parameter_type_in_parameter1610 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_CONST_T_in_parameter1615 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_pure_variable_in_parameter1618 = new BitSet(new long[]{0x0000001000000008L});
    public static final BitSet FOLLOW_scalar_in_parameter1620 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_fully_qualified_class_name_in_parameter_type1645 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_cast_option_in_parameter_type1655 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_167_in_variable_modifiers1673 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_modifier_in_variable_modifiers1679 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_168_in_modifier1703 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000008L,0x0000076000000000L});
    public static final BitSet FOLLOW_169_in_modifier1711 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000008L,0x0000076000000000L});
    public static final BitSet FOLLOW_170_in_modifier1719 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000008L,0x0000076000000000L});
    public static final BitSet FOLLOW_STATIC_T_in_modifier1727 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000008L,0x0000076000000000L});
    public static final BitSet FOLLOW_165_in_modifier1736 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000008L,0x0000076000000000L});
    public static final BitSet FOLLOW_166_in_modifier1745 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000008L,0x0000076000000000L});
    public static final BitSet FOLLOW_EQUAL_T_in_directive1777 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_IDENTIFIER_in_directive1779 = new BitSet(new long[]{0x020001F000282200L,0xFFFFFFFF80020000L,0x0000000000003F3FL});
    public static final BitSet FOLLOW_expression_in_directive1781 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_expression_in_expr_list1818 = new BitSet(new long[]{0x020001F000282202L,0xFFFFFFFF80020000L,0x0000000000003F3FL});
    public static final BitSet FOLLOW_EXPR_in_expression1852 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1856 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_OR_T_in_expression1868 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1872 = new BitSet(new long[]{0x020001F000282200L,0xFFFFFFFF80020000L,0x0000000000003F3FL});
    public static final BitSet FOLLOW_expression_in_expression1876 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_XOR_T_in_expression1888 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1892 = new BitSet(new long[]{0x020001F000282200L,0xFFFFFFFF80020000L,0x0000000000003F3FL});
    public static final BitSet FOLLOW_expression_in_expression1896 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_AND_T_in_expression1908 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1912 = new BitSet(new long[]{0x020001F000282200L,0xFFFFFFFF80020000L,0x0000000000003F3FL});
    public static final BitSet FOLLOW_expression_in_expression1916 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_EQUAL_T_in_expression1928 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1932 = new BitSet(new long[]{0x020001F000282200L,0xFFFFFFFF80020000L,0x0000000000003F3FL});
    public static final BitSet FOLLOW_expression_in_expression1936 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_PLUS_EQ_in_expression1949 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1953 = new BitSet(new long[]{0x020001F000282200L,0xFFFFFFFF80020000L,0x0000000000003F3FL});
    public static final BitSet FOLLOW_expression_in_expression1957 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_MINUS_EQ_in_expression1969 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1973 = new BitSet(new long[]{0x020001F000282200L,0xFFFFFFFF80020000L,0x0000000000003F3FL});
    public static final BitSet FOLLOW_expression_in_expression1977 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_MUL_EQ_in_expression1989 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1993 = new BitSet(new long[]{0x020001F000282200L,0xFFFFFFFF80020000L,0x0000000000003F3FL});
    public static final BitSet FOLLOW_expression_in_expression1997 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_DIV_EQ_in_expression2009 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2013 = new BitSet(new long[]{0x020001F000282200L,0xFFFFFFFF80020000L,0x0000000000003F3FL});
    public static final BitSet FOLLOW_expression_in_expression2017 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_DOT_EQ_in_expression2029 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2033 = new BitSet(new long[]{0x020001F000282200L,0xFFFFFFFF80020000L,0x0000000000003F3FL});
    public static final BitSet FOLLOW_expression_in_expression2037 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_PERCENT_EQ_in_expression2049 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2053 = new BitSet(new long[]{0x020001F000282200L,0xFFFFFFFF80020000L,0x0000000000003F3FL});
    public static final BitSet FOLLOW_expression_in_expression2057 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_BIT_AND_EQ_in_expression2069 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2073 = new BitSet(new long[]{0x020001F000282200L,0xFFFFFFFF80020000L,0x0000000000003F3FL});
    public static final BitSet FOLLOW_expression_in_expression2077 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_BIT_OR_EQ_in_expression2089 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2093 = new BitSet(new long[]{0x020001F000282200L,0xFFFFFFFF80020000L,0x0000000000003F3FL});
    public static final BitSet FOLLOW_expression_in_expression2097 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_POWER_EQ_in_expression2109 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2113 = new BitSet(new long[]{0x020001F000282200L,0xFFFFFFFF80020000L,0x0000000000003F3FL});
    public static final BitSet FOLLOW_expression_in_expression2117 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_LMOVE_EQ_in_expression2129 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2133 = new BitSet(new long[]{0x020001F000282200L,0xFFFFFFFF80020000L,0x0000000000003F3FL});
    public static final BitSet FOLLOW_expression_in_expression2137 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_RMOVE_EQ_in_expression2149 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2153 = new BitSet(new long[]{0x020001F000282200L,0xFFFFFFFF80020000L,0x0000000000003F3FL});
    public static final BitSet FOLLOW_expression_in_expression2157 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_QUESTION_T_in_expression2169 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2173 = new BitSet(new long[]{0x0000000000000000L,0x0000000000200000L});
    public static final BitSet FOLLOW_COLON_T_in_expression2176 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2180 = new BitSet(new long[]{0x020001F000282200L,0xFFFFFFFF80020000L,0x0000000000003F3FL});
    public static final BitSet FOLLOW_expression_in_expression2184 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_LOGICAL_OR_T_in_expression2199 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2203 = new BitSet(new long[]{0x020001F000282200L,0xFFFFFFFF80020000L,0x0000000000003F3FL});
    public static final BitSet FOLLOW_expression_in_expression2207 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_LOGICAL_AND_T_in_expression2219 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2223 = new BitSet(new long[]{0x020001F000282200L,0xFFFFFFFF80020000L,0x0000000000003F3FL});
    public static final BitSet FOLLOW_expression_in_expression2227 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_BIT_OR_T_in_expression2239 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2243 = new BitSet(new long[]{0x020001F000282200L,0xFFFFFFFF80020000L,0x0000000000003F3FL});
    public static final BitSet FOLLOW_expression_in_expression2247 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_POWER_T_in_expression2259 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2261 = new BitSet(new long[]{0x020001F000282200L,0xFFFFFFFF80020000L,0x0000000000003F3FL});
    public static final BitSet FOLLOW_expression_in_expression2263 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_REF_T_in_expression2275 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2279 = new BitSet(new long[]{0x020001F000282208L,0xFFFFFFFF80020000L,0x0000000000003F3FL});
    public static final BitSet FOLLOW_expression_in_expression2283 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_DOT_T_in_expression2296 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2300 = new BitSet(new long[]{0x020001F000282200L,0xFFFFFFFF80020000L,0x0000000000003F3FL});
    public static final BitSet FOLLOW_expression_in_expression2304 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_EQUAL_EQUAL_T_in_expression2316 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2320 = new BitSet(new long[]{0x020001F000282200L,0xFFFFFFFF80020000L,0x0000000000003F3FL});
    public static final BitSet FOLLOW_expression_in_expression2324 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_NOT_EQUAL_T_in_expression2336 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2340 = new BitSet(new long[]{0x020001F000282200L,0xFFFFFFFF80020000L,0x0000000000003F3FL});
    public static final BitSet FOLLOW_expression_in_expression2344 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_EQUAL_EQUAL_EQUAL_T_in_expression2356 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2360 = new BitSet(new long[]{0x020001F000282200L,0xFFFFFFFF80020000L,0x0000000000003F3FL});
    public static final BitSet FOLLOW_expression_in_expression2364 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_NOT_EQUAL_EQUAL_T_in_expression2376 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2380 = new BitSet(new long[]{0x020001F000282200L,0xFFFFFFFF80020000L,0x0000000000003F3FL});
    public static final BitSet FOLLOW_expression_in_expression2384 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_LT_T_in_expression2396 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2400 = new BitSet(new long[]{0x020001F000282200L,0xFFFFFFFF80020000L,0x0000000000003F3FL});
    public static final BitSet FOLLOW_expression_in_expression2404 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_MT_T_in_expression2416 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2420 = new BitSet(new long[]{0x020001F000282200L,0xFFFFFFFF80020000L,0x0000000000003F3FL});
    public static final BitSet FOLLOW_expression_in_expression2424 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_LE_T_in_expression2436 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2440 = new BitSet(new long[]{0x020001F000282200L,0xFFFFFFFF80020000L,0x0000000000003F3FL});
    public static final BitSet FOLLOW_expression_in_expression2444 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_ME_T_in_expression2456 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2458 = new BitSet(new long[]{0x020001F000282200L,0xFFFFFFFF80020000L,0x0000000000003F3FL});
    public static final BitSet FOLLOW_expression_in_expression2460 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_LSHIFT_T_in_expression2472 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2476 = new BitSet(new long[]{0x020001F000282200L,0xFFFFFFFF80020000L,0x0000000000003F3FL});
    public static final BitSet FOLLOW_expression_in_expression2480 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_RSHIFT_T_in_expression2492 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2496 = new BitSet(new long[]{0x020001F000282200L,0xFFFFFFFF80020000L,0x0000000000003F3FL});
    public static final BitSet FOLLOW_expression_in_expression2500 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_PLUS_T_in_expression2512 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2516 = new BitSet(new long[]{0x020001F000282208L,0xFFFFFFFF80020000L,0x0000000000003F3FL});
    public static final BitSet FOLLOW_expression_in_expression2520 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_MINUS_T_in_expression2533 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2537 = new BitSet(new long[]{0x020001F000282208L,0xFFFFFFFF80020000L,0x0000000000003F3FL});
    public static final BitSet FOLLOW_expression_in_expression2541 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_MUL_T_in_expression2554 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2558 = new BitSet(new long[]{0x020001F000282200L,0xFFFFFFFF80020000L,0x0000000000003F3FL});
    public static final BitSet FOLLOW_expression_in_expression2562 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_DIV_T_in_expression2574 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2578 = new BitSet(new long[]{0x020001F000282200L,0xFFFFFFFF80020000L,0x0000000000003F3FL});
    public static final BitSet FOLLOW_expression_in_expression2582 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_PERCENT_T_in_expression2594 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2598 = new BitSet(new long[]{0x020001F000282200L,0xFFFFFFFF80020000L,0x0000000000003F3FL});
    public static final BitSet FOLLOW_expression_in_expression2602 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_CAST_EXPR_in_expression2614 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_cast_option_in_expression2616 = new BitSet(new long[]{0x020001F000282200L,0xFFFFFFFF80020000L,0x0000000000003F3FL});
    public static final BitSet FOLLOW_expression_in_expression2620 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_TILDA_T_in_expression2632 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2636 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_EXC_NOT_T_in_expression2648 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2650 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_POSTFIX_EXPR_in_expression2662 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2666 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x00000000000000C0L});
    public static final BitSet FOLLOW_plus_minus_in_expression2668 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_PREFIX_EXPR_in_expression2680 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_plus_minus_in_expression2682 = new BitSet(new long[]{0x020001F000282200L,0xFFFFFFFF80020000L,0x0000000000003FFFL});
    public static final BitSet FOLLOW_expression_in_expression2687 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_INSTANCEOF_T_in_expression2699 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2703 = new BitSet(new long[]{0x0004000000082000L,0x0000000000008000L});
    public static final BitSet FOLLOW_class_name_reference_in_expression2705 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_AT_T_in_expression2716 = new BitSet(new long[]{0x0200000000082000L});
    public static final BitSet FOLLOW_variable_in_expression2719 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_AT_T_in_expression2729 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_scalar_in_expression2732 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_list_decl_in_expression2742 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ARRAY_DECL_in_expression2753 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_array_pair_list_in_expression2755 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_NEW_T_in_expression2768 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_class_name_reference_in_expression2770 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_CLONE_T_in_expression2785 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_variable_in_expression2787 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_EXIT_T_in_expression2799 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2801 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_UNSET_T_in_expression2810 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_variable_in_expression2812 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_lambda_function_declaration_in_expression2819 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_BACKTRICKLITERAL_in_expression2825 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_plus_minus0 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_171_in_cast_option2864 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_172_in_cast_option2875 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_173_in_cast_option2883 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_174_in_cast_option2895 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_175_in_cast_option2905 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_179_in_cast_option2914 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_178_in_cast_option2924 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_176_in_cast_option2933 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_177_in_cast_option2944 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_UNSET_T_in_cast_option2953 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_CLONE_T_in_cast_option2963 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_METHOD_DECL_in_lambda_function_declaration2982 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_REF_T_in_lambda_function_declaration2984 = new BitSet(new long[]{0x0000000000001800L,0x0000000000000800L});
    public static final BitSet FOLLOW_parameter_list_in_lambda_function_declaration2987 = new BitSet(new long[]{0x0000000000001000L,0x0000000000000800L});
    public static final BitSet FOLLOW_USE_T_in_lambda_function_declaration2992 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_list_in_lambda_function_declaration2994 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_block_in_lambda_function_declaration3006 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_dynamic_name_reference_in_class_name_reference3039 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_fully_qualified_class_name_in_class_name_reference3050 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_base_variable_with_function_calls_in_dynamic_name_reference3073 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_CALL_in_dynamic_name_reference3085 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_dynamic_name_reference_in_dynamic_name_reference3089 = new BitSet(new long[]{0x0000060000020000L});
    public static final BitSet FOLLOW_object_property_in_dynamic_name_reference3093 = new BitSet(new long[]{0x0000000040000008L});
    public static final BitSet FOLLOW_ctor_arguments_in_dynamic_name_reference3095 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_LIST_T_in_list_decl3119 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_assignment_list_in_list_decl3121 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_assignment_element_in_assignment_list3153 = new BitSet(new long[]{0x0200000000082002L,0x0000000000000000L,0x0000000000000400L});
    public static final BitSet FOLLOW_variable_in_assignment_element3171 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_list_decl_in_assignment_element3181 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_array_pair_element_in_array_pair_list3213 = new BitSet(new long[]{0x020001F000282202L,0xFFFFFFFF80020080L,0x0000000000003F3FL});
    public static final BitSet FOLLOW_ARROW_T_in_array_pair_element3234 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_array_pair_element3238 = new BitSet(new long[]{0x020001F000282200L,0xFFFFFFFF80020000L,0x0000000000003F3FL});
    public static final BitSet FOLLOW_expression_in_array_pair_element3242 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_expression_in_array_pair_element3253 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_variable_temp_in_variable3288 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_base_variable_with_function_calls_in_variable_temp3312 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_CALL_in_variable_temp3324 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_variable_temp_in_variable_temp3328 = new BitSet(new long[]{0x0000060000020000L});
    public static final BitSet FOLLOW_object_property_in_variable_temp3332 = new BitSet(new long[]{0x0000000040000008L});
    public static final BitSet FOLLOW_ctor_arguments_in_variable_temp3334 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_VAR_DECL_in_base_variable_with_function_calls3360 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_fully_qualified_class_name_in_base_variable_with_function_calls3362 = new BitSet(new long[]{0x0000060000020000L});
    public static final BitSet FOLLOW_object_property_in_base_variable_with_function_calls3367 = new BitSet(new long[]{0x0000000040000008L});
    public static final BitSet FOLLOW_ctor_arguments_in_base_variable_with_function_calls3369 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_CALL_in_base_variable_with_function_calls3390 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_fully_qualified_class_name_in_base_variable_with_function_calls3392 = new BitSet(new long[]{0x0000000040000000L});
    public static final BitSet FOLLOW_ctor_arguments_in_base_variable_with_function_calls3394 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_VAR_in_object_property3433 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_DOLLAR_T_in_object_property3435 = new BitSet(new long[]{0x0004000000000000L,0x0000000000000000L,0x0000000000020000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_object_property3438 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_VAR_in_object_property3452 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_DOLLAR_T_in_object_property3454 = new BitSet(new long[]{0x020001F000282200L,0xFFFFFFFF80020000L,0x0000000000023F3FL});
    public static final BitSet FOLLOW_expression_in_object_property3457 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_INDEX_in_object_property3469 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_object_property_in_object_property3473 = new BitSet(new long[]{0x020001F000282208L,0xFFFFFFFF80020000L,0x0000000000003F3FL});
    public static final BitSet FOLLOW_expression_in_object_property3475 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_HASH_INDEX_in_object_property3488 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_object_property_in_object_property3492 = new BitSet(new long[]{0x020001F000282208L,0xFFFFFFFF80020000L,0x0000000000003F3FL});
    public static final BitSet FOLLOW_expression_in_object_property3494 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_ARGU_in_ctor_arguments3523 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_list_in_ctor_arguments3525 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_VAR_DECL_in_pure_variable3547 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_REF_T_in_pure_variable3549 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000020000L});
    public static final BitSet FOLLOW_DOLLAR_T_in_pure_variable3552 = new BitSet(new long[]{0x0004000000000000L,0x0000000000000000L,0x0000000000020000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_pure_variable3555 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_SCALAR_in_scalar3586 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_constant_in_scalar3588 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_INTLITERAL_in_constant3614 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_FLOATLITERAL_in_constant3626 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_STRINGLITERAL_in_constant3634 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_DOUBLELITERRAL_in_constant3646 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_common_scalar_in_constant3654 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IDENTIFIER_in_constant3666 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_fully_qualified_class_name_in_constant3678 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_common_scalar0 = new BitSet(new long[]{0x0000000000000002L});

}