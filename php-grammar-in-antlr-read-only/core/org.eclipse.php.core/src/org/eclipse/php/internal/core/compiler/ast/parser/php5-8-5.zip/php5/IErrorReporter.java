package org.eclipse.php.internal.core.compiler.ast.parser.php5;

public interface IErrorReporter {
    void reportError(String error);
}
