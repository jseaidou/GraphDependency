// $ANTLR 3.1.3 Mar 17, 2009 19:23:44 /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g 2009-08-05 22:57:04

  package org.eclipse.php.internal.core.compiler.ast.parser.php5;
  
  import org.antlr.runtime.*;
  import org.antlr.runtime.tree.*;
  import org.antlr.runtime.BitSet;
  
  import java.util.*;
	import org.eclipse.dltk.ast.*;
	import org.eclipse.dltk.ast.declarations.*;
	import org.eclipse.dltk.ast.expressions.*;
	import org.eclipse.dltk.ast.references.*;
	import org.eclipse.dltk.ast.statements.*;
	import org.eclipse.php.internal.core.compiler.ast.nodes.*;
	import org.eclipse.php.internal.core.compiler.ast.parser.*;
	import org.eclipse.php.internal.core.ast.scanner.php5.*;


import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;

import org.antlr.runtime.tree.*;

public class CompilerAstParser extends AbstractASTParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "ModuleDeclaration", "ClassDeclaration", "PROG", "CLASS_BODY", "FIELD_DECL", "METHOD_DECL", "TYPE", "PARAMETER", "BLOCK", "VAR_DECL", "STATEMENT", "CONDITION", "LIST", "INDEX", "MEMBERACCESS", "CALL", "ELIST", "EXPR", "ASSIGN", "LIST_DECL", "SCALAR_ELEMENT", "SCALAR_VAR", "CAST", "LABEL", "ITERATE", "USE_DECL", "ARGU", "CALLED_OBJ", "PREFIX", "POSTFIX", "NAMESPACE", "EMPTYSTATEMENT", "SCALAR", "ARRAY_DECL", "PREFIX_EXPR", "POSTFIX_EXPR", "CAST_EXPR", "UNARY_EXPR", "VAR", "HASH_INDEX", "SOC_T", "SOC_PHP_T", "EOC_T", "LEFT_PARETHESIS", "RIGHT_PARETHESIS", "SEMI_COLON", "CLASS_T", "IDENTIFIER", "EXTENDS_T", "IMPLEMENTS_T", "LEFT_BRACKET", "RIGHT_BRACKET", "INTERFACE_T", "FUNCTION_T", "REF_T", "CONST_T", "WHILE_T", "DO_T", "FOR_T", "SWITCH_T", "BREAK_T", "CONTINUE_T", "RETURN_T", "GLOBAL_T", "STATIC_T", "ECHO_T", "FOREACH_T", "AS_T", "ARROW_T", "DECLARE_T", "TRY_T", "THROW_T", "USE_T", "INCLUDE_T", "INCLUDE_ONCE_T", "REQUIRE_T", "REQUIRE_ONCE_T", "STRINGLITERAL", "DOMAIN_T", "COMMA_T", "EQUAL_T", "IF_T", "ELSEIF_T", "ELSE_T", "COLON_T", "ENDIF_T", "ENDSWITCH_T", "CASE_T", "DEFAULT_T", "CATCH_T", "ENDFOR_T", "ENDWHILE_T", "ENDFOREACH_T", "ENDDECLARE_T", "OR_T", "XOR_T", "AND_T", "PLUS_EQ", "MINUS_EQ", "MUL_EQ", "DIV_EQ", "DOT_EQ", "PERCENT_EQ", "BIT_AND_EQ", "BIT_OR_EQ", "POWER_EQ", "LMOVE_EQ", "RMOVE_EQ", "QUESTION_T", "LOGICAL_OR_T", "LOGICAL_AND_T", "BIT_OR_T", "POWER_T", "DOT_T", "EQUAL_EQUAL_T", "NOT_EQUAL_T", "EQUAL_EQUAL_EQUAL_T", "NOT_EQUAL_EQUAL_T", "LT_T", "MT_T", "LE_T", "ME_T", "LSHIFT_T", "RSHIFT_T", "PLUS_T", "MINUS_T", "MUL_T", "DIV_T", "PERCENT_T", "CLONE_T", "TILDA_T", "EXC_NOT_T", "PLUS_PLUS_T", "MINUS_MINUS_T", "INSTANCEOF_T", "AT_T", "LIST_T", "NEW_T", "BACKTRICKLITERAL", "PRINT_T", "SINGLE_ARROW_T", "LEFT_OPEN_RECT", "RIGHT_OPEN_RECT", "DOLLAR_T", "INTLITERAL", "FLOATLITERAL", "DOUBLELITERRAL", "IntegerNumber", "LongSuffix", "HexPrefix", "HexDigit", "STATIC", "NonIntegerNumber", "FloatSuffix", "DoubleSuffix", "Exponent", "EscapeSequence", "IdentifierStart", "IdentifierPart", "WS", "COMMENT", "LINE_COMMENT", "'__halt_compiler'", "'abstract'", "'final'", "'var'", "'public'", "'protected'", "'private'", "'bool'", "'boolean'", "'int'", "'float'", "'double'", "'real'", "'string'", "'unset'", "'object'", "'array'", "'__CLASS__'", "'__DIR__'", "'__FILE__'", "'__FUNCTION__'", "'__METHOD__'", "'__NAMESPACE__'"
    };
    public static final int RIGHT_OPEN_RECT=146;
    public static final int ENDFOR_T=94;
    public static final int LOGICAL_OR_T=113;
    public static final int CONDITION=15;
    public static final int DOMAIN_T=82;
    public static final int T__167=167;
    public static final int EOF=-1;
    public static final int T__168=168;
    public static final int EQUAL_EQUAL_T=118;
    public static final int T__166=166;
    public static final int STATEMENT=14;
    public static final int TYPE=10;
    public static final int EOC_T=46;
    public static final int CAST_EXPR=40;
    public static final int NOT_EQUAL_EQUAL_T=121;
    public static final int AT_T=139;
    public static final int NonIntegerNumber=156;
    public static final int FloatSuffix=157;
    public static final int RIGHT_BRACKET=55;
    public static final int AND_T=100;
    public static final int ARGU=30;
    public static final int FOR_T=62;
    public static final int MINUS_MINUS_T=137;
    public static final int RMOVE_EQ=111;
    public static final int STATIC=155;
    public static final int WHILE_T=60;
    public static final int ARRAY_DECL=37;
    public static final int MUL_EQ=103;
    public static final int SEMI_COLON=49;
    public static final int INTERFACE_T=56;
    public static final int OR_T=98;
    public static final int INTLITERAL=148;
    public static final int PLUS_EQ=101;
    public static final int ENDDECLARE_T=97;
    public static final int PLUS_T=128;
    public static final int MINUS_EQ=102;
    public static final int LongSuffix=152;
    public static final int REQUIRE_T=79;
    public static final int ENDFOREACH_T=96;
    public static final int WS=163;
    public static final int DO_T=61;
    public static final int EQUAL_T=84;
    public static final int COLON_T=88;
    public static final int USE_T=76;
    public static final int SOC_PHP_T=45;
    public static final int MINUS_T=129;
    public static final int CALL=19;
    public static final int SCALAR_ELEMENT=24;
    public static final int POWER_EQ=109;
    public static final int INCLUDE_ONCE_T=78;
    public static final int BIT_AND_EQ=107;
    public static final int LEFT_BRACKET=54;
    public static final int DOUBLELITERRAL=150;
    public static final int UNARY_EXPR=41;
    public static final int CATCH_T=93;
    public static final int IMPLEMENTS_T=53;
    public static final int HexDigit=154;
    public static final int DEFAULT_T=92;
    public static final int REQUIRE_ONCE_T=80;
    public static final int CONST_T=59;
    public static final int FUNCTION_T=57;
    public static final int MUL_T=130;
    public static final int BIT_OR_EQ=108;
    public static final int BIT_OR_T=115;
    public static final int FOREACH_T=70;
    public static final int PREFIX_EXPR=38;
    public static final int FIELD_DECL=8;
    public static final int CLASS_BODY=7;
    public static final int LIST_T=140;
    public static final int LIST_DECL=23;
    public static final int BACKTRICKLITERAL=142;
    public static final int ITERATE=28;
    public static final int RETURN_T=66;
    public static final int LEFT_PARETHESIS=47;
    public static final int DoubleSuffix=158;
    public static final int ENDWHILE_T=95;
    public static final int STRINGLITERAL=81;
    public static final int BLOCK=12;
    public static final int CONTINUE_T=65;
    public static final int EXTENDS_T=52;
    public static final int PRINT_T=143;
    public static final int FLOATLITERAL=149;
    public static final int ENDSWITCH_T=90;
    public static final int CAST=26;
    public static final int PREFIX=32;
    public static final int TRY_T=74;
    public static final int XOR_T=99;
    public static final int POSTFIX=33;
    public static final int HASH_INDEX=43;
    public static final int PERCENT_EQ=106;
    public static final int INCLUDE_T=77;
    public static final int AS_T=71;
    public static final int VAR_DECL=13;
    public static final int DIV_T=131;
    public static final int COMMA_T=83;
    public static final int STATIC_T=68;
    public static final int DOT_T=117;
    public static final int ENDIF_T=89;
    public static final int POSTFIX_EXPR=39;
    public static final int CALLED_OBJ=31;
    public static final int DIV_EQ=104;
    public static final int GLOBAL_T=67;
    public static final int ELIST=20;
    public static final int IF_T=85;
    public static final int PARAMETER=11;
    public static final int MT_T=123;
    public static final int SCALAR=36;
    public static final int ELSE_T=87;
    public static final int SINGLE_ARROW_T=144;
    public static final int VAR=42;
    public static final int RSHIFT_T=127;
    public static final int COMMENT=164;
    public static final int HexPrefix=153;
    public static final int ARROW_T=72;
    public static final int LINE_COMMENT=165;
    public static final int EQUAL_EQUAL_EQUAL_T=120;
    public static final int CLONE_T=133;
    public static final int IdentifierStart=161;
    public static final int DECLARE_T=73;
    public static final int THROW_T=75;
    public static final int REF_T=58;
    public static final int LIST=16;
    public static final int NAMESPACE=34;
    public static final int EMPTYSTATEMENT=35;
    public static final int NEW_T=141;
    public static final int MEMBERACCESS=18;
    public static final int PLUS_PLUS_T=136;
    public static final int EscapeSequence=160;
    public static final int CLASS_T=50;
    public static final int IntegerNumber=151;
    public static final int ECHO_T=69;
    public static final int DOLLAR_T=147;
    public static final int SOC_T=44;
    public static final int METHOD_DECL=9;
    public static final int Exponent=159;
    public static final int LE_T=124;
    public static final int PERCENT_T=132;
    public static final int INDEX=17;
    public static final int PROG=6;
    public static final int EXPR=21;
    public static final int USE_DECL=29;
    public static final int NOT_EQUAL_T=119;
    public static final int POWER_T=116;
    public static final int IDENTIFIER=51;
    public static final int LEFT_OPEN_RECT=145;
    public static final int LMOVE_EQ=110;
    public static final int SCALAR_VAR=25;
    public static final int TILDA_T=134;
    public static final int IdentifierPart=162;
    public static final int T__184=184;
    public static final int SWITCH_T=63;
    public static final int T__183=183;
    public static final int T__186=186;
    public static final int T__185=185;
    public static final int T__188=188;
    public static final int T__187=187;
    public static final int LOGICAL_AND_T=114;
    public static final int QUESTION_T=112;
    public static final int LSHIFT_T=126;
    public static final int T__180=180;
    public static final int INSTANCEOF_T=138;
    public static final int ELSEIF_T=86;
    public static final int T__182=182;
    public static final int T__181=181;
    public static final int LT_T=122;
    public static final int ModuleDeclaration=4;
    public static final int T__175=175;
    public static final int T__174=174;
    public static final int T__173=173;
    public static final int T__172=172;
    public static final int T__179=179;
    public static final int T__178=178;
    public static final int T__177=177;
    public static final int T__176=176;
    public static final int ME_T=125;
    public static final int LABEL=27;
    public static final int T__171=171;
    public static final int T__170=170;
    public static final int RIGHT_PARETHESIS=48;
    public static final int ASSIGN=22;
    public static final int EXC_NOT_T=135;
    public static final int BREAK_T=64;
    public static final int CASE_T=91;
    public static final int DOT_EQ=105;
    public static final int T__169=169;
    public static final int ClassDeclaration=5;

    // delegates
    // delegators


        public CompilerAstParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public CompilerAstParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        
    protected TreeAdaptor adaptor = new CommonTreeAdaptor();

    public void setTreeAdaptor(TreeAdaptor adaptor) {
        this.adaptor = adaptor;
    }
    public TreeAdaptor getTreeAdaptor() {
        return adaptor;
    }

    public String[] getTokenNames() { return CompilerAstParser.tokenNames; }
    public String getGrammarFileName() { return "/home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g"; }


        private IErrorReporter errorReporter = null;
        public void setErrorReporter(IErrorReporter errorReporter) {
            this.errorReporter = errorReporter;
        }
    //    public void emitErrorMessage(String msg) {
    //        errorReporter.reportError(msg);
    //    }
        
        private List errors = new LinkedList();
        public void displayRecognitionError(String[] tokenNames,
                                            RecognitionException e) {
            String hdr = getErrorHeader(e);
            String msg = getErrorMessage(e, tokenNames);
            errors.add(hdr + " " + msg);
        }
        public List getErrors() {
            return errors;
        }


    public static class php_source_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "php_source"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:111:1: php_source : ( SOC_T | SOC_PHP_T ) ( top_statement_list )? EOC_T -> ^( ModuleDeclaration ( top_statement_list )? ) ;
    public final CompilerAstParser.php_source_return php_source() throws RecognitionException {
        CompilerAstParser.php_source_return retval = new CompilerAstParser.php_source_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token SOC_T1=null;
        Token SOC_PHP_T2=null;
        Token EOC_T4=null;
        CompilerAstParser.top_statement_list_return top_statement_list3 = null;


        SLAST SOC_T1_tree=null;
        SLAST SOC_PHP_T2_tree=null;
        SLAST EOC_T4_tree=null;
        RewriteRuleTokenStream stream_SOC_T=new RewriteRuleTokenStream(adaptor,"token SOC_T");
        RewriteRuleTokenStream stream_EOC_T=new RewriteRuleTokenStream(adaptor,"token EOC_T");
        RewriteRuleTokenStream stream_SOC_PHP_T=new RewriteRuleTokenStream(adaptor,"token SOC_PHP_T");
        RewriteRuleSubtreeStream stream_top_statement_list=new RewriteRuleSubtreeStream(adaptor,"rule top_statement_list");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:121:3: ( ( SOC_T | SOC_PHP_T ) ( top_statement_list )? EOC_T -> ^( ModuleDeclaration ( top_statement_list )? ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:121:5: ( SOC_T | SOC_PHP_T ) ( top_statement_list )? EOC_T
            {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:121:5: ( SOC_T | SOC_PHP_T )
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0==SOC_T) ) {
                alt1=1;
            }
            else if ( (LA1_0==SOC_PHP_T) ) {
                alt1=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 1, 0, input);

                throw nvae;
            }
            switch (alt1) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:121:6: SOC_T
                    {
                    SOC_T1=(Token)match(input,SOC_T,FOLLOW_SOC_T_in_php_source271); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SOC_T.add(SOC_T1);

                    if ( state.backtracking==0 ) {

                          token = (CommonToken)SOC_T1;
                          startIndex = token.getStartIndex();
                        
                    }

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:126:5: SOC_PHP_T
                    {
                    SOC_PHP_T2=(Token)match(input,SOC_PHP_T,FOLLOW_SOC_PHP_T_in_php_source283); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SOC_PHP_T.add(SOC_PHP_T2);

                    if ( state.backtracking==0 ) {

                          token = (CommonToken)SOC_PHP_T2;
                          startIndex = token.getStartIndex();
                        
                    }

                    }
                    break;

            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:131:9: ( top_statement_list )?
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==LEFT_PARETHESIS||(LA2_0>=SEMI_COLON && LA2_0<=IDENTIFIER)||LA2_0==LEFT_BRACKET||(LA2_0>=INTERFACE_T && LA2_0<=REF_T)||(LA2_0>=WHILE_T && LA2_0<=FOREACH_T)||(LA2_0>=DECLARE_T && LA2_0<=STRINGLITERAL)||LA2_0==IF_T||(LA2_0>=PLUS_T && LA2_0<=MINUS_T)||(LA2_0>=CLONE_T && LA2_0<=MINUS_MINUS_T)||(LA2_0>=AT_T && LA2_0<=PRINT_T)||(LA2_0>=DOLLAR_T && LA2_0<=DOUBLELITERRAL)||(LA2_0>=166 && LA2_0<=168)||(LA2_0>=182 && LA2_0<=188)) ) {
                alt2=1;
            }
            switch (alt2) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:131:9: top_statement_list
                    {
                    pushFollow(FOLLOW_top_statement_list_in_php_source298);
                    top_statement_list3=top_statement_list();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_top_statement_list.add(top_statement_list3.getTree());

                    }
                    break;

            }

            EOC_T4=(Token)match(input,EOC_T,FOLLOW_EOC_T_in_php_source307); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_EOC_T.add(EOC_T4);

            if ( state.backtracking==0 ) {

                  token = (CommonToken)EOC_T4;
                  endIndex = token.getStopIndex();
                
            }


            // AST REWRITE
            // elements: top_statement_list
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 137:5: -> ^( ModuleDeclaration ( top_statement_list )? )
            {
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:137:9: ^( ModuleDeclaration ( top_statement_list )? )
                {
                SLAST root_1 = (SLAST)adaptor.nil();
                root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(ModuleDeclaration, "ModuleDeclaration"), root_1);

                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:137:29: ( top_statement_list )?
                if ( stream_top_statement_list.hasNext() ) {
                    adaptor.addChild(root_1, stream_top_statement_list.nextTree());

                }
                stream_top_statement_list.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST phpSourceToken = retval.tree;
                phpSourceToken.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "php_source"

    public static class top_statement_list_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "top_statement_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:141:1: top_statement_list : ( top_statement )+ ;
    public final CompilerAstParser.top_statement_list_return top_statement_list() throws RecognitionException {
        CompilerAstParser.top_statement_list_return retval = new CompilerAstParser.top_statement_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        CompilerAstParser.top_statement_return top_statement5 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:142:3: ( ( top_statement )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:142:5: ( top_statement )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:142:5: ( top_statement )+
            int cnt3=0;
            loop3:
            do {
                int alt3=2;
                int LA3_0 = input.LA(1);

                if ( (LA3_0==LEFT_PARETHESIS||(LA3_0>=SEMI_COLON && LA3_0<=IDENTIFIER)||LA3_0==LEFT_BRACKET||(LA3_0>=INTERFACE_T && LA3_0<=REF_T)||(LA3_0>=WHILE_T && LA3_0<=FOREACH_T)||(LA3_0>=DECLARE_T && LA3_0<=STRINGLITERAL)||LA3_0==IF_T||(LA3_0>=PLUS_T && LA3_0<=MINUS_T)||(LA3_0>=CLONE_T && LA3_0<=MINUS_MINUS_T)||(LA3_0>=AT_T && LA3_0<=PRINT_T)||(LA3_0>=DOLLAR_T && LA3_0<=DOUBLELITERRAL)||(LA3_0>=166 && LA3_0<=168)||(LA3_0>=182 && LA3_0<=188)) ) {
                    alt3=1;
                }


                switch (alt3) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:142:5: top_statement
            	    {
            	    pushFollow(FOLLOW_top_statement_in_top_statement_list342);
            	    top_statement5=top_statement();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, top_statement5.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt3 >= 1 ) break loop3;
            	    if (state.backtracking>0) {state.failed=true; return retval;}
                        EarlyExitException eee =
                            new EarlyExitException(3, input);
                        throw eee;
                }
                cnt3++;
            } while (true);


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "top_statement_list"

    public static class top_statement_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "top_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:145:1: top_statement : ( statement | function_declaration_statement | class_declaration_statement | halt_compiler_statement );
    public final CompilerAstParser.top_statement_return top_statement() throws RecognitionException {
        CompilerAstParser.top_statement_return retval = new CompilerAstParser.top_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        CompilerAstParser.statement_return statement6 = null;

        CompilerAstParser.function_declaration_statement_return function_declaration_statement7 = null;

        CompilerAstParser.class_declaration_statement_return class_declaration_statement8 = null;

        CompilerAstParser.halt_compiler_statement_return halt_compiler_statement9 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:146:3: ( statement | function_declaration_statement | class_declaration_statement | halt_compiler_statement )
            int alt4=4;
            switch ( input.LA(1) ) {
            case LEFT_PARETHESIS:
            case SEMI_COLON:
            case IDENTIFIER:
            case LEFT_BRACKET:
            case REF_T:
            case WHILE_T:
            case DO_T:
            case FOR_T:
            case SWITCH_T:
            case BREAK_T:
            case CONTINUE_T:
            case RETURN_T:
            case GLOBAL_T:
            case STATIC_T:
            case ECHO_T:
            case FOREACH_T:
            case DECLARE_T:
            case TRY_T:
            case THROW_T:
            case USE_T:
            case INCLUDE_T:
            case INCLUDE_ONCE_T:
            case REQUIRE_T:
            case REQUIRE_ONCE_T:
            case STRINGLITERAL:
            case IF_T:
            case PLUS_T:
            case MINUS_T:
            case CLONE_T:
            case TILDA_T:
            case EXC_NOT_T:
            case PLUS_PLUS_T:
            case MINUS_MINUS_T:
            case AT_T:
            case LIST_T:
            case NEW_T:
            case BACKTRICKLITERAL:
            case PRINT_T:
            case DOLLAR_T:
            case INTLITERAL:
            case FLOATLITERAL:
            case DOUBLELITERRAL:
            case 182:
            case 183:
            case 184:
            case 185:
            case 186:
            case 187:
            case 188:
                {
                alt4=1;
                }
                break;
            case FUNCTION_T:
                {
                alt4=2;
                }
                break;
            case CLASS_T:
            case INTERFACE_T:
            case 167:
            case 168:
                {
                alt4=3;
                }
                break;
            case 166:
                {
                alt4=4;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 4, 0, input);

                throw nvae;
            }

            switch (alt4) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:146:5: statement
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_statement_in_top_statement356);
                    statement6=statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, statement6.getTree());

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:147:5: function_declaration_statement
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_function_declaration_statement_in_top_statement362);
                    function_declaration_statement7=function_declaration_statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, function_declaration_statement7.getTree());

                    }
                    break;
                case 3 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:148:5: class_declaration_statement
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_class_declaration_statement_in_top_statement368);
                    class_declaration_statement8=class_declaration_statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, class_declaration_statement8.getTree());

                    }
                    break;
                case 4 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:149:5: halt_compiler_statement
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_halt_compiler_statement_in_top_statement374);
                    halt_compiler_statement9=halt_compiler_statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, halt_compiler_statement9.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "top_statement"

    public static class inner_statement_list_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "inner_statement_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:152:1: inner_statement_list : ( inner_statement )+ ;
    public final CompilerAstParser.inner_statement_list_return inner_statement_list() throws RecognitionException {
        CompilerAstParser.inner_statement_list_return retval = new CompilerAstParser.inner_statement_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        CompilerAstParser.inner_statement_return inner_statement10 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:153:3: ( ( inner_statement )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:153:5: ( inner_statement )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:153:5: ( inner_statement )+
            int cnt5=0;
            loop5:
            do {
                int alt5=2;
                int LA5_0 = input.LA(1);

                if ( (LA5_0==LEFT_PARETHESIS||(LA5_0>=SEMI_COLON && LA5_0<=IDENTIFIER)||LA5_0==LEFT_BRACKET||(LA5_0>=INTERFACE_T && LA5_0<=REF_T)||(LA5_0>=WHILE_T && LA5_0<=FOREACH_T)||(LA5_0>=DECLARE_T && LA5_0<=STRINGLITERAL)||LA5_0==IF_T||(LA5_0>=PLUS_T && LA5_0<=MINUS_T)||(LA5_0>=CLONE_T && LA5_0<=MINUS_MINUS_T)||(LA5_0>=AT_T && LA5_0<=PRINT_T)||(LA5_0>=DOLLAR_T && LA5_0<=DOUBLELITERRAL)||(LA5_0>=166 && LA5_0<=168)||(LA5_0>=182 && LA5_0<=188)) ) {
                    alt5=1;
                }


                switch (alt5) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:153:6: inner_statement
            	    {
            	    pushFollow(FOLLOW_inner_statement_in_inner_statement_list390);
            	    inner_statement10=inner_statement();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, inner_statement10.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt5 >= 1 ) break loop5;
            	    if (state.backtracking>0) {state.failed=true; return retval;}
                        EarlyExitException eee =
                            new EarlyExitException(5, input);
                        throw eee;
                }
                cnt5++;
            } while (true);


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "inner_statement_list"

    public static class inner_statement_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "inner_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:156:1: inner_statement : ( statement | function_declaration_statement | class_declaration_statement | halt_compiler_statement );
    public final CompilerAstParser.inner_statement_return inner_statement() throws RecognitionException {
        CompilerAstParser.inner_statement_return retval = new CompilerAstParser.inner_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        CompilerAstParser.statement_return statement11 = null;

        CompilerAstParser.function_declaration_statement_return function_declaration_statement12 = null;

        CompilerAstParser.class_declaration_statement_return class_declaration_statement13 = null;

        CompilerAstParser.halt_compiler_statement_return halt_compiler_statement14 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:157:3: ( statement | function_declaration_statement | class_declaration_statement | halt_compiler_statement )
            int alt6=4;
            switch ( input.LA(1) ) {
            case LEFT_PARETHESIS:
            case SEMI_COLON:
            case IDENTIFIER:
            case LEFT_BRACKET:
            case REF_T:
            case WHILE_T:
            case DO_T:
            case FOR_T:
            case SWITCH_T:
            case BREAK_T:
            case CONTINUE_T:
            case RETURN_T:
            case GLOBAL_T:
            case STATIC_T:
            case ECHO_T:
            case FOREACH_T:
            case DECLARE_T:
            case TRY_T:
            case THROW_T:
            case USE_T:
            case INCLUDE_T:
            case INCLUDE_ONCE_T:
            case REQUIRE_T:
            case REQUIRE_ONCE_T:
            case STRINGLITERAL:
            case IF_T:
            case PLUS_T:
            case MINUS_T:
            case CLONE_T:
            case TILDA_T:
            case EXC_NOT_T:
            case PLUS_PLUS_T:
            case MINUS_MINUS_T:
            case AT_T:
            case LIST_T:
            case NEW_T:
            case BACKTRICKLITERAL:
            case PRINT_T:
            case DOLLAR_T:
            case INTLITERAL:
            case FLOATLITERAL:
            case DOUBLELITERRAL:
            case 182:
            case 183:
            case 184:
            case 185:
            case 186:
            case 187:
            case 188:
                {
                alt6=1;
                }
                break;
            case FUNCTION_T:
                {
                alt6=2;
                }
                break;
            case CLASS_T:
            case INTERFACE_T:
            case 167:
            case 168:
                {
                alt6=3;
                }
                break;
            case 166:
                {
                alt6=4;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 6, 0, input);

                throw nvae;
            }

            switch (alt6) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:157:5: statement
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_statement_in_inner_statement407);
                    statement11=statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, statement11.getTree());

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:158:5: function_declaration_statement
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_function_declaration_statement_in_inner_statement413);
                    function_declaration_statement12=function_declaration_statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, function_declaration_statement12.getTree());

                    }
                    break;
                case 3 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:159:5: class_declaration_statement
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_class_declaration_statement_in_inner_statement419);
                    class_declaration_statement13=class_declaration_statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, class_declaration_statement13.getTree());

                    }
                    break;
                case 4 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:160:5: halt_compiler_statement
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_halt_compiler_statement_in_inner_statement425);
                    halt_compiler_statement14=halt_compiler_statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, halt_compiler_statement14.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "inner_statement"

    public static class halt_compiler_statement_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "halt_compiler_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:163:1: halt_compiler_statement : '__halt_compiler' LEFT_PARETHESIS RIGHT_PARETHESIS SEMI_COLON -> '__halt_compiler' ;
    public final CompilerAstParser.halt_compiler_statement_return halt_compiler_statement() throws RecognitionException {
        CompilerAstParser.halt_compiler_statement_return retval = new CompilerAstParser.halt_compiler_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token string_literal15=null;
        Token LEFT_PARETHESIS16=null;
        Token RIGHT_PARETHESIS17=null;
        Token SEMI_COLON18=null;

        SLAST string_literal15_tree=null;
        SLAST LEFT_PARETHESIS16_tree=null;
        SLAST RIGHT_PARETHESIS17_tree=null;
        SLAST SEMI_COLON18_tree=null;
        RewriteRuleTokenStream stream_LEFT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token LEFT_PARETHESIS");
        RewriteRuleTokenStream stream_SEMI_COLON=new RewriteRuleTokenStream(adaptor,"token SEMI_COLON");
        RewriteRuleTokenStream stream_166=new RewriteRuleTokenStream(adaptor,"token 166");
        RewriteRuleTokenStream stream_RIGHT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token RIGHT_PARETHESIS");

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:164:3: ( '__halt_compiler' LEFT_PARETHESIS RIGHT_PARETHESIS SEMI_COLON -> '__halt_compiler' )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:164:5: '__halt_compiler' LEFT_PARETHESIS RIGHT_PARETHESIS SEMI_COLON
            {
            string_literal15=(Token)match(input,166,FOLLOW_166_in_halt_compiler_statement440); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_166.add(string_literal15);

            LEFT_PARETHESIS16=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_halt_compiler_statement442); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS16);

            RIGHT_PARETHESIS17=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_halt_compiler_statement444); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS17);

            SEMI_COLON18=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_halt_compiler_statement446); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON18);



            // AST REWRITE
            // elements: 166
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 164:69: -> '__halt_compiler'
            {
                adaptor.addChild(root_0, stream_166.nextNode());

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "halt_compiler_statement"

    public static class class_declaration_statement_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "class_declaration_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:167:1: class_declaration_statement : ( ( ( class_entr_type )? CLASS_T IDENTIFIER ( EXTENDS_T fully_qualified_class_name )? ( IMPLEMENTS_T fully_qualified_class_name_list )? LEFT_BRACKET ( class_statement )* RIGHT_BRACKET -> ^( CLASS_T ( class_entr_type )? IDENTIFIER ( ^( EXTENDS_T fully_qualified_class_name ) )? ( ^( IMPLEMENTS_T fully_qualified_class_name_list ) )? ( ^( CLASS_BODY ( class_statement )* ) )? ) ) | ( INTERFACE_T IDENTIFIER ( EXTENDS_T fully_qualified_class_name_list )? ( IMPLEMENTS_T fully_qualified_class_name_list )? LEFT_BRACKET ( class_statement )* RIGHT_BRACKET -> ^( INTERFACE_T IDENTIFIER ( ^( EXTENDS_T fully_qualified_class_name_list ) )? ( ^( CLASS_BODY ( class_statement )* ) )? ) ) );
    public final CompilerAstParser.class_declaration_statement_return class_declaration_statement() throws RecognitionException {
        CompilerAstParser.class_declaration_statement_return retval = new CompilerAstParser.class_declaration_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token CLASS_T20=null;
        Token IDENTIFIER21=null;
        Token EXTENDS_T22=null;
        Token IMPLEMENTS_T24=null;
        Token LEFT_BRACKET26=null;
        Token RIGHT_BRACKET28=null;
        Token INTERFACE_T29=null;
        Token IDENTIFIER30=null;
        Token EXTENDS_T31=null;
        Token IMPLEMENTS_T33=null;
        Token LEFT_BRACKET35=null;
        Token RIGHT_BRACKET37=null;
        CompilerAstParser.class_entr_type_return class_entr_type19 = null;

        CompilerAstParser.fully_qualified_class_name_return fully_qualified_class_name23 = null;

        CompilerAstParser.fully_qualified_class_name_list_return fully_qualified_class_name_list25 = null;

        CompilerAstParser.class_statement_return class_statement27 = null;

        CompilerAstParser.fully_qualified_class_name_list_return fully_qualified_class_name_list32 = null;

        CompilerAstParser.fully_qualified_class_name_list_return fully_qualified_class_name_list34 = null;

        CompilerAstParser.class_statement_return class_statement36 = null;


        SLAST CLASS_T20_tree=null;
        SLAST IDENTIFIER21_tree=null;
        SLAST EXTENDS_T22_tree=null;
        SLAST IMPLEMENTS_T24_tree=null;
        SLAST LEFT_BRACKET26_tree=null;
        SLAST RIGHT_BRACKET28_tree=null;
        SLAST INTERFACE_T29_tree=null;
        SLAST IDENTIFIER30_tree=null;
        SLAST EXTENDS_T31_tree=null;
        SLAST IMPLEMENTS_T33_tree=null;
        SLAST LEFT_BRACKET35_tree=null;
        SLAST RIGHT_BRACKET37_tree=null;
        RewriteRuleTokenStream stream_EXTENDS_T=new RewriteRuleTokenStream(adaptor,"token EXTENDS_T");
        RewriteRuleTokenStream stream_INTERFACE_T=new RewriteRuleTokenStream(adaptor,"token INTERFACE_T");
        RewriteRuleTokenStream stream_CLASS_T=new RewriteRuleTokenStream(adaptor,"token CLASS_T");
        RewriteRuleTokenStream stream_IMPLEMENTS_T=new RewriteRuleTokenStream(adaptor,"token IMPLEMENTS_T");
        RewriteRuleTokenStream stream_IDENTIFIER=new RewriteRuleTokenStream(adaptor,"token IDENTIFIER");
        RewriteRuleTokenStream stream_LEFT_BRACKET=new RewriteRuleTokenStream(adaptor,"token LEFT_BRACKET");
        RewriteRuleTokenStream stream_RIGHT_BRACKET=new RewriteRuleTokenStream(adaptor,"token RIGHT_BRACKET");
        RewriteRuleSubtreeStream stream_fully_qualified_class_name=new RewriteRuleSubtreeStream(adaptor,"rule fully_qualified_class_name");
        RewriteRuleSubtreeStream stream_fully_qualified_class_name_list=new RewriteRuleSubtreeStream(adaptor,"rule fully_qualified_class_name_list");
        RewriteRuleSubtreeStream stream_class_entr_type=new RewriteRuleSubtreeStream(adaptor,"rule class_entr_type");
        RewriteRuleSubtreeStream stream_class_statement=new RewriteRuleSubtreeStream(adaptor,"rule class_statement");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:177:3: ( ( ( class_entr_type )? CLASS_T IDENTIFIER ( EXTENDS_T fully_qualified_class_name )? ( IMPLEMENTS_T fully_qualified_class_name_list )? LEFT_BRACKET ( class_statement )* RIGHT_BRACKET -> ^( CLASS_T ( class_entr_type )? IDENTIFIER ( ^( EXTENDS_T fully_qualified_class_name ) )? ( ^( IMPLEMENTS_T fully_qualified_class_name_list ) )? ( ^( CLASS_BODY ( class_statement )* ) )? ) ) | ( INTERFACE_T IDENTIFIER ( EXTENDS_T fully_qualified_class_name_list )? ( IMPLEMENTS_T fully_qualified_class_name_list )? LEFT_BRACKET ( class_statement )* RIGHT_BRACKET -> ^( INTERFACE_T IDENTIFIER ( ^( EXTENDS_T fully_qualified_class_name_list ) )? ( ^( CLASS_BODY ( class_statement )* ) )? ) ) )
            int alt14=2;
            int LA14_0 = input.LA(1);

            if ( (LA14_0==CLASS_T||(LA14_0>=167 && LA14_0<=168)) ) {
                alt14=1;
            }
            else if ( (LA14_0==INTERFACE_T) ) {
                alt14=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 14, 0, input);

                throw nvae;
            }
            switch (alt14) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:177:5: ( ( class_entr_type )? CLASS_T IDENTIFIER ( EXTENDS_T fully_qualified_class_name )? ( IMPLEMENTS_T fully_qualified_class_name_list )? LEFT_BRACKET ( class_statement )* RIGHT_BRACKET -> ^( CLASS_T ( class_entr_type )? IDENTIFIER ( ^( EXTENDS_T fully_qualified_class_name ) )? ( ^( IMPLEMENTS_T fully_qualified_class_name_list ) )? ( ^( CLASS_BODY ( class_statement )* ) )? ) )
                    {
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:177:5: ( ( class_entr_type )? CLASS_T IDENTIFIER ( EXTENDS_T fully_qualified_class_name )? ( IMPLEMENTS_T fully_qualified_class_name_list )? LEFT_BRACKET ( class_statement )* RIGHT_BRACKET -> ^( CLASS_T ( class_entr_type )? IDENTIFIER ( ^( EXTENDS_T fully_qualified_class_name ) )? ( ^( IMPLEMENTS_T fully_qualified_class_name_list ) )? ( ^( CLASS_BODY ( class_statement )* ) )? ) )
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:177:7: ( class_entr_type )? CLASS_T IDENTIFIER ( EXTENDS_T fully_qualified_class_name )? ( IMPLEMENTS_T fully_qualified_class_name_list )? LEFT_BRACKET ( class_statement )* RIGHT_BRACKET
                    {
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:177:7: ( class_entr_type )?
                    int alt7=2;
                    int LA7_0 = input.LA(1);

                    if ( ((LA7_0>=167 && LA7_0<=168)) ) {
                        alt7=1;
                    }
                    switch (alt7) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:177:7: class_entr_type
                            {
                            pushFollow(FOLLOW_class_entr_type_in_class_declaration_statement481);
                            class_entr_type19=class_entr_type();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_class_entr_type.add(class_entr_type19.getTree());

                            }
                            break;

                    }

                    CLASS_T20=(Token)match(input,CLASS_T,FOLLOW_CLASS_T_in_class_declaration_statement484); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_CLASS_T.add(CLASS_T20);

                    IDENTIFIER21=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_class_declaration_statement486); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER21);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:177:43: ( EXTENDS_T fully_qualified_class_name )?
                    int alt8=2;
                    int LA8_0 = input.LA(1);

                    if ( (LA8_0==EXTENDS_T) ) {
                        alt8=1;
                    }
                    switch (alt8) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:177:44: EXTENDS_T fully_qualified_class_name
                            {
                            EXTENDS_T22=(Token)match(input,EXTENDS_T,FOLLOW_EXTENDS_T_in_class_declaration_statement489); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_EXTENDS_T.add(EXTENDS_T22);

                            pushFollow(FOLLOW_fully_qualified_class_name_in_class_declaration_statement491);
                            fully_qualified_class_name23=fully_qualified_class_name();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_fully_qualified_class_name.add(fully_qualified_class_name23.getTree());

                            }
                            break;

                    }

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:177:83: ( IMPLEMENTS_T fully_qualified_class_name_list )?
                    int alt9=2;
                    int LA9_0 = input.LA(1);

                    if ( (LA9_0==IMPLEMENTS_T) ) {
                        alt9=1;
                    }
                    switch (alt9) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:177:84: IMPLEMENTS_T fully_qualified_class_name_list
                            {
                            IMPLEMENTS_T24=(Token)match(input,IMPLEMENTS_T,FOLLOW_IMPLEMENTS_T_in_class_declaration_statement496); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_IMPLEMENTS_T.add(IMPLEMENTS_T24);

                            pushFollow(FOLLOW_fully_qualified_class_name_list_in_class_declaration_statement498);
                            fully_qualified_class_name_list25=fully_qualified_class_name_list();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_fully_qualified_class_name_list.add(fully_qualified_class_name_list25.getTree());

                            }
                            break;

                    }

                    LEFT_BRACKET26=(Token)match(input,LEFT_BRACKET,FOLLOW_LEFT_BRACKET_in_class_declaration_statement508); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LEFT_BRACKET.add(LEFT_BRACKET26);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:178:20: ( class_statement )*
                    loop10:
                    do {
                        int alt10=2;
                        int LA10_0 = input.LA(1);

                        if ( (LA10_0==FUNCTION_T||LA10_0==CONST_T||LA10_0==STATIC_T||(LA10_0>=167 && LA10_0<=172)) ) {
                            alt10=1;
                        }


                        switch (alt10) {
                    	case 1 :
                    	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:178:20: class_statement
                    	    {
                    	    pushFollow(FOLLOW_class_statement_in_class_declaration_statement510);
                    	    class_statement27=class_statement();

                    	    state._fsp--;
                    	    if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) stream_class_statement.add(class_statement27.getTree());

                    	    }
                    	    break;

                    	default :
                    	    break loop10;
                        }
                    } while (true);

                    RIGHT_BRACKET28=(Token)match(input,RIGHT_BRACKET,FOLLOW_RIGHT_BRACKET_in_class_declaration_statement513); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RIGHT_BRACKET.add(RIGHT_BRACKET28);

                    if ( state.backtracking==0 ) {

                            startIndex = ((CommonToken)CLASS_T20).getStartIndex();
                            if ((class_entr_type19!=null?input.toString(class_entr_type19.start,class_entr_type19.stop):null) != null) {
                                token = (CommonToken)(class_entr_type19!=null?((Token)class_entr_type19.start):null);
                                startIndex = token.getStartIndex();
                            } 
                            token = (CommonToken)RIGHT_BRACKET28;
                            endIndex = token.getStopIndex(); 
                          
                    }


                    // AST REWRITE
                    // elements: fully_qualified_class_name, fully_qualified_class_name_list, IMPLEMENTS_T, EXTENDS_T, IDENTIFIER, class_statement, CLASS_T, class_entr_type
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 188:5: -> ^( CLASS_T ( class_entr_type )? IDENTIFIER ( ^( EXTENDS_T fully_qualified_class_name ) )? ( ^( IMPLEMENTS_T fully_qualified_class_name_list ) )? ( ^( CLASS_BODY ( class_statement )* ) )? )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:188:9: ^( CLASS_T ( class_entr_type )? IDENTIFIER ( ^( EXTENDS_T fully_qualified_class_name ) )? ( ^( IMPLEMENTS_T fully_qualified_class_name_list ) )? ( ^( CLASS_BODY ( class_statement )* ) )? )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_CLASS_T.nextNode(), root_1);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:188:19: ( class_entr_type )?
                        if ( stream_class_entr_type.hasNext() ) {
                            adaptor.addChild(root_1, stream_class_entr_type.nextTree());

                        }
                        stream_class_entr_type.reset();
                        adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:188:47: ( ^( EXTENDS_T fully_qualified_class_name ) )?
                        if ( stream_fully_qualified_class_name.hasNext()||stream_EXTENDS_T.hasNext() ) {
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:188:47: ^( EXTENDS_T fully_qualified_class_name )
                            {
                            SLAST root_2 = (SLAST)adaptor.nil();
                            root_2 = (SLAST)adaptor.becomeRoot(stream_EXTENDS_T.nextNode(), root_2);

                            adaptor.addChild(root_2, stream_fully_qualified_class_name.nextTree());

                            adaptor.addChild(root_1, root_2);
                            }

                        }
                        stream_fully_qualified_class_name.reset();
                        stream_EXTENDS_T.reset();
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:188:88: ( ^( IMPLEMENTS_T fully_qualified_class_name_list ) )?
                        if ( stream_fully_qualified_class_name_list.hasNext()||stream_IMPLEMENTS_T.hasNext() ) {
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:188:88: ^( IMPLEMENTS_T fully_qualified_class_name_list )
                            {
                            SLAST root_2 = (SLAST)adaptor.nil();
                            root_2 = (SLAST)adaptor.becomeRoot(stream_IMPLEMENTS_T.nextNode(), root_2);

                            adaptor.addChild(root_2, stream_fully_qualified_class_name_list.nextTree());

                            adaptor.addChild(root_1, root_2);
                            }

                        }
                        stream_fully_qualified_class_name_list.reset();
                        stream_IMPLEMENTS_T.reset();
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:189:7: ( ^( CLASS_BODY ( class_statement )* ) )?
                        if ( stream_class_statement.hasNext() ) {
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:189:7: ^( CLASS_BODY ( class_statement )* )
                            {
                            SLAST root_2 = (SLAST)adaptor.nil();
                            root_2 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(CLASS_BODY, "CLASS_BODY"), root_2);

                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:189:20: ( class_statement )*
                            while ( stream_class_statement.hasNext() ) {
                                adaptor.addChild(root_2, stream_class_statement.nextTree());

                            }
                            stream_class_statement.reset();

                            adaptor.addChild(root_1, root_2);
                            }

                        }
                        stream_class_statement.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }


                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:191:6: ( INTERFACE_T IDENTIFIER ( EXTENDS_T fully_qualified_class_name_list )? ( IMPLEMENTS_T fully_qualified_class_name_list )? LEFT_BRACKET ( class_statement )* RIGHT_BRACKET -> ^( INTERFACE_T IDENTIFIER ( ^( EXTENDS_T fully_qualified_class_name_list ) )? ( ^( CLASS_BODY ( class_statement )* ) )? ) )
                    {
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:191:6: ( INTERFACE_T IDENTIFIER ( EXTENDS_T fully_qualified_class_name_list )? ( IMPLEMENTS_T fully_qualified_class_name_list )? LEFT_BRACKET ( class_statement )* RIGHT_BRACKET -> ^( INTERFACE_T IDENTIFIER ( ^( EXTENDS_T fully_qualified_class_name_list ) )? ( ^( CLASS_BODY ( class_statement )* ) )? ) )
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:191:7: INTERFACE_T IDENTIFIER ( EXTENDS_T fully_qualified_class_name_list )? ( IMPLEMENTS_T fully_qualified_class_name_list )? LEFT_BRACKET ( class_statement )* RIGHT_BRACKET
                    {
                    INTERFACE_T29=(Token)match(input,INTERFACE_T,FOLLOW_INTERFACE_T_in_class_declaration_statement575); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_INTERFACE_T.add(INTERFACE_T29);

                    IDENTIFIER30=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_class_declaration_statement577); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER30);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:191:30: ( EXTENDS_T fully_qualified_class_name_list )?
                    int alt11=2;
                    int LA11_0 = input.LA(1);

                    if ( (LA11_0==EXTENDS_T) ) {
                        alt11=1;
                    }
                    switch (alt11) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:191:31: EXTENDS_T fully_qualified_class_name_list
                            {
                            EXTENDS_T31=(Token)match(input,EXTENDS_T,FOLLOW_EXTENDS_T_in_class_declaration_statement580); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_EXTENDS_T.add(EXTENDS_T31);

                            pushFollow(FOLLOW_fully_qualified_class_name_list_in_class_declaration_statement582);
                            fully_qualified_class_name_list32=fully_qualified_class_name_list();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_fully_qualified_class_name_list.add(fully_qualified_class_name_list32.getTree());

                            }
                            break;

                    }

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:191:75: ( IMPLEMENTS_T fully_qualified_class_name_list )?
                    int alt12=2;
                    int LA12_0 = input.LA(1);

                    if ( (LA12_0==IMPLEMENTS_T) ) {
                        alt12=1;
                    }
                    switch (alt12) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:191:76: IMPLEMENTS_T fully_qualified_class_name_list
                            {
                            IMPLEMENTS_T33=(Token)match(input,IMPLEMENTS_T,FOLLOW_IMPLEMENTS_T_in_class_declaration_statement587); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_IMPLEMENTS_T.add(IMPLEMENTS_T33);

                            pushFollow(FOLLOW_fully_qualified_class_name_list_in_class_declaration_statement589);
                            fully_qualified_class_name_list34=fully_qualified_class_name_list();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_fully_qualified_class_name_list.add(fully_qualified_class_name_list34.getTree());

                            }
                            break;

                    }

                    LEFT_BRACKET35=(Token)match(input,LEFT_BRACKET,FOLLOW_LEFT_BRACKET_in_class_declaration_statement599); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LEFT_BRACKET.add(LEFT_BRACKET35);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:192:20: ( class_statement )*
                    loop13:
                    do {
                        int alt13=2;
                        int LA13_0 = input.LA(1);

                        if ( (LA13_0==FUNCTION_T||LA13_0==CONST_T||LA13_0==STATIC_T||(LA13_0>=167 && LA13_0<=172)) ) {
                            alt13=1;
                        }


                        switch (alt13) {
                    	case 1 :
                    	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:192:20: class_statement
                    	    {
                    	    pushFollow(FOLLOW_class_statement_in_class_declaration_statement601);
                    	    class_statement36=class_statement();

                    	    state._fsp--;
                    	    if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) stream_class_statement.add(class_statement36.getTree());

                    	    }
                    	    break;

                    	default :
                    	    break loop13;
                        }
                    } while (true);

                    RIGHT_BRACKET37=(Token)match(input,RIGHT_BRACKET,FOLLOW_RIGHT_BRACKET_in_class_declaration_statement604); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RIGHT_BRACKET.add(RIGHT_BRACKET37);



                    // AST REWRITE
                    // elements: INTERFACE_T, EXTENDS_T, fully_qualified_class_name_list, IDENTIFIER, class_statement
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 193:5: -> ^( INTERFACE_T IDENTIFIER ( ^( EXTENDS_T fully_qualified_class_name_list ) )? ( ^( CLASS_BODY ( class_statement )* ) )? )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:193:9: ^( INTERFACE_T IDENTIFIER ( ^( EXTENDS_T fully_qualified_class_name_list ) )? ( ^( CLASS_BODY ( class_statement )* ) )? )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_INTERFACE_T.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:193:34: ( ^( EXTENDS_T fully_qualified_class_name_list ) )?
                        if ( stream_EXTENDS_T.hasNext()||stream_fully_qualified_class_name_list.hasNext() ) {
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:193:34: ^( EXTENDS_T fully_qualified_class_name_list )
                            {
                            SLAST root_2 = (SLAST)adaptor.nil();
                            root_2 = (SLAST)adaptor.becomeRoot(stream_EXTENDS_T.nextNode(), root_2);

                            adaptor.addChild(root_2, stream_fully_qualified_class_name_list.nextTree());

                            adaptor.addChild(root_1, root_2);
                            }

                        }
                        stream_EXTENDS_T.reset();
                        stream_fully_qualified_class_name_list.reset();
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:194:7: ( ^( CLASS_BODY ( class_statement )* ) )?
                        if ( stream_class_statement.hasNext() ) {
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:194:7: ^( CLASS_BODY ( class_statement )* )
                            {
                            SLAST root_2 = (SLAST)adaptor.nil();
                            root_2 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(CLASS_BODY, "CLASS_BODY"), root_2);

                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:194:20: ( class_statement )*
                            while ( stream_class_statement.hasNext() ) {
                                adaptor.addChild(root_2, stream_class_statement.nextTree());

                            }
                            stream_class_statement.reset();

                            adaptor.addChild(root_1, root_2);
                            }

                        }
                        stream_class_statement.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }


                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "class_declaration_statement"

    public static class class_entr_type_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "class_entr_type"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:198:1: class_entr_type : ( 'abstract' | 'final' );
    public final CompilerAstParser.class_entr_type_return class_entr_type() throws RecognitionException {
        CompilerAstParser.class_entr_type_return retval = new CompilerAstParser.class_entr_type_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token set38=null;

        SLAST set38_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:199:3: ( 'abstract' | 'final' )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:
            {
            root_0 = (SLAST)adaptor.nil();

            set38=(Token)input.LT(1);
            if ( (input.LA(1)>=167 && input.LA(1)<=168) ) {
                input.consume();
                if ( state.backtracking==0 ) adaptor.addChild(root_0, (SLAST)adaptor.create(set38));
                state.errorRecovery=false;state.failed=false;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                MismatchedSetException mse = new MismatchedSetException(null,input);
                throw mse;
            }


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "class_entr_type"

    public static class class_statement_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "class_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:203:1: class_statement : ( variable_modifiers static_var_list SEMI_COLON -> ^( FIELD_DECL variable_modifiers static_var_list ) | ( modifier )? FUNCTION_T ( REF_T )? IDENTIFIER LEFT_PARETHESIS ( parameter_list )? RIGHT_PARETHESIS SEMI_COLON -> ^( METHOD_DECL ( modifier )? ( REF_T )? IDENTIFIER ( parameter_list )? EMPTYSTATEMENT ) | ( modifier )? FUNCTION_T ( REF_T )? IDENTIFIER LEFT_PARETHESIS ( parameter_list )? RIGHT_PARETHESIS block -> ^( METHOD_DECL ( modifier )? ( REF_T )? IDENTIFIER ( parameter_list )? block ) | CONST_T directive SEMI_COLON -> ^( FIELD_DECL CONST_T directive ) );
    public final CompilerAstParser.class_statement_return class_statement() throws RecognitionException {
        CompilerAstParser.class_statement_return retval = new CompilerAstParser.class_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token SEMI_COLON41=null;
        Token FUNCTION_T43=null;
        Token REF_T44=null;
        Token IDENTIFIER45=null;
        Token LEFT_PARETHESIS46=null;
        Token RIGHT_PARETHESIS48=null;
        Token SEMI_COLON49=null;
        Token FUNCTION_T51=null;
        Token REF_T52=null;
        Token IDENTIFIER53=null;
        Token LEFT_PARETHESIS54=null;
        Token RIGHT_PARETHESIS56=null;
        Token CONST_T58=null;
        Token SEMI_COLON60=null;
        CompilerAstParser.variable_modifiers_return variable_modifiers39 = null;

        CompilerAstParser.static_var_list_return static_var_list40 = null;

        CompilerAstParser.modifier_return modifier42 = null;

        CompilerAstParser.parameter_list_return parameter_list47 = null;

        CompilerAstParser.modifier_return modifier50 = null;

        CompilerAstParser.parameter_list_return parameter_list55 = null;

        CompilerAstParser.block_return block57 = null;

        CompilerAstParser.directive_return directive59 = null;


        SLAST SEMI_COLON41_tree=null;
        SLAST FUNCTION_T43_tree=null;
        SLAST REF_T44_tree=null;
        SLAST IDENTIFIER45_tree=null;
        SLAST LEFT_PARETHESIS46_tree=null;
        SLAST RIGHT_PARETHESIS48_tree=null;
        SLAST SEMI_COLON49_tree=null;
        SLAST FUNCTION_T51_tree=null;
        SLAST REF_T52_tree=null;
        SLAST IDENTIFIER53_tree=null;
        SLAST LEFT_PARETHESIS54_tree=null;
        SLAST RIGHT_PARETHESIS56_tree=null;
        SLAST CONST_T58_tree=null;
        SLAST SEMI_COLON60_tree=null;
        RewriteRuleTokenStream stream_LEFT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token LEFT_PARETHESIS");
        RewriteRuleTokenStream stream_SEMI_COLON=new RewriteRuleTokenStream(adaptor,"token SEMI_COLON");
        RewriteRuleTokenStream stream_REF_T=new RewriteRuleTokenStream(adaptor,"token REF_T");
        RewriteRuleTokenStream stream_IDENTIFIER=new RewriteRuleTokenStream(adaptor,"token IDENTIFIER");
        RewriteRuleTokenStream stream_CONST_T=new RewriteRuleTokenStream(adaptor,"token CONST_T");
        RewriteRuleTokenStream stream_FUNCTION_T=new RewriteRuleTokenStream(adaptor,"token FUNCTION_T");
        RewriteRuleTokenStream stream_RIGHT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token RIGHT_PARETHESIS");
        RewriteRuleSubtreeStream stream_modifier=new RewriteRuleSubtreeStream(adaptor,"rule modifier");
        RewriteRuleSubtreeStream stream_block=new RewriteRuleSubtreeStream(adaptor,"rule block");
        RewriteRuleSubtreeStream stream_directive=new RewriteRuleSubtreeStream(adaptor,"rule directive");
        RewriteRuleSubtreeStream stream_static_var_list=new RewriteRuleSubtreeStream(adaptor,"rule static_var_list");
        RewriteRuleSubtreeStream stream_parameter_list=new RewriteRuleSubtreeStream(adaptor,"rule parameter_list");
        RewriteRuleSubtreeStream stream_variable_modifiers=new RewriteRuleSubtreeStream(adaptor,"rule variable_modifiers");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:214:3: ( variable_modifiers static_var_list SEMI_COLON -> ^( FIELD_DECL variable_modifiers static_var_list ) | ( modifier )? FUNCTION_T ( REF_T )? IDENTIFIER LEFT_PARETHESIS ( parameter_list )? RIGHT_PARETHESIS SEMI_COLON -> ^( METHOD_DECL ( modifier )? ( REF_T )? IDENTIFIER ( parameter_list )? EMPTYSTATEMENT ) | ( modifier )? FUNCTION_T ( REF_T )? IDENTIFIER LEFT_PARETHESIS ( parameter_list )? RIGHT_PARETHESIS block -> ^( METHOD_DECL ( modifier )? ( REF_T )? IDENTIFIER ( parameter_list )? block ) | CONST_T directive SEMI_COLON -> ^( FIELD_DECL CONST_T directive ) )
            int alt21=4;
            alt21 = dfa21.predict(input);
            switch (alt21) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:214:5: variable_modifiers static_var_list SEMI_COLON
                    {
                    pushFollow(FOLLOW_variable_modifiers_in_class_statement689);
                    variable_modifiers39=variable_modifiers();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_variable_modifiers.add(variable_modifiers39.getTree());
                    pushFollow(FOLLOW_static_var_list_in_class_statement691);
                    static_var_list40=static_var_list();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_static_var_list.add(static_var_list40.getTree());
                    SEMI_COLON41=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_class_statement693); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON41);

                    if ( state.backtracking==0 ) {

                           token = (CommonToken)(variable_modifiers39!=null?((Token)variable_modifiers39.start):null);
                      	   startIndex = token.getStartIndex();
                      	   token = (CommonToken)SEMI_COLON41;
                           endIndex = token.getStopIndex();
                        
                    }


                    // AST REWRITE
                    // elements: static_var_list, variable_modifiers
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 221:7: -> ^( FIELD_DECL variable_modifiers static_var_list )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:221:11: ^( FIELD_DECL variable_modifiers static_var_list )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(FIELD_DECL, "FIELD_DECL"), root_1);

                        adaptor.addChild(root_1, stream_variable_modifiers.nextTree());
                        adaptor.addChild(root_1, stream_static_var_list.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:222:5: ( modifier )? FUNCTION_T ( REF_T )? IDENTIFIER LEFT_PARETHESIS ( parameter_list )? RIGHT_PARETHESIS SEMI_COLON
                    {
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:222:5: ( modifier )?
                    int alt15=2;
                    int LA15_0 = input.LA(1);

                    if ( (LA15_0==STATIC_T||(LA15_0>=167 && LA15_0<=168)||(LA15_0>=170 && LA15_0<=172)) ) {
                        alt15=1;
                    }
                    switch (alt15) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:222:5: modifier
                            {
                            pushFollow(FOLLOW_modifier_in_class_statement720);
                            modifier42=modifier();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_modifier.add(modifier42.getTree());

                            }
                            break;

                    }

                    FUNCTION_T43=(Token)match(input,FUNCTION_T,FOLLOW_FUNCTION_T_in_class_statement723); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_FUNCTION_T.add(FUNCTION_T43);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:222:26: ( REF_T )?
                    int alt16=2;
                    int LA16_0 = input.LA(1);

                    if ( (LA16_0==REF_T) ) {
                        alt16=1;
                    }
                    switch (alt16) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:222:26: REF_T
                            {
                            REF_T44=(Token)match(input,REF_T,FOLLOW_REF_T_in_class_statement725); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_REF_T.add(REF_T44);


                            }
                            break;

                    }

                    IDENTIFIER45=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_class_statement728); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER45);

                    LEFT_PARETHESIS46=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_class_statement730); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS46);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:222:60: ( parameter_list )?
                    int alt17=2;
                    int LA17_0 = input.LA(1);

                    if ( (LA17_0==IDENTIFIER||(LA17_0>=REF_T && LA17_0<=CONST_T)||LA17_0==CLONE_T||LA17_0==DOLLAR_T||(LA17_0>=173 && LA17_0<=182)) ) {
                        alt17=1;
                    }
                    switch (alt17) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:222:60: parameter_list
                            {
                            pushFollow(FOLLOW_parameter_list_in_class_statement732);
                            parameter_list47=parameter_list();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_parameter_list.add(parameter_list47.getTree());

                            }
                            break;

                    }

                    RIGHT_PARETHESIS48=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_class_statement735); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS48);

                    SEMI_COLON49=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_class_statement737); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON49);

                    if ( state.backtracking==0 ) {

                           if ((modifier42!=null?input.toString(modifier42.start,modifier42.stop):null) != null) {
                             token = (CommonToken)(modifier42!=null?((Token)modifier42.start):null);
                           }
                           else {
                             token = (CommonToken)FUNCTION_T43;
                           }
                           startIndex = token.getStartIndex();
                           token = (CommonToken)SEMI_COLON49;
                           endIndex = token.getStopIndex();
                        
                    }


                    // AST REWRITE
                    // elements: parameter_list, modifier, IDENTIFIER, REF_T
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 234:6: -> ^( METHOD_DECL ( modifier )? ( REF_T )? IDENTIFIER ( parameter_list )? EMPTYSTATEMENT )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:234:10: ^( METHOD_DECL ( modifier )? ( REF_T )? IDENTIFIER ( parameter_list )? EMPTYSTATEMENT )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(METHOD_DECL, "METHOD_DECL"), root_1);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:234:24: ( modifier )?
                        if ( stream_modifier.hasNext() ) {
                            adaptor.addChild(root_1, stream_modifier.nextTree());

                        }
                        stream_modifier.reset();
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:234:34: ( REF_T )?
                        if ( stream_REF_T.hasNext() ) {
                            adaptor.addChild(root_1, stream_REF_T.nextNode());

                        }
                        stream_REF_T.reset();
                        adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:234:52: ( parameter_list )?
                        if ( stream_parameter_list.hasNext() ) {
                            adaptor.addChild(root_1, stream_parameter_list.nextTree());

                        }
                        stream_parameter_list.reset();
                        adaptor.addChild(root_1, (SLAST)adaptor.create(EMPTYSTATEMENT, "EMPTYSTATEMENT"));

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 3 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:235:5: ( modifier )? FUNCTION_T ( REF_T )? IDENTIFIER LEFT_PARETHESIS ( parameter_list )? RIGHT_PARETHESIS block
                    {
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:235:5: ( modifier )?
                    int alt18=2;
                    int LA18_0 = input.LA(1);

                    if ( (LA18_0==STATIC_T||(LA18_0>=167 && LA18_0<=168)||(LA18_0>=170 && LA18_0<=172)) ) {
                        alt18=1;
                    }
                    switch (alt18) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:235:5: modifier
                            {
                            pushFollow(FOLLOW_modifier_in_class_statement772);
                            modifier50=modifier();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_modifier.add(modifier50.getTree());

                            }
                            break;

                    }

                    FUNCTION_T51=(Token)match(input,FUNCTION_T,FOLLOW_FUNCTION_T_in_class_statement775); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_FUNCTION_T.add(FUNCTION_T51);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:235:26: ( REF_T )?
                    int alt19=2;
                    int LA19_0 = input.LA(1);

                    if ( (LA19_0==REF_T) ) {
                        alt19=1;
                    }
                    switch (alt19) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:235:26: REF_T
                            {
                            REF_T52=(Token)match(input,REF_T,FOLLOW_REF_T_in_class_statement777); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_REF_T.add(REF_T52);


                            }
                            break;

                    }

                    IDENTIFIER53=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_class_statement780); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER53);

                    LEFT_PARETHESIS54=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_class_statement782); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS54);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:235:60: ( parameter_list )?
                    int alt20=2;
                    int LA20_0 = input.LA(1);

                    if ( (LA20_0==IDENTIFIER||(LA20_0>=REF_T && LA20_0<=CONST_T)||LA20_0==CLONE_T||LA20_0==DOLLAR_T||(LA20_0>=173 && LA20_0<=182)) ) {
                        alt20=1;
                    }
                    switch (alt20) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:235:60: parameter_list
                            {
                            pushFollow(FOLLOW_parameter_list_in_class_statement784);
                            parameter_list55=parameter_list();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_parameter_list.add(parameter_list55.getTree());

                            }
                            break;

                    }

                    RIGHT_PARETHESIS56=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_class_statement787); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS56);

                    pushFollow(FOLLOW_block_in_class_statement789);
                    block57=block();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_block.add(block57.getTree());
                    if ( state.backtracking==0 ) {

                           if ((modifier50!=null?input.toString(modifier50.start,modifier50.stop):null) != null) {
                             token = (CommonToken)(modifier50!=null?((Token)modifier50.start):null);
                           }
                           else {
                             token = (CommonToken)FUNCTION_T51;
                           }
                           startIndex = token.getStartIndex();
                           token = (CommonToken)(block57!=null?((Token)block57.stop):null);
                           endIndex = token.getStopIndex();
                        
                    }


                    // AST REWRITE
                    // elements: modifier, block, REF_T, parameter_list, IDENTIFIER
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 247:6: -> ^( METHOD_DECL ( modifier )? ( REF_T )? IDENTIFIER ( parameter_list )? block )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:247:10: ^( METHOD_DECL ( modifier )? ( REF_T )? IDENTIFIER ( parameter_list )? block )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(METHOD_DECL, "METHOD_DECL"), root_1);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:247:24: ( modifier )?
                        if ( stream_modifier.hasNext() ) {
                            adaptor.addChild(root_1, stream_modifier.nextTree());

                        }
                        stream_modifier.reset();
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:247:34: ( REF_T )?
                        if ( stream_REF_T.hasNext() ) {
                            adaptor.addChild(root_1, stream_REF_T.nextNode());

                        }
                        stream_REF_T.reset();
                        adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:247:52: ( parameter_list )?
                        if ( stream_parameter_list.hasNext() ) {
                            adaptor.addChild(root_1, stream_parameter_list.nextTree());

                        }
                        stream_parameter_list.reset();
                        adaptor.addChild(root_1, stream_block.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 4 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:248:5: CONST_T directive SEMI_COLON
                    {
                    CONST_T58=(Token)match(input,CONST_T,FOLLOW_CONST_T_in_class_statement824); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_CONST_T.add(CONST_T58);

                    pushFollow(FOLLOW_directive_in_class_statement826);
                    directive59=directive();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_directive.add(directive59.getTree());
                    SEMI_COLON60=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_class_statement828); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON60);

                    if ( state.backtracking==0 ) {

                           token = (CommonToken)CONST_T58;
                           startIndex = token.getStartIndex();
                           token = (CommonToken)SEMI_COLON60;
                           endIndex = token.getStopIndex();
                        
                    }


                    // AST REWRITE
                    // elements: CONST_T, directive
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 255:6: -> ^( FIELD_DECL CONST_T directive )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:255:10: ^( FIELD_DECL CONST_T directive )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(FIELD_DECL, "FIELD_DECL"), root_1);

                        adaptor.addChild(root_1, stream_CONST_T.nextNode());
                        adaptor.addChild(root_1, stream_directive.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);
                System.out.println("classstat:" + startIndex + " " + endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "class_statement"

    public static class function_declaration_statement_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "function_declaration_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:258:1: function_declaration_statement : FUNCTION_T ( REF_T )? IDENTIFIER LEFT_PARETHESIS ( parameter_list )? RIGHT_PARETHESIS block -> ^( METHOD_DECL ( REF_T )? IDENTIFIER ( parameter_list )? block ) ;
    public final CompilerAstParser.function_declaration_statement_return function_declaration_statement() throws RecognitionException {
        CompilerAstParser.function_declaration_statement_return retval = new CompilerAstParser.function_declaration_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token FUNCTION_T61=null;
        Token REF_T62=null;
        Token IDENTIFIER63=null;
        Token LEFT_PARETHESIS64=null;
        Token RIGHT_PARETHESIS66=null;
        CompilerAstParser.parameter_list_return parameter_list65 = null;

        CompilerAstParser.block_return block67 = null;


        SLAST FUNCTION_T61_tree=null;
        SLAST REF_T62_tree=null;
        SLAST IDENTIFIER63_tree=null;
        SLAST LEFT_PARETHESIS64_tree=null;
        SLAST RIGHT_PARETHESIS66_tree=null;
        RewriteRuleTokenStream stream_LEFT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token LEFT_PARETHESIS");
        RewriteRuleTokenStream stream_REF_T=new RewriteRuleTokenStream(adaptor,"token REF_T");
        RewriteRuleTokenStream stream_IDENTIFIER=new RewriteRuleTokenStream(adaptor,"token IDENTIFIER");
        RewriteRuleTokenStream stream_FUNCTION_T=new RewriteRuleTokenStream(adaptor,"token FUNCTION_T");
        RewriteRuleTokenStream stream_RIGHT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token RIGHT_PARETHESIS");
        RewriteRuleSubtreeStream stream_block=new RewriteRuleSubtreeStream(adaptor,"rule block");
        RewriteRuleSubtreeStream stream_parameter_list=new RewriteRuleSubtreeStream(adaptor,"rule parameter_list");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:268:3: ( FUNCTION_T ( REF_T )? IDENTIFIER LEFT_PARETHESIS ( parameter_list )? RIGHT_PARETHESIS block -> ^( METHOD_DECL ( REF_T )? IDENTIFIER ( parameter_list )? block ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:268:5: FUNCTION_T ( REF_T )? IDENTIFIER LEFT_PARETHESIS ( parameter_list )? RIGHT_PARETHESIS block
            {
            FUNCTION_T61=(Token)match(input,FUNCTION_T,FOLLOW_FUNCTION_T_in_function_declaration_statement875); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_FUNCTION_T.add(FUNCTION_T61);

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:268:16: ( REF_T )?
            int alt22=2;
            int LA22_0 = input.LA(1);

            if ( (LA22_0==REF_T) ) {
                alt22=1;
            }
            switch (alt22) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:268:16: REF_T
                    {
                    REF_T62=(Token)match(input,REF_T,FOLLOW_REF_T_in_function_declaration_statement877); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_REF_T.add(REF_T62);


                    }
                    break;

            }

            IDENTIFIER63=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_function_declaration_statement880); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER63);

            LEFT_PARETHESIS64=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_function_declaration_statement882); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS64);

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:268:50: ( parameter_list )?
            int alt23=2;
            int LA23_0 = input.LA(1);

            if ( (LA23_0==IDENTIFIER||(LA23_0>=REF_T && LA23_0<=CONST_T)||LA23_0==CLONE_T||LA23_0==DOLLAR_T||(LA23_0>=173 && LA23_0<=182)) ) {
                alt23=1;
            }
            switch (alt23) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:268:50: parameter_list
                    {
                    pushFollow(FOLLOW_parameter_list_in_function_declaration_statement884);
                    parameter_list65=parameter_list();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_parameter_list.add(parameter_list65.getTree());

                    }
                    break;

            }

            RIGHT_PARETHESIS66=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_function_declaration_statement887); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS66);

            pushFollow(FOLLOW_block_in_function_declaration_statement894);
            block67=block();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_block.add(block67.getTree());
            if ( state.backtracking==0 ) {

                  token = (CommonToken)FUNCTION_T61;
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(block67!=null?((Token)block67.stop):null);
                  endIndex = token.getStopIndex();
                
            }


            // AST REWRITE
            // elements: block, IDENTIFIER, parameter_list, REF_T
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 276:3: -> ^( METHOD_DECL ( REF_T )? IDENTIFIER ( parameter_list )? block )
            {
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:276:6: ^( METHOD_DECL ( REF_T )? IDENTIFIER ( parameter_list )? block )
                {
                SLAST root_1 = (SLAST)adaptor.nil();
                root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(METHOD_DECL, "METHOD_DECL"), root_1);

                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:276:20: ( REF_T )?
                if ( stream_REF_T.hasNext() ) {
                    adaptor.addChild(root_1, stream_REF_T.nextNode());

                }
                stream_REF_T.reset();
                adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:276:38: ( parameter_list )?
                if ( stream_parameter_list.hasNext() ) {
                    adaptor.addChild(root_1, stream_parameter_list.nextTree());

                }
                stream_parameter_list.reset();
                adaptor.addChild(root_1, stream_block.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "function_declaration_statement"

    public static class block_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "block"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:279:1: block : LEFT_BRACKET ( inner_statement_list )? RIGHT_BRACKET -> ^( BLOCK ( inner_statement_list )? ) ;
    public final CompilerAstParser.block_return block() throws RecognitionException {
        CompilerAstParser.block_return retval = new CompilerAstParser.block_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token LEFT_BRACKET68=null;
        Token RIGHT_BRACKET70=null;
        CompilerAstParser.inner_statement_list_return inner_statement_list69 = null;


        SLAST LEFT_BRACKET68_tree=null;
        SLAST RIGHT_BRACKET70_tree=null;
        RewriteRuleTokenStream stream_LEFT_BRACKET=new RewriteRuleTokenStream(adaptor,"token LEFT_BRACKET");
        RewriteRuleTokenStream stream_RIGHT_BRACKET=new RewriteRuleTokenStream(adaptor,"token RIGHT_BRACKET");
        RewriteRuleSubtreeStream stream_inner_statement_list=new RewriteRuleSubtreeStream(adaptor,"rule inner_statement_list");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:289:3: ( LEFT_BRACKET ( inner_statement_list )? RIGHT_BRACKET -> ^( BLOCK ( inner_statement_list )? ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:289:5: LEFT_BRACKET ( inner_statement_list )? RIGHT_BRACKET
            {
            LEFT_BRACKET68=(Token)match(input,LEFT_BRACKET,FOLLOW_LEFT_BRACKET_in_block940); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_LEFT_BRACKET.add(LEFT_BRACKET68);

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:289:18: ( inner_statement_list )?
            int alt24=2;
            int LA24_0 = input.LA(1);

            if ( (LA24_0==LEFT_PARETHESIS||(LA24_0>=SEMI_COLON && LA24_0<=IDENTIFIER)||LA24_0==LEFT_BRACKET||(LA24_0>=INTERFACE_T && LA24_0<=REF_T)||(LA24_0>=WHILE_T && LA24_0<=FOREACH_T)||(LA24_0>=DECLARE_T && LA24_0<=STRINGLITERAL)||LA24_0==IF_T||(LA24_0>=PLUS_T && LA24_0<=MINUS_T)||(LA24_0>=CLONE_T && LA24_0<=MINUS_MINUS_T)||(LA24_0>=AT_T && LA24_0<=PRINT_T)||(LA24_0>=DOLLAR_T && LA24_0<=DOUBLELITERRAL)||(LA24_0>=166 && LA24_0<=168)||(LA24_0>=182 && LA24_0<=188)) ) {
                alt24=1;
            }
            switch (alt24) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:289:18: inner_statement_list
                    {
                    pushFollow(FOLLOW_inner_statement_list_in_block942);
                    inner_statement_list69=inner_statement_list();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_inner_statement_list.add(inner_statement_list69.getTree());

                    }
                    break;

            }

            RIGHT_BRACKET70=(Token)match(input,RIGHT_BRACKET,FOLLOW_RIGHT_BRACKET_in_block945); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_RIGHT_BRACKET.add(RIGHT_BRACKET70);

            if ( state.backtracking==0 ) {

                  token = (CommonToken)LEFT_BRACKET68;
                  startIndex = token.getStartIndex();
                  token = (CommonToken)RIGHT_BRACKET70;
                  endIndex = token.getStopIndex();
                
            }


            // AST REWRITE
            // elements: inner_statement_list
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 297:6: -> ^( BLOCK ( inner_statement_list )? )
            {
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:297:10: ^( BLOCK ( inner_statement_list )? )
                {
                SLAST root_1 = (SLAST)adaptor.nil();
                root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(BLOCK, "BLOCK"), root_1);

                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:297:18: ( inner_statement_list )?
                if ( stream_inner_statement_list.hasNext() ) {
                    adaptor.addChild(root_1, stream_inner_statement_list.nextTree());

                }
                stream_inner_statement_list.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "block"

    public static class statement_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:300:1: statement : topStatement -> ^( STATEMENT topStatement ) ;
    public final CompilerAstParser.statement_return statement() throws RecognitionException {
        CompilerAstParser.statement_return retval = new CompilerAstParser.statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        CompilerAstParser.topStatement_return topStatement71 = null;


        RewriteRuleSubtreeStream stream_topStatement=new RewriteRuleSubtreeStream(adaptor,"rule topStatement");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:310:3: ( topStatement -> ^( STATEMENT topStatement ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:310:5: topStatement
            {
            pushFollow(FOLLOW_topStatement_in_statement992);
            topStatement71=topStatement();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_topStatement.add(topStatement71.getTree());
            if ( state.backtracking==0 ) {

                  token = (CommonToken)(topStatement71!=null?((Token)topStatement71.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(topStatement71!=null?((Token)topStatement71.stop):null);
                  endIndex = token.getStopIndex();
                
            }


            // AST REWRITE
            // elements: topStatement
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 317:5: -> ^( STATEMENT topStatement )
            {
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:317:8: ^( STATEMENT topStatement )
                {
                SLAST root_1 = (SLAST)adaptor.nil();
                root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(STATEMENT, "STATEMENT"), root_1);

                adaptor.addChild(root_1, stream_topStatement.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST exprToken = retval.tree;
                exprToken.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "statement"

    public static class topStatement_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "topStatement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:320:1: topStatement : ( block | if_stat | WHILE_T LEFT_PARETHESIS expression RIGHT_PARETHESIS while_statement -> ^( WHILE_T ^( CONDITION expression ) while_statement ) | DO_T statement WHILE_T LEFT_PARETHESIS expression RIGHT_PARETHESIS SEMI_COLON -> ^( DO_T ^( CONDITION expression ) statement ) | FOR_T LEFT_PARETHESIS (e1= expr_list )? SEMI_COLON (e2= expr_list )? SEMI_COLON (e3= expr_list )? RIGHT_PARETHESIS for_statement -> ^( FOR_T ( $e1)? ^( CONDITION ( $e2)? ) ^( ITERATE ( $e3)? ) ( for_statement )? ) | SWITCH_T LEFT_PARETHESIS expression RIGHT_PARETHESIS switch_case_list -> ^( SWITCH_T ^( CONDITION expression ) switch_case_list ) | BREAK_T ( expression )? SEMI_COLON -> ^( BREAK_T ( expression )? ) | CONTINUE_T ( expression )? SEMI_COLON -> ^( CONTINUE_T ( expression )? ) | RETURN_T ( expression )? SEMI_COLON -> ^( RETURN_T ( expression )? ) | GLOBAL_T variable_list SEMI_COLON -> ^( GLOBAL_T variable_list ) | STATIC_T static_var_list SEMI_COLON -> ^( STATIC_T static_var_list ) | ECHO_T expr_list SEMI_COLON -> ^( ECHO_T expr_list ) | expression SEMI_COLON | FOREACH_T LEFT_PARETHESIS expression AS_T foreach_variable ( ARROW_T foreach_variable )? RIGHT_PARETHESIS foreach_statement -> ^( FOREACH_T ^( AS_T expression foreach_variable ( foreach_variable )? ) foreach_statement ) | DECLARE_T LEFT_PARETHESIS directive RIGHT_PARETHESIS declare_statement -> ^( DECLARE_T directive ( declare_statement )? ) | SEMI_COLON -> ^( EMPTYSTATEMENT SEMI_COLON ) | TRY_T block ( catch_branch )+ -> ^( TRY_T block ( catch_branch )+ ) | THROW_T expression SEMI_COLON -> ^( THROW_T expression ) | USE_T use_filename SEMI_COLON -> ^( USE_T use_filename ) | INCLUDE_T LEFT_PARETHESIS expression RIGHT_PARETHESIS SEMI_COLON -> ^( INCLUDE_T expression ) | INCLUDE_ONCE_T LEFT_PARETHESIS expression RIGHT_PARETHESIS SEMI_COLON -> ^( INCLUDE_ONCE_T expression ) | REQUIRE_T LEFT_PARETHESIS expression RIGHT_PARETHESIS SEMI_COLON -> ^( REQUIRE_T expression ) | REQUIRE_ONCE_T LEFT_PARETHESIS expression RIGHT_PARETHESIS SEMI_COLON -> ^( REQUIRE_ONCE_T expression ) );
    public final CompilerAstParser.topStatement_return topStatement() throws RecognitionException {
        CompilerAstParser.topStatement_return retval = new CompilerAstParser.topStatement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token WHILE_T74=null;
        Token LEFT_PARETHESIS75=null;
        Token RIGHT_PARETHESIS77=null;
        Token DO_T79=null;
        Token WHILE_T81=null;
        Token LEFT_PARETHESIS82=null;
        Token RIGHT_PARETHESIS84=null;
        Token SEMI_COLON85=null;
        Token FOR_T86=null;
        Token LEFT_PARETHESIS87=null;
        Token SEMI_COLON88=null;
        Token SEMI_COLON89=null;
        Token RIGHT_PARETHESIS90=null;
        Token SWITCH_T92=null;
        Token LEFT_PARETHESIS93=null;
        Token RIGHT_PARETHESIS95=null;
        Token BREAK_T97=null;
        Token SEMI_COLON99=null;
        Token CONTINUE_T100=null;
        Token SEMI_COLON102=null;
        Token RETURN_T103=null;
        Token SEMI_COLON105=null;
        Token GLOBAL_T106=null;
        Token SEMI_COLON108=null;
        Token STATIC_T109=null;
        Token SEMI_COLON111=null;
        Token ECHO_T112=null;
        Token SEMI_COLON114=null;
        Token SEMI_COLON116=null;
        Token FOREACH_T117=null;
        Token LEFT_PARETHESIS118=null;
        Token AS_T120=null;
        Token ARROW_T122=null;
        Token RIGHT_PARETHESIS124=null;
        Token DECLARE_T126=null;
        Token LEFT_PARETHESIS127=null;
        Token RIGHT_PARETHESIS129=null;
        Token SEMI_COLON131=null;
        Token TRY_T132=null;
        Token THROW_T135=null;
        Token SEMI_COLON137=null;
        Token USE_T138=null;
        Token SEMI_COLON140=null;
        Token INCLUDE_T141=null;
        Token LEFT_PARETHESIS142=null;
        Token RIGHT_PARETHESIS144=null;
        Token SEMI_COLON145=null;
        Token INCLUDE_ONCE_T146=null;
        Token LEFT_PARETHESIS147=null;
        Token RIGHT_PARETHESIS149=null;
        Token SEMI_COLON150=null;
        Token REQUIRE_T151=null;
        Token LEFT_PARETHESIS152=null;
        Token RIGHT_PARETHESIS154=null;
        Token SEMI_COLON155=null;
        Token REQUIRE_ONCE_T156=null;
        Token LEFT_PARETHESIS157=null;
        Token RIGHT_PARETHESIS159=null;
        Token SEMI_COLON160=null;
        CompilerAstParser.expr_list_return e1 = null;

        CompilerAstParser.expr_list_return e2 = null;

        CompilerAstParser.expr_list_return e3 = null;

        CompilerAstParser.block_return block72 = null;

        CompilerAstParser.if_stat_return if_stat73 = null;

        CompilerAstParser.expression_return expression76 = null;

        CompilerAstParser.while_statement_return while_statement78 = null;

        CompilerAstParser.statement_return statement80 = null;

        CompilerAstParser.expression_return expression83 = null;

        CompilerAstParser.for_statement_return for_statement91 = null;

        CompilerAstParser.expression_return expression94 = null;

        CompilerAstParser.switch_case_list_return switch_case_list96 = null;

        CompilerAstParser.expression_return expression98 = null;

        CompilerAstParser.expression_return expression101 = null;

        CompilerAstParser.expression_return expression104 = null;

        CompilerAstParser.variable_list_return variable_list107 = null;

        CompilerAstParser.static_var_list_return static_var_list110 = null;

        CompilerAstParser.expr_list_return expr_list113 = null;

        CompilerAstParser.expression_return expression115 = null;

        CompilerAstParser.expression_return expression119 = null;

        CompilerAstParser.foreach_variable_return foreach_variable121 = null;

        CompilerAstParser.foreach_variable_return foreach_variable123 = null;

        CompilerAstParser.foreach_statement_return foreach_statement125 = null;

        CompilerAstParser.directive_return directive128 = null;

        CompilerAstParser.declare_statement_return declare_statement130 = null;

        CompilerAstParser.block_return block133 = null;

        CompilerAstParser.catch_branch_return catch_branch134 = null;

        CompilerAstParser.expression_return expression136 = null;

        CompilerAstParser.use_filename_return use_filename139 = null;

        CompilerAstParser.expression_return expression143 = null;

        CompilerAstParser.expression_return expression148 = null;

        CompilerAstParser.expression_return expression153 = null;

        CompilerAstParser.expression_return expression158 = null;


        SLAST WHILE_T74_tree=null;
        SLAST LEFT_PARETHESIS75_tree=null;
        SLAST RIGHT_PARETHESIS77_tree=null;
        SLAST DO_T79_tree=null;
        SLAST WHILE_T81_tree=null;
        SLAST LEFT_PARETHESIS82_tree=null;
        SLAST RIGHT_PARETHESIS84_tree=null;
        SLAST SEMI_COLON85_tree=null;
        SLAST FOR_T86_tree=null;
        SLAST LEFT_PARETHESIS87_tree=null;
        SLAST SEMI_COLON88_tree=null;
        SLAST SEMI_COLON89_tree=null;
        SLAST RIGHT_PARETHESIS90_tree=null;
        SLAST SWITCH_T92_tree=null;
        SLAST LEFT_PARETHESIS93_tree=null;
        SLAST RIGHT_PARETHESIS95_tree=null;
        SLAST BREAK_T97_tree=null;
        SLAST SEMI_COLON99_tree=null;
        SLAST CONTINUE_T100_tree=null;
        SLAST SEMI_COLON102_tree=null;
        SLAST RETURN_T103_tree=null;
        SLAST SEMI_COLON105_tree=null;
        SLAST GLOBAL_T106_tree=null;
        SLAST SEMI_COLON108_tree=null;
        SLAST STATIC_T109_tree=null;
        SLAST SEMI_COLON111_tree=null;
        SLAST ECHO_T112_tree=null;
        SLAST SEMI_COLON114_tree=null;
        SLAST SEMI_COLON116_tree=null;
        SLAST FOREACH_T117_tree=null;
        SLAST LEFT_PARETHESIS118_tree=null;
        SLAST AS_T120_tree=null;
        SLAST ARROW_T122_tree=null;
        SLAST RIGHT_PARETHESIS124_tree=null;
        SLAST DECLARE_T126_tree=null;
        SLAST LEFT_PARETHESIS127_tree=null;
        SLAST RIGHT_PARETHESIS129_tree=null;
        SLAST SEMI_COLON131_tree=null;
        SLAST TRY_T132_tree=null;
        SLAST THROW_T135_tree=null;
        SLAST SEMI_COLON137_tree=null;
        SLAST USE_T138_tree=null;
        SLAST SEMI_COLON140_tree=null;
        SLAST INCLUDE_T141_tree=null;
        SLAST LEFT_PARETHESIS142_tree=null;
        SLAST RIGHT_PARETHESIS144_tree=null;
        SLAST SEMI_COLON145_tree=null;
        SLAST INCLUDE_ONCE_T146_tree=null;
        SLAST LEFT_PARETHESIS147_tree=null;
        SLAST RIGHT_PARETHESIS149_tree=null;
        SLAST SEMI_COLON150_tree=null;
        SLAST REQUIRE_T151_tree=null;
        SLAST LEFT_PARETHESIS152_tree=null;
        SLAST RIGHT_PARETHESIS154_tree=null;
        SLAST SEMI_COLON155_tree=null;
        SLAST REQUIRE_ONCE_T156_tree=null;
        SLAST LEFT_PARETHESIS157_tree=null;
        SLAST RIGHT_PARETHESIS159_tree=null;
        SLAST SEMI_COLON160_tree=null;
        RewriteRuleTokenStream stream_REQUIRE_T=new RewriteRuleTokenStream(adaptor,"token REQUIRE_T");
        RewriteRuleTokenStream stream_SWITCH_T=new RewriteRuleTokenStream(adaptor,"token SWITCH_T");
        RewriteRuleTokenStream stream_ARROW_T=new RewriteRuleTokenStream(adaptor,"token ARROW_T");
        RewriteRuleTokenStream stream_LEFT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token LEFT_PARETHESIS");
        RewriteRuleTokenStream stream_RETURN_T=new RewriteRuleTokenStream(adaptor,"token RETURN_T");
        RewriteRuleTokenStream stream_TRY_T=new RewriteRuleTokenStream(adaptor,"token TRY_T");
        RewriteRuleTokenStream stream_DO_T=new RewriteRuleTokenStream(adaptor,"token DO_T");
        RewriteRuleTokenStream stream_GLOBAL_T=new RewriteRuleTokenStream(adaptor,"token GLOBAL_T");
        RewriteRuleTokenStream stream_ECHO_T=new RewriteRuleTokenStream(adaptor,"token ECHO_T");
        RewriteRuleTokenStream stream_USE_T=new RewriteRuleTokenStream(adaptor,"token USE_T");
        RewriteRuleTokenStream stream_FOREACH_T=new RewriteRuleTokenStream(adaptor,"token FOREACH_T");
        RewriteRuleTokenStream stream_WHILE_T=new RewriteRuleTokenStream(adaptor,"token WHILE_T");
        RewriteRuleTokenStream stream_INCLUDE_T=new RewriteRuleTokenStream(adaptor,"token INCLUDE_T");
        RewriteRuleTokenStream stream_RIGHT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token RIGHT_PARETHESIS");
        RewriteRuleTokenStream stream_AS_T=new RewriteRuleTokenStream(adaptor,"token AS_T");
        RewriteRuleTokenStream stream_BREAK_T=new RewriteRuleTokenStream(adaptor,"token BREAK_T");
        RewriteRuleTokenStream stream_DECLARE_T=new RewriteRuleTokenStream(adaptor,"token DECLARE_T");
        RewriteRuleTokenStream stream_SEMI_COLON=new RewriteRuleTokenStream(adaptor,"token SEMI_COLON");
        RewriteRuleTokenStream stream_FOR_T=new RewriteRuleTokenStream(adaptor,"token FOR_T");
        RewriteRuleTokenStream stream_CONTINUE_T=new RewriteRuleTokenStream(adaptor,"token CONTINUE_T");
        RewriteRuleTokenStream stream_THROW_T=new RewriteRuleTokenStream(adaptor,"token THROW_T");
        RewriteRuleTokenStream stream_REQUIRE_ONCE_T=new RewriteRuleTokenStream(adaptor,"token REQUIRE_ONCE_T");
        RewriteRuleTokenStream stream_INCLUDE_ONCE_T=new RewriteRuleTokenStream(adaptor,"token INCLUDE_ONCE_T");
        RewriteRuleTokenStream stream_STATIC_T=new RewriteRuleTokenStream(adaptor,"token STATIC_T");
        RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");
        RewriteRuleSubtreeStream stream_block=new RewriteRuleSubtreeStream(adaptor,"rule block");
        RewriteRuleSubtreeStream stream_while_statement=new RewriteRuleSubtreeStream(adaptor,"rule while_statement");
        RewriteRuleSubtreeStream stream_static_var_list=new RewriteRuleSubtreeStream(adaptor,"rule static_var_list");
        RewriteRuleSubtreeStream stream_declare_statement=new RewriteRuleSubtreeStream(adaptor,"rule declare_statement");
        RewriteRuleSubtreeStream stream_statement=new RewriteRuleSubtreeStream(adaptor,"rule statement");
        RewriteRuleSubtreeStream stream_use_filename=new RewriteRuleSubtreeStream(adaptor,"rule use_filename");
        RewriteRuleSubtreeStream stream_variable_list=new RewriteRuleSubtreeStream(adaptor,"rule variable_list");
        RewriteRuleSubtreeStream stream_catch_branch=new RewriteRuleSubtreeStream(adaptor,"rule catch_branch");
        RewriteRuleSubtreeStream stream_foreach_statement=new RewriteRuleSubtreeStream(adaptor,"rule foreach_statement");
        RewriteRuleSubtreeStream stream_for_statement=new RewriteRuleSubtreeStream(adaptor,"rule for_statement");
        RewriteRuleSubtreeStream stream_directive=new RewriteRuleSubtreeStream(adaptor,"rule directive");
        RewriteRuleSubtreeStream stream_foreach_variable=new RewriteRuleSubtreeStream(adaptor,"rule foreach_variable");
        RewriteRuleSubtreeStream stream_expr_list=new RewriteRuleSubtreeStream(adaptor,"rule expr_list");
        RewriteRuleSubtreeStream stream_switch_case_list=new RewriteRuleSubtreeStream(adaptor,"rule switch_case_list");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:333:3: ( block | if_stat | WHILE_T LEFT_PARETHESIS expression RIGHT_PARETHESIS while_statement -> ^( WHILE_T ^( CONDITION expression ) while_statement ) | DO_T statement WHILE_T LEFT_PARETHESIS expression RIGHT_PARETHESIS SEMI_COLON -> ^( DO_T ^( CONDITION expression ) statement ) | FOR_T LEFT_PARETHESIS (e1= expr_list )? SEMI_COLON (e2= expr_list )? SEMI_COLON (e3= expr_list )? RIGHT_PARETHESIS for_statement -> ^( FOR_T ( $e1)? ^( CONDITION ( $e2)? ) ^( ITERATE ( $e3)? ) ( for_statement )? ) | SWITCH_T LEFT_PARETHESIS expression RIGHT_PARETHESIS switch_case_list -> ^( SWITCH_T ^( CONDITION expression ) switch_case_list ) | BREAK_T ( expression )? SEMI_COLON -> ^( BREAK_T ( expression )? ) | CONTINUE_T ( expression )? SEMI_COLON -> ^( CONTINUE_T ( expression )? ) | RETURN_T ( expression )? SEMI_COLON -> ^( RETURN_T ( expression )? ) | GLOBAL_T variable_list SEMI_COLON -> ^( GLOBAL_T variable_list ) | STATIC_T static_var_list SEMI_COLON -> ^( STATIC_T static_var_list ) | ECHO_T expr_list SEMI_COLON -> ^( ECHO_T expr_list ) | expression SEMI_COLON | FOREACH_T LEFT_PARETHESIS expression AS_T foreach_variable ( ARROW_T foreach_variable )? RIGHT_PARETHESIS foreach_statement -> ^( FOREACH_T ^( AS_T expression foreach_variable ( foreach_variable )? ) foreach_statement ) | DECLARE_T LEFT_PARETHESIS directive RIGHT_PARETHESIS declare_statement -> ^( DECLARE_T directive ( declare_statement )? ) | SEMI_COLON -> ^( EMPTYSTATEMENT SEMI_COLON ) | TRY_T block ( catch_branch )+ -> ^( TRY_T block ( catch_branch )+ ) | THROW_T expression SEMI_COLON -> ^( THROW_T expression ) | USE_T use_filename SEMI_COLON -> ^( USE_T use_filename ) | INCLUDE_T LEFT_PARETHESIS expression RIGHT_PARETHESIS SEMI_COLON -> ^( INCLUDE_T expression ) | INCLUDE_ONCE_T LEFT_PARETHESIS expression RIGHT_PARETHESIS SEMI_COLON -> ^( INCLUDE_ONCE_T expression ) | REQUIRE_T LEFT_PARETHESIS expression RIGHT_PARETHESIS SEMI_COLON -> ^( REQUIRE_T expression ) | REQUIRE_ONCE_T LEFT_PARETHESIS expression RIGHT_PARETHESIS SEMI_COLON -> ^( REQUIRE_ONCE_T expression ) )
            int alt33=23;
            switch ( input.LA(1) ) {
            case LEFT_BRACKET:
                {
                alt33=1;
                }
                break;
            case IF_T:
                {
                alt33=2;
                }
                break;
            case WHILE_T:
                {
                alt33=3;
                }
                break;
            case DO_T:
                {
                alt33=4;
                }
                break;
            case FOR_T:
                {
                alt33=5;
                }
                break;
            case SWITCH_T:
                {
                alt33=6;
                }
                break;
            case BREAK_T:
                {
                alt33=7;
                }
                break;
            case CONTINUE_T:
                {
                alt33=8;
                }
                break;
            case RETURN_T:
                {
                alt33=9;
                }
                break;
            case GLOBAL_T:
                {
                alt33=10;
                }
                break;
            case STATIC_T:
                {
                alt33=11;
                }
                break;
            case ECHO_T:
                {
                alt33=12;
                }
                break;
            case LEFT_PARETHESIS:
            case IDENTIFIER:
            case REF_T:
            case STRINGLITERAL:
            case PLUS_T:
            case MINUS_T:
            case CLONE_T:
            case TILDA_T:
            case EXC_NOT_T:
            case PLUS_PLUS_T:
            case MINUS_MINUS_T:
            case AT_T:
            case LIST_T:
            case NEW_T:
            case BACKTRICKLITERAL:
            case PRINT_T:
            case DOLLAR_T:
            case INTLITERAL:
            case FLOATLITERAL:
            case DOUBLELITERRAL:
            case 182:
            case 183:
            case 184:
            case 185:
            case 186:
            case 187:
            case 188:
                {
                alt33=13;
                }
                break;
            case FOREACH_T:
                {
                alt33=14;
                }
                break;
            case DECLARE_T:
                {
                alt33=15;
                }
                break;
            case SEMI_COLON:
                {
                alt33=16;
                }
                break;
            case TRY_T:
                {
                alt33=17;
                }
                break;
            case THROW_T:
                {
                alt33=18;
                }
                break;
            case USE_T:
                {
                alt33=19;
                }
                break;
            case INCLUDE_T:
                {
                alt33=20;
                }
                break;
            case INCLUDE_ONCE_T:
                {
                alt33=21;
                }
                break;
            case REQUIRE_T:
                {
                alt33=22;
                }
                break;
            case REQUIRE_ONCE_T:
                {
                alt33=23;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 33, 0, input);

                throw nvae;
            }

            switch (alt33) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:333:5: block
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_block_in_topStatement1034);
                    block72=block();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, block72.getTree());
                    if ( state.backtracking==0 ) {

                          startIndex = ((CommonToken)(block72!=null?((Token)block72.start):null)).getStartIndex();
                          endIndex = ((CommonToken)(block72!=null?((Token)block72.stop):null)).getStopIndex();
                        
                    }

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:338:5: if_stat
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_if_stat_in_topStatement1044);
                    if_stat73=if_stat();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, if_stat73.getTree());
                    if ( state.backtracking==0 ) {

                          startIndex = ((CommonToken)(if_stat73!=null?((Token)if_stat73.start):null)).getStartIndex();
                          endIndex = ((CommonToken)(if_stat73!=null?((Token)if_stat73.stop):null)).getStopIndex();
                        
                    }

                    }
                    break;
                case 3 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:343:5: WHILE_T LEFT_PARETHESIS expression RIGHT_PARETHESIS while_statement
                    {
                    WHILE_T74=(Token)match(input,WHILE_T,FOLLOW_WHILE_T_in_topStatement1054); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_WHILE_T.add(WHILE_T74);

                    LEFT_PARETHESIS75=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_topStatement1056); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS75);

                    pushFollow(FOLLOW_expression_in_topStatement1058);
                    expression76=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_expression.add(expression76.getTree());
                    RIGHT_PARETHESIS77=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_topStatement1060); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS77);

                    pushFollow(FOLLOW_while_statement_in_topStatement1062);
                    while_statement78=while_statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_while_statement.add(while_statement78.getTree());
                    if ( state.backtracking==0 ) {

                          startIndex = ((CommonToken)WHILE_T74).getStartIndex();
                          endIndex = ((CommonToken)(while_statement78!=null?((Token)while_statement78.stop):null)).getStopIndex();
                        
                    }


                    // AST REWRITE
                    // elements: WHILE_T, while_statement, expression
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 348:5: -> ^( WHILE_T ^( CONDITION expression ) while_statement )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:348:9: ^( WHILE_T ^( CONDITION expression ) while_statement )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_WHILE_T.nextNode(), root_1);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:348:19: ^( CONDITION expression )
                        {
                        SLAST root_2 = (SLAST)adaptor.nil();
                        root_2 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(CONDITION, "CONDITION"), root_2);

                        adaptor.addChild(root_2, stream_expression.nextTree());

                        adaptor.addChild(root_1, root_2);
                        }
                        adaptor.addChild(root_1, stream_while_statement.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 4 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:349:5: DO_T statement WHILE_T LEFT_PARETHESIS expression RIGHT_PARETHESIS SEMI_COLON
                    {
                    DO_T79=(Token)match(input,DO_T,FOLLOW_DO_T_in_topStatement1095); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_DO_T.add(DO_T79);

                    pushFollow(FOLLOW_statement_in_topStatement1097);
                    statement80=statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_statement.add(statement80.getTree());
                    WHILE_T81=(Token)match(input,WHILE_T,FOLLOW_WHILE_T_in_topStatement1099); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_WHILE_T.add(WHILE_T81);

                    LEFT_PARETHESIS82=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_topStatement1101); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS82);

                    pushFollow(FOLLOW_expression_in_topStatement1103);
                    expression83=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_expression.add(expression83.getTree());
                    RIGHT_PARETHESIS84=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_topStatement1105); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS84);

                    SEMI_COLON85=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_topStatement1107); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON85);

                    if ( state.backtracking==0 ) {

                          startIndex = ((CommonToken)DO_T79).getStartIndex();
                          endIndex = ((CommonToken)SEMI_COLON85).getStartIndex();
                        
                    }


                    // AST REWRITE
                    // elements: statement, DO_T, expression
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 354:5: -> ^( DO_T ^( CONDITION expression ) statement )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:354:9: ^( DO_T ^( CONDITION expression ) statement )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_DO_T.nextNode(), root_1);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:354:16: ^( CONDITION expression )
                        {
                        SLAST root_2 = (SLAST)adaptor.nil();
                        root_2 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(CONDITION, "CONDITION"), root_2);

                        adaptor.addChild(root_2, stream_expression.nextTree());

                        adaptor.addChild(root_1, root_2);
                        }
                        adaptor.addChild(root_1, stream_statement.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 5 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:355:5: FOR_T LEFT_PARETHESIS (e1= expr_list )? SEMI_COLON (e2= expr_list )? SEMI_COLON (e3= expr_list )? RIGHT_PARETHESIS for_statement
                    {
                    FOR_T86=(Token)match(input,FOR_T,FOLLOW_FOR_T_in_topStatement1137); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_FOR_T.add(FOR_T86);

                    LEFT_PARETHESIS87=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_topStatement1139); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS87);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:355:29: (e1= expr_list )?
                    int alt25=2;
                    int LA25_0 = input.LA(1);

                    if ( (LA25_0==LEFT_PARETHESIS||LA25_0==IDENTIFIER||LA25_0==REF_T||LA25_0==STRINGLITERAL||(LA25_0>=PLUS_T && LA25_0<=MINUS_T)||(LA25_0>=CLONE_T && LA25_0<=MINUS_MINUS_T)||(LA25_0>=AT_T && LA25_0<=PRINT_T)||(LA25_0>=DOLLAR_T && LA25_0<=DOUBLELITERRAL)||(LA25_0>=182 && LA25_0<=188)) ) {
                        alt25=1;
                    }
                    switch (alt25) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:355:29: e1= expr_list
                            {
                            pushFollow(FOLLOW_expr_list_in_topStatement1143);
                            e1=expr_list();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_expr_list.add(e1.getTree());

                            }
                            break;

                    }

                    SEMI_COLON88=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_topStatement1146); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON88);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:355:54: (e2= expr_list )?
                    int alt26=2;
                    int LA26_0 = input.LA(1);

                    if ( (LA26_0==LEFT_PARETHESIS||LA26_0==IDENTIFIER||LA26_0==REF_T||LA26_0==STRINGLITERAL||(LA26_0>=PLUS_T && LA26_0<=MINUS_T)||(LA26_0>=CLONE_T && LA26_0<=MINUS_MINUS_T)||(LA26_0>=AT_T && LA26_0<=PRINT_T)||(LA26_0>=DOLLAR_T && LA26_0<=DOUBLELITERRAL)||(LA26_0>=182 && LA26_0<=188)) ) {
                        alt26=1;
                    }
                    switch (alt26) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:355:54: e2= expr_list
                            {
                            pushFollow(FOLLOW_expr_list_in_topStatement1150);
                            e2=expr_list();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_expr_list.add(e2.getTree());

                            }
                            break;

                    }

                    SEMI_COLON89=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_topStatement1153); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON89);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:355:79: (e3= expr_list )?
                    int alt27=2;
                    int LA27_0 = input.LA(1);

                    if ( (LA27_0==LEFT_PARETHESIS||LA27_0==IDENTIFIER||LA27_0==REF_T||LA27_0==STRINGLITERAL||(LA27_0>=PLUS_T && LA27_0<=MINUS_T)||(LA27_0>=CLONE_T && LA27_0<=MINUS_MINUS_T)||(LA27_0>=AT_T && LA27_0<=PRINT_T)||(LA27_0>=DOLLAR_T && LA27_0<=DOUBLELITERRAL)||(LA27_0>=182 && LA27_0<=188)) ) {
                        alt27=1;
                    }
                    switch (alt27) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:355:79: e3= expr_list
                            {
                            pushFollow(FOLLOW_expr_list_in_topStatement1157);
                            e3=expr_list();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_expr_list.add(e3.getTree());

                            }
                            break;

                    }

                    RIGHT_PARETHESIS90=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_topStatement1160); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS90);

                    pushFollow(FOLLOW_for_statement_in_topStatement1162);
                    for_statement91=for_statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_for_statement.add(for_statement91.getTree());
                    if ( state.backtracking==0 ) {

                          startIndex = ((CommonToken)FOR_T86).getStartIndex();
                          endIndex = ((CommonToken)RIGHT_PARETHESIS90).getStopIndex();
                          if ((for_statement91!=null?input.toString(for_statement91.start,for_statement91.stop):null) != null) {
                            endIndex = ((CommonToken)(for_statement91!=null?((Token)for_statement91.stop):null)).getStopIndex();
                          }
                        
                    }


                    // AST REWRITE
                    // elements: for_statement, FOR_T, e1, e2, e3
                    // token labels: 
                    // rule labels: e3, retval, e1, e2
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_e3=new RewriteRuleSubtreeStream(adaptor,"rule e3",e3!=null?e3.tree:null);
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
                    RewriteRuleSubtreeStream stream_e1=new RewriteRuleSubtreeStream(adaptor,"rule e1",e1!=null?e1.tree:null);
                    RewriteRuleSubtreeStream stream_e2=new RewriteRuleSubtreeStream(adaptor,"rule e2",e2!=null?e2.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 363:5: -> ^( FOR_T ( $e1)? ^( CONDITION ( $e2)? ) ^( ITERATE ( $e3)? ) ( for_statement )? )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:363:9: ^( FOR_T ( $e1)? ^( CONDITION ( $e2)? ) ^( ITERATE ( $e3)? ) ( for_statement )? )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_FOR_T.nextNode(), root_1);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:363:17: ( $e1)?
                        if ( stream_e1.hasNext() ) {
                            adaptor.addChild(root_1, stream_e1.nextTree());

                        }
                        stream_e1.reset();
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:363:22: ^( CONDITION ( $e2)? )
                        {
                        SLAST root_2 = (SLAST)adaptor.nil();
                        root_2 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(CONDITION, "CONDITION"), root_2);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:363:34: ( $e2)?
                        if ( stream_e2.hasNext() ) {
                            adaptor.addChild(root_2, stream_e2.nextTree());

                        }
                        stream_e2.reset();

                        adaptor.addChild(root_1, root_2);
                        }
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:363:40: ^( ITERATE ( $e3)? )
                        {
                        SLAST root_2 = (SLAST)adaptor.nil();
                        root_2 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(ITERATE, "ITERATE"), root_2);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:363:50: ( $e3)?
                        if ( stream_e3.hasNext() ) {
                            adaptor.addChild(root_2, stream_e3.nextTree());

                        }
                        stream_e3.reset();

                        adaptor.addChild(root_1, root_2);
                        }
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:363:56: ( for_statement )?
                        if ( stream_for_statement.hasNext() ) {
                            adaptor.addChild(root_1, stream_for_statement.nextTree());

                        }
                        stream_for_statement.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 6 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:364:5: SWITCH_T LEFT_PARETHESIS expression RIGHT_PARETHESIS switch_case_list
                    {
                    SWITCH_T92=(Token)match(input,SWITCH_T,FOLLOW_SWITCH_T_in_topStatement1206); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SWITCH_T.add(SWITCH_T92);

                    LEFT_PARETHESIS93=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_topStatement1208); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS93);

                    pushFollow(FOLLOW_expression_in_topStatement1210);
                    expression94=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_expression.add(expression94.getTree());
                    RIGHT_PARETHESIS95=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_topStatement1212); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS95);

                    pushFollow(FOLLOW_switch_case_list_in_topStatement1214);
                    switch_case_list96=switch_case_list();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_switch_case_list.add(switch_case_list96.getTree());
                    if ( state.backtracking==0 ) {

                          startIndex = ((CommonToken)SWITCH_T92).getStartIndex();
                          endIndex = ((CommonToken)(switch_case_list96!=null?((Token)switch_case_list96.stop):null)).getStopIndex();
                        
                    }


                    // AST REWRITE
                    // elements: SWITCH_T, switch_case_list, expression
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 369:5: -> ^( SWITCH_T ^( CONDITION expression ) switch_case_list )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:369:9: ^( SWITCH_T ^( CONDITION expression ) switch_case_list )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_SWITCH_T.nextNode(), root_1);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:369:20: ^( CONDITION expression )
                        {
                        SLAST root_2 = (SLAST)adaptor.nil();
                        root_2 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(CONDITION, "CONDITION"), root_2);

                        adaptor.addChild(root_2, stream_expression.nextTree());

                        adaptor.addChild(root_1, root_2);
                        }
                        adaptor.addChild(root_1, stream_switch_case_list.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 7 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:370:5: BREAK_T ( expression )? SEMI_COLON
                    {
                    BREAK_T97=(Token)match(input,BREAK_T,FOLLOW_BREAK_T_in_topStatement1243); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_BREAK_T.add(BREAK_T97);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:370:13: ( expression )?
                    int alt28=2;
                    int LA28_0 = input.LA(1);

                    if ( (LA28_0==LEFT_PARETHESIS||LA28_0==IDENTIFIER||LA28_0==REF_T||LA28_0==STRINGLITERAL||(LA28_0>=PLUS_T && LA28_0<=MINUS_T)||(LA28_0>=CLONE_T && LA28_0<=MINUS_MINUS_T)||(LA28_0>=AT_T && LA28_0<=PRINT_T)||(LA28_0>=DOLLAR_T && LA28_0<=DOUBLELITERRAL)||(LA28_0>=182 && LA28_0<=188)) ) {
                        alt28=1;
                    }
                    switch (alt28) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:370:13: expression
                            {
                            pushFollow(FOLLOW_expression_in_topStatement1245);
                            expression98=expression();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_expression.add(expression98.getTree());

                            }
                            break;

                    }

                    SEMI_COLON99=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_topStatement1248); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON99);

                    if ( state.backtracking==0 ) {

                          startIndex = ((CommonToken)BREAK_T97).getStartIndex();
                          endIndex = ((CommonToken)SEMI_COLON99).getStartIndex();
                        
                    }


                    // AST REWRITE
                    // elements: BREAK_T, expression
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 375:5: -> ^( BREAK_T ( expression )? )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:375:9: ^( BREAK_T ( expression )? )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_BREAK_T.nextNode(), root_1);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:375:19: ( expression )?
                        if ( stream_expression.hasNext() ) {
                            adaptor.addChild(root_1, stream_expression.nextTree());

                        }
                        stream_expression.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 8 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:376:5: CONTINUE_T ( expression )? SEMI_COLON
                    {
                    CONTINUE_T100=(Token)match(input,CONTINUE_T,FOLLOW_CONTINUE_T_in_topStatement1272); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_CONTINUE_T.add(CONTINUE_T100);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:376:16: ( expression )?
                    int alt29=2;
                    int LA29_0 = input.LA(1);

                    if ( (LA29_0==LEFT_PARETHESIS||LA29_0==IDENTIFIER||LA29_0==REF_T||LA29_0==STRINGLITERAL||(LA29_0>=PLUS_T && LA29_0<=MINUS_T)||(LA29_0>=CLONE_T && LA29_0<=MINUS_MINUS_T)||(LA29_0>=AT_T && LA29_0<=PRINT_T)||(LA29_0>=DOLLAR_T && LA29_0<=DOUBLELITERRAL)||(LA29_0>=182 && LA29_0<=188)) ) {
                        alt29=1;
                    }
                    switch (alt29) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:376:16: expression
                            {
                            pushFollow(FOLLOW_expression_in_topStatement1274);
                            expression101=expression();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_expression.add(expression101.getTree());

                            }
                            break;

                    }

                    SEMI_COLON102=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_topStatement1277); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON102);

                    if ( state.backtracking==0 ) {

                          startIndex = ((CommonToken)CONTINUE_T100).getStartIndex();
                          endIndex = ((CommonToken)SEMI_COLON102).getStartIndex();
                        
                    }


                    // AST REWRITE
                    // elements: expression, CONTINUE_T
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 381:5: -> ^( CONTINUE_T ( expression )? )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:381:9: ^( CONTINUE_T ( expression )? )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_CONTINUE_T.nextNode(), root_1);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:381:22: ( expression )?
                        if ( stream_expression.hasNext() ) {
                            adaptor.addChild(root_1, stream_expression.nextTree());

                        }
                        stream_expression.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 9 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:382:5: RETURN_T ( expression )? SEMI_COLON
                    {
                    RETURN_T103=(Token)match(input,RETURN_T,FOLLOW_RETURN_T_in_topStatement1313); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RETURN_T.add(RETURN_T103);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:382:14: ( expression )?
                    int alt30=2;
                    int LA30_0 = input.LA(1);

                    if ( (LA30_0==LEFT_PARETHESIS||LA30_0==IDENTIFIER||LA30_0==REF_T||LA30_0==STRINGLITERAL||(LA30_0>=PLUS_T && LA30_0<=MINUS_T)||(LA30_0>=CLONE_T && LA30_0<=MINUS_MINUS_T)||(LA30_0>=AT_T && LA30_0<=PRINT_T)||(LA30_0>=DOLLAR_T && LA30_0<=DOUBLELITERRAL)||(LA30_0>=182 && LA30_0<=188)) ) {
                        alt30=1;
                    }
                    switch (alt30) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:382:14: expression
                            {
                            pushFollow(FOLLOW_expression_in_topStatement1315);
                            expression104=expression();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_expression.add(expression104.getTree());

                            }
                            break;

                    }

                    SEMI_COLON105=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_topStatement1318); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON105);

                    if ( state.backtracking==0 ) {

                          startIndex = ((CommonToken)RETURN_T103).getStartIndex();
                          endIndex = ((CommonToken)SEMI_COLON105).getStartIndex();
                        
                    }


                    // AST REWRITE
                    // elements: RETURN_T, expression
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 387:5: -> ^( RETURN_T ( expression )? )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:387:9: ^( RETURN_T ( expression )? )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_RETURN_T.nextNode(), root_1);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:387:20: ( expression )?
                        if ( stream_expression.hasNext() ) {
                            adaptor.addChild(root_1, stream_expression.nextTree());

                        }
                        stream_expression.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 10 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:388:5: GLOBAL_T variable_list SEMI_COLON
                    {
                    GLOBAL_T106=(Token)match(input,GLOBAL_T,FOLLOW_GLOBAL_T_in_topStatement1357); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_GLOBAL_T.add(GLOBAL_T106);

                    pushFollow(FOLLOW_variable_list_in_topStatement1359);
                    variable_list107=variable_list();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_variable_list.add(variable_list107.getTree());
                    SEMI_COLON108=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_topStatement1361); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON108);

                    if ( state.backtracking==0 ) {

                          startIndex = ((CommonToken)GLOBAL_T106).getStartIndex();
                          endIndex = ((CommonToken)SEMI_COLON108).getStartIndex();
                        
                    }


                    // AST REWRITE
                    // elements: GLOBAL_T, variable_list
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 393:5: -> ^( GLOBAL_T variable_list )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:393:9: ^( GLOBAL_T variable_list )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_GLOBAL_T.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_variable_list.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 11 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:394:5: STATIC_T static_var_list SEMI_COLON
                    {
                    STATIC_T109=(Token)match(input,STATIC_T,FOLLOW_STATIC_T_in_topStatement1399); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_STATIC_T.add(STATIC_T109);

                    pushFollow(FOLLOW_static_var_list_in_topStatement1401);
                    static_var_list110=static_var_list();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_static_var_list.add(static_var_list110.getTree());
                    SEMI_COLON111=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_topStatement1403); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON111);

                    if ( state.backtracking==0 ) {

                          startIndex = ((CommonToken)STATIC_T109).getStartIndex();
                          endIndex = ((CommonToken)SEMI_COLON111).getStartIndex();
                        
                    }


                    // AST REWRITE
                    // elements: STATIC_T, static_var_list
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 399:5: -> ^( STATIC_T static_var_list )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:399:9: ^( STATIC_T static_var_list )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_STATIC_T.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_static_var_list.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 12 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:400:5: ECHO_T expr_list SEMI_COLON
                    {
                    ECHO_T112=(Token)match(input,ECHO_T,FOLLOW_ECHO_T_in_topStatement1438); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_ECHO_T.add(ECHO_T112);

                    pushFollow(FOLLOW_expr_list_in_topStatement1440);
                    expr_list113=expr_list();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_expr_list.add(expr_list113.getTree());
                    SEMI_COLON114=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_topStatement1442); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON114);

                    if ( state.backtracking==0 ) {

                          startIndex = ((CommonToken)ECHO_T112).getStartIndex();
                          endIndex = ((CommonToken)SEMI_COLON114).getStartIndex();
                        
                    }


                    // AST REWRITE
                    // elements: ECHO_T, expr_list
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 405:5: -> ^( ECHO_T expr_list )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:405:9: ^( ECHO_T expr_list )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_ECHO_T.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_expr_list.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 13 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:406:5: expression SEMI_COLON
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_expression_in_topStatement1465);
                    expression115=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, expression115.getTree());
                    SEMI_COLON116=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_topStatement1467); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {

                          startIndex = ((CommonToken)(expression115!=null?((Token)expression115.start):null)).getStartIndex();
                          endIndex = ((CommonToken)(expression115!=null?((Token)expression115.stop):null)).getStopIndex();
                        
                    }

                    }
                    break;
                case 14 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:411:5: FOREACH_T LEFT_PARETHESIS expression AS_T foreach_variable ( ARROW_T foreach_variable )? RIGHT_PARETHESIS foreach_statement
                    {
                    FOREACH_T117=(Token)match(input,FOREACH_T,FOLLOW_FOREACH_T_in_topStatement1478); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_FOREACH_T.add(FOREACH_T117);

                    LEFT_PARETHESIS118=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_topStatement1480); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS118);

                    pushFollow(FOLLOW_expression_in_topStatement1482);
                    expression119=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_expression.add(expression119.getTree());
                    AS_T120=(Token)match(input,AS_T,FOLLOW_AS_T_in_topStatement1484); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_AS_T.add(AS_T120);

                    pushFollow(FOLLOW_foreach_variable_in_topStatement1486);
                    foreach_variable121=foreach_variable();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_foreach_variable.add(foreach_variable121.getTree());
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:411:64: ( ARROW_T foreach_variable )?
                    int alt31=2;
                    int LA31_0 = input.LA(1);

                    if ( (LA31_0==ARROW_T) ) {
                        alt31=1;
                    }
                    switch (alt31) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:411:65: ARROW_T foreach_variable
                            {
                            ARROW_T122=(Token)match(input,ARROW_T,FOLLOW_ARROW_T_in_topStatement1489); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_ARROW_T.add(ARROW_T122);

                            pushFollow(FOLLOW_foreach_variable_in_topStatement1491);
                            foreach_variable123=foreach_variable();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_foreach_variable.add(foreach_variable123.getTree());

                            }
                            break;

                    }

                    RIGHT_PARETHESIS124=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_topStatement1495); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS124);

                    pushFollow(FOLLOW_foreach_statement_in_topStatement1505);
                    foreach_statement125=foreach_statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_foreach_statement.add(foreach_statement125.getTree());
                    if ( state.backtracking==0 ) {

                          startIndex = ((CommonToken)FOREACH_T117).getStartIndex();
                          endIndex = ((CommonToken)(foreach_statement125!=null?((Token)foreach_statement125.stop):null)).getStopIndex();
                        
                    }


                    // AST REWRITE
                    // elements: foreach_statement, foreach_variable, FOREACH_T, AS_T, expression, foreach_variable
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 417:6: -> ^( FOREACH_T ^( AS_T expression foreach_variable ( foreach_variable )? ) foreach_statement )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:417:9: ^( FOREACH_T ^( AS_T expression foreach_variable ( foreach_variable )? ) foreach_statement )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_FOREACH_T.nextNode(), root_1);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:417:21: ^( AS_T expression foreach_variable ( foreach_variable )? )
                        {
                        SLAST root_2 = (SLAST)adaptor.nil();
                        root_2 = (SLAST)adaptor.becomeRoot(stream_AS_T.nextNode(), root_2);

                        adaptor.addChild(root_2, stream_expression.nextTree());
                        adaptor.addChild(root_2, stream_foreach_variable.nextTree());
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:417:56: ( foreach_variable )?
                        if ( stream_foreach_variable.hasNext() ) {
                            adaptor.addChild(root_2, stream_foreach_variable.nextTree());

                        }
                        stream_foreach_variable.reset();

                        adaptor.addChild(root_1, root_2);
                        }
                        adaptor.addChild(root_1, stream_foreach_statement.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 15 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:418:5: DECLARE_T LEFT_PARETHESIS directive RIGHT_PARETHESIS declare_statement
                    {
                    DECLARE_T126=(Token)match(input,DECLARE_T,FOLLOW_DECLARE_T_in_topStatement1540); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_DECLARE_T.add(DECLARE_T126);

                    LEFT_PARETHESIS127=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_topStatement1542); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS127);

                    pushFollow(FOLLOW_directive_in_topStatement1544);
                    directive128=directive();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_directive.add(directive128.getTree());
                    RIGHT_PARETHESIS129=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_topStatement1546); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS129);

                    pushFollow(FOLLOW_declare_statement_in_topStatement1548);
                    declare_statement130=declare_statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_declare_statement.add(declare_statement130.getTree());
                    if ( state.backtracking==0 ) {

                          startIndex = ((CommonToken)DECLARE_T126).getStartIndex();
                          endIndex = ((CommonToken)(declare_statement130!=null?((Token)declare_statement130.stop):null)).getStopIndex();
                        
                    }


                    // AST REWRITE
                    // elements: DECLARE_T, declare_statement, directive
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 423:5: -> ^( DECLARE_T directive ( declare_statement )? )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:423:9: ^( DECLARE_T directive ( declare_statement )? )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_DECLARE_T.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_directive.nextTree());
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:423:31: ( declare_statement )?
                        if ( stream_declare_statement.hasNext() ) {
                            adaptor.addChild(root_1, stream_declare_statement.nextTree());

                        }
                        stream_declare_statement.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 16 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:424:5: SEMI_COLON
                    {
                    SEMI_COLON131=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_topStatement1574); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON131);



                    // AST REWRITE
                    // elements: SEMI_COLON
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 425:5: -> ^( EMPTYSTATEMENT SEMI_COLON )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:425:9: ^( EMPTYSTATEMENT SEMI_COLON )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(EMPTYSTATEMENT, "EMPTYSTATEMENT"), root_1);

                        adaptor.addChild(root_1, stream_SEMI_COLON.nextNode());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 17 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:426:5: TRY_T block ( catch_branch )+
                    {
                    TRY_T132=(Token)match(input,TRY_T,FOLLOW_TRY_T_in_topStatement1593); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_TRY_T.add(TRY_T132);

                    pushFollow(FOLLOW_block_in_topStatement1595);
                    block133=block();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_block.add(block133.getTree());
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:426:17: ( catch_branch )+
                    int cnt32=0;
                    loop32:
                    do {
                        int alt32=2;
                        int LA32_0 = input.LA(1);

                        if ( (LA32_0==CATCH_T) ) {
                            alt32=1;
                        }


                        switch (alt32) {
                    	case 1 :
                    	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:426:17: catch_branch
                    	    {
                    	    pushFollow(FOLLOW_catch_branch_in_topStatement1597);
                    	    catch_branch134=catch_branch();

                    	    state._fsp--;
                    	    if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) stream_catch_branch.add(catch_branch134.getTree());

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt32 >= 1 ) break loop32;
                    	    if (state.backtracking>0) {state.failed=true; return retval;}
                                EarlyExitException eee =
                                    new EarlyExitException(32, input);
                                throw eee;
                        }
                        cnt32++;
                    } while (true);

                    if ( state.backtracking==0 ) {

                          startIndex = ((CommonToken)TRY_T132).getStartIndex();
                          endIndex = ((CommonToken)(catch_branch134!=null?((Token)catch_branch134.stop):null)).getStopIndex();
                        
                    }


                    // AST REWRITE
                    // elements: catch_branch, TRY_T, block
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 431:5: -> ^( TRY_T block ( catch_branch )+ )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:431:9: ^( TRY_T block ( catch_branch )+ )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_TRY_T.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_block.nextTree());
                        if ( !(stream_catch_branch.hasNext()) ) {
                            throw new RewriteEarlyExitException();
                        }
                        while ( stream_catch_branch.hasNext() ) {
                            adaptor.addChild(root_1, stream_catch_branch.nextTree());

                        }
                        stream_catch_branch.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 18 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:432:5: THROW_T expression SEMI_COLON
                    {
                    THROW_T135=(Token)match(input,THROW_T,FOLLOW_THROW_T_in_topStatement1624); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_THROW_T.add(THROW_T135);

                    pushFollow(FOLLOW_expression_in_topStatement1626);
                    expression136=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_expression.add(expression136.getTree());
                    SEMI_COLON137=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_topStatement1628); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON137);

                    if ( state.backtracking==0 ) {

                          startIndex = ((CommonToken)THROW_T135).getStartIndex();
                          endIndex = ((CommonToken)SEMI_COLON137).getStartIndex();
                        
                    }


                    // AST REWRITE
                    // elements: expression, THROW_T
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 437:5: -> ^( THROW_T expression )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:437:9: ^( THROW_T expression )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_THROW_T.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_expression.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 19 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:438:5: USE_T use_filename SEMI_COLON
                    {
                    USE_T138=(Token)match(input,USE_T,FOLLOW_USE_T_in_topStatement1665); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_USE_T.add(USE_T138);

                    pushFollow(FOLLOW_use_filename_in_topStatement1667);
                    use_filename139=use_filename();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_use_filename.add(use_filename139.getTree());
                    SEMI_COLON140=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_topStatement1669); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON140);

                    if ( state.backtracking==0 ) {

                          startIndex = ((CommonToken)USE_T138).getStartIndex();
                          endIndex = ((CommonToken)SEMI_COLON140).getStartIndex();
                        
                    }


                    // AST REWRITE
                    // elements: use_filename, USE_T
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 443:5: -> ^( USE_T use_filename )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:443:9: ^( USE_T use_filename )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_USE_T.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_use_filename.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 20 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:444:5: INCLUDE_T LEFT_PARETHESIS expression RIGHT_PARETHESIS SEMI_COLON
                    {
                    INCLUDE_T141=(Token)match(input,INCLUDE_T,FOLLOW_INCLUDE_T_in_topStatement1706); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_INCLUDE_T.add(INCLUDE_T141);

                    LEFT_PARETHESIS142=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_topStatement1708); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS142);

                    pushFollow(FOLLOW_expression_in_topStatement1710);
                    expression143=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_expression.add(expression143.getTree());
                    RIGHT_PARETHESIS144=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_topStatement1712); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS144);

                    SEMI_COLON145=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_topStatement1714); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON145);

                    if ( state.backtracking==0 ) {

                          startIndex = ((CommonToken)INCLUDE_T141).getStartIndex();
                          endIndex = ((CommonToken)SEMI_COLON145).getStartIndex();
                        
                    }


                    // AST REWRITE
                    // elements: INCLUDE_T, expression
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 449:5: -> ^( INCLUDE_T expression )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:449:9: ^( INCLUDE_T expression )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_INCLUDE_T.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_expression.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 21 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:450:5: INCLUDE_ONCE_T LEFT_PARETHESIS expression RIGHT_PARETHESIS SEMI_COLON
                    {
                    INCLUDE_ONCE_T146=(Token)match(input,INCLUDE_ONCE_T,FOLLOW_INCLUDE_ONCE_T_in_topStatement1737); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_INCLUDE_ONCE_T.add(INCLUDE_ONCE_T146);

                    LEFT_PARETHESIS147=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_topStatement1739); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS147);

                    pushFollow(FOLLOW_expression_in_topStatement1741);
                    expression148=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_expression.add(expression148.getTree());
                    RIGHT_PARETHESIS149=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_topStatement1743); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS149);

                    SEMI_COLON150=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_topStatement1745); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON150);

                    if ( state.backtracking==0 ) {

                          startIndex = ((CommonToken)INCLUDE_ONCE_T146).getStartIndex();
                          endIndex = ((CommonToken)SEMI_COLON150).getStartIndex();
                        
                    }


                    // AST REWRITE
                    // elements: expression, INCLUDE_ONCE_T
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 455:5: -> ^( INCLUDE_ONCE_T expression )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:455:9: ^( INCLUDE_ONCE_T expression )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_INCLUDE_ONCE_T.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_expression.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 22 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:456:5: REQUIRE_T LEFT_PARETHESIS expression RIGHT_PARETHESIS SEMI_COLON
                    {
                    REQUIRE_T151=(Token)match(input,REQUIRE_T,FOLLOW_REQUIRE_T_in_topStatement1768); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_REQUIRE_T.add(REQUIRE_T151);

                    LEFT_PARETHESIS152=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_topStatement1770); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS152);

                    pushFollow(FOLLOW_expression_in_topStatement1772);
                    expression153=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_expression.add(expression153.getTree());
                    RIGHT_PARETHESIS154=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_topStatement1774); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS154);

                    SEMI_COLON155=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_topStatement1776); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON155);

                    if ( state.backtracking==0 ) {

                          startIndex = ((CommonToken)REQUIRE_T151).getStartIndex();
                          endIndex = ((CommonToken)SEMI_COLON155).getStartIndex();
                        
                    }


                    // AST REWRITE
                    // elements: REQUIRE_T, expression
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 461:5: -> ^( REQUIRE_T expression )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:461:9: ^( REQUIRE_T expression )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_REQUIRE_T.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_expression.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 23 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:462:5: REQUIRE_ONCE_T LEFT_PARETHESIS expression RIGHT_PARETHESIS SEMI_COLON
                    {
                    REQUIRE_ONCE_T156=(Token)match(input,REQUIRE_ONCE_T,FOLLOW_REQUIRE_ONCE_T_in_topStatement1799); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_REQUIRE_ONCE_T.add(REQUIRE_ONCE_T156);

                    LEFT_PARETHESIS157=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_topStatement1801); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS157);

                    pushFollow(FOLLOW_expression_in_topStatement1803);
                    expression158=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_expression.add(expression158.getTree());
                    RIGHT_PARETHESIS159=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_topStatement1805); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS159);

                    SEMI_COLON160=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_topStatement1807); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON160);

                    if ( state.backtracking==0 ) {

                          startIndex = ((CommonToken)REQUIRE_ONCE_T156).getStartIndex();
                          endIndex = ((CommonToken)SEMI_COLON160).getStartIndex();
                        
                    }


                    // AST REWRITE
                    // elements: expression, REQUIRE_ONCE_T
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 467:5: -> ^( REQUIRE_ONCE_T expression )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:467:9: ^( REQUIRE_ONCE_T expression )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_REQUIRE_ONCE_T.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_expression.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                if (ast != null) {
                  ast.setIndex(startIndex, endIndex);
                  System.out.println("statement " + startIndex + " " + endIndex);
                }

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "topStatement"

    public static class foreach_variable_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "foreach_variable"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:474:1: foreach_variable : ( REF_T )? variable ;
    public final CompilerAstParser.foreach_variable_return foreach_variable() throws RecognitionException {
        CompilerAstParser.foreach_variable_return retval = new CompilerAstParser.foreach_variable_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token REF_T161=null;
        CompilerAstParser.variable_return variable162 = null;


        SLAST REF_T161_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:477:3: ( ( REF_T )? variable )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:477:5: ( REF_T )? variable
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:477:5: ( REF_T )?
            int alt34=2;
            int LA34_0 = input.LA(1);

            if ( (LA34_0==REF_T) ) {
                alt34=1;
            }
            switch (alt34) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:477:5: REF_T
                    {
                    REF_T161=(Token)match(input,REF_T,FOLLOW_REF_T_in_foreach_variable1847); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    REF_T161_tree = (SLAST)adaptor.create(REF_T161);
                    adaptor.addChild(root_0, REF_T161_tree);
                    }

                    }
                    break;

            }

            pushFollow(FOLLOW_variable_in_foreach_variable1850);
            variable162=variable();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, variable162.getTree());

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "foreach_variable"

    public static class use_filename_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "use_filename"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:480:1: use_filename : ( STRINGLITERAL | LEFT_PARETHESIS STRINGLITERAL RIGHT_PARETHESIS );
    public final CompilerAstParser.use_filename_return use_filename() throws RecognitionException {
        CompilerAstParser.use_filename_return retval = new CompilerAstParser.use_filename_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token STRINGLITERAL163=null;
        Token LEFT_PARETHESIS164=null;
        Token STRINGLITERAL165=null;
        Token RIGHT_PARETHESIS166=null;

        SLAST STRINGLITERAL163_tree=null;
        SLAST LEFT_PARETHESIS164_tree=null;
        SLAST STRINGLITERAL165_tree=null;
        SLAST RIGHT_PARETHESIS166_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:481:3: ( STRINGLITERAL | LEFT_PARETHESIS STRINGLITERAL RIGHT_PARETHESIS )
            int alt35=2;
            int LA35_0 = input.LA(1);

            if ( (LA35_0==STRINGLITERAL) ) {
                alt35=1;
            }
            else if ( (LA35_0==LEFT_PARETHESIS) ) {
                alt35=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 35, 0, input);

                throw nvae;
            }
            switch (alt35) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:481:5: STRINGLITERAL
                    {
                    root_0 = (SLAST)adaptor.nil();

                    STRINGLITERAL163=(Token)match(input,STRINGLITERAL,FOLLOW_STRINGLITERAL_in_use_filename1865); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    STRINGLITERAL163_tree = (SLAST)adaptor.create(STRINGLITERAL163);
                    adaptor.addChild(root_0, STRINGLITERAL163_tree);
                    }

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:482:5: LEFT_PARETHESIS STRINGLITERAL RIGHT_PARETHESIS
                    {
                    root_0 = (SLAST)adaptor.nil();

                    LEFT_PARETHESIS164=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_use_filename1871); if (state.failed) return retval;
                    STRINGLITERAL165=(Token)match(input,STRINGLITERAL,FOLLOW_STRINGLITERAL_in_use_filename1874); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    STRINGLITERAL165_tree = (SLAST)adaptor.create(STRINGLITERAL165);
                    adaptor.addChild(root_0, STRINGLITERAL165_tree);
                    }
                    RIGHT_PARETHESIS166=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_use_filename1876); if (state.failed) return retval;

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "use_filename"

    public static class fully_qualified_class_name_list_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "fully_qualified_class_name_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:498:1: fully_qualified_class_name_list : fully_qualified_class_name ( ',' fully_qualified_class_name )* -> ( fully_qualified_class_name )+ ;
    public final CompilerAstParser.fully_qualified_class_name_list_return fully_qualified_class_name_list() throws RecognitionException {
        CompilerAstParser.fully_qualified_class_name_list_return retval = new CompilerAstParser.fully_qualified_class_name_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token char_literal168=null;
        CompilerAstParser.fully_qualified_class_name_return fully_qualified_class_name167 = null;

        CompilerAstParser.fully_qualified_class_name_return fully_qualified_class_name169 = null;


        SLAST char_literal168_tree=null;
        RewriteRuleTokenStream stream_COMMA_T=new RewriteRuleTokenStream(adaptor,"token COMMA_T");
        RewriteRuleSubtreeStream stream_fully_qualified_class_name=new RewriteRuleSubtreeStream(adaptor,"rule fully_qualified_class_name");
        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:499:3: ( fully_qualified_class_name ( ',' fully_qualified_class_name )* -> ( fully_qualified_class_name )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:499:5: fully_qualified_class_name ( ',' fully_qualified_class_name )*
            {
            pushFollow(FOLLOW_fully_qualified_class_name_in_fully_qualified_class_name_list1905);
            fully_qualified_class_name167=fully_qualified_class_name();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_fully_qualified_class_name.add(fully_qualified_class_name167.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:499:32: ( ',' fully_qualified_class_name )*
            loop36:
            do {
                int alt36=2;
                int LA36_0 = input.LA(1);

                if ( (LA36_0==COMMA_T) ) {
                    alt36=1;
                }


                switch (alt36) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:499:33: ',' fully_qualified_class_name
            	    {
            	    char_literal168=(Token)match(input,COMMA_T,FOLLOW_COMMA_T_in_fully_qualified_class_name_list1908); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_COMMA_T.add(char_literal168);

            	    pushFollow(FOLLOW_fully_qualified_class_name_in_fully_qualified_class_name_list1910);
            	    fully_qualified_class_name169=fully_qualified_class_name();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_fully_qualified_class_name.add(fully_qualified_class_name169.getTree());

            	    }
            	    break;

            	default :
            	    break loop36;
                }
            } while (true);



            // AST REWRITE
            // elements: fully_qualified_class_name
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 499:69: -> ( fully_qualified_class_name )+
            {
                if ( !(stream_fully_qualified_class_name.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_fully_qualified_class_name.hasNext() ) {
                    adaptor.addChild(root_0, stream_fully_qualified_class_name.nextTree());

                }
                stream_fully_qualified_class_name.reset();

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "fully_qualified_class_name_list"

    public static class fully_qualified_class_name_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "fully_qualified_class_name"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:502:1: fully_qualified_class_name : id1= IDENTIFIER ( DOMAIN_T id2= IDENTIFIER )* (d2= DOMAIN_T )? ;
    public final CompilerAstParser.fully_qualified_class_name_return fully_qualified_class_name() throws RecognitionException {
        CompilerAstParser.fully_qualified_class_name_return retval = new CompilerAstParser.fully_qualified_class_name_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token id1=null;
        Token id2=null;
        Token d2=null;
        Token DOMAIN_T170=null;

        SLAST id1_tree=null;
        SLAST id2_tree=null;
        SLAST d2_tree=null;
        SLAST DOMAIN_T170_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:512:3: (id1= IDENTIFIER ( DOMAIN_T id2= IDENTIFIER )* (d2= DOMAIN_T )? )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:512:5: id1= IDENTIFIER ( DOMAIN_T id2= IDENTIFIER )* (d2= DOMAIN_T )?
            {
            root_0 = (SLAST)adaptor.nil();

            id1=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_fully_qualified_class_name1946); if (state.failed) return retval;
            if ( state.backtracking==0 ) {
            id1_tree = (SLAST)adaptor.create(id1);
            adaptor.addChild(root_0, id1_tree);
            }
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:512:20: ( DOMAIN_T id2= IDENTIFIER )*
            loop37:
            do {
                int alt37=2;
                int LA37_0 = input.LA(1);

                if ( (LA37_0==DOMAIN_T) ) {
                    int LA37_1 = input.LA(2);

                    if ( (LA37_1==IDENTIFIER) ) {
                        alt37=1;
                    }


                }


                switch (alt37) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:512:21: DOMAIN_T id2= IDENTIFIER
            	    {
            	    DOMAIN_T170=(Token)match(input,DOMAIN_T,FOLLOW_DOMAIN_T_in_fully_qualified_class_name1949); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    DOMAIN_T170_tree = (SLAST)adaptor.create(DOMAIN_T170);
            	    root_0 = (SLAST)adaptor.becomeRoot(DOMAIN_T170_tree, root_0);
            	    }
            	    id2=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_fully_qualified_class_name1954); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    id2_tree = (SLAST)adaptor.create(id2);
            	    adaptor.addChild(root_0, id2_tree);
            	    }

            	    }
            	    break;

            	default :
            	    break loop37;
                }
            } while (true);

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:512:50: (d2= DOMAIN_T )?
            int alt38=2;
            int LA38_0 = input.LA(1);

            if ( (LA38_0==DOMAIN_T) ) {
                alt38=1;
            }
            switch (alt38) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:512:50: d2= DOMAIN_T
                    {
                    d2=(Token)match(input,DOMAIN_T,FOLLOW_DOMAIN_T_in_fully_qualified_class_name1960); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    d2_tree = (SLAST)adaptor.create(d2);
                    adaptor.addChild(root_0, d2_tree);
                    }

                    }
                    break;

            }

            if ( state.backtracking==0 ) {

                  token = (CommonToken)id1;
                  startIndex = token.getStartIndex();
                  endIndex = token.getStopIndex();
                  if ((d2!=null?d2.getText():null) != null) {
                    endIndex = ((CommonToken)d2).getStopIndex();
                  }
                  else if ((id2!=null?id2.getText():null) != null) {
                    endIndex = ((CommonToken)id2).getStopIndex();
                  }
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "fully_qualified_class_name"

    public static class static_var_list_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "static_var_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:534:1: static_var_list : static_var_element ( COMMA_T static_var_element )* -> ( static_var_element )+ ;
    public final CompilerAstParser.static_var_list_return static_var_list() throws RecognitionException {
        CompilerAstParser.static_var_list_return retval = new CompilerAstParser.static_var_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token COMMA_T172=null;
        CompilerAstParser.static_var_element_return static_var_element171 = null;

        CompilerAstParser.static_var_element_return static_var_element173 = null;


        SLAST COMMA_T172_tree=null;
        RewriteRuleTokenStream stream_COMMA_T=new RewriteRuleTokenStream(adaptor,"token COMMA_T");
        RewriteRuleSubtreeStream stream_static_var_element=new RewriteRuleSubtreeStream(adaptor,"rule static_var_element");
        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:535:3: ( static_var_element ( COMMA_T static_var_element )* -> ( static_var_element )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:535:5: static_var_element ( COMMA_T static_var_element )*
            {
            pushFollow(FOLLOW_static_var_element_in_static_var_list1991);
            static_var_element171=static_var_element();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_static_var_element.add(static_var_element171.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:535:24: ( COMMA_T static_var_element )*
            loop39:
            do {
                int alt39=2;
                int LA39_0 = input.LA(1);

                if ( (LA39_0==COMMA_T) ) {
                    alt39=1;
                }


                switch (alt39) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:535:25: COMMA_T static_var_element
            	    {
            	    COMMA_T172=(Token)match(input,COMMA_T,FOLLOW_COMMA_T_in_static_var_list1994); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_COMMA_T.add(COMMA_T172);

            	    pushFollow(FOLLOW_static_var_element_in_static_var_list1996);
            	    static_var_element173=static_var_element();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_static_var_element.add(static_var_element173.getTree());

            	    }
            	    break;

            	default :
            	    break loop39;
                }
            } while (true);



            // AST REWRITE
            // elements: static_var_element
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 535:55: -> ( static_var_element )+
            {
                if ( !(stream_static_var_element.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_static_var_element.hasNext() ) {
                    adaptor.addChild(root_0, stream_static_var_element.nextTree());

                }
                stream_static_var_element.reset();

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "static_var_list"

    public static class static_var_element_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "static_var_element"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:538:1: static_var_element : pure_variable ( EQUAL_T scalar )? ;
    public final CompilerAstParser.static_var_element_return static_var_element() throws RecognitionException {
        CompilerAstParser.static_var_element_return retval = new CompilerAstParser.static_var_element_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token EQUAL_T175=null;
        CompilerAstParser.pure_variable_return pure_variable174 = null;

        CompilerAstParser.scalar_return scalar176 = null;


        SLAST EQUAL_T175_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:548:3: ( pure_variable ( EQUAL_T scalar )? )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:548:5: pure_variable ( EQUAL_T scalar )?
            {
            root_0 = (SLAST)adaptor.nil();

            pushFollow(FOLLOW_pure_variable_in_static_var_element2028);
            pure_variable174=pure_variable();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, pure_variable174.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:548:19: ( EQUAL_T scalar )?
            int alt40=2;
            int LA40_0 = input.LA(1);

            if ( (LA40_0==EQUAL_T) ) {
                alt40=1;
            }
            switch (alt40) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:548:20: EQUAL_T scalar
                    {
                    EQUAL_T175=(Token)match(input,EQUAL_T,FOLLOW_EQUAL_T_in_static_var_element2031); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    EQUAL_T175_tree = (SLAST)adaptor.create(EQUAL_T175);
                    root_0 = (SLAST)adaptor.becomeRoot(EQUAL_T175_tree, root_0);
                    }
                    pushFollow(FOLLOW_scalar_in_static_var_element2034);
                    scalar176=scalar();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, scalar176.getTree());

                    }
                    break;

            }

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(pure_variable174!=null?((Token)pure_variable174.start):null);
                  startIndex = token.getStartIndex();
                  endIndex = token.getStopIndex();
                  if ((scalar176!=null?input.toString(scalar176.start,scalar176.stop):null) != null) {
                    endIndex = ((CommonToken)(scalar176!=null?((Token)scalar176.stop):null)).getStopIndex();
                  }
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "static_var_element"

    public static class if_stat_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "if_stat"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:559:1: if_stat : IF_T LEFT_PARETHESIS eIfCond= expression RIGHT_PARETHESIS (s1= statement ( options {k=1; backtrack=true; } : ELSEIF_T LEFT_PARETHESIS eElseCond= expression RIGHT_PARETHESIS s2= statement )* ( options {k=1; backtrack=true; } : ELSE_T s3= statement )? -> ^( IF_T ^( CONDITION $eIfCond) $s1 ( ^( ELSEIF_T ^( CONDITION $eElseCond) $s2) )* ( ^( ELSE_T $s3) )? ) | COLON_T ( inner_statement_list )? ( new_elseif_branch )* ( options {k=1; backtrack=true; } : ELSE_T COLON_T s4= statement )? ENDIF_T SEMI_COLON -> ^( IF_T ^( CONDITION $eIfCond) ( inner_statement_list )? ( new_elseif_branch )* ( ^( ELSE_T $s4) )? ) ) ;
    public final CompilerAstParser.if_stat_return if_stat() throws RecognitionException {
        CompilerAstParser.if_stat_return retval = new CompilerAstParser.if_stat_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token IF_T177=null;
        Token LEFT_PARETHESIS178=null;
        Token RIGHT_PARETHESIS179=null;
        Token ELSEIF_T180=null;
        Token LEFT_PARETHESIS181=null;
        Token RIGHT_PARETHESIS182=null;
        Token ELSE_T183=null;
        Token COLON_T184=null;
        Token ELSE_T187=null;
        Token COLON_T188=null;
        Token ENDIF_T189=null;
        Token SEMI_COLON190=null;
        CompilerAstParser.expression_return eIfCond = null;

        CompilerAstParser.statement_return s1 = null;

        CompilerAstParser.expression_return eElseCond = null;

        CompilerAstParser.statement_return s2 = null;

        CompilerAstParser.statement_return s3 = null;

        CompilerAstParser.statement_return s4 = null;

        CompilerAstParser.inner_statement_list_return inner_statement_list185 = null;

        CompilerAstParser.new_elseif_branch_return new_elseif_branch186 = null;


        SLAST IF_T177_tree=null;
        SLAST LEFT_PARETHESIS178_tree=null;
        SLAST RIGHT_PARETHESIS179_tree=null;
        SLAST ELSEIF_T180_tree=null;
        SLAST LEFT_PARETHESIS181_tree=null;
        SLAST RIGHT_PARETHESIS182_tree=null;
        SLAST ELSE_T183_tree=null;
        SLAST COLON_T184_tree=null;
        SLAST ELSE_T187_tree=null;
        SLAST COLON_T188_tree=null;
        SLAST ENDIF_T189_tree=null;
        SLAST SEMI_COLON190_tree=null;
        RewriteRuleTokenStream stream_LEFT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token LEFT_PARETHESIS");
        RewriteRuleTokenStream stream_SEMI_COLON=new RewriteRuleTokenStream(adaptor,"token SEMI_COLON");
        RewriteRuleTokenStream stream_COLON_T=new RewriteRuleTokenStream(adaptor,"token COLON_T");
        RewriteRuleTokenStream stream_IF_T=new RewriteRuleTokenStream(adaptor,"token IF_T");
        RewriteRuleTokenStream stream_ELSEIF_T=new RewriteRuleTokenStream(adaptor,"token ELSEIF_T");
        RewriteRuleTokenStream stream_ENDIF_T=new RewriteRuleTokenStream(adaptor,"token ENDIF_T");
        RewriteRuleTokenStream stream_RIGHT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token RIGHT_PARETHESIS");
        RewriteRuleTokenStream stream_ELSE_T=new RewriteRuleTokenStream(adaptor,"token ELSE_T");
        RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");
        RewriteRuleSubtreeStream stream_statement=new RewriteRuleSubtreeStream(adaptor,"rule statement");
        RewriteRuleSubtreeStream stream_inner_statement_list=new RewriteRuleSubtreeStream(adaptor,"rule inner_statement_list");
        RewriteRuleSubtreeStream stream_new_elseif_branch=new RewriteRuleSubtreeStream(adaptor,"rule new_elseif_branch");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:569:3: ( IF_T LEFT_PARETHESIS eIfCond= expression RIGHT_PARETHESIS (s1= statement ( options {k=1; backtrack=true; } : ELSEIF_T LEFT_PARETHESIS eElseCond= expression RIGHT_PARETHESIS s2= statement )* ( options {k=1; backtrack=true; } : ELSE_T s3= statement )? -> ^( IF_T ^( CONDITION $eIfCond) $s1 ( ^( ELSEIF_T ^( CONDITION $eElseCond) $s2) )* ( ^( ELSE_T $s3) )? ) | COLON_T ( inner_statement_list )? ( new_elseif_branch )* ( options {k=1; backtrack=true; } : ELSE_T COLON_T s4= statement )? ENDIF_T SEMI_COLON -> ^( IF_T ^( CONDITION $eIfCond) ( inner_statement_list )? ( new_elseif_branch )* ( ^( ELSE_T $s4) )? ) ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:569:5: IF_T LEFT_PARETHESIS eIfCond= expression RIGHT_PARETHESIS (s1= statement ( options {k=1; backtrack=true; } : ELSEIF_T LEFT_PARETHESIS eElseCond= expression RIGHT_PARETHESIS s2= statement )* ( options {k=1; backtrack=true; } : ELSE_T s3= statement )? -> ^( IF_T ^( CONDITION $eIfCond) $s1 ( ^( ELSEIF_T ^( CONDITION $eElseCond) $s2) )* ( ^( ELSE_T $s3) )? ) | COLON_T ( inner_statement_list )? ( new_elseif_branch )* ( options {k=1; backtrack=true; } : ELSE_T COLON_T s4= statement )? ENDIF_T SEMI_COLON -> ^( IF_T ^( CONDITION $eIfCond) ( inner_statement_list )? ( new_elseif_branch )* ( ^( ELSE_T $s4) )? ) )
            {
            IF_T177=(Token)match(input,IF_T,FOLLOW_IF_T_in_if_stat2065); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_IF_T.add(IF_T177);

            LEFT_PARETHESIS178=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_if_stat2067); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS178);

            pushFollow(FOLLOW_expression_in_if_stat2071);
            eIfCond=expression();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_expression.add(eIfCond.getTree());
            RIGHT_PARETHESIS179=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_if_stat2073); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS179);

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:570:5: (s1= statement ( options {k=1; backtrack=true; } : ELSEIF_T LEFT_PARETHESIS eElseCond= expression RIGHT_PARETHESIS s2= statement )* ( options {k=1; backtrack=true; } : ELSE_T s3= statement )? -> ^( IF_T ^( CONDITION $eIfCond) $s1 ( ^( ELSEIF_T ^( CONDITION $eElseCond) $s2) )* ( ^( ELSE_T $s3) )? ) | COLON_T ( inner_statement_list )? ( new_elseif_branch )* ( options {k=1; backtrack=true; } : ELSE_T COLON_T s4= statement )? ENDIF_T SEMI_COLON -> ^( IF_T ^( CONDITION $eIfCond) ( inner_statement_list )? ( new_elseif_branch )* ( ^( ELSE_T $s4) )? ) )
            int alt46=2;
            int LA46_0 = input.LA(1);

            if ( (LA46_0==LEFT_PARETHESIS||LA46_0==SEMI_COLON||LA46_0==IDENTIFIER||LA46_0==LEFT_BRACKET||LA46_0==REF_T||(LA46_0>=WHILE_T && LA46_0<=FOREACH_T)||(LA46_0>=DECLARE_T && LA46_0<=STRINGLITERAL)||LA46_0==IF_T||(LA46_0>=PLUS_T && LA46_0<=MINUS_T)||(LA46_0>=CLONE_T && LA46_0<=MINUS_MINUS_T)||(LA46_0>=AT_T && LA46_0<=PRINT_T)||(LA46_0>=DOLLAR_T && LA46_0<=DOUBLELITERRAL)||(LA46_0>=182 && LA46_0<=188)) ) {
                alt46=1;
            }
            else if ( (LA46_0==COLON_T) ) {
                alt46=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 46, 0, input);

                throw nvae;
            }
            switch (alt46) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:571:7: s1= statement ( options {k=1; backtrack=true; } : ELSEIF_T LEFT_PARETHESIS eElseCond= expression RIGHT_PARETHESIS s2= statement )* ( options {k=1; backtrack=true; } : ELSE_T s3= statement )?
                    {
                    pushFollow(FOLLOW_statement_in_if_stat2089);
                    s1=statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_statement.add(s1.getTree());
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:571:20: ( options {k=1; backtrack=true; } : ELSEIF_T LEFT_PARETHESIS eElseCond= expression RIGHT_PARETHESIS s2= statement )*
                    loop41:
                    do {
                        int alt41=2;
                        alt41 = dfa41.predict(input);
                        switch (alt41) {
                    	case 1 :
                    	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:571:53: ELSEIF_T LEFT_PARETHESIS eElseCond= expression RIGHT_PARETHESIS s2= statement
                    	    {
                    	    ELSEIF_T180=(Token)match(input,ELSEIF_T,FOLLOW_ELSEIF_T_in_if_stat2105); if (state.failed) return retval; 
                    	    if ( state.backtracking==0 ) stream_ELSEIF_T.add(ELSEIF_T180);

                    	    LEFT_PARETHESIS181=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_if_stat2107); if (state.failed) return retval; 
                    	    if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS181);

                    	    pushFollow(FOLLOW_expression_in_if_stat2111);
                    	    eElseCond=expression();

                    	    state._fsp--;
                    	    if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) stream_expression.add(eElseCond.getTree());
                    	    RIGHT_PARETHESIS182=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_if_stat2113); if (state.failed) return retval; 
                    	    if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS182);

                    	    pushFollow(FOLLOW_statement_in_if_stat2117);
                    	    s2=statement();

                    	    state._fsp--;
                    	    if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) stream_statement.add(s2.getTree());

                    	    }
                    	    break;

                    	default :
                    	    break loop41;
                        }
                    } while (true);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:572:9: ( options {k=1; backtrack=true; } : ELSE_T s3= statement )?
                    int alt42=2;
                    alt42 = dfa42.predict(input);
                    switch (alt42) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:572:42: ELSE_T s3= statement
                            {
                            ELSE_T183=(Token)match(input,ELSE_T,FOLLOW_ELSE_T_in_if_stat2143); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_ELSE_T.add(ELSE_T183);

                            pushFollow(FOLLOW_statement_in_if_stat2147);
                            s3=statement();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_statement.add(s3.getTree());

                            }
                            break;

                    }

                    if ( state.backtracking==0 ) {

                              startIndex = ((CommonToken)IF_T177).getStartIndex();
                              endIndex = ((CommonToken)(s1!=null?((Token)s1.stop):null)).getStopIndex();
                              if ((s2!=null?input.toString(s2.start,s2.stop):null) != null) {
                                endIndex = ((CommonToken)(s2!=null?((Token)s2.stop):null)).getStopIndex();
                              }
                              if ((s3!=null?input.toString(s3.start,s3.stop):null) != null) {
                                endIndex = ((CommonToken)(s3!=null?((Token)s3.stop):null)).getStopIndex();
                              }
                           
                    }


                    // AST REWRITE
                    // elements: s2, IF_T, ELSE_T, s1, eIfCond, eElseCond, s3, ELSEIF_T
                    // token labels: 
                    // rule labels: retval, s2, s1, eIfCond, s3, eElseCond
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
                    RewriteRuleSubtreeStream stream_s2=new RewriteRuleSubtreeStream(adaptor,"rule s2",s2!=null?s2.tree:null);
                    RewriteRuleSubtreeStream stream_s1=new RewriteRuleSubtreeStream(adaptor,"rule s1",s1!=null?s1.tree:null);
                    RewriteRuleSubtreeStream stream_eIfCond=new RewriteRuleSubtreeStream(adaptor,"rule eIfCond",eIfCond!=null?eIfCond.tree:null);
                    RewriteRuleSubtreeStream stream_s3=new RewriteRuleSubtreeStream(adaptor,"rule s3",s3!=null?s3.tree:null);
                    RewriteRuleSubtreeStream stream_eElseCond=new RewriteRuleSubtreeStream(adaptor,"rule eElseCond",eElseCond!=null?eElseCond.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 583:7: -> ^( IF_T ^( CONDITION $eIfCond) $s1 ( ^( ELSEIF_T ^( CONDITION $eElseCond) $s2) )* ( ^( ELSE_T $s3) )? )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:583:11: ^( IF_T ^( CONDITION $eIfCond) $s1 ( ^( ELSEIF_T ^( CONDITION $eElseCond) $s2) )* ( ^( ELSE_T $s3) )? )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_IF_T.nextNode(), root_1);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:583:18: ^( CONDITION $eIfCond)
                        {
                        SLAST root_2 = (SLAST)adaptor.nil();
                        root_2 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(CONDITION, "CONDITION"), root_2);

                        adaptor.addChild(root_2, stream_eIfCond.nextTree());

                        adaptor.addChild(root_1, root_2);
                        }
                        adaptor.addChild(root_1, stream_s1.nextTree());
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:583:45: ( ^( ELSEIF_T ^( CONDITION $eElseCond) $s2) )*
                        while ( stream_s2.hasNext()||stream_eElseCond.hasNext()||stream_ELSEIF_T.hasNext() ) {
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:583:45: ^( ELSEIF_T ^( CONDITION $eElseCond) $s2)
                            {
                            SLAST root_2 = (SLAST)adaptor.nil();
                            root_2 = (SLAST)adaptor.becomeRoot(stream_ELSEIF_T.nextNode(), root_2);

                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:583:56: ^( CONDITION $eElseCond)
                            {
                            SLAST root_3 = (SLAST)adaptor.nil();
                            root_3 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(CONDITION, "CONDITION"), root_3);

                            adaptor.addChild(root_3, stream_eElseCond.nextTree());

                            adaptor.addChild(root_2, root_3);
                            }
                            adaptor.addChild(root_2, stream_s2.nextTree());

                            adaptor.addChild(root_1, root_2);
                            }

                        }
                        stream_s2.reset();
                        stream_eElseCond.reset();
                        stream_ELSEIF_T.reset();
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:583:86: ( ^( ELSE_T $s3) )?
                        if ( stream_ELSE_T.hasNext()||stream_s3.hasNext() ) {
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:583:86: ^( ELSE_T $s3)
                            {
                            SLAST root_2 = (SLAST)adaptor.nil();
                            root_2 = (SLAST)adaptor.becomeRoot(stream_ELSE_T.nextNode(), root_2);

                            adaptor.addChild(root_2, stream_s3.nextTree());

                            adaptor.addChild(root_1, root_2);
                            }

                        }
                        stream_ELSE_T.reset();
                        stream_s3.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:584:9: COLON_T ( inner_statement_list )? ( new_elseif_branch )* ( options {k=1; backtrack=true; } : ELSE_T COLON_T s4= statement )? ENDIF_T SEMI_COLON
                    {
                    COLON_T184=(Token)match(input,COLON_T,FOLLOW_COLON_T_in_if_stat2213); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_COLON_T.add(COLON_T184);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:584:17: ( inner_statement_list )?
                    int alt43=2;
                    int LA43_0 = input.LA(1);

                    if ( (LA43_0==LEFT_PARETHESIS||(LA43_0>=SEMI_COLON && LA43_0<=IDENTIFIER)||LA43_0==LEFT_BRACKET||(LA43_0>=INTERFACE_T && LA43_0<=REF_T)||(LA43_0>=WHILE_T && LA43_0<=FOREACH_T)||(LA43_0>=DECLARE_T && LA43_0<=STRINGLITERAL)||LA43_0==IF_T||(LA43_0>=PLUS_T && LA43_0<=MINUS_T)||(LA43_0>=CLONE_T && LA43_0<=MINUS_MINUS_T)||(LA43_0>=AT_T && LA43_0<=PRINT_T)||(LA43_0>=DOLLAR_T && LA43_0<=DOUBLELITERRAL)||(LA43_0>=166 && LA43_0<=168)||(LA43_0>=182 && LA43_0<=188)) ) {
                        alt43=1;
                    }
                    switch (alt43) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:584:17: inner_statement_list
                            {
                            pushFollow(FOLLOW_inner_statement_list_in_if_stat2215);
                            inner_statement_list185=inner_statement_list();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_inner_statement_list.add(inner_statement_list185.getTree());

                            }
                            break;

                    }

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:584:39: ( new_elseif_branch )*
                    loop44:
                    do {
                        int alt44=2;
                        int LA44_0 = input.LA(1);

                        if ( (LA44_0==ELSEIF_T) ) {
                            alt44=1;
                        }


                        switch (alt44) {
                    	case 1 :
                    	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:584:39: new_elseif_branch
                    	    {
                    	    pushFollow(FOLLOW_new_elseif_branch_in_if_stat2218);
                    	    new_elseif_branch186=new_elseif_branch();

                    	    state._fsp--;
                    	    if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) stream_new_elseif_branch.add(new_elseif_branch186.getTree());

                    	    }
                    	    break;

                    	default :
                    	    break loop44;
                        }
                    } while (true);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:584:58: ( options {k=1; backtrack=true; } : ELSE_T COLON_T s4= statement )?
                    int alt45=2;
                    int LA45_0 = input.LA(1);

                    if ( (LA45_0==ELSE_T) ) {
                        alt45=1;
                    }
                    switch (alt45) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:584:91: ELSE_T COLON_T s4= statement
                            {
                            ELSE_T187=(Token)match(input,ELSE_T,FOLLOW_ELSE_T_in_if_stat2235); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_ELSE_T.add(ELSE_T187);

                            COLON_T188=(Token)match(input,COLON_T,FOLLOW_COLON_T_in_if_stat2237); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_COLON_T.add(COLON_T188);

                            pushFollow(FOLLOW_statement_in_if_stat2241);
                            s4=statement();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_statement.add(s4.getTree());

                            }
                            break;

                    }

                    ENDIF_T189=(Token)match(input,ENDIF_T,FOLLOW_ENDIF_T_in_if_stat2245); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_ENDIF_T.add(ENDIF_T189);

                    SEMI_COLON190=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_if_stat2247); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON190);

                    if ( state.backtracking==0 ) {

                              startIndex = ((CommonToken)IF_T177).getStartIndex();
                              endIndex = ((CommonToken)SEMI_COLON190).getStopIndex();
                           
                    }


                    // AST REWRITE
                    // elements: s4, IF_T, ELSE_T, eIfCond, new_elseif_branch, inner_statement_list
                    // token labels: 
                    // rule labels: retval, eIfCond, s4
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
                    RewriteRuleSubtreeStream stream_eIfCond=new RewriteRuleSubtreeStream(adaptor,"rule eIfCond",eIfCond!=null?eIfCond.tree:null);
                    RewriteRuleSubtreeStream stream_s4=new RewriteRuleSubtreeStream(adaptor,"rule s4",s4!=null?s4.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 589:7: -> ^( IF_T ^( CONDITION $eIfCond) ( inner_statement_list )? ( new_elseif_branch )* ( ^( ELSE_T $s4) )? )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:589:11: ^( IF_T ^( CONDITION $eIfCond) ( inner_statement_list )? ( new_elseif_branch )* ( ^( ELSE_T $s4) )? )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_IF_T.nextNode(), root_1);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:589:18: ^( CONDITION $eIfCond)
                        {
                        SLAST root_2 = (SLAST)adaptor.nil();
                        root_2 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(CONDITION, "CONDITION"), root_2);

                        adaptor.addChild(root_2, stream_eIfCond.nextTree());

                        adaptor.addChild(root_1, root_2);
                        }
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:589:40: ( inner_statement_list )?
                        if ( stream_inner_statement_list.hasNext() ) {
                            adaptor.addChild(root_1, stream_inner_statement_list.nextTree());

                        }
                        stream_inner_statement_list.reset();
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:589:62: ( new_elseif_branch )*
                        while ( stream_new_elseif_branch.hasNext() ) {
                            adaptor.addChild(root_1, stream_new_elseif_branch.nextTree());

                        }
                        stream_new_elseif_branch.reset();
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:589:81: ( ^( ELSE_T $s4) )?
                        if ( stream_s4.hasNext()||stream_ELSE_T.hasNext() ) {
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:589:81: ^( ELSE_T $s4)
                            {
                            SLAST root_2 = (SLAST)adaptor.nil();
                            root_2 = (SLAST)adaptor.becomeRoot(stream_ELSE_T.nextNode(), root_2);

                            adaptor.addChild(root_2, stream_s4.nextTree());

                            adaptor.addChild(root_1, root_2);
                            }

                        }
                        stream_s4.reset();
                        stream_ELSE_T.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "if_stat"

    public static class new_elseif_branch_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "new_elseif_branch"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:593:1: new_elseif_branch : ELSEIF_T LEFT_PARETHESIS expression RIGHT_PARETHESIS COLON_T ( inner_statement_list )? -> ^( ELSEIF_T ^( CONDITION expression ) ( inner_statement_list )? ) ;
    public final CompilerAstParser.new_elseif_branch_return new_elseif_branch() throws RecognitionException {
        CompilerAstParser.new_elseif_branch_return retval = new CompilerAstParser.new_elseif_branch_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token ELSEIF_T191=null;
        Token LEFT_PARETHESIS192=null;
        Token RIGHT_PARETHESIS194=null;
        Token COLON_T195=null;
        CompilerAstParser.expression_return expression193 = null;

        CompilerAstParser.inner_statement_list_return inner_statement_list196 = null;


        SLAST ELSEIF_T191_tree=null;
        SLAST LEFT_PARETHESIS192_tree=null;
        SLAST RIGHT_PARETHESIS194_tree=null;
        SLAST COLON_T195_tree=null;
        RewriteRuleTokenStream stream_LEFT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token LEFT_PARETHESIS");
        RewriteRuleTokenStream stream_COLON_T=new RewriteRuleTokenStream(adaptor,"token COLON_T");
        RewriteRuleTokenStream stream_ELSEIF_T=new RewriteRuleTokenStream(adaptor,"token ELSEIF_T");
        RewriteRuleTokenStream stream_RIGHT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token RIGHT_PARETHESIS");
        RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");
        RewriteRuleSubtreeStream stream_inner_statement_list=new RewriteRuleSubtreeStream(adaptor,"rule inner_statement_list");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:603:2: ( ELSEIF_T LEFT_PARETHESIS expression RIGHT_PARETHESIS COLON_T ( inner_statement_list )? -> ^( ELSEIF_T ^( CONDITION expression ) ( inner_statement_list )? ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:603:4: ELSEIF_T LEFT_PARETHESIS expression RIGHT_PARETHESIS COLON_T ( inner_statement_list )?
            {
            ELSEIF_T191=(Token)match(input,ELSEIF_T,FOLLOW_ELSEIF_T_in_new_elseif_branch2318); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_ELSEIF_T.add(ELSEIF_T191);

            LEFT_PARETHESIS192=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_new_elseif_branch2320); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS192);

            pushFollow(FOLLOW_expression_in_new_elseif_branch2322);
            expression193=expression();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_expression.add(expression193.getTree());
            RIGHT_PARETHESIS194=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_new_elseif_branch2324); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS194);

            COLON_T195=(Token)match(input,COLON_T,FOLLOW_COLON_T_in_new_elseif_branch2326); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_COLON_T.add(COLON_T195);

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:603:65: ( inner_statement_list )?
            int alt47=2;
            int LA47_0 = input.LA(1);

            if ( (LA47_0==LEFT_PARETHESIS||(LA47_0>=SEMI_COLON && LA47_0<=IDENTIFIER)||LA47_0==LEFT_BRACKET||(LA47_0>=INTERFACE_T && LA47_0<=REF_T)||(LA47_0>=WHILE_T && LA47_0<=FOREACH_T)||(LA47_0>=DECLARE_T && LA47_0<=STRINGLITERAL)||LA47_0==IF_T||(LA47_0>=PLUS_T && LA47_0<=MINUS_T)||(LA47_0>=CLONE_T && LA47_0<=MINUS_MINUS_T)||(LA47_0>=AT_T && LA47_0<=PRINT_T)||(LA47_0>=DOLLAR_T && LA47_0<=DOUBLELITERRAL)||(LA47_0>=166 && LA47_0<=168)||(LA47_0>=182 && LA47_0<=188)) ) {
                alt47=1;
            }
            switch (alt47) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:603:65: inner_statement_list
                    {
                    pushFollow(FOLLOW_inner_statement_list_in_new_elseif_branch2328);
                    inner_statement_list196=inner_statement_list();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_inner_statement_list.add(inner_statement_list196.getTree());

                    }
                    break;

            }

            if ( state.backtracking==0 ) {

                  token = (CommonToken)ELSEIF_T191;
                  startIndex = token.getStartIndex();
                  token = (CommonToken)COLON_T195;
                  endIndex = token.getStopIndex();
                  if ((inner_statement_list196!=null?input.toString(inner_statement_list196.start,inner_statement_list196.stop):null) != null) {
                    endIndex = ((CommonToken)(inner_statement_list196!=null?((Token)inner_statement_list196.stop):null)).getStopIndex();
                  }
                
            }


            // AST REWRITE
            // elements: inner_statement_list, ELSEIF_T, expression
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 613:4: -> ^( ELSEIF_T ^( CONDITION expression ) ( inner_statement_list )? )
            {
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:613:8: ^( ELSEIF_T ^( CONDITION expression ) ( inner_statement_list )? )
                {
                SLAST root_1 = (SLAST)adaptor.nil();
                root_1 = (SLAST)adaptor.becomeRoot(stream_ELSEIF_T.nextNode(), root_1);

                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:613:19: ^( CONDITION expression )
                {
                SLAST root_2 = (SLAST)adaptor.nil();
                root_2 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(CONDITION, "CONDITION"), root_2);

                adaptor.addChild(root_2, stream_expression.nextTree());

                adaptor.addChild(root_1, root_2);
                }
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:613:43: ( inner_statement_list )?
                if ( stream_inner_statement_list.hasNext() ) {
                    adaptor.addChild(root_1, stream_inner_statement_list.nextTree());

                }
                stream_inner_statement_list.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "new_elseif_branch"

    public static class switch_case_list_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "switch_case_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:616:1: switch_case_list : ( LEFT_BRACKET ( SEMI_COLON )? ( case_list )+ RIGHT_BRACKET -> ( case_list )+ | COLON_T ( SEMI_COLON )? ( case_list )+ ENDSWITCH_T SEMI_COLON -> ( case_list )+ );
    public final CompilerAstParser.switch_case_list_return switch_case_list() throws RecognitionException {
        CompilerAstParser.switch_case_list_return retval = new CompilerAstParser.switch_case_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token LEFT_BRACKET197=null;
        Token SEMI_COLON198=null;
        Token RIGHT_BRACKET200=null;
        Token COLON_T201=null;
        Token SEMI_COLON202=null;
        Token ENDSWITCH_T204=null;
        Token SEMI_COLON205=null;
        CompilerAstParser.case_list_return case_list199 = null;

        CompilerAstParser.case_list_return case_list203 = null;


        SLAST LEFT_BRACKET197_tree=null;
        SLAST SEMI_COLON198_tree=null;
        SLAST RIGHT_BRACKET200_tree=null;
        SLAST COLON_T201_tree=null;
        SLAST SEMI_COLON202_tree=null;
        SLAST ENDSWITCH_T204_tree=null;
        SLAST SEMI_COLON205_tree=null;
        RewriteRuleTokenStream stream_SEMI_COLON=new RewriteRuleTokenStream(adaptor,"token SEMI_COLON");
        RewriteRuleTokenStream stream_COLON_T=new RewriteRuleTokenStream(adaptor,"token COLON_T");
        RewriteRuleTokenStream stream_ENDSWITCH_T=new RewriteRuleTokenStream(adaptor,"token ENDSWITCH_T");
        RewriteRuleTokenStream stream_LEFT_BRACKET=new RewriteRuleTokenStream(adaptor,"token LEFT_BRACKET");
        RewriteRuleTokenStream stream_RIGHT_BRACKET=new RewriteRuleTokenStream(adaptor,"token RIGHT_BRACKET");
        RewriteRuleSubtreeStream stream_case_list=new RewriteRuleSubtreeStream(adaptor,"rule case_list");
        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:617:3: ( LEFT_BRACKET ( SEMI_COLON )? ( case_list )+ RIGHT_BRACKET -> ( case_list )+ | COLON_T ( SEMI_COLON )? ( case_list )+ ENDSWITCH_T SEMI_COLON -> ( case_list )+ )
            int alt52=2;
            int LA52_0 = input.LA(1);

            if ( (LA52_0==LEFT_BRACKET) ) {
                alt52=1;
            }
            else if ( (LA52_0==COLON_T) ) {
                alt52=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 52, 0, input);

                throw nvae;
            }
            switch (alt52) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:617:5: LEFT_BRACKET ( SEMI_COLON )? ( case_list )+ RIGHT_BRACKET
                    {
                    LEFT_BRACKET197=(Token)match(input,LEFT_BRACKET,FOLLOW_LEFT_BRACKET_in_switch_case_list2366); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LEFT_BRACKET.add(LEFT_BRACKET197);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:617:18: ( SEMI_COLON )?
                    int alt48=2;
                    int LA48_0 = input.LA(1);

                    if ( (LA48_0==SEMI_COLON) ) {
                        alt48=1;
                    }
                    switch (alt48) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:617:18: SEMI_COLON
                            {
                            SEMI_COLON198=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_switch_case_list2368); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON198);


                            }
                            break;

                    }

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:617:30: ( case_list )+
                    int cnt49=0;
                    loop49:
                    do {
                        int alt49=2;
                        int LA49_0 = input.LA(1);

                        if ( ((LA49_0>=CASE_T && LA49_0<=DEFAULT_T)) ) {
                            alt49=1;
                        }


                        switch (alt49) {
                    	case 1 :
                    	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:617:30: case_list
                    	    {
                    	    pushFollow(FOLLOW_case_list_in_switch_case_list2371);
                    	    case_list199=case_list();

                    	    state._fsp--;
                    	    if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) stream_case_list.add(case_list199.getTree());

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt49 >= 1 ) break loop49;
                    	    if (state.backtracking>0) {state.failed=true; return retval;}
                                EarlyExitException eee =
                                    new EarlyExitException(49, input);
                                throw eee;
                        }
                        cnt49++;
                    } while (true);

                    RIGHT_BRACKET200=(Token)match(input,RIGHT_BRACKET,FOLLOW_RIGHT_BRACKET_in_switch_case_list2374); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RIGHT_BRACKET.add(RIGHT_BRACKET200);



                    // AST REWRITE
                    // elements: case_list
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 617:65: -> ( case_list )+
                    {
                        if ( !(stream_case_list.hasNext()) ) {
                            throw new RewriteEarlyExitException();
                        }
                        while ( stream_case_list.hasNext() ) {
                            adaptor.addChild(root_0, stream_case_list.nextTree());

                        }
                        stream_case_list.reset();

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:618:5: COLON_T ( SEMI_COLON )? ( case_list )+ ENDSWITCH_T SEMI_COLON
                    {
                    COLON_T201=(Token)match(input,COLON_T,FOLLOW_COLON_T_in_switch_case_list2396); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_COLON_T.add(COLON_T201);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:618:13: ( SEMI_COLON )?
                    int alt50=2;
                    int LA50_0 = input.LA(1);

                    if ( (LA50_0==SEMI_COLON) ) {
                        alt50=1;
                    }
                    switch (alt50) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:618:13: SEMI_COLON
                            {
                            SEMI_COLON202=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_switch_case_list2398); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON202);


                            }
                            break;

                    }

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:618:25: ( case_list )+
                    int cnt51=0;
                    loop51:
                    do {
                        int alt51=2;
                        int LA51_0 = input.LA(1);

                        if ( ((LA51_0>=CASE_T && LA51_0<=DEFAULT_T)) ) {
                            alt51=1;
                        }


                        switch (alt51) {
                    	case 1 :
                    	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:618:25: case_list
                    	    {
                    	    pushFollow(FOLLOW_case_list_in_switch_case_list2401);
                    	    case_list203=case_list();

                    	    state._fsp--;
                    	    if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) stream_case_list.add(case_list203.getTree());

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt51 >= 1 ) break loop51;
                    	    if (state.backtracking>0) {state.failed=true; return retval;}
                                EarlyExitException eee =
                                    new EarlyExitException(51, input);
                                throw eee;
                        }
                        cnt51++;
                    } while (true);

                    ENDSWITCH_T204=(Token)match(input,ENDSWITCH_T,FOLLOW_ENDSWITCH_T_in_switch_case_list2404); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_ENDSWITCH_T.add(ENDSWITCH_T204);

                    SEMI_COLON205=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_switch_case_list2406); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON205);



                    // AST REWRITE
                    // elements: case_list
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 618:63: -> ( case_list )+
                    {
                        if ( !(stream_case_list.hasNext()) ) {
                            throw new RewriteEarlyExitException();
                        }
                        while ( stream_case_list.hasNext() ) {
                            adaptor.addChild(root_0, stream_case_list.nextTree());

                        }
                        stream_case_list.reset();

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "switch_case_list"

    public static class case_list_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "case_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:621:1: case_list : ( CASE_T expression ( COLON_T | SEMI_COLON ) ( inner_statement_list )? -> ^( CASE_T expression ( inner_statement_list )? ) | DEFAULT_T ( COLON_T | SEMI_COLON ) ( inner_statement_list )? -> ^( DEFAULT_T ( inner_statement_list )? ) );
    public final CompilerAstParser.case_list_return case_list() throws RecognitionException {
        CompilerAstParser.case_list_return retval = new CompilerAstParser.case_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token CASE_T206=null;
        Token COLON_T208=null;
        Token SEMI_COLON209=null;
        Token DEFAULT_T211=null;
        Token COLON_T212=null;
        Token SEMI_COLON213=null;
        CompilerAstParser.expression_return expression207 = null;

        CompilerAstParser.inner_statement_list_return inner_statement_list210 = null;

        CompilerAstParser.inner_statement_list_return inner_statement_list214 = null;


        SLAST CASE_T206_tree=null;
        SLAST COLON_T208_tree=null;
        SLAST SEMI_COLON209_tree=null;
        SLAST DEFAULT_T211_tree=null;
        SLAST COLON_T212_tree=null;
        SLAST SEMI_COLON213_tree=null;
        RewriteRuleTokenStream stream_CASE_T=new RewriteRuleTokenStream(adaptor,"token CASE_T");
        RewriteRuleTokenStream stream_SEMI_COLON=new RewriteRuleTokenStream(adaptor,"token SEMI_COLON");
        RewriteRuleTokenStream stream_COLON_T=new RewriteRuleTokenStream(adaptor,"token COLON_T");
        RewriteRuleTokenStream stream_DEFAULT_T=new RewriteRuleTokenStream(adaptor,"token DEFAULT_T");
        RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");
        RewriteRuleSubtreeStream stream_inner_statement_list=new RewriteRuleSubtreeStream(adaptor,"rule inner_statement_list");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:631:3: ( CASE_T expression ( COLON_T | SEMI_COLON ) ( inner_statement_list )? -> ^( CASE_T expression ( inner_statement_list )? ) | DEFAULT_T ( COLON_T | SEMI_COLON ) ( inner_statement_list )? -> ^( DEFAULT_T ( inner_statement_list )? ) )
            int alt57=2;
            int LA57_0 = input.LA(1);

            if ( (LA57_0==CASE_T) ) {
                alt57=1;
            }
            else if ( (LA57_0==DEFAULT_T) ) {
                alt57=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 57, 0, input);

                throw nvae;
            }
            switch (alt57) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:631:5: CASE_T expression ( COLON_T | SEMI_COLON ) ( inner_statement_list )?
                    {
                    CASE_T206=(Token)match(input,CASE_T,FOLLOW_CASE_T_in_case_list2439); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_CASE_T.add(CASE_T206);

                    pushFollow(FOLLOW_expression_in_case_list2441);
                    expression207=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_expression.add(expression207.getTree());
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:631:23: ( COLON_T | SEMI_COLON )
                    int alt53=2;
                    int LA53_0 = input.LA(1);

                    if ( (LA53_0==COLON_T) ) {
                        alt53=1;
                    }
                    else if ( (LA53_0==SEMI_COLON) ) {
                        alt53=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return retval;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 53, 0, input);

                        throw nvae;
                    }
                    switch (alt53) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:631:24: COLON_T
                            {
                            COLON_T208=(Token)match(input,COLON_T,FOLLOW_COLON_T_in_case_list2444); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_COLON_T.add(COLON_T208);


                            }
                            break;
                        case 2 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:631:34: SEMI_COLON
                            {
                            SEMI_COLON209=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_case_list2448); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON209);


                            }
                            break;

                    }

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:631:46: ( inner_statement_list )?
                    int alt54=2;
                    int LA54_0 = input.LA(1);

                    if ( (LA54_0==LEFT_PARETHESIS||(LA54_0>=SEMI_COLON && LA54_0<=IDENTIFIER)||LA54_0==LEFT_BRACKET||(LA54_0>=INTERFACE_T && LA54_0<=REF_T)||(LA54_0>=WHILE_T && LA54_0<=FOREACH_T)||(LA54_0>=DECLARE_T && LA54_0<=STRINGLITERAL)||LA54_0==IF_T||(LA54_0>=PLUS_T && LA54_0<=MINUS_T)||(LA54_0>=CLONE_T && LA54_0<=MINUS_MINUS_T)||(LA54_0>=AT_T && LA54_0<=PRINT_T)||(LA54_0>=DOLLAR_T && LA54_0<=DOUBLELITERRAL)||(LA54_0>=166 && LA54_0<=168)||(LA54_0>=182 && LA54_0<=188)) ) {
                        alt54=1;
                    }
                    switch (alt54) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:631:46: inner_statement_list
                            {
                            pushFollow(FOLLOW_inner_statement_list_in_case_list2451);
                            inner_statement_list210=inner_statement_list();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_inner_statement_list.add(inner_statement_list210.getTree());

                            }
                            break;

                    }

                    if ( state.backtracking==0 ) {

                          token = (CommonToken)CASE_T206;
                          startIndex = token.getStartIndex();
                          token = (CommonToken)COLON_T208;
                          if ((SEMI_COLON209!=null?SEMI_COLON209.getText():null) != null) {
                            token = (CommonToken)SEMI_COLON209;
                          }
                          endIndex = token.getStopIndex();
                          if ((inner_statement_list210!=null?input.toString(inner_statement_list210.start,inner_statement_list210.stop):null) != null) {
                            endIndex = ((CommonToken)(inner_statement_list210!=null?((Token)inner_statement_list210.stop):null)).getStopIndex();
                          }
                        
                    }


                    // AST REWRITE
                    // elements: expression, CASE_T, inner_statement_list
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 644:5: -> ^( CASE_T expression ( inner_statement_list )? )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:644:9: ^( CASE_T expression ( inner_statement_list )? )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_CASE_T.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_expression.nextTree());
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:644:29: ( inner_statement_list )?
                        if ( stream_inner_statement_list.hasNext() ) {
                            adaptor.addChild(root_1, stream_inner_statement_list.nextTree());

                        }
                        stream_inner_statement_list.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:645:5: DEFAULT_T ( COLON_T | SEMI_COLON ) ( inner_statement_list )?
                    {
                    DEFAULT_T211=(Token)match(input,DEFAULT_T,FOLLOW_DEFAULT_T_in_case_list2483); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_DEFAULT_T.add(DEFAULT_T211);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:645:15: ( COLON_T | SEMI_COLON )
                    int alt55=2;
                    int LA55_0 = input.LA(1);

                    if ( (LA55_0==COLON_T) ) {
                        alt55=1;
                    }
                    else if ( (LA55_0==SEMI_COLON) ) {
                        alt55=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return retval;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 55, 0, input);

                        throw nvae;
                    }
                    switch (alt55) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:645:16: COLON_T
                            {
                            COLON_T212=(Token)match(input,COLON_T,FOLLOW_COLON_T_in_case_list2486); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_COLON_T.add(COLON_T212);


                            }
                            break;
                        case 2 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:645:26: SEMI_COLON
                            {
                            SEMI_COLON213=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_case_list2490); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON213);


                            }
                            break;

                    }

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:645:38: ( inner_statement_list )?
                    int alt56=2;
                    int LA56_0 = input.LA(1);

                    if ( (LA56_0==LEFT_PARETHESIS||(LA56_0>=SEMI_COLON && LA56_0<=IDENTIFIER)||LA56_0==LEFT_BRACKET||(LA56_0>=INTERFACE_T && LA56_0<=REF_T)||(LA56_0>=WHILE_T && LA56_0<=FOREACH_T)||(LA56_0>=DECLARE_T && LA56_0<=STRINGLITERAL)||LA56_0==IF_T||(LA56_0>=PLUS_T && LA56_0<=MINUS_T)||(LA56_0>=CLONE_T && LA56_0<=MINUS_MINUS_T)||(LA56_0>=AT_T && LA56_0<=PRINT_T)||(LA56_0>=DOLLAR_T && LA56_0<=DOUBLELITERRAL)||(LA56_0>=166 && LA56_0<=168)||(LA56_0>=182 && LA56_0<=188)) ) {
                        alt56=1;
                    }
                    switch (alt56) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:645:38: inner_statement_list
                            {
                            pushFollow(FOLLOW_inner_statement_list_in_case_list2493);
                            inner_statement_list214=inner_statement_list();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_inner_statement_list.add(inner_statement_list214.getTree());

                            }
                            break;

                    }

                    if ( state.backtracking==0 ) {

                          token = (CommonToken)DEFAULT_T211;
                          startIndex = token.getStartIndex();
                          token = (CommonToken)COLON_T212;
                          if ((SEMI_COLON213!=null?SEMI_COLON213.getText():null) != null) {
                            token = (CommonToken)SEMI_COLON213;
                          }
                          endIndex = token.getStopIndex();
                          if ((inner_statement_list214!=null?input.toString(inner_statement_list214.start,inner_statement_list214.stop):null) != null) {
                            endIndex = ((CommonToken)(inner_statement_list214!=null?((Token)inner_statement_list214.stop):null)).getStopIndex();
                          }
                        
                    }


                    // AST REWRITE
                    // elements: inner_statement_list, DEFAULT_T
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 658:5: -> ^( DEFAULT_T ( inner_statement_list )? )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:658:9: ^( DEFAULT_T ( inner_statement_list )? )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_DEFAULT_T.nextNode(), root_1);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:658:21: ( inner_statement_list )?
                        if ( stream_inner_statement_list.hasNext() ) {
                            adaptor.addChild(root_1, stream_inner_statement_list.nextTree());

                        }
                        stream_inner_statement_list.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "case_list"

    public static class catch_branch_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "catch_branch"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:661:1: catch_branch : CATCH_T LEFT_PARETHESIS fully_qualified_class_name variable RIGHT_PARETHESIS block -> ^( CATCH_T fully_qualified_class_name variable block ) ;
    public final CompilerAstParser.catch_branch_return catch_branch() throws RecognitionException {
        CompilerAstParser.catch_branch_return retval = new CompilerAstParser.catch_branch_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token CATCH_T215=null;
        Token LEFT_PARETHESIS216=null;
        Token RIGHT_PARETHESIS219=null;
        CompilerAstParser.fully_qualified_class_name_return fully_qualified_class_name217 = null;

        CompilerAstParser.variable_return variable218 = null;

        CompilerAstParser.block_return block220 = null;


        SLAST CATCH_T215_tree=null;
        SLAST LEFT_PARETHESIS216_tree=null;
        SLAST RIGHT_PARETHESIS219_tree=null;
        RewriteRuleTokenStream stream_CATCH_T=new RewriteRuleTokenStream(adaptor,"token CATCH_T");
        RewriteRuleTokenStream stream_LEFT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token LEFT_PARETHESIS");
        RewriteRuleTokenStream stream_RIGHT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token RIGHT_PARETHESIS");
        RewriteRuleSubtreeStream stream_fully_qualified_class_name=new RewriteRuleSubtreeStream(adaptor,"rule fully_qualified_class_name");
        RewriteRuleSubtreeStream stream_block=new RewriteRuleSubtreeStream(adaptor,"rule block");
        RewriteRuleSubtreeStream stream_variable=new RewriteRuleSubtreeStream(adaptor,"rule variable");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:671:3: ( CATCH_T LEFT_PARETHESIS fully_qualified_class_name variable RIGHT_PARETHESIS block -> ^( CATCH_T fully_qualified_class_name variable block ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:671:5: CATCH_T LEFT_PARETHESIS fully_qualified_class_name variable RIGHT_PARETHESIS block
            {
            CATCH_T215=(Token)match(input,CATCH_T,FOLLOW_CATCH_T_in_catch_branch2542); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_CATCH_T.add(CATCH_T215);

            LEFT_PARETHESIS216=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_catch_branch2544); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS216);

            pushFollow(FOLLOW_fully_qualified_class_name_in_catch_branch2546);
            fully_qualified_class_name217=fully_qualified_class_name();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_fully_qualified_class_name.add(fully_qualified_class_name217.getTree());
            pushFollow(FOLLOW_variable_in_catch_branch2548);
            variable218=variable();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_variable.add(variable218.getTree());
            RIGHT_PARETHESIS219=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_catch_branch2550); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS219);

            pushFollow(FOLLOW_block_in_catch_branch2558);
            block220=block();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_block.add(block220.getTree());
            if ( state.backtracking==0 ) {

              	    token = (CommonToken)CATCH_T215;
              	    startIndex = token.getStartIndex();
              	    token = (CommonToken)(block220!=null?((Token)block220.stop):null);
              	    endIndex = token.getStopIndex();  
                  
            }


            // AST REWRITE
            // elements: variable, fully_qualified_class_name, block, CATCH_T
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 679:5: -> ^( CATCH_T fully_qualified_class_name variable block )
            {
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:679:9: ^( CATCH_T fully_qualified_class_name variable block )
                {
                SLAST root_1 = (SLAST)adaptor.nil();
                root_1 = (SLAST)adaptor.becomeRoot(stream_CATCH_T.nextNode(), root_1);

                adaptor.addChild(root_1, stream_fully_qualified_class_name.nextTree());
                adaptor.addChild(root_1, stream_variable.nextTree());
                adaptor.addChild(root_1, stream_block.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "catch_branch"

    public static class for_statement_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "for_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:682:1: for_statement : ( statement -> statement | COLON_T ( inner_statement_list )? ENDFOR_T SEMI_COLON -> ( inner_statement_list )? );
    public final CompilerAstParser.for_statement_return for_statement() throws RecognitionException {
        CompilerAstParser.for_statement_return retval = new CompilerAstParser.for_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token COLON_T222=null;
        Token ENDFOR_T224=null;
        Token SEMI_COLON225=null;
        CompilerAstParser.statement_return statement221 = null;

        CompilerAstParser.inner_statement_list_return inner_statement_list223 = null;


        SLAST COLON_T222_tree=null;
        SLAST ENDFOR_T224_tree=null;
        SLAST SEMI_COLON225_tree=null;
        RewriteRuleTokenStream stream_SEMI_COLON=new RewriteRuleTokenStream(adaptor,"token SEMI_COLON");
        RewriteRuleTokenStream stream_COLON_T=new RewriteRuleTokenStream(adaptor,"token COLON_T");
        RewriteRuleTokenStream stream_ENDFOR_T=new RewriteRuleTokenStream(adaptor,"token ENDFOR_T");
        RewriteRuleSubtreeStream stream_statement=new RewriteRuleSubtreeStream(adaptor,"rule statement");
        RewriteRuleSubtreeStream stream_inner_statement_list=new RewriteRuleSubtreeStream(adaptor,"rule inner_statement_list");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:692:2: ( statement -> statement | COLON_T ( inner_statement_list )? ENDFOR_T SEMI_COLON -> ( inner_statement_list )? )
            int alt59=2;
            int LA59_0 = input.LA(1);

            if ( (LA59_0==LEFT_PARETHESIS||LA59_0==SEMI_COLON||LA59_0==IDENTIFIER||LA59_0==LEFT_BRACKET||LA59_0==REF_T||(LA59_0>=WHILE_T && LA59_0<=FOREACH_T)||(LA59_0>=DECLARE_T && LA59_0<=STRINGLITERAL)||LA59_0==IF_T||(LA59_0>=PLUS_T && LA59_0<=MINUS_T)||(LA59_0>=CLONE_T && LA59_0<=MINUS_MINUS_T)||(LA59_0>=AT_T && LA59_0<=PRINT_T)||(LA59_0>=DOLLAR_T && LA59_0<=DOUBLELITERRAL)||(LA59_0>=182 && LA59_0<=188)) ) {
                alt59=1;
            }
            else if ( (LA59_0==COLON_T) ) {
                alt59=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 59, 0, input);

                throw nvae;
            }
            switch (alt59) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:692:4: statement
                    {
                    pushFollow(FOLLOW_statement_in_for_statement2603);
                    statement221=statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_statement.add(statement221.getTree());
                    if ( state.backtracking==0 ) {

                          startIndex = ((CommonToken)(statement221!=null?((Token)statement221.start):null)).getStartIndex();
                          endIndex = ((CommonToken)(statement221!=null?((Token)statement221.stop):null)).getStopIndex();
                       
                    }


                    // AST REWRITE
                    // elements: statement
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 697:4: -> statement
                    {
                        adaptor.addChild(root_0, stream_statement.nextTree());

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:698:4: COLON_T ( inner_statement_list )? ENDFOR_T SEMI_COLON
                    {
                    COLON_T222=(Token)match(input,COLON_T,FOLLOW_COLON_T_in_for_statement2619); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_COLON_T.add(COLON_T222);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:698:12: ( inner_statement_list )?
                    int alt58=2;
                    int LA58_0 = input.LA(1);

                    if ( (LA58_0==LEFT_PARETHESIS||(LA58_0>=SEMI_COLON && LA58_0<=IDENTIFIER)||LA58_0==LEFT_BRACKET||(LA58_0>=INTERFACE_T && LA58_0<=REF_T)||(LA58_0>=WHILE_T && LA58_0<=FOREACH_T)||(LA58_0>=DECLARE_T && LA58_0<=STRINGLITERAL)||LA58_0==IF_T||(LA58_0>=PLUS_T && LA58_0<=MINUS_T)||(LA58_0>=CLONE_T && LA58_0<=MINUS_MINUS_T)||(LA58_0>=AT_T && LA58_0<=PRINT_T)||(LA58_0>=DOLLAR_T && LA58_0<=DOUBLELITERRAL)||(LA58_0>=166 && LA58_0<=168)||(LA58_0>=182 && LA58_0<=188)) ) {
                        alt58=1;
                    }
                    switch (alt58) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:698:12: inner_statement_list
                            {
                            pushFollow(FOLLOW_inner_statement_list_in_for_statement2621);
                            inner_statement_list223=inner_statement_list();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_inner_statement_list.add(inner_statement_list223.getTree());

                            }
                            break;

                    }

                    ENDFOR_T224=(Token)match(input,ENDFOR_T,FOLLOW_ENDFOR_T_in_for_statement2624); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_ENDFOR_T.add(ENDFOR_T224);

                    SEMI_COLON225=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_for_statement2626); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON225);

                    if ( state.backtracking==0 ) {

                          startIndex = ((CommonToken)COLON_T222).getStartIndex();
                          endIndex = ((CommonToken)SEMI_COLON225).getStopIndex();
                       
                    }


                    // AST REWRITE
                    // elements: inner_statement_list
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 703:4: -> ( inner_statement_list )?
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:703:8: ( inner_statement_list )?
                        if ( stream_inner_statement_list.hasNext() ) {
                            adaptor.addChild(root_0, stream_inner_statement_list.nextTree());

                        }
                        stream_inner_statement_list.reset();

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "for_statement"

    public static class while_statement_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "while_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:706:1: while_statement : ( statement -> statement | COLON_T ( inner_statement_list )? ENDWHILE_T SEMI_COLON -> ( inner_statement_list )? );
    public final CompilerAstParser.while_statement_return while_statement() throws RecognitionException {
        CompilerAstParser.while_statement_return retval = new CompilerAstParser.while_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token COLON_T227=null;
        Token ENDWHILE_T229=null;
        Token SEMI_COLON230=null;
        CompilerAstParser.statement_return statement226 = null;

        CompilerAstParser.inner_statement_list_return inner_statement_list228 = null;


        SLAST COLON_T227_tree=null;
        SLAST ENDWHILE_T229_tree=null;
        SLAST SEMI_COLON230_tree=null;
        RewriteRuleTokenStream stream_SEMI_COLON=new RewriteRuleTokenStream(adaptor,"token SEMI_COLON");
        RewriteRuleTokenStream stream_COLON_T=new RewriteRuleTokenStream(adaptor,"token COLON_T");
        RewriteRuleTokenStream stream_ENDWHILE_T=new RewriteRuleTokenStream(adaptor,"token ENDWHILE_T");
        RewriteRuleSubtreeStream stream_statement=new RewriteRuleSubtreeStream(adaptor,"rule statement");
        RewriteRuleSubtreeStream stream_inner_statement_list=new RewriteRuleSubtreeStream(adaptor,"rule inner_statement_list");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:716:2: ( statement -> statement | COLON_T ( inner_statement_list )? ENDWHILE_T SEMI_COLON -> ( inner_statement_list )? )
            int alt61=2;
            int LA61_0 = input.LA(1);

            if ( (LA61_0==LEFT_PARETHESIS||LA61_0==SEMI_COLON||LA61_0==IDENTIFIER||LA61_0==LEFT_BRACKET||LA61_0==REF_T||(LA61_0>=WHILE_T && LA61_0<=FOREACH_T)||(LA61_0>=DECLARE_T && LA61_0<=STRINGLITERAL)||LA61_0==IF_T||(LA61_0>=PLUS_T && LA61_0<=MINUS_T)||(LA61_0>=CLONE_T && LA61_0<=MINUS_MINUS_T)||(LA61_0>=AT_T && LA61_0<=PRINT_T)||(LA61_0>=DOLLAR_T && LA61_0<=DOUBLELITERRAL)||(LA61_0>=182 && LA61_0<=188)) ) {
                alt61=1;
            }
            else if ( (LA61_0==COLON_T) ) {
                alt61=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 61, 0, input);

                throw nvae;
            }
            switch (alt61) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:716:4: statement
                    {
                    pushFollow(FOLLOW_statement_in_while_statement2660);
                    statement226=statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_statement.add(statement226.getTree());
                    if ( state.backtracking==0 ) {

                          startIndex = ((CommonToken)(statement226!=null?((Token)statement226.start):null)).getStartIndex();
                          endIndex = ((CommonToken)(statement226!=null?((Token)statement226.stop):null)).getStopIndex();
                        
                    }


                    // AST REWRITE
                    // elements: statement
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 721:4: -> statement
                    {
                        adaptor.addChild(root_0, stream_statement.nextTree());

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:722:4: COLON_T ( inner_statement_list )? ENDWHILE_T SEMI_COLON
                    {
                    COLON_T227=(Token)match(input,COLON_T,FOLLOW_COLON_T_in_while_statement2677); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_COLON_T.add(COLON_T227);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:722:12: ( inner_statement_list )?
                    int alt60=2;
                    int LA60_0 = input.LA(1);

                    if ( (LA60_0==LEFT_PARETHESIS||(LA60_0>=SEMI_COLON && LA60_0<=IDENTIFIER)||LA60_0==LEFT_BRACKET||(LA60_0>=INTERFACE_T && LA60_0<=REF_T)||(LA60_0>=WHILE_T && LA60_0<=FOREACH_T)||(LA60_0>=DECLARE_T && LA60_0<=STRINGLITERAL)||LA60_0==IF_T||(LA60_0>=PLUS_T && LA60_0<=MINUS_T)||(LA60_0>=CLONE_T && LA60_0<=MINUS_MINUS_T)||(LA60_0>=AT_T && LA60_0<=PRINT_T)||(LA60_0>=DOLLAR_T && LA60_0<=DOUBLELITERRAL)||(LA60_0>=166 && LA60_0<=168)||(LA60_0>=182 && LA60_0<=188)) ) {
                        alt60=1;
                    }
                    switch (alt60) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:722:12: inner_statement_list
                            {
                            pushFollow(FOLLOW_inner_statement_list_in_while_statement2679);
                            inner_statement_list228=inner_statement_list();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_inner_statement_list.add(inner_statement_list228.getTree());

                            }
                            break;

                    }

                    ENDWHILE_T229=(Token)match(input,ENDWHILE_T,FOLLOW_ENDWHILE_T_in_while_statement2682); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_ENDWHILE_T.add(ENDWHILE_T229);

                    SEMI_COLON230=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_while_statement2684); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON230);

                    if ( state.backtracking==0 ) {

                          startIndex = ((CommonToken)COLON_T227).getStartIndex();
                          endIndex = ((CommonToken)SEMI_COLON230).getStopIndex();
                        
                    }


                    // AST REWRITE
                    // elements: inner_statement_list
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 727:4: -> ( inner_statement_list )?
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:727:8: ( inner_statement_list )?
                        if ( stream_inner_statement_list.hasNext() ) {
                            adaptor.addChild(root_0, stream_inner_statement_list.nextTree());

                        }
                        stream_inner_statement_list.reset();

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "while_statement"

    public static class foreach_statement_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "foreach_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:730:1: foreach_statement : ( statement -> statement | COLON_T ( inner_statement_list )? ENDFOREACH_T SEMI_COLON -> ( inner_statement_list )? );
    public final CompilerAstParser.foreach_statement_return foreach_statement() throws RecognitionException {
        CompilerAstParser.foreach_statement_return retval = new CompilerAstParser.foreach_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token COLON_T232=null;
        Token ENDFOREACH_T234=null;
        Token SEMI_COLON235=null;
        CompilerAstParser.statement_return statement231 = null;

        CompilerAstParser.inner_statement_list_return inner_statement_list233 = null;


        SLAST COLON_T232_tree=null;
        SLAST ENDFOREACH_T234_tree=null;
        SLAST SEMI_COLON235_tree=null;
        RewriteRuleTokenStream stream_ENDFOREACH_T=new RewriteRuleTokenStream(adaptor,"token ENDFOREACH_T");
        RewriteRuleTokenStream stream_SEMI_COLON=new RewriteRuleTokenStream(adaptor,"token SEMI_COLON");
        RewriteRuleTokenStream stream_COLON_T=new RewriteRuleTokenStream(adaptor,"token COLON_T");
        RewriteRuleSubtreeStream stream_statement=new RewriteRuleSubtreeStream(adaptor,"rule statement");
        RewriteRuleSubtreeStream stream_inner_statement_list=new RewriteRuleSubtreeStream(adaptor,"rule inner_statement_list");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:740:3: ( statement -> statement | COLON_T ( inner_statement_list )? ENDFOREACH_T SEMI_COLON -> ( inner_statement_list )? )
            int alt63=2;
            int LA63_0 = input.LA(1);

            if ( (LA63_0==LEFT_PARETHESIS||LA63_0==SEMI_COLON||LA63_0==IDENTIFIER||LA63_0==LEFT_BRACKET||LA63_0==REF_T||(LA63_0>=WHILE_T && LA63_0<=FOREACH_T)||(LA63_0>=DECLARE_T && LA63_0<=STRINGLITERAL)||LA63_0==IF_T||(LA63_0>=PLUS_T && LA63_0<=MINUS_T)||(LA63_0>=CLONE_T && LA63_0<=MINUS_MINUS_T)||(LA63_0>=AT_T && LA63_0<=PRINT_T)||(LA63_0>=DOLLAR_T && LA63_0<=DOUBLELITERRAL)||(LA63_0>=182 && LA63_0<=188)) ) {
                alt63=1;
            }
            else if ( (LA63_0==COLON_T) ) {
                alt63=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 63, 0, input);

                throw nvae;
            }
            switch (alt63) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:740:5: statement
                    {
                    pushFollow(FOLLOW_statement_in_foreach_statement2720);
                    statement231=statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_statement.add(statement231.getTree());
                    if ( state.backtracking==0 ) {

                          startIndex = ((CommonToken)(statement231!=null?((Token)statement231.start):null)).getStartIndex();
                          endIndex = ((CommonToken)(statement231!=null?((Token)statement231.stop):null)).getStopIndex();
                        
                    }


                    // AST REWRITE
                    // elements: statement
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 745:4: -> statement
                    {
                        adaptor.addChild(root_0, stream_statement.nextTree());

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:746:5: COLON_T ( inner_statement_list )? ENDFOREACH_T SEMI_COLON
                    {
                    COLON_T232=(Token)match(input,COLON_T,FOLLOW_COLON_T_in_foreach_statement2738); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_COLON_T.add(COLON_T232);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:746:13: ( inner_statement_list )?
                    int alt62=2;
                    int LA62_0 = input.LA(1);

                    if ( (LA62_0==LEFT_PARETHESIS||(LA62_0>=SEMI_COLON && LA62_0<=IDENTIFIER)||LA62_0==LEFT_BRACKET||(LA62_0>=INTERFACE_T && LA62_0<=REF_T)||(LA62_0>=WHILE_T && LA62_0<=FOREACH_T)||(LA62_0>=DECLARE_T && LA62_0<=STRINGLITERAL)||LA62_0==IF_T||(LA62_0>=PLUS_T && LA62_0<=MINUS_T)||(LA62_0>=CLONE_T && LA62_0<=MINUS_MINUS_T)||(LA62_0>=AT_T && LA62_0<=PRINT_T)||(LA62_0>=DOLLAR_T && LA62_0<=DOUBLELITERRAL)||(LA62_0>=166 && LA62_0<=168)||(LA62_0>=182 && LA62_0<=188)) ) {
                        alt62=1;
                    }
                    switch (alt62) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:746:13: inner_statement_list
                            {
                            pushFollow(FOLLOW_inner_statement_list_in_foreach_statement2740);
                            inner_statement_list233=inner_statement_list();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_inner_statement_list.add(inner_statement_list233.getTree());

                            }
                            break;

                    }

                    ENDFOREACH_T234=(Token)match(input,ENDFOREACH_T,FOLLOW_ENDFOREACH_T_in_foreach_statement2743); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_ENDFOREACH_T.add(ENDFOREACH_T234);

                    SEMI_COLON235=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_foreach_statement2745); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON235);

                    if ( state.backtracking==0 ) {

                          startIndex = ((CommonToken)COLON_T232).getStartIndex();
                          endIndex = ((CommonToken)SEMI_COLON235).getStopIndex();
                        
                    }


                    // AST REWRITE
                    // elements: inner_statement_list
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 751:4: -> ( inner_statement_list )?
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:751:8: ( inner_statement_list )?
                        if ( stream_inner_statement_list.hasNext() ) {
                            adaptor.addChild(root_0, stream_inner_statement_list.nextTree());

                        }
                        stream_inner_statement_list.reset();

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "foreach_statement"

    public static class declare_statement_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "declare_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:754:1: declare_statement : ( statement -> statement | COLON_T ( inner_statement_list )? ENDDECLARE_T SEMI_COLON -> ( inner_statement_list )? );
    public final CompilerAstParser.declare_statement_return declare_statement() throws RecognitionException {
        CompilerAstParser.declare_statement_return retval = new CompilerAstParser.declare_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token COLON_T237=null;
        Token ENDDECLARE_T239=null;
        Token SEMI_COLON240=null;
        CompilerAstParser.statement_return statement236 = null;

        CompilerAstParser.inner_statement_list_return inner_statement_list238 = null;


        SLAST COLON_T237_tree=null;
        SLAST ENDDECLARE_T239_tree=null;
        SLAST SEMI_COLON240_tree=null;
        RewriteRuleTokenStream stream_SEMI_COLON=new RewriteRuleTokenStream(adaptor,"token SEMI_COLON");
        RewriteRuleTokenStream stream_COLON_T=new RewriteRuleTokenStream(adaptor,"token COLON_T");
        RewriteRuleTokenStream stream_ENDDECLARE_T=new RewriteRuleTokenStream(adaptor,"token ENDDECLARE_T");
        RewriteRuleSubtreeStream stream_statement=new RewriteRuleSubtreeStream(adaptor,"rule statement");
        RewriteRuleSubtreeStream stream_inner_statement_list=new RewriteRuleSubtreeStream(adaptor,"rule inner_statement_list");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:764:3: ( statement -> statement | COLON_T ( inner_statement_list )? ENDDECLARE_T SEMI_COLON -> ( inner_statement_list )? )
            int alt65=2;
            int LA65_0 = input.LA(1);

            if ( (LA65_0==LEFT_PARETHESIS||LA65_0==SEMI_COLON||LA65_0==IDENTIFIER||LA65_0==LEFT_BRACKET||LA65_0==REF_T||(LA65_0>=WHILE_T && LA65_0<=FOREACH_T)||(LA65_0>=DECLARE_T && LA65_0<=STRINGLITERAL)||LA65_0==IF_T||(LA65_0>=PLUS_T && LA65_0<=MINUS_T)||(LA65_0>=CLONE_T && LA65_0<=MINUS_MINUS_T)||(LA65_0>=AT_T && LA65_0<=PRINT_T)||(LA65_0>=DOLLAR_T && LA65_0<=DOUBLELITERRAL)||(LA65_0>=182 && LA65_0<=188)) ) {
                alt65=1;
            }
            else if ( (LA65_0==COLON_T) ) {
                alt65=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 65, 0, input);

                throw nvae;
            }
            switch (alt65) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:764:5: statement
                    {
                    pushFollow(FOLLOW_statement_in_declare_statement2783);
                    statement236=statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_statement.add(statement236.getTree());
                    if ( state.backtracking==0 ) {

                          startIndex = ((CommonToken)(statement236!=null?((Token)statement236.start):null)).getStartIndex();
                          endIndex = ((CommonToken)(statement236!=null?((Token)statement236.stop):null)).getStopIndex();
                        
                    }


                    // AST REWRITE
                    // elements: statement
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 769:5: -> statement
                    {
                        adaptor.addChild(root_0, stream_statement.nextTree());

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:770:5: COLON_T ( inner_statement_list )? ENDDECLARE_T SEMI_COLON
                    {
                    COLON_T237=(Token)match(input,COLON_T,FOLLOW_COLON_T_in_declare_statement2802); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_COLON_T.add(COLON_T237);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:770:13: ( inner_statement_list )?
                    int alt64=2;
                    int LA64_0 = input.LA(1);

                    if ( (LA64_0==LEFT_PARETHESIS||(LA64_0>=SEMI_COLON && LA64_0<=IDENTIFIER)||LA64_0==LEFT_BRACKET||(LA64_0>=INTERFACE_T && LA64_0<=REF_T)||(LA64_0>=WHILE_T && LA64_0<=FOREACH_T)||(LA64_0>=DECLARE_T && LA64_0<=STRINGLITERAL)||LA64_0==IF_T||(LA64_0>=PLUS_T && LA64_0<=MINUS_T)||(LA64_0>=CLONE_T && LA64_0<=MINUS_MINUS_T)||(LA64_0>=AT_T && LA64_0<=PRINT_T)||(LA64_0>=DOLLAR_T && LA64_0<=DOUBLELITERRAL)||(LA64_0>=166 && LA64_0<=168)||(LA64_0>=182 && LA64_0<=188)) ) {
                        alt64=1;
                    }
                    switch (alt64) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:770:13: inner_statement_list
                            {
                            pushFollow(FOLLOW_inner_statement_list_in_declare_statement2804);
                            inner_statement_list238=inner_statement_list();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_inner_statement_list.add(inner_statement_list238.getTree());

                            }
                            break;

                    }

                    ENDDECLARE_T239=(Token)match(input,ENDDECLARE_T,FOLLOW_ENDDECLARE_T_in_declare_statement2807); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_ENDDECLARE_T.add(ENDDECLARE_T239);

                    SEMI_COLON240=(Token)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_declare_statement2809); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SEMI_COLON.add(SEMI_COLON240);

                    if ( state.backtracking==0 ) {

                          startIndex = ((CommonToken)COLON_T237).getStartIndex();
                          endIndex = ((CommonToken)SEMI_COLON240).getStopIndex();
                        
                    }


                    // AST REWRITE
                    // elements: inner_statement_list
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 775:5: -> ( inner_statement_list )?
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:775:9: ( inner_statement_list )?
                        if ( stream_inner_statement_list.hasNext() ) {
                            adaptor.addChild(root_0, stream_inner_statement_list.nextTree());

                        }
                        stream_inner_statement_list.reset();

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "declare_statement"

    public static class parameter_list_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "parameter_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:778:1: parameter_list : p1= parameter ( COMMA_T p2= parameter )* -> ( parameter )+ ;
    public final CompilerAstParser.parameter_list_return parameter_list() throws RecognitionException {
        CompilerAstParser.parameter_list_return retval = new CompilerAstParser.parameter_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token COMMA_T241=null;
        CompilerAstParser.parameter_return p1 = null;

        CompilerAstParser.parameter_return p2 = null;


        SLAST COMMA_T241_tree=null;
        RewriteRuleTokenStream stream_COMMA_T=new RewriteRuleTokenStream(adaptor,"token COMMA_T");
        RewriteRuleSubtreeStream stream_parameter=new RewriteRuleSubtreeStream(adaptor,"rule parameter");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:788:3: (p1= parameter ( COMMA_T p2= parameter )* -> ( parameter )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:788:5: p1= parameter ( COMMA_T p2= parameter )*
            {
            pushFollow(FOLLOW_parameter_in_parameter_list2851);
            p1=parameter();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_parameter.add(p1.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:788:18: ( COMMA_T p2= parameter )*
            loop66:
            do {
                int alt66=2;
                int LA66_0 = input.LA(1);

                if ( (LA66_0==COMMA_T) ) {
                    alt66=1;
                }


                switch (alt66) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:788:19: COMMA_T p2= parameter
            	    {
            	    COMMA_T241=(Token)match(input,COMMA_T,FOLLOW_COMMA_T_in_parameter_list2854); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_COMMA_T.add(COMMA_T241);

            	    pushFollow(FOLLOW_parameter_in_parameter_list2858);
            	    p2=parameter();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_parameter.add(p2.getTree());

            	    }
            	    break;

            	default :
            	    break loop66;
                }
            } while (true);

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(p1!=null?((Token)p1.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(p1!=null?((Token)p1.stop):null);
                  if ((p2!=null?input.toString(p2.start,p2.stop):null) != null) {
                    token = (CommonToken)(p2!=null?((Token)p2.stop):null);
                  }
                  endIndex = token.getStopIndex();
                
            }


            // AST REWRITE
            // elements: parameter
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 798:5: -> ( parameter )+
            {
                if ( !(stream_parameter.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_parameter.hasNext() ) {
                    adaptor.addChild(root_0, stream_parameter.nextTree());

                }
                stream_parameter.reset();

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "parameter_list"

    public static class parameter_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "parameter"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:801:1: parameter : ( parameter_type )? ( CONST_T )? pure_variable ( options {k=1; backtrack=true; } : EQUAL_T scalar )? -> ^( PARAMETER ( ^( TYPE parameter_type ) )? ( CONST_T )? pure_variable ( scalar )? ) ;
    public final CompilerAstParser.parameter_return parameter() throws RecognitionException {
        CompilerAstParser.parameter_return retval = new CompilerAstParser.parameter_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token CONST_T243=null;
        Token EQUAL_T245=null;
        CompilerAstParser.parameter_type_return parameter_type242 = null;

        CompilerAstParser.pure_variable_return pure_variable244 = null;

        CompilerAstParser.scalar_return scalar246 = null;


        SLAST CONST_T243_tree=null;
        SLAST EQUAL_T245_tree=null;
        RewriteRuleTokenStream stream_EQUAL_T=new RewriteRuleTokenStream(adaptor,"token EQUAL_T");
        RewriteRuleTokenStream stream_CONST_T=new RewriteRuleTokenStream(adaptor,"token CONST_T");
        RewriteRuleSubtreeStream stream_scalar=new RewriteRuleSubtreeStream(adaptor,"rule scalar");
        RewriteRuleSubtreeStream stream_parameter_type=new RewriteRuleSubtreeStream(adaptor,"rule parameter_type");
        RewriteRuleSubtreeStream stream_pure_variable=new RewriteRuleSubtreeStream(adaptor,"rule pure_variable");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:811:3: ( ( parameter_type )? ( CONST_T )? pure_variable ( options {k=1; backtrack=true; } : EQUAL_T scalar )? -> ^( PARAMETER ( ^( TYPE parameter_type ) )? ( CONST_T )? pure_variable ( scalar )? ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:811:5: ( parameter_type )? ( CONST_T )? pure_variable ( options {k=1; backtrack=true; } : EQUAL_T scalar )?
            {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:811:5: ( parameter_type )?
            int alt67=2;
            int LA67_0 = input.LA(1);

            if ( (LA67_0==IDENTIFIER||LA67_0==CLONE_T||(LA67_0>=173 && LA67_0<=182)) ) {
                alt67=1;
            }
            switch (alt67) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:811:5: parameter_type
                    {
                    pushFollow(FOLLOW_parameter_type_in_parameter2908);
                    parameter_type242=parameter_type();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_parameter_type.add(parameter_type242.getTree());

                    }
                    break;

            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:811:21: ( CONST_T )?
            int alt68=2;
            int LA68_0 = input.LA(1);

            if ( (LA68_0==CONST_T) ) {
                alt68=1;
            }
            switch (alt68) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:811:21: CONST_T
                    {
                    CONST_T243=(Token)match(input,CONST_T,FOLLOW_CONST_T_in_parameter2911); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_CONST_T.add(CONST_T243);


                    }
                    break;

            }

            pushFollow(FOLLOW_pure_variable_in_parameter2914);
            pure_variable244=pure_variable();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_pure_variable.add(pure_variable244.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:811:44: ( options {k=1; backtrack=true; } : EQUAL_T scalar )?
            int alt69=2;
            int LA69_0 = input.LA(1);

            if ( (LA69_0==EQUAL_T) ) {
                alt69=1;
            }
            switch (alt69) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:811:76: EQUAL_T scalar
                    {
                    EQUAL_T245=(Token)match(input,EQUAL_T,FOLLOW_EQUAL_T_in_parameter2930); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_EQUAL_T.add(EQUAL_T245);

                    pushFollow(FOLLOW_scalar_in_parameter2932);
                    scalar246=scalar();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_scalar.add(scalar246.getTree());

                    }
                    break;

            }

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(pure_variable244!=null?((Token)pure_variable244.start):null);
                  if ((parameter_type242!=null?input.toString(parameter_type242.start,parameter_type242.stop):null) != null) {
                    token = (CommonToken)(parameter_type242!=null?((Token)parameter_type242.start):null);
                  }
                  else if ((CONST_T243!=null?CONST_T243.getText():null) != null) {
                    token = (CommonToken)CONST_T243;
                  }
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(pure_variable244!=null?((Token)pure_variable244.stop):null);
                  if ((scalar246!=null?input.toString(scalar246.start,scalar246.stop):null) != null) {
                    token = (CommonToken)(scalar246!=null?((Token)scalar246.stop):null);
                  }
                  endIndex = token.getStopIndex();
                
            }


            // AST REWRITE
            // elements: pure_variable, scalar, CONST_T, parameter_type
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 828:3: -> ^( PARAMETER ( ^( TYPE parameter_type ) )? ( CONST_T )? pure_variable ( scalar )? )
            {
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:828:6: ^( PARAMETER ( ^( TYPE parameter_type ) )? ( CONST_T )? pure_variable ( scalar )? )
                {
                SLAST root_1 = (SLAST)adaptor.nil();
                root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(PARAMETER, "PARAMETER"), root_1);

                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:828:18: ( ^( TYPE parameter_type ) )?
                if ( stream_parameter_type.hasNext() ) {
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:828:18: ^( TYPE parameter_type )
                    {
                    SLAST root_2 = (SLAST)adaptor.nil();
                    root_2 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(TYPE, "TYPE"), root_2);

                    adaptor.addChild(root_2, stream_parameter_type.nextTree());

                    adaptor.addChild(root_1, root_2);
                    }

                }
                stream_parameter_type.reset();
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:828:42: ( CONST_T )?
                if ( stream_CONST_T.hasNext() ) {
                    adaptor.addChild(root_1, stream_CONST_T.nextNode());

                }
                stream_CONST_T.reset();
                adaptor.addChild(root_1, stream_pure_variable.nextTree());
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:828:65: ( scalar )?
                if ( stream_scalar.hasNext() ) {
                    adaptor.addChild(root_1, stream_scalar.nextTree());

                }
                stream_scalar.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "parameter"

    public static class parameter_type_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "parameter_type"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:831:1: parameter_type : ( fully_qualified_class_name | cast_option );
    public final CompilerAstParser.parameter_type_return parameter_type() throws RecognitionException {
        CompilerAstParser.parameter_type_return retval = new CompilerAstParser.parameter_type_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        CompilerAstParser.fully_qualified_class_name_return fully_qualified_class_name247 = null;

        CompilerAstParser.cast_option_return cast_option248 = null;




          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:841:3: ( fully_qualified_class_name | cast_option )
            int alt70=2;
            int LA70_0 = input.LA(1);

            if ( (LA70_0==IDENTIFIER) ) {
                alt70=1;
            }
            else if ( (LA70_0==CLONE_T||(LA70_0>=173 && LA70_0<=182)) ) {
                alt70=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 70, 0, input);

                throw nvae;
            }
            switch (alt70) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:841:5: fully_qualified_class_name
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_fully_qualified_class_name_in_parameter_type2991);
                    fully_qualified_class_name247=fully_qualified_class_name();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, fully_qualified_class_name247.getTree());
                    if ( state.backtracking==0 ) {

                          startIndex = ((CommonToken)(fully_qualified_class_name247!=null?((Token)fully_qualified_class_name247.start):null)).getStartIndex();
                          endIndex = ((CommonToken)(fully_qualified_class_name247!=null?((Token)fully_qualified_class_name247.stop):null)).getStopIndex();
                        
                    }

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:846:5: cast_option
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_cast_option_in_parameter_type3001);
                    cast_option248=cast_option();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, cast_option248.getTree());
                    if ( state.backtracking==0 ) {

                          startIndex = ((CommonToken)(cast_option248!=null?((Token)cast_option248.start):null)).getStartIndex();
                          endIndex = ((CommonToken)(cast_option248!=null?((Token)cast_option248.stop):null)).getStopIndex();
                        
                    }

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "parameter_type"

    public static class variable_list_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "variable_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:853:1: variable_list : v1= variable ( COMMA_T v2= variable )* -> ( variable )+ ;
    public final CompilerAstParser.variable_list_return variable_list() throws RecognitionException {
        CompilerAstParser.variable_list_return retval = new CompilerAstParser.variable_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token COMMA_T249=null;
        CompilerAstParser.variable_return v1 = null;

        CompilerAstParser.variable_return v2 = null;


        SLAST COMMA_T249_tree=null;
        RewriteRuleTokenStream stream_COMMA_T=new RewriteRuleTokenStream(adaptor,"token COMMA_T");
        RewriteRuleSubtreeStream stream_variable=new RewriteRuleSubtreeStream(adaptor,"rule variable");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:863:3: (v1= variable ( COMMA_T v2= variable )* -> ( variable )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:863:5: v1= variable ( COMMA_T v2= variable )*
            {
            pushFollow(FOLLOW_variable_in_variable_list3032);
            v1=variable();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_variable.add(v1.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:863:17: ( COMMA_T v2= variable )*
            loop71:
            do {
                int alt71=2;
                int LA71_0 = input.LA(1);

                if ( (LA71_0==COMMA_T) ) {
                    alt71=1;
                }


                switch (alt71) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:863:18: COMMA_T v2= variable
            	    {
            	    COMMA_T249=(Token)match(input,COMMA_T,FOLLOW_COMMA_T_in_variable_list3035); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_COMMA_T.add(COMMA_T249);

            	    pushFollow(FOLLOW_variable_in_variable_list3039);
            	    v2=variable();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_variable.add(v2.getTree());

            	    }
            	    break;

            	default :
            	    break loop71;
                }
            } while (true);

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(v1!=null?((Token)v1.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(v1!=null?((Token)v1.stop):null);
                  if ((v2!=null?input.toString(v2.start,v2.stop):null) != null) {
                    token = (CommonToken)(v2!=null?((Token)v2.stop):null);
                  }
                  endIndex = token.getStopIndex();
                
            }


            // AST REWRITE
            // elements: variable
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 873:5: -> ( variable )+
            {
                if ( !(stream_variable.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_variable.hasNext() ) {
                    adaptor.addChild(root_0, stream_variable.nextTree());

                }
                stream_variable.reset();

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "variable_list"

    public static class variable_modifiers_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "variable_modifiers"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:876:1: variable_modifiers : ( 'var' | modifier );
    public final CompilerAstParser.variable_modifiers_return variable_modifiers() throws RecognitionException {
        CompilerAstParser.variable_modifiers_return retval = new CompilerAstParser.variable_modifiers_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token string_literal250=null;
        CompilerAstParser.modifier_return modifier251 = null;


        SLAST string_literal250_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:877:3: ( 'var' | modifier )
            int alt72=2;
            int LA72_0 = input.LA(1);

            if ( (LA72_0==169) ) {
                alt72=1;
            }
            else if ( (LA72_0==STATIC_T||(LA72_0>=167 && LA72_0<=168)||(LA72_0>=170 && LA72_0<=172)) ) {
                alt72=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 72, 0, input);

                throw nvae;
            }
            switch (alt72) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:877:5: 'var'
                    {
                    root_0 = (SLAST)adaptor.nil();

                    string_literal250=(Token)match(input,169,FOLLOW_169_in_variable_modifiers3070); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    string_literal250_tree = (SLAST)adaptor.create(string_literal250);
                    adaptor.addChild(root_0, string_literal250_tree);
                    }

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:878:5: modifier
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_modifier_in_variable_modifiers3076);
                    modifier251=modifier();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, modifier251.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "variable_modifiers"

    public static class modifier_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "modifier"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:881:1: modifier : ( 'public' | 'protected' | 'private' | 'static' | 'abstract' | 'final' )+ ;
    public final CompilerAstParser.modifier_return modifier() throws RecognitionException {
        CompilerAstParser.modifier_return retval = new CompilerAstParser.modifier_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token set252=null;

        SLAST set252_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:882:3: ( ( 'public' | 'protected' | 'private' | 'static' | 'abstract' | 'final' )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:882:5: ( 'public' | 'protected' | 'private' | 'static' | 'abstract' | 'final' )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:882:5: ( 'public' | 'protected' | 'private' | 'static' | 'abstract' | 'final' )+
            int cnt73=0;
            loop73:
            do {
                int alt73=2;
                int LA73_0 = input.LA(1);

                if ( (LA73_0==STATIC_T||(LA73_0>=167 && LA73_0<=168)||(LA73_0>=170 && LA73_0<=172)) ) {
                    alt73=1;
                }


                switch (alt73) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:
            	    {
            	    set252=(Token)input.LT(1);
            	    if ( input.LA(1)==STATIC_T||(input.LA(1)>=167 && input.LA(1)<=168)||(input.LA(1)>=170 && input.LA(1)<=172) ) {
            	        input.consume();
            	        if ( state.backtracking==0 ) adaptor.addChild(root_0, (SLAST)adaptor.create(set252));
            	        state.errorRecovery=false;state.failed=false;
            	    }
            	    else {
            	        if (state.backtracking>0) {state.failed=true; return retval;}
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        throw mse;
            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt73 >= 1 ) break loop73;
            	    if (state.backtracking>0) {state.failed=true; return retval;}
                        EarlyExitException eee =
                            new EarlyExitException(73, input);
                        throw eee;
                }
                cnt73++;
            } while (true);


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "modifier"

    public static class directive_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "directive"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:890:1: directive : d1= directive_element ( COMMA_T d2= directive_element )* -> ( directive_element )+ ;
    public final CompilerAstParser.directive_return directive() throws RecognitionException {
        CompilerAstParser.directive_return retval = new CompilerAstParser.directive_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token COMMA_T253=null;
        CompilerAstParser.directive_element_return d1 = null;

        CompilerAstParser.directive_element_return d2 = null;


        SLAST COMMA_T253_tree=null;
        RewriteRuleTokenStream stream_COMMA_T=new RewriteRuleTokenStream(adaptor,"token COMMA_T");
        RewriteRuleSubtreeStream stream_directive_element=new RewriteRuleSubtreeStream(adaptor,"rule directive_element");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:900:3: (d1= directive_element ( COMMA_T d2= directive_element )* -> ( directive_element )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:900:5: d1= directive_element ( COMMA_T d2= directive_element )*
            {
            pushFollow(FOLLOW_directive_element_in_directive3153);
            d1=directive_element();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_directive_element.add(d1.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:900:26: ( COMMA_T d2= directive_element )*
            loop74:
            do {
                int alt74=2;
                int LA74_0 = input.LA(1);

                if ( (LA74_0==COMMA_T) ) {
                    alt74=1;
                }


                switch (alt74) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:900:27: COMMA_T d2= directive_element
            	    {
            	    COMMA_T253=(Token)match(input,COMMA_T,FOLLOW_COMMA_T_in_directive3156); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_COMMA_T.add(COMMA_T253);

            	    pushFollow(FOLLOW_directive_element_in_directive3160);
            	    d2=directive_element();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_directive_element.add(d2.getTree());

            	    }
            	    break;

            	default :
            	    break loop74;
                }
            } while (true);

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(d1!=null?((Token)d1.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(d1!=null?((Token)d1.stop):null);
                  if ((d2!=null?input.toString(d2.start,d2.stop):null) != null) {
                    token = (CommonToken)(d2!=null?((Token)d2.stop):null);
                  }
                  endIndex = token.getStopIndex();
                
            }


            // AST REWRITE
            // elements: directive_element
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 910:4: -> ( directive_element )+
            {
                if ( !(stream_directive_element.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_directive_element.hasNext() ) {
                    adaptor.addChild(root_0, stream_directive_element.nextTree());

                }
                stream_directive_element.reset();

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "directive"

    public static class directive_element_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "directive_element"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:913:1: directive_element : IDENTIFIER EQUAL_T expression -> ^( EQUAL_T IDENTIFIER expression ) ;
    public final CompilerAstParser.directive_element_return directive_element() throws RecognitionException {
        CompilerAstParser.directive_element_return retval = new CompilerAstParser.directive_element_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token IDENTIFIER254=null;
        Token EQUAL_T255=null;
        CompilerAstParser.expression_return expression256 = null;


        SLAST IDENTIFIER254_tree=null;
        SLAST EQUAL_T255_tree=null;
        RewriteRuleTokenStream stream_EQUAL_T=new RewriteRuleTokenStream(adaptor,"token EQUAL_T");
        RewriteRuleTokenStream stream_IDENTIFIER=new RewriteRuleTokenStream(adaptor,"token IDENTIFIER");
        RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:923:3: ( IDENTIFIER EQUAL_T expression -> ^( EQUAL_T IDENTIFIER expression ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:923:5: IDENTIFIER EQUAL_T expression
            {
            IDENTIFIER254=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_directive_element3203); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER254);

            EQUAL_T255=(Token)match(input,EQUAL_T,FOLLOW_EQUAL_T_in_directive_element3205); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_EQUAL_T.add(EQUAL_T255);

            pushFollow(FOLLOW_expression_in_directive_element3207);
            expression256=expression();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_expression.add(expression256.getTree());
            if ( state.backtracking==0 ) {

                  token = (CommonToken)IDENTIFIER254;
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(expression256!=null?((Token)expression256.stop):null);
                  endIndex = token.getStopIndex();  
                
            }


            // AST REWRITE
            // elements: expression, IDENTIFIER, EQUAL_T
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 930:5: -> ^( EQUAL_T IDENTIFIER expression )
            {
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:930:9: ^( EQUAL_T IDENTIFIER expression )
                {
                SLAST root_1 = (SLAST)adaptor.nil();
                root_1 = (SLAST)adaptor.becomeRoot(stream_EQUAL_T.nextNode(), root_1);

                adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());
                adaptor.addChild(root_1, stream_expression.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "directive_element"

    public static class expr_list_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "expr_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:933:1: expr_list : e1= expression ( COMMA_T e2= expression )* -> ( expression )+ ;
    public final CompilerAstParser.expr_list_return expr_list() throws RecognitionException {
        CompilerAstParser.expr_list_return retval = new CompilerAstParser.expr_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token COMMA_T257=null;
        CompilerAstParser.expression_return e1 = null;

        CompilerAstParser.expression_return e2 = null;


        SLAST COMMA_T257_tree=null;
        RewriteRuleTokenStream stream_COMMA_T=new RewriteRuleTokenStream(adaptor,"token COMMA_T");
        RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:943:2: (e1= expression ( COMMA_T e2= expression )* -> ( expression )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:943:4: e1= expression ( COMMA_T e2= expression )*
            {
            pushFollow(FOLLOW_expression_in_expr_list3252);
            e1=expression();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_expression.add(e1.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:943:18: ( COMMA_T e2= expression )*
            loop75:
            do {
                int alt75=2;
                int LA75_0 = input.LA(1);

                if ( (LA75_0==COMMA_T) ) {
                    alt75=1;
                }


                switch (alt75) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:943:19: COMMA_T e2= expression
            	    {
            	    COMMA_T257=(Token)match(input,COMMA_T,FOLLOW_COMMA_T_in_expr_list3255); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_COMMA_T.add(COMMA_T257);

            	    pushFollow(FOLLOW_expression_in_expr_list3259);
            	    e2=expression();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_expression.add(e2.getTree());

            	    }
            	    break;

            	default :
            	    break loop75;
                }
            } while (true);

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(e1!=null?((Token)e1.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(e1!=null?((Token)e1.stop):null);
                  if ((e2!=null?input.toString(e2.start,e2.stop):null) != null) {
                    token = (CommonToken)(e2!=null?((Token)e2.stop):null);
                  }
                  endIndex = token.getStopIndex();
                
            }


            // AST REWRITE
            // elements: expression
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 953:5: -> ( expression )+
            {
                if ( !(stream_expression.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_expression.hasNext() ) {
                    adaptor.addChild(root_0, stream_expression.nextTree());

                }
                stream_expression.reset();

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "expr_list"

    public static class expression_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "expression"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:956:1: expression : logical_text_or_expr -> ^( EXPR logical_text_or_expr ) ;
    public final CompilerAstParser.expression_return expression() throws RecognitionException {
        CompilerAstParser.expression_return retval = new CompilerAstParser.expression_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        CompilerAstParser.logical_text_or_expr_return logical_text_or_expr258 = null;


        RewriteRuleSubtreeStream stream_logical_text_or_expr=new RewriteRuleSubtreeStream(adaptor,"rule logical_text_or_expr");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:966:3: ( logical_text_or_expr -> ^( EXPR logical_text_or_expr ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:966:5: logical_text_or_expr
            {
            pushFollow(FOLLOW_logical_text_or_expr_in_expression3300);
            logical_text_or_expr258=logical_text_or_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_logical_text_or_expr.add(logical_text_or_expr258.getTree());
            if ( state.backtracking==0 ) {

                  token = (CommonToken)(logical_text_or_expr258!=null?((Token)logical_text_or_expr258.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(logical_text_or_expr258!=null?((Token)logical_text_or_expr258.stop):null);
                  endIndex = token.getStopIndex();
                
            }


            // AST REWRITE
            // elements: logical_text_or_expr
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 973:5: -> ^( EXPR logical_text_or_expr )
            {
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:973:9: ^( EXPR logical_text_or_expr )
                {
                SLAST root_1 = (SLAST)adaptor.nil();
                root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(EXPR, "EXPR"), root_1);

                adaptor.addChild(root_1, stream_logical_text_or_expr.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "expression"

    public static class logical_text_or_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "logical_text_or_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:976:1: logical_text_or_expr : e1= logical_text_xor_expr ( OR_T e2= logical_text_xor_expr )* ;
    public final CompilerAstParser.logical_text_or_expr_return logical_text_or_expr() throws RecognitionException {
        CompilerAstParser.logical_text_or_expr_return retval = new CompilerAstParser.logical_text_or_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token OR_T259=null;
        CompilerAstParser.logical_text_xor_expr_return e1 = null;

        CompilerAstParser.logical_text_xor_expr_return e2 = null;


        SLAST OR_T259_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:986:3: (e1= logical_text_xor_expr ( OR_T e2= logical_text_xor_expr )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:986:5: e1= logical_text_xor_expr ( OR_T e2= logical_text_xor_expr )*
            {
            root_0 = (SLAST)adaptor.nil();

            pushFollow(FOLLOW_logical_text_xor_expr_in_logical_text_or_expr3343);
            e1=logical_text_xor_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, e1.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:986:30: ( OR_T e2= logical_text_xor_expr )*
            loop76:
            do {
                int alt76=2;
                int LA76_0 = input.LA(1);

                if ( (LA76_0==OR_T) ) {
                    alt76=1;
                }


                switch (alt76) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:986:31: OR_T e2= logical_text_xor_expr
            	    {
            	    OR_T259=(Token)match(input,OR_T,FOLLOW_OR_T_in_logical_text_or_expr3346); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    OR_T259_tree = (SLAST)adaptor.create(OR_T259);
            	    root_0 = (SLAST)adaptor.becomeRoot(OR_T259_tree, root_0);
            	    }
            	    pushFollow(FOLLOW_logical_text_xor_expr_in_logical_text_or_expr3351);
            	    e2=logical_text_xor_expr();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, e2.getTree());

            	    }
            	    break;

            	default :
            	    break loop76;
                }
            } while (true);

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(e1!=null?((Token)e1.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(e1!=null?((Token)e1.stop):null);
                  if ((e2!=null?input.toString(e2.start,e2.stop):null) != null) {
                    token = (CommonToken)(e2!=null?((Token)e2.stop):null);
                  }
                  endIndex = token.getStopIndex();
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "logical_text_or_expr"

    public static class logical_text_xor_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "logical_text_xor_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:998:1: logical_text_xor_expr : e1= logical_text_and_expr ( XOR_T e2= logical_text_and_expr )* ;
    public final CompilerAstParser.logical_text_xor_expr_return logical_text_xor_expr() throws RecognitionException {
        CompilerAstParser.logical_text_xor_expr_return retval = new CompilerAstParser.logical_text_xor_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token XOR_T260=null;
        CompilerAstParser.logical_text_and_expr_return e1 = null;

        CompilerAstParser.logical_text_and_expr_return e2 = null;


        SLAST XOR_T260_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1008:3: (e1= logical_text_and_expr ( XOR_T e2= logical_text_and_expr )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1008:5: e1= logical_text_and_expr ( XOR_T e2= logical_text_and_expr )*
            {
            root_0 = (SLAST)adaptor.nil();

            pushFollow(FOLLOW_logical_text_and_expr_in_logical_text_xor_expr3382);
            e1=logical_text_and_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, e1.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1008:30: ( XOR_T e2= logical_text_and_expr )*
            loop77:
            do {
                int alt77=2;
                int LA77_0 = input.LA(1);

                if ( (LA77_0==XOR_T) ) {
                    alt77=1;
                }


                switch (alt77) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1008:31: XOR_T e2= logical_text_and_expr
            	    {
            	    XOR_T260=(Token)match(input,XOR_T,FOLLOW_XOR_T_in_logical_text_xor_expr3385); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    XOR_T260_tree = (SLAST)adaptor.create(XOR_T260);
            	    root_0 = (SLAST)adaptor.becomeRoot(XOR_T260_tree, root_0);
            	    }
            	    pushFollow(FOLLOW_logical_text_and_expr_in_logical_text_xor_expr3390);
            	    e2=logical_text_and_expr();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, e2.getTree());

            	    }
            	    break;

            	default :
            	    break loop77;
                }
            } while (true);

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(e1!=null?((Token)e1.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(e1!=null?((Token)e1.stop):null);
                  if ((e2!=null?input.toString(e2.start,e2.stop):null) != null) {
                    token = (CommonToken)(e2!=null?((Token)e2.stop):null);
                  }
                  endIndex = token.getStopIndex();
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "logical_text_xor_expr"

    public static class logical_text_and_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "logical_text_and_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1020:1: logical_text_and_expr : e1= assignment_expr ( AND_T e2= assignment_expr )* ;
    public final CompilerAstParser.logical_text_and_expr_return logical_text_and_expr() throws RecognitionException {
        CompilerAstParser.logical_text_and_expr_return retval = new CompilerAstParser.logical_text_and_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token AND_T261=null;
        CompilerAstParser.assignment_expr_return e1 = null;

        CompilerAstParser.assignment_expr_return e2 = null;


        SLAST AND_T261_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1030:3: (e1= assignment_expr ( AND_T e2= assignment_expr )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1030:5: e1= assignment_expr ( AND_T e2= assignment_expr )*
            {
            root_0 = (SLAST)adaptor.nil();

            pushFollow(FOLLOW_assignment_expr_in_logical_text_and_expr3421);
            e1=assignment_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, e1.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1030:24: ( AND_T e2= assignment_expr )*
            loop78:
            do {
                int alt78=2;
                int LA78_0 = input.LA(1);

                if ( (LA78_0==AND_T) ) {
                    alt78=1;
                }


                switch (alt78) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1030:25: AND_T e2= assignment_expr
            	    {
            	    AND_T261=(Token)match(input,AND_T,FOLLOW_AND_T_in_logical_text_and_expr3424); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    AND_T261_tree = (SLAST)adaptor.create(AND_T261);
            	    root_0 = (SLAST)adaptor.becomeRoot(AND_T261_tree, root_0);
            	    }
            	    pushFollow(FOLLOW_assignment_expr_in_logical_text_and_expr3429);
            	    e2=assignment_expr();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, e2.getTree());

            	    }
            	    break;

            	default :
            	    break loop78;
                }
            } while (true);

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(e1!=null?((Token)e1.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(e1!=null?((Token)e1.stop):null);
                  if ((e2!=null?input.toString(e2.start,e2.stop):null) != null) {
                    token = (CommonToken)(e2!=null?((Token)e2.stop):null);
                  }
                  endIndex = token.getStopIndex();
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "logical_text_and_expr"

    public static class assignment_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "assignment_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1042:1: assignment_expr : e1= conditional_expr ( assignment_operator e2= conditional_expr )* ;
    public final CompilerAstParser.assignment_expr_return assignment_expr() throws RecognitionException {
        CompilerAstParser.assignment_expr_return retval = new CompilerAstParser.assignment_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        CompilerAstParser.conditional_expr_return e1 = null;

        CompilerAstParser.conditional_expr_return e2 = null;

        CompilerAstParser.assignment_operator_return assignment_operator262 = null;




          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1052:3: (e1= conditional_expr ( assignment_operator e2= conditional_expr )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1052:5: e1= conditional_expr ( assignment_operator e2= conditional_expr )*
            {
            root_0 = (SLAST)adaptor.nil();

            pushFollow(FOLLOW_conditional_expr_in_assignment_expr3460);
            e1=conditional_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, e1.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1052:25: ( assignment_operator e2= conditional_expr )*
            loop79:
            do {
                int alt79=2;
                int LA79_0 = input.LA(1);

                if ( (LA79_0==EQUAL_T||(LA79_0>=PLUS_EQ && LA79_0<=RMOVE_EQ)) ) {
                    alt79=1;
                }


                switch (alt79) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1052:26: assignment_operator e2= conditional_expr
            	    {
            	    pushFollow(FOLLOW_assignment_operator_in_assignment_expr3463);
            	    assignment_operator262=assignment_operator();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) root_0 = (SLAST)adaptor.becomeRoot(assignment_operator262.getTree(), root_0);
            	    pushFollow(FOLLOW_conditional_expr_in_assignment_expr3468);
            	    e2=conditional_expr();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, e2.getTree());

            	    }
            	    break;

            	default :
            	    break loop79;
                }
            } while (true);

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(e1!=null?((Token)e1.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(e1!=null?((Token)e1.stop):null);
                  if ((e2!=null?input.toString(e2.start,e2.stop):null) != null) {
                    token = (CommonToken)(e2!=null?((Token)e2.stop):null);
                  }
                  endIndex = token.getStopIndex();
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "assignment_expr"

    public static class assignment_operator_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "assignment_operator"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1064:1: assignment_operator : ( EQUAL_T | PLUS_EQ | MINUS_EQ | MUL_EQ | DIV_EQ | DOT_EQ | PERCENT_EQ | BIT_AND_EQ | BIT_OR_EQ | POWER_EQ | LMOVE_EQ | RMOVE_EQ );
    public final CompilerAstParser.assignment_operator_return assignment_operator() throws RecognitionException {
        CompilerAstParser.assignment_operator_return retval = new CompilerAstParser.assignment_operator_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token set263=null;

        SLAST set263_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1065:3: ( EQUAL_T | PLUS_EQ | MINUS_EQ | MUL_EQ | DIV_EQ | DOT_EQ | PERCENT_EQ | BIT_AND_EQ | BIT_OR_EQ | POWER_EQ | LMOVE_EQ | RMOVE_EQ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:
            {
            root_0 = (SLAST)adaptor.nil();

            set263=(Token)input.LT(1);
            if ( input.LA(1)==EQUAL_T||(input.LA(1)>=PLUS_EQ && input.LA(1)<=RMOVE_EQ) ) {
                input.consume();
                if ( state.backtracking==0 ) adaptor.addChild(root_0, (SLAST)adaptor.create(set263));
                state.errorRecovery=false;state.failed=false;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                MismatchedSetException mse = new MismatchedSetException(null,input);
                throw mse;
            }


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "assignment_operator"

    public static class conditional_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "conditional_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1079:1: conditional_expr : (ll= logical_or_expr -> $ll) ( QUESTION_T ( expression )? COLON_T lr= logical_or_expr -> ^( QUESTION_T $ll ^( COLON_T ( expression )? $lr) ) )? ;
    public final CompilerAstParser.conditional_expr_return conditional_expr() throws RecognitionException {
        CompilerAstParser.conditional_expr_return retval = new CompilerAstParser.conditional_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token QUESTION_T264=null;
        Token COLON_T266=null;
        CompilerAstParser.logical_or_expr_return ll = null;

        CompilerAstParser.logical_or_expr_return lr = null;

        CompilerAstParser.expression_return expression265 = null;


        SLAST QUESTION_T264_tree=null;
        SLAST COLON_T266_tree=null;
        RewriteRuleTokenStream stream_QUESTION_T=new RewriteRuleTokenStream(adaptor,"token QUESTION_T");
        RewriteRuleTokenStream stream_COLON_T=new RewriteRuleTokenStream(adaptor,"token COLON_T");
        RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");
        RewriteRuleSubtreeStream stream_logical_or_expr=new RewriteRuleSubtreeStream(adaptor,"rule logical_or_expr");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1090:3: ( (ll= logical_or_expr -> $ll) ( QUESTION_T ( expression )? COLON_T lr= logical_or_expr -> ^( QUESTION_T $ll ^( COLON_T ( expression )? $lr) ) )? )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1090:5: (ll= logical_or_expr -> $ll) ( QUESTION_T ( expression )? COLON_T lr= logical_or_expr -> ^( QUESTION_T $ll ^( COLON_T ( expression )? $lr) ) )?
            {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1090:5: (ll= logical_or_expr -> $ll)
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1090:6: ll= logical_or_expr
            {
            pushFollow(FOLLOW_logical_or_expr_in_conditional_expr3605);
            ll=logical_or_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_logical_or_expr.add(ll.getTree());
            if ( state.backtracking==0 ) {

                  token = (CommonToken)(ll!=null?((Token)ll.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(ll!=null?((Token)ll.stop):null);
                  endIndex = token.getStopIndex();
                
            }


            // AST REWRITE
            // elements: ll
            // token labels: 
            // rule labels: retval, ll
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
            RewriteRuleSubtreeStream stream_ll=new RewriteRuleSubtreeStream(adaptor,"rule ll",ll!=null?ll.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 1097:4: -> $ll
            {
                adaptor.addChild(root_0, stream_ll.nextTree());

            }

            retval.tree = root_0;}
            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1098:4: ( QUESTION_T ( expression )? COLON_T lr= logical_or_expr -> ^( QUESTION_T $ll ^( COLON_T ( expression )? $lr) ) )?
            int alt81=2;
            int LA81_0 = input.LA(1);

            if ( (LA81_0==QUESTION_T) ) {
                alt81=1;
            }
            switch (alt81) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1098:5: QUESTION_T ( expression )? COLON_T lr= logical_or_expr
                    {
                    QUESTION_T264=(Token)match(input,QUESTION_T,FOLLOW_QUESTION_T_in_conditional_expr3624); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_QUESTION_T.add(QUESTION_T264);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1098:16: ( expression )?
                    int alt80=2;
                    int LA80_0 = input.LA(1);

                    if ( (LA80_0==LEFT_PARETHESIS||LA80_0==IDENTIFIER||LA80_0==REF_T||LA80_0==STRINGLITERAL||(LA80_0>=PLUS_T && LA80_0<=MINUS_T)||(LA80_0>=CLONE_T && LA80_0<=MINUS_MINUS_T)||(LA80_0>=AT_T && LA80_0<=PRINT_T)||(LA80_0>=DOLLAR_T && LA80_0<=DOUBLELITERRAL)||(LA80_0>=182 && LA80_0<=188)) ) {
                        alt80=1;
                    }
                    switch (alt80) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1098:16: expression
                            {
                            pushFollow(FOLLOW_expression_in_conditional_expr3626);
                            expression265=expression();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_expression.add(expression265.getTree());

                            }
                            break;

                    }

                    COLON_T266=(Token)match(input,COLON_T,FOLLOW_COLON_T_in_conditional_expr3629); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_COLON_T.add(COLON_T266);

                    pushFollow(FOLLOW_logical_or_expr_in_conditional_expr3633);
                    lr=logical_or_expr();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_logical_or_expr.add(lr.getTree());
                    if ( state.backtracking==0 ) {

                          token = (CommonToken)(lr!=null?((Token)lr.stop):null);
                          endIndex = token.getStopIndex();
                        
                    }


                    // AST REWRITE
                    // elements: ll, QUESTION_T, COLON_T, expression, lr
                    // token labels: 
                    // rule labels: retval, ll, lr
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
                    RewriteRuleSubtreeStream stream_ll=new RewriteRuleSubtreeStream(adaptor,"rule ll",ll!=null?ll.tree:null);
                    RewriteRuleSubtreeStream stream_lr=new RewriteRuleSubtreeStream(adaptor,"rule lr",lr!=null?lr.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 1102:5: -> ^( QUESTION_T $ll ^( COLON_T ( expression )? $lr) )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1102:8: ^( QUESTION_T $ll ^( COLON_T ( expression )? $lr) )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_QUESTION_T.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_ll.nextTree());
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1102:25: ^( COLON_T ( expression )? $lr)
                        {
                        SLAST root_2 = (SLAST)adaptor.nil();
                        root_2 = (SLAST)adaptor.becomeRoot(stream_COLON_T.nextNode(), root_2);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1102:35: ( expression )?
                        if ( stream_expression.hasNext() ) {
                            adaptor.addChild(root_2, stream_expression.nextTree());

                        }
                        stream_expression.reset();
                        adaptor.addChild(root_2, stream_lr.nextTree());

                        adaptor.addChild(root_1, root_2);
                        }

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);
                System.out.println("condition " + startIndex + " " + endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "conditional_expr"

    public static class logical_or_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "logical_or_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1105:1: logical_or_expr : e1= logical_and_expr ( LOGICAL_OR_T e2= logical_and_expr )* ;
    public final CompilerAstParser.logical_or_expr_return logical_or_expr() throws RecognitionException {
        CompilerAstParser.logical_or_expr_return retval = new CompilerAstParser.logical_or_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token LOGICAL_OR_T267=null;
        CompilerAstParser.logical_and_expr_return e1 = null;

        CompilerAstParser.logical_and_expr_return e2 = null;


        SLAST LOGICAL_OR_T267_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1115:3: (e1= logical_and_expr ( LOGICAL_OR_T e2= logical_and_expr )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1115:5: e1= logical_and_expr ( LOGICAL_OR_T e2= logical_and_expr )*
            {
            root_0 = (SLAST)adaptor.nil();

            pushFollow(FOLLOW_logical_and_expr_in_logical_or_expr3683);
            e1=logical_and_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, e1.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1115:25: ( LOGICAL_OR_T e2= logical_and_expr )*
            loop82:
            do {
                int alt82=2;
                int LA82_0 = input.LA(1);

                if ( (LA82_0==LOGICAL_OR_T) ) {
                    alt82=1;
                }


                switch (alt82) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1115:26: LOGICAL_OR_T e2= logical_and_expr
            	    {
            	    LOGICAL_OR_T267=(Token)match(input,LOGICAL_OR_T,FOLLOW_LOGICAL_OR_T_in_logical_or_expr3686); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    LOGICAL_OR_T267_tree = (SLAST)adaptor.create(LOGICAL_OR_T267);
            	    root_0 = (SLAST)adaptor.becomeRoot(LOGICAL_OR_T267_tree, root_0);
            	    }
            	    pushFollow(FOLLOW_logical_and_expr_in_logical_or_expr3691);
            	    e2=logical_and_expr();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, e2.getTree());

            	    }
            	    break;

            	default :
            	    break loop82;
                }
            } while (true);

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(e1!=null?((Token)e1.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(e1!=null?((Token)e1.stop):null);
                  if ((e2!=null?input.toString(e2.start,e2.stop):null) != null) {
                    token = (CommonToken)(e2!=null?((Token)e2.stop):null);
                  }
                  endIndex = token.getStopIndex();
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "logical_or_expr"

    public static class logical_and_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "logical_and_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1127:1: logical_and_expr : e1= bitwise_or_expr ( LOGICAL_AND_T e2= bitwise_or_expr )* ;
    public final CompilerAstParser.logical_and_expr_return logical_and_expr() throws RecognitionException {
        CompilerAstParser.logical_and_expr_return retval = new CompilerAstParser.logical_and_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token LOGICAL_AND_T268=null;
        CompilerAstParser.bitwise_or_expr_return e1 = null;

        CompilerAstParser.bitwise_or_expr_return e2 = null;


        SLAST LOGICAL_AND_T268_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1137:3: (e1= bitwise_or_expr ( LOGICAL_AND_T e2= bitwise_or_expr )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1137:5: e1= bitwise_or_expr ( LOGICAL_AND_T e2= bitwise_or_expr )*
            {
            root_0 = (SLAST)adaptor.nil();

            pushFollow(FOLLOW_bitwise_or_expr_in_logical_and_expr3722);
            e1=bitwise_or_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, e1.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1137:24: ( LOGICAL_AND_T e2= bitwise_or_expr )*
            loop83:
            do {
                int alt83=2;
                int LA83_0 = input.LA(1);

                if ( (LA83_0==LOGICAL_AND_T) ) {
                    alt83=1;
                }


                switch (alt83) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1137:25: LOGICAL_AND_T e2= bitwise_or_expr
            	    {
            	    LOGICAL_AND_T268=(Token)match(input,LOGICAL_AND_T,FOLLOW_LOGICAL_AND_T_in_logical_and_expr3725); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    LOGICAL_AND_T268_tree = (SLAST)adaptor.create(LOGICAL_AND_T268);
            	    root_0 = (SLAST)adaptor.becomeRoot(LOGICAL_AND_T268_tree, root_0);
            	    }
            	    pushFollow(FOLLOW_bitwise_or_expr_in_logical_and_expr3730);
            	    e2=bitwise_or_expr();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, e2.getTree());

            	    }
            	    break;

            	default :
            	    break loop83;
                }
            } while (true);

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(e1!=null?((Token)e1.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(e1!=null?((Token)e1.stop):null);
                  if ((e2!=null?input.toString(e2.start,e2.stop):null) != null) {
                    token = (CommonToken)(e2!=null?((Token)e2.stop):null);
                  }
                  endIndex = token.getStopIndex();
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "logical_and_expr"

    public static class bitwise_or_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "bitwise_or_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1149:1: bitwise_or_expr : e1= bitwise_xor_expr ( BIT_OR_T e2= bitwise_xor_expr )* ;
    public final CompilerAstParser.bitwise_or_expr_return bitwise_or_expr() throws RecognitionException {
        CompilerAstParser.bitwise_or_expr_return retval = new CompilerAstParser.bitwise_or_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token BIT_OR_T269=null;
        CompilerAstParser.bitwise_xor_expr_return e1 = null;

        CompilerAstParser.bitwise_xor_expr_return e2 = null;


        SLAST BIT_OR_T269_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1159:3: (e1= bitwise_xor_expr ( BIT_OR_T e2= bitwise_xor_expr )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1159:5: e1= bitwise_xor_expr ( BIT_OR_T e2= bitwise_xor_expr )*
            {
            root_0 = (SLAST)adaptor.nil();

            pushFollow(FOLLOW_bitwise_xor_expr_in_bitwise_or_expr3761);
            e1=bitwise_xor_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, e1.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1159:25: ( BIT_OR_T e2= bitwise_xor_expr )*
            loop84:
            do {
                int alt84=2;
                int LA84_0 = input.LA(1);

                if ( (LA84_0==BIT_OR_T) ) {
                    alt84=1;
                }


                switch (alt84) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1159:26: BIT_OR_T e2= bitwise_xor_expr
            	    {
            	    BIT_OR_T269=(Token)match(input,BIT_OR_T,FOLLOW_BIT_OR_T_in_bitwise_or_expr3764); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    BIT_OR_T269_tree = (SLAST)adaptor.create(BIT_OR_T269);
            	    root_0 = (SLAST)adaptor.becomeRoot(BIT_OR_T269_tree, root_0);
            	    }
            	    pushFollow(FOLLOW_bitwise_xor_expr_in_bitwise_or_expr3769);
            	    e2=bitwise_xor_expr();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, e2.getTree());

            	    }
            	    break;

            	default :
            	    break loop84;
                }
            } while (true);

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(e1!=null?((Token)e1.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(e1!=null?((Token)e1.stop):null);
                  if ((e2!=null?input.toString(e2.start,e2.stop):null) != null) {
                    token = (CommonToken)(e2!=null?((Token)e2.stop):null);
                  }
                  endIndex = token.getStopIndex();
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "bitwise_or_expr"

    public static class bitwise_xor_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "bitwise_xor_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1171:1: bitwise_xor_expr : e1= bitwise_and_expr ( POWER_T e2= bitwise_and_expr )* ;
    public final CompilerAstParser.bitwise_xor_expr_return bitwise_xor_expr() throws RecognitionException {
        CompilerAstParser.bitwise_xor_expr_return retval = new CompilerAstParser.bitwise_xor_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token POWER_T270=null;
        CompilerAstParser.bitwise_and_expr_return e1 = null;

        CompilerAstParser.bitwise_and_expr_return e2 = null;


        SLAST POWER_T270_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1181:3: (e1= bitwise_and_expr ( POWER_T e2= bitwise_and_expr )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1181:5: e1= bitwise_and_expr ( POWER_T e2= bitwise_and_expr )*
            {
            root_0 = (SLAST)adaptor.nil();

            pushFollow(FOLLOW_bitwise_and_expr_in_bitwise_xor_expr3800);
            e1=bitwise_and_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, e1.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1181:25: ( POWER_T e2= bitwise_and_expr )*
            loop85:
            do {
                int alt85=2;
                int LA85_0 = input.LA(1);

                if ( (LA85_0==POWER_T) ) {
                    alt85=1;
                }


                switch (alt85) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1181:26: POWER_T e2= bitwise_and_expr
            	    {
            	    POWER_T270=(Token)match(input,POWER_T,FOLLOW_POWER_T_in_bitwise_xor_expr3803); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    POWER_T270_tree = (SLAST)adaptor.create(POWER_T270);
            	    root_0 = (SLAST)adaptor.becomeRoot(POWER_T270_tree, root_0);
            	    }
            	    pushFollow(FOLLOW_bitwise_and_expr_in_bitwise_xor_expr3808);
            	    e2=bitwise_and_expr();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, e2.getTree());

            	    }
            	    break;

            	default :
            	    break loop85;
                }
            } while (true);

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(e1!=null?((Token)e1.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(e1!=null?((Token)e1.stop):null);
                  if ((e2!=null?input.toString(e2.start,e2.stop):null) != null) {
                    token = (CommonToken)(e2!=null?((Token)e2.stop):null);
                  }
                  endIndex = token.getStopIndex();
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "bitwise_xor_expr"

    public static class bitwise_and_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "bitwise_and_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1193:1: bitwise_and_expr : e1= concat_expr ( DOT_T e2= concat_expr )* ;
    public final CompilerAstParser.bitwise_and_expr_return bitwise_and_expr() throws RecognitionException {
        CompilerAstParser.bitwise_and_expr_return retval = new CompilerAstParser.bitwise_and_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token DOT_T271=null;
        CompilerAstParser.concat_expr_return e1 = null;

        CompilerAstParser.concat_expr_return e2 = null;


        SLAST DOT_T271_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1203:3: (e1= concat_expr ( DOT_T e2= concat_expr )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1203:5: e1= concat_expr ( DOT_T e2= concat_expr )*
            {
            root_0 = (SLAST)adaptor.nil();

            pushFollow(FOLLOW_concat_expr_in_bitwise_and_expr3839);
            e1=concat_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, e1.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1203:20: ( DOT_T e2= concat_expr )*
            loop86:
            do {
                int alt86=2;
                int LA86_0 = input.LA(1);

                if ( (LA86_0==DOT_T) ) {
                    alt86=1;
                }


                switch (alt86) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1203:21: DOT_T e2= concat_expr
            	    {
            	    DOT_T271=(Token)match(input,DOT_T,FOLLOW_DOT_T_in_bitwise_and_expr3842); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    DOT_T271_tree = (SLAST)adaptor.create(DOT_T271);
            	    root_0 = (SLAST)adaptor.becomeRoot(DOT_T271_tree, root_0);
            	    }
            	    pushFollow(FOLLOW_concat_expr_in_bitwise_and_expr3847);
            	    e2=concat_expr();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, e2.getTree());

            	    }
            	    break;

            	default :
            	    break loop86;
                }
            } while (true);

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(e1!=null?((Token)e1.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(e1!=null?((Token)e1.stop):null);
                  if ((e2!=null?input.toString(e2.start,e2.stop):null) != null) {
                    token = (CommonToken)(e2!=null?((Token)e2.stop):null);
                  }
                  endIndex = token.getStopIndex();
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "bitwise_and_expr"

    public static class concat_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "concat_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1215:1: concat_expr : e1= equality_expr ( REF_T e2= equality_expr )* ;
    public final CompilerAstParser.concat_expr_return concat_expr() throws RecognitionException {
        CompilerAstParser.concat_expr_return retval = new CompilerAstParser.concat_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token REF_T272=null;
        CompilerAstParser.equality_expr_return e1 = null;

        CompilerAstParser.equality_expr_return e2 = null;


        SLAST REF_T272_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1225:3: (e1= equality_expr ( REF_T e2= equality_expr )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1225:5: e1= equality_expr ( REF_T e2= equality_expr )*
            {
            root_0 = (SLAST)adaptor.nil();

            pushFollow(FOLLOW_equality_expr_in_concat_expr3878);
            e1=equality_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, e1.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1225:22: ( REF_T e2= equality_expr )*
            loop87:
            do {
                int alt87=2;
                int LA87_0 = input.LA(1);

                if ( (LA87_0==REF_T) ) {
                    alt87=1;
                }


                switch (alt87) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1225:23: REF_T e2= equality_expr
            	    {
            	    REF_T272=(Token)match(input,REF_T,FOLLOW_REF_T_in_concat_expr3881); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    REF_T272_tree = (SLAST)adaptor.create(REF_T272);
            	    root_0 = (SLAST)adaptor.becomeRoot(REF_T272_tree, root_0);
            	    }
            	    pushFollow(FOLLOW_equality_expr_in_concat_expr3886);
            	    e2=equality_expr();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, e2.getTree());

            	    }
            	    break;

            	default :
            	    break loop87;
                }
            } while (true);

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(e1!=null?((Token)e1.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(e1!=null?((Token)e1.stop):null);
                  if ((e2!=null?input.toString(e2.start,e2.stop):null) != null) {
                    token = (CommonToken)(e2!=null?((Token)e2.stop):null);
                  }
                  endIndex = token.getStopIndex();
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "concat_expr"

    public static class equality_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "equality_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1237:1: equality_expr : e1= relational_expr ( ( EQUAL_EQUAL_T | NOT_EQUAL_T | EQUAL_EQUAL_EQUAL_T | NOT_EQUAL_EQUAL_T ) e2= relational_expr )* ;
    public final CompilerAstParser.equality_expr_return equality_expr() throws RecognitionException {
        CompilerAstParser.equality_expr_return retval = new CompilerAstParser.equality_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token set273=null;
        CompilerAstParser.relational_expr_return e1 = null;

        CompilerAstParser.relational_expr_return e2 = null;


        SLAST set273_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1248:3: (e1= relational_expr ( ( EQUAL_EQUAL_T | NOT_EQUAL_T | EQUAL_EQUAL_EQUAL_T | NOT_EQUAL_EQUAL_T ) e2= relational_expr )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1248:5: e1= relational_expr ( ( EQUAL_EQUAL_T | NOT_EQUAL_T | EQUAL_EQUAL_EQUAL_T | NOT_EQUAL_EQUAL_T ) e2= relational_expr )*
            {
            root_0 = (SLAST)adaptor.nil();

            pushFollow(FOLLOW_relational_expr_in_equality_expr3917);
            e1=relational_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, e1.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1248:24: ( ( EQUAL_EQUAL_T | NOT_EQUAL_T | EQUAL_EQUAL_EQUAL_T | NOT_EQUAL_EQUAL_T ) e2= relational_expr )*
            loop88:
            do {
                int alt88=2;
                int LA88_0 = input.LA(1);

                if ( ((LA88_0>=EQUAL_EQUAL_T && LA88_0<=NOT_EQUAL_EQUAL_T)) ) {
                    alt88=1;
                }


                switch (alt88) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1248:25: ( EQUAL_EQUAL_T | NOT_EQUAL_T | EQUAL_EQUAL_EQUAL_T | NOT_EQUAL_EQUAL_T ) e2= relational_expr
            	    {
            	    set273=(Token)input.LT(1);
            	    set273=(Token)input.LT(1);
            	    if ( (input.LA(1)>=EQUAL_EQUAL_T && input.LA(1)<=NOT_EQUAL_EQUAL_T) ) {
            	        input.consume();
            	        if ( state.backtracking==0 ) root_0 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(set273), root_0);
            	        state.errorRecovery=false;state.failed=false;
            	    }
            	    else {
            	        if (state.backtracking>0) {state.failed=true; return retval;}
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        throw mse;
            	    }

            	    pushFollow(FOLLOW_relational_expr_in_equality_expr3939);
            	    e2=relational_expr();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, e2.getTree());

            	    }
            	    break;

            	default :
            	    break loop88;
                }
            } while (true);

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(e1!=null?((Token)e1.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(e1!=null?((Token)e1.stop):null);
                  if ((e2!=null?input.toString(e2.start,e2.stop):null) != null) {
                    token = (CommonToken)(e2!=null?((Token)e2.stop):null);
                  }
                  endIndex = token.getStopIndex();
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);
                System.out.println("euqa " + startIndex + " " + endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "equality_expr"

    public static class relational_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "relational_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1260:1: relational_expr : e1= shift_expr ( ( LT_T | MT_T | LE_T | ME_T ) e2= shift_expr )* ;
    public final CompilerAstParser.relational_expr_return relational_expr() throws RecognitionException {
        CompilerAstParser.relational_expr_return retval = new CompilerAstParser.relational_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token set274=null;
        CompilerAstParser.shift_expr_return e1 = null;

        CompilerAstParser.shift_expr_return e2 = null;


        SLAST set274_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1271:3: (e1= shift_expr ( ( LT_T | MT_T | LE_T | ME_T ) e2= shift_expr )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1271:5: e1= shift_expr ( ( LT_T | MT_T | LE_T | ME_T ) e2= shift_expr )*
            {
            root_0 = (SLAST)adaptor.nil();

            pushFollow(FOLLOW_shift_expr_in_relational_expr3970);
            e1=shift_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, e1.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1271:19: ( ( LT_T | MT_T | LE_T | ME_T ) e2= shift_expr )*
            loop89:
            do {
                int alt89=2;
                int LA89_0 = input.LA(1);

                if ( ((LA89_0>=LT_T && LA89_0<=ME_T)) ) {
                    alt89=1;
                }


                switch (alt89) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1271:20: ( LT_T | MT_T | LE_T | ME_T ) e2= shift_expr
            	    {
            	    set274=(Token)input.LT(1);
            	    set274=(Token)input.LT(1);
            	    if ( (input.LA(1)>=LT_T && input.LA(1)<=ME_T) ) {
            	        input.consume();
            	        if ( state.backtracking==0 ) root_0 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(set274), root_0);
            	        state.errorRecovery=false;state.failed=false;
            	    }
            	    else {
            	        if (state.backtracking>0) {state.failed=true; return retval;}
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        throw mse;
            	    }

            	    pushFollow(FOLLOW_shift_expr_in_relational_expr3992);
            	    e2=shift_expr();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, e2.getTree());

            	    }
            	    break;

            	default :
            	    break loop89;
                }
            } while (true);

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(e1!=null?((Token)e1.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(e1!=null?((Token)e1.stop):null);
                  if ((e2!=null?input.toString(e2.start,e2.stop):null) != null) {
                    token = (CommonToken)(e2!=null?((Token)e2.stop):null);
                  }
                  endIndex = token.getStopIndex();
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);
                System.out.println("rela " + startIndex + " " + endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "relational_expr"

    public static class shift_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "shift_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1283:1: shift_expr : e1= additive_expr ( ( LSHIFT_T | RSHIFT_T ) e2= additive_expr )* ;
    public final CompilerAstParser.shift_expr_return shift_expr() throws RecognitionException {
        CompilerAstParser.shift_expr_return retval = new CompilerAstParser.shift_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token set275=null;
        CompilerAstParser.additive_expr_return e1 = null;

        CompilerAstParser.additive_expr_return e2 = null;


        SLAST set275_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1294:3: (e1= additive_expr ( ( LSHIFT_T | RSHIFT_T ) e2= additive_expr )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1294:5: e1= additive_expr ( ( LSHIFT_T | RSHIFT_T ) e2= additive_expr )*
            {
            root_0 = (SLAST)adaptor.nil();

            pushFollow(FOLLOW_additive_expr_in_shift_expr4023);
            e1=additive_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, e1.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1294:22: ( ( LSHIFT_T | RSHIFT_T ) e2= additive_expr )*
            loop90:
            do {
                int alt90=2;
                int LA90_0 = input.LA(1);

                if ( ((LA90_0>=LSHIFT_T && LA90_0<=RSHIFT_T)) ) {
                    alt90=1;
                }


                switch (alt90) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1294:23: ( LSHIFT_T | RSHIFT_T ) e2= additive_expr
            	    {
            	    set275=(Token)input.LT(1);
            	    set275=(Token)input.LT(1);
            	    if ( (input.LA(1)>=LSHIFT_T && input.LA(1)<=RSHIFT_T) ) {
            	        input.consume();
            	        if ( state.backtracking==0 ) root_0 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(set275), root_0);
            	        state.errorRecovery=false;state.failed=false;
            	    }
            	    else {
            	        if (state.backtracking>0) {state.failed=true; return retval;}
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        throw mse;
            	    }

            	    pushFollow(FOLLOW_additive_expr_in_shift_expr4037);
            	    e2=additive_expr();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, e2.getTree());

            	    }
            	    break;

            	default :
            	    break loop90;
                }
            } while (true);

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(e1!=null?((Token)e1.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(e1!=null?((Token)e1.stop):null);
                  if ((e2!=null?input.toString(e2.start,e2.stop):null) != null) {
                    token = (CommonToken)(e2!=null?((Token)e2.stop):null);
                  }
                  endIndex = token.getStopIndex();
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);
                System.out.println("shift " + startIndex + " " + endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "shift_expr"

    public static class additive_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "additive_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1306:1: additive_expr : e1= multiplicative_expr ( ( PLUS_T | MINUS_T ) e2= multiplicative_expr )* ;
    public final CompilerAstParser.additive_expr_return additive_expr() throws RecognitionException {
        CompilerAstParser.additive_expr_return retval = new CompilerAstParser.additive_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token set276=null;
        CompilerAstParser.multiplicative_expr_return e1 = null;

        CompilerAstParser.multiplicative_expr_return e2 = null;


        SLAST set276_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1317:3: (e1= multiplicative_expr ( ( PLUS_T | MINUS_T ) e2= multiplicative_expr )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1317:5: e1= multiplicative_expr ( ( PLUS_T | MINUS_T ) e2= multiplicative_expr )*
            {
            root_0 = (SLAST)adaptor.nil();

            pushFollow(FOLLOW_multiplicative_expr_in_additive_expr4068);
            e1=multiplicative_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, e1.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1317:28: ( ( PLUS_T | MINUS_T ) e2= multiplicative_expr )*
            loop91:
            do {
                int alt91=2;
                int LA91_0 = input.LA(1);

                if ( ((LA91_0>=PLUS_T && LA91_0<=MINUS_T)) ) {
                    alt91=1;
                }


                switch (alt91) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1317:29: ( PLUS_T | MINUS_T ) e2= multiplicative_expr
            	    {
            	    set276=(Token)input.LT(1);
            	    set276=(Token)input.LT(1);
            	    if ( (input.LA(1)>=PLUS_T && input.LA(1)<=MINUS_T) ) {
            	        input.consume();
            	        if ( state.backtracking==0 ) root_0 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(set276), root_0);
            	        state.errorRecovery=false;state.failed=false;
            	    }
            	    else {
            	        if (state.backtracking>0) {state.failed=true; return retval;}
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        throw mse;
            	    }

            	    pushFollow(FOLLOW_multiplicative_expr_in_additive_expr4082);
            	    e2=multiplicative_expr();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, e2.getTree());

            	    }
            	    break;

            	default :
            	    break loop91;
                }
            } while (true);

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(e1!=null?((Token)e1.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(e1!=null?((Token)e1.stop):null);
                  if ((e2!=null?input.toString(e2.start,e2.stop):null) != null) {
                    token = (CommonToken)(e2!=null?((Token)e2.stop):null);
                  }
                  endIndex = token.getStopIndex();
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);
                System.out.println("add " + startIndex + " " + endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "additive_expr"

    public static class multiplicative_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "multiplicative_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1329:1: multiplicative_expr : e1= cast_expr ( ( MUL_T | DIV_T | PERCENT_T ) e2= cast_expr )* ;
    public final CompilerAstParser.multiplicative_expr_return multiplicative_expr() throws RecognitionException {
        CompilerAstParser.multiplicative_expr_return retval = new CompilerAstParser.multiplicative_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token set277=null;
        CompilerAstParser.cast_expr_return e1 = null;

        CompilerAstParser.cast_expr_return e2 = null;


        SLAST set277_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1340:3: (e1= cast_expr ( ( MUL_T | DIV_T | PERCENT_T ) e2= cast_expr )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1340:5: e1= cast_expr ( ( MUL_T | DIV_T | PERCENT_T ) e2= cast_expr )*
            {
            root_0 = (SLAST)adaptor.nil();

            pushFollow(FOLLOW_cast_expr_in_multiplicative_expr4113);
            e1=cast_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, e1.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1340:18: ( ( MUL_T | DIV_T | PERCENT_T ) e2= cast_expr )*
            loop92:
            do {
                int alt92=2;
                int LA92_0 = input.LA(1);

                if ( ((LA92_0>=MUL_T && LA92_0<=PERCENT_T)) ) {
                    alt92=1;
                }


                switch (alt92) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1340:19: ( MUL_T | DIV_T | PERCENT_T ) e2= cast_expr
            	    {
            	    set277=(Token)input.LT(1);
            	    set277=(Token)input.LT(1);
            	    if ( (input.LA(1)>=MUL_T && input.LA(1)<=PERCENT_T) ) {
            	        input.consume();
            	        if ( state.backtracking==0 ) root_0 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(set277), root_0);
            	        state.errorRecovery=false;state.failed=false;
            	    }
            	    else {
            	        if (state.backtracking>0) {state.failed=true; return retval;}
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        throw mse;
            	    }

            	    pushFollow(FOLLOW_cast_expr_in_multiplicative_expr4131);
            	    e2=cast_expr();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, e2.getTree());

            	    }
            	    break;

            	default :
            	    break loop92;
                }
            } while (true);

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(e1!=null?((Token)e1.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(e1!=null?((Token)e1.stop):null);
                  if ((e2!=null?input.toString(e2.start,e2.stop):null) != null) {
                    token = (CommonToken)(e2!=null?((Token)e2.stop):null);
                  }
                  endIndex = token.getStopIndex();
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);
                System.out.println("mult " + startIndex + " " + endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "multiplicative_expr"

    public static class cast_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "cast_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1352:1: cast_expr : ( unary_expr | ( LEFT_PARETHESIS cast_option RIGHT_PARETHESIS )+ unary_expr -> ^( CAST_EXPR ( cast_option )+ unary_expr ) );
    public final CompilerAstParser.cast_expr_return cast_expr() throws RecognitionException {
        CompilerAstParser.cast_expr_return retval = new CompilerAstParser.cast_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token LEFT_PARETHESIS279=null;
        Token RIGHT_PARETHESIS281=null;
        CompilerAstParser.unary_expr_return unary_expr278 = null;

        CompilerAstParser.cast_option_return cast_option280 = null;

        CompilerAstParser.unary_expr_return unary_expr282 = null;


        SLAST LEFT_PARETHESIS279_tree=null;
        SLAST RIGHT_PARETHESIS281_tree=null;
        RewriteRuleTokenStream stream_LEFT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token LEFT_PARETHESIS");
        RewriteRuleTokenStream stream_RIGHT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token RIGHT_PARETHESIS");
        RewriteRuleSubtreeStream stream_unary_expr=new RewriteRuleSubtreeStream(adaptor,"rule unary_expr");
        RewriteRuleSubtreeStream stream_cast_option=new RewriteRuleSubtreeStream(adaptor,"rule cast_option");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1363:3: ( unary_expr | ( LEFT_PARETHESIS cast_option RIGHT_PARETHESIS )+ unary_expr -> ^( CAST_EXPR ( cast_option )+ unary_expr ) )
            int alt94=2;
            int LA94_0 = input.LA(1);

            if ( (LA94_0==IDENTIFIER||LA94_0==REF_T||LA94_0==STRINGLITERAL||(LA94_0>=PLUS_T && LA94_0<=MINUS_T)||(LA94_0>=CLONE_T && LA94_0<=MINUS_MINUS_T)||(LA94_0>=AT_T && LA94_0<=PRINT_T)||(LA94_0>=DOLLAR_T && LA94_0<=DOUBLELITERRAL)||(LA94_0>=182 && LA94_0<=188)) ) {
                alt94=1;
            }
            else if ( (LA94_0==LEFT_PARETHESIS) ) {
                switch ( input.LA(2) ) {
                case 182:
                    {
                    int LA94_3 = input.LA(3);

                    if ( (LA94_3==LEFT_PARETHESIS) ) {
                        alt94=1;
                    }
                    else if ( (LA94_3==RIGHT_PARETHESIS) ) {
                        alt94=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return retval;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 94, 3, input);

                        throw nvae;
                    }
                    }
                    break;
                case LEFT_PARETHESIS:
                case IDENTIFIER:
                case REF_T:
                case STRINGLITERAL:
                case PLUS_T:
                case MINUS_T:
                case TILDA_T:
                case EXC_NOT_T:
                case PLUS_PLUS_T:
                case MINUS_MINUS_T:
                case AT_T:
                case LIST_T:
                case NEW_T:
                case BACKTRICKLITERAL:
                case PRINT_T:
                case DOLLAR_T:
                case INTLITERAL:
                case FLOATLITERAL:
                case DOUBLELITERRAL:
                case 183:
                case 184:
                case 185:
                case 186:
                case 187:
                case 188:
                    {
                    alt94=1;
                    }
                    break;
                case CLONE_T:
                    {
                    int LA94_4 = input.LA(3);

                    if ( (LA94_4==RIGHT_PARETHESIS) ) {
                        alt94=2;
                    }
                    else if ( (LA94_4==IDENTIFIER||LA94_4==DOLLAR_T) ) {
                        alt94=1;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return retval;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 94, 4, input);

                        throw nvae;
                    }
                    }
                    break;
                case 173:
                case 174:
                case 175:
                case 176:
                case 177:
                case 178:
                case 179:
                case 180:
                case 181:
                    {
                    alt94=2;
                    }
                    break;
                default:
                    if (state.backtracking>0) {state.failed=true; return retval;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 94, 2, input);

                    throw nvae;
                }

            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 94, 0, input);

                throw nvae;
            }
            switch (alt94) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1363:5: unary_expr
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_unary_expr_in_cast_expr4160);
                    unary_expr278=unary_expr();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, unary_expr278.getTree());
                    if ( state.backtracking==0 ) {

                          token = (CommonToken)(unary_expr278!=null?((Token)unary_expr278.start):null);
                          startIndex = token.getStartIndex();
                          token = (CommonToken)(unary_expr278!=null?((Token)unary_expr278.stop):null);
                          endIndex = token.getStopIndex();
                        
                    }

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1370:5: ( LEFT_PARETHESIS cast_option RIGHT_PARETHESIS )+ unary_expr
                    {
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1370:5: ( LEFT_PARETHESIS cast_option RIGHT_PARETHESIS )+
                    int cnt93=0;
                    loop93:
                    do {
                        int alt93=2;
                        int LA93_0 = input.LA(1);

                        if ( (LA93_0==LEFT_PARETHESIS) ) {
                            switch ( input.LA(2) ) {
                            case 182:
                                {
                                int LA93_3 = input.LA(3);

                                if ( (LA93_3==RIGHT_PARETHESIS) ) {
                                    alt93=1;
                                }


                                }
                                break;
                            case CLONE_T:
                                {
                                int LA93_4 = input.LA(3);

                                if ( (LA93_4==RIGHT_PARETHESIS) ) {
                                    alt93=1;
                                }


                                }
                                break;
                            case 173:
                            case 174:
                            case 175:
                            case 176:
                            case 177:
                            case 178:
                            case 179:
                            case 180:
                            case 181:
                                {
                                alt93=1;
                                }
                                break;

                            }

                        }


                        switch (alt93) {
                    	case 1 :
                    	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1370:6: LEFT_PARETHESIS cast_option RIGHT_PARETHESIS
                    	    {
                    	    LEFT_PARETHESIS279=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_cast_expr4171); if (state.failed) return retval; 
                    	    if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS279);

                    	    pushFollow(FOLLOW_cast_option_in_cast_expr4173);
                    	    cast_option280=cast_option();

                    	    state._fsp--;
                    	    if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) stream_cast_option.add(cast_option280.getTree());
                    	    RIGHT_PARETHESIS281=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_cast_expr4175); if (state.failed) return retval; 
                    	    if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS281);


                    	    }
                    	    break;

                    	default :
                    	    if ( cnt93 >= 1 ) break loop93;
                    	    if (state.backtracking>0) {state.failed=true; return retval;}
                                EarlyExitException eee =
                                    new EarlyExitException(93, input);
                                throw eee;
                        }
                        cnt93++;
                    } while (true);

                    pushFollow(FOLLOW_unary_expr_in_cast_expr4179);
                    unary_expr282=unary_expr();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_unary_expr.add(unary_expr282.getTree());
                    if ( state.backtracking==0 ) {

                          token = (CommonToken)LEFT_PARETHESIS279;
                          startIndex = token.getStartIndex();
                          token = (CommonToken)(unary_expr282!=null?((Token)unary_expr282.stop):null);
                          endIndex = token.getStopIndex();
                        
                    }


                    // AST REWRITE
                    // elements: unary_expr, cast_option
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 1377:4: -> ^( CAST_EXPR ( cast_option )+ unary_expr )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1377:7: ^( CAST_EXPR ( cast_option )+ unary_expr )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(CAST_EXPR, "CAST_EXPR"), root_1);

                        if ( !(stream_cast_option.hasNext()) ) {
                            throw new RewriteEarlyExitException();
                        }
                        while ( stream_cast_option.hasNext() ) {
                            adaptor.addChild(root_1, stream_cast_option.nextTree());

                        }
                        stream_cast_option.reset();
                        adaptor.addChild(root_1, stream_unary_expr.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);
                System.out.println("cast " + startIndex + " " + endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "cast_expr"

    public static class cast_option_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "cast_option"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1380:1: cast_option : ( 'bool' | 'boolean' | 'int' | 'float' | 'double' | 'real' | 'string' | 'unset' | CLONE_T | 'object' | 'array' );
    public final CompilerAstParser.cast_option_return cast_option() throws RecognitionException {
        CompilerAstParser.cast_option_return retval = new CompilerAstParser.cast_option_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token set283=null;

        SLAST set283_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1381:3: ( 'bool' | 'boolean' | 'int' | 'float' | 'double' | 'real' | 'string' | 'unset' | CLONE_T | 'object' | 'array' )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:
            {
            root_0 = (SLAST)adaptor.nil();

            set283=(Token)input.LT(1);
            if ( input.LA(1)==CLONE_T||(input.LA(1)>=173 && input.LA(1)<=182) ) {
                input.consume();
                if ( state.backtracking==0 ) adaptor.addChild(root_0, (SLAST)adaptor.create(set283));
                state.errorRecovery=false;state.failed=false;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                MismatchedSetException mse = new MismatchedSetException(null,input);
                throw mse;
            }


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "cast_option"

    public static class unary_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "unary_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1394:1: unary_expr : ( unary_symbol_list prefix_inc_dec_expr -> ^( UNARY_EXPR unary_symbol_list prefix_inc_dec_expr ) | prefix_inc_dec_expr );
    public final CompilerAstParser.unary_expr_return unary_expr() throws RecognitionException {
        CompilerAstParser.unary_expr_return retval = new CompilerAstParser.unary_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        CompilerAstParser.unary_symbol_list_return unary_symbol_list284 = null;

        CompilerAstParser.prefix_inc_dec_expr_return prefix_inc_dec_expr285 = null;

        CompilerAstParser.prefix_inc_dec_expr_return prefix_inc_dec_expr286 = null;


        RewriteRuleSubtreeStream stream_prefix_inc_dec_expr=new RewriteRuleSubtreeStream(adaptor,"rule prefix_inc_dec_expr");
        RewriteRuleSubtreeStream stream_unary_symbol_list=new RewriteRuleSubtreeStream(adaptor,"rule unary_symbol_list");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1405:3: ( unary_symbol_list prefix_inc_dec_expr -> ^( UNARY_EXPR unary_symbol_list prefix_inc_dec_expr ) | prefix_inc_dec_expr )
            int alt95=2;
            int LA95_0 = input.LA(1);

            if ( (LA95_0==REF_T||(LA95_0>=PLUS_T && LA95_0<=MINUS_T)||(LA95_0>=TILDA_T && LA95_0<=EXC_NOT_T)) ) {
                alt95=1;
            }
            else if ( (LA95_0==LEFT_PARETHESIS||LA95_0==IDENTIFIER||LA95_0==STRINGLITERAL||LA95_0==CLONE_T||(LA95_0>=PLUS_PLUS_T && LA95_0<=MINUS_MINUS_T)||(LA95_0>=AT_T && LA95_0<=PRINT_T)||(LA95_0>=DOLLAR_T && LA95_0<=DOUBLELITERRAL)||(LA95_0>=182 && LA95_0<=188)) ) {
                alt95=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 95, 0, input);

                throw nvae;
            }
            switch (alt95) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1405:5: unary_symbol_list prefix_inc_dec_expr
                    {
                    pushFollow(FOLLOW_unary_symbol_list_in_unary_expr4299);
                    unary_symbol_list284=unary_symbol_list();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_unary_symbol_list.add(unary_symbol_list284.getTree());
                    pushFollow(FOLLOW_prefix_inc_dec_expr_in_unary_expr4301);
                    prefix_inc_dec_expr285=prefix_inc_dec_expr();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_prefix_inc_dec_expr.add(prefix_inc_dec_expr285.getTree());
                    if ( state.backtracking==0 ) {

                          token = (CommonToken)(unary_symbol_list284!=null?((Token)unary_symbol_list284.start):null);
                          startIndex = token.getStartIndex();
                          token = (CommonToken)(prefix_inc_dec_expr285!=null?((Token)prefix_inc_dec_expr285.stop):null);
                          endIndex = token.getStopIndex();
                        
                    }


                    // AST REWRITE
                    // elements: prefix_inc_dec_expr, unary_symbol_list
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 1412:5: -> ^( UNARY_EXPR unary_symbol_list prefix_inc_dec_expr )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1412:9: ^( UNARY_EXPR unary_symbol_list prefix_inc_dec_expr )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(UNARY_EXPR, "UNARY_EXPR"), root_1);

                        adaptor.addChild(root_1, stream_unary_symbol_list.nextTree());
                        adaptor.addChild(root_1, stream_prefix_inc_dec_expr.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1413:5: prefix_inc_dec_expr
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_prefix_inc_dec_expr_in_unary_expr4326);
                    prefix_inc_dec_expr286=prefix_inc_dec_expr();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, prefix_inc_dec_expr286.getTree());
                    if ( state.backtracking==0 ) {

                          token = (CommonToken)(prefix_inc_dec_expr286!=null?((Token)prefix_inc_dec_expr286.start):null);
                          startIndex = token.getStartIndex();
                          token = (CommonToken)(prefix_inc_dec_expr286!=null?((Token)prefix_inc_dec_expr286.stop):null);
                          endIndex = token.getStopIndex();
                        
                    }

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);
                System.out.println("unary " + startIndex + " " + endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "unary_expr"

    public static class unary_symbol_list_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "unary_symbol_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1422:1: unary_symbol_list : ( unary_symbol )+ ;
    public final CompilerAstParser.unary_symbol_list_return unary_symbol_list() throws RecognitionException {
        CompilerAstParser.unary_symbol_list_return retval = new CompilerAstParser.unary_symbol_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        CompilerAstParser.unary_symbol_return unary_symbol287 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1423:3: ( ( unary_symbol )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1423:5: ( unary_symbol )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1423:5: ( unary_symbol )+
            int cnt96=0;
            loop96:
            do {
                int alt96=2;
                int LA96_0 = input.LA(1);

                if ( (LA96_0==REF_T||(LA96_0>=PLUS_T && LA96_0<=MINUS_T)||(LA96_0>=TILDA_T && LA96_0<=EXC_NOT_T)) ) {
                    alt96=1;
                }


                switch (alt96) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1423:5: unary_symbol
            	    {
            	    pushFollow(FOLLOW_unary_symbol_in_unary_symbol_list4343);
            	    unary_symbol287=unary_symbol();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, unary_symbol287.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt96 >= 1 ) break loop96;
            	    if (state.backtracking>0) {state.failed=true; return retval;}
                        EarlyExitException eee =
                            new EarlyExitException(96, input);
                        throw eee;
                }
                cnt96++;
            } while (true);


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "unary_symbol_list"

    public static class unary_symbol_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "unary_symbol"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1426:1: unary_symbol : ( REF_T | PLUS_T | MINUS_T | TILDA_T | EXC_NOT_T );
    public final CompilerAstParser.unary_symbol_return unary_symbol() throws RecognitionException {
        CompilerAstParser.unary_symbol_return retval = new CompilerAstParser.unary_symbol_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token set288=null;

        SLAST set288_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1427:3: ( REF_T | PLUS_T | MINUS_T | TILDA_T | EXC_NOT_T )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:
            {
            root_0 = (SLAST)adaptor.nil();

            set288=(Token)input.LT(1);
            if ( input.LA(1)==REF_T||(input.LA(1)>=PLUS_T && input.LA(1)<=MINUS_T)||(input.LA(1)>=TILDA_T && input.LA(1)<=EXC_NOT_T) ) {
                input.consume();
                if ( state.backtracking==0 ) adaptor.addChild(root_0, (SLAST)adaptor.create(set288));
                state.errorRecovery=false;state.failed=false;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                MismatchedSetException mse = new MismatchedSetException(null,input);
                throw mse;
            }


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "unary_symbol"

    public static class prefix_inc_dec_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "prefix_inc_dec_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1430:1: prefix_inc_dec_expr : ( post_inc_dec_expr | ( plus_minus )+ post_inc_dec_expr -> ^( PREFIX_EXPR ( plus_minus )+ post_inc_dec_expr ) );
    public final CompilerAstParser.prefix_inc_dec_expr_return prefix_inc_dec_expr() throws RecognitionException {
        CompilerAstParser.prefix_inc_dec_expr_return retval = new CompilerAstParser.prefix_inc_dec_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        CompilerAstParser.post_inc_dec_expr_return post_inc_dec_expr289 = null;

        CompilerAstParser.plus_minus_return plus_minus290 = null;

        CompilerAstParser.post_inc_dec_expr_return post_inc_dec_expr291 = null;


        RewriteRuleSubtreeStream stream_plus_minus=new RewriteRuleSubtreeStream(adaptor,"rule plus_minus");
        RewriteRuleSubtreeStream stream_post_inc_dec_expr=new RewriteRuleSubtreeStream(adaptor,"rule post_inc_dec_expr");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1441:3: ( post_inc_dec_expr | ( plus_minus )+ post_inc_dec_expr -> ^( PREFIX_EXPR ( plus_minus )+ post_inc_dec_expr ) )
            int alt98=2;
            int LA98_0 = input.LA(1);

            if ( (LA98_0==LEFT_PARETHESIS||LA98_0==IDENTIFIER||LA98_0==STRINGLITERAL||LA98_0==CLONE_T||(LA98_0>=AT_T && LA98_0<=PRINT_T)||(LA98_0>=DOLLAR_T && LA98_0<=DOUBLELITERRAL)||(LA98_0>=182 && LA98_0<=188)) ) {
                alt98=1;
            }
            else if ( ((LA98_0>=PLUS_PLUS_T && LA98_0<=MINUS_MINUS_T)) ) {
                alt98=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 98, 0, input);

                throw nvae;
            }
            switch (alt98) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1441:5: post_inc_dec_expr
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_post_inc_dec_expr_in_prefix_inc_dec_expr4400);
                    post_inc_dec_expr289=post_inc_dec_expr();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, post_inc_dec_expr289.getTree());
                    if ( state.backtracking==0 ) {

                          token = (CommonToken)(post_inc_dec_expr289!=null?((Token)post_inc_dec_expr289.start):null);
                          startIndex = token.getStartIndex();
                          token = (CommonToken)(post_inc_dec_expr289!=null?((Token)post_inc_dec_expr289.stop):null);
                          endIndex = token.getStopIndex();
                        
                    }

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1448:5: ( plus_minus )+ post_inc_dec_expr
                    {
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1448:5: ( plus_minus )+
                    int cnt97=0;
                    loop97:
                    do {
                        int alt97=2;
                        int LA97_0 = input.LA(1);

                        if ( ((LA97_0>=PLUS_PLUS_T && LA97_0<=MINUS_MINUS_T)) ) {
                            alt97=1;
                        }


                        switch (alt97) {
                    	case 1 :
                    	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1448:6: plus_minus
                    	    {
                    	    pushFollow(FOLLOW_plus_minus_in_prefix_inc_dec_expr4411);
                    	    plus_minus290=plus_minus();

                    	    state._fsp--;
                    	    if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) stream_plus_minus.add(plus_minus290.getTree());

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt97 >= 1 ) break loop97;
                    	    if (state.backtracking>0) {state.failed=true; return retval;}
                                EarlyExitException eee =
                                    new EarlyExitException(97, input);
                                throw eee;
                        }
                        cnt97++;
                    } while (true);

                    pushFollow(FOLLOW_post_inc_dec_expr_in_prefix_inc_dec_expr4415);
                    post_inc_dec_expr291=post_inc_dec_expr();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_post_inc_dec_expr.add(post_inc_dec_expr291.getTree());
                    if ( state.backtracking==0 ) {

                          token = (CommonToken)(plus_minus290!=null?((Token)plus_minus290.start):null);
                          startIndex = token.getStartIndex();
                          token = (CommonToken)(post_inc_dec_expr291!=null?((Token)post_inc_dec_expr291.stop):null);
                          endIndex = token.getStopIndex();
                        
                    }


                    // AST REWRITE
                    // elements: post_inc_dec_expr, plus_minus
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 1455:4: -> ^( PREFIX_EXPR ( plus_minus )+ post_inc_dec_expr )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1455:8: ^( PREFIX_EXPR ( plus_minus )+ post_inc_dec_expr )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(PREFIX_EXPR, "PREFIX_EXPR"), root_1);

                        if ( !(stream_plus_minus.hasNext()) ) {
                            throw new RewriteEarlyExitException();
                        }
                        while ( stream_plus_minus.hasNext() ) {
                            adaptor.addChild(root_1, stream_plus_minus.nextTree());

                        }
                        stream_plus_minus.reset();
                        adaptor.addChild(root_1, stream_post_inc_dec_expr.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);
                System.out.println("prefix " + startIndex + " " + endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "prefix_inc_dec_expr"

    public static class post_inc_dec_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "post_inc_dec_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1458:1: post_inc_dec_expr : ( instance_expr -> instance_expr ) ( plus_minus -> ^( POSTFIX_EXPR instance_expr plus_minus ) )* ;
    public final CompilerAstParser.post_inc_dec_expr_return post_inc_dec_expr() throws RecognitionException {
        CompilerAstParser.post_inc_dec_expr_return retval = new CompilerAstParser.post_inc_dec_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        CompilerAstParser.instance_expr_return instance_expr292 = null;

        CompilerAstParser.plus_minus_return plus_minus293 = null;


        RewriteRuleSubtreeStream stream_plus_minus=new RewriteRuleSubtreeStream(adaptor,"rule plus_minus");
        RewriteRuleSubtreeStream stream_instance_expr=new RewriteRuleSubtreeStream(adaptor,"rule instance_expr");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1469:3: ( ( instance_expr -> instance_expr ) ( plus_minus -> ^( POSTFIX_EXPR instance_expr plus_minus ) )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1469:5: ( instance_expr -> instance_expr ) ( plus_minus -> ^( POSTFIX_EXPR instance_expr plus_minus ) )*
            {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1469:5: ( instance_expr -> instance_expr )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1469:6: instance_expr
            {
            pushFollow(FOLLOW_instance_expr_in_post_inc_dec_expr4460);
            instance_expr292=instance_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_instance_expr.add(instance_expr292.getTree());
            if ( state.backtracking==0 ) {

                  token = (CommonToken)(instance_expr292!=null?((Token)instance_expr292.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(instance_expr292!=null?((Token)instance_expr292.stop):null);
                  endIndex = token.getStopIndex();
                
            }


            // AST REWRITE
            // elements: instance_expr
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 1476:4: -> instance_expr
            {
                adaptor.addChild(root_0, stream_instance_expr.nextTree());

            }

            retval.tree = root_0;}
            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1477:3: ( plus_minus -> ^( POSTFIX_EXPR instance_expr plus_minus ) )*
            loop99:
            do {
                int alt99=2;
                int LA99_0 = input.LA(1);

                if ( ((LA99_0>=PLUS_PLUS_T && LA99_0<=MINUS_MINUS_T)) ) {
                    alt99=1;
                }


                switch (alt99) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1477:4: plus_minus
            	    {
            	    pushFollow(FOLLOW_plus_minus_in_post_inc_dec_expr4477);
            	    plus_minus293=plus_minus();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_plus_minus.add(plus_minus293.getTree());
            	    if ( state.backtracking==0 ) {

            	          token = (CommonToken)(instance_expr292!=null?((Token)instance_expr292.start):null);
            	          startIndex = token.getStartIndex();
            	          token = (CommonToken)(plus_minus293!=null?((Token)plus_minus293.stop):null);
            	          endIndex = token.getStopIndex();
            	        
            	    }


            	    // AST REWRITE
            	    // elements: instance_expr, plus_minus
            	    // token labels: 
            	    // rule labels: retval
            	    // token list labels: 
            	    // rule list labels: 
            	    // wildcard labels: 
            	    if ( state.backtracking==0 ) {
            	    retval.tree = root_0;
            	    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            	    root_0 = (SLAST)adaptor.nil();
            	    // 1484:4: -> ^( POSTFIX_EXPR instance_expr plus_minus )
            	    {
            	        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1484:7: ^( POSTFIX_EXPR instance_expr plus_minus )
            	        {
            	        SLAST root_1 = (SLAST)adaptor.nil();
            	        root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(POSTFIX_EXPR, "POSTFIX_EXPR"), root_1);

            	        adaptor.addChild(root_1, stream_instance_expr.nextTree());
            	        adaptor.addChild(root_1, stream_plus_minus.nextTree());

            	        adaptor.addChild(root_0, root_1);
            	        }

            	    }

            	    retval.tree = root_0;}
            	    }
            	    break;

            	default :
            	    break loop99;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);
                System.out.println("post " + startIndex + " " + endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "post_inc_dec_expr"

    public static class plus_minus_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "plus_minus"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1487:1: plus_minus : ( PLUS_PLUS_T | MINUS_MINUS_T );
    public final CompilerAstParser.plus_minus_return plus_minus() throws RecognitionException {
        CompilerAstParser.plus_minus_return retval = new CompilerAstParser.plus_minus_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token set294=null;

        SLAST set294_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1488:3: ( PLUS_PLUS_T | MINUS_MINUS_T )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:
            {
            root_0 = (SLAST)adaptor.nil();

            set294=(Token)input.LT(1);
            if ( (input.LA(1)>=PLUS_PLUS_T && input.LA(1)<=MINUS_MINUS_T) ) {
                input.consume();
                if ( state.backtracking==0 ) adaptor.addChild(root_0, (SLAST)adaptor.create(set294));
                state.errorRecovery=false;state.failed=false;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                MismatchedSetException mse = new MismatchedSetException(null,input);
                throw mse;
            }


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "plus_minus"

    public static class instance_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "instance_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1492:1: instance_expr : atom_expr ( INSTANCEOF_T class_name_reference )? ;
    public final CompilerAstParser.instance_expr_return instance_expr() throws RecognitionException {
        CompilerAstParser.instance_expr_return retval = new CompilerAstParser.instance_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token INSTANCEOF_T296=null;
        CompilerAstParser.atom_expr_return atom_expr295 = null;

        CompilerAstParser.class_name_reference_return class_name_reference297 = null;


        SLAST INSTANCEOF_T296_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1502:3: ( atom_expr ( INSTANCEOF_T class_name_reference )? )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1502:5: atom_expr ( INSTANCEOF_T class_name_reference )?
            {
            root_0 = (SLAST)adaptor.nil();

            pushFollow(FOLLOW_atom_expr_in_instance_expr4544);
            atom_expr295=atom_expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, atom_expr295.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1502:15: ( INSTANCEOF_T class_name_reference )?
            int alt100=2;
            int LA100_0 = input.LA(1);

            if ( (LA100_0==INSTANCEOF_T) ) {
                alt100=1;
            }
            switch (alt100) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1502:16: INSTANCEOF_T class_name_reference
                    {
                    INSTANCEOF_T296=(Token)match(input,INSTANCEOF_T,FOLLOW_INSTANCEOF_T_in_instance_expr4547); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    INSTANCEOF_T296_tree = (SLAST)adaptor.create(INSTANCEOF_T296);
                    root_0 = (SLAST)adaptor.becomeRoot(INSTANCEOF_T296_tree, root_0);
                    }
                    pushFollow(FOLLOW_class_name_reference_in_instance_expr4550);
                    class_name_reference297=class_name_reference();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, class_name_reference297.getTree());

                    }
                    break;

            }

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(atom_expr295!=null?((Token)atom_expr295.start):null);
                  startIndex = token.getStartIndex();    
                  token = (CommonToken)(atom_expr295!=null?((Token)atom_expr295.stop):null);
                  if ((class_name_reference297!=null?input.toString(class_name_reference297.start,class_name_reference297.stop):null) != null) {
                    token = (CommonToken)(class_name_reference297!=null?((Token)class_name_reference297.stop):null);
                  }
                  endIndex = token.getStopIndex();
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "instance_expr"

    public static class atom_expr_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "atom_expr"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1514:1: atom_expr : ( ( AT_T )? variable | ( AT_T )? scalar | LEFT_PARETHESIS expression RIGHT_PARETHESIS | LIST_T LEFT_PARETHESIS assignment_list RIGHT_PARETHESIS -> ^( LIST_T assignment_list ) | 'array' LEFT_PARETHESIS ( array_pair_list )? RIGHT_PARETHESIS -> ^( ARRAY_DECL ( array_pair_list )? ) | NEW_T class_name_reference -> ^( NEW_T class_name_reference ) | CLONE_T variable -> ^( CLONE_T variable ) | BACKTRICKLITERAL | PRINT_T expression -> ^( PRINT_T expression ) );
    public final CompilerAstParser.atom_expr_return atom_expr() throws RecognitionException {
        CompilerAstParser.atom_expr_return retval = new CompilerAstParser.atom_expr_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token AT_T298=null;
        Token AT_T300=null;
        Token LEFT_PARETHESIS302=null;
        Token RIGHT_PARETHESIS304=null;
        Token LIST_T305=null;
        Token LEFT_PARETHESIS306=null;
        Token RIGHT_PARETHESIS308=null;
        Token string_literal309=null;
        Token LEFT_PARETHESIS310=null;
        Token RIGHT_PARETHESIS312=null;
        Token NEW_T313=null;
        Token CLONE_T315=null;
        Token BACKTRICKLITERAL317=null;
        Token PRINT_T318=null;
        CompilerAstParser.variable_return variable299 = null;

        CompilerAstParser.scalar_return scalar301 = null;

        CompilerAstParser.expression_return expression303 = null;

        CompilerAstParser.assignment_list_return assignment_list307 = null;

        CompilerAstParser.array_pair_list_return array_pair_list311 = null;

        CompilerAstParser.class_name_reference_return class_name_reference314 = null;

        CompilerAstParser.variable_return variable316 = null;

        CompilerAstParser.expression_return expression319 = null;


        SLAST AT_T298_tree=null;
        SLAST AT_T300_tree=null;
        SLAST LEFT_PARETHESIS302_tree=null;
        SLAST RIGHT_PARETHESIS304_tree=null;
        SLAST LIST_T305_tree=null;
        SLAST LEFT_PARETHESIS306_tree=null;
        SLAST RIGHT_PARETHESIS308_tree=null;
        SLAST string_literal309_tree=null;
        SLAST LEFT_PARETHESIS310_tree=null;
        SLAST RIGHT_PARETHESIS312_tree=null;
        SLAST NEW_T313_tree=null;
        SLAST CLONE_T315_tree=null;
        SLAST BACKTRICKLITERAL317_tree=null;
        SLAST PRINT_T318_tree=null;
        RewriteRuleTokenStream stream_182=new RewriteRuleTokenStream(adaptor,"token 182");
        RewriteRuleTokenStream stream_LEFT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token LEFT_PARETHESIS");
        RewriteRuleTokenStream stream_PRINT_T=new RewriteRuleTokenStream(adaptor,"token PRINT_T");
        RewriteRuleTokenStream stream_LIST_T=new RewriteRuleTokenStream(adaptor,"token LIST_T");
        RewriteRuleTokenStream stream_NEW_T=new RewriteRuleTokenStream(adaptor,"token NEW_T");
        RewriteRuleTokenStream stream_CLONE_T=new RewriteRuleTokenStream(adaptor,"token CLONE_T");
        RewriteRuleTokenStream stream_RIGHT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token RIGHT_PARETHESIS");
        RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");
        RewriteRuleSubtreeStream stream_array_pair_list=new RewriteRuleSubtreeStream(adaptor,"rule array_pair_list");
        RewriteRuleSubtreeStream stream_class_name_reference=new RewriteRuleSubtreeStream(adaptor,"rule class_name_reference");
        RewriteRuleSubtreeStream stream_assignment_list=new RewriteRuleSubtreeStream(adaptor,"rule assignment_list");
        RewriteRuleSubtreeStream stream_variable=new RewriteRuleSubtreeStream(adaptor,"rule variable");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1524:3: ( ( AT_T )? variable | ( AT_T )? scalar | LEFT_PARETHESIS expression RIGHT_PARETHESIS | LIST_T LEFT_PARETHESIS assignment_list RIGHT_PARETHESIS -> ^( LIST_T assignment_list ) | 'array' LEFT_PARETHESIS ( array_pair_list )? RIGHT_PARETHESIS -> ^( ARRAY_DECL ( array_pair_list )? ) | NEW_T class_name_reference -> ^( NEW_T class_name_reference ) | CLONE_T variable -> ^( CLONE_T variable ) | BACKTRICKLITERAL | PRINT_T expression -> ^( PRINT_T expression ) )
            int alt104=9;
            alt104 = dfa104.predict(input);
            switch (alt104) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1524:6: ( AT_T )? variable
                    {
                    root_0 = (SLAST)adaptor.nil();

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1524:6: ( AT_T )?
                    int alt101=2;
                    int LA101_0 = input.LA(1);

                    if ( (LA101_0==AT_T) ) {
                        alt101=1;
                    }
                    switch (alt101) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1524:6: AT_T
                            {
                            AT_T298=(Token)match(input,AT_T,FOLLOW_AT_T_in_atom_expr4582); if (state.failed) return retval;
                            if ( state.backtracking==0 ) {
                            AT_T298_tree = (SLAST)adaptor.create(AT_T298);
                            adaptor.addChild(root_0, AT_T298_tree);
                            }

                            }
                            break;

                    }

                    pushFollow(FOLLOW_variable_in_atom_expr4585);
                    variable299=variable();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, variable299.getTree());
                    if ( state.backtracking==0 ) {

                            token = (CommonToken)(variable299!=null?((Token)variable299.start):null);
                            if ((AT_T298!=null?AT_T298.getText():null) != null) {
                              token = (CommonToken)AT_T298;
                            }
                            startIndex = token.getStartIndex();
                            token = (CommonToken)(variable299!=null?((Token)variable299.stop):null);
                            endIndex = token.getStopIndex();
                            System.out.println("i write here: " + startIndex + " " + endIndex);
                          
                    }

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1535:6: ( AT_T )? scalar
                    {
                    root_0 = (SLAST)adaptor.nil();

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1535:6: ( AT_T )?
                    int alt102=2;
                    int LA102_0 = input.LA(1);

                    if ( (LA102_0==AT_T) ) {
                        alt102=1;
                    }
                    switch (alt102) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1535:6: AT_T
                            {
                            AT_T300=(Token)match(input,AT_T,FOLLOW_AT_T_in_atom_expr4598); if (state.failed) return retval;
                            if ( state.backtracking==0 ) {
                            AT_T300_tree = (SLAST)adaptor.create(AT_T300);
                            adaptor.addChild(root_0, AT_T300_tree);
                            }

                            }
                            break;

                    }

                    pushFollow(FOLLOW_scalar_in_atom_expr4601);
                    scalar301=scalar();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, scalar301.getTree());
                    if ( state.backtracking==0 ) {

                            token = (CommonToken)(scalar301!=null?((Token)scalar301.start):null);
                            if ((AT_T300!=null?AT_T300.getText():null) != null) {
                              token = (CommonToken)AT_T300;
                            }
                            startIndex = token.getStartIndex();
                            token = (CommonToken)(scalar301!=null?((Token)scalar301.stop):null);
                            endIndex = token.getStopIndex();
                          
                    }

                    }
                    break;
                case 3 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1545:6: LEFT_PARETHESIS expression RIGHT_PARETHESIS
                    {
                    root_0 = (SLAST)adaptor.nil();

                    LEFT_PARETHESIS302=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_atom_expr4614); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    LEFT_PARETHESIS302_tree = (SLAST)adaptor.create(LEFT_PARETHESIS302);
                    adaptor.addChild(root_0, LEFT_PARETHESIS302_tree);
                    }
                    pushFollow(FOLLOW_expression_in_atom_expr4616);
                    expression303=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, expression303.getTree());
                    RIGHT_PARETHESIS304=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_atom_expr4618); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    RIGHT_PARETHESIS304_tree = (SLAST)adaptor.create(RIGHT_PARETHESIS304);
                    adaptor.addChild(root_0, RIGHT_PARETHESIS304_tree);
                    }
                    if ( state.backtracking==0 ) {

                            token = (CommonToken)LEFT_PARETHESIS302;
                            startIndex = token.getStartIndex();
                            token = (CommonToken)RIGHT_PARETHESIS304;
                            endIndex = token.getStopIndex();
                          
                    }

                    }
                    break;
                case 4 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1552:6: LIST_T LEFT_PARETHESIS assignment_list RIGHT_PARETHESIS
                    {
                    LIST_T305=(Token)match(input,LIST_T,FOLLOW_LIST_T_in_atom_expr4631); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LIST_T.add(LIST_T305);

                    LEFT_PARETHESIS306=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_atom_expr4633); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS306);

                    pushFollow(FOLLOW_assignment_list_in_atom_expr4635);
                    assignment_list307=assignment_list();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_assignment_list.add(assignment_list307.getTree());
                    RIGHT_PARETHESIS308=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_atom_expr4637); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS308);

                    if ( state.backtracking==0 ) {

                            token = (CommonToken)LIST_T305;
                            startIndex = token.getStartIndex();
                            token = (CommonToken)RIGHT_PARETHESIS308;
                            endIndex = token.getStopIndex();
                          
                    }


                    // AST REWRITE
                    // elements: LIST_T, assignment_list
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 1559:6: -> ^( LIST_T assignment_list )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1559:10: ^( LIST_T assignment_list )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_LIST_T.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_assignment_list.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 5 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1560:6: 'array' LEFT_PARETHESIS ( array_pair_list )? RIGHT_PARETHESIS
                    {
                    string_literal309=(Token)match(input,182,FOLLOW_182_in_atom_expr4664); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_182.add(string_literal309);

                    LEFT_PARETHESIS310=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_atom_expr4666); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS310);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1560:30: ( array_pair_list )?
                    int alt103=2;
                    int LA103_0 = input.LA(1);

                    if ( (LA103_0==LEFT_PARETHESIS||LA103_0==IDENTIFIER||LA103_0==REF_T||LA103_0==STRINGLITERAL||(LA103_0>=PLUS_T && LA103_0<=MINUS_T)||(LA103_0>=CLONE_T && LA103_0<=MINUS_MINUS_T)||(LA103_0>=AT_T && LA103_0<=PRINT_T)||(LA103_0>=DOLLAR_T && LA103_0<=DOUBLELITERRAL)||(LA103_0>=182 && LA103_0<=188)) ) {
                        alt103=1;
                    }
                    switch (alt103) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1560:30: array_pair_list
                            {
                            pushFollow(FOLLOW_array_pair_list_in_atom_expr4668);
                            array_pair_list311=array_pair_list();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_array_pair_list.add(array_pair_list311.getTree());

                            }
                            break;

                    }

                    RIGHT_PARETHESIS312=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_atom_expr4671); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS312);

                    if ( state.backtracking==0 ) {

                            token = (CommonToken)LEFT_PARETHESIS310;
                      	    startIndex = token.getStartIndex() - 5;
                      	    token = (CommonToken)RIGHT_PARETHESIS312;
                      	    endIndex = token.getStopIndex();
                          
                    }


                    // AST REWRITE
                    // elements: array_pair_list
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 1567:7: -> ^( ARRAY_DECL ( array_pair_list )? )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1567:11: ^( ARRAY_DECL ( array_pair_list )? )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(ARRAY_DECL, "ARRAY_DECL"), root_1);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1567:24: ( array_pair_list )?
                        if ( stream_array_pair_list.hasNext() ) {
                            adaptor.addChild(root_1, stream_array_pair_list.nextTree());

                        }
                        stream_array_pair_list.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 6 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1568:6: NEW_T class_name_reference
                    {
                    NEW_T313=(Token)match(input,NEW_T,FOLLOW_NEW_T_in_atom_expr4700); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_NEW_T.add(NEW_T313);

                    pushFollow(FOLLOW_class_name_reference_in_atom_expr4702);
                    class_name_reference314=class_name_reference();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_class_name_reference.add(class_name_reference314.getTree());
                    if ( state.backtracking==0 ) {

                            token = (CommonToken)NEW_T313;
                            startIndex = token.getStartIndex();
                            token = (CommonToken)(class_name_reference314!=null?((Token)class_name_reference314.stop):null);
                            endIndex = token.getStopIndex();
                          
                    }


                    // AST REWRITE
                    // elements: class_name_reference, NEW_T
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 1575:4: -> ^( NEW_T class_name_reference )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1575:8: ^( NEW_T class_name_reference )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_NEW_T.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_class_name_reference.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 7 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1576:6: CLONE_T variable
                    {
                    CLONE_T315=(Token)match(input,CLONE_T,FOLLOW_CLONE_T_in_atom_expr4729); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_CLONE_T.add(CLONE_T315);

                    pushFollow(FOLLOW_variable_in_atom_expr4731);
                    variable316=variable();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_variable.add(variable316.getTree());
                    if ( state.backtracking==0 ) {

                            token = (CommonToken)CLONE_T315;
                            startIndex = token.getStartIndex();
                            token = (CommonToken)(variable316!=null?((Token)variable316.stop):null);
                            endIndex = token.getStopIndex();
                          
                    }


                    // AST REWRITE
                    // elements: CLONE_T, variable
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 1583:4: -> ^( CLONE_T variable )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1583:8: ^( CLONE_T variable )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_CLONE_T.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_variable.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 8 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1595:6: BACKTRICKLITERAL
                    {
                    root_0 = (SLAST)adaptor.nil();

                    BACKTRICKLITERAL317=(Token)match(input,BACKTRICKLITERAL,FOLLOW_BACKTRICKLITERAL_in_atom_expr4767); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    BACKTRICKLITERAL317_tree = (SLAST)adaptor.create(BACKTRICKLITERAL317);
                    adaptor.addChild(root_0, BACKTRICKLITERAL317_tree);
                    }

                    }
                    break;
                case 9 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1596:6: PRINT_T expression
                    {
                    PRINT_T318=(Token)match(input,PRINT_T,FOLLOW_PRINT_T_in_atom_expr4774); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_PRINT_T.add(PRINT_T318);

                    pushFollow(FOLLOW_expression_in_atom_expr4776);
                    expression319=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_expression.add(expression319.getTree());
                    if ( state.backtracking==0 ) {

                            token = (CommonToken)PRINT_T318;
                            startIndex = token.getStartIndex();
                            if ((expression319!=null?input.toString(expression319.start,expression319.stop):null) != null) {
                              token = (CommonToken)(expression319!=null?((Token)expression319.stop):null);
                            }
                            endIndex = token.getStopIndex();
                          
                    }


                    // AST REWRITE
                    // elements: expression, PRINT_T
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 1605:4: -> ^( PRINT_T expression )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1605:7: ^( PRINT_T expression )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_PRINT_T.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_expression.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "atom_expr"

    public static class class_name_reference_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "class_name_reference"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1615:1: class_name_reference : ( dynamic_name_reference | fully_qualified_class_name );
    public final CompilerAstParser.class_name_reference_return class_name_reference() throws RecognitionException {
        CompilerAstParser.class_name_reference_return retval = new CompilerAstParser.class_name_reference_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        CompilerAstParser.dynamic_name_reference_return dynamic_name_reference320 = null;

        CompilerAstParser.fully_qualified_class_name_return fully_qualified_class_name321 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1616:3: ( dynamic_name_reference | fully_qualified_class_name )
            int alt105=2;
            alt105 = dfa105.predict(input);
            switch (alt105) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1616:5: dynamic_name_reference
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_dynamic_name_reference_in_class_name_reference4819);
                    dynamic_name_reference320=dynamic_name_reference();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, dynamic_name_reference320.getTree());

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1617:5: fully_qualified_class_name
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_fully_qualified_class_name_in_class_name_reference4825);
                    fully_qualified_class_name321=fully_qualified_class_name();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, fully_qualified_class_name321.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "class_name_reference"

    public static class dynamic_name_reference_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "dynamic_name_reference"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1620:1: dynamic_name_reference : ( base_variable_with_function_calls -> base_variable_with_function_calls ) ( SINGLE_ARROW_T object_property ( ctor_arguments )? -> ^( CALL $dynamic_name_reference object_property ( ctor_arguments )? ) )* ;
    public final CompilerAstParser.dynamic_name_reference_return dynamic_name_reference() throws RecognitionException {
        CompilerAstParser.dynamic_name_reference_return retval = new CompilerAstParser.dynamic_name_reference_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token SINGLE_ARROW_T323=null;
        CompilerAstParser.base_variable_with_function_calls_return base_variable_with_function_calls322 = null;

        CompilerAstParser.object_property_return object_property324 = null;

        CompilerAstParser.ctor_arguments_return ctor_arguments325 = null;


        SLAST SINGLE_ARROW_T323_tree=null;
        RewriteRuleTokenStream stream_SINGLE_ARROW_T=new RewriteRuleTokenStream(adaptor,"token SINGLE_ARROW_T");
        RewriteRuleSubtreeStream stream_ctor_arguments=new RewriteRuleSubtreeStream(adaptor,"rule ctor_arguments");
        RewriteRuleSubtreeStream stream_object_property=new RewriteRuleSubtreeStream(adaptor,"rule object_property");
        RewriteRuleSubtreeStream stream_base_variable_with_function_calls=new RewriteRuleSubtreeStream(adaptor,"rule base_variable_with_function_calls");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1630:3: ( ( base_variable_with_function_calls -> base_variable_with_function_calls ) ( SINGLE_ARROW_T object_property ( ctor_arguments )? -> ^( CALL $dynamic_name_reference object_property ( ctor_arguments )? ) )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1630:5: ( base_variable_with_function_calls -> base_variable_with_function_calls ) ( SINGLE_ARROW_T object_property ( ctor_arguments )? -> ^( CALL $dynamic_name_reference object_property ( ctor_arguments )? ) )*
            {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1630:5: ( base_variable_with_function_calls -> base_variable_with_function_calls )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1630:6: base_variable_with_function_calls
            {
            pushFollow(FOLLOW_base_variable_with_function_calls_in_dynamic_name_reference4853);
            base_variable_with_function_calls322=base_variable_with_function_calls();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_base_variable_with_function_calls.add(base_variable_with_function_calls322.getTree());
            if ( state.backtracking==0 ) {

                    token = (CommonToken)(base_variable_with_function_calls322!=null?((Token)base_variable_with_function_calls322.start):null);
                    startIndex = token.getStartIndex();
                    endIndex = token.getStopIndex();
                  
            }


            // AST REWRITE
            // elements: base_variable_with_function_calls
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 1636:7: -> base_variable_with_function_calls
            {
                adaptor.addChild(root_0, stream_base_variable_with_function_calls.nextTree());

            }

            retval.tree = root_0;}
            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1637:5: ( SINGLE_ARROW_T object_property ( ctor_arguments )? -> ^( CALL $dynamic_name_reference object_property ( ctor_arguments )? ) )*
            loop107:
            do {
                int alt107=2;
                int LA107_0 = input.LA(1);

                if ( (LA107_0==SINGLE_ARROW_T) ) {
                    alt107=1;
                }


                switch (alt107) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1637:6: SINGLE_ARROW_T object_property ( ctor_arguments )?
            	    {
            	    SINGLE_ARROW_T323=(Token)match(input,SINGLE_ARROW_T,FOLLOW_SINGLE_ARROW_T_in_dynamic_name_reference4878); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_SINGLE_ARROW_T.add(SINGLE_ARROW_T323);

            	    pushFollow(FOLLOW_object_property_in_dynamic_name_reference4880);
            	    object_property324=object_property();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_object_property.add(object_property324.getTree());
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1637:37: ( ctor_arguments )?
            	    int alt106=2;
            	    int LA106_0 = input.LA(1);

            	    if ( (LA106_0==LEFT_PARETHESIS) ) {
            	        alt106=1;
            	    }
            	    switch (alt106) {
            	        case 1 :
            	            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1637:37: ctor_arguments
            	            {
            	            pushFollow(FOLLOW_ctor_arguments_in_dynamic_name_reference4882);
            	            ctor_arguments325=ctor_arguments();

            	            state._fsp--;
            	            if (state.failed) return retval;
            	            if ( state.backtracking==0 ) stream_ctor_arguments.add(ctor_arguments325.getTree());

            	            }
            	            break;

            	    }

            	    if ( state.backtracking==0 ) {

            	            token = (CommonToken)(base_variable_with_function_calls322!=null?((Token)base_variable_with_function_calls322.start):null);
            	            startIndex = token.getStartIndex();
            	            token = (CommonToken)(object_property324!=null?((Token)object_property324.stop):null);
            	            endIndex = token.getStopIndex();
            	            if ((ctor_arguments325!=null?input.toString(ctor_arguments325.start,ctor_arguments325.stop):null) != null) {
            	              endIndex = ((CommonToken)(ctor_arguments325!=null?((Token)ctor_arguments325.stop):null)).getStopIndex();
            	            }
            	          
            	    }


            	    // AST REWRITE
            	    // elements: object_property, ctor_arguments, dynamic_name_reference
            	    // token labels: 
            	    // rule labels: retval
            	    // token list labels: 
            	    // rule list labels: 
            	    // wildcard labels: 
            	    if ( state.backtracking==0 ) {
            	    retval.tree = root_0;
            	    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            	    root_0 = (SLAST)adaptor.nil();
            	    // 1647:5: -> ^( CALL $dynamic_name_reference object_property ( ctor_arguments )? )
            	    {
            	        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1647:9: ^( CALL $dynamic_name_reference object_property ( ctor_arguments )? )
            	        {
            	        SLAST root_1 = (SLAST)adaptor.nil();
            	        root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(CALL, "CALL"), root_1);

            	        adaptor.addChild(root_1, stream_retval.nextTree());
            	        adaptor.addChild(root_1, stream_object_property.nextTree());
            	        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1647:56: ( ctor_arguments )?
            	        if ( stream_ctor_arguments.hasNext() ) {
            	            adaptor.addChild(root_1, stream_ctor_arguments.nextTree());

            	        }
            	        stream_ctor_arguments.reset();

            	        adaptor.addChild(root_0, root_1);
            	        }

            	    }

            	    retval.tree = root_0;}
            	    }
            	    break;

            	default :
            	    break loop107;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "dynamic_name_reference"

    public static class assignment_list_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "assignment_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1650:1: assignment_list : ( assignment_element )? ( COMMA_T ( assignment_element )? )* -> ( assignment_element )* ;
    public final CompilerAstParser.assignment_list_return assignment_list() throws RecognitionException {
        CompilerAstParser.assignment_list_return retval = new CompilerAstParser.assignment_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token COMMA_T327=null;
        CompilerAstParser.assignment_element_return assignment_element326 = null;

        CompilerAstParser.assignment_element_return assignment_element328 = null;


        SLAST COMMA_T327_tree=null;
        RewriteRuleTokenStream stream_COMMA_T=new RewriteRuleTokenStream(adaptor,"token COMMA_T");
        RewriteRuleSubtreeStream stream_assignment_element=new RewriteRuleSubtreeStream(adaptor,"rule assignment_element");
        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1651:3: ( ( assignment_element )? ( COMMA_T ( assignment_element )? )* -> ( assignment_element )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1651:5: ( assignment_element )? ( COMMA_T ( assignment_element )? )*
            {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1651:5: ( assignment_element )?
            int alt108=2;
            int LA108_0 = input.LA(1);

            if ( (LA108_0==IDENTIFIER||LA108_0==LIST_T||LA108_0==DOLLAR_T) ) {
                alt108=1;
            }
            switch (alt108) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1651:5: assignment_element
                    {
                    pushFollow(FOLLOW_assignment_element_in_assignment_list4933);
                    assignment_element326=assignment_element();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_assignment_element.add(assignment_element326.getTree());

                    }
                    break;

            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1651:25: ( COMMA_T ( assignment_element )? )*
            loop110:
            do {
                int alt110=2;
                int LA110_0 = input.LA(1);

                if ( (LA110_0==COMMA_T) ) {
                    alt110=1;
                }


                switch (alt110) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1651:26: COMMA_T ( assignment_element )?
            	    {
            	    COMMA_T327=(Token)match(input,COMMA_T,FOLLOW_COMMA_T_in_assignment_list4937); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_COMMA_T.add(COMMA_T327);

            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1651:34: ( assignment_element )?
            	    int alt109=2;
            	    int LA109_0 = input.LA(1);

            	    if ( (LA109_0==IDENTIFIER||LA109_0==LIST_T||LA109_0==DOLLAR_T) ) {
            	        alt109=1;
            	    }
            	    switch (alt109) {
            	        case 1 :
            	            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1651:34: assignment_element
            	            {
            	            pushFollow(FOLLOW_assignment_element_in_assignment_list4939);
            	            assignment_element328=assignment_element();

            	            state._fsp--;
            	            if (state.failed) return retval;
            	            if ( state.backtracking==0 ) stream_assignment_element.add(assignment_element328.getTree());

            	            }
            	            break;

            	    }


            	    }
            	    break;

            	default :
            	    break loop110;
                }
            } while (true);



            // AST REWRITE
            // elements: assignment_element
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 1651:57: -> ( assignment_element )*
            {
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1651:61: ( assignment_element )*
                while ( stream_assignment_element.hasNext() ) {
                    adaptor.addChild(root_0, stream_assignment_element.nextTree());

                }
                stream_assignment_element.reset();

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "assignment_list"

    public static class assignment_element_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "assignment_element"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1654:1: assignment_element : ( variable | LIST_T LEFT_PARETHESIS assignment_list RIGHT_PARETHESIS -> ^( LIST_T assignment_list ) );
    public final CompilerAstParser.assignment_element_return assignment_element() throws RecognitionException {
        CompilerAstParser.assignment_element_return retval = new CompilerAstParser.assignment_element_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token LIST_T330=null;
        Token LEFT_PARETHESIS331=null;
        Token RIGHT_PARETHESIS333=null;
        CompilerAstParser.variable_return variable329 = null;

        CompilerAstParser.assignment_list_return assignment_list332 = null;


        SLAST LIST_T330_tree=null;
        SLAST LEFT_PARETHESIS331_tree=null;
        SLAST RIGHT_PARETHESIS333_tree=null;
        RewriteRuleTokenStream stream_LEFT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token LEFT_PARETHESIS");
        RewriteRuleTokenStream stream_LIST_T=new RewriteRuleTokenStream(adaptor,"token LIST_T");
        RewriteRuleTokenStream stream_RIGHT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token RIGHT_PARETHESIS");
        RewriteRuleSubtreeStream stream_assignment_list=new RewriteRuleSubtreeStream(adaptor,"rule assignment_list");
        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1655:3: ( variable | LIST_T LEFT_PARETHESIS assignment_list RIGHT_PARETHESIS -> ^( LIST_T assignment_list ) )
            int alt111=2;
            int LA111_0 = input.LA(1);

            if ( (LA111_0==IDENTIFIER||LA111_0==DOLLAR_T) ) {
                alt111=1;
            }
            else if ( (LA111_0==LIST_T) ) {
                alt111=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 111, 0, input);

                throw nvae;
            }
            switch (alt111) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1655:5: variable
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_variable_in_assignment_element4963);
                    variable329=variable();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, variable329.getTree());

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1656:5: LIST_T LEFT_PARETHESIS assignment_list RIGHT_PARETHESIS
                    {
                    LIST_T330=(Token)match(input,LIST_T,FOLLOW_LIST_T_in_assignment_element4969); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LIST_T.add(LIST_T330);

                    LEFT_PARETHESIS331=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_assignment_element4971); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS331);

                    pushFollow(FOLLOW_assignment_list_in_assignment_element4973);
                    assignment_list332=assignment_list();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_assignment_list.add(assignment_list332.getTree());
                    RIGHT_PARETHESIS333=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_assignment_element4975); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS333);



                    // AST REWRITE
                    // elements: LIST_T, assignment_list
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 1656:62: -> ^( LIST_T assignment_list )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1656:66: ^( LIST_T assignment_list )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot(stream_LIST_T.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_assignment_list.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "assignment_element"

    public static class array_pair_list_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "array_pair_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1659:1: array_pair_list : e1= array_pair_element ( COMMA_T e2= array_pair_element )* ( COMMA_T )? -> ( array_pair_element )+ ;
    public final CompilerAstParser.array_pair_list_return array_pair_list() throws RecognitionException {
        CompilerAstParser.array_pair_list_return retval = new CompilerAstParser.array_pair_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token COMMA_T334=null;
        Token COMMA_T335=null;
        CompilerAstParser.array_pair_element_return e1 = null;

        CompilerAstParser.array_pair_element_return e2 = null;


        SLAST COMMA_T334_tree=null;
        SLAST COMMA_T335_tree=null;
        RewriteRuleTokenStream stream_COMMA_T=new RewriteRuleTokenStream(adaptor,"token COMMA_T");
        RewriteRuleSubtreeStream stream_array_pair_element=new RewriteRuleSubtreeStream(adaptor,"rule array_pair_element");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1669:3: (e1= array_pair_element ( COMMA_T e2= array_pair_element )* ( COMMA_T )? -> ( array_pair_element )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1669:5: e1= array_pair_element ( COMMA_T e2= array_pair_element )* ( COMMA_T )?
            {
            pushFollow(FOLLOW_array_pair_element_in_array_pair_list5012);
            e1=array_pair_element();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_array_pair_element.add(e1.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1669:27: ( COMMA_T e2= array_pair_element )*
            loop112:
            do {
                int alt112=2;
                int LA112_0 = input.LA(1);

                if ( (LA112_0==COMMA_T) ) {
                    int LA112_1 = input.LA(2);

                    if ( (LA112_1==LEFT_PARETHESIS||LA112_1==IDENTIFIER||LA112_1==REF_T||LA112_1==STRINGLITERAL||(LA112_1>=PLUS_T && LA112_1<=MINUS_T)||(LA112_1>=CLONE_T && LA112_1<=MINUS_MINUS_T)||(LA112_1>=AT_T && LA112_1<=PRINT_T)||(LA112_1>=DOLLAR_T && LA112_1<=DOUBLELITERRAL)||(LA112_1>=182 && LA112_1<=188)) ) {
                        alt112=1;
                    }


                }


                switch (alt112) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1669:28: COMMA_T e2= array_pair_element
            	    {
            	    COMMA_T334=(Token)match(input,COMMA_T,FOLLOW_COMMA_T_in_array_pair_list5015); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_COMMA_T.add(COMMA_T334);

            	    pushFollow(FOLLOW_array_pair_element_in_array_pair_list5019);
            	    e2=array_pair_element();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_array_pair_element.add(e2.getTree());

            	    }
            	    break;

            	default :
            	    break loop112;
                }
            } while (true);

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1669:60: ( COMMA_T )?
            int alt113=2;
            int LA113_0 = input.LA(1);

            if ( (LA113_0==COMMA_T) ) {
                alt113=1;
            }
            switch (alt113) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1669:60: COMMA_T
                    {
                    COMMA_T335=(Token)match(input,COMMA_T,FOLLOW_COMMA_T_in_array_pair_list5023); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_COMMA_T.add(COMMA_T335);


                    }
                    break;

            }

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(e1!=null?((Token)e1.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(e1!=null?((Token)e1.stop):null);
                  if ((e2!=null?input.toString(e2.start,e2.stop):null) != null) {
                    token = (CommonToken)(e2!=null?((Token)e2.stop):null);
                  }
                  endIndex = token.getStopIndex();
                
            }


            // AST REWRITE
            // elements: array_pair_element
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 1679:6: -> ( array_pair_element )+
            {
                if ( !(stream_array_pair_element.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_array_pair_element.hasNext() ) {
                    adaptor.addChild(root_0, stream_array_pair_element.nextTree());

                }
                stream_array_pair_element.reset();

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "array_pair_list"

    public static class array_pair_element_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "array_pair_element"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1682:1: array_pair_element : e1= expression ( ARROW_T e2= expression )? ;
    public final CompilerAstParser.array_pair_element_return array_pair_element() throws RecognitionException {
        CompilerAstParser.array_pair_element_return retval = new CompilerAstParser.array_pair_element_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token ARROW_T336=null;
        CompilerAstParser.expression_return e1 = null;

        CompilerAstParser.expression_return e2 = null;


        SLAST ARROW_T336_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1692:3: (e1= expression ( ARROW_T e2= expression )? )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1692:5: e1= expression ( ARROW_T e2= expression )?
            {
            root_0 = (SLAST)adaptor.nil();

            pushFollow(FOLLOW_expression_in_array_pair_element5068);
            e1=expression();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, e1.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1692:19: ( ARROW_T e2= expression )?
            int alt114=2;
            int LA114_0 = input.LA(1);

            if ( (LA114_0==ARROW_T) ) {
                alt114=1;
            }
            switch (alt114) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1692:20: ARROW_T e2= expression
                    {
                    ARROW_T336=(Token)match(input,ARROW_T,FOLLOW_ARROW_T_in_array_pair_element5071); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    ARROW_T336_tree = (SLAST)adaptor.create(ARROW_T336);
                    root_0 = (SLAST)adaptor.becomeRoot(ARROW_T336_tree, root_0);
                    }
                    pushFollow(FOLLOW_expression_in_array_pair_element5076);
                    e2=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, e2.getTree());

                    }
                    break;

            }

            if ( state.backtracking==0 ) {

                  token = (CommonToken)(e1!=null?((Token)e1.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(e1!=null?((Token)e1.stop):null);
                  if ((e2!=null?input.toString(e2.start,e2.stop):null) != null) {
                    token = (CommonToken)(e2!=null?((Token)e2.stop):null);
                  }
                  endIndex = token.getStopIndex();
                
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "array_pair_element"

    public static class variable_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "variable"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1704:1: variable : ( base_variable_with_function_calls -> base_variable_with_function_calls ) ( SINGLE_ARROW_T object_property ( ctor_arguments )? -> ^( CALL $variable object_property ( ctor_arguments )? ) )* ;
    public final CompilerAstParser.variable_return variable() throws RecognitionException {
        CompilerAstParser.variable_return retval = new CompilerAstParser.variable_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token SINGLE_ARROW_T338=null;
        CompilerAstParser.base_variable_with_function_calls_return base_variable_with_function_calls337 = null;

        CompilerAstParser.object_property_return object_property339 = null;

        CompilerAstParser.ctor_arguments_return ctor_arguments340 = null;


        SLAST SINGLE_ARROW_T338_tree=null;
        RewriteRuleTokenStream stream_SINGLE_ARROW_T=new RewriteRuleTokenStream(adaptor,"token SINGLE_ARROW_T");
        RewriteRuleSubtreeStream stream_ctor_arguments=new RewriteRuleSubtreeStream(adaptor,"rule ctor_arguments");
        RewriteRuleSubtreeStream stream_object_property=new RewriteRuleSubtreeStream(adaptor,"rule object_property");
        RewriteRuleSubtreeStream stream_base_variable_with_function_calls=new RewriteRuleSubtreeStream(adaptor,"rule base_variable_with_function_calls");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1715:3: ( ( base_variable_with_function_calls -> base_variable_with_function_calls ) ( SINGLE_ARROW_T object_property ( ctor_arguments )? -> ^( CALL $variable object_property ( ctor_arguments )? ) )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1715:5: ( base_variable_with_function_calls -> base_variable_with_function_calls ) ( SINGLE_ARROW_T object_property ( ctor_arguments )? -> ^( CALL $variable object_property ( ctor_arguments )? ) )*
            {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1715:5: ( base_variable_with_function_calls -> base_variable_with_function_calls )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1715:6: base_variable_with_function_calls
            {
            pushFollow(FOLLOW_base_variable_with_function_calls_in_variable5110);
            base_variable_with_function_calls337=base_variable_with_function_calls();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_base_variable_with_function_calls.add(base_variable_with_function_calls337.getTree());
            if ( state.backtracking==0 ) {

                    token = (CommonToken)(base_variable_with_function_calls337!=null?((Token)base_variable_with_function_calls337.start):null);
                    startIndex = token.getStartIndex();
                    endIndex = token.getStopIndex();
                  
            }


            // AST REWRITE
            // elements: base_variable_with_function_calls
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 1721:6: -> base_variable_with_function_calls
            {
                adaptor.addChild(root_0, stream_base_variable_with_function_calls.nextTree());

            }

            retval.tree = root_0;}
            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1722:5: ( SINGLE_ARROW_T object_property ( ctor_arguments )? -> ^( CALL $variable object_property ( ctor_arguments )? ) )*
            loop116:
            do {
                int alt116=2;
                int LA116_0 = input.LA(1);

                if ( (LA116_0==SINGLE_ARROW_T) ) {
                    alt116=1;
                }


                switch (alt116) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1722:6: SINGLE_ARROW_T object_property ( ctor_arguments )?
            	    {
            	    SINGLE_ARROW_T338=(Token)match(input,SINGLE_ARROW_T,FOLLOW_SINGLE_ARROW_T_in_variable5133); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_SINGLE_ARROW_T.add(SINGLE_ARROW_T338);

            	    pushFollow(FOLLOW_object_property_in_variable5135);
            	    object_property339=object_property();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_object_property.add(object_property339.getTree());
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1722:37: ( ctor_arguments )?
            	    int alt115=2;
            	    int LA115_0 = input.LA(1);

            	    if ( (LA115_0==LEFT_PARETHESIS) ) {
            	        alt115=1;
            	    }
            	    switch (alt115) {
            	        case 1 :
            	            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1722:37: ctor_arguments
            	            {
            	            pushFollow(FOLLOW_ctor_arguments_in_variable5137);
            	            ctor_arguments340=ctor_arguments();

            	            state._fsp--;
            	            if (state.failed) return retval;
            	            if ( state.backtracking==0 ) stream_ctor_arguments.add(ctor_arguments340.getTree());

            	            }
            	            break;

            	    }

            	    if ( state.backtracking==0 ) {

            	            token = (CommonToken)(base_variable_with_function_calls337!=null?((Token)base_variable_with_function_calls337.start):null);
            	            startIndex = token.getStartIndex();
            	            token = (CommonToken)(object_property339!=null?((Token)object_property339.stop):null);
            	            endIndex = token.getStopIndex();
            	            if ((ctor_arguments340!=null?input.toString(ctor_arguments340.start,ctor_arguments340.stop):null) != null) {
            	              endIndex = ((CommonToken)(ctor_arguments340!=null?((Token)ctor_arguments340.stop):null)).getStopIndex();
            	            }
            	          
            	    }


            	    // AST REWRITE
            	    // elements: object_property, ctor_arguments, variable
            	    // token labels: 
            	    // rule labels: retval
            	    // token list labels: 
            	    // rule list labels: 
            	    // wildcard labels: 
            	    if ( state.backtracking==0 ) {
            	    retval.tree = root_0;
            	    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            	    root_0 = (SLAST)adaptor.nil();
            	    // 1732:5: -> ^( CALL $variable object_property ( ctor_arguments )? )
            	    {
            	        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1732:9: ^( CALL $variable object_property ( ctor_arguments )? )
            	        {
            	        SLAST root_1 = (SLAST)adaptor.nil();
            	        root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(CALL, "CALL"), root_1);

            	        adaptor.addChild(root_1, stream_retval.nextTree());
            	        adaptor.addChild(root_1, stream_object_property.nextTree());
            	        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1732:42: ( ctor_arguments )?
            	        if ( stream_ctor_arguments.hasNext() ) {
            	            adaptor.addChild(root_1, stream_ctor_arguments.nextTree());

            	        }
            	        stream_ctor_arguments.reset();

            	        adaptor.addChild(root_0, root_1);
            	        }

            	    }

            	    retval.tree = root_0;}
            	    }
            	    break;

            	default :
            	    break loop116;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);
                System.out.println("variable:" + startIndex + " " + endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "variable"

    public static class base_variable_with_function_calls_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "base_variable_with_function_calls"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1735:1: base_variable_with_function_calls : ( ( fully_qualified_class_name )? reference_variable ( ctor_arguments )? -> ^( VAR_DECL ( fully_qualified_class_name )? reference_variable ( ctor_arguments )? ) | fully_qualified_class_name ctor_arguments -> ^( CALL fully_qualified_class_name ctor_arguments ) );
    public final CompilerAstParser.base_variable_with_function_calls_return base_variable_with_function_calls() throws RecognitionException {
        CompilerAstParser.base_variable_with_function_calls_return retval = new CompilerAstParser.base_variable_with_function_calls_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        CompilerAstParser.fully_qualified_class_name_return fully_qualified_class_name341 = null;

        CompilerAstParser.reference_variable_return reference_variable342 = null;

        CompilerAstParser.ctor_arguments_return ctor_arguments343 = null;

        CompilerAstParser.fully_qualified_class_name_return fully_qualified_class_name344 = null;

        CompilerAstParser.ctor_arguments_return ctor_arguments345 = null;


        RewriteRuleSubtreeStream stream_ctor_arguments=new RewriteRuleSubtreeStream(adaptor,"rule ctor_arguments");
        RewriteRuleSubtreeStream stream_fully_qualified_class_name=new RewriteRuleSubtreeStream(adaptor,"rule fully_qualified_class_name");
        RewriteRuleSubtreeStream stream_reference_variable=new RewriteRuleSubtreeStream(adaptor,"rule reference_variable");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1746:3: ( ( fully_qualified_class_name )? reference_variable ( ctor_arguments )? -> ^( VAR_DECL ( fully_qualified_class_name )? reference_variable ( ctor_arguments )? ) | fully_qualified_class_name ctor_arguments -> ^( CALL fully_qualified_class_name ctor_arguments ) )
            int alt119=2;
            alt119 = dfa119.predict(input);
            switch (alt119) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1746:5: ( fully_qualified_class_name )? reference_variable ( ctor_arguments )?
                    {
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1746:5: ( fully_qualified_class_name )?
                    int alt117=2;
                    int LA117_0 = input.LA(1);

                    if ( (LA117_0==IDENTIFIER) ) {
                        alt117=1;
                    }
                    switch (alt117) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1746:5: fully_qualified_class_name
                            {
                            pushFollow(FOLLOW_fully_qualified_class_name_in_base_variable_with_function_calls5194);
                            fully_qualified_class_name341=fully_qualified_class_name();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_fully_qualified_class_name.add(fully_qualified_class_name341.getTree());

                            }
                            break;

                    }

                    pushFollow(FOLLOW_reference_variable_in_base_variable_with_function_calls5197);
                    reference_variable342=reference_variable();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_reference_variable.add(reference_variable342.getTree());
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1746:52: ( ctor_arguments )?
                    int alt118=2;
                    int LA118_0 = input.LA(1);

                    if ( (LA118_0==LEFT_PARETHESIS) ) {
                        alt118=1;
                    }
                    switch (alt118) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1746:52: ctor_arguments
                            {
                            pushFollow(FOLLOW_ctor_arguments_in_base_variable_with_function_calls5199);
                            ctor_arguments343=ctor_arguments();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_ctor_arguments.add(ctor_arguments343.getTree());

                            }
                            break;

                    }

                    if ( state.backtracking==0 ) {

                            token = (CommonToken)(reference_variable342!=null?((Token)reference_variable342.start):null);
                            if ((fully_qualified_class_name341!=null?input.toString(fully_qualified_class_name341.start,fully_qualified_class_name341.stop):null) != null) {
                              token = (CommonToken)(fully_qualified_class_name341!=null?((Token)fully_qualified_class_name341.start):null);
                            }
                            startIndex = token.getStartIndex();
                            token = (CommonToken)(reference_variable342!=null?((Token)reference_variable342.stop):null);
                            if ((ctor_arguments343!=null?input.toString(ctor_arguments343.start,ctor_arguments343.stop):null) != null) {
                              token = (CommonToken)(ctor_arguments343!=null?((Token)ctor_arguments343.stop):null);
                            }
                            endIndex = token.getStopIndex();
                          
                    }


                    // AST REWRITE
                    // elements: fully_qualified_class_name, reference_variable, ctor_arguments
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 1759:7: -> ^( VAR_DECL ( fully_qualified_class_name )? reference_variable ( ctor_arguments )? )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1759:11: ^( VAR_DECL ( fully_qualified_class_name )? reference_variable ( ctor_arguments )? )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(VAR_DECL, "VAR_DECL"), root_1);

                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1759:22: ( fully_qualified_class_name )?
                        if ( stream_fully_qualified_class_name.hasNext() ) {
                            adaptor.addChild(root_1, stream_fully_qualified_class_name.nextTree());

                        }
                        stream_fully_qualified_class_name.reset();
                        adaptor.addChild(root_1, stream_reference_variable.nextTree());
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1759:69: ( ctor_arguments )?
                        if ( stream_ctor_arguments.hasNext() ) {
                            adaptor.addChild(root_1, stream_ctor_arguments.nextTree());

                        }
                        stream_ctor_arguments.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1760:5: fully_qualified_class_name ctor_arguments
                    {
                    pushFollow(FOLLOW_fully_qualified_class_name_in_base_variable_with_function_calls5233);
                    fully_qualified_class_name344=fully_qualified_class_name();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_fully_qualified_class_name.add(fully_qualified_class_name344.getTree());
                    pushFollow(FOLLOW_ctor_arguments_in_base_variable_with_function_calls5235);
                    ctor_arguments345=ctor_arguments();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_ctor_arguments.add(ctor_arguments345.getTree());
                    if ( state.backtracking==0 ) {

                            token = (CommonToken)(fully_qualified_class_name344!=null?((Token)fully_qualified_class_name344.start):null);
                            startIndex = token.getStartIndex();
                            token = (CommonToken)(ctor_arguments345!=null?((Token)ctor_arguments345.stop):null);
                            endIndex = token.getStopIndex();
                          
                    }


                    // AST REWRITE
                    // elements: ctor_arguments, fully_qualified_class_name
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (SLAST)adaptor.nil();
                    // 1767:7: -> ^( CALL fully_qualified_class_name ctor_arguments )
                    {
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1767:11: ^( CALL fully_qualified_class_name ctor_arguments )
                        {
                        SLAST root_1 = (SLAST)adaptor.nil();
                        root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(CALL, "CALL"), root_1);

                        adaptor.addChild(root_1, stream_fully_qualified_class_name.nextTree());
                        adaptor.addChild(root_1, stream_ctor_arguments.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);
                System.out.println("base var: " + startIndex + " " + endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "base_variable_with_function_calls"

    public static class object_property_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "object_property"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1772:1: object_property : ( reference_variable | reference_variable_without_dollar );
    public final CompilerAstParser.object_property_return object_property() throws RecognitionException {
        CompilerAstParser.object_property_return retval = new CompilerAstParser.object_property_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        CompilerAstParser.reference_variable_return reference_variable346 = null;

        CompilerAstParser.reference_variable_without_dollar_return reference_variable_without_dollar347 = null;




          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1783:3: ( reference_variable | reference_variable_without_dollar )
            int alt120=2;
            int LA120_0 = input.LA(1);

            if ( (LA120_0==DOLLAR_T) ) {
                alt120=1;
            }
            else if ( (LA120_0==IDENTIFIER||LA120_0==LEFT_BRACKET) ) {
                alt120=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 120, 0, input);

                throw nvae;
            }
            switch (alt120) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1783:5: reference_variable
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_reference_variable_in_object_property5288);
                    reference_variable346=reference_variable();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, reference_variable346.getTree());
                    if ( state.backtracking==0 ) {

                           token = (CommonToken)(reference_variable346!=null?((Token)reference_variable346.start):null);
                           startIndex = token.getStartIndex();
                           token = (CommonToken)(reference_variable346!=null?((Token)reference_variable346.stop):null);
                           endIndex = token.getStopIndex();
                        
                    }

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1790:5: reference_variable_without_dollar
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_reference_variable_without_dollar_in_object_property5298);
                    reference_variable_without_dollar347=reference_variable_without_dollar();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, reference_variable_without_dollar347.getTree());
                    if ( state.backtracking==0 ) {

                           token = (CommonToken)(reference_variable_without_dollar347!=null?((Token)reference_variable_without_dollar347.start):null);
                           startIndex = token.getStartIndex();
                           token = (CommonToken)(reference_variable_without_dollar347!=null?((Token)reference_variable_without_dollar347.stop):null);
                           endIndex = token.getStopIndex();
                        
                    }

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);
                System.out.println("obj: " + startIndex + " " + endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "object_property"

    public static class reference_variable_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "reference_variable"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1799:1: reference_variable : ( compound_variable -> ^( VAR compound_variable ) ) ( LEFT_OPEN_RECT (e= expression )? RIGHT_OPEN_RECT -> ^( INDEX $reference_variable ( $e)? ) | LEFT_BRACKET e= expression RIGHT_BRACKET -> ^( HASH_INDEX $reference_variable $e) )* ;
    public final CompilerAstParser.reference_variable_return reference_variable() throws RecognitionException {
        CompilerAstParser.reference_variable_return retval = new CompilerAstParser.reference_variable_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token LEFT_OPEN_RECT349=null;
        Token RIGHT_OPEN_RECT350=null;
        Token LEFT_BRACKET351=null;
        Token RIGHT_BRACKET352=null;
        CompilerAstParser.expression_return e = null;

        CompilerAstParser.compound_variable_return compound_variable348 = null;


        SLAST LEFT_OPEN_RECT349_tree=null;
        SLAST RIGHT_OPEN_RECT350_tree=null;
        SLAST LEFT_BRACKET351_tree=null;
        SLAST RIGHT_BRACKET352_tree=null;
        RewriteRuleTokenStream stream_RIGHT_OPEN_RECT=new RewriteRuleTokenStream(adaptor,"token RIGHT_OPEN_RECT");
        RewriteRuleTokenStream stream_LEFT_BRACKET=new RewriteRuleTokenStream(adaptor,"token LEFT_BRACKET");
        RewriteRuleTokenStream stream_LEFT_OPEN_RECT=new RewriteRuleTokenStream(adaptor,"token LEFT_OPEN_RECT");
        RewriteRuleTokenStream stream_RIGHT_BRACKET=new RewriteRuleTokenStream(adaptor,"token RIGHT_BRACKET");
        RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");
        RewriteRuleSubtreeStream stream_compound_variable=new RewriteRuleSubtreeStream(adaptor,"rule compound_variable");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;  

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1810:3: ( ( compound_variable -> ^( VAR compound_variable ) ) ( LEFT_OPEN_RECT (e= expression )? RIGHT_OPEN_RECT -> ^( INDEX $reference_variable ( $e)? ) | LEFT_BRACKET e= expression RIGHT_BRACKET -> ^( HASH_INDEX $reference_variable $e) )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1810:5: ( compound_variable -> ^( VAR compound_variable ) ) ( LEFT_OPEN_RECT (e= expression )? RIGHT_OPEN_RECT -> ^( INDEX $reference_variable ( $e)? ) | LEFT_BRACKET e= expression RIGHT_BRACKET -> ^( HASH_INDEX $reference_variable $e) )*
            {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1810:5: ( compound_variable -> ^( VAR compound_variable ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1810:6: compound_variable
            {
            pushFollow(FOLLOW_compound_variable_in_reference_variable5328);
            compound_variable348=compound_variable();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_compound_variable.add(compound_variable348.getTree());
            if ( state.backtracking==0 ) {

                  token = (CommonToken)(compound_variable348!=null?((Token)compound_variable348.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(compound_variable348!=null?((Token)compound_variable348.stop):null);
                  endIndex = token.getStopIndex();
                
            }


            // AST REWRITE
            // elements: compound_variable
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 1817:5: -> ^( VAR compound_variable )
            {
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1817:8: ^( VAR compound_variable )
                {
                SLAST root_1 = (SLAST)adaptor.nil();
                root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(VAR, "VAR"), root_1);

                adaptor.addChild(root_1, stream_compound_variable.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1818:3: ( LEFT_OPEN_RECT (e= expression )? RIGHT_OPEN_RECT -> ^( INDEX $reference_variable ( $e)? ) | LEFT_BRACKET e= expression RIGHT_BRACKET -> ^( HASH_INDEX $reference_variable $e) )*
            loop122:
            do {
                int alt122=3;
                int LA122_0 = input.LA(1);

                if ( (LA122_0==LEFT_OPEN_RECT) ) {
                    alt122=1;
                }
                else if ( (LA122_0==LEFT_BRACKET) ) {
                    alt122=2;
                }


                switch (alt122) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1819:3: LEFT_OPEN_RECT (e= expression )? RIGHT_OPEN_RECT
            	    {
            	    LEFT_OPEN_RECT349=(Token)match(input,LEFT_OPEN_RECT,FOLLOW_LEFT_OPEN_RECT_in_reference_variable5353); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_LEFT_OPEN_RECT.add(LEFT_OPEN_RECT349);

            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1819:19: (e= expression )?
            	    int alt121=2;
            	    int LA121_0 = input.LA(1);

            	    if ( (LA121_0==LEFT_PARETHESIS||LA121_0==IDENTIFIER||LA121_0==REF_T||LA121_0==STRINGLITERAL||(LA121_0>=PLUS_T && LA121_0<=MINUS_T)||(LA121_0>=CLONE_T && LA121_0<=MINUS_MINUS_T)||(LA121_0>=AT_T && LA121_0<=PRINT_T)||(LA121_0>=DOLLAR_T && LA121_0<=DOUBLELITERRAL)||(LA121_0>=182 && LA121_0<=188)) ) {
            	        alt121=1;
            	    }
            	    switch (alt121) {
            	        case 1 :
            	            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1819:19: e= expression
            	            {
            	            pushFollow(FOLLOW_expression_in_reference_variable5357);
            	            e=expression();

            	            state._fsp--;
            	            if (state.failed) return retval;
            	            if ( state.backtracking==0 ) stream_expression.add(e.getTree());

            	            }
            	            break;

            	    }

            	    RIGHT_OPEN_RECT350=(Token)match(input,RIGHT_OPEN_RECT,FOLLOW_RIGHT_OPEN_RECT_in_reference_variable5360); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_RIGHT_OPEN_RECT.add(RIGHT_OPEN_RECT350);

            	    if ( state.backtracking==0 ) {

            	          endIndex = ((CommonToken)RIGHT_OPEN_RECT350).getStopIndex();
            	        
            	    }


            	    // AST REWRITE
            	    // elements: e, reference_variable
            	    // token labels: 
            	    // rule labels: retval, e
            	    // token list labels: 
            	    // rule list labels: 
            	    // wildcard labels: 
            	    if ( state.backtracking==0 ) {
            	    retval.tree = root_0;
            	    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
            	    RewriteRuleSubtreeStream stream_e=new RewriteRuleSubtreeStream(adaptor,"rule e",e!=null?e.tree:null);

            	    root_0 = (SLAST)adaptor.nil();
            	    // 1823:5: -> ^( INDEX $reference_variable ( $e)? )
            	    {
            	        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1823:9: ^( INDEX $reference_variable ( $e)? )
            	        {
            	        SLAST root_1 = (SLAST)adaptor.nil();
            	        root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(INDEX, "INDEX"), root_1);

            	        adaptor.addChild(root_1, stream_retval.nextTree());
            	        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1823:37: ( $e)?
            	        if ( stream_e.hasNext() ) {
            	            adaptor.addChild(root_1, stream_e.nextTree());

            	        }
            	        stream_e.reset();

            	        adaptor.addChild(root_0, root_1);
            	        }

            	    }

            	    retval.tree = root_0;}
            	    }
            	    break;
            	case 2 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1825:3: LEFT_BRACKET e= expression RIGHT_BRACKET
            	    {
            	    LEFT_BRACKET351=(Token)match(input,LEFT_BRACKET,FOLLOW_LEFT_BRACKET_in_reference_variable5390); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_LEFT_BRACKET.add(LEFT_BRACKET351);

            	    pushFollow(FOLLOW_expression_in_reference_variable5394);
            	    e=expression();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_expression.add(e.getTree());
            	    RIGHT_BRACKET352=(Token)match(input,RIGHT_BRACKET,FOLLOW_RIGHT_BRACKET_in_reference_variable5396); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_RIGHT_BRACKET.add(RIGHT_BRACKET352);

            	    if ( state.backtracking==0 ) {

            	          endIndex = ((CommonToken)RIGHT_BRACKET352).getStopIndex();
            	        
            	    }


            	    // AST REWRITE
            	    // elements: reference_variable, e
            	    // token labels: 
            	    // rule labels: retval, e
            	    // token list labels: 
            	    // rule list labels: 
            	    // wildcard labels: 
            	    if ( state.backtracking==0 ) {
            	    retval.tree = root_0;
            	    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
            	    RewriteRuleSubtreeStream stream_e=new RewriteRuleSubtreeStream(adaptor,"rule e",e!=null?e.tree:null);

            	    root_0 = (SLAST)adaptor.nil();
            	    // 1829:5: -> ^( HASH_INDEX $reference_variable $e)
            	    {
            	        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1829:9: ^( HASH_INDEX $reference_variable $e)
            	        {
            	        SLAST root_1 = (SLAST)adaptor.nil();
            	        root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(HASH_INDEX, "HASH_INDEX"), root_1);

            	        adaptor.addChild(root_1, stream_retval.nextTree());
            	        adaptor.addChild(root_1, stream_e.nextTree());

            	        adaptor.addChild(root_0, root_1);
            	        }

            	    }

            	    retval.tree = root_0;}
            	    }
            	    break;

            	default :
            	    break loop122;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);
                System.out.println("ref:" + startIndex + " " + endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "reference_variable"

    public static class compound_variable_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "compound_variable"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1833:1: compound_variable : ( ( DOLLAR_T )+ IDENTIFIER | ( DOLLAR_T )+ LEFT_BRACKET expression RIGHT_BRACKET );
    public final CompilerAstParser.compound_variable_return compound_variable() throws RecognitionException {
        CompilerAstParser.compound_variable_return retval = new CompilerAstParser.compound_variable_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token DOLLAR_T353=null;
        Token IDENTIFIER354=null;
        Token DOLLAR_T355=null;
        Token LEFT_BRACKET356=null;
        Token RIGHT_BRACKET358=null;
        CompilerAstParser.expression_return expression357 = null;


        SLAST DOLLAR_T353_tree=null;
        SLAST IDENTIFIER354_tree=null;
        SLAST DOLLAR_T355_tree=null;
        SLAST LEFT_BRACKET356_tree=null;
        SLAST RIGHT_BRACKET358_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;  

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1844:3: ( ( DOLLAR_T )+ IDENTIFIER | ( DOLLAR_T )+ LEFT_BRACKET expression RIGHT_BRACKET )
            int alt125=2;
            alt125 = dfa125.predict(input);
            switch (alt125) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1844:5: ( DOLLAR_T )+ IDENTIFIER
                    {
                    root_0 = (SLAST)adaptor.nil();

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1844:5: ( DOLLAR_T )+
                    int cnt123=0;
                    loop123:
                    do {
                        int alt123=2;
                        int LA123_0 = input.LA(1);

                        if ( (LA123_0==DOLLAR_T) ) {
                            alt123=1;
                        }


                        switch (alt123) {
                    	case 1 :
                    	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1844:5: DOLLAR_T
                    	    {
                    	    DOLLAR_T353=(Token)match(input,DOLLAR_T,FOLLOW_DOLLAR_T_in_compound_variable5447); if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) {
                    	    DOLLAR_T353_tree = (SLAST)adaptor.create(DOLLAR_T353);
                    	    adaptor.addChild(root_0, DOLLAR_T353_tree);
                    	    }

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt123 >= 1 ) break loop123;
                    	    if (state.backtracking>0) {state.failed=true; return retval;}
                                EarlyExitException eee =
                                    new EarlyExitException(123, input);
                                throw eee;
                        }
                        cnt123++;
                    } while (true);

                    IDENTIFIER354=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_compound_variable5450); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    IDENTIFIER354_tree = (SLAST)adaptor.create(IDENTIFIER354);
                    adaptor.addChild(root_0, IDENTIFIER354_tree);
                    }
                    if ( state.backtracking==0 ) {

                           token = (CommonToken)DOLLAR_T353;
                           startIndex = token.getStartIndex();
                           token = (CommonToken)IDENTIFIER354;
                           endIndex = token.getStopIndex();
                         
                    }

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1851:5: ( DOLLAR_T )+ LEFT_BRACKET expression RIGHT_BRACKET
                    {
                    root_0 = (SLAST)adaptor.nil();

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1851:5: ( DOLLAR_T )+
                    int cnt124=0;
                    loop124:
                    do {
                        int alt124=2;
                        int LA124_0 = input.LA(1);

                        if ( (LA124_0==DOLLAR_T) ) {
                            alt124=1;
                        }


                        switch (alt124) {
                    	case 1 :
                    	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1851:5: DOLLAR_T
                    	    {
                    	    DOLLAR_T355=(Token)match(input,DOLLAR_T,FOLLOW_DOLLAR_T_in_compound_variable5462); if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) {
                    	    DOLLAR_T355_tree = (SLAST)adaptor.create(DOLLAR_T355);
                    	    adaptor.addChild(root_0, DOLLAR_T355_tree);
                    	    }

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt124 >= 1 ) break loop124;
                    	    if (state.backtracking>0) {state.failed=true; return retval;}
                                EarlyExitException eee =
                                    new EarlyExitException(124, input);
                                throw eee;
                        }
                        cnt124++;
                    } while (true);

                    LEFT_BRACKET356=(Token)match(input,LEFT_BRACKET,FOLLOW_LEFT_BRACKET_in_compound_variable5465); if (state.failed) return retval;
                    pushFollow(FOLLOW_expression_in_compound_variable5468);
                    expression357=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, expression357.getTree());
                    RIGHT_BRACKET358=(Token)match(input,RIGHT_BRACKET,FOLLOW_RIGHT_BRACKET_in_compound_variable5470); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {

                           token = (CommonToken)DOLLAR_T355;
                           startIndex = token.getStartIndex();
                           token = (CommonToken)RIGHT_BRACKET358;
                           endIndex = token.getStopIndex();
                         
                    }

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);
                System.out.println("com:" + startIndex + " " + endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "compound_variable"

    public static class reference_variable_without_dollar_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "reference_variable_without_dollar"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1860:1: reference_variable_without_dollar : ( compound_variable_without_dollar -> ^( VAR compound_variable_without_dollar ) ) ( LEFT_OPEN_RECT ( expression )? RIGHT_OPEN_RECT -> ^( INDEX $reference_variable_without_dollar ( expression )? ) | LEFT_BRACKET expression RIGHT_BRACKET -> ^( HASH_INDEX $reference_variable_without_dollar expression ) )* ;
    public final CompilerAstParser.reference_variable_without_dollar_return reference_variable_without_dollar() throws RecognitionException {
        CompilerAstParser.reference_variable_without_dollar_return retval = new CompilerAstParser.reference_variable_without_dollar_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token LEFT_OPEN_RECT360=null;
        Token RIGHT_OPEN_RECT362=null;
        Token LEFT_BRACKET363=null;
        Token RIGHT_BRACKET365=null;
        CompilerAstParser.compound_variable_without_dollar_return compound_variable_without_dollar359 = null;

        CompilerAstParser.expression_return expression361 = null;

        CompilerAstParser.expression_return expression364 = null;


        SLAST LEFT_OPEN_RECT360_tree=null;
        SLAST RIGHT_OPEN_RECT362_tree=null;
        SLAST LEFT_BRACKET363_tree=null;
        SLAST RIGHT_BRACKET365_tree=null;
        RewriteRuleTokenStream stream_RIGHT_OPEN_RECT=new RewriteRuleTokenStream(adaptor,"token RIGHT_OPEN_RECT");
        RewriteRuleTokenStream stream_LEFT_BRACKET=new RewriteRuleTokenStream(adaptor,"token LEFT_BRACKET");
        RewriteRuleTokenStream stream_LEFT_OPEN_RECT=new RewriteRuleTokenStream(adaptor,"token LEFT_OPEN_RECT");
        RewriteRuleTokenStream stream_RIGHT_BRACKET=new RewriteRuleTokenStream(adaptor,"token RIGHT_BRACKET");
        RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");
        RewriteRuleSubtreeStream stream_compound_variable_without_dollar=new RewriteRuleSubtreeStream(adaptor,"rule compound_variable_without_dollar");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;  

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1870:3: ( ( compound_variable_without_dollar -> ^( VAR compound_variable_without_dollar ) ) ( LEFT_OPEN_RECT ( expression )? RIGHT_OPEN_RECT -> ^( INDEX $reference_variable_without_dollar ( expression )? ) | LEFT_BRACKET expression RIGHT_BRACKET -> ^( HASH_INDEX $reference_variable_without_dollar expression ) )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1870:5: ( compound_variable_without_dollar -> ^( VAR compound_variable_without_dollar ) ) ( LEFT_OPEN_RECT ( expression )? RIGHT_OPEN_RECT -> ^( INDEX $reference_variable_without_dollar ( expression )? ) | LEFT_BRACKET expression RIGHT_BRACKET -> ^( HASH_INDEX $reference_variable_without_dollar expression ) )*
            {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1870:5: ( compound_variable_without_dollar -> ^( VAR compound_variable_without_dollar ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1870:6: compound_variable_without_dollar
            {
            pushFollow(FOLLOW_compound_variable_without_dollar_in_reference_variable_without_dollar5503);
            compound_variable_without_dollar359=compound_variable_without_dollar();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_compound_variable_without_dollar.add(compound_variable_without_dollar359.getTree());
            if ( state.backtracking==0 ) {

                  token = (CommonToken)(compound_variable_without_dollar359!=null?((Token)compound_variable_without_dollar359.start):null);
                  startIndex = token.getStartIndex();
                  endIndex = token.getStopIndex();
                
            }


            // AST REWRITE
            // elements: compound_variable_without_dollar
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 1876:6: -> ^( VAR compound_variable_without_dollar )
            {
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1876:10: ^( VAR compound_variable_without_dollar )
                {
                SLAST root_1 = (SLAST)adaptor.nil();
                root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(VAR, "VAR"), root_1);

                adaptor.addChild(root_1, stream_compound_variable_without_dollar.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1877:3: ( LEFT_OPEN_RECT ( expression )? RIGHT_OPEN_RECT -> ^( INDEX $reference_variable_without_dollar ( expression )? ) | LEFT_BRACKET expression RIGHT_BRACKET -> ^( HASH_INDEX $reference_variable_without_dollar expression ) )*
            loop127:
            do {
                int alt127=3;
                int LA127_0 = input.LA(1);

                if ( (LA127_0==LEFT_OPEN_RECT) ) {
                    alt127=1;
                }
                else if ( (LA127_0==LEFT_BRACKET) ) {
                    alt127=2;
                }


                switch (alt127) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1878:3: LEFT_OPEN_RECT ( expression )? RIGHT_OPEN_RECT
            	    {
            	    LEFT_OPEN_RECT360=(Token)match(input,LEFT_OPEN_RECT,FOLLOW_LEFT_OPEN_RECT_in_reference_variable_without_dollar5532); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_LEFT_OPEN_RECT.add(LEFT_OPEN_RECT360);

            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1878:18: ( expression )?
            	    int alt126=2;
            	    int LA126_0 = input.LA(1);

            	    if ( (LA126_0==LEFT_PARETHESIS||LA126_0==IDENTIFIER||LA126_0==REF_T||LA126_0==STRINGLITERAL||(LA126_0>=PLUS_T && LA126_0<=MINUS_T)||(LA126_0>=CLONE_T && LA126_0<=MINUS_MINUS_T)||(LA126_0>=AT_T && LA126_0<=PRINT_T)||(LA126_0>=DOLLAR_T && LA126_0<=DOUBLELITERRAL)||(LA126_0>=182 && LA126_0<=188)) ) {
            	        alt126=1;
            	    }
            	    switch (alt126) {
            	        case 1 :
            	            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1878:18: expression
            	            {
            	            pushFollow(FOLLOW_expression_in_reference_variable_without_dollar5534);
            	            expression361=expression();

            	            state._fsp--;
            	            if (state.failed) return retval;
            	            if ( state.backtracking==0 ) stream_expression.add(expression361.getTree());

            	            }
            	            break;

            	    }

            	    RIGHT_OPEN_RECT362=(Token)match(input,RIGHT_OPEN_RECT,FOLLOW_RIGHT_OPEN_RECT_in_reference_variable_without_dollar5537); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_RIGHT_OPEN_RECT.add(RIGHT_OPEN_RECT362);

            	    if ( state.backtracking==0 ) {

            	          endIndex = ((CommonToken)RIGHT_OPEN_RECT362).getStopIndex();
            	        
            	    }


            	    // AST REWRITE
            	    // elements: reference_variable_without_dollar, expression
            	    // token labels: 
            	    // rule labels: retval
            	    // token list labels: 
            	    // rule list labels: 
            	    // wildcard labels: 
            	    if ( state.backtracking==0 ) {
            	    retval.tree = root_0;
            	    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            	    root_0 = (SLAST)adaptor.nil();
            	    // 1882:6: -> ^( INDEX $reference_variable_without_dollar ( expression )? )
            	    {
            	        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1882:10: ^( INDEX $reference_variable_without_dollar ( expression )? )
            	        {
            	        SLAST root_1 = (SLAST)adaptor.nil();
            	        root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(INDEX, "INDEX"), root_1);

            	        adaptor.addChild(root_1, stream_retval.nextTree());
            	        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1882:53: ( expression )?
            	        if ( stream_expression.hasNext() ) {
            	            adaptor.addChild(root_1, stream_expression.nextTree());

            	        }
            	        stream_expression.reset();

            	        adaptor.addChild(root_0, root_1);
            	        }

            	    }

            	    retval.tree = root_0;}
            	    }
            	    break;
            	case 2 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1884:3: LEFT_BRACKET expression RIGHT_BRACKET
            	    {
            	    LEFT_BRACKET363=(Token)match(input,LEFT_BRACKET,FOLLOW_LEFT_BRACKET_in_reference_variable_without_dollar5568); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_LEFT_BRACKET.add(LEFT_BRACKET363);

            	    pushFollow(FOLLOW_expression_in_reference_variable_without_dollar5570);
            	    expression364=expression();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_expression.add(expression364.getTree());
            	    RIGHT_BRACKET365=(Token)match(input,RIGHT_BRACKET,FOLLOW_RIGHT_BRACKET_in_reference_variable_without_dollar5572); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_RIGHT_BRACKET.add(RIGHT_BRACKET365);

            	    if ( state.backtracking==0 ) {

            	          endIndex = ((CommonToken)RIGHT_BRACKET365).getStopIndex();
            	        
            	    }


            	    // AST REWRITE
            	    // elements: expression, reference_variable_without_dollar
            	    // token labels: 
            	    // rule labels: retval
            	    // token list labels: 
            	    // rule list labels: 
            	    // wildcard labels: 
            	    if ( state.backtracking==0 ) {
            	    retval.tree = root_0;
            	    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            	    root_0 = (SLAST)adaptor.nil();
            	    // 1888:6: -> ^( HASH_INDEX $reference_variable_without_dollar expression )
            	    {
            	        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1888:10: ^( HASH_INDEX $reference_variable_without_dollar expression )
            	        {
            	        SLAST root_1 = (SLAST)adaptor.nil();
            	        root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(HASH_INDEX, "HASH_INDEX"), root_1);

            	        adaptor.addChild(root_1, stream_retval.nextTree());
            	        adaptor.addChild(root_1, stream_expression.nextTree());

            	        adaptor.addChild(root_0, root_1);
            	        }

            	    }

            	    retval.tree = root_0;}
            	    }
            	    break;

            	default :
            	    break loop127;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "reference_variable_without_dollar"

    public static class compound_variable_without_dollar_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "compound_variable_without_dollar"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1892:1: compound_variable_without_dollar : ( IDENTIFIER | LEFT_BRACKET expression RIGHT_BRACKET );
    public final CompilerAstParser.compound_variable_without_dollar_return compound_variable_without_dollar() throws RecognitionException {
        CompilerAstParser.compound_variable_without_dollar_return retval = new CompilerAstParser.compound_variable_without_dollar_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token IDENTIFIER366=null;
        Token LEFT_BRACKET367=null;
        Token RIGHT_BRACKET369=null;
        CompilerAstParser.expression_return expression368 = null;


        SLAST IDENTIFIER366_tree=null;
        SLAST LEFT_BRACKET367_tree=null;
        SLAST RIGHT_BRACKET369_tree=null;


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;  

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1903:3: ( IDENTIFIER | LEFT_BRACKET expression RIGHT_BRACKET )
            int alt128=2;
            int LA128_0 = input.LA(1);

            if ( (LA128_0==IDENTIFIER) ) {
                alt128=1;
            }
            else if ( (LA128_0==LEFT_BRACKET) ) {
                alt128=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 128, 0, input);

                throw nvae;
            }
            switch (alt128) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1903:5: IDENTIFIER
                    {
                    root_0 = (SLAST)adaptor.nil();

                    IDENTIFIER366=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_compound_variable_without_dollar5622); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    IDENTIFIER366_tree = (SLAST)adaptor.create(IDENTIFIER366);
                    adaptor.addChild(root_0, IDENTIFIER366_tree);
                    }
                    if ( state.backtracking==0 ) {

                           token = (CommonToken)IDENTIFIER366;
                           startIndex = token.getStartIndex();
                           endIndex = token.getStopIndex();
                        
                    }

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1909:5: LEFT_BRACKET expression RIGHT_BRACKET
                    {
                    root_0 = (SLAST)adaptor.nil();

                    LEFT_BRACKET367=(Token)match(input,LEFT_BRACKET,FOLLOW_LEFT_BRACKET_in_compound_variable_without_dollar5632); if (state.failed) return retval;
                    pushFollow(FOLLOW_expression_in_compound_variable_without_dollar5635);
                    expression368=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, expression368.getTree());
                    RIGHT_BRACKET369=(Token)match(input,RIGHT_BRACKET,FOLLOW_RIGHT_BRACKET_in_compound_variable_without_dollar5637); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {

                           token = (CommonToken)LEFT_BRACKET367;
                           startIndex = token.getStartIndex();
                           token = (CommonToken)RIGHT_BRACKET369;
                           endIndex = token.getStopIndex();
                        
                    }

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);
                System.out.println("com:" + startIndex + " " + endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "compound_variable_without_dollar"

    public static class ctor_arguments_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "ctor_arguments"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1918:1: ctor_arguments : LEFT_PARETHESIS ( expr_list )? RIGHT_PARETHESIS -> ^( ARGU ( expr_list )? ) ;
    public final CompilerAstParser.ctor_arguments_return ctor_arguments() throws RecognitionException {
        CompilerAstParser.ctor_arguments_return retval = new CompilerAstParser.ctor_arguments_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token LEFT_PARETHESIS370=null;
        Token RIGHT_PARETHESIS372=null;
        CompilerAstParser.expr_list_return expr_list371 = null;


        SLAST LEFT_PARETHESIS370_tree=null;
        SLAST RIGHT_PARETHESIS372_tree=null;
        RewriteRuleTokenStream stream_LEFT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token LEFT_PARETHESIS");
        RewriteRuleTokenStream stream_RIGHT_PARETHESIS=new RewriteRuleTokenStream(adaptor,"token RIGHT_PARETHESIS");
        RewriteRuleSubtreeStream stream_expr_list=new RewriteRuleSubtreeStream(adaptor,"rule expr_list");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1928:3: ( LEFT_PARETHESIS ( expr_list )? RIGHT_PARETHESIS -> ^( ARGU ( expr_list )? ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1928:6: LEFT_PARETHESIS ( expr_list )? RIGHT_PARETHESIS
            {
            LEFT_PARETHESIS370=(Token)match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_ctor_arguments5668); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_LEFT_PARETHESIS.add(LEFT_PARETHESIS370);

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1928:22: ( expr_list )?
            int alt129=2;
            int LA129_0 = input.LA(1);

            if ( (LA129_0==LEFT_PARETHESIS||LA129_0==IDENTIFIER||LA129_0==REF_T||LA129_0==STRINGLITERAL||(LA129_0>=PLUS_T && LA129_0<=MINUS_T)||(LA129_0>=CLONE_T && LA129_0<=MINUS_MINUS_T)||(LA129_0>=AT_T && LA129_0<=PRINT_T)||(LA129_0>=DOLLAR_T && LA129_0<=DOUBLELITERRAL)||(LA129_0>=182 && LA129_0<=188)) ) {
                alt129=1;
            }
            switch (alt129) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1928:22: expr_list
                    {
                    pushFollow(FOLLOW_expr_list_in_ctor_arguments5670);
                    expr_list371=expr_list();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_expr_list.add(expr_list371.getTree());

                    }
                    break;

            }

            RIGHT_PARETHESIS372=(Token)match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_ctor_arguments5673); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_RIGHT_PARETHESIS.add(RIGHT_PARETHESIS372);

            if ( state.backtracking==0 ) {

                    token = (CommonToken)LEFT_PARETHESIS370;
                    startIndex = token.getStartIndex();
                    token = (CommonToken)RIGHT_PARETHESIS372;
                    endIndex = token.getStopIndex();
                  
            }


            // AST REWRITE
            // elements: expr_list
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 1935:6: -> ^( ARGU ( expr_list )? )
            {
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1935:10: ^( ARGU ( expr_list )? )
                {
                SLAST root_1 = (SLAST)adaptor.nil();
                root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(ARGU, "ARGU"), root_1);

                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1935:17: ( expr_list )?
                if ( stream_expr_list.hasNext() ) {
                    adaptor.addChild(root_1, stream_expr_list.nextTree());

                }
                stream_expr_list.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "ctor_arguments"

    public static class pure_variable_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "pure_variable"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1938:1: pure_variable : ( REF_T )? ( DOLLAR_T )+ IDENTIFIER -> ^( VAR_DECL ( REF_T )? ( DOLLAR_T )+ IDENTIFIER ) ;
    public final CompilerAstParser.pure_variable_return pure_variable() throws RecognitionException {
        CompilerAstParser.pure_variable_return retval = new CompilerAstParser.pure_variable_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token REF_T373=null;
        Token DOLLAR_T374=null;
        Token IDENTIFIER375=null;

        SLAST REF_T373_tree=null;
        SLAST DOLLAR_T374_tree=null;
        SLAST IDENTIFIER375_tree=null;
        RewriteRuleTokenStream stream_REF_T=new RewriteRuleTokenStream(adaptor,"token REF_T");
        RewriteRuleTokenStream stream_IDENTIFIER=new RewriteRuleTokenStream(adaptor,"token IDENTIFIER");
        RewriteRuleTokenStream stream_DOLLAR_T=new RewriteRuleTokenStream(adaptor,"token DOLLAR_T");


          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1948:3: ( ( REF_T )? ( DOLLAR_T )+ IDENTIFIER -> ^( VAR_DECL ( REF_T )? ( DOLLAR_T )+ IDENTIFIER ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1948:5: ( REF_T )? ( DOLLAR_T )+ IDENTIFIER
            {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1948:5: ( REF_T )?
            int alt130=2;
            int LA130_0 = input.LA(1);

            if ( (LA130_0==REF_T) ) {
                alt130=1;
            }
            switch (alt130) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1948:5: REF_T
                    {
                    REF_T373=(Token)match(input,REF_T,FOLLOW_REF_T_in_pure_variable5719); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_REF_T.add(REF_T373);


                    }
                    break;

            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1948:12: ( DOLLAR_T )+
            int cnt131=0;
            loop131:
            do {
                int alt131=2;
                int LA131_0 = input.LA(1);

                if ( (LA131_0==DOLLAR_T) ) {
                    alt131=1;
                }


                switch (alt131) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1948:12: DOLLAR_T
            	    {
            	    DOLLAR_T374=(Token)match(input,DOLLAR_T,FOLLOW_DOLLAR_T_in_pure_variable5722); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_DOLLAR_T.add(DOLLAR_T374);


            	    }
            	    break;

            	default :
            	    if ( cnt131 >= 1 ) break loop131;
            	    if (state.backtracking>0) {state.failed=true; return retval;}
                        EarlyExitException eee =
                            new EarlyExitException(131, input);
                        throw eee;
                }
                cnt131++;
            } while (true);

            IDENTIFIER375=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_pure_variable5725); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER375);

            if ( state.backtracking==0 ) {

                    token = (CommonToken)DOLLAR_T374;
                    if ((REF_T373!=null?REF_T373.getText():null) != null) {
                      token = (CommonToken)REF_T373;
                    }
                    startIndex = token.getStartIndex();
                    token = (CommonToken)IDENTIFIER375;
                    endIndex = token.getStopIndex();
                  
            }


            // AST REWRITE
            // elements: REF_T, IDENTIFIER, DOLLAR_T
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 1958:5: -> ^( VAR_DECL ( REF_T )? ( DOLLAR_T )+ IDENTIFIER )
            {
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1958:9: ^( VAR_DECL ( REF_T )? ( DOLLAR_T )+ IDENTIFIER )
                {
                SLAST root_1 = (SLAST)adaptor.nil();
                root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(VAR_DECL, "VAR_DECL"), root_1);

                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1958:20: ( REF_T )?
                if ( stream_REF_T.hasNext() ) {
                    adaptor.addChild(root_1, stream_REF_T.nextNode());

                }
                stream_REF_T.reset();
                if ( !(stream_DOLLAR_T.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_DOLLAR_T.hasNext() ) {
                    adaptor.addChild(root_1, stream_DOLLAR_T.nextNode());

                }
                stream_DOLLAR_T.reset();
                adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST ast = retval.tree;
                ast.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "pure_variable"

    public static class scalar_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "scalar"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1961:1: scalar : constant -> ^( SCALAR constant ) ;
    public final CompilerAstParser.scalar_return scalar() throws RecognitionException {
        CompilerAstParser.scalar_return retval = new CompilerAstParser.scalar_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        CompilerAstParser.constant_return constant376 = null;


        RewriteRuleSubtreeStream stream_constant=new RewriteRuleSubtreeStream(adaptor,"rule constant");

          int startIndex = -1;
          int endIndex = -1;
          CommonToken token;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1971:3: ( constant -> ^( SCALAR constant ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1971:5: constant
            {
            pushFollow(FOLLOW_constant_in_scalar5777);
            constant376=constant();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_constant.add(constant376.getTree());
            if ( state.backtracking==0 ) {

                  token = (CommonToken)(constant376!=null?((Token)constant376.start):null);
                  startIndex = token.getStartIndex();
                  token = (CommonToken)(constant376!=null?((Token)constant376.stop):null);
                  endIndex = token.getStopIndex();
                
            }


            // AST REWRITE
            // elements: constant
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (SLAST)adaptor.nil();
            // 1978:5: -> ^( SCALAR constant )
            {
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1978:9: ^( SCALAR constant )
                {
                SLAST root_1 = (SLAST)adaptor.nil();
                root_1 = (SLAST)adaptor.becomeRoot((SLAST)adaptor.create(SCALAR, "SCALAR"), root_1);

                adaptor.addChild(root_1, stream_constant.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
            if ( state.backtracking==0 ) {

                SLAST exprToken = retval.tree;
                exprToken.setIndex(startIndex, endIndex);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "scalar"

    public static class constant_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "constant"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1981:1: constant : ( INTLITERAL | FLOATLITERAL | STRINGLITERAL | DOUBLELITERRAL | common_scalar | fully_qualified_class_name );
    public final CompilerAstParser.constant_return constant() throws RecognitionException {
        CompilerAstParser.constant_return retval = new CompilerAstParser.constant_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token INTLITERAL377=null;
        Token FLOATLITERAL378=null;
        Token STRINGLITERAL379=null;
        Token DOUBLELITERRAL380=null;
        CompilerAstParser.common_scalar_return common_scalar381 = null;

        CompilerAstParser.fully_qualified_class_name_return fully_qualified_class_name382 = null;


        SLAST INTLITERAL377_tree=null;
        SLAST FLOATLITERAL378_tree=null;
        SLAST STRINGLITERAL379_tree=null;
        SLAST DOUBLELITERRAL380_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1982:3: ( INTLITERAL | FLOATLITERAL | STRINGLITERAL | DOUBLELITERRAL | common_scalar | fully_qualified_class_name )
            int alt132=6;
            switch ( input.LA(1) ) {
            case INTLITERAL:
                {
                alt132=1;
                }
                break;
            case FLOATLITERAL:
                {
                alt132=2;
                }
                break;
            case STRINGLITERAL:
                {
                alt132=3;
                }
                break;
            case DOUBLELITERRAL:
                {
                alt132=4;
                }
                break;
            case 183:
            case 184:
            case 185:
            case 186:
            case 187:
            case 188:
                {
                alt132=5;
                }
                break;
            case IDENTIFIER:
                {
                alt132=6;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 132, 0, input);

                throw nvae;
            }

            switch (alt132) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1982:5: INTLITERAL
                    {
                    root_0 = (SLAST)adaptor.nil();

                    INTLITERAL377=(Token)match(input,INTLITERAL,FOLLOW_INTLITERAL_in_constant5812); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    INTLITERAL377_tree = (SLAST)adaptor.create(INTLITERAL377);
                    adaptor.addChild(root_0, INTLITERAL377_tree);
                    }

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1983:5: FLOATLITERAL
                    {
                    root_0 = (SLAST)adaptor.nil();

                    FLOATLITERAL378=(Token)match(input,FLOATLITERAL,FOLLOW_FLOATLITERAL_in_constant5821); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    FLOATLITERAL378_tree = (SLAST)adaptor.create(FLOATLITERAL378);
                    adaptor.addChild(root_0, FLOATLITERAL378_tree);
                    }

                    }
                    break;
                case 3 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1984:5: STRINGLITERAL
                    {
                    root_0 = (SLAST)adaptor.nil();

                    STRINGLITERAL379=(Token)match(input,STRINGLITERAL,FOLLOW_STRINGLITERAL_in_constant5829); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    STRINGLITERAL379_tree = (SLAST)adaptor.create(STRINGLITERAL379);
                    adaptor.addChild(root_0, STRINGLITERAL379_tree);
                    }

                    }
                    break;
                case 4 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1985:5: DOUBLELITERRAL
                    {
                    root_0 = (SLAST)adaptor.nil();

                    DOUBLELITERRAL380=(Token)match(input,DOUBLELITERRAL,FOLLOW_DOUBLELITERRAL_in_constant5838); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    DOUBLELITERRAL380_tree = (SLAST)adaptor.create(DOUBLELITERRAL380);
                    adaptor.addChild(root_0, DOUBLELITERRAL380_tree);
                    }

                    }
                    break;
                case 5 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1986:5: common_scalar
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_common_scalar_in_constant5845);
                    common_scalar381=common_scalar();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, common_scalar381.getTree());

                    }
                    break;
                case 6 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1987:5: fully_qualified_class_name
                    {
                    root_0 = (SLAST)adaptor.nil();

                    pushFollow(FOLLOW_fully_qualified_class_name_in_constant5853);
                    fully_qualified_class_name382=fully_qualified_class_name();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, fully_qualified_class_name382.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "constant"

    public static class common_scalar_return extends ParserRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "common_scalar"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1990:1: common_scalar : ( '__CLASS__' | '__DIR__' | '__FILE__' | '__FUNCTION__' | '__METHOD__' | '__NAMESPACE__' );
    public final CompilerAstParser.common_scalar_return common_scalar() throws RecognitionException {
        CompilerAstParser.common_scalar_return retval = new CompilerAstParser.common_scalar_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        Token set383=null;

        SLAST set383_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:1991:3: ( '__CLASS__' | '__DIR__' | '__FILE__' | '__FUNCTION__' | '__METHOD__' | '__NAMESPACE__' )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:
            {
            root_0 = (SLAST)adaptor.nil();

            set383=(Token)input.LT(1);
            if ( (input.LA(1)>=183 && input.LA(1)<=188) ) {
                input.consume();
                if ( state.backtracking==0 ) adaptor.addChild(root_0, (SLAST)adaptor.create(set383));
                state.errorRecovery=false;state.failed=false;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                MismatchedSetException mse = new MismatchedSetException(null,input);
                throw mse;
            }


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (SLAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "common_scalar"

    // $ANTLR start synpred1_CompilerAst
    public final void synpred1_CompilerAst_fragment() throws RecognitionException {   
        CompilerAstParser.expression_return eElseCond = null;

        CompilerAstParser.statement_return s2 = null;


        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:571:53: ( ELSEIF_T LEFT_PARETHESIS eElseCond= expression RIGHT_PARETHESIS s2= statement )
        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:571:53: ELSEIF_T LEFT_PARETHESIS eElseCond= expression RIGHT_PARETHESIS s2= statement
        {
        match(input,ELSEIF_T,FOLLOW_ELSEIF_T_in_synpred1_CompilerAst2105); if (state.failed) return ;
        match(input,LEFT_PARETHESIS,FOLLOW_LEFT_PARETHESIS_in_synpred1_CompilerAst2107); if (state.failed) return ;
        pushFollow(FOLLOW_expression_in_synpred1_CompilerAst2111);
        eElseCond=expression();

        state._fsp--;
        if (state.failed) return ;
        match(input,RIGHT_PARETHESIS,FOLLOW_RIGHT_PARETHESIS_in_synpred1_CompilerAst2113); if (state.failed) return ;
        pushFollow(FOLLOW_statement_in_synpred1_CompilerAst2117);
        s2=statement();

        state._fsp--;
        if (state.failed) return ;

        }
    }
    // $ANTLR end synpred1_CompilerAst

    // $ANTLR start synpred2_CompilerAst
    public final void synpred2_CompilerAst_fragment() throws RecognitionException {   
        CompilerAstParser.statement_return s3 = null;


        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:572:42: ( ELSE_T s3= statement )
        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/CompilerAst.g:572:42: ELSE_T s3= statement
        {
        match(input,ELSE_T,FOLLOW_ELSE_T_in_synpred2_CompilerAst2143); if (state.failed) return ;
        pushFollow(FOLLOW_statement_in_synpred2_CompilerAst2147);
        s3=statement();

        state._fsp--;
        if (state.failed) return ;

        }
    }
    // $ANTLR end synpred2_CompilerAst

    // Delegated rules

    public final boolean synpred2_CompilerAst() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred2_CompilerAst_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }
    public final boolean synpred1_CompilerAst() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred1_CompilerAst_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }


    protected DFA21 dfa21 = new DFA21(this);
    protected DFA41 dfa41 = new DFA41(this);
    protected DFA42 dfa42 = new DFA42(this);
    protected DFA104 dfa104 = new DFA104(this);
    protected DFA105 dfa105 = new DFA105(this);
    protected DFA119 dfa119 = new DFA119(this);
    protected DFA125 dfa125 = new DFA125(this);
    static final String DFA21_eotS =
        "\56\uffff";
    static final String DFA21_eofS =
        "\56\uffff";
    static final String DFA21_minS =
        "\1\71\1\uffff\1\71\1\63\1\uffff\1\63\1\57\1\60\3\72\1\u0093\1\63"+
        "\1\61\1\63\1\60\2\uffff\1\72\2\63\6\60\3\72\1\u0093\1\63\1\60\1"+
        "\63\2\60\1\72\1\63\10\60";
    static final String DFA21_maxS =
        "\1\u00ac\1\uffff\1\u00ac\1\72\1\uffff\1\63\1\57\1\u00b6\5\u0093"+
        "\1\66\1\u0093\1\124\2\uffff\1\u0093\1\u00bc\1\u00b6\6\123\5\u0093"+
        "\1\123\1\u0093\1\124\1\123\1\u0093\1\u00bc\10\123";
    static final String DFA21_acceptS =
        "\1\uffff\1\1\2\uffff\1\4\13\uffff\1\2\1\3\34\uffff";
    static final String DFA21_specialS =
        "\56\uffff}>";
    static final String[] DFA21_transitionS = {
            "\1\3\1\uffff\1\4\10\uffff\1\2\142\uffff\2\2\1\1\3\2",
            "",
            "\1\3\1\1\11\uffff\1\2\116\uffff\1\1\23\uffff\2\2\1\uffff\3"+
            "\2",
            "\1\6\6\uffff\1\5",
            "",
            "\1\6",
            "\1\7",
            "\1\15\2\uffff\1\10\6\uffff\1\13\1\12\111\uffff\1\11\15\uffff"+
            "\1\14\31\uffff\12\11",
            "\1\13\1\12\26\uffff\1\16\100\uffff\1\14",
            "\1\13\1\12\127\uffff\1\14",
            "\1\13\130\uffff\1\14",
            "\1\14",
            "\1\17\137\uffff\1\14",
            "\1\20\4\uffff\1\21",
            "\1\22\6\uffff\1\13\1\12\127\uffff\1\14",
            "\1\15\42\uffff\1\24\1\23",
            "",
            "",
            "\1\13\1\12\26\uffff\1\16\100\uffff\1\14",
            "\1\32\35\uffff\1\27\102\uffff\1\25\1\26\1\30\40\uffff\6\31",
            "\1\33\6\uffff\1\36\1\35\111\uffff\1\34\15\uffff\1\37\31\uffff"+
            "\12\34",
            "\1\15\42\uffff\1\24",
            "\1\15\42\uffff\1\24",
            "\1\15\42\uffff\1\24",
            "\1\15\42\uffff\1\24",
            "\1\15\42\uffff\1\24",
            "\1\15\41\uffff\1\40\1\24",
            "\1\36\1\35\26\uffff\1\41\100\uffff\1\37",
            "\1\36\1\35\127\uffff\1\37",
            "\1\36\130\uffff\1\37",
            "\1\37",
            "\1\42\137\uffff\1\37",
            "\1\15\2\uffff\1\43\37\uffff\1\24",
            "\1\44\6\uffff\1\36\1\35\127\uffff\1\37",
            "\1\15\42\uffff\1\24\1\45",
            "\1\15\41\uffff\1\40\1\24",
            "\1\36\1\35\26\uffff\1\41\100\uffff\1\37",
            "\1\53\35\uffff\1\50\102\uffff\1\46\1\47\1\51\40\uffff\6\52",
            "\1\15\42\uffff\1\24",
            "\1\15\42\uffff\1\24",
            "\1\15\42\uffff\1\24",
            "\1\15\42\uffff\1\24",
            "\1\15\42\uffff\1\24",
            "\1\15\41\uffff\1\54\1\24",
            "\1\15\2\uffff\1\55\37\uffff\1\24",
            "\1\15\41\uffff\1\54\1\24"
    };

    static final short[] DFA21_eot = DFA.unpackEncodedString(DFA21_eotS);
    static final short[] DFA21_eof = DFA.unpackEncodedString(DFA21_eofS);
    static final char[] DFA21_min = DFA.unpackEncodedStringToUnsignedChars(DFA21_minS);
    static final char[] DFA21_max = DFA.unpackEncodedStringToUnsignedChars(DFA21_maxS);
    static final short[] DFA21_accept = DFA.unpackEncodedString(DFA21_acceptS);
    static final short[] DFA21_special = DFA.unpackEncodedString(DFA21_specialS);
    static final short[][] DFA21_transition;

    static {
        int numStates = DFA21_transitionS.length;
        DFA21_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA21_transition[i] = DFA.unpackEncodedString(DFA21_transitionS[i]);
        }
    }

    class DFA21 extends DFA {

        public DFA21(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 21;
            this.eot = DFA21_eot;
            this.eof = DFA21_eof;
            this.min = DFA21_min;
            this.max = DFA21_max;
            this.accept = DFA21_accept;
            this.special = DFA21_special;
            this.transition = DFA21_transition;
        }
        public String getDescription() {
            return "203:1: class_statement : ( variable_modifiers static_var_list SEMI_COLON -> ^( FIELD_DECL variable_modifiers static_var_list ) | ( modifier )? FUNCTION_T ( REF_T )? IDENTIFIER LEFT_PARETHESIS ( parameter_list )? RIGHT_PARETHESIS SEMI_COLON -> ^( METHOD_DECL ( modifier )? ( REF_T )? IDENTIFIER ( parameter_list )? EMPTYSTATEMENT ) | ( modifier )? FUNCTION_T ( REF_T )? IDENTIFIER LEFT_PARETHESIS ( parameter_list )? RIGHT_PARETHESIS block -> ^( METHOD_DECL ( modifier )? ( REF_T )? IDENTIFIER ( parameter_list )? block ) | CONST_T directive SEMI_COLON -> ^( FIELD_DECL CONST_T directive ) );";
        }
    }
    static final String DFA41_eotS =
        "\73\uffff";
    static final String DFA41_eofS =
        "\1\1\72\uffff";
    static final String DFA41_minS =
        "\1\56\57\uffff\1\0\12\uffff";
    static final String DFA41_maxS =
        "\1\u00bc\57\uffff\1\0\12\uffff";
    static final String DFA41_acceptS =
        "\1\uffff\1\2\70\uffff\1\1";
    static final String DFA41_specialS =
        "\60\uffff\1\0\12\uffff}>";
    static final String[] DFA41_transitionS = {
            "\2\1\1\uffff\3\1\2\uffff\5\1\1\uffff\13\1\2\uffff\11\1\3\uffff"+
            "\1\1\1\60\1\1\1\uffff\4\1\1\uffff\4\1\36\uffff\2\1\3\uffff\5"+
            "\1\1\uffff\5\1\3\uffff\4\1\17\uffff\3\1\15\uffff\7\1",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\1\uffff",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA41_eot = DFA.unpackEncodedString(DFA41_eotS);
    static final short[] DFA41_eof = DFA.unpackEncodedString(DFA41_eofS);
    static final char[] DFA41_min = DFA.unpackEncodedStringToUnsignedChars(DFA41_minS);
    static final char[] DFA41_max = DFA.unpackEncodedStringToUnsignedChars(DFA41_maxS);
    static final short[] DFA41_accept = DFA.unpackEncodedString(DFA41_acceptS);
    static final short[] DFA41_special = DFA.unpackEncodedString(DFA41_specialS);
    static final short[][] DFA41_transition;

    static {
        int numStates = DFA41_transitionS.length;
        DFA41_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA41_transition[i] = DFA.unpackEncodedString(DFA41_transitionS[i]);
        }
    }

    class DFA41 extends DFA {

        public DFA41(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 41;
            this.eot = DFA41_eot;
            this.eof = DFA41_eof;
            this.min = DFA41_min;
            this.max = DFA41_max;
            this.accept = DFA41_accept;
            this.special = DFA41_special;
            this.transition = DFA41_transition;
        }
        public String getDescription() {
            return "()* loopback of 571:20: ( options {k=1; backtrack=true; } : ELSEIF_T LEFT_PARETHESIS eElseCond= expression RIGHT_PARETHESIS s2= statement )*";
        }
        public int specialStateTransition(int s, IntStream _input) throws NoViableAltException {
            TokenStream input = (TokenStream)_input;
        	int _s = s;
            switch ( s ) {
                    case 0 : 
                        int LA41_48 = input.LA(1);

                         
                        int index41_48 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred1_CompilerAst()) ) {s = 58;}

                        else if ( (true) ) {s = 1;}

                         
                        input.seek(index41_48);
                        if ( s>=0 ) return s;
                        break;
            }
            if (state.backtracking>0) {state.failed=true; return -1;}
            NoViableAltException nvae =
                new NoViableAltException(getDescription(), 41, _s, input);
            error(nvae);
            throw nvae;
        }
    }
    static final String DFA42_eotS =
        "\73\uffff";
    static final String DFA42_eofS =
        "\1\2\72\uffff";
    static final String DFA42_minS =
        "\1\56\1\0\71\uffff";
    static final String DFA42_maxS =
        "\1\u00bc\1\0\71\uffff";
    static final String DFA42_acceptS =
        "\2\uffff\1\2\67\uffff\1\1";
    static final String DFA42_specialS =
        "\1\uffff\1\0\71\uffff}>";
    static final String[] DFA42_transitionS = {
            "\2\2\1\uffff\3\2\2\uffff\5\2\1\uffff\13\2\2\uffff\11\2\3\uffff"+
            "\2\2\1\1\1\uffff\4\2\1\uffff\4\2\36\uffff\2\2\3\uffff\5\2\1"+
            "\uffff\5\2\3\uffff\4\2\17\uffff\3\2\15\uffff\7\2",
            "\1\uffff",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA42_eot = DFA.unpackEncodedString(DFA42_eotS);
    static final short[] DFA42_eof = DFA.unpackEncodedString(DFA42_eofS);
    static final char[] DFA42_min = DFA.unpackEncodedStringToUnsignedChars(DFA42_minS);
    static final char[] DFA42_max = DFA.unpackEncodedStringToUnsignedChars(DFA42_maxS);
    static final short[] DFA42_accept = DFA.unpackEncodedString(DFA42_acceptS);
    static final short[] DFA42_special = DFA.unpackEncodedString(DFA42_specialS);
    static final short[][] DFA42_transition;

    static {
        int numStates = DFA42_transitionS.length;
        DFA42_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA42_transition[i] = DFA.unpackEncodedString(DFA42_transitionS[i]);
        }
    }

    class DFA42 extends DFA {

        public DFA42(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 42;
            this.eot = DFA42_eot;
            this.eof = DFA42_eof;
            this.min = DFA42_min;
            this.max = DFA42_max;
            this.accept = DFA42_accept;
            this.special = DFA42_special;
            this.transition = DFA42_transition;
        }
        public String getDescription() {
            return "572:9: ( options {k=1; backtrack=true; } : ELSE_T s3= statement )?";
        }
        public int specialStateTransition(int s, IntStream _input) throws NoViableAltException {
            TokenStream input = (TokenStream)_input;
        	int _s = s;
            switch ( s ) {
                    case 0 : 
                        int LA42_1 = input.LA(1);

                         
                        int index42_1 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred2_CompilerAst()) ) {s = 58;}

                        else if ( (true) ) {s = 2;}

                         
                        input.seek(index42_1);
                        if ( s>=0 ) return s;
                        break;
            }
            if (state.backtracking>0) {state.failed=true; return -1;}
            NoViableAltException nvae =
                new NoViableAltException(getDescription(), 42, _s, input);
            error(nvae);
            throw nvae;
        }
    }
    static final String DFA104_eotS =
        "\16\uffff";
    static final String DFA104_eofS =
        "\16\uffff";
    static final String DFA104_minS =
        "\1\57\1\63\1\57\11\uffff\2\57";
    static final String DFA104_maxS =
        "\2\u00bc\1\u0093\11\uffff\2\u0093";
    static final String DFA104_acceptS =
        "\3\uffff\1\1\1\2\1\3\1\4\1\5\1\6\1\7\1\10\1\11\2\uffff";
    static final String DFA104_specialS =
        "\16\uffff}>";
    static final String[] DFA104_transitionS = {
            "\1\5\3\uffff\1\2\35\uffff\1\4\63\uffff\1\11\5\uffff\1\1\1\6"+
            "\1\10\1\12\1\13\3\uffff\1\3\3\4\37\uffff\1\7\6\4",
            "\1\2\35\uffff\1\4\101\uffff\1\3\3\4\40\uffff\6\4",
            "\1\3\2\4\5\uffff\1\4\2\uffff\1\4\14\uffff\2\4\11\uffff\1\14"+
            "\2\4\3\uffff\1\4\11\uffff\43\4\3\uffff\3\4\7\uffff\1\4\1\3",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\1\3\2\4\1\uffff\1\15\3\uffff\1\4\2\uffff\1\4\14\uffff\2\4"+
            "\12\uffff\2\4\3\uffff\1\4\11\uffff\43\4\3\uffff\3\4\7\uffff"+
            "\1\4\1\3",
            "\1\3\2\4\5\uffff\1\4\2\uffff\1\4\14\uffff\2\4\11\uffff\1\14"+
            "\2\4\3\uffff\1\4\11\uffff\43\4\3\uffff\3\4\7\uffff\1\4\1\3"
    };

    static final short[] DFA104_eot = DFA.unpackEncodedString(DFA104_eotS);
    static final short[] DFA104_eof = DFA.unpackEncodedString(DFA104_eofS);
    static final char[] DFA104_min = DFA.unpackEncodedStringToUnsignedChars(DFA104_minS);
    static final char[] DFA104_max = DFA.unpackEncodedStringToUnsignedChars(DFA104_maxS);
    static final short[] DFA104_accept = DFA.unpackEncodedString(DFA104_acceptS);
    static final short[] DFA104_special = DFA.unpackEncodedString(DFA104_specialS);
    static final short[][] DFA104_transition;

    static {
        int numStates = DFA104_transitionS.length;
        DFA104_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA104_transition[i] = DFA.unpackEncodedString(DFA104_transitionS[i]);
        }
    }

    class DFA104 extends DFA {

        public DFA104(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 104;
            this.eot = DFA104_eot;
            this.eof = DFA104_eof;
            this.min = DFA104_min;
            this.max = DFA104_max;
            this.accept = DFA104_accept;
            this.special = DFA104_special;
            this.transition = DFA104_transition;
        }
        public String getDescription() {
            return "1514:1: atom_expr : ( ( AT_T )? variable | ( AT_T )? scalar | LEFT_PARETHESIS expression RIGHT_PARETHESIS | LIST_T LEFT_PARETHESIS assignment_list RIGHT_PARETHESIS -> ^( LIST_T assignment_list ) | 'array' LEFT_PARETHESIS ( array_pair_list )? RIGHT_PARETHESIS -> ^( ARRAY_DECL ( array_pair_list )? ) | NEW_T class_name_reference -> ^( NEW_T class_name_reference ) | CLONE_T variable -> ^( CLONE_T variable ) | BACKTRICKLITERAL | PRINT_T expression -> ^( PRINT_T expression ) );";
        }
    }
    static final String DFA105_eotS =
        "\6\uffff";
    static final String DFA105_eofS =
        "\6\uffff";
    static final String DFA105_minS =
        "\1\63\1\57\1\uffff\1\57\1\uffff\1\57";
    static final String DFA105_maxS =
        "\2\u0093\1\uffff\1\u0093\1\uffff\1\u0093";
    static final String DFA105_acceptS =
        "\2\uffff\1\1\1\uffff\1\2\1\uffff";
    static final String DFA105_specialS =
        "\6\uffff}>";
    static final String[] DFA105_transitionS = {
            "\1\1\137\uffff\1\2",
            "\1\2\2\4\5\uffff\1\4\2\uffff\1\4\14\uffff\2\4\11\uffff\1\3"+
            "\2\4\3\uffff\1\4\11\uffff\43\4\3\uffff\3\4\7\uffff\1\4\1\2",
            "",
            "\1\2\2\4\1\uffff\1\5\3\uffff\1\4\2\uffff\1\4\14\uffff\2\4\12"+
            "\uffff\2\4\3\uffff\1\4\11\uffff\43\4\3\uffff\3\4\7\uffff\1\4"+
            "\1\2",
            "",
            "\1\2\2\4\5\uffff\1\4\2\uffff\1\4\14\uffff\2\4\11\uffff\1\3"+
            "\2\4\3\uffff\1\4\11\uffff\43\4\3\uffff\3\4\7\uffff\1\4\1\2"
    };

    static final short[] DFA105_eot = DFA.unpackEncodedString(DFA105_eotS);
    static final short[] DFA105_eof = DFA.unpackEncodedString(DFA105_eofS);
    static final char[] DFA105_min = DFA.unpackEncodedStringToUnsignedChars(DFA105_minS);
    static final char[] DFA105_max = DFA.unpackEncodedStringToUnsignedChars(DFA105_maxS);
    static final short[] DFA105_accept = DFA.unpackEncodedString(DFA105_acceptS);
    static final short[] DFA105_special = DFA.unpackEncodedString(DFA105_specialS);
    static final short[][] DFA105_transition;

    static {
        int numStates = DFA105_transitionS.length;
        DFA105_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA105_transition[i] = DFA.unpackEncodedString(DFA105_transitionS[i]);
        }
    }

    class DFA105 extends DFA {

        public DFA105(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 105;
            this.eot = DFA105_eot;
            this.eof = DFA105_eof;
            this.min = DFA105_min;
            this.max = DFA105_max;
            this.accept = DFA105_accept;
            this.special = DFA105_special;
            this.transition = DFA105_transition;
        }
        public String getDescription() {
            return "1615:1: class_name_reference : ( dynamic_name_reference | fully_qualified_class_name );";
        }
    }
    static final String DFA119_eotS =
        "\6\uffff";
    static final String DFA119_eofS =
        "\6\uffff";
    static final String DFA119_minS =
        "\1\63\1\57\1\uffff\1\57\1\uffff\1\57";
    static final String DFA119_maxS =
        "\2\u0093\1\uffff\1\u0093\1\uffff\1\u0093";
    static final String DFA119_acceptS =
        "\2\uffff\1\1\1\uffff\1\2\1\uffff";
    static final String DFA119_specialS =
        "\6\uffff}>";
    static final String[] DFA119_transitionS = {
            "\1\1\137\uffff\1\2",
            "\1\4\42\uffff\1\3\100\uffff\1\2",
            "",
            "\1\4\3\uffff\1\5\137\uffff\1\2",
            "",
            "\1\4\42\uffff\1\3\100\uffff\1\2"
    };

    static final short[] DFA119_eot = DFA.unpackEncodedString(DFA119_eotS);
    static final short[] DFA119_eof = DFA.unpackEncodedString(DFA119_eofS);
    static final char[] DFA119_min = DFA.unpackEncodedStringToUnsignedChars(DFA119_minS);
    static final char[] DFA119_max = DFA.unpackEncodedStringToUnsignedChars(DFA119_maxS);
    static final short[] DFA119_accept = DFA.unpackEncodedString(DFA119_acceptS);
    static final short[] DFA119_special = DFA.unpackEncodedString(DFA119_specialS);
    static final short[][] DFA119_transition;

    static {
        int numStates = DFA119_transitionS.length;
        DFA119_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA119_transition[i] = DFA.unpackEncodedString(DFA119_transitionS[i]);
        }
    }

    class DFA119 extends DFA {

        public DFA119(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 119;
            this.eot = DFA119_eot;
            this.eof = DFA119_eof;
            this.min = DFA119_min;
            this.max = DFA119_max;
            this.accept = DFA119_accept;
            this.special = DFA119_special;
            this.transition = DFA119_transition;
        }
        public String getDescription() {
            return "1735:1: base_variable_with_function_calls : ( ( fully_qualified_class_name )? reference_variable ( ctor_arguments )? -> ^( VAR_DECL ( fully_qualified_class_name )? reference_variable ( ctor_arguments )? ) | fully_qualified_class_name ctor_arguments -> ^( CALL fully_qualified_class_name ctor_arguments ) );";
        }
    }
    static final String DFA125_eotS =
        "\4\uffff";
    static final String DFA125_eofS =
        "\4\uffff";
    static final String DFA125_minS =
        "\1\u0093\1\63\2\uffff";
    static final String DFA125_maxS =
        "\2\u0093\2\uffff";
    static final String DFA125_acceptS =
        "\2\uffff\1\2\1\1";
    static final String DFA125_specialS =
        "\4\uffff}>";
    static final String[] DFA125_transitionS = {
            "\1\1",
            "\1\3\2\uffff\1\2\134\uffff\1\1",
            "",
            ""
    };

    static final short[] DFA125_eot = DFA.unpackEncodedString(DFA125_eotS);
    static final short[] DFA125_eof = DFA.unpackEncodedString(DFA125_eofS);
    static final char[] DFA125_min = DFA.unpackEncodedStringToUnsignedChars(DFA125_minS);
    static final char[] DFA125_max = DFA.unpackEncodedStringToUnsignedChars(DFA125_maxS);
    static final short[] DFA125_accept = DFA.unpackEncodedString(DFA125_acceptS);
    static final short[] DFA125_special = DFA.unpackEncodedString(DFA125_specialS);
    static final short[][] DFA125_transition;

    static {
        int numStates = DFA125_transitionS.length;
        DFA125_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA125_transition[i] = DFA.unpackEncodedString(DFA125_transitionS[i]);
        }
    }

    class DFA125 extends DFA {

        public DFA125(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 125;
            this.eot = DFA125_eot;
            this.eof = DFA125_eof;
            this.min = DFA125_min;
            this.max = DFA125_max;
            this.accept = DFA125_accept;
            this.special = DFA125_special;
            this.transition = DFA125_transition;
        }
        public String getDescription() {
            return "1833:1: compound_variable : ( ( DOLLAR_T )+ IDENTIFIER | ( DOLLAR_T )+ LEFT_BRACKET expression RIGHT_BRACKET );";
        }
    }
 

    public static final BitSet FOLLOW_SOC_T_in_php_source271 = new BitSet(new long[]{0xF74EC00000000000L,0x000000000023FE7FL,0x1FC001C00078FBE3L});
    public static final BitSet FOLLOW_SOC_PHP_T_in_php_source283 = new BitSet(new long[]{0xF74EC00000000000L,0x000000000023FE7FL,0x1FC001C00078FBE3L});
    public static final BitSet FOLLOW_top_statement_list_in_php_source298 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_EOC_T_in_php_source307 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_top_statement_in_top_statement_list342 = new BitSet(new long[]{0xF74E800000000002L,0x000000000023FE7FL,0x1FC001C00078FBE3L});
    public static final BitSet FOLLOW_statement_in_top_statement356 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_function_declaration_statement_in_top_statement362 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_class_declaration_statement_in_top_statement368 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_halt_compiler_statement_in_top_statement374 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_inner_statement_in_inner_statement_list390 = new BitSet(new long[]{0xF74E800000000002L,0x000000000023FE7FL,0x1FC001C00078FBE3L});
    public static final BitSet FOLLOW_statement_in_inner_statement407 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_function_declaration_statement_in_inner_statement413 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_class_declaration_statement_in_inner_statement419 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_halt_compiler_statement_in_inner_statement425 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_166_in_halt_compiler_statement440 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_halt_compiler_statement442 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_halt_compiler_statement444 = new BitSet(new long[]{0x0002000000000000L});
    public static final BitSet FOLLOW_SEMI_COLON_in_halt_compiler_statement446 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_class_entr_type_in_class_declaration_statement481 = new BitSet(new long[]{0x0004000000000000L});
    public static final BitSet FOLLOW_CLASS_T_in_class_declaration_statement484 = new BitSet(new long[]{0x0008000000000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_class_declaration_statement486 = new BitSet(new long[]{0x0070000000000000L});
    public static final BitSet FOLLOW_EXTENDS_T_in_class_declaration_statement489 = new BitSet(new long[]{0x0008000000000000L});
    public static final BitSet FOLLOW_fully_qualified_class_name_in_class_declaration_statement491 = new BitSet(new long[]{0x0060000000000000L});
    public static final BitSet FOLLOW_IMPLEMENTS_T_in_class_declaration_statement496 = new BitSet(new long[]{0x0008000000000000L});
    public static final BitSet FOLLOW_fully_qualified_class_name_list_in_class_declaration_statement498 = new BitSet(new long[]{0x0040000000000000L});
    public static final BitSet FOLLOW_LEFT_BRACKET_in_class_declaration_statement508 = new BitSet(new long[]{0x0A80000000000000L,0x0000000000000010L,0x00001F8000000000L});
    public static final BitSet FOLLOW_class_statement_in_class_declaration_statement510 = new BitSet(new long[]{0x0A80000000000000L,0x0000000000000010L,0x00001F8000000000L});
    public static final BitSet FOLLOW_RIGHT_BRACKET_in_class_declaration_statement513 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_INTERFACE_T_in_class_declaration_statement575 = new BitSet(new long[]{0x0008000000000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_class_declaration_statement577 = new BitSet(new long[]{0x0070000000000000L});
    public static final BitSet FOLLOW_EXTENDS_T_in_class_declaration_statement580 = new BitSet(new long[]{0x0008000000000000L});
    public static final BitSet FOLLOW_fully_qualified_class_name_list_in_class_declaration_statement582 = new BitSet(new long[]{0x0060000000000000L});
    public static final BitSet FOLLOW_IMPLEMENTS_T_in_class_declaration_statement587 = new BitSet(new long[]{0x0008000000000000L});
    public static final BitSet FOLLOW_fully_qualified_class_name_list_in_class_declaration_statement589 = new BitSet(new long[]{0x0040000000000000L});
    public static final BitSet FOLLOW_LEFT_BRACKET_in_class_declaration_statement599 = new BitSet(new long[]{0x0A80000000000000L,0x0000000000000010L,0x00001F8000000000L});
    public static final BitSet FOLLOW_class_statement_in_class_declaration_statement601 = new BitSet(new long[]{0x0A80000000000000L,0x0000000000000010L,0x00001F8000000000L});
    public static final BitSet FOLLOW_RIGHT_BRACKET_in_class_declaration_statement604 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_class_entr_type0 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_variable_modifiers_in_class_statement689 = new BitSet(new long[]{0x0400000000000000L,0x0000000000000000L,0x0000000000080000L});
    public static final BitSet FOLLOW_static_var_list_in_class_statement691 = new BitSet(new long[]{0x0002000000000000L});
    public static final BitSet FOLLOW_SEMI_COLON_in_class_statement693 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_modifier_in_class_statement720 = new BitSet(new long[]{0x0200000000000000L});
    public static final BitSet FOLLOW_FUNCTION_T_in_class_statement723 = new BitSet(new long[]{0x0408000000000000L});
    public static final BitSet FOLLOW_REF_T_in_class_statement725 = new BitSet(new long[]{0x0008000000000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_class_statement728 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_class_statement730 = new BitSet(new long[]{0x0C09000000000000L,0x0000000000000000L,0x007FE00000080020L});
    public static final BitSet FOLLOW_parameter_list_in_class_statement732 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_class_statement735 = new BitSet(new long[]{0x0002000000000000L});
    public static final BitSet FOLLOW_SEMI_COLON_in_class_statement737 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_modifier_in_class_statement772 = new BitSet(new long[]{0x0200000000000000L});
    public static final BitSet FOLLOW_FUNCTION_T_in_class_statement775 = new BitSet(new long[]{0x0408000000000000L});
    public static final BitSet FOLLOW_REF_T_in_class_statement777 = new BitSet(new long[]{0x0008000000000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_class_statement780 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_class_statement782 = new BitSet(new long[]{0x0C09000000000000L,0x0000000000000000L,0x007FE00000080020L});
    public static final BitSet FOLLOW_parameter_list_in_class_statement784 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_class_statement787 = new BitSet(new long[]{0x0040000000000000L});
    public static final BitSet FOLLOW_block_in_class_statement789 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_CONST_T_in_class_statement824 = new BitSet(new long[]{0x0008000000000000L});
    public static final BitSet FOLLOW_directive_in_class_statement826 = new BitSet(new long[]{0x0002000000000000L});
    public static final BitSet FOLLOW_SEMI_COLON_in_class_statement828 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_FUNCTION_T_in_function_declaration_statement875 = new BitSet(new long[]{0x0408000000000000L});
    public static final BitSet FOLLOW_REF_T_in_function_declaration_statement877 = new BitSet(new long[]{0x0008000000000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_function_declaration_statement880 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_function_declaration_statement882 = new BitSet(new long[]{0x0C09000000000000L,0x0000000000000000L,0x007FE00000080020L});
    public static final BitSet FOLLOW_parameter_list_in_function_declaration_statement884 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_function_declaration_statement887 = new BitSet(new long[]{0x0040000000000000L});
    public static final BitSet FOLLOW_block_in_function_declaration_statement894 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LEFT_BRACKET_in_block940 = new BitSet(new long[]{0xF7CE800000000000L,0x000000000023FE7FL,0x1FC001C00078FBE3L});
    public static final BitSet FOLLOW_inner_statement_list_in_block942 = new BitSet(new long[]{0x0080000000000000L});
    public static final BitSet FOLLOW_RIGHT_BRACKET_in_block945 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_topStatement_in_statement992 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_block_in_topStatement1034 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_if_stat_in_topStatement1044 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_WHILE_T_in_topStatement1054 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_topStatement1056 = new BitSet(new long[]{0x0408800000000000L,0x0000000000020000L,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_expression_in_topStatement1058 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_topStatement1060 = new BitSet(new long[]{0xF44A800000000000L,0x000000000123FE7FL,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_while_statement_in_topStatement1062 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_DO_T_in_topStatement1095 = new BitSet(new long[]{0xF44A800000000000L,0x000000000023FE7FL,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_statement_in_topStatement1097 = new BitSet(new long[]{0x1000000000000000L});
    public static final BitSet FOLLOW_WHILE_T_in_topStatement1099 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_topStatement1101 = new BitSet(new long[]{0x0408800000000000L,0x0000000000020000L,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_expression_in_topStatement1103 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_topStatement1105 = new BitSet(new long[]{0x0002000000000000L});
    public static final BitSet FOLLOW_SEMI_COLON_in_topStatement1107 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_FOR_T_in_topStatement1137 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_topStatement1139 = new BitSet(new long[]{0x040A800000000000L,0x0000000000020000L,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_expr_list_in_topStatement1143 = new BitSet(new long[]{0x0002000000000000L});
    public static final BitSet FOLLOW_SEMI_COLON_in_topStatement1146 = new BitSet(new long[]{0x040A800000000000L,0x0000000000020000L,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_expr_list_in_topStatement1150 = new BitSet(new long[]{0x0002000000000000L});
    public static final BitSet FOLLOW_SEMI_COLON_in_topStatement1153 = new BitSet(new long[]{0x0409800000000000L,0x0000000000020000L,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_expr_list_in_topStatement1157 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_topStatement1160 = new BitSet(new long[]{0xF44A800000000000L,0x000000000123FE7FL,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_for_statement_in_topStatement1162 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_SWITCH_T_in_topStatement1206 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_topStatement1208 = new BitSet(new long[]{0x0408800000000000L,0x0000000000020000L,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_expression_in_topStatement1210 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_topStatement1212 = new BitSet(new long[]{0x0040000000000000L,0x0000000001000000L});
    public static final BitSet FOLLOW_switch_case_list_in_topStatement1214 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_BREAK_T_in_topStatement1243 = new BitSet(new long[]{0x040A800000000000L,0x0000000000020000L,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_expression_in_topStatement1245 = new BitSet(new long[]{0x0002000000000000L});
    public static final BitSet FOLLOW_SEMI_COLON_in_topStatement1248 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_CONTINUE_T_in_topStatement1272 = new BitSet(new long[]{0x040A800000000000L,0x0000000000020000L,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_expression_in_topStatement1274 = new BitSet(new long[]{0x0002000000000000L});
    public static final BitSet FOLLOW_SEMI_COLON_in_topStatement1277 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RETURN_T_in_topStatement1313 = new BitSet(new long[]{0x040A800000000000L,0x0000000000020000L,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_expression_in_topStatement1315 = new BitSet(new long[]{0x0002000000000000L});
    public static final BitSet FOLLOW_SEMI_COLON_in_topStatement1318 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_GLOBAL_T_in_topStatement1357 = new BitSet(new long[]{0x0008000000000000L,0x0000000000000000L,0x0000000000080800L});
    public static final BitSet FOLLOW_variable_list_in_topStatement1359 = new BitSet(new long[]{0x0002000000000000L});
    public static final BitSet FOLLOW_SEMI_COLON_in_topStatement1361 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_STATIC_T_in_topStatement1399 = new BitSet(new long[]{0x0400000000000000L,0x0000000000000000L,0x0000000000080000L});
    public static final BitSet FOLLOW_static_var_list_in_topStatement1401 = new BitSet(new long[]{0x0002000000000000L});
    public static final BitSet FOLLOW_SEMI_COLON_in_topStatement1403 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ECHO_T_in_topStatement1438 = new BitSet(new long[]{0x0408800000000000L,0x0000000000020000L,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_expr_list_in_topStatement1440 = new BitSet(new long[]{0x0002000000000000L});
    public static final BitSet FOLLOW_SEMI_COLON_in_topStatement1442 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_expression_in_topStatement1465 = new BitSet(new long[]{0x0002000000000000L});
    public static final BitSet FOLLOW_SEMI_COLON_in_topStatement1467 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_FOREACH_T_in_topStatement1478 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_topStatement1480 = new BitSet(new long[]{0x0408800000000000L,0x0000000000020000L,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_expression_in_topStatement1482 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000080L});
    public static final BitSet FOLLOW_AS_T_in_topStatement1484 = new BitSet(new long[]{0x0408000000000000L,0x0000000000000000L,0x0000000000080800L});
    public static final BitSet FOLLOW_foreach_variable_in_topStatement1486 = new BitSet(new long[]{0x0001000000000000L,0x0000000000000100L});
    public static final BitSet FOLLOW_ARROW_T_in_topStatement1489 = new BitSet(new long[]{0x0408000000000000L,0x0000000000000000L,0x0000000000080800L});
    public static final BitSet FOLLOW_foreach_variable_in_topStatement1491 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_topStatement1495 = new BitSet(new long[]{0xF44A800000000000L,0x000000000123FE7FL,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_foreach_statement_in_topStatement1505 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_DECLARE_T_in_topStatement1540 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_topStatement1542 = new BitSet(new long[]{0x0008000000000000L});
    public static final BitSet FOLLOW_directive_in_topStatement1544 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_topStatement1546 = new BitSet(new long[]{0xF44A800000000000L,0x000000000123FE7FL,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_declare_statement_in_topStatement1548 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_SEMI_COLON_in_topStatement1574 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_TRY_T_in_topStatement1593 = new BitSet(new long[]{0x0040000000000000L});
    public static final BitSet FOLLOW_block_in_topStatement1595 = new BitSet(new long[]{0x0000000000000000L,0x0000000020000000L});
    public static final BitSet FOLLOW_catch_branch_in_topStatement1597 = new BitSet(new long[]{0x0000000000000002L,0x0000000020000000L});
    public static final BitSet FOLLOW_THROW_T_in_topStatement1624 = new BitSet(new long[]{0x0408800000000000L,0x0000000000020000L,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_expression_in_topStatement1626 = new BitSet(new long[]{0x0002000000000000L});
    public static final BitSet FOLLOW_SEMI_COLON_in_topStatement1628 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_USE_T_in_topStatement1665 = new BitSet(new long[]{0x0000800000000000L,0x0000000000020000L});
    public static final BitSet FOLLOW_use_filename_in_topStatement1667 = new BitSet(new long[]{0x0002000000000000L});
    public static final BitSet FOLLOW_SEMI_COLON_in_topStatement1669 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_INCLUDE_T_in_topStatement1706 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_topStatement1708 = new BitSet(new long[]{0x0408800000000000L,0x0000000000020000L,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_expression_in_topStatement1710 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_topStatement1712 = new BitSet(new long[]{0x0002000000000000L});
    public static final BitSet FOLLOW_SEMI_COLON_in_topStatement1714 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_INCLUDE_ONCE_T_in_topStatement1737 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_topStatement1739 = new BitSet(new long[]{0x0408800000000000L,0x0000000000020000L,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_expression_in_topStatement1741 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_topStatement1743 = new BitSet(new long[]{0x0002000000000000L});
    public static final BitSet FOLLOW_SEMI_COLON_in_topStatement1745 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_REQUIRE_T_in_topStatement1768 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_topStatement1770 = new BitSet(new long[]{0x0408800000000000L,0x0000000000020000L,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_expression_in_topStatement1772 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_topStatement1774 = new BitSet(new long[]{0x0002000000000000L});
    public static final BitSet FOLLOW_SEMI_COLON_in_topStatement1776 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_REQUIRE_ONCE_T_in_topStatement1799 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_topStatement1801 = new BitSet(new long[]{0x0408800000000000L,0x0000000000020000L,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_expression_in_topStatement1803 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_topStatement1805 = new BitSet(new long[]{0x0002000000000000L});
    public static final BitSet FOLLOW_SEMI_COLON_in_topStatement1807 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_REF_T_in_foreach_variable1847 = new BitSet(new long[]{0x0008000000000000L,0x0000000000000000L,0x0000000000080800L});
    public static final BitSet FOLLOW_variable_in_foreach_variable1850 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_STRINGLITERAL_in_use_filename1865 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_use_filename1871 = new BitSet(new long[]{0x0000000000000000L,0x0000000000020000L});
    public static final BitSet FOLLOW_STRINGLITERAL_in_use_filename1874 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_use_filename1876 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_fully_qualified_class_name_in_fully_qualified_class_name_list1905 = new BitSet(new long[]{0x0000000000000002L,0x0000000000080000L});
    public static final BitSet FOLLOW_COMMA_T_in_fully_qualified_class_name_list1908 = new BitSet(new long[]{0x0008000000000000L});
    public static final BitSet FOLLOW_fully_qualified_class_name_in_fully_qualified_class_name_list1910 = new BitSet(new long[]{0x0000000000000002L,0x0000000000080000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_fully_qualified_class_name1946 = new BitSet(new long[]{0x0000000000000002L,0x0000000000040000L});
    public static final BitSet FOLLOW_DOMAIN_T_in_fully_qualified_class_name1949 = new BitSet(new long[]{0x0008000000000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_fully_qualified_class_name1954 = new BitSet(new long[]{0x0000000000000002L,0x0000000000040000L});
    public static final BitSet FOLLOW_DOMAIN_T_in_fully_qualified_class_name1960 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_static_var_element_in_static_var_list1991 = new BitSet(new long[]{0x0000000000000002L,0x0000000000080000L});
    public static final BitSet FOLLOW_COMMA_T_in_static_var_list1994 = new BitSet(new long[]{0x0400000000000000L,0x0000000000000000L,0x0000000000080000L});
    public static final BitSet FOLLOW_static_var_element_in_static_var_list1996 = new BitSet(new long[]{0x0000000000000002L,0x0000000000080000L});
    public static final BitSet FOLLOW_pure_variable_in_static_var_element2028 = new BitSet(new long[]{0x0000000000000002L,0x0000000000100000L});
    public static final BitSet FOLLOW_EQUAL_T_in_static_var_element2031 = new BitSet(new long[]{0x0008000000000000L,0x0000000000020000L,0x1F80000000700800L});
    public static final BitSet FOLLOW_scalar_in_static_var_element2034 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IF_T_in_if_stat2065 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_if_stat2067 = new BitSet(new long[]{0x0408800000000000L,0x0000000000020000L,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_expression_in_if_stat2071 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_if_stat2073 = new BitSet(new long[]{0xF44A800000000000L,0x000000000123FE7FL,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_statement_in_if_stat2089 = new BitSet(new long[]{0x0000000000000002L,0x0000000000C00000L});
    public static final BitSet FOLLOW_ELSEIF_T_in_if_stat2105 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_if_stat2107 = new BitSet(new long[]{0x0408800000000000L,0x0000000000020000L,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_expression_in_if_stat2111 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_if_stat2113 = new BitSet(new long[]{0xF44A800000000000L,0x000000000023FE7FL,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_statement_in_if_stat2117 = new BitSet(new long[]{0x0000000000000002L,0x0000000000C00000L});
    public static final BitSet FOLLOW_ELSE_T_in_if_stat2143 = new BitSet(new long[]{0xF44A800000000000L,0x000000000023FE7FL,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_statement_in_if_stat2147 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_COLON_T_in_if_stat2213 = new BitSet(new long[]{0xF74E800000000000L,0x0000000002E3FE7FL,0x1FC001C00078FBE3L});
    public static final BitSet FOLLOW_inner_statement_list_in_if_stat2215 = new BitSet(new long[]{0x0000000000000000L,0x0000000002C00000L});
    public static final BitSet FOLLOW_new_elseif_branch_in_if_stat2218 = new BitSet(new long[]{0x0000000000000000L,0x0000000002C00000L});
    public static final BitSet FOLLOW_ELSE_T_in_if_stat2235 = new BitSet(new long[]{0x0000000000000000L,0x0000000001000000L});
    public static final BitSet FOLLOW_COLON_T_in_if_stat2237 = new BitSet(new long[]{0xF44A800000000000L,0x000000000023FE7FL,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_statement_in_if_stat2241 = new BitSet(new long[]{0x0000000000000000L,0x0000000002000000L});
    public static final BitSet FOLLOW_ENDIF_T_in_if_stat2245 = new BitSet(new long[]{0x0002000000000000L});
    public static final BitSet FOLLOW_SEMI_COLON_in_if_stat2247 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ELSEIF_T_in_new_elseif_branch2318 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_new_elseif_branch2320 = new BitSet(new long[]{0x0408800000000000L,0x0000000000020000L,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_expression_in_new_elseif_branch2322 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_new_elseif_branch2324 = new BitSet(new long[]{0x0000000000000000L,0x0000000001000000L});
    public static final BitSet FOLLOW_COLON_T_in_new_elseif_branch2326 = new BitSet(new long[]{0xF74E800000000002L,0x000000000023FE7FL,0x1FC001C00078FBE3L});
    public static final BitSet FOLLOW_inner_statement_list_in_new_elseif_branch2328 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LEFT_BRACKET_in_switch_case_list2366 = new BitSet(new long[]{0x0002000000000000L,0x0000000018000000L});
    public static final BitSet FOLLOW_SEMI_COLON_in_switch_case_list2368 = new BitSet(new long[]{0x0002000000000000L,0x0000000018000000L});
    public static final BitSet FOLLOW_case_list_in_switch_case_list2371 = new BitSet(new long[]{0x0082000000000000L,0x0000000018000000L});
    public static final BitSet FOLLOW_RIGHT_BRACKET_in_switch_case_list2374 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_COLON_T_in_switch_case_list2396 = new BitSet(new long[]{0x0002000000000000L,0x0000000018000000L});
    public static final BitSet FOLLOW_SEMI_COLON_in_switch_case_list2398 = new BitSet(new long[]{0x0002000000000000L,0x0000000018000000L});
    public static final BitSet FOLLOW_case_list_in_switch_case_list2401 = new BitSet(new long[]{0x0002000000000000L,0x000000001C000000L});
    public static final BitSet FOLLOW_ENDSWITCH_T_in_switch_case_list2404 = new BitSet(new long[]{0x0002000000000000L});
    public static final BitSet FOLLOW_SEMI_COLON_in_switch_case_list2406 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_CASE_T_in_case_list2439 = new BitSet(new long[]{0x0408800000000000L,0x0000000000020000L,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_expression_in_case_list2441 = new BitSet(new long[]{0x0002000000000000L,0x0000000001000000L});
    public static final BitSet FOLLOW_COLON_T_in_case_list2444 = new BitSet(new long[]{0xF74E800000000002L,0x000000000023FE7FL,0x1FC001C00078FBE3L});
    public static final BitSet FOLLOW_SEMI_COLON_in_case_list2448 = new BitSet(new long[]{0xF74E800000000002L,0x000000000023FE7FL,0x1FC001C00078FBE3L});
    public static final BitSet FOLLOW_inner_statement_list_in_case_list2451 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_DEFAULT_T_in_case_list2483 = new BitSet(new long[]{0x0002000000000000L,0x0000000001000000L});
    public static final BitSet FOLLOW_COLON_T_in_case_list2486 = new BitSet(new long[]{0xF74E800000000002L,0x000000000023FE7FL,0x1FC001C00078FBE3L});
    public static final BitSet FOLLOW_SEMI_COLON_in_case_list2490 = new BitSet(new long[]{0xF74E800000000002L,0x000000000023FE7FL,0x1FC001C00078FBE3L});
    public static final BitSet FOLLOW_inner_statement_list_in_case_list2493 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_CATCH_T_in_catch_branch2542 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_catch_branch2544 = new BitSet(new long[]{0x0008000000000000L});
    public static final BitSet FOLLOW_fully_qualified_class_name_in_catch_branch2546 = new BitSet(new long[]{0x0008000000000000L,0x0000000000000000L,0x0000000000080800L});
    public static final BitSet FOLLOW_variable_in_catch_branch2548 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_catch_branch2550 = new BitSet(new long[]{0x0040000000000000L});
    public static final BitSet FOLLOW_block_in_catch_branch2558 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_statement_in_for_statement2603 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_COLON_T_in_for_statement2619 = new BitSet(new long[]{0xF74E800000000000L,0x000000004023FE7FL,0x1FC001C00078FBE3L});
    public static final BitSet FOLLOW_inner_statement_list_in_for_statement2621 = new BitSet(new long[]{0x0000000000000000L,0x0000000040000000L});
    public static final BitSet FOLLOW_ENDFOR_T_in_for_statement2624 = new BitSet(new long[]{0x0002000000000000L});
    public static final BitSet FOLLOW_SEMI_COLON_in_for_statement2626 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_statement_in_while_statement2660 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_COLON_T_in_while_statement2677 = new BitSet(new long[]{0xF74E800000000000L,0x000000008023FE7FL,0x1FC001C00078FBE3L});
    public static final BitSet FOLLOW_inner_statement_list_in_while_statement2679 = new BitSet(new long[]{0x0000000000000000L,0x0000000080000000L});
    public static final BitSet FOLLOW_ENDWHILE_T_in_while_statement2682 = new BitSet(new long[]{0x0002000000000000L});
    public static final BitSet FOLLOW_SEMI_COLON_in_while_statement2684 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_statement_in_foreach_statement2720 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_COLON_T_in_foreach_statement2738 = new BitSet(new long[]{0xF74E800000000000L,0x000000010023FE7FL,0x1FC001C00078FBE3L});
    public static final BitSet FOLLOW_inner_statement_list_in_foreach_statement2740 = new BitSet(new long[]{0x0000000000000000L,0x0000000100000000L});
    public static final BitSet FOLLOW_ENDFOREACH_T_in_foreach_statement2743 = new BitSet(new long[]{0x0002000000000000L});
    public static final BitSet FOLLOW_SEMI_COLON_in_foreach_statement2745 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_statement_in_declare_statement2783 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_COLON_T_in_declare_statement2802 = new BitSet(new long[]{0xF74E800000000000L,0x000000020023FE7FL,0x1FC001C00078FBE3L});
    public static final BitSet FOLLOW_inner_statement_list_in_declare_statement2804 = new BitSet(new long[]{0x0000000000000000L,0x0000000200000000L});
    public static final BitSet FOLLOW_ENDDECLARE_T_in_declare_statement2807 = new BitSet(new long[]{0x0002000000000000L});
    public static final BitSet FOLLOW_SEMI_COLON_in_declare_statement2809 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_parameter_in_parameter_list2851 = new BitSet(new long[]{0x0000000000000002L,0x0000000000080000L});
    public static final BitSet FOLLOW_COMMA_T_in_parameter_list2854 = new BitSet(new long[]{0x0C08000000000000L,0x0000000000000000L,0x007FE00000080020L});
    public static final BitSet FOLLOW_parameter_in_parameter_list2858 = new BitSet(new long[]{0x0000000000000002L,0x0000000000080000L});
    public static final BitSet FOLLOW_parameter_type_in_parameter2908 = new BitSet(new long[]{0x0C00000000000000L,0x0000000000000000L,0x0000000000080000L});
    public static final BitSet FOLLOW_CONST_T_in_parameter2911 = new BitSet(new long[]{0x0400000000000000L,0x0000000000000000L,0x0000000000080000L});
    public static final BitSet FOLLOW_pure_variable_in_parameter2914 = new BitSet(new long[]{0x0000000000000002L,0x0000000000100000L});
    public static final BitSet FOLLOW_EQUAL_T_in_parameter2930 = new BitSet(new long[]{0x0008000000000000L,0x0000000000020000L,0x1F80000000700800L});
    public static final BitSet FOLLOW_scalar_in_parameter2932 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_fully_qualified_class_name_in_parameter_type2991 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_cast_option_in_parameter_type3001 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_variable_in_variable_list3032 = new BitSet(new long[]{0x0000000000000002L,0x0000000000080000L});
    public static final BitSet FOLLOW_COMMA_T_in_variable_list3035 = new BitSet(new long[]{0x0008000000000000L,0x0000000000000000L,0x0000000000080800L});
    public static final BitSet FOLLOW_variable_in_variable_list3039 = new BitSet(new long[]{0x0000000000000002L,0x0000000000080000L});
    public static final BitSet FOLLOW_169_in_variable_modifiers3070 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_modifier_in_variable_modifiers3076 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_modifier3090 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000010L,0x00001D8000000000L});
    public static final BitSet FOLLOW_directive_element_in_directive3153 = new BitSet(new long[]{0x0000000000000002L,0x0000000000080000L});
    public static final BitSet FOLLOW_COMMA_T_in_directive3156 = new BitSet(new long[]{0x0008000000000000L});
    public static final BitSet FOLLOW_directive_element_in_directive3160 = new BitSet(new long[]{0x0000000000000002L,0x0000000000080000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_directive_element3203 = new BitSet(new long[]{0x0000000000000000L,0x0000000000100000L});
    public static final BitSet FOLLOW_EQUAL_T_in_directive_element3205 = new BitSet(new long[]{0x0408800000000000L,0x0000000000020000L,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_expression_in_directive_element3207 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_expression_in_expr_list3252 = new BitSet(new long[]{0x0000000000000002L,0x0000000000080000L});
    public static final BitSet FOLLOW_COMMA_T_in_expr_list3255 = new BitSet(new long[]{0x0408800000000000L,0x0000000000020000L,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_expression_in_expr_list3259 = new BitSet(new long[]{0x0000000000000002L,0x0000000000080000L});
    public static final BitSet FOLLOW_logical_text_or_expr_in_expression3300 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_logical_text_xor_expr_in_logical_text_or_expr3343 = new BitSet(new long[]{0x0000000000000002L,0x0000000400000000L});
    public static final BitSet FOLLOW_OR_T_in_logical_text_or_expr3346 = new BitSet(new long[]{0x0408800000000000L,0x0000000000020000L,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_logical_text_xor_expr_in_logical_text_or_expr3351 = new BitSet(new long[]{0x0000000000000002L,0x0000000400000000L});
    public static final BitSet FOLLOW_logical_text_and_expr_in_logical_text_xor_expr3382 = new BitSet(new long[]{0x0000000000000002L,0x0000000800000000L});
    public static final BitSet FOLLOW_XOR_T_in_logical_text_xor_expr3385 = new BitSet(new long[]{0x0408800000000000L,0x0000000000020000L,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_logical_text_and_expr_in_logical_text_xor_expr3390 = new BitSet(new long[]{0x0000000000000002L,0x0000000800000000L});
    public static final BitSet FOLLOW_assignment_expr_in_logical_text_and_expr3421 = new BitSet(new long[]{0x0000000000000002L,0x0000001000000000L});
    public static final BitSet FOLLOW_AND_T_in_logical_text_and_expr3424 = new BitSet(new long[]{0x0408800000000000L,0x0000000000020000L,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_assignment_expr_in_logical_text_and_expr3429 = new BitSet(new long[]{0x0000000000000002L,0x0000001000000000L});
    public static final BitSet FOLLOW_conditional_expr_in_assignment_expr3460 = new BitSet(new long[]{0x0000000000000002L,0x0000FFE000100000L});
    public static final BitSet FOLLOW_assignment_operator_in_assignment_expr3463 = new BitSet(new long[]{0x0408800000000000L,0x0000000000020000L,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_conditional_expr_in_assignment_expr3468 = new BitSet(new long[]{0x0000000000000002L,0x0000FFE000100000L});
    public static final BitSet FOLLOW_set_in_assignment_operator0 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_logical_or_expr_in_conditional_expr3605 = new BitSet(new long[]{0x0000000000000002L,0x0001000000000000L});
    public static final BitSet FOLLOW_QUESTION_T_in_conditional_expr3624 = new BitSet(new long[]{0x0408800000000000L,0x0000000001020000L,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_expression_in_conditional_expr3626 = new BitSet(new long[]{0x0000000000000000L,0x0000000001000000L});
    public static final BitSet FOLLOW_COLON_T_in_conditional_expr3629 = new BitSet(new long[]{0x0408800000000000L,0x0000000000020000L,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_logical_or_expr_in_conditional_expr3633 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_logical_and_expr_in_logical_or_expr3683 = new BitSet(new long[]{0x0000000000000002L,0x0002000000000000L});
    public static final BitSet FOLLOW_LOGICAL_OR_T_in_logical_or_expr3686 = new BitSet(new long[]{0x0408800000000000L,0x0000000000020000L,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_logical_and_expr_in_logical_or_expr3691 = new BitSet(new long[]{0x0000000000000002L,0x0002000000000000L});
    public static final BitSet FOLLOW_bitwise_or_expr_in_logical_and_expr3722 = new BitSet(new long[]{0x0000000000000002L,0x0004000000000000L});
    public static final BitSet FOLLOW_LOGICAL_AND_T_in_logical_and_expr3725 = new BitSet(new long[]{0x0408800000000000L,0x0000000000020000L,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_bitwise_or_expr_in_logical_and_expr3730 = new BitSet(new long[]{0x0000000000000002L,0x0004000000000000L});
    public static final BitSet FOLLOW_bitwise_xor_expr_in_bitwise_or_expr3761 = new BitSet(new long[]{0x0000000000000002L,0x0008000000000000L});
    public static final BitSet FOLLOW_BIT_OR_T_in_bitwise_or_expr3764 = new BitSet(new long[]{0x0408800000000000L,0x0000000000020000L,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_bitwise_xor_expr_in_bitwise_or_expr3769 = new BitSet(new long[]{0x0000000000000002L,0x0008000000000000L});
    public static final BitSet FOLLOW_bitwise_and_expr_in_bitwise_xor_expr3800 = new BitSet(new long[]{0x0000000000000002L,0x0010000000000000L});
    public static final BitSet FOLLOW_POWER_T_in_bitwise_xor_expr3803 = new BitSet(new long[]{0x0408800000000000L,0x0000000000020000L,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_bitwise_and_expr_in_bitwise_xor_expr3808 = new BitSet(new long[]{0x0000000000000002L,0x0010000000000000L});
    public static final BitSet FOLLOW_concat_expr_in_bitwise_and_expr3839 = new BitSet(new long[]{0x0000000000000002L,0x0020000000000000L});
    public static final BitSet FOLLOW_DOT_T_in_bitwise_and_expr3842 = new BitSet(new long[]{0x0408800000000000L,0x0000000000020000L,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_concat_expr_in_bitwise_and_expr3847 = new BitSet(new long[]{0x0000000000000002L,0x0020000000000000L});
    public static final BitSet FOLLOW_equality_expr_in_concat_expr3878 = new BitSet(new long[]{0x0400000000000002L});
    public static final BitSet FOLLOW_REF_T_in_concat_expr3881 = new BitSet(new long[]{0x0408800000000000L,0x0000000000020000L,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_equality_expr_in_concat_expr3886 = new BitSet(new long[]{0x0400000000000002L});
    public static final BitSet FOLLOW_relational_expr_in_equality_expr3917 = new BitSet(new long[]{0x0000000000000002L,0x03C0000000000000L});
    public static final BitSet FOLLOW_set_in_equality_expr3920 = new BitSet(new long[]{0x0408800000000000L,0x0000000000020000L,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_relational_expr_in_equality_expr3939 = new BitSet(new long[]{0x0000000000000002L,0x03C0000000000000L});
    public static final BitSet FOLLOW_shift_expr_in_relational_expr3970 = new BitSet(new long[]{0x0000000000000002L,0x3C00000000000000L});
    public static final BitSet FOLLOW_set_in_relational_expr3973 = new BitSet(new long[]{0x0408800000000000L,0x0000000000020000L,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_shift_expr_in_relational_expr3992 = new BitSet(new long[]{0x0000000000000002L,0x3C00000000000000L});
    public static final BitSet FOLLOW_additive_expr_in_shift_expr4023 = new BitSet(new long[]{0x0000000000000002L,0xC000000000000000L});
    public static final BitSet FOLLOW_set_in_shift_expr4026 = new BitSet(new long[]{0x0408800000000000L,0x0000000000020000L,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_additive_expr_in_shift_expr4037 = new BitSet(new long[]{0x0000000000000002L,0xC000000000000000L});
    public static final BitSet FOLLOW_multiplicative_expr_in_additive_expr4068 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000000003L});
    public static final BitSet FOLLOW_set_in_additive_expr4071 = new BitSet(new long[]{0x0408800000000000L,0x0000000000020000L,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_multiplicative_expr_in_additive_expr4082 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000000003L});
    public static final BitSet FOLLOW_cast_expr_in_multiplicative_expr4113 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x000000000000001CL});
    public static final BitSet FOLLOW_set_in_multiplicative_expr4116 = new BitSet(new long[]{0x0408800000000000L,0x0000000000020000L,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_cast_expr_in_multiplicative_expr4131 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x000000000000001CL});
    public static final BitSet FOLLOW_unary_expr_in_cast_expr4160 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_cast_expr4171 = new BitSet(new long[]{0x0008000000000000L,0x0000000000000000L,0x007FE00000000020L});
    public static final BitSet FOLLOW_cast_option_in_cast_expr4173 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_cast_expr4175 = new BitSet(new long[]{0x0408800000000000L,0x0000000000020000L,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_unary_expr_in_cast_expr4179 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_cast_option0 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_unary_symbol_list_in_unary_expr4299 = new BitSet(new long[]{0x0408800000000000L,0x0000000000020000L,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_prefix_inc_dec_expr_in_unary_expr4301 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_prefix_inc_dec_expr_in_unary_expr4326 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_unary_symbol_in_unary_symbol_list4343 = new BitSet(new long[]{0x0400000000000002L,0x0000000000000000L,0x00000000000000C3L});
    public static final BitSet FOLLOW_set_in_unary_symbol0 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_post_inc_dec_expr_in_prefix_inc_dec_expr4400 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_plus_minus_in_prefix_inc_dec_expr4411 = new BitSet(new long[]{0x0408800000000000L,0x0000000000020000L,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_post_inc_dec_expr_in_prefix_inc_dec_expr4415 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_instance_expr_in_post_inc_dec_expr4460 = new BitSet(new long[]{0x0408800000000002L,0x0000000000020000L,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_plus_minus_in_post_inc_dec_expr4477 = new BitSet(new long[]{0x0408800000000002L,0x0000000000020000L,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_set_in_plus_minus0 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_atom_expr_in_instance_expr4544 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000000400L});
    public static final BitSet FOLLOW_INSTANCEOF_T_in_instance_expr4547 = new BitSet(new long[]{0x0008000000000000L,0x0000000000000000L,0x0000000000080800L});
    public static final BitSet FOLLOW_class_name_reference_in_instance_expr4550 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_AT_T_in_atom_expr4582 = new BitSet(new long[]{0x0008000000000000L,0x0000000000000000L,0x0000000000080800L});
    public static final BitSet FOLLOW_variable_in_atom_expr4585 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_AT_T_in_atom_expr4598 = new BitSet(new long[]{0x0008000000000000L,0x0000000000020000L,0x1F80000000700800L});
    public static final BitSet FOLLOW_scalar_in_atom_expr4601 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_atom_expr4614 = new BitSet(new long[]{0x0408800000000000L,0x0000000000020000L,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_expression_in_atom_expr4616 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_atom_expr4618 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LIST_T_in_atom_expr4631 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_atom_expr4633 = new BitSet(new long[]{0x0009000000000000L,0x0000000000080000L,0x0000000000081800L});
    public static final BitSet FOLLOW_assignment_list_in_atom_expr4635 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_atom_expr4637 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_182_in_atom_expr4664 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_atom_expr4666 = new BitSet(new long[]{0x0409800000000000L,0x0000000000020000L,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_array_pair_list_in_atom_expr4668 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_atom_expr4671 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NEW_T_in_atom_expr4700 = new BitSet(new long[]{0x0008000000000000L,0x0000000000000000L,0x0000000000080800L});
    public static final BitSet FOLLOW_class_name_reference_in_atom_expr4702 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_CLONE_T_in_atom_expr4729 = new BitSet(new long[]{0x0008000000000000L,0x0000000000000000L,0x0000000000080800L});
    public static final BitSet FOLLOW_variable_in_atom_expr4731 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_BACKTRICKLITERAL_in_atom_expr4767 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_PRINT_T_in_atom_expr4774 = new BitSet(new long[]{0x0408800000000000L,0x0000000000020000L,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_expression_in_atom_expr4776 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_dynamic_name_reference_in_class_name_reference4819 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_fully_qualified_class_name_in_class_name_reference4825 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_base_variable_with_function_calls_in_dynamic_name_reference4853 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000010000L});
    public static final BitSet FOLLOW_SINGLE_ARROW_T_in_dynamic_name_reference4878 = new BitSet(new long[]{0x0048000000000000L,0x0000000000000000L,0x0000000000080000L});
    public static final BitSet FOLLOW_object_property_in_dynamic_name_reference4880 = new BitSet(new long[]{0x0000800000000002L,0x0000000000000000L,0x0000000000010000L});
    public static final BitSet FOLLOW_ctor_arguments_in_dynamic_name_reference4882 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000010000L});
    public static final BitSet FOLLOW_assignment_element_in_assignment_list4933 = new BitSet(new long[]{0x0000000000000002L,0x0000000000080000L});
    public static final BitSet FOLLOW_COMMA_T_in_assignment_list4937 = new BitSet(new long[]{0x0008000000000002L,0x0000000000080000L,0x0000000000081800L});
    public static final BitSet FOLLOW_assignment_element_in_assignment_list4939 = new BitSet(new long[]{0x0000000000000002L,0x0000000000080000L});
    public static final BitSet FOLLOW_variable_in_assignment_element4963 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LIST_T_in_assignment_element4969 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_assignment_element4971 = new BitSet(new long[]{0x0009000000000000L,0x0000000000080000L,0x0000000000081800L});
    public static final BitSet FOLLOW_assignment_list_in_assignment_element4973 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_assignment_element4975 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_array_pair_element_in_array_pair_list5012 = new BitSet(new long[]{0x0000000000000002L,0x0000000000080000L});
    public static final BitSet FOLLOW_COMMA_T_in_array_pair_list5015 = new BitSet(new long[]{0x0408800000000000L,0x0000000000020000L,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_array_pair_element_in_array_pair_list5019 = new BitSet(new long[]{0x0000000000000002L,0x0000000000080000L});
    public static final BitSet FOLLOW_COMMA_T_in_array_pair_list5023 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_expression_in_array_pair_element5068 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000100L});
    public static final BitSet FOLLOW_ARROW_T_in_array_pair_element5071 = new BitSet(new long[]{0x0408800000000000L,0x0000000000020000L,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_expression_in_array_pair_element5076 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_base_variable_with_function_calls_in_variable5110 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000010000L});
    public static final BitSet FOLLOW_SINGLE_ARROW_T_in_variable5133 = new BitSet(new long[]{0x0048000000000000L,0x0000000000000000L,0x0000000000080000L});
    public static final BitSet FOLLOW_object_property_in_variable5135 = new BitSet(new long[]{0x0000800000000002L,0x0000000000000000L,0x0000000000010000L});
    public static final BitSet FOLLOW_ctor_arguments_in_variable5137 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000010000L});
    public static final BitSet FOLLOW_fully_qualified_class_name_in_base_variable_with_function_calls5194 = new BitSet(new long[]{0x0008000000000000L,0x0000000000000000L,0x0000000000080000L});
    public static final BitSet FOLLOW_reference_variable_in_base_variable_with_function_calls5197 = new BitSet(new long[]{0x0000800000000002L});
    public static final BitSet FOLLOW_ctor_arguments_in_base_variable_with_function_calls5199 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_fully_qualified_class_name_in_base_variable_with_function_calls5233 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_ctor_arguments_in_base_variable_with_function_calls5235 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_reference_variable_in_object_property5288 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_reference_variable_without_dollar_in_object_property5298 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_compound_variable_in_reference_variable5328 = new BitSet(new long[]{0x0040000000000002L,0x0000000000000000L,0x0000000000020000L});
    public static final BitSet FOLLOW_LEFT_OPEN_RECT_in_reference_variable5353 = new BitSet(new long[]{0x0408800000000000L,0x0000000000020000L,0x1FC00000007CFBE3L});
    public static final BitSet FOLLOW_expression_in_reference_variable5357 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000040000L});
    public static final BitSet FOLLOW_RIGHT_OPEN_RECT_in_reference_variable5360 = new BitSet(new long[]{0x0040000000000002L,0x0000000000000000L,0x0000000000020000L});
    public static final BitSet FOLLOW_LEFT_BRACKET_in_reference_variable5390 = new BitSet(new long[]{0x0408800000000000L,0x0000000000020000L,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_expression_in_reference_variable5394 = new BitSet(new long[]{0x0080000000000000L});
    public static final BitSet FOLLOW_RIGHT_BRACKET_in_reference_variable5396 = new BitSet(new long[]{0x0040000000000002L,0x0000000000000000L,0x0000000000020000L});
    public static final BitSet FOLLOW_DOLLAR_T_in_compound_variable5447 = new BitSet(new long[]{0x0008000000000000L,0x0000000000000000L,0x0000000000080000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_compound_variable5450 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_DOLLAR_T_in_compound_variable5462 = new BitSet(new long[]{0x0040000000000000L,0x0000000000000000L,0x0000000000080000L});
    public static final BitSet FOLLOW_LEFT_BRACKET_in_compound_variable5465 = new BitSet(new long[]{0x0408800000000000L,0x0000000000020000L,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_expression_in_compound_variable5468 = new BitSet(new long[]{0x0080000000000000L});
    public static final BitSet FOLLOW_RIGHT_BRACKET_in_compound_variable5470 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_compound_variable_without_dollar_in_reference_variable_without_dollar5503 = new BitSet(new long[]{0x0040000000000002L,0x0000000000000000L,0x0000000000020000L});
    public static final BitSet FOLLOW_LEFT_OPEN_RECT_in_reference_variable_without_dollar5532 = new BitSet(new long[]{0x0408800000000000L,0x0000000000020000L,0x1FC00000007CFBE3L});
    public static final BitSet FOLLOW_expression_in_reference_variable_without_dollar5534 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000040000L});
    public static final BitSet FOLLOW_RIGHT_OPEN_RECT_in_reference_variable_without_dollar5537 = new BitSet(new long[]{0x0040000000000002L,0x0000000000000000L,0x0000000000020000L});
    public static final BitSet FOLLOW_LEFT_BRACKET_in_reference_variable_without_dollar5568 = new BitSet(new long[]{0x0408800000000000L,0x0000000000020000L,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_expression_in_reference_variable_without_dollar5570 = new BitSet(new long[]{0x0080000000000000L});
    public static final BitSet FOLLOW_RIGHT_BRACKET_in_reference_variable_without_dollar5572 = new BitSet(new long[]{0x0040000000000002L,0x0000000000000000L,0x0000000000020000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_compound_variable_without_dollar5622 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LEFT_BRACKET_in_compound_variable_without_dollar5632 = new BitSet(new long[]{0x0408800000000000L,0x0000000000020000L,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_expression_in_compound_variable_without_dollar5635 = new BitSet(new long[]{0x0080000000000000L});
    public static final BitSet FOLLOW_RIGHT_BRACKET_in_compound_variable_without_dollar5637 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_ctor_arguments5668 = new BitSet(new long[]{0x0409800000000000L,0x0000000000020000L,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_expr_list_in_ctor_arguments5670 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_ctor_arguments5673 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_REF_T_in_pure_variable5719 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000080000L});
    public static final BitSet FOLLOW_DOLLAR_T_in_pure_variable5722 = new BitSet(new long[]{0x0008000000000000L,0x0000000000000000L,0x0000000000080000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_pure_variable5725 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_constant_in_scalar5777 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_INTLITERAL_in_constant5812 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_FLOATLITERAL_in_constant5821 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_STRINGLITERAL_in_constant5829 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_DOUBLELITERRAL_in_constant5838 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_common_scalar_in_constant5845 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_fully_qualified_class_name_in_constant5853 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_common_scalar0 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ELSEIF_T_in_synpred1_CompilerAst2105 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_LEFT_PARETHESIS_in_synpred1_CompilerAst2107 = new BitSet(new long[]{0x0408800000000000L,0x0000000000020000L,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_expression_in_synpred1_CompilerAst2111 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_RIGHT_PARETHESIS_in_synpred1_CompilerAst2113 = new BitSet(new long[]{0xF44A800000000000L,0x000000000023FE7FL,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_statement_in_synpred1_CompilerAst2117 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ELSE_T_in_synpred2_CompilerAst2143 = new BitSet(new long[]{0xF44A800000000000L,0x000000000023FE7FL,0x1FC000000078FBE3L});
    public static final BitSet FOLLOW_statement_in_synpred2_CompilerAst2147 = new BitSet(new long[]{0x0000000000000002L});

}