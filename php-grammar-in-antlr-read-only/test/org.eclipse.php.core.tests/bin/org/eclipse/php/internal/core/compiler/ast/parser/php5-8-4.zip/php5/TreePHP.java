// $ANTLR 3.1.3 Mar 17, 2009 19:23:44 /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g 2009-08-04 15:09:31

  package org.eclipse.php.internal.core.compiler.ast.parser.php5;
  
  import org.eclipse.dltk.ast.*;
import org.eclipse.dltk.ast.declarations.*;
import org.eclipse.dltk.ast.expressions.*;
import org.eclipse.dltk.ast.references.*;
import org.eclipse.dltk.ast.statements.*;
import org.eclipse.php.internal.core.compiler.ast.nodes.*;
import org.eclipse.php.internal.core.compiler.ast.parser.*;
import java.util.*;
import org.antlr.runtime.BitSet;


import org.antlr.runtime.*;
import org.antlr.runtime.tree.*;import java.util.Stack;
import java.util.List;
import java.util.ArrayList;


public class TreePHP extends TreeParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "ModuleDeclaration", "ClassDeclaration", "PROG", "CLASS_BODY", "FIELD_DECL", "METHOD_DECL", "TYPE", "PARAMETER", "BLOCK", "VAR_DECL", "STATEMENT", "CONDITION", "LIST", "INDEX", "MEMBERACCESS", "CALL", "ELIST", "EXPR", "ASSIGN", "LIST_DECL", "SCALAR_ELEMENT", "SCALAR_VAR", "CAST", "LABEL", "ITERATE", "USE_DECL", "ARGU", "CALLED_OBJ", "PREFIX", "POSTFIX", "NAMESPACE", "EMPTYSTATEMENT", "SCALAR", "ARRAY_DECL", "PREFIX_EXPR", "POSTFIX_EXPR", "CAST_EXPR", "VAR", "SOC_T", "SOC_PHP_T", "EOC_T", "LEFT_PARETHESIS", "RIGHT_PARETHESIS", "SEMI_COLON", "CLASS_T", "IDENTIFIER", "EXTENDS_T", "IMPLEMENTS_T", "LEFT_BRACKET", "RIGHT_BRACKET", "INTERFACE_T", "FUNCTION_T", "REF_T", "CONST_T", "WHILE_T", "DO_T", "FOR_T", "SWITCH_T", "BREAK_T", "CONTINUE_T", "RETURN_T", "GLOBAL_T", "STATIC_T", "ECHO_T", "FOREACH_T", "AS_T", "ARROW_T", "DECLARE_T", "TRY_T", "THROW_T", "USE_T", "STRINGLITERAL", "DOMAIN_T", "COMMA_T", "EQUAL_T", "IF_T", "ELSEIF_T", "ELSE_T", "COLON_T", "ENDIF_T", "ENDSWITCH_T", "CASE_T", "DEFAULT_T", "CATCH_T", "ENDFOR_T", "ENDWHILE_T", "ENDFOREACH_T", "ENDDECLARE_T", "OR_T", "XOR_T", "AND_T", "PLUS_EQ", "MINUS_EQ", "MUL_EQ", "DIV_EQ", "DOT_EQ", "PERCENT_EQ", "BIT_AND_EQ", "BIT_OR_EQ", "POWER_EQ", "LMOVE_EQ", "RMOVE_EQ", "QUESTION_T", "LOGICAL_OR_T", "LOGICAL_AND_T", "BIT_OR_T", "POWER_T", "DOT_T", "EQUAL_EQUAL_T", "NOT_EQUAL_T", "EQUAL_EQUAL_EQUAL_T", "NOT_EQUAL_EQUAL_T", "LT_T", "MT_T", "LE_T", "ME_T", "LSHIFT_T", "RSHIFT_T", "PLUS_T", "MINUS_T", "MUL_T", "DIV_T", "PERCENT_T", "UNSET_T", "CLONE_T", "TILDA_T", "EXC_NOT_T", "PLUS_PLUS_T", "MINUS_MINUS_T", "INSTANCEOF_T", "AT_T", "LIST_T", "NEW_T", "EXIT_T", "BACKTRICKLITERAL", "SINGLE_ARROW_T", "LEFT_OPEN_RECT", "RIGHT_OPEN_RECT", "DOLLAR_T", "INTLITERAL", "FLOATLITERAL", "DOUBLELITERRAL", "IntegerNumber", "LongSuffix", "HexPrefix", "HexDigit", "STATIC", "NonIntegerNumber", "FloatSuffix", "DoubleSuffix", "Exponent", "EscapeSequence", "IdentifierStart", "IdentifierPart", "WS", "COMMENT", "LINE_COMMENT", "'__halt_compiler'", "'abstract'", "'final'", "'var'", "'public'", "'protected'", "'private'", "'bool'", "'boolean'", "'int'", "'float'", "'double'", "'real'", "'string'", "'object'", "'array'", "'__CLASS__'", "'__DIR__'", "'__FILE__'", "'__FUNCTION__'", "'__METHOD__'", "'__NAMESPACE__'"
    };
    public static final int CAST=26;
    public static final int PREFIX=32;
    public static final int RIGHT_OPEN_RECT=141;
    public static final int XOR_T=93;
    public static final int TRY_T=72;
    public static final int POSTFIX=33;
    public static final int LOGICAL_OR_T=107;
    public static final int ENDFOR_T=88;
    public static final int PERCENT_EQ=100;
    public static final int AS_T=69;
    public static final int VAR_DECL=13;
    public static final int CONDITION=15;
    public static final int DIV_T=125;
    public static final int COMMA_T=77;
    public static final int DOMAIN_T=76;
    public static final int T__167=167;
    public static final int T__168=168;
    public static final int EOF=-1;
    public static final int T__165=165;
    public static final int EQUAL_EQUAL_T=112;
    public static final int STATIC_T=66;
    public static final int T__166=166;
    public static final int T__163=163;
    public static final int STATEMENT=14;
    public static final int DOT_T=111;
    public static final int T__164=164;
    public static final int T__161=161;
    public static final int TYPE=10;
    public static final int ENDIF_T=83;
    public static final int POSTFIX_EXPR=39;
    public static final int T__162=162;
    public static final int CALLED_OBJ=31;
    public static final int EOC_T=44;
    public static final int CAST_EXPR=40;
    public static final int DIV_EQ=98;
    public static final int NOT_EQUAL_EQUAL_T=115;
    public static final int GLOBAL_T=65;
    public static final int ELIST=20;
    public static final int IF_T=79;
    public static final int AT_T=134;
    public static final int FloatSuffix=152;
    public static final int NonIntegerNumber=151;
    public static final int MT_T=117;
    public static final int PARAMETER=11;
    public static final int AND_T=94;
    public static final int ELSE_T=81;
    public static final int SCALAR=36;
    public static final int RIGHT_BRACKET=53;
    public static final int SINGLE_ARROW_T=139;
    public static final int ARGU=30;
    public static final int VAR=41;
    public static final int FOR_T=60;
    public static final int RSHIFT_T=121;
    public static final int COMMENT=159;
    public static final int HexPrefix=148;
    public static final int MINUS_MINUS_T=132;
    public static final int ARROW_T=70;
    public static final int RMOVE_EQ=105;
    public static final int LINE_COMMENT=160;
    public static final int EQUAL_EQUAL_EQUAL_T=114;
    public static final int STATIC=150;
    public static final int CLONE_T=128;
    public static final int WHILE_T=58;
    public static final int ARRAY_DECL=37;
    public static final int MUL_EQ=97;
    public static final int IdentifierStart=156;
    public static final int DECLARE_T=71;
    public static final int SEMI_COLON=47;
    public static final int OR_T=92;
    public static final int INTERFACE_T=54;
    public static final int INTLITERAL=143;
    public static final int THROW_T=73;
    public static final int PLUS_EQ=95;
    public static final int LIST=16;
    public static final int REF_T=56;
    public static final int ENDDECLARE_T=91;
    public static final int PLUS_T=122;
    public static final int NAMESPACE=34;
    public static final int MINUS_EQ=96;
    public static final int LongSuffix=147;
    public static final int ENDFOREACH_T=90;
    public static final int EMPTYSTATEMENT=35;
    public static final int WS=158;
    public static final int DO_T=59;
    public static final int EQUAL_T=78;
    public static final int COLON_T=82;
    public static final int UNSET_T=127;
    public static final int NEW_T=136;
    public static final int USE_T=74;
    public static final int SOC_PHP_T=43;
    public static final int MINUS_T=123;
    public static final int MEMBERACCESS=18;
    public static final int PLUS_PLUS_T=131;
    public static final int CALL=19;
    public static final int SCALAR_ELEMENT=24;
    public static final int POWER_EQ=103;
    public static final int BIT_AND_EQ=101;
    public static final int EscapeSequence=155;
    public static final int CLASS_T=48;
    public static final int IntegerNumber=146;
    public static final int ECHO_T=67;
    public static final int LEFT_BRACKET=52;
    public static final int DOLLAR_T=142;
    public static final int DOUBLELITERRAL=145;
    public static final int SOC_T=42;
    public static final int METHOD_DECL=9;
    public static final int CATCH_T=87;
    public static final int Exponent=154;
    public static final int LE_T=118;
    public static final int PERCENT_T=126;
    public static final int IMPLEMENTS_T=51;
    public static final int HexDigit=149;
    public static final int DEFAULT_T=86;
    public static final int INDEX=17;
    public static final int PROG=6;
    public static final int EXPR=21;
    public static final int USE_DECL=29;
    public static final int NOT_EQUAL_T=113;
    public static final int POWER_T=110;
    public static final int IDENTIFIER=49;
    public static final int LEFT_OPEN_RECT=140;
    public static final int LMOVE_EQ=104;
    public static final int SCALAR_VAR=25;
    public static final int CONST_T=57;
    public static final int TILDA_T=129;
    public static final int IdentifierPart=157;
    public static final int FUNCTION_T=55;
    public static final int SWITCH_T=61;
    public static final int EXIT_T=137;
    public static final int MUL_T=124;
    public static final int LOGICAL_AND_T=108;
    public static final int QUESTION_T=106;
    public static final int LSHIFT_T=120;
    public static final int BIT_OR_EQ=102;
    public static final int BIT_OR_T=109;
    public static final int T__180=180;
    public static final int INSTANCEOF_T=133;
    public static final int FOREACH_T=68;
    public static final int ELSEIF_T=80;
    public static final int T__182=182;
    public static final int T__181=181;
    public static final int PREFIX_EXPR=38;
    public static final int FIELD_DECL=8;
    public static final int LT_T=116;
    public static final int CLASS_BODY=7;
    public static final int LIST_T=135;
    public static final int LIST_DECL=23;
    public static final int ModuleDeclaration=4;
    public static final int T__175=175;
    public static final int BACKTRICKLITERAL=138;
    public static final int T__174=174;
    public static final int ITERATE=28;
    public static final int T__173=173;
    public static final int T__172=172;
    public static final int RETURN_T=64;
    public static final int LEFT_PARETHESIS=45;
    public static final int T__179=179;
    public static final int T__178=178;
    public static final int T__177=177;
    public static final int T__176=176;
    public static final int ME_T=119;
    public static final int DoubleSuffix=153;
    public static final int LABEL=27;
    public static final int ENDWHILE_T=89;
    public static final int STRINGLITERAL=75;
    public static final int T__171=171;
    public static final int T__170=170;
    public static final int BLOCK=12;
    public static final int RIGHT_PARETHESIS=46;
    public static final int ASSIGN=22;
    public static final int EXC_NOT_T=130;
    public static final int BREAK_T=62;
    public static final int CASE_T=85;
    public static final int CONTINUE_T=63;
    public static final int EXTENDS_T=50;
    public static final int DOT_EQ=99;
    public static final int T__169=169;
    public static final int ClassDeclaration=5;
    public static final int FLOATLITERAL=144;
    public static final int ENDSWITCH_T=84;

    // delegates
    // delegators


        public TreePHP(TreeNodeStream input) {
            this(input, new RecognizerSharedState());
        }
        public TreePHP(TreeNodeStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        
    protected TreeAdaptor adaptor = new CommonTreeAdaptor();

    public void setTreeAdaptor(TreeAdaptor adaptor) {
        this.adaptor = adaptor;
    }
    public TreeAdaptor getTreeAdaptor() {
        return adaptor;
    }

    public String[] getTokenNames() { return TreePHP.tokenNames; }
    public String getGrammarFileName() { return "/home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g"; }


      ModuleDeclaration program;
      
      AbstractASTParser parser;
      
      boolean inExprList = false;
      
      boolean inClassStatementList = false;
        
      public TreePHP(TreeNodeStream input, AbstractASTParser parser) {
         this(input, new RecognizerSharedState());
         this.parser = parser;
      }
       
      public ModuleDeclaration getModuleDeclaration() {
        return program;
      }
      
      class ModifierDocPair {
        public int modifier;
        public PHPDocBlock doc;
        
        public ModifierDocPair(int modifier, PHPDocBlock doc) {
          this.modifier = modifier;
          this.doc = doc;
        }
      }
      
      public Expression createDispatch(Expression dispatcher, Expression property) {

        if (property.getKind() == ASTNodeKinds.REFLECTION_CALL_EXPRESSION) {
          ((ReflectionCallExpression) property).setReceiver (dispatcher);
          dispatcher = property;
        } else if (property.getKind() == ASTNodeKinds.METHOD_INVOCATION) {
          PHPCallExpression callExpression = (PHPCallExpression) property;
          dispatcher = new PHPCallExpression(dispatcher.sourceStart(), callExpression.sourceEnd(), dispatcher, callExpression.getCallName(), callExpression.getArgs());
        } else {
          dispatcher =  new FieldAccess(dispatcher.sourceStart(), property.sourceEnd(), dispatcher, property);
        }

        return dispatcher;
      }
      
        private List errors = new LinkedList();
        public void displayRecognitionError(String[] tokenNames,
                                            RecognitionException e) {
            String hdr = getErrorHeader(e);
            String msg = getErrorMessage(e, tokenNames);
            errors.add(hdr + " " + msg);
        }
        public List<String> getErrors() {
            return errors;
        }


    public static class php_source_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "php_source"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:82:1: php_source : ^( ModuleDeclaration ( top_statement_list )? ) ;
    public final TreePHP.php_source_return php_source() throws RecognitionException {
        TreePHP.php_source_return retval = new TreePHP.php_source_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST ModuleDeclaration1=null;
        TreePHP.top_statement_list_return top_statement_list2 = null;


        SLAST ModuleDeclaration1_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:83:3: ( ^( ModuleDeclaration ( top_statement_list )? ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:83:6: ^( ModuleDeclaration ( top_statement_list )? )
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_1 = _last;
            SLAST _first_1 = null;
            SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            ModuleDeclaration1=(SLAST)match(input,ModuleDeclaration,FOLLOW_ModuleDeclaration_in_php_source58); 
            ModuleDeclaration1_tree = (SLAST)adaptor.dupNode(ModuleDeclaration1);

            root_1 = (SLAST)adaptor.becomeRoot(ModuleDeclaration1_tree, root_1);



            if ( input.LA(1)==Token.DOWN ) {
                match(input, Token.DOWN, null); 
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:83:26: ( top_statement_list )?
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( (LA1_0==STATEMENT||LA1_0==CLASS_T||(LA1_0>=INTERFACE_T && LA1_0<=FUNCTION_T)||LA1_0==161) ) {
                    alt1=1;
                }
                switch (alt1) {
                    case 1 :
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:83:26: top_statement_list
                        {
                        _last = (SLAST)input.LT(1);
                        pushFollow(FOLLOW_top_statement_list_in_php_source60);
                        top_statement_list2=top_statement_list();

                        state._fsp--;

                        adaptor.addChild(root_1, top_statement_list2.getTree());

                        }
                        break;

                }


                match(input, Token.UP, null); 
            }adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


                ModuleDeclaration RESULT = null;
                int startIndex = ModuleDeclaration1.startIndex;
                int endIndex = ModuleDeclaration1.endIndex + 1;
             
                PHPModuleDeclaration program = parser.getModuleDeclaration();
            	  program.setStart(startIndex);
            	  program.setEnd(endIndex);
            	  RESULT = program;
            	  
            	  System.out.println("module: \n" + RESULT);
              

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "php_source"

    public static class top_statement_list_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "top_statement_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:99:1: top_statement_list : ( top_statement )+ ;
    public final TreePHP.top_statement_list_return top_statement_list() throws RecognitionException {
        TreePHP.top_statement_list_return retval = new TreePHP.top_statement_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.top_statement_return top_statement3 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:100:3: ( ( top_statement )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:100:5: ( top_statement )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:100:5: ( top_statement )+
            int cnt2=0;
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( (LA2_0==STATEMENT||LA2_0==CLASS_T||(LA2_0>=INTERFACE_T && LA2_0<=FUNCTION_T)||LA2_0==161) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:100:5: top_statement
            	    {
            	    _last = (SLAST)input.LT(1);
            	    pushFollow(FOLLOW_top_statement_in_top_statement_list80);
            	    top_statement3=top_statement();

            	    state._fsp--;

            	    adaptor.addChild(root_0, top_statement3.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt2 >= 1 ) break loop2;
                        EarlyExitException eee =
                            new EarlyExitException(2, input);
                        throw eee;
                }
                cnt2++;
            } while (true);


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "top_statement_list"

    public static class top_statement_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "top_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:103:1: top_statement : ( statement | function_declaration_statement | class_declaration_statement | halt_compiler_statement );
    public final TreePHP.top_statement_return top_statement() throws RecognitionException {
        TreePHP.top_statement_return retval = new TreePHP.top_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.statement_return statement4 = null;

        TreePHP.function_declaration_statement_return function_declaration_statement5 = null;

        TreePHP.class_declaration_statement_return class_declaration_statement6 = null;

        TreePHP.halt_compiler_statement_return halt_compiler_statement7 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:104:3: ( statement | function_declaration_statement | class_declaration_statement | halt_compiler_statement )
            int alt3=4;
            switch ( input.LA(1) ) {
            case STATEMENT:
                {
                alt3=1;
                }
                break;
            case FUNCTION_T:
                {
                alt3=2;
                }
                break;
            case CLASS_T:
            case INTERFACE_T:
                {
                alt3=3;
                }
                break;
            case 161:
                {
                alt3=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 3, 0, input);

                throw nvae;
            }

            switch (alt3) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:104:5: statement
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_statement_in_top_statement94);
                    statement4=statement();

                    state._fsp--;

                    adaptor.addChild(root_0, statement4.getTree());

                        Statement stat = (statement4!=null?statement4.stat:null);
                        parser.addStatement(stat);
                      

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:109:5: function_declaration_statement
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_function_declaration_statement_in_top_statement104);
                    function_declaration_statement5=function_declaration_statement();

                    state._fsp--;

                    adaptor.addChild(root_0, function_declaration_statement5.getTree());

                    }
                    break;
                case 3 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:110:5: class_declaration_statement
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_class_declaration_statement_in_top_statement110);
                    class_declaration_statement6=class_declaration_statement();

                    state._fsp--;

                    adaptor.addChild(root_0, class_declaration_statement6.getTree());

                        ClassDeclaration classDeclaration = (class_declaration_statement6!=null?class_declaration_statement6.classDeclaration:null);
                        parser.addDeclarationStatement(classDeclaration);
                        parser.declarations.push(classDeclaration);
                        parser.addStatement(classDeclaration);
                      

                    }
                    break;
                case 4 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:117:5: halt_compiler_statement
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_halt_compiler_statement_in_top_statement120);
                    halt_compiler_statement7=halt_compiler_statement();

                    state._fsp--;

                    adaptor.addChild(root_0, halt_compiler_statement7.getTree());

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "top_statement"

    protected static class inner_statement_list_scope {
        List list;
    }
    protected Stack inner_statement_list_stack = new Stack();

    public static class inner_statement_list_return extends TreeRuleReturnScope {
        public List innerStatementList;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "inner_statement_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:120:1: inner_statement_list returns [List innerStatementList] : ( inner_statement )+ ;
    public final TreePHP.inner_statement_list_return inner_statement_list() throws RecognitionException {
        inner_statement_list_stack.push(new inner_statement_list_scope());
        TreePHP.inner_statement_list_return retval = new TreePHP.inner_statement_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.inner_statement_return inner_statement8 = null;




          ((inner_statement_list_scope)inner_statement_list_stack.peek()).list = new LinkedList();

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:127:3: ( ( inner_statement )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:127:5: ( inner_statement )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:127:5: ( inner_statement )+
            int cnt4=0;
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( (LA4_0==STATEMENT||LA4_0==CLASS_T||(LA4_0>=INTERFACE_T && LA4_0<=FUNCTION_T)||LA4_0==161) ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:127:6: inner_statement
            	    {
            	    _last = (SLAST)input.LT(1);
            	    pushFollow(FOLLOW_inner_statement_in_inner_statement_list147);
            	    inner_statement8=inner_statement();

            	    state._fsp--;

            	    adaptor.addChild(root_0, inner_statement8.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt4 >= 1 ) break loop4;
                        EarlyExitException eee =
                            new EarlyExitException(4, input);
                        throw eee;
                }
                cnt4++;
            } while (true);


                retval.innerStatementList = ((inner_statement_list_scope)inner_statement_list_stack.peek()).list;
              

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
            inner_statement_list_stack.pop();
        }
        return retval;
    }
    // $ANTLR end "inner_statement_list"

    public static class inner_statement_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "inner_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:133:1: inner_statement : ( statement | function_declaration_statement | class_declaration_statement | halt_compiler_statement );
    public final TreePHP.inner_statement_return inner_statement() throws RecognitionException {
        TreePHP.inner_statement_return retval = new TreePHP.inner_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.statement_return statement9 = null;

        TreePHP.function_declaration_statement_return function_declaration_statement10 = null;

        TreePHP.class_declaration_statement_return class_declaration_statement11 = null;

        TreePHP.halt_compiler_statement_return halt_compiler_statement12 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:134:3: ( statement | function_declaration_statement | class_declaration_statement | halt_compiler_statement )
            int alt5=4;
            switch ( input.LA(1) ) {
            case STATEMENT:
                {
                alt5=1;
                }
                break;
            case FUNCTION_T:
                {
                alt5=2;
                }
                break;
            case CLASS_T:
            case INTERFACE_T:
                {
                alt5=3;
                }
                break;
            case 161:
                {
                alt5=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 5, 0, input);

                throw nvae;
            }

            switch (alt5) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:134:5: statement
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_statement_in_inner_statement169);
                    statement9=statement();

                    state._fsp--;

                    adaptor.addChild(root_0, statement9.getTree());

                        if ((statement9!=null?statement9.stat:null) != null) {
                          ((inner_statement_list_scope)inner_statement_list_stack.peek()).list.add((statement9!=null?statement9.stat:null));
                          System.out.println("inner state: " + (statement9!=null?statement9.stat:null));
                        }
                      

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:141:5: function_declaration_statement
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_function_declaration_statement_in_inner_statement179);
                    function_declaration_statement10=function_declaration_statement();

                    state._fsp--;

                    adaptor.addChild(root_0, function_declaration_statement10.getTree());

                    }
                    break;
                case 3 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:142:5: class_declaration_statement
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_class_declaration_statement_in_inner_statement185);
                    class_declaration_statement11=class_declaration_statement();

                    state._fsp--;

                    adaptor.addChild(root_0, class_declaration_statement11.getTree());

                    }
                    break;
                case 4 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:143:5: halt_compiler_statement
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_halt_compiler_statement_in_inner_statement191);
                    halt_compiler_statement12=halt_compiler_statement();

                    state._fsp--;

                    adaptor.addChild(root_0, halt_compiler_statement12.getTree());

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "inner_statement"

    public static class halt_compiler_statement_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "halt_compiler_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:146:1: halt_compiler_statement : '__halt_compiler' ;
    public final TreePHP.halt_compiler_statement_return halt_compiler_statement() throws RecognitionException {
        TreePHP.halt_compiler_statement_return retval = new TreePHP.halt_compiler_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST string_literal13=null;

        SLAST string_literal13_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:147:3: ( '__halt_compiler' )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:147:5: '__halt_compiler'
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            string_literal13=(SLAST)match(input,161,FOLLOW_161_in_halt_compiler_statement206); 
            string_literal13_tree = (SLAST)adaptor.dupNode(string_literal13);

            adaptor.addChild(root_0, string_literal13_tree);


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "halt_compiler_statement"

    public static class class_declaration_statement_return extends TreeRuleReturnScope {
        public ClassDeclaration classDeclaration;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "class_declaration_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:150:1: class_declaration_statement returns [ClassDeclaration classDeclaration] : ( ^( CLASS_T ( class_entr_type )? IDENTIFIER ( ^( EXTENDS_T fully_qualified_class_name ) )? ( ^( IMPLEMENTS_T fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? ) | ^( INTERFACE_T IDENTIFIER ( ^( EXTENDS_T fully_qualified_class_name_list ) )? ( ^( IMPLEMENTS_T fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? ) );
    public final TreePHP.class_declaration_statement_return class_declaration_statement() throws RecognitionException {
        TreePHP.class_declaration_statement_return retval = new TreePHP.class_declaration_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST CLASS_T14=null;
        SLAST IDENTIFIER16=null;
        SLAST EXTENDS_T17=null;
        SLAST IMPLEMENTS_T19=null;
        SLAST CLASS_BODY21=null;
        SLAST INTERFACE_T23=null;
        SLAST IDENTIFIER24=null;
        SLAST EXTENDS_T25=null;
        SLAST IMPLEMENTS_T27=null;
        SLAST CLASS_BODY29=null;
        TreePHP.class_entr_type_return class_entr_type15 = null;

        TreePHP.fully_qualified_class_name_return fully_qualified_class_name18 = null;

        TreePHP.fully_qualified_class_name_list_return fully_qualified_class_name_list20 = null;

        TreePHP.class_statement_list_return class_statement_list22 = null;

        TreePHP.fully_qualified_class_name_list_return fully_qualified_class_name_list26 = null;

        TreePHP.fully_qualified_class_name_list_return fully_qualified_class_name_list28 = null;

        TreePHP.class_statement_list_return class_statement_list30 = null;


        SLAST CLASS_T14_tree=null;
        SLAST IDENTIFIER16_tree=null;
        SLAST EXTENDS_T17_tree=null;
        SLAST IMPLEMENTS_T19_tree=null;
        SLAST CLASS_BODY21_tree=null;
        SLAST INTERFACE_T23_tree=null;
        SLAST IDENTIFIER24_tree=null;
        SLAST EXTENDS_T25_tree=null;
        SLAST IMPLEMENTS_T27_tree=null;
        SLAST CLASS_BODY29_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:151:3: ( ^( CLASS_T ( class_entr_type )? IDENTIFIER ( ^( EXTENDS_T fully_qualified_class_name ) )? ( ^( IMPLEMENTS_T fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? ) | ^( INTERFACE_T IDENTIFIER ( ^( EXTENDS_T fully_qualified_class_name_list ) )? ( ^( IMPLEMENTS_T fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? ) )
            int alt13=2;
            int LA13_0 = input.LA(1);

            if ( (LA13_0==CLASS_T) ) {
                alt13=1;
            }
            else if ( (LA13_0==INTERFACE_T) ) {
                alt13=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 13, 0, input);

                throw nvae;
            }
            switch (alt13) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:151:5: ^( CLASS_T ( class_entr_type )? IDENTIFIER ( ^( EXTENDS_T fully_qualified_class_name ) )? ( ^( IMPLEMENTS_T fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    CLASS_T14=(SLAST)match(input,CLASS_T,FOLLOW_CLASS_T_in_class_declaration_statement226); 
                    CLASS_T14_tree = (SLAST)adaptor.dupNode(CLASS_T14);

                    root_1 = (SLAST)adaptor.becomeRoot(CLASS_T14_tree, root_1);



                    match(input, Token.DOWN, null); 
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:151:15: ( class_entr_type )?
                    int alt6=2;
                    int LA6_0 = input.LA(1);

                    if ( ((LA6_0>=162 && LA6_0<=163)) ) {
                        alt6=1;
                    }
                    switch (alt6) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:151:15: class_entr_type
                            {
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_class_entr_type_in_class_declaration_statement228);
                            class_entr_type15=class_entr_type();

                            state._fsp--;

                            adaptor.addChild(root_1, class_entr_type15.getTree());

                            }
                            break;

                    }

                    _last = (SLAST)input.LT(1);
                    IDENTIFIER16=(SLAST)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_class_declaration_statement231); 
                    IDENTIFIER16_tree = (SLAST)adaptor.dupNode(IDENTIFIER16);

                    adaptor.addChild(root_1, IDENTIFIER16_tree);


                          TreePHP.ModifierDocPair modifier = new ModifierDocPair(Modifiers.AccDefault, null);
                          int startIndex = CLASS_T14.startIndex;
                          int endIndex = CLASS_T14.endIndex + 1;
                          if ((class_entr_type15!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(class_entr_type15.start),
                      input.getTreeAdaptor().getTokenStopIndex(class_entr_type15.start))):null) != null) {
                              if ((class_entr_type15!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(class_entr_type15.start),
                      input.getTreeAdaptor().getTokenStopIndex(class_entr_type15.start))):null).equals("abstract")) {
                                modifier = new ModifierDocPair(Modifiers.AccAbstract, null);
                              }
                          }
                          
                          CommonToken token = (CommonToken)IDENTIFIER16.token;
                          int classNameLeft = token.getStartIndex();
                          int classNameRight = token.getStopIndex();
                          String className = (IDENTIFIER16!=null?IDENTIFIER16.getText():null);
                          
                          retval.classDeclaration = new ClassDeclaration(startIndex ,endIndex, classNameLeft, classNameRight, modifier.modifier, className, null, null, new Block(classNameRight,classNameRight,null), null);
                          parser.addDeclarationStatement(retval.classDeclaration);
                          parser.declarations.push(retval.classDeclaration);
                      
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:172:4: ( ^( EXTENDS_T fully_qualified_class_name ) )?
                    int alt7=2;
                    int LA7_0 = input.LA(1);

                    if ( (LA7_0==EXTENDS_T) ) {
                        alt7=1;
                    }
                    switch (alt7) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:172:5: ^( EXTENDS_T fully_qualified_class_name )
                            {
                            _last = (SLAST)input.LT(1);
                            {
                            SLAST _save_last_2 = _last;
                            SLAST _first_2 = null;
                            SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                            EXTENDS_T17=(SLAST)match(input,EXTENDS_T,FOLLOW_EXTENDS_T_in_class_declaration_statement245); 
                            EXTENDS_T17_tree = (SLAST)adaptor.dupNode(EXTENDS_T17);

                            root_2 = (SLAST)adaptor.becomeRoot(EXTENDS_T17_tree, root_2);



                            match(input, Token.DOWN, null); 
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_fully_qualified_class_name_in_class_declaration_statement247);
                            fully_qualified_class_name18=fully_qualified_class_name();

                            state._fsp--;

                            adaptor.addChild(root_2, fully_qualified_class_name18.getTree());

                            match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
                            }


                            }
                            break;

                    }

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:172:47: ( ^( IMPLEMENTS_T fully_qualified_class_name_list ) )?
                    int alt8=2;
                    int LA8_0 = input.LA(1);

                    if ( (LA8_0==IMPLEMENTS_T) ) {
                        alt8=1;
                    }
                    switch (alt8) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:172:48: ^( IMPLEMENTS_T fully_qualified_class_name_list )
                            {
                            _last = (SLAST)input.LT(1);
                            {
                            SLAST _save_last_2 = _last;
                            SLAST _first_2 = null;
                            SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                            IMPLEMENTS_T19=(SLAST)match(input,IMPLEMENTS_T,FOLLOW_IMPLEMENTS_T_in_class_declaration_statement254); 
                            IMPLEMENTS_T19_tree = (SLAST)adaptor.dupNode(IMPLEMENTS_T19);

                            root_2 = (SLAST)adaptor.becomeRoot(IMPLEMENTS_T19_tree, root_2);



                            match(input, Token.DOWN, null); 
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_fully_qualified_class_name_list_in_class_declaration_statement256);
                            fully_qualified_class_name_list20=fully_qualified_class_name_list();

                            state._fsp--;

                            adaptor.addChild(root_2, fully_qualified_class_name_list20.getTree());

                            match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
                            }


                            }
                            break;

                    }

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:173:7: ( ^( CLASS_BODY class_statement_list ) )?
                    int alt9=2;
                    int LA9_0 = input.LA(1);

                    if ( (LA9_0==CLASS_BODY) ) {
                        alt9=1;
                    }
                    switch (alt9) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:173:8: ^( CLASS_BODY class_statement_list )
                            {
                            _last = (SLAST)input.LT(1);
                            {
                            SLAST _save_last_2 = _last;
                            SLAST _first_2 = null;
                            SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                            CLASS_BODY21=(SLAST)match(input,CLASS_BODY,FOLLOW_CLASS_BODY_in_class_declaration_statement269); 
                            CLASS_BODY21_tree = (SLAST)adaptor.dupNode(CLASS_BODY21);

                            root_2 = (SLAST)adaptor.becomeRoot(CLASS_BODY21_tree, root_2);



                            match(input, Token.DOWN, null); 
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_class_statement_list_in_class_declaration_statement271);
                            class_statement_list22=class_statement_list();

                            state._fsp--;

                            adaptor.addChild(root_2, class_statement_list22.getTree());

                            match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
                            }


                            }
                            break;

                    }


                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                          
                          TreePHP.ModifierDocPair modifier = new ModifierDocPair(Modifiers.AccDefault, null);
                          int startIndex = CLASS_T14.startIndex;
                          int endIndex = CLASS_T14.endIndex + 1;
                          if ((class_entr_type15!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(class_entr_type15.start),
                      input.getTreeAdaptor().getTokenStopIndex(class_entr_type15.start))):null) != null) {
                              if ((class_entr_type15!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(class_entr_type15.start),
                      input.getTreeAdaptor().getTokenStopIndex(class_entr_type15.start))):null).equals("abstract")) {
                                modifier = new ModifierDocPair(Modifiers.AccAbstract, null);
                              }
                          }
                          
                          CommonToken token = (CommonToken)IDENTIFIER16.token;
                          int classNameLeft = token.getStartIndex();
                          int classNameRight = token.getStopIndex();
                          String className = (IDENTIFIER16!=null?IDENTIFIER16.getText():null);
                          
                    //      retval.classDeclaration = new ClassDeclaration(startIndex ,endIndex, classNameLeft, classNameRight, modifier.modifier, className, null, null, new Block(classNameRight,classNameRight,null), null);
                    //      parser.addDeclarationStatement(retval.classDeclaration);
                    //      parser.declarations.push(retval.classDeclaration);
                          
                          TypeReference superClass = null;
                          int superClassLeft = 0;
                          int superClassRight = 0;
                          if ((fully_qualified_class_name18!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(fully_qualified_class_name18.start),
                      input.getTreeAdaptor().getTokenStopIndex(fully_qualified_class_name18.start))):null) != null) {
                              superClassLeft = ((CommonToken)(fully_qualified_class_name18!=null?((SLAST)fully_qualified_class_name18.tree):null).token).getStartIndex();
                              superClassRight = ((CommonToken)(fully_qualified_class_name18!=null?((SLAST)fully_qualified_class_name18.tree):null).token).getStopIndex();
                              superClass = (fully_qualified_class_name18!=null?fully_qualified_class_name18.type:null);
                          }
                          
                          List interfaces = null;
                          int interfacesLeft = 0;
                          int interfacesRight = 0;
                          if ((fully_qualified_class_name_list20!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(fully_qualified_class_name_list20.start),
                      input.getTreeAdaptor().getTokenStopIndex(fully_qualified_class_name_list20.start))):null) != null) {
                              interfacesLeft = ((CommonToken)(fully_qualified_class_name_list20!=null?((SLAST)fully_qualified_class_name_list20.tree):null).token).getStartIndex();
                              interfacesRight = ((CommonToken)(fully_qualified_class_name_list20!=null?((SLAST)fully_qualified_class_name_list20.tree):null).token).getStopIndex();
                          }
                          
                          retval.classDeclaration = (ClassDeclaration)parser.declarations.peek();
                    		  if (superClass != null) {
                    		    retval.classDeclaration.setSuperClass(superClass);
                    		  }
                    		  if (interfaces != null) {
                    		    retval.classDeclaration.setInterfaceList(interfaces);
                    		  }
                        
                          int blockEndLeft = 0;
                          int blockEndRight = 1;
                        
                          retval.classDeclaration = (ClassDeclaration)parser.declarations.pop();
                          if ((class_statement_list22!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(class_statement_list22.start),
                      input.getTreeAdaptor().getTokenStopIndex(class_statement_list22.start))):null) != null) {
                    		      retval.classDeclaration.getBody().setStart(blockEndLeft);
                    		      retval.classDeclaration.getBody().setEnd(blockEndRight);
                    		  }
                        

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:228:5: ^( INTERFACE_T IDENTIFIER ( ^( EXTENDS_T fully_qualified_class_name_list ) )? ( ^( IMPLEMENTS_T fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    INTERFACE_T23=(SLAST)match(input,INTERFACE_T,FOLLOW_INTERFACE_T_in_class_declaration_statement288); 
                    INTERFACE_T23_tree = (SLAST)adaptor.dupNode(INTERFACE_T23);

                    root_1 = (SLAST)adaptor.becomeRoot(INTERFACE_T23_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    IDENTIFIER24=(SLAST)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_class_declaration_statement290); 
                    IDENTIFIER24_tree = (SLAST)adaptor.dupNode(IDENTIFIER24);

                    adaptor.addChild(root_1, IDENTIFIER24_tree);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:228:30: ( ^( EXTENDS_T fully_qualified_class_name_list ) )?
                    int alt10=2;
                    int LA10_0 = input.LA(1);

                    if ( (LA10_0==EXTENDS_T) ) {
                        alt10=1;
                    }
                    switch (alt10) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:228:31: ^( EXTENDS_T fully_qualified_class_name_list )
                            {
                            _last = (SLAST)input.LT(1);
                            {
                            SLAST _save_last_2 = _last;
                            SLAST _first_2 = null;
                            SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                            EXTENDS_T25=(SLAST)match(input,EXTENDS_T,FOLLOW_EXTENDS_T_in_class_declaration_statement294); 
                            EXTENDS_T25_tree = (SLAST)adaptor.dupNode(EXTENDS_T25);

                            root_2 = (SLAST)adaptor.becomeRoot(EXTENDS_T25_tree, root_2);



                            match(input, Token.DOWN, null); 
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_fully_qualified_class_name_list_in_class_declaration_statement296);
                            fully_qualified_class_name_list26=fully_qualified_class_name_list();

                            state._fsp--;

                            adaptor.addChild(root_2, fully_qualified_class_name_list26.getTree());

                            match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
                            }


                            }
                            break;

                    }

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:228:78: ( ^( IMPLEMENTS_T fully_qualified_class_name_list ) )?
                    int alt11=2;
                    int LA11_0 = input.LA(1);

                    if ( (LA11_0==IMPLEMENTS_T) ) {
                        alt11=1;
                    }
                    switch (alt11) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:228:79: ^( IMPLEMENTS_T fully_qualified_class_name_list )
                            {
                            _last = (SLAST)input.LT(1);
                            {
                            SLAST _save_last_2 = _last;
                            SLAST _first_2 = null;
                            SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                            IMPLEMENTS_T27=(SLAST)match(input,IMPLEMENTS_T,FOLLOW_IMPLEMENTS_T_in_class_declaration_statement303); 
                            IMPLEMENTS_T27_tree = (SLAST)adaptor.dupNode(IMPLEMENTS_T27);

                            root_2 = (SLAST)adaptor.becomeRoot(IMPLEMENTS_T27_tree, root_2);



                            match(input, Token.DOWN, null); 
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_fully_qualified_class_name_list_in_class_declaration_statement305);
                            fully_qualified_class_name_list28=fully_qualified_class_name_list();

                            state._fsp--;

                            adaptor.addChild(root_2, fully_qualified_class_name_list28.getTree());

                            match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
                            }


                            }
                            break;

                    }

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:229:7: ( ^( CLASS_BODY class_statement_list ) )?
                    int alt12=2;
                    int LA12_0 = input.LA(1);

                    if ( (LA12_0==CLASS_BODY) ) {
                        alt12=1;
                    }
                    switch (alt12) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:229:8: ^( CLASS_BODY class_statement_list )
                            {
                            _last = (SLAST)input.LT(1);
                            {
                            SLAST _save_last_2 = _last;
                            SLAST _first_2 = null;
                            SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                            CLASS_BODY29=(SLAST)match(input,CLASS_BODY,FOLLOW_CLASS_BODY_in_class_declaration_statement318); 
                            CLASS_BODY29_tree = (SLAST)adaptor.dupNode(CLASS_BODY29);

                            root_2 = (SLAST)adaptor.becomeRoot(CLASS_BODY29_tree, root_2);



                            match(input, Token.DOWN, null); 
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_class_statement_list_in_class_declaration_statement320);
                            class_statement_list30=class_statement_list();

                            state._fsp--;

                            adaptor.addChild(root_2, class_statement_list30.getTree());

                            match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
                            }


                            }
                            break;

                    }


                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "class_declaration_statement"

    public static class class_entr_type_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "class_entr_type"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:232:1: class_entr_type : ( 'abstract' | 'final' );
    public final TreePHP.class_entr_type_return class_entr_type() throws RecognitionException {
        TreePHP.class_entr_type_return retval = new TreePHP.class_entr_type_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST set31=null;

        SLAST set31_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:233:3: ( 'abstract' | 'final' )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            set31=(SLAST)input.LT(1);
            if ( (input.LA(1)>=162 && input.LA(1)<=163) ) {
                input.consume();

                set31_tree = (SLAST)adaptor.dupNode(set31);

                adaptor.addChild(root_0, set31_tree);

                state.errorRecovery=false;
            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                throw mse;
            }

             

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "class_entr_type"

    public static class class_statement_list_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "class_statement_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:237:1: class_statement_list : ( class_statement )+ ;
    public final TreePHP.class_statement_list_return class_statement_list() throws RecognitionException {
        TreePHP.class_statement_list_return retval = new TreePHP.class_statement_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.class_statement_return class_statement32 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:238:3: ( ( class_statement )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:238:5: ( class_statement )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:238:5: ( class_statement )+
            int cnt14=0;
            loop14:
            do {
                int alt14=2;
                int LA14_0 = input.LA(1);

                if ( ((LA14_0>=FIELD_DECL && LA14_0<=METHOD_DECL)) ) {
                    alt14=1;
                }


                switch (alt14) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:238:5: class_statement
            	    {
            	    _last = (SLAST)input.LT(1);
            	    pushFollow(FOLLOW_class_statement_in_class_statement_list360);
            	    class_statement32=class_statement();

            	    state._fsp--;

            	    adaptor.addChild(root_0, class_statement32.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt14 >= 1 ) break loop14;
                        EarlyExitException eee =
                            new EarlyExitException(14, input);
                        throw eee;
                }
                cnt14++;
            } while (true);


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "class_statement_list"

    protected static class class_statement_scope {
        List constList;
        List varList;
    }
    protected Stack class_statement_stack = new Stack();

    public static class class_statement_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "class_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:241:1: class_statement : ( ^( FIELD_DECL variable_modifiers ( static_var_element )+ ) | ^( METHOD_DECL modifier ( REF_T )? IDENTIFIER ( parameter_list )? ( block | EMPTYSTATEMENT ) ) | ^( FIELD_DECL CONST_T ( directive )+ ) );
    public final TreePHP.class_statement_return class_statement() throws RecognitionException {
        class_statement_stack.push(new class_statement_scope());
        TreePHP.class_statement_return retval = new TreePHP.class_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST FIELD_DECL33=null;
        SLAST METHOD_DECL36=null;
        SLAST REF_T38=null;
        SLAST IDENTIFIER39=null;
        SLAST EMPTYSTATEMENT42=null;
        SLAST FIELD_DECL43=null;
        SLAST CONST_T44=null;
        TreePHP.variable_modifiers_return variable_modifiers34 = null;

        TreePHP.static_var_element_return static_var_element35 = null;

        TreePHP.modifier_return modifier37 = null;

        TreePHP.parameter_list_return parameter_list40 = null;

        TreePHP.block_return block41 = null;

        TreePHP.directive_return directive45 = null;


        SLAST FIELD_DECL33_tree=null;
        SLAST METHOD_DECL36_tree=null;
        SLAST REF_T38_tree=null;
        SLAST IDENTIFIER39_tree=null;
        SLAST EMPTYSTATEMENT42_tree=null;
        SLAST FIELD_DECL43_tree=null;
        SLAST CONST_T44_tree=null;


          ((class_statement_scope)class_statement_stack.peek()).constList = new LinkedList();
          ((class_statement_scope)class_statement_stack.peek()).varList = new LinkedList();

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:250:3: ( ^( FIELD_DECL variable_modifiers ( static_var_element )+ ) | ^( METHOD_DECL modifier ( REF_T )? IDENTIFIER ( parameter_list )? ( block | EMPTYSTATEMENT ) ) | ^( FIELD_DECL CONST_T ( directive )+ ) )
            int alt20=3;
            int LA20_0 = input.LA(1);

            if ( (LA20_0==FIELD_DECL) ) {
                int LA20_1 = input.LA(2);

                if ( (LA20_1==DOWN) ) {
                    int LA20_3 = input.LA(3);

                    if ( (LA20_3==VAR_DECL||LA20_3==STATIC_T||LA20_3==EQUAL_T||(LA20_3>=162 && LA20_3<=167)) ) {
                        alt20=1;
                    }
                    else if ( (LA20_3==CONST_T) ) {
                        alt20=3;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 20, 3, input);

                        throw nvae;
                    }
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 20, 1, input);

                    throw nvae;
                }
            }
            else if ( (LA20_0==METHOD_DECL) ) {
                alt20=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 20, 0, input);

                throw nvae;
            }
            switch (alt20) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:250:5: ^( FIELD_DECL variable_modifiers ( static_var_element )+ )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    FIELD_DECL33=(SLAST)match(input,FIELD_DECL,FOLLOW_FIELD_DECL_in_class_statement385); 
                    FIELD_DECL33_tree = (SLAST)adaptor.dupNode(FIELD_DECL33);

                    root_1 = (SLAST)adaptor.becomeRoot(FIELD_DECL33_tree, root_1);


                    inClassStatementList = true;

                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_variable_modifiers_in_class_statement389);
                    variable_modifiers34=variable_modifiers();

                    state._fsp--;

                    adaptor.addChild(root_1, variable_modifiers34.getTree());
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:250:68: ( static_var_element )+
                    int cnt15=0;
                    loop15:
                    do {
                        int alt15=2;
                        int LA15_0 = input.LA(1);

                        if ( (LA15_0==VAR_DECL||LA15_0==EQUAL_T) ) {
                            alt15=1;
                        }


                        switch (alt15) {
                    	case 1 :
                    	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:250:68: static_var_element
                    	    {
                    	    _last = (SLAST)input.LT(1);
                    	    pushFollow(FOLLOW_static_var_element_in_class_statement391);
                    	    static_var_element35=static_var_element();

                    	    state._fsp--;

                    	    adaptor.addChild(root_1, static_var_element35.getTree());

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt15 >= 1 ) break loop15;
                                EarlyExitException eee =
                                    new EarlyExitException(15, input);
                                throw eee;
                        }
                        cnt15++;
                    } while (true);

                    inClassStatementList = false;

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        ModifierDocPair modifier = new ModifierDocPair(Modifiers.AccDefault, null);
                        int modifierLeft = ((CommonToken)(variable_modifiers34!=null?((SLAST)variable_modifiers34.tree):null).token).getStartIndex();
                        if ((variable_modifiers34!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(variable_modifiers34.start),
                      input.getTreeAdaptor().getTokenStopIndex(variable_modifiers34.start))):null).equals("var")) {
                          modifier = new ModifierDocPair(Modifiers.AccPublic, null);
                        }
                        
                        Iterator iter = ((class_statement_scope)class_statement_stack.peek()).varList.iterator();
                        while (iter.hasNext()) {
                    	    ASTNode[] decl = (ASTNode[])iter.next();
                    	    if (decl != null) {
                    		    VariableReference variable = (VariableReference)decl[0];
                    		    Expression initializer = (Expression)decl[1];
                    		    int start = variable.sourceStart();
                    		    int end = (initializer == null ? variable.sourceEnd() : initializer.sourceEnd());
                    		    parser.addDeclarationStatement(new PHPFieldDeclaration(variable, initializer, start, end, modifier.modifier, modifierLeft, modifier.doc));
                    		  }
                    		}
                      

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:270:5: ^( METHOD_DECL modifier ( REF_T )? IDENTIFIER ( parameter_list )? ( block | EMPTYSTATEMENT ) )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    METHOD_DECL36=(SLAST)match(input,METHOD_DECL,FOLLOW_METHOD_DECL_in_class_statement406); 
                    METHOD_DECL36_tree = (SLAST)adaptor.dupNode(METHOD_DECL36);

                    root_1 = (SLAST)adaptor.becomeRoot(METHOD_DECL36_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_modifier_in_class_statement408);
                    modifier37=modifier();

                    state._fsp--;

                    adaptor.addChild(root_1, modifier37.getTree());
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:270:28: ( REF_T )?
                    int alt16=2;
                    int LA16_0 = input.LA(1);

                    if ( (LA16_0==REF_T) ) {
                        alt16=1;
                    }
                    switch (alt16) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:270:28: REF_T
                            {
                            _last = (SLAST)input.LT(1);
                            REF_T38=(SLAST)match(input,REF_T,FOLLOW_REF_T_in_class_statement410); 
                            REF_T38_tree = (SLAST)adaptor.dupNode(REF_T38);

                            adaptor.addChild(root_1, REF_T38_tree);


                            }
                            break;

                    }

                    _last = (SLAST)input.LT(1);
                    IDENTIFIER39=(SLAST)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_class_statement413); 
                    IDENTIFIER39_tree = (SLAST)adaptor.dupNode(IDENTIFIER39);

                    adaptor.addChild(root_1, IDENTIFIER39_tree);


                          ModifierDocPair modifier = new ModifierDocPair(Modifiers.AccDefault, null);
                          PHPDocBlock start = null;
                          Boolean isReference = false;
                          if ((REF_T38!=null?REF_T38.getText():null) != null) {
                             isReference = true;
                          }
                          int functionNameLeft = ((CommonToken)IDENTIFIER39.token).getStartIndex();
                          int functionNameRight = ((CommonToken)IDENTIFIER39.token).getStopIndex();
                          String functionName = (IDENTIFIER39!=null?IDENTIFIER39.getText():null);
                      
                          int startIndex = METHOD_DECL36.startIndex;
                          int endIndex = METHOD_DECL36.endIndex + 1;
                          int modifierValue = modifier == null ? Modifiers.AccPublic : modifier.modifier;
                          
                          PHPDocBlock docBlock = start;
                          if (modifier != null && modifier.doc != null) {
                            docBlock = modifier.doc;
                          }
                          PHPMethodDeclaration methodDeclaration = new PHPMethodDeclaration(startIndex, endIndex, functionNameLeft, functionNameRight, functionName, modifierValue, null, new Block(functionNameLeft, functionNameRight, null), isReference.booleanValue(), docBlock);
                          parser.addDeclarationStatement(methodDeclaration);
                          parser.declarations.push(methodDeclaration);
                        
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:294:7: ( parameter_list )?
                    int alt17=2;
                    int LA17_0 = input.LA(1);

                    if ( (LA17_0==PARAMETER) ) {
                        alt17=1;
                    }
                    switch (alt17) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:294:7: parameter_list
                            {
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_parameter_list_in_class_statement427);
                            parameter_list40=parameter_list();

                            state._fsp--;

                            adaptor.addChild(root_1, parameter_list40.getTree());

                            }
                            break;

                    }


                            if ((parameter_list40!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(parameter_list40.start),
                      input.getTreeAdaptor().getTokenStopIndex(parameter_list40.start))):null) != null) {
                              PHPMethodDeclaration functionDeclaration = (PHPMethodDeclaration)parser.declarations.peek();
                    				  functionDeclaration.acceptArguments((parameter_list40!=null?parameter_list40.parameterList:null));
                            }
                          
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:301:5: ( block | EMPTYSTATEMENT )
                    int alt18=2;
                    int LA18_0 = input.LA(1);

                    if ( (LA18_0==BLOCK) ) {
                        alt18=1;
                    }
                    else if ( (LA18_0==EMPTYSTATEMENT) ) {
                        alt18=2;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 18, 0, input);

                        throw nvae;
                    }
                    switch (alt18) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:301:6: block
                            {
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_block_in_class_statement443);
                            block41=block();

                            state._fsp--;

                            adaptor.addChild(root_1, block41.getTree());

                                    startIndex = ((CommonToken)(block41!=null?((SLAST)block41.tree):null).token).getStartIndex();
                            		    endIndex = ((CommonToken)(block41!=null?((SLAST)block41.tree):null).token).getStopIndex();
                            		    
                            		    methodDeclaration = (PHPMethodDeclaration)parser.declarations.peek();
                            			  methodDeclaration.getBody().setStart(startIndex);
                            			  methodDeclaration.getBody().setEnd(endIndex);
                            			  methodDeclaration.getBody().getStatements().clear();
                            			  methodDeclaration.getBody().acceptStatements((block41!=null?block41.statList:null));
                            			  
                            			  methodDeclaration = (PHPMethodDeclaration)parser.declarations.pop();
                            //			  if(body instanceof ASTError) {
                            //			    parser.reportError(new ASTError(methodDeclaration.sourceEnd() - 1, methodDeclaration.sourceEnd()), "syntax error, unfinished method declaration");
                            //			  }
                            			  TypeDeclaration type = (TypeDeclaration)parser.declarations.peek();
                            			  methodDeclaration.setDeclaringTypeName(type.getName()); 
                                 

                            }
                            break;
                        case 2 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:320:5: EMPTYSTATEMENT
                            {
                            _last = (SLAST)input.LT(1);
                            EMPTYSTATEMENT42=(SLAST)match(input,EMPTYSTATEMENT,FOLLOW_EMPTYSTATEMENT_in_class_statement462); 
                            EMPTYSTATEMENT42_tree = (SLAST)adaptor.dupNode(EMPTYSTATEMENT42);

                            adaptor.addChild(root_1, EMPTYSTATEMENT42_tree);

                               
                                    startIndex = ((CommonToken)EMPTYSTATEMENT42.token).getStartIndex();
                                    endIndex = ((CommonToken)EMPTYSTATEMENT42.token).getStopIndex();
                                    
                                    methodDeclaration = (PHPMethodDeclaration)parser.declarations.peek();
                                    methodDeclaration.getBody().setStart(startIndex);
                                    methodDeclaration.getBody().setEnd(endIndex);
                                    methodDeclaration.getBody().getStatements().clear();
                                    methodDeclaration.getBody().acceptStatements(new LinkedList());
                                    
                                    methodDeclaration = (PHPMethodDeclaration)parser.declarations.pop();
                            //        if(body instanceof ASTError) {
                            //          parser.reportError(new ASTError(methodDeclaration.sourceEnd() - 1, methodDeclaration.sourceEnd()), "syntax error, unfinished method declaration");
                            //        }
                                    TypeDeclaration type = (TypeDeclaration)parser.declarations.peek();
                                    methodDeclaration.setDeclaringTypeName(type.getName()); 
                                 

                            }
                            break;

                    }


                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 3 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:339:5: ^( FIELD_DECL CONST_T ( directive )+ )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    FIELD_DECL43=(SLAST)match(input,FIELD_DECL,FOLLOW_FIELD_DECL_in_class_statement485); 
                    FIELD_DECL43_tree = (SLAST)adaptor.dupNode(FIELD_DECL43);

                    root_1 = (SLAST)adaptor.becomeRoot(FIELD_DECL43_tree, root_1);


                    inClassStatementList = true;

                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    CONST_T44=(SLAST)match(input,CONST_T,FOLLOW_CONST_T_in_class_statement489); 
                    CONST_T44_tree = (SLAST)adaptor.dupNode(CONST_T44);

                    adaptor.addChild(root_1, CONST_T44_tree);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:339:57: ( directive )+
                    int cnt19=0;
                    loop19:
                    do {
                        int alt19=2;
                        int LA19_0 = input.LA(1);

                        if ( (LA19_0==EQUAL_T) ) {
                            alt19=1;
                        }


                        switch (alt19) {
                    	case 1 :
                    	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:339:57: directive
                    	    {
                    	    _last = (SLAST)input.LT(1);
                    	    pushFollow(FOLLOW_directive_in_class_statement491);
                    	    directive45=directive();

                    	    state._fsp--;

                    	    adaptor.addChild(root_1, directive45.getTree());

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt19 >= 1 ) break loop19;
                                EarlyExitException eee =
                                    new EarlyExitException(19, input);
                                throw eee;
                        }
                        cnt19++;
                    } while (true);

                    inClassStatementList = false;

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        Iterator iter = ((class_statement_scope)class_statement_stack.peek()).constList.iterator();
                        while (iter.hasNext()) {
                          ASTNode[] decl = (ASTNode[])iter.next();
                    	    if (decl != null) {
                    		    ConstantReference constant = (ConstantReference)decl[0];
                    		    Expression initializer = (Expression)decl[1];
                    		    int decListLeft = ((CommonToken)(directive45!=null?((SLAST)directive45.tree):null).token).getStartIndex();
                    		      
                    		    PHPDocBlock docBlock = null;
                    		    if (decl.length == 3) {
                    		      docBlock = (PHPDocBlock)decl[2];
                    		    }
                    		    int start = constant.sourceStart();
                    		    int end = (initializer == null ? constant.sourceEnd() : initializer.sourceEnd());
                    		    parser.addDeclarationStatement(new ConstantDeclaration(constant, initializer, decListLeft, end, docBlock));
                    		  }
                    		}
                      

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
            class_statement_stack.pop();
        }
        return retval;
    }
    // $ANTLR end "class_statement"

    public static class function_declaration_statement_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "function_declaration_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:361:1: function_declaration_statement : ^( FUNCTION_T ( REF_T )? IDENTIFIER ( parameter_list )? block ) ;
    public final TreePHP.function_declaration_statement_return function_declaration_statement() throws RecognitionException {
        TreePHP.function_declaration_statement_return retval = new TreePHP.function_declaration_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST FUNCTION_T46=null;
        SLAST REF_T47=null;
        SLAST IDENTIFIER48=null;
        TreePHP.parameter_list_return parameter_list49 = null;

        TreePHP.block_return block50 = null;


        SLAST FUNCTION_T46_tree=null;
        SLAST REF_T47_tree=null;
        SLAST IDENTIFIER48_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:362:3: ( ^( FUNCTION_T ( REF_T )? IDENTIFIER ( parameter_list )? block ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:362:5: ^( FUNCTION_T ( REF_T )? IDENTIFIER ( parameter_list )? block )
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_1 = _last;
            SLAST _first_1 = null;
            SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            FUNCTION_T46=(SLAST)match(input,FUNCTION_T,FOLLOW_FUNCTION_T_in_function_declaration_statement513); 
            FUNCTION_T46_tree = (SLAST)adaptor.dupNode(FUNCTION_T46);

            root_1 = (SLAST)adaptor.becomeRoot(FUNCTION_T46_tree, root_1);



            match(input, Token.DOWN, null); 
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:362:18: ( REF_T )?
            int alt21=2;
            int LA21_0 = input.LA(1);

            if ( (LA21_0==REF_T) ) {
                alt21=1;
            }
            switch (alt21) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:362:18: REF_T
                    {
                    _last = (SLAST)input.LT(1);
                    REF_T47=(SLAST)match(input,REF_T,FOLLOW_REF_T_in_function_declaration_statement515); 
                    REF_T47_tree = (SLAST)adaptor.dupNode(REF_T47);

                    adaptor.addChild(root_1, REF_T47_tree);


                    }
                    break;

            }

            _last = (SLAST)input.LT(1);
            IDENTIFIER48=(SLAST)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_function_declaration_statement518); 
            IDENTIFIER48_tree = (SLAST)adaptor.dupNode(IDENTIFIER48);

            adaptor.addChild(root_1, IDENTIFIER48_tree);

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:362:36: ( parameter_list )?
            int alt22=2;
            int LA22_0 = input.LA(1);

            if ( (LA22_0==PARAMETER) ) {
                alt22=1;
            }
            switch (alt22) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:362:36: parameter_list
                    {
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_parameter_list_in_function_declaration_statement520);
                    parameter_list49=parameter_list();

                    state._fsp--;

                    adaptor.addChild(root_1, parameter_list49.getTree());

                    }
                    break;

            }

            _last = (SLAST)input.LT(1);
            pushFollow(FOLLOW_block_in_function_declaration_statement523);
            block50=block();

            state._fsp--;

            adaptor.addChild(root_1, block50.getTree());

            match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "function_declaration_statement"

    public static class block_return extends TreeRuleReturnScope {
        public Statement stat;
        public List statList;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "block"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:365:1: block returns [Statement stat, List statList] : ^( BLOCK ( inner_statement_list )? ) ;
    public final TreePHP.block_return block() throws RecognitionException {
        TreePHP.block_return retval = new TreePHP.block_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST BLOCK51=null;
        TreePHP.inner_statement_list_return inner_statement_list52 = null;


        SLAST BLOCK51_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:366:3: ( ^( BLOCK ( inner_statement_list )? ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:366:5: ^( BLOCK ( inner_statement_list )? )
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_1 = _last;
            SLAST _first_1 = null;
            SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            BLOCK51=(SLAST)match(input,BLOCK,FOLLOW_BLOCK_in_block543); 
            BLOCK51_tree = (SLAST)adaptor.dupNode(BLOCK51);

            root_1 = (SLAST)adaptor.becomeRoot(BLOCK51_tree, root_1);



            if ( input.LA(1)==Token.DOWN ) {
                match(input, Token.DOWN, null); 
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:366:13: ( inner_statement_list )?
                int alt23=2;
                int LA23_0 = input.LA(1);

                if ( (LA23_0==STATEMENT||LA23_0==CLASS_T||(LA23_0>=INTERFACE_T && LA23_0<=FUNCTION_T)||LA23_0==161) ) {
                    alt23=1;
                }
                switch (alt23) {
                    case 1 :
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:366:13: inner_statement_list
                        {
                        _last = (SLAST)input.LT(1);
                        pushFollow(FOLLOW_inner_statement_list_in_block545);
                        inner_statement_list52=inner_statement_list();

                        state._fsp--;

                        adaptor.addChild(root_1, inner_statement_list52.getTree());

                        }
                        break;

                }


                match(input, Token.UP, null); 
            }adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


                  int startIndex = -1;
                  int endIndex = -1;
                  Block block = new Block(startIndex, endIndex, new LinkedList());
                  if ((inner_statement_list52!=null?inner_statement_list52.innerStatementList:null) != null) {
                    block.getStatements().clear();
                    block.acceptStatements((inner_statement_list52!=null?inner_statement_list52.innerStatementList:null));
                    retval.statList = (inner_statement_list52!=null?inner_statement_list52.innerStatementList:null);
                  }
                  retval.stat = block;
                

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "block"

    public static class statement_return extends TreeRuleReturnScope {
        public Statement stat;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:387:1: statement returns [Statement stat] : ^( STATEMENT topStatement ) ;
    public final TreePHP.statement_return statement() throws RecognitionException {
        TreePHP.statement_return retval = new TreePHP.statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST STATEMENT53=null;
        TreePHP.topStatement_return topStatement54 = null;


        SLAST STATEMENT53_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:388:3: ( ^( STATEMENT topStatement ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:388:5: ^( STATEMENT topStatement )
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_1 = _last;
            SLAST _first_1 = null;
            SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            STATEMENT53=(SLAST)match(input,STATEMENT,FOLLOW_STATEMENT_in_statement581); 
            STATEMENT53_tree = (SLAST)adaptor.dupNode(STATEMENT53);

            root_1 = (SLAST)adaptor.becomeRoot(STATEMENT53_tree, root_1);



            match(input, Token.DOWN, null); 
            _last = (SLAST)input.LT(1);
            pushFollow(FOLLOW_topStatement_in_statement583);
            topStatement54=topStatement();

            state._fsp--;

            adaptor.addChild(root_1, topStatement54.getTree());

            match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


                if ((topStatement54!=null?topStatement54.expr:null) != null) {
            	    int startIndex = STATEMENT53.startIndex;
            	    int endIndex = STATEMENT53.endIndex + 1;
            	    retval.stat = new ExpressionStatement(startIndex, endIndex, (topStatement54!=null?topStatement54.expr:null));
                }
                else {
                  retval.stat = (topStatement54!=null?topStatement54.stat:null);
                }
              

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "statement"

    protected static class topStatement_scope {
        List declareKey;
        List declareValue;
    }
    protected Stack topStatement_stack = new Stack();

    public static class topStatement_return extends TreeRuleReturnScope {
        public Expression expr;
        public Statement stat;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "topStatement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:401:1: topStatement returns [Expression expr, Statement stat] : ( block | if_stat | ^( WHILE_T ^( CONDITION e= expression ) while_statement ) | ^( DO_T ^( CONDITION e= expression ) statement ) | ^( FOR_T (e1= expr_list )? ^( CONDITION (e2= expr_list )? ) ^( ITERATE (e3= expr_list )? ) s1= for_statement ) | ^( SWITCH_T ^( CONDITION expression ) switch_case_list ) | ^( BREAK_T ( expression )? ) | ^( CONTINUE_T (e= expression )? ) | ^( RETURN_T (e= expression )? ) | ^( GLOBAL_T variable ) | ^( STATIC_T static_var_list ) | ^( ECHO_T expr_list ) | ^( EMPTYSTATEMENT SEMI_COLON ) | expression | ^( FOREACH_T ^( AS_T e= expression v1= foreach_variable (v2= foreach_variable )? ) foreach_statement ) | ^( DECLARE_T directive declare_statement ) | ^( TRY_T ^( BLOCK top_statement ) ( catch_branch )+ ) | ^( THROW_T expression ) | ^( USE_T use_filename ) );
    public final TreePHP.topStatement_return topStatement() throws RecognitionException {
        topStatement_stack.push(new topStatement_scope());
        TreePHP.topStatement_return retval = new TreePHP.topStatement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST WHILE_T57=null;
        SLAST CONDITION58=null;
        SLAST DO_T60=null;
        SLAST CONDITION61=null;
        SLAST FOR_T63=null;
        SLAST CONDITION64=null;
        SLAST ITERATE65=null;
        SLAST SWITCH_T66=null;
        SLAST CONDITION67=null;
        SLAST BREAK_T70=null;
        SLAST CONTINUE_T72=null;
        SLAST RETURN_T73=null;
        SLAST GLOBAL_T74=null;
        SLAST STATIC_T76=null;
        SLAST ECHO_T78=null;
        SLAST EMPTYSTATEMENT80=null;
        SLAST SEMI_COLON81=null;
        SLAST FOREACH_T83=null;
        SLAST AS_T84=null;
        SLAST DECLARE_T86=null;
        SLAST TRY_T89=null;
        SLAST BLOCK90=null;
        SLAST THROW_T93=null;
        SLAST USE_T95=null;
        TreePHP.expression_return e = null;

        TreePHP.expr_list_return e1 = null;

        TreePHP.expr_list_return e2 = null;

        TreePHP.expr_list_return e3 = null;

        TreePHP.for_statement_return s1 = null;

        TreePHP.foreach_variable_return v1 = null;

        TreePHP.foreach_variable_return v2 = null;

        TreePHP.block_return block55 = null;

        TreePHP.if_stat_return if_stat56 = null;

        TreePHP.while_statement_return while_statement59 = null;

        TreePHP.statement_return statement62 = null;

        TreePHP.expression_return expression68 = null;

        TreePHP.switch_case_list_return switch_case_list69 = null;

        TreePHP.expression_return expression71 = null;

        TreePHP.variable_return variable75 = null;

        TreePHP.static_var_list_return static_var_list77 = null;

        TreePHP.expr_list_return expr_list79 = null;

        TreePHP.expression_return expression82 = null;

        TreePHP.foreach_statement_return foreach_statement85 = null;

        TreePHP.directive_return directive87 = null;

        TreePHP.declare_statement_return declare_statement88 = null;

        TreePHP.top_statement_return top_statement91 = null;

        TreePHP.catch_branch_return catch_branch92 = null;

        TreePHP.expression_return expression94 = null;

        TreePHP.use_filename_return use_filename96 = null;


        SLAST WHILE_T57_tree=null;
        SLAST CONDITION58_tree=null;
        SLAST DO_T60_tree=null;
        SLAST CONDITION61_tree=null;
        SLAST FOR_T63_tree=null;
        SLAST CONDITION64_tree=null;
        SLAST ITERATE65_tree=null;
        SLAST SWITCH_T66_tree=null;
        SLAST CONDITION67_tree=null;
        SLAST BREAK_T70_tree=null;
        SLAST CONTINUE_T72_tree=null;
        SLAST RETURN_T73_tree=null;
        SLAST GLOBAL_T74_tree=null;
        SLAST STATIC_T76_tree=null;
        SLAST ECHO_T78_tree=null;
        SLAST EMPTYSTATEMENT80_tree=null;
        SLAST SEMI_COLON81_tree=null;
        SLAST FOREACH_T83_tree=null;
        SLAST AS_T84_tree=null;
        SLAST DECLARE_T86_tree=null;
        SLAST TRY_T89_tree=null;
        SLAST BLOCK90_tree=null;
        SLAST THROW_T93_tree=null;
        SLAST USE_T95_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:406:3: ( block | if_stat | ^( WHILE_T ^( CONDITION e= expression ) while_statement ) | ^( DO_T ^( CONDITION e= expression ) statement ) | ^( FOR_T (e1= expr_list )? ^( CONDITION (e2= expr_list )? ) ^( ITERATE (e3= expr_list )? ) s1= for_statement ) | ^( SWITCH_T ^( CONDITION expression ) switch_case_list ) | ^( BREAK_T ( expression )? ) | ^( CONTINUE_T (e= expression )? ) | ^( RETURN_T (e= expression )? ) | ^( GLOBAL_T variable ) | ^( STATIC_T static_var_list ) | ^( ECHO_T expr_list ) | ^( EMPTYSTATEMENT SEMI_COLON ) | expression | ^( FOREACH_T ^( AS_T e= expression v1= foreach_variable (v2= foreach_variable )? ) foreach_statement ) | ^( DECLARE_T directive declare_statement ) | ^( TRY_T ^( BLOCK top_statement ) ( catch_branch )+ ) | ^( THROW_T expression ) | ^( USE_T use_filename ) )
            int alt32=19;
            switch ( input.LA(1) ) {
            case BLOCK:
                {
                alt32=1;
                }
                break;
            case IF_T:
                {
                alt32=2;
                }
                break;
            case WHILE_T:
                {
                alt32=3;
                }
                break;
            case DO_T:
                {
                alt32=4;
                }
                break;
            case FOR_T:
                {
                alt32=5;
                }
                break;
            case SWITCH_T:
                {
                alt32=6;
                }
                break;
            case BREAK_T:
                {
                alt32=7;
                }
                break;
            case CONTINUE_T:
                {
                alt32=8;
                }
                break;
            case RETURN_T:
                {
                alt32=9;
                }
                break;
            case GLOBAL_T:
                {
                alt32=10;
                }
                break;
            case STATIC_T:
                {
                alt32=11;
                }
                break;
            case ECHO_T:
                {
                alt32=12;
                }
                break;
            case EMPTYSTATEMENT:
                {
                alt32=13;
                }
                break;
            case METHOD_DECL:
            case VAR_DECL:
            case CALL:
            case EXPR:
            case SCALAR:
            case ARRAY_DECL:
            case PREFIX_EXPR:
            case POSTFIX_EXPR:
            case CAST_EXPR:
            case REF_T:
            case EQUAL_T:
            case OR_T:
            case XOR_T:
            case AND_T:
            case PLUS_EQ:
            case MINUS_EQ:
            case MUL_EQ:
            case DIV_EQ:
            case DOT_EQ:
            case PERCENT_EQ:
            case BIT_AND_EQ:
            case BIT_OR_EQ:
            case POWER_EQ:
            case LMOVE_EQ:
            case RMOVE_EQ:
            case QUESTION_T:
            case LOGICAL_OR_T:
            case LOGICAL_AND_T:
            case BIT_OR_T:
            case POWER_T:
            case DOT_T:
            case EQUAL_EQUAL_T:
            case NOT_EQUAL_T:
            case EQUAL_EQUAL_EQUAL_T:
            case NOT_EQUAL_EQUAL_T:
            case LT_T:
            case MT_T:
            case LE_T:
            case ME_T:
            case LSHIFT_T:
            case RSHIFT_T:
            case PLUS_T:
            case MINUS_T:
            case MUL_T:
            case DIV_T:
            case PERCENT_T:
            case UNSET_T:
            case CLONE_T:
            case TILDA_T:
            case EXC_NOT_T:
            case INSTANCEOF_T:
            case AT_T:
            case LIST_T:
            case NEW_T:
            case EXIT_T:
            case BACKTRICKLITERAL:
                {
                alt32=14;
                }
                break;
            case FOREACH_T:
                {
                alt32=15;
                }
                break;
            case DECLARE_T:
                {
                alt32=16;
                }
                break;
            case TRY_T:
                {
                alt32=17;
                }
                break;
            case THROW_T:
                {
                alt32=18;
                }
                break;
            case USE_T:
                {
                alt32=19;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 32, 0, input);

                throw nvae;
            }

            switch (alt32) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:406:5: block
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_block_in_topStatement609);
                    block55=block();

                    state._fsp--;

                    adaptor.addChild(root_0, block55.getTree());

                        retval.stat = (block55!=null?block55.stat:null);
                      

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:410:5: if_stat
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_if_stat_in_topStatement620);
                    if_stat56=if_stat();

                    state._fsp--;

                    adaptor.addChild(root_0, if_stat56.getTree());

                        retval.stat = (if_stat56!=null?if_stat56.stat:null);
                      

                    }
                    break;
                case 3 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:414:5: ^( WHILE_T ^( CONDITION e= expression ) while_statement )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    WHILE_T57=(SLAST)match(input,WHILE_T,FOLLOW_WHILE_T_in_topStatement631); 
                    WHILE_T57_tree = (SLAST)adaptor.dupNode(WHILE_T57);

                    root_1 = (SLAST)adaptor.becomeRoot(WHILE_T57_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_2 = _last;
                    SLAST _first_2 = null;
                    SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    CONDITION58=(SLAST)match(input,CONDITION,FOLLOW_CONDITION_in_topStatement634); 
                    CONDITION58_tree = (SLAST)adaptor.dupNode(CONDITION58);

                    root_2 = (SLAST)adaptor.becomeRoot(CONDITION58_tree, root_2);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_topStatement638);
                    e=expression();

                    state._fsp--;

                    adaptor.addChild(root_2, e.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
                    }

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_while_statement_in_topStatement641);
                    while_statement59=while_statement();

                    state._fsp--;

                    adaptor.addChild(root_1, while_statement59.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = WHILE_T57.startIndex;
                        int endIndex = WHILE_T57.endIndex + 1;
                        retval.stat = new WhileStatement(startIndex, endIndex, (e!=null?e.expr:null), (while_statement59!=null?while_statement59.block:null));   
                      

                    }
                    break;
                case 4 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:421:5: ^( DO_T ^( CONDITION e= expression ) statement )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    DO_T60=(SLAST)match(input,DO_T,FOLLOW_DO_T_in_topStatement656); 
                    DO_T60_tree = (SLAST)adaptor.dupNode(DO_T60);

                    root_1 = (SLAST)adaptor.becomeRoot(DO_T60_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_2 = _last;
                    SLAST _first_2 = null;
                    SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    CONDITION61=(SLAST)match(input,CONDITION,FOLLOW_CONDITION_in_topStatement659); 
                    CONDITION61_tree = (SLAST)adaptor.dupNode(CONDITION61);

                    root_2 = (SLAST)adaptor.becomeRoot(CONDITION61_tree, root_2);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_topStatement663);
                    e=expression();

                    state._fsp--;

                    adaptor.addChild(root_2, e.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
                    }

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_statement_in_topStatement666);
                    statement62=statement();

                    state._fsp--;

                    adaptor.addChild(root_1, statement62.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = DO_T60.startIndex;
                        int endIndex = DO_T60.endIndex + 1;
                        retval.stat = new DoStatement(startIndex, startIndex, (e!=null?e.expr:null), (statement62!=null?statement62.stat:null));      
                      

                    }
                    break;
                case 5 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:427:5: ^( FOR_T (e1= expr_list )? ^( CONDITION (e2= expr_list )? ) ^( ITERATE (e3= expr_list )? ) s1= for_statement )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    FOR_T63=(SLAST)match(input,FOR_T,FOLLOW_FOR_T_in_topStatement678); 
                    FOR_T63_tree = (SLAST)adaptor.dupNode(FOR_T63);

                    root_1 = (SLAST)adaptor.becomeRoot(FOR_T63_tree, root_1);



                    match(input, Token.DOWN, null); 
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:427:15: (e1= expr_list )?
                    int alt24=2;
                    int LA24_0 = input.LA(1);

                    if ( (LA24_0==METHOD_DECL||LA24_0==VAR_DECL||LA24_0==CALL||LA24_0==EXPR||(LA24_0>=SCALAR && LA24_0<=CAST_EXPR)||LA24_0==REF_T||LA24_0==EQUAL_T||(LA24_0>=OR_T && LA24_0<=EXC_NOT_T)||(LA24_0>=INSTANCEOF_T && LA24_0<=BACKTRICKLITERAL)) ) {
                        alt24=1;
                    }
                    switch (alt24) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:427:15: e1= expr_list
                            {
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_expr_list_in_topStatement682);
                            e1=expr_list();

                            state._fsp--;

                            adaptor.addChild(root_1, e1.getTree());

                            }
                            break;

                    }

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_2 = _last;
                    SLAST _first_2 = null;
                    SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    CONDITION64=(SLAST)match(input,CONDITION,FOLLOW_CONDITION_in_topStatement686); 
                    CONDITION64_tree = (SLAST)adaptor.dupNode(CONDITION64);

                    root_2 = (SLAST)adaptor.becomeRoot(CONDITION64_tree, root_2);



                    if ( input.LA(1)==Token.DOWN ) {
                        match(input, Token.DOWN, null); 
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:427:41: (e2= expr_list )?
                        int alt25=2;
                        int LA25_0 = input.LA(1);

                        if ( (LA25_0==METHOD_DECL||LA25_0==VAR_DECL||LA25_0==CALL||LA25_0==EXPR||(LA25_0>=SCALAR && LA25_0<=CAST_EXPR)||LA25_0==REF_T||LA25_0==EQUAL_T||(LA25_0>=OR_T && LA25_0<=EXC_NOT_T)||(LA25_0>=INSTANCEOF_T && LA25_0<=BACKTRICKLITERAL)) ) {
                            alt25=1;
                        }
                        switch (alt25) {
                            case 1 :
                                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:427:41: e2= expr_list
                                {
                                _last = (SLAST)input.LT(1);
                                pushFollow(FOLLOW_expr_list_in_topStatement690);
                                e2=expr_list();

                                state._fsp--;

                                adaptor.addChild(root_2, e2.getTree());

                                }
                                break;

                        }


                        match(input, Token.UP, null); 
                    }adaptor.addChild(root_1, root_2);_last = _save_last_2;
                    }

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_2 = _last;
                    SLAST _first_2 = null;
                    SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    ITERATE65=(SLAST)match(input,ITERATE,FOLLOW_ITERATE_in_topStatement695); 
                    ITERATE65_tree = (SLAST)adaptor.dupNode(ITERATE65);

                    root_2 = (SLAST)adaptor.becomeRoot(ITERATE65_tree, root_2);



                    if ( input.LA(1)==Token.DOWN ) {
                        match(input, Token.DOWN, null); 
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:427:66: (e3= expr_list )?
                        int alt26=2;
                        int LA26_0 = input.LA(1);

                        if ( (LA26_0==METHOD_DECL||LA26_0==VAR_DECL||LA26_0==CALL||LA26_0==EXPR||(LA26_0>=SCALAR && LA26_0<=CAST_EXPR)||LA26_0==REF_T||LA26_0==EQUAL_T||(LA26_0>=OR_T && LA26_0<=EXC_NOT_T)||(LA26_0>=INSTANCEOF_T && LA26_0<=BACKTRICKLITERAL)) ) {
                            alt26=1;
                        }
                        switch (alt26) {
                            case 1 :
                                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:427:66: e3= expr_list
                                {
                                _last = (SLAST)input.LT(1);
                                pushFollow(FOLLOW_expr_list_in_topStatement699);
                                e3=expr_list();

                                state._fsp--;

                                adaptor.addChild(root_2, e3.getTree());

                                }
                                break;

                        }


                        match(input, Token.UP, null); 
                    }adaptor.addChild(root_1, root_2);_last = _save_last_2;
                    }

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_for_statement_in_topStatement705);
                    s1=for_statement();

                    state._fsp--;

                    adaptor.addChild(root_1, s1.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = FOR_T63.startIndex;
                        int endIndex = FOR_T63.endIndex + 1;
                        retval.stat = new ForStatement(startIndex, endIndex, (e1!=null?e1.exprList:null), (e2!=null?e2.exprList:null), (e3!=null?e3.exprList:null), (s1!=null?s1.block:null));
                      

                    }
                    break;
                case 6 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:433:5: ^( SWITCH_T ^( CONDITION expression ) switch_case_list )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    SWITCH_T66=(SLAST)match(input,SWITCH_T,FOLLOW_SWITCH_T_in_topStatement717); 
                    SWITCH_T66_tree = (SLAST)adaptor.dupNode(SWITCH_T66);

                    root_1 = (SLAST)adaptor.becomeRoot(SWITCH_T66_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_2 = _last;
                    SLAST _first_2 = null;
                    SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    CONDITION67=(SLAST)match(input,CONDITION,FOLLOW_CONDITION_in_topStatement720); 
                    CONDITION67_tree = (SLAST)adaptor.dupNode(CONDITION67);

                    root_2 = (SLAST)adaptor.becomeRoot(CONDITION67_tree, root_2);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_topStatement722);
                    expression68=expression();

                    state._fsp--;

                    adaptor.addChild(root_2, expression68.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
                    }

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_switch_case_list_in_topStatement725);
                    switch_case_list69=switch_case_list();

                    state._fsp--;

                    adaptor.addChild(root_1, switch_case_list69.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 7 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:434:5: ^( BREAK_T ( expression )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    BREAK_T70=(SLAST)match(input,BREAK_T,FOLLOW_BREAK_T_in_topStatement733); 
                    BREAK_T70_tree = (SLAST)adaptor.dupNode(BREAK_T70);

                    root_1 = (SLAST)adaptor.becomeRoot(BREAK_T70_tree, root_1);



                    if ( input.LA(1)==Token.DOWN ) {
                        match(input, Token.DOWN, null); 
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:434:15: ( expression )?
                        int alt27=2;
                        int LA27_0 = input.LA(1);

                        if ( (LA27_0==METHOD_DECL||LA27_0==VAR_DECL||LA27_0==CALL||LA27_0==EXPR||(LA27_0>=SCALAR && LA27_0<=CAST_EXPR)||LA27_0==REF_T||LA27_0==EQUAL_T||(LA27_0>=OR_T && LA27_0<=EXC_NOT_T)||(LA27_0>=INSTANCEOF_T && LA27_0<=BACKTRICKLITERAL)) ) {
                            alt27=1;
                        }
                        switch (alt27) {
                            case 1 :
                                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:434:15: expression
                                {
                                _last = (SLAST)input.LT(1);
                                pushFollow(FOLLOW_expression_in_topStatement735);
                                expression71=expression();

                                state._fsp--;

                                adaptor.addChild(root_1, expression71.getTree());

                                }
                                break;

                        }


                        match(input, Token.UP, null); 
                    }adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = BREAK_T70.startIndex;
                        int endIndex = BREAK_T70.endIndex + 1;
                        retval.stat = new BreakStatement(startIndex, endIndex);
                      

                    }
                    break;
                case 8 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:440:5: ^( CONTINUE_T (e= expression )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    CONTINUE_T72=(SLAST)match(input,CONTINUE_T,FOLLOW_CONTINUE_T_in_topStatement748); 
                    CONTINUE_T72_tree = (SLAST)adaptor.dupNode(CONTINUE_T72);

                    root_1 = (SLAST)adaptor.becomeRoot(CONTINUE_T72_tree, root_1);



                    if ( input.LA(1)==Token.DOWN ) {
                        match(input, Token.DOWN, null); 
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:440:19: (e= expression )?
                        int alt28=2;
                        int LA28_0 = input.LA(1);

                        if ( (LA28_0==METHOD_DECL||LA28_0==VAR_DECL||LA28_0==CALL||LA28_0==EXPR||(LA28_0>=SCALAR && LA28_0<=CAST_EXPR)||LA28_0==REF_T||LA28_0==EQUAL_T||(LA28_0>=OR_T && LA28_0<=EXC_NOT_T)||(LA28_0>=INSTANCEOF_T && LA28_0<=BACKTRICKLITERAL)) ) {
                            alt28=1;
                        }
                        switch (alt28) {
                            case 1 :
                                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:440:19: e= expression
                                {
                                _last = (SLAST)input.LT(1);
                                pushFollow(FOLLOW_expression_in_topStatement752);
                                e=expression();

                                state._fsp--;

                                adaptor.addChild(root_1, e.getTree());

                                }
                                break;

                        }


                        match(input, Token.UP, null); 
                    }adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = CONTINUE_T72.startIndex;
                        int endIndex = CONTINUE_T72.endIndex;
                        retval.stat = new ContinueStatement(startIndex, endIndex);
                        if ((e!=null?e.expr:null) != null) {
                          retval.stat = new ContinueStatement(startIndex, endIndex, (e!=null?e.expr:null));
                        }
                      

                    }
                    break;
                case 9 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:449:5: ^( RETURN_T (e= expression )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    RETURN_T73=(SLAST)match(input,RETURN_T,FOLLOW_RETURN_T_in_topStatement765); 
                    RETURN_T73_tree = (SLAST)adaptor.dupNode(RETURN_T73);

                    root_1 = (SLAST)adaptor.becomeRoot(RETURN_T73_tree, root_1);



                    if ( input.LA(1)==Token.DOWN ) {
                        match(input, Token.DOWN, null); 
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:449:17: (e= expression )?
                        int alt29=2;
                        int LA29_0 = input.LA(1);

                        if ( (LA29_0==METHOD_DECL||LA29_0==VAR_DECL||LA29_0==CALL||LA29_0==EXPR||(LA29_0>=SCALAR && LA29_0<=CAST_EXPR)||LA29_0==REF_T||LA29_0==EQUAL_T||(LA29_0>=OR_T && LA29_0<=EXC_NOT_T)||(LA29_0>=INSTANCEOF_T && LA29_0<=BACKTRICKLITERAL)) ) {
                            alt29=1;
                        }
                        switch (alt29) {
                            case 1 :
                                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:449:17: e= expression
                                {
                                _last = (SLAST)input.LT(1);
                                pushFollow(FOLLOW_expression_in_topStatement769);
                                e=expression();

                                state._fsp--;

                                adaptor.addChild(root_1, e.getTree());

                                }
                                break;

                        }


                        match(input, Token.UP, null); 
                    }adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = RETURN_T73.startIndex;
                        int endIndex = RETURN_T73.endIndex;
                        retval.stat = new ReturnStatement(startIndex, endIndex);
                        if ((e!=null?e.expr:null) != null) {
                          retval.stat = new ReturnStatement(startIndex, endIndex, (e!=null?e.expr:null));
                        }
                      

                    }
                    break;
                case 10 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:458:5: ^( GLOBAL_T variable )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    GLOBAL_T74=(SLAST)match(input,GLOBAL_T,FOLLOW_GLOBAL_T_in_topStatement782); 
                    GLOBAL_T74_tree = (SLAST)adaptor.dupNode(GLOBAL_T74);

                    root_1 = (SLAST)adaptor.becomeRoot(GLOBAL_T74_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_variable_in_topStatement784);
                    variable75=variable();

                    state._fsp--;

                    adaptor.addChild(root_1, variable75.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 11 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:459:5: ^( STATIC_T static_var_list )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    STATIC_T76=(SLAST)match(input,STATIC_T,FOLLOW_STATIC_T_in_topStatement792); 
                    STATIC_T76_tree = (SLAST)adaptor.dupNode(STATIC_T76);

                    root_1 = (SLAST)adaptor.becomeRoot(STATIC_T76_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_static_var_list_in_topStatement794);
                    static_var_list77=static_var_list();

                    state._fsp--;

                    adaptor.addChild(root_1, static_var_list77.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = STATIC_T76.startIndex;
                        int endIndex = STATIC_T76.endIndex;
                        retval.stat = new StaticStatement(startIndex, endIndex, (static_var_list77!=null?static_var_list77.staticVarList:null));
                      

                    }
                    break;
                case 12 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:465:5: ^( ECHO_T expr_list )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    ECHO_T78=(SLAST)match(input,ECHO_T,FOLLOW_ECHO_T_in_topStatement806); 
                    ECHO_T78_tree = (SLAST)adaptor.dupNode(ECHO_T78);

                    root_1 = (SLAST)adaptor.becomeRoot(ECHO_T78_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expr_list_in_topStatement808);
                    expr_list79=expr_list();

                    state._fsp--;

                    adaptor.addChild(root_1, expr_list79.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = ECHO_T78.startIndex;
                        int endIndex = ECHO_T78.endIndex;
                        retval.stat = new EchoStatement(startIndex, endIndex, (expr_list79!=null?expr_list79.exprList:null)); 
                      

                    }
                    break;
                case 13 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:471:5: ^( EMPTYSTATEMENT SEMI_COLON )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    EMPTYSTATEMENT80=(SLAST)match(input,EMPTYSTATEMENT,FOLLOW_EMPTYSTATEMENT_in_topStatement820); 
                    EMPTYSTATEMENT80_tree = (SLAST)adaptor.dupNode(EMPTYSTATEMENT80);

                    root_1 = (SLAST)adaptor.becomeRoot(EMPTYSTATEMENT80_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    SEMI_COLON81=(SLAST)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_topStatement822); 
                    SEMI_COLON81_tree = (SLAST)adaptor.dupNode(SEMI_COLON81);

                    adaptor.addChild(root_1, SEMI_COLON81_tree);


                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = EMPTYSTATEMENT80.startIndex;
                        int endIndex = EMPTYSTATEMENT80.endIndex;
                        retval.stat = new EmptyStatement(startIndex, endIndex); 
                      

                    }
                    break;
                case 14 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:477:5: expression
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_topStatement833);
                    expression82=expression();

                    state._fsp--;

                    adaptor.addChild(root_0, expression82.getTree());

                         retval.expr = (expression82!=null?expression82.expr:null);
                      

                    }
                    break;
                case 15 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:481:5: ^( FOREACH_T ^( AS_T e= expression v1= foreach_variable (v2= foreach_variable )? ) foreach_statement )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    FOREACH_T83=(SLAST)match(input,FOREACH_T,FOLLOW_FOREACH_T_in_topStatement844); 
                    FOREACH_T83_tree = (SLAST)adaptor.dupNode(FOREACH_T83);

                    root_1 = (SLAST)adaptor.becomeRoot(FOREACH_T83_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_2 = _last;
                    SLAST _first_2 = null;
                    SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    AS_T84=(SLAST)match(input,AS_T,FOLLOW_AS_T_in_topStatement847); 
                    AS_T84_tree = (SLAST)adaptor.dupNode(AS_T84);

                    root_2 = (SLAST)adaptor.becomeRoot(AS_T84_tree, root_2);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_topStatement851);
                    e=expression();

                    state._fsp--;

                    adaptor.addChild(root_2, e.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_foreach_variable_in_topStatement855);
                    v1=foreach_variable();

                    state._fsp--;

                    adaptor.addChild(root_2, v1.getTree());
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:481:59: (v2= foreach_variable )?
                    int alt30=2;
                    int LA30_0 = input.LA(1);

                    if ( (LA30_0==VAR_DECL||LA30_0==CALL||LA30_0==REF_T) ) {
                        alt30=1;
                    }
                    switch (alt30) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:481:59: v2= foreach_variable
                            {
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_foreach_variable_in_topStatement859);
                            v2=foreach_variable();

                            state._fsp--;

                            adaptor.addChild(root_2, v2.getTree());

                            }
                            break;

                    }


                    match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
                    }

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_foreach_statement_in_topStatement863);
                    foreach_statement85=foreach_statement();

                    state._fsp--;

                    adaptor.addChild(root_1, foreach_statement85.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = FOREACH_T83.startIndex;
                        int endIndex = FOREACH_T83.endIndex;
                        
                        if ((v2!=null?v2.expr:null) == null) {
                          retval.stat = new ForEachStatement(startIndex, endIndex, (e!=null?e.expr:null), (v1!=null?v1.expr:null), (foreach_statement85!=null?foreach_statement85.block:null));
                        }
                        else {
                          retval.stat = new ForEachStatement(startIndex, endIndex, (e!=null?e.expr:null), (v1!=null?v1.expr:null), (v2!=null?v2.expr:null), (foreach_statement85!=null?foreach_statement85.block:null));
                        }
                      

                    }
                    break;
                case 16 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:493:5: ^( DECLARE_T directive declare_statement )
                    {
                    root_0 = (SLAST)adaptor.nil();


                    	    ((topStatement_scope)topStatement_stack.peek()).declareKey = new LinkedList();
                    	    ((topStatement_scope)topStatement_stack.peek()).declareValue = new LinkedList();
                        
                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    DECLARE_T86=(SLAST)match(input,DECLARE_T,FOLLOW_DECLARE_T_in_topStatement882); 
                    DECLARE_T86_tree = (SLAST)adaptor.dupNode(DECLARE_T86);

                    root_1 = (SLAST)adaptor.becomeRoot(DECLARE_T86_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_directive_in_topStatement884);
                    directive87=directive();

                    state._fsp--;

                    adaptor.addChild(root_1, directive87.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_declare_statement_in_topStatement886);
                    declare_statement88=declare_statement();

                    state._fsp--;

                    adaptor.addChild(root_1, declare_statement88.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    	    int startIndex = DECLARE_T86.startIndex;
                    	    int endIndex = DECLARE_T86.endIndex;
                    	    DeclareStatement declare = new DeclareStatement(startIndex, endIndex, ((topStatement_scope)topStatement_stack.peek()).declareKey, ((topStatement_scope)topStatement_stack.peek()).declareValue, (declare_statement88!=null?declare_statement88.block:null));
                    	    retval.stat = declare;
                    	  

                    }
                    break;
                case 17 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:504:5: ^( TRY_T ^( BLOCK top_statement ) ( catch_branch )+ )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    TRY_T89=(SLAST)match(input,TRY_T,FOLLOW_TRY_T_in_topStatement899); 
                    TRY_T89_tree = (SLAST)adaptor.dupNode(TRY_T89);

                    root_1 = (SLAST)adaptor.becomeRoot(TRY_T89_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_2 = _last;
                    SLAST _first_2 = null;
                    SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    BLOCK90=(SLAST)match(input,BLOCK,FOLLOW_BLOCK_in_topStatement902); 
                    BLOCK90_tree = (SLAST)adaptor.dupNode(BLOCK90);

                    root_2 = (SLAST)adaptor.becomeRoot(BLOCK90_tree, root_2);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_top_statement_in_topStatement904);
                    top_statement91=top_statement();

                    state._fsp--;

                    adaptor.addChild(root_2, top_statement91.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
                    }

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:504:36: ( catch_branch )+
                    int cnt31=0;
                    loop31:
                    do {
                        int alt31=2;
                        int LA31_0 = input.LA(1);

                        if ( (LA31_0==CATCH_T) ) {
                            alt31=1;
                        }


                        switch (alt31) {
                    	case 1 :
                    	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:504:36: catch_branch
                    	    {
                    	    _last = (SLAST)input.LT(1);
                    	    pushFollow(FOLLOW_catch_branch_in_topStatement907);
                    	    catch_branch92=catch_branch();

                    	    state._fsp--;

                    	    adaptor.addChild(root_1, catch_branch92.getTree());

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt31 >= 1 ) break loop31;
                                EarlyExitException eee =
                                    new EarlyExitException(31, input);
                                throw eee;
                        }
                        cnt31++;
                    } while (true);


                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 18 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:505:5: ^( THROW_T expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    THROW_T93=(SLAST)match(input,THROW_T,FOLLOW_THROW_T_in_topStatement916); 
                    THROW_T93_tree = (SLAST)adaptor.dupNode(THROW_T93);

                    root_1 = (SLAST)adaptor.becomeRoot(THROW_T93_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_topStatement918);
                    expression94=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression94.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 19 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:506:5: ^( USE_T use_filename )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    USE_T95=(SLAST)match(input,USE_T,FOLLOW_USE_T_in_topStatement926); 
                    USE_T95_tree = (SLAST)adaptor.dupNode(USE_T95);

                    root_1 = (SLAST)adaptor.becomeRoot(USE_T95_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_use_filename_in_topStatement928);
                    use_filename96=use_filename();

                    state._fsp--;

                    adaptor.addChild(root_1, use_filename96.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
            topStatement_stack.pop();
        }
        return retval;
    }
    // $ANTLR end "topStatement"

    public static class foreach_variable_return extends TreeRuleReturnScope {
        public Expression expr;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "foreach_variable"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:512:1: foreach_variable returns [Expression expr] : ( REF_T )? variable ;
    public final TreePHP.foreach_variable_return foreach_variable() throws RecognitionException {
        TreePHP.foreach_variable_return retval = new TreePHP.foreach_variable_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST REF_T97=null;
        TreePHP.variable_return variable98 = null;


        SLAST REF_T97_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:518:3: ( ( REF_T )? variable )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:518:5: ( REF_T )? variable
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:518:5: ( REF_T )?
            int alt33=2;
            int LA33_0 = input.LA(1);

            if ( (LA33_0==REF_T) ) {
                alt33=1;
            }
            switch (alt33) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:518:5: REF_T
                    {
                    _last = (SLAST)input.LT(1);
                    REF_T97=(SLAST)match(input,REF_T,FOLLOW_REF_T_in_foreach_variable954); 
                    REF_T97_tree = (SLAST)adaptor.dupNode(REF_T97);

                    adaptor.addChild(root_0, REF_T97_tree);


                    }
                    break;

            }

            _last = (SLAST)input.LT(1);
            pushFollow(FOLLOW_variable_in_foreach_variable957);
            variable98=variable();

            state._fsp--;

            adaptor.addChild(root_0, variable98.getTree());

                retval.expr = (variable98!=null?variable98.var:null);
              

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "foreach_variable"

    public static class use_filename_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "use_filename"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:524:1: use_filename : STRINGLITERAL ;
    public final TreePHP.use_filename_return use_filename() throws RecognitionException {
        TreePHP.use_filename_return retval = new TreePHP.use_filename_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST STRINGLITERAL99=null;

        SLAST STRINGLITERAL99_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:525:3: ( STRINGLITERAL )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:525:5: STRINGLITERAL
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            STRINGLITERAL99=(SLAST)match(input,STRINGLITERAL,FOLLOW_STRINGLITERAL_in_use_filename976); 
            STRINGLITERAL99_tree = (SLAST)adaptor.dupNode(STRINGLITERAL99);

            adaptor.addChild(root_0, STRINGLITERAL99_tree);


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "use_filename"

    public static class method_declaration_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "method_declaration"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:528:1: method_declaration : ^( METHOD_DECL ( REF_T )? IDENTIFIER ( parameter_list )? ( block | EMPTYSTATEMENT ) ) ;
    public final TreePHP.method_declaration_return method_declaration() throws RecognitionException {
        TreePHP.method_declaration_return retval = new TreePHP.method_declaration_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST METHOD_DECL100=null;
        SLAST REF_T101=null;
        SLAST IDENTIFIER102=null;
        SLAST EMPTYSTATEMENT105=null;
        TreePHP.parameter_list_return parameter_list103 = null;

        TreePHP.block_return block104 = null;


        SLAST METHOD_DECL100_tree=null;
        SLAST REF_T101_tree=null;
        SLAST IDENTIFIER102_tree=null;
        SLAST EMPTYSTATEMENT105_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:529:3: ( ^( METHOD_DECL ( REF_T )? IDENTIFIER ( parameter_list )? ( block | EMPTYSTATEMENT ) ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:529:5: ^( METHOD_DECL ( REF_T )? IDENTIFIER ( parameter_list )? ( block | EMPTYSTATEMENT ) )
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_1 = _last;
            SLAST _first_1 = null;
            SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            METHOD_DECL100=(SLAST)match(input,METHOD_DECL,FOLLOW_METHOD_DECL_in_method_declaration992); 
            METHOD_DECL100_tree = (SLAST)adaptor.dupNode(METHOD_DECL100);

            root_1 = (SLAST)adaptor.becomeRoot(METHOD_DECL100_tree, root_1);



            match(input, Token.DOWN, null); 
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:529:19: ( REF_T )?
            int alt34=2;
            int LA34_0 = input.LA(1);

            if ( (LA34_0==REF_T) ) {
                alt34=1;
            }
            switch (alt34) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:529:19: REF_T
                    {
                    _last = (SLAST)input.LT(1);
                    REF_T101=(SLAST)match(input,REF_T,FOLLOW_REF_T_in_method_declaration994); 
                    REF_T101_tree = (SLAST)adaptor.dupNode(REF_T101);

                    adaptor.addChild(root_1, REF_T101_tree);


                    }
                    break;

            }

            _last = (SLAST)input.LT(1);
            IDENTIFIER102=(SLAST)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_method_declaration997); 
            IDENTIFIER102_tree = (SLAST)adaptor.dupNode(IDENTIFIER102);

            adaptor.addChild(root_1, IDENTIFIER102_tree);

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:529:37: ( parameter_list )?
            int alt35=2;
            int LA35_0 = input.LA(1);

            if ( (LA35_0==PARAMETER) ) {
                alt35=1;
            }
            switch (alt35) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:529:37: parameter_list
                    {
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_parameter_list_in_method_declaration999);
                    parameter_list103=parameter_list();

                    state._fsp--;

                    adaptor.addChild(root_1, parameter_list103.getTree());

                    }
                    break;

            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:529:53: ( block | EMPTYSTATEMENT )
            int alt36=2;
            int LA36_0 = input.LA(1);

            if ( (LA36_0==BLOCK) ) {
                alt36=1;
            }
            else if ( (LA36_0==EMPTYSTATEMENT) ) {
                alt36=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 36, 0, input);

                throw nvae;
            }
            switch (alt36) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:529:54: block
                    {
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_block_in_method_declaration1003);
                    block104=block();

                    state._fsp--;

                    adaptor.addChild(root_1, block104.getTree());

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:529:61: EMPTYSTATEMENT
                    {
                    _last = (SLAST)input.LT(1);
                    EMPTYSTATEMENT105=(SLAST)match(input,EMPTYSTATEMENT,FOLLOW_EMPTYSTATEMENT_in_method_declaration1006); 
                    EMPTYSTATEMENT105_tree = (SLAST)adaptor.dupNode(EMPTYSTATEMENT105);

                    adaptor.addChild(root_1, EMPTYSTATEMENT105_tree);


                    }
                    break;

            }


            match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "method_declaration"

    public static class fully_qualified_class_name_list_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "fully_qualified_class_name_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:533:1: fully_qualified_class_name_list : ( fully_qualified_class_name )+ ;
    public final TreePHP.fully_qualified_class_name_list_return fully_qualified_class_name_list() throws RecognitionException {
        TreePHP.fully_qualified_class_name_list_return retval = new TreePHP.fully_qualified_class_name_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.fully_qualified_class_name_return fully_qualified_class_name106 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:534:3: ( ( fully_qualified_class_name )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:534:5: ( fully_qualified_class_name )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:534:5: ( fully_qualified_class_name )+
            int cnt37=0;
            loop37:
            do {
                int alt37=2;
                int LA37_0 = input.LA(1);

                if ( (LA37_0==IDENTIFIER||LA37_0==DOMAIN_T) ) {
                    alt37=1;
                }


                switch (alt37) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:534:5: fully_qualified_class_name
            	    {
            	    _last = (SLAST)input.LT(1);
            	    pushFollow(FOLLOW_fully_qualified_class_name_in_fully_qualified_class_name_list1024);
            	    fully_qualified_class_name106=fully_qualified_class_name();

            	    state._fsp--;

            	    adaptor.addChild(root_0, fully_qualified_class_name106.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt37 >= 1 ) break loop37;
                        EarlyExitException eee =
                            new EarlyExitException(37, input);
                        throw eee;
                }
                cnt37++;
            } while (true);


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "fully_qualified_class_name_list"

    public static class fully_qualified_class_name_return extends TreeRuleReturnScope {
        public String name;
        public TypeReference type;
        public StaticConstantAccess constant;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "fully_qualified_class_name"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:537:1: fully_qualified_class_name returns [String name, TypeReference type, StaticConstantAccess constant] : ( ^(d= DOMAIN_T f= fully_qualified_class_name IDENTIFIER ) ( DOMAIN_T )? | IDENTIFIER ( DOMAIN_T )? );
    public final TreePHP.fully_qualified_class_name_return fully_qualified_class_name() throws RecognitionException {
        TreePHP.fully_qualified_class_name_return retval = new TreePHP.fully_qualified_class_name_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST d=null;
        SLAST IDENTIFIER107=null;
        SLAST DOMAIN_T108=null;
        SLAST IDENTIFIER109=null;
        SLAST DOMAIN_T110=null;
        TreePHP.fully_qualified_class_name_return f = null;


        SLAST d_tree=null;
        SLAST IDENTIFIER107_tree=null;
        SLAST DOMAIN_T108_tree=null;
        SLAST IDENTIFIER109_tree=null;
        SLAST DOMAIN_T110_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:538:3: ( ^(d= DOMAIN_T f= fully_qualified_class_name IDENTIFIER ) ( DOMAIN_T )? | IDENTIFIER ( DOMAIN_T )? )
            int alt40=2;
            int LA40_0 = input.LA(1);

            if ( (LA40_0==DOMAIN_T) ) {
                alt40=1;
            }
            else if ( (LA40_0==IDENTIFIER) ) {
                alt40=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 40, 0, input);

                throw nvae;
            }
            switch (alt40) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:538:5: ^(d= DOMAIN_T f= fully_qualified_class_name IDENTIFIER ) ( DOMAIN_T )?
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    d=(SLAST)match(input,DOMAIN_T,FOLLOW_DOMAIN_T_in_fully_qualified_class_name1047); 
                    d_tree = (SLAST)adaptor.dupNode(d);

                    root_1 = (SLAST)adaptor.becomeRoot(d_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_fully_qualified_class_name_in_fully_qualified_class_name1051);
                    f=fully_qualified_class_name();

                    state._fsp--;

                    adaptor.addChild(root_1, f.getTree());
                    _last = (SLAST)input.LT(1);
                    IDENTIFIER107=(SLAST)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_fully_qualified_class_name1053); 
                    IDENTIFIER107_tree = (SLAST)adaptor.dupNode(IDENTIFIER107);

                    adaptor.addChild(root_1, IDENTIFIER107_tree);


                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:538:59: ( DOMAIN_T )?
                    int alt38=2;
                    int LA38_0 = input.LA(1);

                    if ( (LA38_0==DOMAIN_T) ) {
                        int LA38_1 = input.LA(2);

                        if ( (LA38_1==UP||LA38_1==INDEX||LA38_1==ARGU||LA38_1==VAR||LA38_1==IDENTIFIER||LA38_1==DOMAIN_T) ) {
                            alt38=1;
                        }
                    }
                    switch (alt38) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:538:59: DOMAIN_T
                            {
                            _last = (SLAST)input.LT(1);
                            DOMAIN_T108=(SLAST)match(input,DOMAIN_T,FOLLOW_DOMAIN_T_in_fully_qualified_class_name1056); 
                            DOMAIN_T108_tree = (SLAST)adaptor.dupNode(DOMAIN_T108);

                            adaptor.addChild(root_0, DOMAIN_T108_tree);


                            }
                            break;

                    }


                        int startIndex = d.startIndex;
                        int endIndex = d.endIndex + 1;
                        String className = null;
                        TypeReference type = null;
                        if ((f!=null?f.name:null) != null) {
                          className = (f!=null?f.name:null);
                          int typeLeft = ((CommonToken)(f!=null?((SLAST)f.tree):null).token).getStartIndex();
                          int typeRight = ((CommonToken)(f!=null?((SLAST)f.tree):null).token).getStopIndex() + 1;
                          type = new TypeReference(typeLeft, typeRight, className);
                        }
                        else {
                          type = retval.type;
                        }
                          
                        CommonToken token = (CommonToken)IDENTIFIER107.token;
                        int varLeft = token.getStartIndex();
                        int varRight = token.getStopIndex();
                        ConstantReference constRef = new ConstantReference(varLeft, varRight, (IDENTIFIER107!=null?IDENTIFIER107.getText():null));
                        retval.constant = new StaticConstantAccess(startIndex, endIndex, type, constRef);
                      

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:560:5: IDENTIFIER ( DOMAIN_T )?
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    IDENTIFIER109=(SLAST)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_fully_qualified_class_name1067); 
                    IDENTIFIER109_tree = (SLAST)adaptor.dupNode(IDENTIFIER109);

                    adaptor.addChild(root_0, IDENTIFIER109_tree);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:560:16: ( DOMAIN_T )?
                    int alt39=2;
                    int LA39_0 = input.LA(1);

                    if ( (LA39_0==DOMAIN_T) ) {
                        int LA39_1 = input.LA(2);

                        if ( (LA39_1==UP||LA39_1==INDEX||LA39_1==ARGU||LA39_1==VAR||LA39_1==IDENTIFIER||LA39_1==DOMAIN_T) ) {
                            alt39=1;
                        }
                    }
                    switch (alt39) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:560:16: DOMAIN_T
                            {
                            _last = (SLAST)input.LT(1);
                            DOMAIN_T110=(SLAST)match(input,DOMAIN_T,FOLLOW_DOMAIN_T_in_fully_qualified_class_name1069); 
                            DOMAIN_T110_tree = (SLAST)adaptor.dupNode(DOMAIN_T110);

                            adaptor.addChild(root_0, DOMAIN_T110_tree);


                            }
                            break;

                    }


                        retval.name = (IDENTIFIER109!=null?IDENTIFIER109.getText():null);
                        int typeLeft = ((CommonToken)IDENTIFIER109.token).getStartIndex();
                        int typeRight = ((CommonToken)IDENTIFIER109.token).getStopIndex();
                        if ((DOMAIN_T110!=null?DOMAIN_T110.getText():null) != null) {
                          typeRight = ((CommonToken)DOMAIN_T110.token).getStopIndex();
                        }
                        retval.type = new TypeReference(typeLeft, typeRight, (IDENTIFIER109!=null?IDENTIFIER109.getText():null));
                      

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "fully_qualified_class_name"

    public static class static_array_pair_list_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "static_array_pair_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:572:1: static_array_pair_list : ( ^( SCALAR_ELEMENT static_scalar_element ) )+ ;
    public final TreePHP.static_array_pair_list_return static_array_pair_list() throws RecognitionException {
        TreePHP.static_array_pair_list_return retval = new TreePHP.static_array_pair_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST SCALAR_ELEMENT111=null;
        TreePHP.static_scalar_element_return static_scalar_element112 = null;


        SLAST SCALAR_ELEMENT111_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:573:3: ( ( ^( SCALAR_ELEMENT static_scalar_element ) )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:573:5: ( ^( SCALAR_ELEMENT static_scalar_element ) )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:573:5: ( ^( SCALAR_ELEMENT static_scalar_element ) )+
            int cnt41=0;
            loop41:
            do {
                int alt41=2;
                int LA41_0 = input.LA(1);

                if ( (LA41_0==SCALAR_ELEMENT) ) {
                    alt41=1;
                }


                switch (alt41) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:573:6: ^( SCALAR_ELEMENT static_scalar_element )
            	    {
            	    _last = (SLAST)input.LT(1);
            	    {
            	    SLAST _save_last_1 = _last;
            	    SLAST _first_1 = null;
            	    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            	    SCALAR_ELEMENT111=(SLAST)match(input,SCALAR_ELEMENT,FOLLOW_SCALAR_ELEMENT_in_static_array_pair_list1091); 
            	    SCALAR_ELEMENT111_tree = (SLAST)adaptor.dupNode(SCALAR_ELEMENT111);

            	    root_1 = (SLAST)adaptor.becomeRoot(SCALAR_ELEMENT111_tree, root_1);



            	    match(input, Token.DOWN, null); 
            	    _last = (SLAST)input.LT(1);
            	    pushFollow(FOLLOW_static_scalar_element_in_static_array_pair_list1093);
            	    static_scalar_element112=static_scalar_element();

            	    state._fsp--;

            	    adaptor.addChild(root_1, static_scalar_element112.getTree());

            	    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt41 >= 1 ) break loop41;
                        EarlyExitException eee =
                            new EarlyExitException(41, input);
                        throw eee;
                }
                cnt41++;
            } while (true);


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "static_array_pair_list"

    public static class static_scalar_element_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "static_scalar_element"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:576:1: static_scalar_element : scalar ( ARROW_T scalar )? ;
    public final TreePHP.static_scalar_element_return static_scalar_element() throws RecognitionException {
        TreePHP.static_scalar_element_return retval = new TreePHP.static_scalar_element_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST ARROW_T114=null;
        TreePHP.scalar_return scalar113 = null;

        TreePHP.scalar_return scalar115 = null;


        SLAST ARROW_T114_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:577:3: ( scalar ( ARROW_T scalar )? )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:577:5: scalar ( ARROW_T scalar )?
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            pushFollow(FOLLOW_scalar_in_static_scalar_element1110);
            scalar113=scalar();

            state._fsp--;

            adaptor.addChild(root_0, scalar113.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:577:12: ( ARROW_T scalar )?
            int alt42=2;
            int LA42_0 = input.LA(1);

            if ( (LA42_0==ARROW_T) ) {
                alt42=1;
            }
            switch (alt42) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:577:13: ARROW_T scalar
                    {
                    _last = (SLAST)input.LT(1);
                    ARROW_T114=(SLAST)match(input,ARROW_T,FOLLOW_ARROW_T_in_static_scalar_element1113); 
                    ARROW_T114_tree = (SLAST)adaptor.dupNode(ARROW_T114);

                    root_0 = (SLAST)adaptor.becomeRoot(ARROW_T114_tree, root_0);

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_scalar_in_static_scalar_element1116);
                    scalar115=scalar();

                    state._fsp--;

                    adaptor.addChild(root_0, scalar115.getTree());

                    }
                    break;

            }


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "static_scalar_element"

    protected static class static_var_list_scope {
        List varList;
    }
    protected Stack static_var_list_stack = new Stack();

    public static class static_var_list_return extends TreeRuleReturnScope {
        public List staticVarList;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "static_var_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:580:1: static_var_list returns [List staticVarList] : ( static_var_element )+ ;
    public final TreePHP.static_var_list_return static_var_list() throws RecognitionException {
        static_var_list_stack.push(new static_var_list_scope());
        TreePHP.static_var_list_return retval = new TreePHP.static_var_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.static_var_element_return static_var_element116 = null;




          ((static_var_list_scope)static_var_list_stack.peek()).varList = new LinkedList();

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:587:3: ( ( static_var_element )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:587:5: ( static_var_element )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:587:5: ( static_var_element )+
            int cnt43=0;
            loop43:
            do {
                int alt43=2;
                int LA43_0 = input.LA(1);

                if ( (LA43_0==VAR_DECL||LA43_0==EQUAL_T) ) {
                    alt43=1;
                }


                switch (alt43) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:587:5: static_var_element
            	    {
            	    _last = (SLAST)input.LT(1);
            	    pushFollow(FOLLOW_static_var_element_in_static_var_list1146);
            	    static_var_element116=static_var_element();

            	    state._fsp--;

            	    adaptor.addChild(root_0, static_var_element116.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt43 >= 1 ) break loop43;
                        EarlyExitException eee =
                            new EarlyExitException(43, input);
                        throw eee;
                }
                cnt43++;
            } while (true);


                retval.staticVarList = ((static_var_list_scope)static_var_list_stack.peek()).varList;
              

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
            static_var_list_stack.pop();
        }
        return retval;
    }
    // $ANTLR end "static_var_list"

    public static class static_var_element_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "static_var_element"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:593:1: static_var_element : ( pure_variable | ^( EQUAL_T pure_variable scalar ) );
    public final TreePHP.static_var_element_return static_var_element() throws RecognitionException {
        TreePHP.static_var_element_return retval = new TreePHP.static_var_element_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST EQUAL_T118=null;
        TreePHP.pure_variable_return pure_variable117 = null;

        TreePHP.pure_variable_return pure_variable119 = null;

        TreePHP.scalar_return scalar120 = null;


        SLAST EQUAL_T118_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:594:3: ( pure_variable | ^( EQUAL_T pure_variable scalar ) )
            int alt44=2;
            int LA44_0 = input.LA(1);

            if ( (LA44_0==VAR_DECL) ) {
                alt44=1;
            }
            else if ( (LA44_0==EQUAL_T) ) {
                alt44=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 44, 0, input);

                throw nvae;
            }
            switch (alt44) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:594:5: pure_variable
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_pure_variable_in_static_var_element1164);
                    pure_variable117=pure_variable();

                    state._fsp--;

                    adaptor.addChild(root_0, pure_variable117.getTree());

                        int varNameLeft = ((CommonToken)(pure_variable117!=null?((SLAST)pure_variable117.tree):null).token).getStartIndex();
                        int varNameRight = ((CommonToken)(pure_variable117!=null?((SLAST)pure_variable117.tree):null).token).getStopIndex();
                        String varName = (pure_variable117!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(pure_variable117.start),
                      input.getTreeAdaptor().getTokenStopIndex(pure_variable117.start))):null);
                        VariableReference varId = new VariableReference(varNameLeft, varNameRight, varName);
                        
                        if (inClassStatementList) {
                          Object obj = new ASTNode[] {varId, null};
                          ((class_statement_scope)class_statement_stack.peek()).varList.add(obj);
                        }
                        else {
                          ((static_var_list_scope)static_var_list_stack.peek()).varList.add(varId);
                        }
                      

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:609:5: ^( EQUAL_T pure_variable scalar )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    EQUAL_T118=(SLAST)match(input,EQUAL_T,FOLLOW_EQUAL_T_in_static_var_element1175); 
                    EQUAL_T118_tree = (SLAST)adaptor.dupNode(EQUAL_T118);

                    root_1 = (SLAST)adaptor.becomeRoot(EQUAL_T118_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_pure_variable_in_static_var_element1177);
                    pure_variable119=pure_variable();

                    state._fsp--;

                    adaptor.addChild(root_1, pure_variable119.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_scalar_in_static_var_element1179);
                    scalar120=scalar();

                    state._fsp--;

                    adaptor.addChild(root_1, scalar120.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int varNameLeft = ((CommonToken)(pure_variable119!=null?((SLAST)pure_variable119.tree):null).token).getStartIndex();
                        int varNameRight = ((CommonToken)(pure_variable119!=null?((SLAST)pure_variable119.tree):null).token).getStopIndex();
                        String varName = (pure_variable119!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(pure_variable119.start),
                      input.getTreeAdaptor().getTokenStopIndex(pure_variable119.start))):null);
                        Expression expr = (scalar120!=null?scalar120.expr:null);
                        
                        VariableReference varId = new VariableReference(varNameLeft, varNameRight, varName);

                        if (inClassStatementList) {
                          Object obj = new ASTNode[] {varId, expr};
                          ((class_statement_scope)class_statement_stack.peek()).varList.add(obj);
                        }
                        else {
                          ((static_var_list_scope)static_var_list_stack.peek()).varList.add(varId);
                        }
                      

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "static_var_element"

    protected static class if_stat_scope {
        List conditionList;
        List statementList;
        List tokenList;
    }
    protected Stack if_stat_stack = new Stack();

    public static class if_stat_return extends TreeRuleReturnScope {
        public Statement stat;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "if_stat"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:628:1: if_stat returns [Statement stat] : ^( IF_T ^( CONDITION expression ) ( ( inner_statement_list )? ( else_if_stat )* ( ^( ELSE_T statement ) )? ) ) ;
    public final TreePHP.if_stat_return if_stat() throws RecognitionException {
        if_stat_stack.push(new if_stat_scope());
        TreePHP.if_stat_return retval = new TreePHP.if_stat_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST IF_T121=null;
        SLAST CONDITION122=null;
        SLAST ELSE_T126=null;
        TreePHP.expression_return expression123 = null;

        TreePHP.inner_statement_list_return inner_statement_list124 = null;

        TreePHP.else_if_stat_return else_if_stat125 = null;

        TreePHP.statement_return statement127 = null;


        SLAST IF_T121_tree=null;
        SLAST CONDITION122_tree=null;
        SLAST ELSE_T126_tree=null;


          ((if_stat_scope)if_stat_stack.peek()).conditionList = new LinkedList();
          ((if_stat_scope)if_stat_stack.peek()).statementList = new LinkedList();
          ((if_stat_scope)if_stat_stack.peek()).tokenList = new LinkedList();

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:639:3: ( ^( IF_T ^( CONDITION expression ) ( ( inner_statement_list )? ( else_if_stat )* ( ^( ELSE_T statement ) )? ) ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:639:5: ^( IF_T ^( CONDITION expression ) ( ( inner_statement_list )? ( else_if_stat )* ( ^( ELSE_T statement ) )? ) )
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_1 = _last;
            SLAST _first_1 = null;
            SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            IF_T121=(SLAST)match(input,IF_T,FOLLOW_IF_T_in_if_stat1213); 
            IF_T121_tree = (SLAST)adaptor.dupNode(IF_T121);

            root_1 = (SLAST)adaptor.becomeRoot(IF_T121_tree, root_1);



            match(input, Token.DOWN, null); 
            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_2 = _last;
            SLAST _first_2 = null;
            SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            CONDITION122=(SLAST)match(input,CONDITION,FOLLOW_CONDITION_in_if_stat1216); 
            CONDITION122_tree = (SLAST)adaptor.dupNode(CONDITION122);

            root_2 = (SLAST)adaptor.becomeRoot(CONDITION122_tree, root_2);



            match(input, Token.DOWN, null); 
            _last = (SLAST)input.LT(1);
            pushFollow(FOLLOW_expression_in_if_stat1218);
            expression123=expression();

            state._fsp--;

            adaptor.addChild(root_2, expression123.getTree());

            match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:640:5: ( ( inner_statement_list )? ( else_if_stat )* ( ^( ELSE_T statement ) )? )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:641:7: ( inner_statement_list )? ( else_if_stat )* ( ^( ELSE_T statement ) )?
            {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:641:7: ( inner_statement_list )?
            int alt45=2;
            int LA45_0 = input.LA(1);

            if ( (LA45_0==STATEMENT||LA45_0==CLASS_T||(LA45_0>=INTERFACE_T && LA45_0<=FUNCTION_T)||LA45_0==161) ) {
                alt45=1;
            }
            switch (alt45) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:641:7: inner_statement_list
                    {
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_inner_statement_list_in_if_stat1234);
                    inner_statement_list124=inner_statement_list();

                    state._fsp--;

                    adaptor.addChild(root_1, inner_statement_list124.getTree());

                    }
                    break;

            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:642:7: ( else_if_stat )*
            loop46:
            do {
                int alt46=2;
                int LA46_0 = input.LA(1);

                if ( (LA46_0==ELSEIF_T) ) {
                    alt46=1;
                }


                switch (alt46) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:642:7: else_if_stat
            	    {
            	    _last = (SLAST)input.LT(1);
            	    pushFollow(FOLLOW_else_if_stat_in_if_stat1243);
            	    else_if_stat125=else_if_stat();

            	    state._fsp--;

            	    adaptor.addChild(root_1, else_if_stat125.getTree());

            	    }
            	    break;

            	default :
            	    break loop46;
                }
            } while (true);

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:642:21: ( ^( ELSE_T statement ) )?
            int alt47=2;
            int LA47_0 = input.LA(1);

            if ( (LA47_0==ELSE_T) ) {
                alt47=1;
            }
            switch (alt47) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:642:22: ^( ELSE_T statement )
                    {
                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_2 = _last;
                    SLAST _first_2 = null;
                    SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    ELSE_T126=(SLAST)match(input,ELSE_T,FOLLOW_ELSE_T_in_if_stat1248); 
                    ELSE_T126_tree = (SLAST)adaptor.dupNode(ELSE_T126);

                    root_2 = (SLAST)adaptor.becomeRoot(ELSE_T126_tree, root_2);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_statement_in_if_stat1250);
                    statement127=statement();

                    state._fsp--;

                    adaptor.addChild(root_2, statement127.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
                    }


                    }
                    break;

            }


            }


            match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


                  int startIndex = IF_T121.startIndex;
                  int endIndex = IF_T121.endIndex;
                  Expression innerCondition = null; 
                  Statement trueStatement = null;
                  Statement falseStatement = (statement127!=null?statement127.stat:null);
                  Iterator iterCond = ((if_stat_scope)if_stat_stack.peek()).conditionList.iterator(),
                          iterIfTrueStat = ((if_stat_scope)if_stat_stack.peek()).statementList.iterator(),
                          iterTokenList = ((if_stat_scope)if_stat_stack.peek()).tokenList.iterator();
                  while (iterCond.hasNext()) {
                     innerCondition = (Expression)iterCond.next();
                     trueStatement = (Statement)iterIfTrueStat.next();
                     int start = (Integer)iterTokenList.next();
                     falseStatement = new IfStatement(start, 999, innerCondition, trueStatement, falseStatement);
                  }
                  
                  int sid = ((CommonToken)(inner_statement_list124!=null?((SLAST)inner_statement_list124.tree):null).token).getStartIndex();
                  int eid = ((CommonToken)(inner_statement_list124!=null?((SLAST)inner_statement_list124.tree):null).token).getStopIndex();
                  Block block = new Block(sid, eid, new LinkedList());
                  if ((inner_statement_list124!=null?inner_statement_list124.innerStatementList:null) != null) {
                    block.getStatements().clear();
                    block.acceptStatements((inner_statement_list124!=null?inner_statement_list124.innerStatementList:null));
                  }
                  retval.stat = new IfStatement(startIndex, endIndex, (expression123!=null?expression123.expr:null), block, falseStatement);  
                

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
            if_stat_stack.pop();
        }
        return retval;
    }
    // $ANTLR end "if_stat"

    public static class else_if_stat_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "else_if_stat"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:671:1: else_if_stat : ^( ELSEIF_T ^( CONDITION expression ) ( inner_statement_list )? ) ;
    public final TreePHP.else_if_stat_return else_if_stat() throws RecognitionException {
        TreePHP.else_if_stat_return retval = new TreePHP.else_if_stat_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST ELSEIF_T128=null;
        SLAST CONDITION129=null;
        TreePHP.expression_return expression130 = null;

        TreePHP.inner_statement_list_return inner_statement_list131 = null;


        SLAST ELSEIF_T128_tree=null;
        SLAST CONDITION129_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:672:3: ( ^( ELSEIF_T ^( CONDITION expression ) ( inner_statement_list )? ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:672:5: ^( ELSEIF_T ^( CONDITION expression ) ( inner_statement_list )? )
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_1 = _last;
            SLAST _first_1 = null;
            SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            ELSEIF_T128=(SLAST)match(input,ELSEIF_T,FOLLOW_ELSEIF_T_in_else_if_stat1280); 
            ELSEIF_T128_tree = (SLAST)adaptor.dupNode(ELSEIF_T128);

            root_1 = (SLAST)adaptor.becomeRoot(ELSEIF_T128_tree, root_1);



            match(input, Token.DOWN, null); 
            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_2 = _last;
            SLAST _first_2 = null;
            SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            CONDITION129=(SLAST)match(input,CONDITION,FOLLOW_CONDITION_in_else_if_stat1283); 
            CONDITION129_tree = (SLAST)adaptor.dupNode(CONDITION129);

            root_2 = (SLAST)adaptor.becomeRoot(CONDITION129_tree, root_2);



            match(input, Token.DOWN, null); 
            _last = (SLAST)input.LT(1);
            pushFollow(FOLLOW_expression_in_else_if_stat1285);
            expression130=expression();

            state._fsp--;

            adaptor.addChild(root_2, expression130.getTree());

            match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:672:40: ( inner_statement_list )?
            int alt48=2;
            int LA48_0 = input.LA(1);

            if ( (LA48_0==STATEMENT||LA48_0==CLASS_T||(LA48_0>=INTERFACE_T && LA48_0<=FUNCTION_T)||LA48_0==161) ) {
                alt48=1;
            }
            switch (alt48) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:672:40: inner_statement_list
                    {
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_inner_statement_list_in_else_if_stat1288);
                    inner_statement_list131=inner_statement_list();

                    state._fsp--;

                    adaptor.addChild(root_1, inner_statement_list131.getTree());

                    }
                    break;

            }


            match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


                int startIndex = ELSEIF_T128.startIndex;
                ((if_stat_scope)if_stat_stack.peek()).conditionList.add((expression130!=null?expression130.expr:null));
                
                Block block = new Block(999, 999, new LinkedList());
                if ((inner_statement_list131!=null?inner_statement_list131.innerStatementList:null) != null) {
                  block.getStatements().clear();
                  block.acceptStatements((inner_statement_list131!=null?inner_statement_list131.innerStatementList:null));
                }
                ((if_stat_scope)if_stat_stack.peek()).statementList.add(block);
                ((if_stat_scope)if_stat_stack.peek()).tokenList.add(startIndex);
              

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "else_if_stat"

    public static class switch_case_list_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "switch_case_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:688:1: switch_case_list : ( case_list )+ ;
    public final TreePHP.switch_case_list_return switch_case_list() throws RecognitionException {
        TreePHP.switch_case_list_return retval = new TreePHP.switch_case_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.case_list_return case_list132 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:689:3: ( ( case_list )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:689:5: ( case_list )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:689:5: ( case_list )+
            int cnt49=0;
            loop49:
            do {
                int alt49=2;
                int LA49_0 = input.LA(1);

                if ( ((LA49_0>=CASE_T && LA49_0<=DEFAULT_T)) ) {
                    alt49=1;
                }


                switch (alt49) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:689:5: case_list
            	    {
            	    _last = (SLAST)input.LT(1);
            	    pushFollow(FOLLOW_case_list_in_switch_case_list1309);
            	    case_list132=case_list();

            	    state._fsp--;

            	    adaptor.addChild(root_0, case_list132.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt49 >= 1 ) break loop49;
                        EarlyExitException eee =
                            new EarlyExitException(49, input);
                        throw eee;
                }
                cnt49++;
            } while (true);


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "switch_case_list"

    public static class case_list_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "case_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:692:1: case_list : ( ^( CASE_T expression ( inner_statement_list )? ) | ^( DEFAULT_T ( inner_statement_list )? ) );
    public final TreePHP.case_list_return case_list() throws RecognitionException {
        TreePHP.case_list_return retval = new TreePHP.case_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST CASE_T133=null;
        SLAST DEFAULT_T136=null;
        TreePHP.expression_return expression134 = null;

        TreePHP.inner_statement_list_return inner_statement_list135 = null;

        TreePHP.inner_statement_list_return inner_statement_list137 = null;


        SLAST CASE_T133_tree=null;
        SLAST DEFAULT_T136_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:693:3: ( ^( CASE_T expression ( inner_statement_list )? ) | ^( DEFAULT_T ( inner_statement_list )? ) )
            int alt52=2;
            int LA52_0 = input.LA(1);

            if ( (LA52_0==CASE_T) ) {
                alt52=1;
            }
            else if ( (LA52_0==DEFAULT_T) ) {
                alt52=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 52, 0, input);

                throw nvae;
            }
            switch (alt52) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:693:5: ^( CASE_T expression ( inner_statement_list )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    CASE_T133=(SLAST)match(input,CASE_T,FOLLOW_CASE_T_in_case_list1324); 
                    CASE_T133_tree = (SLAST)adaptor.dupNode(CASE_T133);

                    root_1 = (SLAST)adaptor.becomeRoot(CASE_T133_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_case_list1326);
                    expression134=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression134.getTree());
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:693:25: ( inner_statement_list )?
                    int alt50=2;
                    int LA50_0 = input.LA(1);

                    if ( (LA50_0==STATEMENT||LA50_0==CLASS_T||(LA50_0>=INTERFACE_T && LA50_0<=FUNCTION_T)||LA50_0==161) ) {
                        alt50=1;
                    }
                    switch (alt50) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:693:25: inner_statement_list
                            {
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_inner_statement_list_in_case_list1328);
                            inner_statement_list135=inner_statement_list();

                            state._fsp--;

                            adaptor.addChild(root_1, inner_statement_list135.getTree());

                            }
                            break;

                    }


                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:694:5: ^( DEFAULT_T ( inner_statement_list )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    DEFAULT_T136=(SLAST)match(input,DEFAULT_T,FOLLOW_DEFAULT_T_in_case_list1337); 
                    DEFAULT_T136_tree = (SLAST)adaptor.dupNode(DEFAULT_T136);

                    root_1 = (SLAST)adaptor.becomeRoot(DEFAULT_T136_tree, root_1);



                    if ( input.LA(1)==Token.DOWN ) {
                        match(input, Token.DOWN, null); 
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:694:17: ( inner_statement_list )?
                        int alt51=2;
                        int LA51_0 = input.LA(1);

                        if ( (LA51_0==STATEMENT||LA51_0==CLASS_T||(LA51_0>=INTERFACE_T && LA51_0<=FUNCTION_T)||LA51_0==161) ) {
                            alt51=1;
                        }
                        switch (alt51) {
                            case 1 :
                                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:694:17: inner_statement_list
                                {
                                _last = (SLAST)input.LT(1);
                                pushFollow(FOLLOW_inner_statement_list_in_case_list1339);
                                inner_statement_list137=inner_statement_list();

                                state._fsp--;

                                adaptor.addChild(root_1, inner_statement_list137.getTree());

                                }
                                break;

                        }


                        match(input, Token.UP, null); 
                    }adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "case_list"

    public static class catch_branch_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "catch_branch"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:697:1: catch_branch : ^( CATCH_T IDENTIFIER variable block ) ;
    public final TreePHP.catch_branch_return catch_branch() throws RecognitionException {
        TreePHP.catch_branch_return retval = new TreePHP.catch_branch_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST CATCH_T138=null;
        SLAST IDENTIFIER139=null;
        TreePHP.variable_return variable140 = null;

        TreePHP.block_return block141 = null;


        SLAST CATCH_T138_tree=null;
        SLAST IDENTIFIER139_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:698:3: ( ^( CATCH_T IDENTIFIER variable block ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:698:5: ^( CATCH_T IDENTIFIER variable block )
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_1 = _last;
            SLAST _first_1 = null;
            SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            CATCH_T138=(SLAST)match(input,CATCH_T,FOLLOW_CATCH_T_in_catch_branch1356); 
            CATCH_T138_tree = (SLAST)adaptor.dupNode(CATCH_T138);

            root_1 = (SLAST)adaptor.becomeRoot(CATCH_T138_tree, root_1);



            match(input, Token.DOWN, null); 
            _last = (SLAST)input.LT(1);
            IDENTIFIER139=(SLAST)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_catch_branch1358); 
            IDENTIFIER139_tree = (SLAST)adaptor.dupNode(IDENTIFIER139);

            adaptor.addChild(root_1, IDENTIFIER139_tree);

            _last = (SLAST)input.LT(1);
            pushFollow(FOLLOW_variable_in_catch_branch1360);
            variable140=variable();

            state._fsp--;

            adaptor.addChild(root_1, variable140.getTree());
            _last = (SLAST)input.LT(1);
            pushFollow(FOLLOW_block_in_catch_branch1362);
            block141=block();

            state._fsp--;

            adaptor.addChild(root_1, block141.getTree());

            match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "catch_branch"

    public static class for_statement_return extends TreeRuleReturnScope {
        public Statement block;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "for_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:701:1: for_statement returns [Statement block] : ( inner_statement_list )? ;
    public final TreePHP.for_statement_return for_statement() throws RecognitionException {
        TreePHP.for_statement_return retval = new TreePHP.for_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.inner_statement_list_return inner_statement_list142 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:702:2: ( ( inner_statement_list )? )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:702:4: ( inner_statement_list )?
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:702:4: ( inner_statement_list )?
            int alt53=2;
            int LA53_0 = input.LA(1);

            if ( (LA53_0==STATEMENT||LA53_0==CLASS_T||(LA53_0>=INTERFACE_T && LA53_0<=FUNCTION_T)||LA53_0==161) ) {
                alt53=1;
            }
            switch (alt53) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:702:4: inner_statement_list
                    {
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_inner_statement_list_in_for_statement1379);
                    inner_statement_list142=inner_statement_list();

                    state._fsp--;

                    adaptor.addChild(root_0, inner_statement_list142.getTree());

                    }
                    break;

            }


                  int startIndex = -1;
                  int endIndex = -1;
                  Block block = new Block(startIndex, endIndex, new LinkedList());
                  if ((inner_statement_list142!=null?inner_statement_list142.innerStatementList:null) != null) {
                    block.getStatements().clear();
                    block.acceptStatements((inner_statement_list142!=null?inner_statement_list142.innerStatementList:null));
                  }

                  retval.block = block;
                  System.out.println("what block" + block);
                

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "for_statement"

    public static class while_statement_return extends TreeRuleReturnScope {
        public Statement block;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "while_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:717:1: while_statement returns [Statement block] : ( inner_statement_list )? ;
    public final TreePHP.while_statement_return while_statement() throws RecognitionException {
        TreePHP.while_statement_return retval = new TreePHP.while_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.inner_statement_list_return inner_statement_list143 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:718:3: ( ( inner_statement_list )? )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:718:5: ( inner_statement_list )?
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:718:5: ( inner_statement_list )?
            int alt54=2;
            int LA54_0 = input.LA(1);

            if ( (LA54_0==STATEMENT||LA54_0==CLASS_T||(LA54_0>=INTERFACE_T && LA54_0<=FUNCTION_T)||LA54_0==161) ) {
                alt54=1;
            }
            switch (alt54) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:718:5: inner_statement_list
                    {
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_inner_statement_list_in_while_statement1402);
                    inner_statement_list143=inner_statement_list();

                    state._fsp--;

                    adaptor.addChild(root_0, inner_statement_list143.getTree());

                    }
                    break;

            }


                  int startIndex = -1;
                  int endIndex = -1;
                  Block block = new Block(startIndex, endIndex, new LinkedList());
                  if ((inner_statement_list143!=null?inner_statement_list143.innerStatementList:null) != null) {
                    block.getStatements().clear();
                    block.acceptStatements((inner_statement_list143!=null?inner_statement_list143.innerStatementList:null));
                  }
                  retval.block = block;
                

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "while_statement"

    public static class foreach_statement_return extends TreeRuleReturnScope {
        public Statement block;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "foreach_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:731:1: foreach_statement returns [Statement block] : ( inner_statement_list )? ;
    public final TreePHP.foreach_statement_return foreach_statement() throws RecognitionException {
        TreePHP.foreach_statement_return retval = new TreePHP.foreach_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.inner_statement_list_return inner_statement_list144 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:732:3: ( ( inner_statement_list )? )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:732:5: ( inner_statement_list )?
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:732:5: ( inner_statement_list )?
            int alt55=2;
            int LA55_0 = input.LA(1);

            if ( (LA55_0==STATEMENT||LA55_0==CLASS_T||(LA55_0>=INTERFACE_T && LA55_0<=FUNCTION_T)||LA55_0==161) ) {
                alt55=1;
            }
            switch (alt55) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:732:5: inner_statement_list
                    {
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_inner_statement_list_in_foreach_statement1427);
                    inner_statement_list144=inner_statement_list();

                    state._fsp--;

                    adaptor.addChild(root_0, inner_statement_list144.getTree());

                    }
                    break;

            }


                  int startIndex = -1;
                  int endIndex = -1;
                  Block block = new Block(startIndex, endIndex, new LinkedList());
                  if ((inner_statement_list144!=null?inner_statement_list144.innerStatementList:null) != null) {
                    block.getStatements().clear();
                    block.acceptStatements((inner_statement_list144!=null?inner_statement_list144.innerStatementList:null));
                  }
                  retval.block = block;
                

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "foreach_statement"

    public static class declare_statement_return extends TreeRuleReturnScope {
        public Statement block;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "declare_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:745:1: declare_statement returns [Statement block] : ( inner_statement_list )? ;
    public final TreePHP.declare_statement_return declare_statement() throws RecognitionException {
        TreePHP.declare_statement_return retval = new TreePHP.declare_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.inner_statement_list_return inner_statement_list145 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:746:3: ( ( inner_statement_list )? )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:747:3: ( inner_statement_list )?
            {
            root_0 = (SLAST)adaptor.nil();


                System.out.println("declare ssssssssstat");
              
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:751:3: ( inner_statement_list )?
            int alt56=2;
            int LA56_0 = input.LA(1);

            if ( (LA56_0==STATEMENT||LA56_0==CLASS_T||(LA56_0>=INTERFACE_T && LA56_0<=FUNCTION_T)||LA56_0==161) ) {
                alt56=1;
            }
            switch (alt56) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:751:3: inner_statement_list
                    {
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_inner_statement_list_in_declare_statement1463);
                    inner_statement_list145=inner_statement_list();

                    state._fsp--;

                    adaptor.addChild(root_0, inner_statement_list145.getTree());

                    }
                    break;

            }


                  System.out.println("declare stat");
                  int startIndex = -1;
                  int endIndex = -1;
                  Block block = new Block(startIndex, endIndex, new LinkedList());
                  if ((inner_statement_list145!=null?inner_statement_list145.innerStatementList:null) != null) {
            			  block.getStatements().clear();
            			  block.acceptStatements((inner_statement_list145!=null?inner_statement_list145.innerStatementList:null));
            			}
            			retval.block = block;
                

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "declare_statement"

    protected static class parameter_list_scope {
        List paramList;
    }
    protected Stack parameter_list_stack = new Stack();

    public static class parameter_list_return extends TreeRuleReturnScope {
        public List parameterList;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "parameter_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:765:1: parameter_list returns [List parameterList] : ( parameter )+ ;
    public final TreePHP.parameter_list_return parameter_list() throws RecognitionException {
        parameter_list_stack.push(new parameter_list_scope());
        TreePHP.parameter_list_return retval = new TreePHP.parameter_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.parameter_return parameter146 = null;




          ((parameter_list_scope)parameter_list_stack.peek()).paramList = new LinkedList();

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:772:3: ( ( parameter )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:772:5: ( parameter )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:772:5: ( parameter )+
            int cnt57=0;
            loop57:
            do {
                int alt57=2;
                int LA57_0 = input.LA(1);

                if ( (LA57_0==PARAMETER) ) {
                    alt57=1;
                }


                switch (alt57) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:772:5: parameter
            	    {
            	    _last = (SLAST)input.LT(1);
            	    pushFollow(FOLLOW_parameter_in_parameter_list1498);
            	    parameter146=parameter();

            	    state._fsp--;

            	    adaptor.addChild(root_0, parameter146.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt57 >= 1 ) break loop57;
                        EarlyExitException eee =
                            new EarlyExitException(57, input);
                        throw eee;
                }
                cnt57++;
            } while (true);


                retval.parameterList = ((parameter_list_scope)parameter_list_stack.peek()).paramList;
              

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
            parameter_list_stack.pop();
        }
        return retval;
    }
    // $ANTLR end "parameter_list"

    public static class parameter_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "parameter"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:778:1: parameter : ^( PARAMETER ( ^( TYPE parameter_type ) )? ( CONST_T )? pure_variable ( scalar )? ) ;
    public final TreePHP.parameter_return parameter() throws RecognitionException {
        TreePHP.parameter_return retval = new TreePHP.parameter_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST PARAMETER147=null;
        SLAST TYPE148=null;
        SLAST CONST_T150=null;
        TreePHP.parameter_type_return parameter_type149 = null;

        TreePHP.pure_variable_return pure_variable151 = null;

        TreePHP.scalar_return scalar152 = null;


        SLAST PARAMETER147_tree=null;
        SLAST TYPE148_tree=null;
        SLAST CONST_T150_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:779:3: ( ^( PARAMETER ( ^( TYPE parameter_type ) )? ( CONST_T )? pure_variable ( scalar )? ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:779:5: ^( PARAMETER ( ^( TYPE parameter_type ) )? ( CONST_T )? pure_variable ( scalar )? )
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_1 = _last;
            SLAST _first_1 = null;
            SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            PARAMETER147=(SLAST)match(input,PARAMETER,FOLLOW_PARAMETER_in_parameter1519); 
            PARAMETER147_tree = (SLAST)adaptor.dupNode(PARAMETER147);

            root_1 = (SLAST)adaptor.becomeRoot(PARAMETER147_tree, root_1);



            match(input, Token.DOWN, null); 
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:779:17: ( ^( TYPE parameter_type ) )?
            int alt58=2;
            int LA58_0 = input.LA(1);

            if ( (LA58_0==TYPE) ) {
                alt58=1;
            }
            switch (alt58) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:779:18: ^( TYPE parameter_type )
                    {
                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_2 = _last;
                    SLAST _first_2 = null;
                    SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    TYPE148=(SLAST)match(input,TYPE,FOLLOW_TYPE_in_parameter1523); 
                    TYPE148_tree = (SLAST)adaptor.dupNode(TYPE148);

                    root_2 = (SLAST)adaptor.becomeRoot(TYPE148_tree, root_2);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_parameter_type_in_parameter1525);
                    parameter_type149=parameter_type();

                    state._fsp--;

                    adaptor.addChild(root_2, parameter_type149.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
                    }


                    }
                    break;

            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:779:43: ( CONST_T )?
            int alt59=2;
            int LA59_0 = input.LA(1);

            if ( (LA59_0==CONST_T) ) {
                alt59=1;
            }
            switch (alt59) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:779:43: CONST_T
                    {
                    _last = (SLAST)input.LT(1);
                    CONST_T150=(SLAST)match(input,CONST_T,FOLLOW_CONST_T_in_parameter1530); 
                    CONST_T150_tree = (SLAST)adaptor.dupNode(CONST_T150);

                    adaptor.addChild(root_1, CONST_T150_tree);


                    }
                    break;

            }

            _last = (SLAST)input.LT(1);
            pushFollow(FOLLOW_pure_variable_in_parameter1533);
            pure_variable151=pure_variable();

            state._fsp--;

            adaptor.addChild(root_1, pure_variable151.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:779:66: ( scalar )?
            int alt60=2;
            int LA60_0 = input.LA(1);

            if ( (LA60_0==SCALAR) ) {
                alt60=1;
            }
            switch (alt60) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:779:66: scalar
                    {
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_scalar_in_parameter1535);
                    scalar152=scalar();

                    state._fsp--;

                    adaptor.addChild(root_1, scalar152.getTree());

                    }
                    break;

            }


            match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


                FormalParameter RESULT = null;
                TypeReference classType = null;
                int varLeft = ((CommonToken)(pure_variable151!=null?((SLAST)pure_variable151.tree):null).token).getStartIndex();
                int varRight = ((CommonToken)(pure_variable151!=null?((SLAST)pure_variable151.tree):null).token).getStopIndex();
                String varName = (pure_variable151!=null?(input.getTokenStream().toString(
              input.getTreeAdaptor().getTokenStartIndex(pure_variable151.start),
              input.getTreeAdaptor().getTokenStopIndex(pure_variable151.start))):null);
                
                int startIndex = PARAMETER147.startIndex;
                int endIndex = PARAMETER147.endIndex + 1;
                VariableReference var = new VariableReference(varLeft, varRight, varName, PHPVariableKind.LOCAL);
                
                if ((scalar152!=null?scalar152.expr:null) == null) {
                  ((parameter_list_scope)parameter_list_stack.peek()).paramList.add(new FormalParameter(startIndex, endIndex, classType, var));
                }
                else {
                  ((parameter_list_scope)parameter_list_stack.peek()).paramList.add(new FormalParameter(startIndex, endIndex, classType, var, (scalar152!=null?scalar152.expr:null)));
                }
              

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "parameter"

    public static class parameter_type_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "parameter_type"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:800:1: parameter_type : ( fully_qualified_class_name | cast_option );
    public final TreePHP.parameter_type_return parameter_type() throws RecognitionException {
        TreePHP.parameter_type_return retval = new TreePHP.parameter_type_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.fully_qualified_class_name_return fully_qualified_class_name153 = null;

        TreePHP.cast_option_return cast_option154 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:801:3: ( fully_qualified_class_name | cast_option )
            int alt61=2;
            int LA61_0 = input.LA(1);

            if ( (LA61_0==IDENTIFIER||LA61_0==DOMAIN_T) ) {
                alt61=1;
            }
            else if ( ((LA61_0>=UNSET_T && LA61_0<=CLONE_T)||(LA61_0>=168 && LA61_0<=176)) ) {
                alt61=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 61, 0, input);

                throw nvae;
            }
            switch (alt61) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:801:5: fully_qualified_class_name
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_fully_qualified_class_name_in_parameter_type1556);
                    fully_qualified_class_name153=fully_qualified_class_name();

                    state._fsp--;

                    adaptor.addChild(root_0, fully_qualified_class_name153.getTree());

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:802:5: cast_option
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_cast_option_in_parameter_type1562);
                    cast_option154=cast_option();

                    state._fsp--;

                    adaptor.addChild(root_0, cast_option154.getTree());

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "parameter_type"

    public static class variable_modifiers_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "variable_modifiers"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:805:1: variable_modifiers : ( 'var' | modifier );
    public final TreePHP.variable_modifiers_return variable_modifiers() throws RecognitionException {
        TreePHP.variable_modifiers_return retval = new TreePHP.variable_modifiers_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST string_literal155=null;
        TreePHP.modifier_return modifier156 = null;


        SLAST string_literal155_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:806:3: ( 'var' | modifier )
            int alt62=2;
            int LA62_0 = input.LA(1);

            if ( (LA62_0==164) ) {
                alt62=1;
            }
            else if ( (LA62_0==VAR_DECL||LA62_0==IDENTIFIER||LA62_0==REF_T||LA62_0==STATIC_T||LA62_0==EQUAL_T||(LA62_0>=162 && LA62_0<=163)||(LA62_0>=165 && LA62_0<=167)) ) {
                alt62=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 62, 0, input);

                throw nvae;
            }
            switch (alt62) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:806:5: 'var'
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    string_literal155=(SLAST)match(input,164,FOLLOW_164_in_variable_modifiers1576); 
                    string_literal155_tree = (SLAST)adaptor.dupNode(string_literal155);

                    adaptor.addChild(root_0, string_literal155_tree);


                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:807:5: modifier
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_modifier_in_variable_modifiers1582);
                    modifier156=modifier();

                    state._fsp--;

                    adaptor.addChild(root_0, modifier156.getTree());

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "variable_modifiers"

    public static class modifier_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "modifier"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:810:1: modifier : ( 'public' | 'protected' | 'private' | 'static' | 'abstract' | 'final' )* ;
    public final TreePHP.modifier_return modifier() throws RecognitionException {
        TreePHP.modifier_return retval = new TreePHP.modifier_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST set157=null;

        SLAST set157_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:811:3: ( ( 'public' | 'protected' | 'private' | 'static' | 'abstract' | 'final' )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:811:5: ( 'public' | 'protected' | 'private' | 'static' | 'abstract' | 'final' )*
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:811:5: ( 'public' | 'protected' | 'private' | 'static' | 'abstract' | 'final' )*
            loop63:
            do {
                int alt63=2;
                int LA63_0 = input.LA(1);

                if ( (LA63_0==STATIC_T||(LA63_0>=162 && LA63_0<=163)||(LA63_0>=165 && LA63_0<=167)) ) {
                    alt63=1;
                }


                switch (alt63) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:
            	    {
            	    _last = (SLAST)input.LT(1);
            	    set157=(SLAST)input.LT(1);
            	    if ( input.LA(1)==STATIC_T||(input.LA(1)>=162 && input.LA(1)<=163)||(input.LA(1)>=165 && input.LA(1)<=167) ) {
            	        input.consume();

            	        set157_tree = (SLAST)adaptor.dupNode(set157);

            	        adaptor.addChild(root_0, set157_tree);

            	        state.errorRecovery=false;
            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        throw mse;
            	    }


            	    }
            	    break;

            	default :
            	    break loop63;
                }
            } while (true);


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "modifier"

    public static class directive_return extends TreeRuleReturnScope {
        public Object astNode;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "directive"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:819:1: directive returns [Object astNode] : ^( EQUAL_T IDENTIFIER expression ) ;
    public final TreePHP.directive_return directive() throws RecognitionException {
        TreePHP.directive_return retval = new TreePHP.directive_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST EQUAL_T158=null;
        SLAST IDENTIFIER159=null;
        TreePHP.expression_return expression160 = null;


        SLAST EQUAL_T158_tree=null;
        SLAST IDENTIFIER159_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:820:3: ( ^( EQUAL_T IDENTIFIER expression ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:820:5: ^( EQUAL_T IDENTIFIER expression )
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_1 = _last;
            SLAST _first_1 = null;
            SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            EQUAL_T158=(SLAST)match(input,EQUAL_T,FOLLOW_EQUAL_T_in_directive1652); 
            EQUAL_T158_tree = (SLAST)adaptor.dupNode(EQUAL_T158);

            root_1 = (SLAST)adaptor.becomeRoot(EQUAL_T158_tree, root_1);



            match(input, Token.DOWN, null); 
            _last = (SLAST)input.LT(1);
            IDENTIFIER159=(SLAST)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_directive1654); 
            IDENTIFIER159_tree = (SLAST)adaptor.dupNode(IDENTIFIER159);

            adaptor.addChild(root_1, IDENTIFIER159_tree);

            _last = (SLAST)input.LT(1);
            pushFollow(FOLLOW_expression_in_directive1656);
            expression160=expression();

            state._fsp--;

            adaptor.addChild(root_1, expression160.getTree());

            match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


                if (inClassStatementList) {
            	    int constNameleft = ((CommonToken)IDENTIFIER159.token).getStartIndex();
            	    int constNameright = ((CommonToken)IDENTIFIER159.token).getStopIndex();
            	    String constName = (IDENTIFIER159!=null?IDENTIFIER159.getText():null);
            	    int exprLeft = ((CommonToken)((expression160!=null?((SLAST)expression160.tree):null).token)).getStartIndex();
            	    int exprRight = ((CommonToken)((expression160!=null?((SLAST)expression160.tree):null).token)).getStopIndex();
            	    Expression expr = (expression160!=null?expression160.expr:null);
            	    
            	    ConstantReference constId = new ConstantReference(constNameleft, constNameright, constName);
            	    Object obj = new ASTNode[]{constId, expr};
            	    ((class_statement_scope)class_statement_stack.peek()).constList.add(obj);
            	  }
            	  else {
            	    System.out.println("id: " + (IDENTIFIER159!=null?IDENTIFIER159.getText():null));
                  ((topStatement_scope)topStatement_stack.peek()).declareKey.add((IDENTIFIER159!=null?IDENTIFIER159.getText():null));
                  ((topStatement_scope)topStatement_stack.peek()).declareValue.add((expression160!=null?expression160.expr:null));
                  System.out.println("OVER");
                }
              

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "directive"

    protected static class expr_list_scope {
        List list;
    }
    protected Stack expr_list_stack = new Stack();

    public static class expr_list_return extends TreeRuleReturnScope {
        public List exprList;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "expr_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:843:1: expr_list returns [List exprList] : ( expression )+ ;
    public final TreePHP.expr_list_return expr_list() throws RecognitionException {
        expr_list_stack.push(new expr_list_scope());
        TreePHP.expr_list_return retval = new TreePHP.expr_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.expression_return expression161 = null;




          ((expr_list_scope)expr_list_stack.peek()).list = new LinkedList();
          inExprList = true;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:854:2: ( ( expression )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:854:4: ( expression )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:854:4: ( expression )+
            int cnt64=0;
            loop64:
            do {
                int alt64=2;
                int LA64_0 = input.LA(1);

                if ( (LA64_0==METHOD_DECL||LA64_0==VAR_DECL||LA64_0==CALL||LA64_0==EXPR||(LA64_0>=SCALAR && LA64_0<=CAST_EXPR)||LA64_0==REF_T||LA64_0==EQUAL_T||(LA64_0>=OR_T && LA64_0<=EXC_NOT_T)||(LA64_0>=INSTANCEOF_T && LA64_0<=BACKTRICKLITERAL)) ) {
                    alt64=1;
                }


                switch (alt64) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:854:4: expression
            	    {
            	    _last = (SLAST)input.LT(1);
            	    pushFollow(FOLLOW_expression_in_expr_list1693);
            	    expression161=expression();

            	    state._fsp--;

            	    adaptor.addChild(root_0, expression161.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt64 >= 1 ) break loop64;
                        EarlyExitException eee =
                            new EarlyExitException(64, input);
                        throw eee;
                }
                cnt64++;
            } while (true);


              retval.exprList = ((expr_list_scope)expr_list_stack.peek()).list;
             

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);


              inExprList = false;

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
            expr_list_stack.pop();
        }
        return retval;
    }
    // $ANTLR end "expr_list"

    public static class expression_return extends TreeRuleReturnScope {
        public Expression expr;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "expression"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:860:1: expression returns [Expression expr] : ( ^( EXPR etop= expression ) | ^( OR_T e1= expression e2= expression ) | ^( XOR_T e1= expression e2= expression ) | ^( AND_T e1= expression e2= expression ) | ^( EQUAL_T e1= expression e2= expression ) | ^( PLUS_EQ e1= expression e2= expression ) | ^( MINUS_EQ e1= expression e2= expression ) | ^( MUL_EQ e1= expression e2= expression ) | ^( DIV_EQ e1= expression e2= expression ) | ^( DOT_EQ e1= expression e2= expression ) | ^( PERCENT_EQ e1= expression e2= expression ) | ^( BIT_AND_EQ e1= expression e2= expression ) | ^( BIT_OR_EQ e1= expression e2= expression ) | ^( POWER_EQ e1= expression e2= expression ) | ^( LMOVE_EQ e1= expression e2= expression ) | ^( RMOVE_EQ e1= expression e2= expression ) | ^( QUESTION_T e1= expression ^( COLON_T e2= expression e3= expression ) ) | ^( LOGICAL_OR_T e1= expression e2= expression ) | ^( LOGICAL_AND_T e1= expression e2= expression ) | ^( BIT_OR_T e1= expression e2= expression ) | ^( POWER_T expression expression ) | ^( REF_T e1= expression e2= expression ) | ^( DOT_T e1= expression e2= expression ) | ^( EQUAL_EQUAL_T e1= expression e2= expression ) | ^( NOT_EQUAL_T e1= expression e2= expression ) | ^( EQUAL_EQUAL_EQUAL_T e1= expression e2= expression ) | ^( NOT_EQUAL_EQUAL_T e1= expression e2= expression ) | ^( LT_T e1= expression e2= expression ) | ^( MT_T e1= expression e2= expression ) | ^( LE_T e1= expression e2= expression ) | ^( ME_T expression expression ) | ^( LSHIFT_T e1= expression e2= expression ) | ^( RSHIFT_T e1= expression e2= expression ) | ^( PLUS_T e1= expression e2= expression ) | ^( MINUS_T e1= expression e2= expression ) | ^( MUL_T e1= expression e2= expression ) | ^( DIV_T e1= expression e2= expression ) | ^( PERCENT_T e1= expression e2= expression ) | ^( CAST_EXPR cast_option e= expression ) | ^( TILDA_T e= expression ) | ^( EXC_NOT_T expression ) | ^( POSTFIX_EXPR e= expression plus_minus ) | ^( PREFIX_EXPR ( plus_minus )+ e= expression ) | ^( INSTANCEOF_T expression class_name_reference ) | ( AT_T )? variable | ( AT_T )? scalar | ^( LIST_T ( assignment_list )? ) | ^( ARRAY_DECL ( array_pair_list )? ) | ^( NEW_T class_name_reference ) | ^( CLONE_T variable ) | ^( EXIT_T ( expression )? ) | ^( UNSET_T variable ) | lambda_function_declaration | BACKTRICKLITERAL );
    public final TreePHP.expression_return expression() throws RecognitionException {
        TreePHP.expression_return retval = new TreePHP.expression_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST EXPR162=null;
        SLAST OR_T163=null;
        SLAST XOR_T164=null;
        SLAST AND_T165=null;
        SLAST EQUAL_T166=null;
        SLAST PLUS_EQ167=null;
        SLAST MINUS_EQ168=null;
        SLAST MUL_EQ169=null;
        SLAST DIV_EQ170=null;
        SLAST DOT_EQ171=null;
        SLAST PERCENT_EQ172=null;
        SLAST BIT_AND_EQ173=null;
        SLAST BIT_OR_EQ174=null;
        SLAST POWER_EQ175=null;
        SLAST LMOVE_EQ176=null;
        SLAST RMOVE_EQ177=null;
        SLAST QUESTION_T178=null;
        SLAST COLON_T179=null;
        SLAST LOGICAL_OR_T180=null;
        SLAST LOGICAL_AND_T181=null;
        SLAST BIT_OR_T182=null;
        SLAST POWER_T183=null;
        SLAST REF_T186=null;
        SLAST DOT_T187=null;
        SLAST EQUAL_EQUAL_T188=null;
        SLAST NOT_EQUAL_T189=null;
        SLAST EQUAL_EQUAL_EQUAL_T190=null;
        SLAST NOT_EQUAL_EQUAL_T191=null;
        SLAST LT_T192=null;
        SLAST MT_T193=null;
        SLAST LE_T194=null;
        SLAST ME_T195=null;
        SLAST LSHIFT_T198=null;
        SLAST RSHIFT_T199=null;
        SLAST PLUS_T200=null;
        SLAST MINUS_T201=null;
        SLAST MUL_T202=null;
        SLAST DIV_T203=null;
        SLAST PERCENT_T204=null;
        SLAST CAST_EXPR205=null;
        SLAST TILDA_T207=null;
        SLAST EXC_NOT_T208=null;
        SLAST POSTFIX_EXPR210=null;
        SLAST PREFIX_EXPR212=null;
        SLAST INSTANCEOF_T214=null;
        SLAST AT_T217=null;
        SLAST AT_T219=null;
        SLAST LIST_T221=null;
        SLAST ARRAY_DECL223=null;
        SLAST NEW_T225=null;
        SLAST CLONE_T227=null;
        SLAST EXIT_T229=null;
        SLAST UNSET_T231=null;
        SLAST BACKTRICKLITERAL234=null;
        TreePHP.expression_return etop = null;

        TreePHP.expression_return e1 = null;

        TreePHP.expression_return e2 = null;

        TreePHP.expression_return e3 = null;

        TreePHP.expression_return e = null;

        TreePHP.expression_return expression184 = null;

        TreePHP.expression_return expression185 = null;

        TreePHP.expression_return expression196 = null;

        TreePHP.expression_return expression197 = null;

        TreePHP.cast_option_return cast_option206 = null;

        TreePHP.expression_return expression209 = null;

        TreePHP.plus_minus_return plus_minus211 = null;

        TreePHP.plus_minus_return plus_minus213 = null;

        TreePHP.expression_return expression215 = null;

        TreePHP.class_name_reference_return class_name_reference216 = null;

        TreePHP.variable_return variable218 = null;

        TreePHP.scalar_return scalar220 = null;

        TreePHP.assignment_list_return assignment_list222 = null;

        TreePHP.array_pair_list_return array_pair_list224 = null;

        TreePHP.class_name_reference_return class_name_reference226 = null;

        TreePHP.variable_return variable228 = null;

        TreePHP.expression_return expression230 = null;

        TreePHP.variable_return variable232 = null;

        TreePHP.lambda_function_declaration_return lambda_function_declaration233 = null;


        SLAST EXPR162_tree=null;
        SLAST OR_T163_tree=null;
        SLAST XOR_T164_tree=null;
        SLAST AND_T165_tree=null;
        SLAST EQUAL_T166_tree=null;
        SLAST PLUS_EQ167_tree=null;
        SLAST MINUS_EQ168_tree=null;
        SLAST MUL_EQ169_tree=null;
        SLAST DIV_EQ170_tree=null;
        SLAST DOT_EQ171_tree=null;
        SLAST PERCENT_EQ172_tree=null;
        SLAST BIT_AND_EQ173_tree=null;
        SLAST BIT_OR_EQ174_tree=null;
        SLAST POWER_EQ175_tree=null;
        SLAST LMOVE_EQ176_tree=null;
        SLAST RMOVE_EQ177_tree=null;
        SLAST QUESTION_T178_tree=null;
        SLAST COLON_T179_tree=null;
        SLAST LOGICAL_OR_T180_tree=null;
        SLAST LOGICAL_AND_T181_tree=null;
        SLAST BIT_OR_T182_tree=null;
        SLAST POWER_T183_tree=null;
        SLAST REF_T186_tree=null;
        SLAST DOT_T187_tree=null;
        SLAST EQUAL_EQUAL_T188_tree=null;
        SLAST NOT_EQUAL_T189_tree=null;
        SLAST EQUAL_EQUAL_EQUAL_T190_tree=null;
        SLAST NOT_EQUAL_EQUAL_T191_tree=null;
        SLAST LT_T192_tree=null;
        SLAST MT_T193_tree=null;
        SLAST LE_T194_tree=null;
        SLAST ME_T195_tree=null;
        SLAST LSHIFT_T198_tree=null;
        SLAST RSHIFT_T199_tree=null;
        SLAST PLUS_T200_tree=null;
        SLAST MINUS_T201_tree=null;
        SLAST MUL_T202_tree=null;
        SLAST DIV_T203_tree=null;
        SLAST PERCENT_T204_tree=null;
        SLAST CAST_EXPR205_tree=null;
        SLAST TILDA_T207_tree=null;
        SLAST EXC_NOT_T208_tree=null;
        SLAST POSTFIX_EXPR210_tree=null;
        SLAST PREFIX_EXPR212_tree=null;
        SLAST INSTANCEOF_T214_tree=null;
        SLAST AT_T217_tree=null;
        SLAST AT_T219_tree=null;
        SLAST LIST_T221_tree=null;
        SLAST ARRAY_DECL223_tree=null;
        SLAST NEW_T225_tree=null;
        SLAST CLONE_T227_tree=null;
        SLAST EXIT_T229_tree=null;
        SLAST UNSET_T231_tree=null;
        SLAST BACKTRICKLITERAL234_tree=null;


          SLAST ast = null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:869:3: ( ^( EXPR etop= expression ) | ^( OR_T e1= expression e2= expression ) | ^( XOR_T e1= expression e2= expression ) | ^( AND_T e1= expression e2= expression ) | ^( EQUAL_T e1= expression e2= expression ) | ^( PLUS_EQ e1= expression e2= expression ) | ^( MINUS_EQ e1= expression e2= expression ) | ^( MUL_EQ e1= expression e2= expression ) | ^( DIV_EQ e1= expression e2= expression ) | ^( DOT_EQ e1= expression e2= expression ) | ^( PERCENT_EQ e1= expression e2= expression ) | ^( BIT_AND_EQ e1= expression e2= expression ) | ^( BIT_OR_EQ e1= expression e2= expression ) | ^( POWER_EQ e1= expression e2= expression ) | ^( LMOVE_EQ e1= expression e2= expression ) | ^( RMOVE_EQ e1= expression e2= expression ) | ^( QUESTION_T e1= expression ^( COLON_T e2= expression e3= expression ) ) | ^( LOGICAL_OR_T e1= expression e2= expression ) | ^( LOGICAL_AND_T e1= expression e2= expression ) | ^( BIT_OR_T e1= expression e2= expression ) | ^( POWER_T expression expression ) | ^( REF_T e1= expression e2= expression ) | ^( DOT_T e1= expression e2= expression ) | ^( EQUAL_EQUAL_T e1= expression e2= expression ) | ^( NOT_EQUAL_T e1= expression e2= expression ) | ^( EQUAL_EQUAL_EQUAL_T e1= expression e2= expression ) | ^( NOT_EQUAL_EQUAL_T e1= expression e2= expression ) | ^( LT_T e1= expression e2= expression ) | ^( MT_T e1= expression e2= expression ) | ^( LE_T e1= expression e2= expression ) | ^( ME_T expression expression ) | ^( LSHIFT_T e1= expression e2= expression ) | ^( RSHIFT_T e1= expression e2= expression ) | ^( PLUS_T e1= expression e2= expression ) | ^( MINUS_T e1= expression e2= expression ) | ^( MUL_T e1= expression e2= expression ) | ^( DIV_T e1= expression e2= expression ) | ^( PERCENT_T e1= expression e2= expression ) | ^( CAST_EXPR cast_option e= expression ) | ^( TILDA_T e= expression ) | ^( EXC_NOT_T expression ) | ^( POSTFIX_EXPR e= expression plus_minus ) | ^( PREFIX_EXPR ( plus_minus )+ e= expression ) | ^( INSTANCEOF_T expression class_name_reference ) | ( AT_T )? variable | ( AT_T )? scalar | ^( LIST_T ( assignment_list )? ) | ^( ARRAY_DECL ( array_pair_list )? ) | ^( NEW_T class_name_reference ) | ^( CLONE_T variable ) | ^( EXIT_T ( expression )? ) | ^( UNSET_T variable ) | lambda_function_declaration | BACKTRICKLITERAL )
            int alt71=54;
            alt71 = dfa71.predict(input);
            switch (alt71) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:869:5: ^( EXPR etop= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    EXPR162=(SLAST)match(input,EXPR,FOLLOW_EXPR_in_expression1727); 
                    EXPR162_tree = (SLAST)adaptor.dupNode(EXPR162);

                    root_1 = (SLAST)adaptor.becomeRoot(EXPR162_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1731);
                    etop=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, etop.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        retval.expr = (etop!=null?etop.expr:null);
                        ast = (etop!=null?((SLAST)etop.tree):null);
                        if (inExprList) {
                          ((expr_list_scope)expr_list_stack.peek()).list.add(retval.expr);
                        }
                      

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:877:5: ^( OR_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    OR_T163=(SLAST)match(input,OR_T,FOLLOW_OR_T_in_expression1743); 
                    OR_T163_tree = (SLAST)adaptor.dupNode(OR_T163);

                    root_1 = (SLAST)adaptor.becomeRoot(OR_T163_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1747);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1751);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = OR_T163.startIndex;
                        int endIndex = OR_T163.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1 , InfixExpression.OP_STRING_OR, expr2); 
                      

                    }
                    break;
                case 3 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:885:5: ^( XOR_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    XOR_T164=(SLAST)match(input,XOR_T,FOLLOW_XOR_T_in_expression1763); 
                    XOR_T164_tree = (SLAST)adaptor.dupNode(XOR_T164);

                    root_1 = (SLAST)adaptor.becomeRoot(XOR_T164_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1767);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1771);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = XOR_T164.startIndex;
                        int endIndex = XOR_T164.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1 , InfixExpression.OP_STRING_XOR, expr2);
                      

                    }
                    break;
                case 4 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:893:5: ^( AND_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    AND_T165=(SLAST)match(input,AND_T,FOLLOW_AND_T_in_expression1783); 
                    AND_T165_tree = (SLAST)adaptor.dupNode(AND_T165);

                    root_1 = (SLAST)adaptor.becomeRoot(AND_T165_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1787);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1791);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = AND_T165.startIndex;
                        int endIndex = AND_T165.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1 , InfixExpression.OP_STRING_AND, expr2);
                      

                    }
                    break;
                case 5 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:901:5: ^( EQUAL_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    EQUAL_T166=(SLAST)match(input,EQUAL_T,FOLLOW_EQUAL_T_in_expression1803); 
                    EQUAL_T166_tree = (SLAST)adaptor.dupNode(EQUAL_T166);

                    root_1 = (SLAST)adaptor.becomeRoot(EQUAL_T166_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1807);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1811);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = EQUAL_T166.startIndex;
                        int endIndex = EQUAL_T166.endIndex + 1;
                        Expression var = (e1!=null?e1.expr:null);
                        Expression expr = (e2!=null?e2.expr:null);
                        retval.expr = new Assignment(startIndex, endIndex, var, Assignment.OP_EQUAL, expr);
                      

                    }
                    break;
                case 6 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:909:5: ^( PLUS_EQ e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    PLUS_EQ167=(SLAST)match(input,PLUS_EQ,FOLLOW_PLUS_EQ_in_expression1824); 
                    PLUS_EQ167_tree = (SLAST)adaptor.dupNode(PLUS_EQ167);

                    root_1 = (SLAST)adaptor.becomeRoot(PLUS_EQ167_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1828);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1832);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = PLUS_EQ167.startIndex;
                        int endIndex = PLUS_EQ167.endIndex + 1;
                        Expression var = (e1!=null?e1.expr:null);
                        Expression expr = (e2!=null?e2.expr:null);
                        retval.expr = new Assignment(startIndex, endIndex, var, Assignment.OP_PLUS_EQUAL, expr);
                      

                    }
                    break;
                case 7 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:917:5: ^( MINUS_EQ e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    MINUS_EQ168=(SLAST)match(input,MINUS_EQ,FOLLOW_MINUS_EQ_in_expression1844); 
                    MINUS_EQ168_tree = (SLAST)adaptor.dupNode(MINUS_EQ168);

                    root_1 = (SLAST)adaptor.becomeRoot(MINUS_EQ168_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1848);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1852);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = MINUS_EQ168.startIndex;
                        int endIndex = MINUS_EQ168.endIndex + 1;
                        Expression var = (e1!=null?e1.expr:null);
                        Expression expr = (e2!=null?e2.expr:null);
                        retval.expr = new Assignment(startIndex, endIndex, var, Assignment.OP_MINUS_EQUAL, expr);
                      

                    }
                    break;
                case 8 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:925:5: ^( MUL_EQ e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    MUL_EQ169=(SLAST)match(input,MUL_EQ,FOLLOW_MUL_EQ_in_expression1864); 
                    MUL_EQ169_tree = (SLAST)adaptor.dupNode(MUL_EQ169);

                    root_1 = (SLAST)adaptor.becomeRoot(MUL_EQ169_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1868);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1872);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = MUL_EQ169.startIndex;
                        int endIndex = MUL_EQ169.endIndex + 1;
                        Expression var = (e1!=null?e1.expr:null);
                        Expression expr = (e2!=null?e2.expr:null);
                        retval.expr = new Assignment(startIndex, endIndex, var, Assignment.OP_MUL_EQUAL, expr);
                      

                    }
                    break;
                case 9 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:933:5: ^( DIV_EQ e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    DIV_EQ170=(SLAST)match(input,DIV_EQ,FOLLOW_DIV_EQ_in_expression1884); 
                    DIV_EQ170_tree = (SLAST)adaptor.dupNode(DIV_EQ170);

                    root_1 = (SLAST)adaptor.becomeRoot(DIV_EQ170_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1888);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1892);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = DIV_EQ170.startIndex;
                        int endIndex = DIV_EQ170.endIndex + 1;
                        Expression var = (e1!=null?e1.expr:null);
                        Expression expr = (e2!=null?e2.expr:null);
                        retval.expr = new Assignment(startIndex, endIndex, var, Assignment.OP_DIV_EQUAL, expr);
                      

                    }
                    break;
                case 10 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:941:5: ^( DOT_EQ e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    DOT_EQ171=(SLAST)match(input,DOT_EQ,FOLLOW_DOT_EQ_in_expression1904); 
                    DOT_EQ171_tree = (SLAST)adaptor.dupNode(DOT_EQ171);

                    root_1 = (SLAST)adaptor.becomeRoot(DOT_EQ171_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1908);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1912);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = DOT_EQ171.startIndex;
                        int endIndex = DOT_EQ171.endIndex + 1;
                        Expression var = (e1!=null?e1.expr:null);
                        Expression expr = (e2!=null?e2.expr:null);
                        retval.expr = new Assignment(startIndex, endIndex, var, Assignment.OP_CONCAT_EQUAL, expr);
                      

                    }
                    break;
                case 11 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:949:5: ^( PERCENT_EQ e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    PERCENT_EQ172=(SLAST)match(input,PERCENT_EQ,FOLLOW_PERCENT_EQ_in_expression1924); 
                    PERCENT_EQ172_tree = (SLAST)adaptor.dupNode(PERCENT_EQ172);

                    root_1 = (SLAST)adaptor.becomeRoot(PERCENT_EQ172_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1928);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1932);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = PERCENT_EQ172.startIndex;
                        int endIndex = PERCENT_EQ172.endIndex + 1;
                        Expression var = (e1!=null?e1.expr:null);
                        Expression expr = (e2!=null?e2.expr:null);
                        retval.expr = new Assignment(startIndex, endIndex, var, Assignment.OP_MOD_EQUAL, expr);
                      

                    }
                    break;
                case 12 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:957:5: ^( BIT_AND_EQ e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    BIT_AND_EQ173=(SLAST)match(input,BIT_AND_EQ,FOLLOW_BIT_AND_EQ_in_expression1944); 
                    BIT_AND_EQ173_tree = (SLAST)adaptor.dupNode(BIT_AND_EQ173);

                    root_1 = (SLAST)adaptor.becomeRoot(BIT_AND_EQ173_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1948);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1952);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = BIT_AND_EQ173.startIndex;
                        int endIndex = BIT_AND_EQ173.endIndex + 1;
                        Expression var = (e1!=null?e1.expr:null);
                        Expression expr = (e2!=null?e2.expr:null);
                        retval.expr = new Assignment(startIndex, endIndex, var, Assignment.OP_AND_EQUAL, expr);
                      

                    }
                    break;
                case 13 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:965:5: ^( BIT_OR_EQ e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    BIT_OR_EQ174=(SLAST)match(input,BIT_OR_EQ,FOLLOW_BIT_OR_EQ_in_expression1964); 
                    BIT_OR_EQ174_tree = (SLAST)adaptor.dupNode(BIT_OR_EQ174);

                    root_1 = (SLAST)adaptor.becomeRoot(BIT_OR_EQ174_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1968);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1972);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = BIT_OR_EQ174.startIndex;
                        int endIndex = BIT_OR_EQ174.endIndex + 1;
                        Expression var = (e1!=null?e1.expr:null);
                        Expression expr = (e2!=null?e2.expr:null);
                        retval.expr = new Assignment(startIndex, endIndex, var, Assignment.OP_OR_EQUAL, expr);
                      

                    }
                    break;
                case 14 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:973:5: ^( POWER_EQ e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    POWER_EQ175=(SLAST)match(input,POWER_EQ,FOLLOW_POWER_EQ_in_expression1984); 
                    POWER_EQ175_tree = (SLAST)adaptor.dupNode(POWER_EQ175);

                    root_1 = (SLAST)adaptor.becomeRoot(POWER_EQ175_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1988);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1992);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = POWER_EQ175.startIndex;
                        int endIndex = POWER_EQ175.endIndex + 1;
                        Expression var = (e1!=null?e1.expr:null);
                        Expression expr = (e2!=null?e2.expr:null);
                        retval.expr = new Assignment(startIndex, endIndex, var, Assignment.OP_XOR_EQUAL, expr);
                      

                    }
                    break;
                case 15 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:981:5: ^( LMOVE_EQ e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    LMOVE_EQ176=(SLAST)match(input,LMOVE_EQ,FOLLOW_LMOVE_EQ_in_expression2004); 
                    LMOVE_EQ176_tree = (SLAST)adaptor.dupNode(LMOVE_EQ176);

                    root_1 = (SLAST)adaptor.becomeRoot(LMOVE_EQ176_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2008);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2012);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = LMOVE_EQ176.startIndex;
                        int endIndex = LMOVE_EQ176.endIndex + 1;
                        Expression var = (e1!=null?e1.expr:null);
                        Expression expr = (e2!=null?e2.expr:null);
                        retval.expr = new Assignment(startIndex, endIndex, var, Assignment.OP_SL_EQUAL, expr);
                      

                    }
                    break;
                case 16 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:989:5: ^( RMOVE_EQ e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    RMOVE_EQ177=(SLAST)match(input,RMOVE_EQ,FOLLOW_RMOVE_EQ_in_expression2024); 
                    RMOVE_EQ177_tree = (SLAST)adaptor.dupNode(RMOVE_EQ177);

                    root_1 = (SLAST)adaptor.becomeRoot(RMOVE_EQ177_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2028);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2032);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = RMOVE_EQ177.startIndex;
                        int endIndex = RMOVE_EQ177.endIndex + 1;
                        Expression var = (e1!=null?e1.expr:null);
                        Expression expr = (e2!=null?e2.expr:null);
                        retval.expr = new Assignment(startIndex, endIndex, var, Assignment.OP_SR_EQUAL, expr);
                      

                    }
                    break;
                case 17 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:997:5: ^( QUESTION_T e1= expression ^( COLON_T e2= expression e3= expression ) )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    QUESTION_T178=(SLAST)match(input,QUESTION_T,FOLLOW_QUESTION_T_in_expression2044); 
                    QUESTION_T178_tree = (SLAST)adaptor.dupNode(QUESTION_T178);

                    root_1 = (SLAST)adaptor.becomeRoot(QUESTION_T178_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2048);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_2 = _last;
                    SLAST _first_2 = null;
                    SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    COLON_T179=(SLAST)match(input,COLON_T,FOLLOW_COLON_T_in_expression2051); 
                    COLON_T179_tree = (SLAST)adaptor.dupNode(COLON_T179);

                    root_2 = (SLAST)adaptor.becomeRoot(COLON_T179_tree, root_2);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2055);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_2, e2.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2059);
                    e3=expression();

                    state._fsp--;

                    adaptor.addChild(root_2, e3.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
                    }


                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = QUESTION_T178.startIndex;
                        int endIndex = QUESTION_T178.endIndex;
                        retval.expr = new ConditionalExpression(startIndex, endIndex, (e1!=null?e1.expr:null), (e2!=null?e2.expr:null), (e3!=null?e3.expr:null)); 
                      

                    }
                    break;
                case 18 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1003:5: ^( LOGICAL_OR_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    LOGICAL_OR_T180=(SLAST)match(input,LOGICAL_OR_T,FOLLOW_LOGICAL_OR_T_in_expression2074); 
                    LOGICAL_OR_T180_tree = (SLAST)adaptor.dupNode(LOGICAL_OR_T180);

                    root_1 = (SLAST)adaptor.becomeRoot(LOGICAL_OR_T180_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2078);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2082);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = LOGICAL_OR_T180.startIndex;
                        int endIndex = LOGICAL_OR_T180.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1 , InfixExpression.OP_BOOL_OR, expr2); 
                      

                    }
                    break;
                case 19 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1011:5: ^( LOGICAL_AND_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    LOGICAL_AND_T181=(SLAST)match(input,LOGICAL_AND_T,FOLLOW_LOGICAL_AND_T_in_expression2094); 
                    LOGICAL_AND_T181_tree = (SLAST)adaptor.dupNode(LOGICAL_AND_T181);

                    root_1 = (SLAST)adaptor.becomeRoot(LOGICAL_AND_T181_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2098);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2102);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = LOGICAL_AND_T181.startIndex;
                        int endIndex = LOGICAL_AND_T181.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1 , InfixExpression.OP_BOOL_AND, expr2);
                      

                    }
                    break;
                case 20 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1019:5: ^( BIT_OR_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    BIT_OR_T182=(SLAST)match(input,BIT_OR_T,FOLLOW_BIT_OR_T_in_expression2114); 
                    BIT_OR_T182_tree = (SLAST)adaptor.dupNode(BIT_OR_T182);

                    root_1 = (SLAST)adaptor.becomeRoot(BIT_OR_T182_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2118);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2122);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = BIT_OR_T182.startIndex;
                        int endIndex = BIT_OR_T182.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1 , InfixExpression.OP_OR, expr2); 
                      

                    }
                    break;
                case 21 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1027:5: ^( POWER_T expression expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    POWER_T183=(SLAST)match(input,POWER_T,FOLLOW_POWER_T_in_expression2134); 
                    POWER_T183_tree = (SLAST)adaptor.dupNode(POWER_T183);

                    root_1 = (SLAST)adaptor.becomeRoot(POWER_T183_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2136);
                    expression184=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression184.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2138);
                    expression185=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression185.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = POWER_T183.startIndex;
                        int endIndex = POWER_T183.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1 , InfixExpression.OP_XOR, expr2); 
                      

                    }
                    break;
                case 22 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1035:5: ^( REF_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    REF_T186=(SLAST)match(input,REF_T,FOLLOW_REF_T_in_expression2150); 
                    REF_T186_tree = (SLAST)adaptor.dupNode(REF_T186);

                    root_1 = (SLAST)adaptor.becomeRoot(REF_T186_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2154);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2158);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = REF_T186.startIndex;
                        int endIndex = REF_T186.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1 , InfixExpression.OP_AND, expr2); 
                      

                    }
                    break;
                case 23 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1043:5: ^( DOT_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    DOT_T187=(SLAST)match(input,DOT_T,FOLLOW_DOT_T_in_expression2170); 
                    DOT_T187_tree = (SLAST)adaptor.dupNode(DOT_T187);

                    root_1 = (SLAST)adaptor.becomeRoot(DOT_T187_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2174);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2178);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = DOT_T187.startIndex;
                        int endIndex = DOT_T187.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1 , InfixExpression.OP_CONCAT, expr2); 
                      

                    }
                    break;
                case 24 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1051:5: ^( EQUAL_EQUAL_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    EQUAL_EQUAL_T188=(SLAST)match(input,EQUAL_EQUAL_T,FOLLOW_EQUAL_EQUAL_T_in_expression2190); 
                    EQUAL_EQUAL_T188_tree = (SLAST)adaptor.dupNode(EQUAL_EQUAL_T188);

                    root_1 = (SLAST)adaptor.becomeRoot(EQUAL_EQUAL_T188_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2194);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2198);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = EQUAL_EQUAL_T188.startIndex;
                        int endIndex = EQUAL_EQUAL_T188.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1 , InfixExpression.OP_IS_EQUAL, expr2);
                      

                    }
                    break;
                case 25 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1059:5: ^( NOT_EQUAL_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    NOT_EQUAL_T189=(SLAST)match(input,NOT_EQUAL_T,FOLLOW_NOT_EQUAL_T_in_expression2210); 
                    NOT_EQUAL_T189_tree = (SLAST)adaptor.dupNode(NOT_EQUAL_T189);

                    root_1 = (SLAST)adaptor.becomeRoot(NOT_EQUAL_T189_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2214);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2218);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = NOT_EQUAL_T189.startIndex;
                        int endIndex = NOT_EQUAL_T189.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1 , InfixExpression.OP_IS_NOT_EQUAL, expr2);
                      

                    }
                    break;
                case 26 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1067:5: ^( EQUAL_EQUAL_EQUAL_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    EQUAL_EQUAL_EQUAL_T190=(SLAST)match(input,EQUAL_EQUAL_EQUAL_T,FOLLOW_EQUAL_EQUAL_EQUAL_T_in_expression2230); 
                    EQUAL_EQUAL_EQUAL_T190_tree = (SLAST)adaptor.dupNode(EQUAL_EQUAL_EQUAL_T190);

                    root_1 = (SLAST)adaptor.becomeRoot(EQUAL_EQUAL_EQUAL_T190_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2234);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2238);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = EQUAL_EQUAL_EQUAL_T190.startIndex;
                        int endIndex = EQUAL_EQUAL_EQUAL_T190.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1 , InfixExpression.OP_IS_IDENTICAL, expr2);
                      

                    }
                    break;
                case 27 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1075:5: ^( NOT_EQUAL_EQUAL_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    NOT_EQUAL_EQUAL_T191=(SLAST)match(input,NOT_EQUAL_EQUAL_T,FOLLOW_NOT_EQUAL_EQUAL_T_in_expression2250); 
                    NOT_EQUAL_EQUAL_T191_tree = (SLAST)adaptor.dupNode(NOT_EQUAL_EQUAL_T191);

                    root_1 = (SLAST)adaptor.becomeRoot(NOT_EQUAL_EQUAL_T191_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2254);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2258);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = NOT_EQUAL_EQUAL_T191.startIndex;
                        int endIndex = NOT_EQUAL_EQUAL_T191.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1 , InfixExpression.OP_IS_NOT_IDENTICAL, expr2);
                      

                    }
                    break;
                case 28 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1083:5: ^( LT_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    LT_T192=(SLAST)match(input,LT_T,FOLLOW_LT_T_in_expression2270); 
                    LT_T192_tree = (SLAST)adaptor.dupNode(LT_T192);

                    root_1 = (SLAST)adaptor.becomeRoot(LT_T192_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2274);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2278);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = LT_T192.startIndex;
                        int endIndex = LT_T192.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1 , InfixExpression.OP_RGREATER, expr2); 
                      

                    }
                    break;
                case 29 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1091:5: ^( MT_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    MT_T193=(SLAST)match(input,MT_T,FOLLOW_MT_T_in_expression2290); 
                    MT_T193_tree = (SLAST)adaptor.dupNode(MT_T193);

                    root_1 = (SLAST)adaptor.becomeRoot(MT_T193_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2294);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2298);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = MT_T193.startIndex;
                        int endIndex = MT_T193.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1 , InfixExpression.OP_LGREATER, expr2); 
                      

                    }
                    break;
                case 30 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1099:5: ^( LE_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    LE_T194=(SLAST)match(input,LE_T,FOLLOW_LE_T_in_expression2310); 
                    LE_T194_tree = (SLAST)adaptor.dupNode(LE_T194);

                    root_1 = (SLAST)adaptor.becomeRoot(LE_T194_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2314);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2318);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = LE_T194.startIndex;
                        int endIndex = LE_T194.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1 , InfixExpression.OP_IS_SMALLER_OR_EQUAL, expr2); 
                      

                    }
                    break;
                case 31 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1107:5: ^( ME_T expression expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    ME_T195=(SLAST)match(input,ME_T,FOLLOW_ME_T_in_expression2330); 
                    ME_T195_tree = (SLAST)adaptor.dupNode(ME_T195);

                    root_1 = (SLAST)adaptor.becomeRoot(ME_T195_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2332);
                    expression196=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression196.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2334);
                    expression197=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression197.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = ME_T195.startIndex;
                        int endIndex = ME_T195.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1 , InfixExpression.OP_IS_GREATER_OR_EQUAL, expr2); 
                      

                    }
                    break;
                case 32 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1115:5: ^( LSHIFT_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    LSHIFT_T198=(SLAST)match(input,LSHIFT_T,FOLLOW_LSHIFT_T_in_expression2346); 
                    LSHIFT_T198_tree = (SLAST)adaptor.dupNode(LSHIFT_T198);

                    root_1 = (SLAST)adaptor.becomeRoot(LSHIFT_T198_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2350);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2354);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = LSHIFT_T198.startIndex;
                        int endIndex = LSHIFT_T198.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1, InfixExpression.OP_SL, expr2); 
                      

                    }
                    break;
                case 33 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1123:5: ^( RSHIFT_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    RSHIFT_T199=(SLAST)match(input,RSHIFT_T,FOLLOW_RSHIFT_T_in_expression2366); 
                    RSHIFT_T199_tree = (SLAST)adaptor.dupNode(RSHIFT_T199);

                    root_1 = (SLAST)adaptor.becomeRoot(RSHIFT_T199_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2370);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2374);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = RSHIFT_T199.startIndex;
                        int endIndex = RSHIFT_T199.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1, InfixExpression.OP_SR, expr2); 
                      

                    }
                    break;
                case 34 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1131:5: ^( PLUS_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    PLUS_T200=(SLAST)match(input,PLUS_T,FOLLOW_PLUS_T_in_expression2386); 
                    PLUS_T200_tree = (SLAST)adaptor.dupNode(PLUS_T200);

                    root_1 = (SLAST)adaptor.becomeRoot(PLUS_T200_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2390);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2394);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = PLUS_T200.startIndex;
                        int endIndex = PLUS_T200.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1, InfixExpression.OP_PLUS, expr2);
                      

                    }
                    break;
                case 35 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1139:5: ^( MINUS_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    MINUS_T201=(SLAST)match(input,MINUS_T,FOLLOW_MINUS_T_in_expression2406); 
                    MINUS_T201_tree = (SLAST)adaptor.dupNode(MINUS_T201);

                    root_1 = (SLAST)adaptor.becomeRoot(MINUS_T201_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2410);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2414);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = MINUS_T201.startIndex;
                        int endIndex = MINUS_T201.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1, InfixExpression.OP_MINUS, expr2);
                      

                    }
                    break;
                case 36 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1147:5: ^( MUL_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    MUL_T202=(SLAST)match(input,MUL_T,FOLLOW_MUL_T_in_expression2426); 
                    MUL_T202_tree = (SLAST)adaptor.dupNode(MUL_T202);

                    root_1 = (SLAST)adaptor.becomeRoot(MUL_T202_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2430);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2434);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = MUL_T202.startIndex;
                        int endIndex = MUL_T202.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1, InfixExpression.OP_MUL, expr2);
                      

                    }
                    break;
                case 37 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1155:5: ^( DIV_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    DIV_T203=(SLAST)match(input,DIV_T,FOLLOW_DIV_T_in_expression2446); 
                    DIV_T203_tree = (SLAST)adaptor.dupNode(DIV_T203);

                    root_1 = (SLAST)adaptor.becomeRoot(DIV_T203_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2450);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2454);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = DIV_T203.startIndex;
                        int endIndex = DIV_T203.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1, InfixExpression.OP_DIV, expr2);
                      

                    }
                    break;
                case 38 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1163:5: ^( PERCENT_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    PERCENT_T204=(SLAST)match(input,PERCENT_T,FOLLOW_PERCENT_T_in_expression2466); 
                    PERCENT_T204_tree = (SLAST)adaptor.dupNode(PERCENT_T204);

                    root_1 = (SLAST)adaptor.becomeRoot(PERCENT_T204_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2470);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2474);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = PERCENT_T204.startIndex;
                        int endIndex = PERCENT_T204.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1, InfixExpression.OP_MOD, expr2);
                      

                    }
                    break;
                case 39 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1171:5: ^( CAST_EXPR cast_option e= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    CAST_EXPR205=(SLAST)match(input,CAST_EXPR,FOLLOW_CAST_EXPR_in_expression2486); 
                    CAST_EXPR205_tree = (SLAST)adaptor.dupNode(CAST_EXPR205);

                    root_1 = (SLAST)adaptor.becomeRoot(CAST_EXPR205_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_cast_option_in_expression2488);
                    cast_option206=cast_option();

                    state._fsp--;

                    adaptor.addChild(root_1, cast_option206.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2492);
                    e=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int result = (cast_option206!=null?cast_option206.castOption:0);
                        int startIndex = CAST_EXPR205.startIndex;
                        int endIndex = CAST_EXPR205.endIndex + 1;
                        Expression expr = (e!=null?e.expr:null);
                        switch(result) {
                          case 1:
                          case 2:
                            retval.expr = new CastExpression(startIndex, endIndex, expr, CastExpression.TYPE_BOOL);
                            break;
                          case 3:
                            retval.expr = new CastExpression(startIndex, endIndex, expr, CastExpression.TYPE_INT);
                            break;
                          case 6:
                            retval.expr = new CastExpression(startIndex, endIndex, expr, CastExpression.TYPE_ARRAY);
                            break;
                          case 7:
                            retval.expr = new CastExpression(startIndex, endIndex, expr, CastExpression.TYPE_OBJECT);
                            break;
                          case 8:
                            retval.expr = new CastExpression(startIndex, endIndex, expr, CastExpression.TYPE_REAL);
                            break;
                          case 9:
                            retval.expr = new CastExpression(startIndex, endIndex, expr, CastExpression.TYPE_STRING);
                            break;
                          case 10:
                            retval.expr = new CastExpression(startIndex, endIndex, expr, CastExpression.TYPE_UNSET);
                            break;
                          default:
                            retval.expr = new CastExpression(startIndex, endIndex, expr, CastExpression.TYPE_OBJECT);
                            break;
                        }
                      

                    }
                    break;
                case 40 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1205:5: ^( TILDA_T e= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    TILDA_T207=(SLAST)match(input,TILDA_T,FOLLOW_TILDA_T_in_expression2504); 
                    TILDA_T207_tree = (SLAST)adaptor.dupNode(TILDA_T207);

                    root_1 = (SLAST)adaptor.becomeRoot(TILDA_T207_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2508);
                    e=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                          int startIndex = TILDA_T207.startIndex;
                          int endIndex = TILDA_T207.endIndex + 1;
                          retval.expr = new UnaryOperation(startIndex, endIndex, (e!=null?e.expr:null) , UnaryOperation.OP_TILDA);
                      

                    }
                    break;
                case 41 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1211:5: ^( EXC_NOT_T expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    EXC_NOT_T208=(SLAST)match(input,EXC_NOT_T,FOLLOW_EXC_NOT_T_in_expression2520); 
                    EXC_NOT_T208_tree = (SLAST)adaptor.dupNode(EXC_NOT_T208);

                    root_1 = (SLAST)adaptor.becomeRoot(EXC_NOT_T208_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2522);
                    expression209=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression209.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 42 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1212:5: ^( POSTFIX_EXPR e= expression plus_minus )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    POSTFIX_EXPR210=(SLAST)match(input,POSTFIX_EXPR,FOLLOW_POSTFIX_EXPR_in_expression2530); 
                    POSTFIX_EXPR210_tree = (SLAST)adaptor.dupNode(POSTFIX_EXPR210);

                    root_1 = (SLAST)adaptor.becomeRoot(POSTFIX_EXPR210_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2534);
                    e=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_plus_minus_in_expression2536);
                    plus_minus211=plus_minus();

                    state._fsp--;

                    adaptor.addChild(root_1, plus_minus211.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                          int startIndex = POSTFIX_EXPR210.startIndex;
                          int endIndex = POSTFIX_EXPR210.endIndex + 1;
                          if ((plus_minus211!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(plus_minus211.start),
                      input.getTreeAdaptor().getTokenStopIndex(plus_minus211.start))):null).equals("++")) {
                            retval.expr = new PostfixExpression(startIndex, endIndex, (e!=null?e.expr:null) , PostfixExpression.OP_INC);
                          }
                          else {
                            retval.expr = new PostfixExpression(startIndex, endIndex, (e!=null?e.expr:null) , PostfixExpression.OP_DEC);
                          } 
                      

                    }
                    break;
                case 43 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1223:5: ^( PREFIX_EXPR ( plus_minus )+ e= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    PREFIX_EXPR212=(SLAST)match(input,PREFIX_EXPR,FOLLOW_PREFIX_EXPR_in_expression2548); 
                    PREFIX_EXPR212_tree = (SLAST)adaptor.dupNode(PREFIX_EXPR212);

                    root_1 = (SLAST)adaptor.becomeRoot(PREFIX_EXPR212_tree, root_1);



                    match(input, Token.DOWN, null); 
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1223:19: ( plus_minus )+
                    int cnt65=0;
                    loop65:
                    do {
                        int alt65=2;
                        int LA65_0 = input.LA(1);

                        if ( ((LA65_0>=PLUS_PLUS_T && LA65_0<=MINUS_MINUS_T)) ) {
                            alt65=1;
                        }


                        switch (alt65) {
                    	case 1 :
                    	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1223:19: plus_minus
                    	    {
                    	    _last = (SLAST)input.LT(1);
                    	    pushFollow(FOLLOW_plus_minus_in_expression2550);
                    	    plus_minus213=plus_minus();

                    	    state._fsp--;

                    	    adaptor.addChild(root_1, plus_minus213.getTree());

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt65 >= 1 ) break loop65;
                                EarlyExitException eee =
                                    new EarlyExitException(65, input);
                                throw eee;
                        }
                        cnt65++;
                    } while (true);

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2555);
                    e=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                          int startIndex = PREFIX_EXPR212.startIndex;
                          int endIndex = PREFIX_EXPR212.endIndex + 1;
                          if ((plus_minus213!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(plus_minus213.start),
                      input.getTreeAdaptor().getTokenStopIndex(plus_minus213.start))):null).equals("++")) {
                            retval.expr = new PrefixExpression(startIndex, endIndex, (e!=null?e.expr:null), PrefixExpression.OP_INC);
                          }
                          else {
                            retval.expr = new PrefixExpression(startIndex, endIndex, (e!=null?e.expr:null), PrefixExpression.OP_DEC);
                          }
                      

                    }
                    break;
                case 44 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1234:5: ^( INSTANCEOF_T expression class_name_reference )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    INSTANCEOF_T214=(SLAST)match(input,INSTANCEOF_T,FOLLOW_INSTANCEOF_T_in_expression2567); 
                    INSTANCEOF_T214_tree = (SLAST)adaptor.dupNode(INSTANCEOF_T214);

                    root_1 = (SLAST)adaptor.becomeRoot(INSTANCEOF_T214_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2569);
                    expression215=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression215.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_class_name_reference_in_expression2571);
                    class_name_reference216=class_name_reference();

                    state._fsp--;

                    adaptor.addChild(root_1, class_name_reference216.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 45 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1235:5: ( AT_T )? variable
                    {
                    root_0 = (SLAST)adaptor.nil();

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1235:5: ( AT_T )?
                    int alt66=2;
                    int LA66_0 = input.LA(1);

                    if ( (LA66_0==AT_T) ) {
                        alt66=1;
                    }
                    switch (alt66) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1235:5: AT_T
                            {
                            _last = (SLAST)input.LT(1);
                            AT_T217=(SLAST)match(input,AT_T,FOLLOW_AT_T_in_expression2578); 
                            AT_T217_tree = (SLAST)adaptor.dupNode(AT_T217);

                            adaptor.addChild(root_0, AT_T217_tree);


                            }
                            break;

                    }

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_variable_in_expression2581);
                    variable218=variable();

                    state._fsp--;

                    adaptor.addChild(root_0, variable218.getTree());

                        retval.expr = (variable218!=null?variable218.var:null);
                      

                    }
                    break;
                case 46 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1239:5: ( AT_T )? scalar
                    {
                    root_0 = (SLAST)adaptor.nil();

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1239:5: ( AT_T )?
                    int alt67=2;
                    int LA67_0 = input.LA(1);

                    if ( (LA67_0==AT_T) ) {
                        alt67=1;
                    }
                    switch (alt67) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1239:5: AT_T
                            {
                            _last = (SLAST)input.LT(1);
                            AT_T219=(SLAST)match(input,AT_T,FOLLOW_AT_T_in_expression2591); 
                            AT_T219_tree = (SLAST)adaptor.dupNode(AT_T219);

                            adaptor.addChild(root_0, AT_T219_tree);


                            }
                            break;

                    }

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_scalar_in_expression2594);
                    scalar220=scalar();

                    state._fsp--;

                    adaptor.addChild(root_0, scalar220.getTree());

                        retval.expr = (scalar220!=null?scalar220.expr:null);
                        ast = (scalar220!=null?((SLAST)scalar220.tree):null);
                      

                    }
                    break;
                case 47 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1244:5: ^( LIST_T ( assignment_list )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    LIST_T221=(SLAST)match(input,LIST_T,FOLLOW_LIST_T_in_expression2605); 
                    LIST_T221_tree = (SLAST)adaptor.dupNode(LIST_T221);

                    root_1 = (SLAST)adaptor.becomeRoot(LIST_T221_tree, root_1);



                    if ( input.LA(1)==Token.DOWN ) {
                        match(input, Token.DOWN, null); 
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1244:14: ( assignment_list )?
                        int alt68=2;
                        int LA68_0 = input.LA(1);

                        if ( (LA68_0==VAR_DECL||LA68_0==CALL||LA68_0==LIST_T) ) {
                            alt68=1;
                        }
                        switch (alt68) {
                            case 1 :
                                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1244:14: assignment_list
                                {
                                _last = (SLAST)input.LT(1);
                                pushFollow(FOLLOW_assignment_list_in_expression2607);
                                assignment_list222=assignment_list();

                                state._fsp--;

                                adaptor.addChild(root_1, assignment_list222.getTree());

                                }
                                break;

                        }


                        match(input, Token.UP, null); 
                    }adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 48 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1245:5: ^( ARRAY_DECL ( array_pair_list )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    ARRAY_DECL223=(SLAST)match(input,ARRAY_DECL,FOLLOW_ARRAY_DECL_in_expression2616); 
                    ARRAY_DECL223_tree = (SLAST)adaptor.dupNode(ARRAY_DECL223);

                    root_1 = (SLAST)adaptor.becomeRoot(ARRAY_DECL223_tree, root_1);



                    if ( input.LA(1)==Token.DOWN ) {
                        match(input, Token.DOWN, null); 
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1245:18: ( array_pair_list )?
                        int alt69=2;
                        int LA69_0 = input.LA(1);

                        if ( (LA69_0==METHOD_DECL||LA69_0==VAR_DECL||LA69_0==CALL||LA69_0==EXPR||(LA69_0>=SCALAR && LA69_0<=CAST_EXPR)||LA69_0==REF_T||LA69_0==ARROW_T||LA69_0==EQUAL_T||(LA69_0>=OR_T && LA69_0<=EXC_NOT_T)||(LA69_0>=INSTANCEOF_T && LA69_0<=BACKTRICKLITERAL)) ) {
                            alt69=1;
                        }
                        switch (alt69) {
                            case 1 :
                                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1245:18: array_pair_list
                                {
                                _last = (SLAST)input.LT(1);
                                pushFollow(FOLLOW_array_pair_list_in_expression2618);
                                array_pair_list224=array_pair_list();

                                state._fsp--;

                                adaptor.addChild(root_1, array_pair_list224.getTree());

                                }
                                break;

                        }


                        match(input, Token.UP, null); 
                    }adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = ARRAY_DECL223.startIndex;
                        int endIndex = ARRAY_DECL223.endIndex + 1;
                        if ((array_pair_list224!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(array_pair_list224.start),
                      input.getTreeAdaptor().getTokenStopIndex(array_pair_list224.start))):null) != null) {
                           retval.expr = new ArrayCreation(startIndex, endIndex, (array_pair_list224!=null?array_pair_list224.arrayList:null));
                        }
                        else {
                           retval.expr = new ArrayCreation(startIndex, endIndex, new LinkedList());
                        }
                      

                    }
                    break;
                case 49 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1256:5: ^( NEW_T class_name_reference )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    NEW_T225=(SLAST)match(input,NEW_T,FOLLOW_NEW_T_in_expression2631); 
                    NEW_T225_tree = (SLAST)adaptor.dupNode(NEW_T225);

                    root_1 = (SLAST)adaptor.becomeRoot(NEW_T225_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_class_name_reference_in_expression2633);
                    class_name_reference226=class_name_reference();

                    state._fsp--;

                    adaptor.addChild(root_1, class_name_reference226.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = NEW_T225.startIndex;
                        int endIndex = NEW_T225.endIndex + 1;
                        Expression className = (class_name_reference226!=null?class_name_reference226.var:null);
                        PHPCallArgumentsList ctor = (class_name_reference226!=null?class_name_reference226.parameterList:null);
                        if (ctor == null) {
                          ctor = new PHPCallArgumentsList();
                        }
                        
                        ClassInstanceCreation classInstanceCreation = new ClassInstanceCreation(startIndex, endIndex, className, ctor);
                        retval.expr = classInstanceCreation;
                      

                    }
                    break;
                case 50 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1270:5: ^( CLONE_T variable )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    CLONE_T227=(SLAST)match(input,CLONE_T,FOLLOW_CLONE_T_in_expression2648); 
                    CLONE_T227_tree = (SLAST)adaptor.dupNode(CLONE_T227);

                    root_1 = (SLAST)adaptor.becomeRoot(CLONE_T227_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_variable_in_expression2650);
                    variable228=variable();

                    state._fsp--;

                    adaptor.addChild(root_1, variable228.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = CLONE_T227.startIndex;
                        int endIndex = CLONE_T227.endIndex;
                        retval.expr = new CloneExpression(startIndex, endIndex, (variable228!=null?variable228.var:null));
                      

                    }
                    break;
                case 51 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1276:5: ^( EXIT_T ( expression )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    EXIT_T229=(SLAST)match(input,EXIT_T,FOLLOW_EXIT_T_in_expression2662); 
                    EXIT_T229_tree = (SLAST)adaptor.dupNode(EXIT_T229);

                    root_1 = (SLAST)adaptor.becomeRoot(EXIT_T229_tree, root_1);



                    if ( input.LA(1)==Token.DOWN ) {
                        match(input, Token.DOWN, null); 
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1276:14: ( expression )?
                        int alt70=2;
                        int LA70_0 = input.LA(1);

                        if ( (LA70_0==METHOD_DECL||LA70_0==VAR_DECL||LA70_0==CALL||LA70_0==EXPR||(LA70_0>=SCALAR && LA70_0<=CAST_EXPR)||LA70_0==REF_T||LA70_0==EQUAL_T||(LA70_0>=OR_T && LA70_0<=EXC_NOT_T)||(LA70_0>=INSTANCEOF_T && LA70_0<=BACKTRICKLITERAL)) ) {
                            alt70=1;
                        }
                        switch (alt70) {
                            case 1 :
                                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1276:14: expression
                                {
                                _last = (SLAST)input.LT(1);
                                pushFollow(FOLLOW_expression_in_expression2664);
                                expression230=expression();

                                state._fsp--;

                                adaptor.addChild(root_1, expression230.getTree());

                                }
                                break;

                        }


                        match(input, Token.UP, null); 
                    }adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 52 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1277:5: ^( UNSET_T variable )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    UNSET_T231=(SLAST)match(input,UNSET_T,FOLLOW_UNSET_T_in_expression2673); 
                    UNSET_T231_tree = (SLAST)adaptor.dupNode(UNSET_T231);

                    root_1 = (SLAST)adaptor.becomeRoot(UNSET_T231_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_variable_in_expression2675);
                    variable232=variable();

                    state._fsp--;

                    adaptor.addChild(root_1, variable232.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 53 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1278:5: lambda_function_declaration
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_lambda_function_declaration_in_expression2682);
                    lambda_function_declaration233=lambda_function_declaration();

                    state._fsp--;

                    adaptor.addChild(root_0, lambda_function_declaration233.getTree());

                    }
                    break;
                case 54 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1279:5: BACKTRICKLITERAL
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    BACKTRICKLITERAL234=(SLAST)match(input,BACKTRICKLITERAL,FOLLOW_BACKTRICKLITERAL_in_expression2688); 
                    BACKTRICKLITERAL234_tree = (SLAST)adaptor.dupNode(BACKTRICKLITERAL234);

                    adaptor.addChild(root_0, BACKTRICKLITERAL234_tree);


                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);


              if (ast != null) {
                retval.tree = ast;
              }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "expression"

    public static class plus_minus_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "plus_minus"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1283:1: plus_minus : ( PLUS_PLUS_T | MINUS_MINUS_T );
    public final TreePHP.plus_minus_return plus_minus() throws RecognitionException {
        TreePHP.plus_minus_return retval = new TreePHP.plus_minus_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST set235=null;

        SLAST set235_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1284:3: ( PLUS_PLUS_T | MINUS_MINUS_T )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            set235=(SLAST)input.LT(1);
            if ( (input.LA(1)>=PLUS_PLUS_T && input.LA(1)<=MINUS_MINUS_T) ) {
                input.consume();

                set235_tree = (SLAST)adaptor.dupNode(set235);

                adaptor.addChild(root_0, set235_tree);

                state.errorRecovery=false;
            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                throw mse;
            }

             

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "plus_minus"

    public static class cast_option_return extends TreeRuleReturnScope {
        public int castOption;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "cast_option"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1288:1: cast_option returns [int castOption] : ( 'bool' | 'boolean' | 'int' | 'float' | 'double' | 'array' | 'object' | 'real' | 'string' | UNSET_T | CLONE_T );
    public final TreePHP.cast_option_return cast_option() throws RecognitionException {
        TreePHP.cast_option_return retval = new TreePHP.cast_option_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST string_literal236=null;
        SLAST string_literal237=null;
        SLAST string_literal238=null;
        SLAST string_literal239=null;
        SLAST string_literal240=null;
        SLAST string_literal241=null;
        SLAST string_literal242=null;
        SLAST string_literal243=null;
        SLAST string_literal244=null;
        SLAST UNSET_T245=null;
        SLAST CLONE_T246=null;

        SLAST string_literal236_tree=null;
        SLAST string_literal237_tree=null;
        SLAST string_literal238_tree=null;
        SLAST string_literal239_tree=null;
        SLAST string_literal240_tree=null;
        SLAST string_literal241_tree=null;
        SLAST string_literal242_tree=null;
        SLAST string_literal243_tree=null;
        SLAST string_literal244_tree=null;
        SLAST UNSET_T245_tree=null;
        SLAST CLONE_T246_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1289:3: ( 'bool' | 'boolean' | 'int' | 'float' | 'double' | 'array' | 'object' | 'real' | 'string' | UNSET_T | CLONE_T )
            int alt72=11;
            switch ( input.LA(1) ) {
            case 168:
                {
                alt72=1;
                }
                break;
            case 169:
                {
                alt72=2;
                }
                break;
            case 170:
                {
                alt72=3;
                }
                break;
            case 171:
                {
                alt72=4;
                }
                break;
            case 172:
                {
                alt72=5;
                }
                break;
            case 176:
                {
                alt72=6;
                }
                break;
            case 175:
                {
                alt72=7;
                }
                break;
            case 173:
                {
                alt72=8;
                }
                break;
            case 174:
                {
                alt72=9;
                }
                break;
            case UNSET_T:
                {
                alt72=10;
                }
                break;
            case CLONE_T:
                {
                alt72=11;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 72, 0, input);

                throw nvae;
            }

            switch (alt72) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1289:5: 'bool'
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    string_literal236=(SLAST)match(input,168,FOLLOW_168_in_cast_option2727); 
                    string_literal236_tree = (SLAST)adaptor.dupNode(string_literal236);

                    adaptor.addChild(root_0, string_literal236_tree);

                    retval.castOption = 1;

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1290:5: 'boolean'
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    string_literal237=(SLAST)match(input,169,FOLLOW_169_in_cast_option2738); 
                    string_literal237_tree = (SLAST)adaptor.dupNode(string_literal237);

                    adaptor.addChild(root_0, string_literal237_tree);

                    retval.castOption = 2;

                    }
                    break;
                case 3 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1291:5: 'int'
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    string_literal238=(SLAST)match(input,170,FOLLOW_170_in_cast_option2746); 
                    string_literal238_tree = (SLAST)adaptor.dupNode(string_literal238);

                    adaptor.addChild(root_0, string_literal238_tree);

                    retval.castOption = 3;

                    }
                    break;
                case 4 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1292:5: 'float'
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    string_literal239=(SLAST)match(input,171,FOLLOW_171_in_cast_option2758); 
                    string_literal239_tree = (SLAST)adaptor.dupNode(string_literal239);

                    adaptor.addChild(root_0, string_literal239_tree);

                    retval.castOption = 4;

                    }
                    break;
                case 5 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1293:5: 'double'
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    string_literal240=(SLAST)match(input,172,FOLLOW_172_in_cast_option2768); 
                    string_literal240_tree = (SLAST)adaptor.dupNode(string_literal240);

                    adaptor.addChild(root_0, string_literal240_tree);

                    retval.castOption = 5;

                    }
                    break;
                case 6 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1294:5: 'array'
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    string_literal241=(SLAST)match(input,176,FOLLOW_176_in_cast_option2777); 
                    string_literal241_tree = (SLAST)adaptor.dupNode(string_literal241);

                    adaptor.addChild(root_0, string_literal241_tree);

                    retval.castOption = 6;

                    }
                    break;
                case 7 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1295:5: 'object'
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    string_literal242=(SLAST)match(input,175,FOLLOW_175_in_cast_option2787); 
                    string_literal242_tree = (SLAST)adaptor.dupNode(string_literal242);

                    adaptor.addChild(root_0, string_literal242_tree);

                    retval.castOption = 7;

                    }
                    break;
                case 8 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1296:5: 'real'
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    string_literal243=(SLAST)match(input,173,FOLLOW_173_in_cast_option2796); 
                    string_literal243_tree = (SLAST)adaptor.dupNode(string_literal243);

                    adaptor.addChild(root_0, string_literal243_tree);

                    retval.castOption = 8;

                    }
                    break;
                case 9 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1297:5: 'string'
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    string_literal244=(SLAST)match(input,174,FOLLOW_174_in_cast_option2807); 
                    string_literal244_tree = (SLAST)adaptor.dupNode(string_literal244);

                    adaptor.addChild(root_0, string_literal244_tree);

                    retval.castOption = 9;

                    }
                    break;
                case 10 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1298:5: UNSET_T
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    UNSET_T245=(SLAST)match(input,UNSET_T,FOLLOW_UNSET_T_in_cast_option2816); 
                    UNSET_T245_tree = (SLAST)adaptor.dupNode(UNSET_T245);

                    adaptor.addChild(root_0, UNSET_T245_tree);

                    retval.castOption = 10;

                    }
                    break;
                case 11 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1299:5: CLONE_T
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    CLONE_T246=(SLAST)match(input,CLONE_T,FOLLOW_CLONE_T_in_cast_option2826); 
                    CLONE_T246_tree = (SLAST)adaptor.dupNode(CLONE_T246);

                    adaptor.addChild(root_0, CLONE_T246_tree);

                    retval.castOption = 11;

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "cast_option"

    public static class lambda_function_declaration_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "lambda_function_declaration"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1302:1: lambda_function_declaration : ^( METHOD_DECL ( REF_T )? ( parameter_list )? ( ^( USE_T ( expr_list )? ) )? block ) ;
    public final TreePHP.lambda_function_declaration_return lambda_function_declaration() throws RecognitionException {
        TreePHP.lambda_function_declaration_return retval = new TreePHP.lambda_function_declaration_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST METHOD_DECL247=null;
        SLAST REF_T248=null;
        SLAST USE_T250=null;
        TreePHP.parameter_list_return parameter_list249 = null;

        TreePHP.expr_list_return expr_list251 = null;

        TreePHP.block_return block252 = null;


        SLAST METHOD_DECL247_tree=null;
        SLAST REF_T248_tree=null;
        SLAST USE_T250_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1303:3: ( ^( METHOD_DECL ( REF_T )? ( parameter_list )? ( ^( USE_T ( expr_list )? ) )? block ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1303:5: ^( METHOD_DECL ( REF_T )? ( parameter_list )? ( ^( USE_T ( expr_list )? ) )? block )
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_1 = _last;
            SLAST _first_1 = null;
            SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            METHOD_DECL247=(SLAST)match(input,METHOD_DECL,FOLLOW_METHOD_DECL_in_lambda_function_declaration2845); 
            METHOD_DECL247_tree = (SLAST)adaptor.dupNode(METHOD_DECL247);

            root_1 = (SLAST)adaptor.becomeRoot(METHOD_DECL247_tree, root_1);



            match(input, Token.DOWN, null); 
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1303:19: ( REF_T )?
            int alt73=2;
            int LA73_0 = input.LA(1);

            if ( (LA73_0==REF_T) ) {
                alt73=1;
            }
            switch (alt73) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1303:19: REF_T
                    {
                    _last = (SLAST)input.LT(1);
                    REF_T248=(SLAST)match(input,REF_T,FOLLOW_REF_T_in_lambda_function_declaration2847); 
                    REF_T248_tree = (SLAST)adaptor.dupNode(REF_T248);

                    adaptor.addChild(root_1, REF_T248_tree);


                    }
                    break;

            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1303:26: ( parameter_list )?
            int alt74=2;
            int LA74_0 = input.LA(1);

            if ( (LA74_0==PARAMETER) ) {
                alt74=1;
            }
            switch (alt74) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1303:26: parameter_list
                    {
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_parameter_list_in_lambda_function_declaration2850);
                    parameter_list249=parameter_list();

                    state._fsp--;

                    adaptor.addChild(root_1, parameter_list249.getTree());

                    }
                    break;

            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1303:42: ( ^( USE_T ( expr_list )? ) )?
            int alt76=2;
            int LA76_0 = input.LA(1);

            if ( (LA76_0==USE_T) ) {
                alt76=1;
            }
            switch (alt76) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1303:43: ^( USE_T ( expr_list )? )
                    {
                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_2 = _last;
                    SLAST _first_2 = null;
                    SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    USE_T250=(SLAST)match(input,USE_T,FOLLOW_USE_T_in_lambda_function_declaration2855); 
                    USE_T250_tree = (SLAST)adaptor.dupNode(USE_T250);

                    root_2 = (SLAST)adaptor.becomeRoot(USE_T250_tree, root_2);



                    if ( input.LA(1)==Token.DOWN ) {
                        match(input, Token.DOWN, null); 
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1303:51: ( expr_list )?
                        int alt75=2;
                        int LA75_0 = input.LA(1);

                        if ( (LA75_0==METHOD_DECL||LA75_0==VAR_DECL||LA75_0==CALL||LA75_0==EXPR||(LA75_0>=SCALAR && LA75_0<=CAST_EXPR)||LA75_0==REF_T||LA75_0==EQUAL_T||(LA75_0>=OR_T && LA75_0<=EXC_NOT_T)||(LA75_0>=INSTANCEOF_T && LA75_0<=BACKTRICKLITERAL)) ) {
                            alt75=1;
                        }
                        switch (alt75) {
                            case 1 :
                                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1303:51: expr_list
                                {
                                _last = (SLAST)input.LT(1);
                                pushFollow(FOLLOW_expr_list_in_lambda_function_declaration2857);
                                expr_list251=expr_list();

                                state._fsp--;

                                adaptor.addChild(root_2, expr_list251.getTree());

                                }
                                break;

                        }


                        match(input, Token.UP, null); 
                    }adaptor.addChild(root_1, root_2);_last = _save_last_2;
                    }


                    }
                    break;

            }

            _last = (SLAST)input.LT(1);
            pushFollow(FOLLOW_block_in_lambda_function_declaration2869);
            block252=block();

            state._fsp--;

            adaptor.addChild(root_1, block252.getTree());

            match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "lambda_function_declaration"

    protected static class class_name_reference_scope {
        List list;
        List argList;
    }
    protected Stack class_name_reference_stack = new Stack();

    public static class class_name_reference_return extends TreeRuleReturnScope {
        public Expression var;
        public Expression expr;
        public PHPCallArgumentsList parameterList;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "class_name_reference"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1307:1: class_name_reference returns [Expression var, Expression expr, PHPCallArgumentsList parameterList] : ( dynamic_name_reference | fully_qualified_class_name );
    public final TreePHP.class_name_reference_return class_name_reference() throws RecognitionException {
        class_name_reference_stack.push(new class_name_reference_scope());
        TreePHP.class_name_reference_return retval = new TreePHP.class_name_reference_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.dynamic_name_reference_return dynamic_name_reference253 = null;

        TreePHP.fully_qualified_class_name_return fully_qualified_class_name254 = null;




          ((class_name_reference_scope)class_name_reference_stack.peek()).list = new LinkedList();
          ((class_name_reference_scope)class_name_reference_stack.peek()).argList = new LinkedList();

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1316:3: ( dynamic_name_reference | fully_qualified_class_name )
            int alt77=2;
            int LA77_0 = input.LA(1);

            if ( (LA77_0==VAR_DECL||LA77_0==CALL) ) {
                alt77=1;
            }
            else if ( (LA77_0==IDENTIFIER||LA77_0==DOMAIN_T) ) {
                alt77=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 77, 0, input);

                throw nvae;
            }
            switch (alt77) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1316:5: dynamic_name_reference
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_dynamic_name_reference_in_class_name_reference2902);
                    dynamic_name_reference253=dynamic_name_reference();

                    state._fsp--;

                    adaptor.addChild(root_0, dynamic_name_reference253.getTree());

                        retval.var = (dynamic_name_reference253!=null?dynamic_name_reference253.var:null);
                        retval.parameterList = (dynamic_name_reference253!=null?dynamic_name_reference253.parameterList:null);
                        retval.expr = (dynamic_name_reference253!=null?dynamic_name_reference253.expr:null);
                        
                        Expression dispatcher = retval.var;
                        Iterator iter = ((class_name_reference_scope)class_name_reference_stack.peek()).list.iterator();
                        while (iter.hasNext()) {
                          Expression property = (Expression)iter.next();
                          dispatcher = createDispatch(dispatcher, property);
                        }
                        retval.var = dispatcher;
                      

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1330:5: fully_qualified_class_name
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_fully_qualified_class_name_in_class_name_reference2913);
                    fully_qualified_class_name254=fully_qualified_class_name();

                    state._fsp--;

                    adaptor.addChild(root_0, fully_qualified_class_name254.getTree());

                        retval.var = (fully_qualified_class_name254!=null?fully_qualified_class_name254.type:null);
                      

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
            class_name_reference_stack.pop();
        }
        return retval;
    }
    // $ANTLR end "class_name_reference"

    public static class dynamic_name_reference_return extends TreeRuleReturnScope {
        public Expression var;
        public PHPCallArgumentsList parameterList;
        public Expression expr;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "dynamic_name_reference"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1336:1: dynamic_name_reference returns [Expression var, PHPCallArgumentsList parameterList, Expression expr] : ( base_variable_with_function_calls | ^( CALL v1= dynamic_name_reference obj= object_property ( ctor_arguments )? ) );
    public final TreePHP.dynamic_name_reference_return dynamic_name_reference() throws RecognitionException {
        TreePHP.dynamic_name_reference_return retval = new TreePHP.dynamic_name_reference_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST CALL256=null;
        TreePHP.dynamic_name_reference_return v1 = null;

        TreePHP.object_property_return obj = null;

        TreePHP.base_variable_with_function_calls_return base_variable_with_function_calls255 = null;

        TreePHP.ctor_arguments_return ctor_arguments257 = null;


        SLAST CALL256_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1337:3: ( base_variable_with_function_calls | ^( CALL v1= dynamic_name_reference obj= object_property ( ctor_arguments )? ) )
            int alt79=2;
            int LA79_0 = input.LA(1);

            if ( (LA79_0==VAR_DECL) ) {
                alt79=1;
            }
            else if ( (LA79_0==CALL) ) {
                int LA79_2 = input.LA(2);

                if ( (LA79_2==DOWN) ) {
                    int LA79_3 = input.LA(3);

                    if ( (LA79_3==VAR_DECL||LA79_3==CALL) ) {
                        alt79=2;
                    }
                    else if ( (LA79_3==IDENTIFIER||LA79_3==DOMAIN_T) ) {
                        alt79=1;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 79, 3, input);

                        throw nvae;
                    }
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 79, 2, input);

                    throw nvae;
                }
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 79, 0, input);

                throw nvae;
            }
            switch (alt79) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1337:5: base_variable_with_function_calls
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_base_variable_with_function_calls_in_dynamic_name_reference2936);
                    base_variable_with_function_calls255=base_variable_with_function_calls();

                    state._fsp--;

                    adaptor.addChild(root_0, base_variable_with_function_calls255.getTree());

                         retval.expr = (base_variable_with_function_calls255!=null?base_variable_with_function_calls255.var:null);
                         retval.var = (base_variable_with_function_calls255!=null?base_variable_with_function_calls255.var:null);
                         retval.parameterList = (base_variable_with_function_calls255!=null?base_variable_with_function_calls255.parameterList:null);
                      

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1343:5: ^( CALL v1= dynamic_name_reference obj= object_property ( ctor_arguments )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    CALL256=(SLAST)match(input,CALL,FOLLOW_CALL_in_dynamic_name_reference2948); 
                    CALL256_tree = (SLAST)adaptor.dupNode(CALL256);

                    root_1 = (SLAST)adaptor.becomeRoot(CALL256_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_dynamic_name_reference_in_dynamic_name_reference2952);
                    v1=dynamic_name_reference();

                    state._fsp--;

                    adaptor.addChild(root_1, v1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_object_property_in_dynamic_name_reference2956);
                    obj=object_property();

                    state._fsp--;

                    adaptor.addChild(root_1, obj.getTree());
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1343:58: ( ctor_arguments )?
                    int alt78=2;
                    int LA78_0 = input.LA(1);

                    if ( (LA78_0==ARGU) ) {
                        alt78=1;
                    }
                    switch (alt78) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1343:58: ctor_arguments
                            {
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_ctor_arguments_in_dynamic_name_reference2958);
                            ctor_arguments257=ctor_arguments();

                            state._fsp--;

                            adaptor.addChild(root_1, ctor_arguments257.getTree());

                            }
                            break;

                    }


                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                          retval.var = (v1!=null?v1.expr:null);
                          retval.expr = (v1!=null?v1.var:null);
                          
                          ((class_name_reference_scope)class_name_reference_stack.peek()).list.add((obj!=null?obj.expr:null));
                          
                          System.out.println("ctor:");
                          if ((ctor_arguments257!=null?ctor_arguments257.argumentList:null) != null) {
                            retval.parameterList = (ctor_arguments257!=null?ctor_arguments257.argumentList:null);
                          }
                          else if ((v1!=null?v1.parameterList:null) != null) {
                            retval.parameterList = (ctor_arguments257!=null?ctor_arguments257.argumentList:null);
                          }
                      

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "dynamic_name_reference"

    public static class assignment_list_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "assignment_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1360:1: assignment_list : ( assignment_element )+ ;
    public final TreePHP.assignment_list_return assignment_list() throws RecognitionException {
        TreePHP.assignment_list_return retval = new TreePHP.assignment_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.assignment_element_return assignment_element258 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1361:3: ( ( assignment_element )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1361:5: ( assignment_element )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1361:5: ( assignment_element )+
            int cnt80=0;
            loop80:
            do {
                int alt80=2;
                int LA80_0 = input.LA(1);

                if ( (LA80_0==VAR_DECL||LA80_0==CALL||LA80_0==LIST_T) ) {
                    alt80=1;
                }


                switch (alt80) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1361:5: assignment_element
            	    {
            	    _last = (SLAST)input.LT(1);
            	    pushFollow(FOLLOW_assignment_element_in_assignment_list2977);
            	    assignment_element258=assignment_element();

            	    state._fsp--;

            	    adaptor.addChild(root_0, assignment_element258.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt80 >= 1 ) break loop80;
                        EarlyExitException eee =
                            new EarlyExitException(80, input);
                        throw eee;
                }
                cnt80++;
            } while (true);


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "assignment_list"

    public static class assignment_element_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "assignment_element"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1364:1: assignment_element : ( variable | ^( LIST_T ( assignment_list )? ) );
    public final TreePHP.assignment_element_return assignment_element() throws RecognitionException {
        TreePHP.assignment_element_return retval = new TreePHP.assignment_element_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST LIST_T260=null;
        TreePHP.variable_return variable259 = null;

        TreePHP.assignment_list_return assignment_list261 = null;


        SLAST LIST_T260_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1365:3: ( variable | ^( LIST_T ( assignment_list )? ) )
            int alt82=2;
            int LA82_0 = input.LA(1);

            if ( (LA82_0==VAR_DECL||LA82_0==CALL) ) {
                alt82=1;
            }
            else if ( (LA82_0==LIST_T) ) {
                alt82=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 82, 0, input);

                throw nvae;
            }
            switch (alt82) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1365:5: variable
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_variable_in_assignment_element2993);
                    variable259=variable();

                    state._fsp--;

                    adaptor.addChild(root_0, variable259.getTree());

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1366:5: ^( LIST_T ( assignment_list )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    LIST_T260=(SLAST)match(input,LIST_T,FOLLOW_LIST_T_in_assignment_element3000); 
                    LIST_T260_tree = (SLAST)adaptor.dupNode(LIST_T260);

                    root_1 = (SLAST)adaptor.becomeRoot(LIST_T260_tree, root_1);



                    if ( input.LA(1)==Token.DOWN ) {
                        match(input, Token.DOWN, null); 
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1366:14: ( assignment_list )?
                        int alt81=2;
                        int LA81_0 = input.LA(1);

                        if ( (LA81_0==VAR_DECL||LA81_0==CALL||LA81_0==LIST_T) ) {
                            alt81=1;
                        }
                        switch (alt81) {
                            case 1 :
                                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1366:14: assignment_list
                                {
                                _last = (SLAST)input.LT(1);
                                pushFollow(FOLLOW_assignment_list_in_assignment_element3002);
                                assignment_list261=assignment_list();

                                state._fsp--;

                                adaptor.addChild(root_1, assignment_list261.getTree());

                                }
                                break;

                        }


                        match(input, Token.UP, null); 
                    }adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "assignment_element"

    protected static class array_pair_list_scope {
        List list;
    }
    protected Stack array_pair_list_stack = new Stack();

    public static class array_pair_list_return extends TreeRuleReturnScope {
        public List arrayList;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "array_pair_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1369:1: array_pair_list returns [List arrayList] : ( array_pair_element )+ ;
    public final TreePHP.array_pair_list_return array_pair_list() throws RecognitionException {
        array_pair_list_stack.push(new array_pair_list_scope());
        TreePHP.array_pair_list_return retval = new TreePHP.array_pair_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.array_pair_element_return array_pair_element262 = null;




          ((array_pair_list_scope)array_pair_list_stack.peek()).list = new LinkedList();

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1376:3: ( ( array_pair_element )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1376:5: ( array_pair_element )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1376:5: ( array_pair_element )+
            int cnt83=0;
            loop83:
            do {
                int alt83=2;
                int LA83_0 = input.LA(1);

                if ( (LA83_0==METHOD_DECL||LA83_0==VAR_DECL||LA83_0==CALL||LA83_0==EXPR||(LA83_0>=SCALAR && LA83_0<=CAST_EXPR)||LA83_0==REF_T||LA83_0==ARROW_T||LA83_0==EQUAL_T||(LA83_0>=OR_T && LA83_0<=EXC_NOT_T)||(LA83_0>=INSTANCEOF_T && LA83_0<=BACKTRICKLITERAL)) ) {
                    alt83=1;
                }


                switch (alt83) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1376:5: array_pair_element
            	    {
            	    _last = (SLAST)input.LT(1);
            	    pushFollow(FOLLOW_array_pair_element_in_array_pair_list3032);
            	    array_pair_element262=array_pair_element();

            	    state._fsp--;

            	    adaptor.addChild(root_0, array_pair_element262.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt83 >= 1 ) break loop83;
                        EarlyExitException eee =
                            new EarlyExitException(83, input);
                        throw eee;
                }
                cnt83++;
            } while (true);


                retval.arrayList = ((array_pair_list_scope)array_pair_list_stack.peek()).list;
              

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
            array_pair_list_stack.pop();
        }
        return retval;
    }
    // $ANTLR end "array_pair_list"

    public static class array_pair_element_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "array_pair_element"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1382:1: array_pair_element : ( ^( ARROW_T e1= expression e2= expression ) | expression );
    public final TreePHP.array_pair_element_return array_pair_element() throws RecognitionException {
        TreePHP.array_pair_element_return retval = new TreePHP.array_pair_element_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST ARROW_T263=null;
        TreePHP.expression_return e1 = null;

        TreePHP.expression_return e2 = null;

        TreePHP.expression_return expression264 = null;


        SLAST ARROW_T263_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1383:3: ( ^( ARROW_T e1= expression e2= expression ) | expression )
            int alt84=2;
            int LA84_0 = input.LA(1);

            if ( (LA84_0==ARROW_T) ) {
                alt84=1;
            }
            else if ( (LA84_0==METHOD_DECL||LA84_0==VAR_DECL||LA84_0==CALL||LA84_0==EXPR||(LA84_0>=SCALAR && LA84_0<=CAST_EXPR)||LA84_0==REF_T||LA84_0==EQUAL_T||(LA84_0>=OR_T && LA84_0<=EXC_NOT_T)||(LA84_0>=INSTANCEOF_T && LA84_0<=BACKTRICKLITERAL)) ) {
                alt84=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 84, 0, input);

                throw nvae;
            }
            switch (alt84) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1383:5: ^( ARROW_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    ARROW_T263=(SLAST)match(input,ARROW_T,FOLLOW_ARROW_T_in_array_pair_element3053); 
                    ARROW_T263_tree = (SLAST)adaptor.dupNode(ARROW_T263);

                    root_1 = (SLAST)adaptor.becomeRoot(ARROW_T263_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_array_pair_element3057);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_array_pair_element3061);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = ((CommonToken)(e1!=null?((SLAST)e1.tree):null).token).getStartIndex();
                        int endIndex = ((CommonToken)(e2!=null?((SLAST)e2.tree):null).token).getStopIndex() + 1;
                        Expression key = (e1!=null?e1.expr:null);
                        Expression value = (e2!=null?e2.expr:null); 
                        ArrayElement element = new ArrayElement(startIndex, endIndex, key, value);
                        ((array_pair_list_scope)array_pair_list_stack.peek()).list.add(element);
                      

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1392:5: expression
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_array_pair_element3072);
                    expression264=expression();

                    state._fsp--;

                    adaptor.addChild(root_0, expression264.getTree());

                        int startIndex = ((CommonToken)(expression264!=null?((SLAST)expression264.tree):null).token).getStartIndex();
                        int endIndex = ((CommonToken)(expression264!=null?((SLAST)expression264.tree):null).token).getStopIndex() + 1;
                        Expression expr = (expression264!=null?expression264.expr:null);
                        ArrayElement element = new ArrayElement(startIndex, endIndex, expr);
                        ((array_pair_list_scope)array_pair_list_stack.peek()).list.add(element);
                      

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "array_pair_element"

    protected static class variable_scope {
        List list;
    }
    protected Stack variable_stack = new Stack();

    public static class variable_return extends TreeRuleReturnScope {
        public Expression expr;
        public Expression var;
        public PHPCallArgumentsList parameterList;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "variable"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1402:1: variable returns [Expression expr, Expression var, PHPCallArgumentsList parameterList] : variable_temp ;
    public final TreePHP.variable_return variable() throws RecognitionException {
        variable_stack.push(new variable_scope());
        TreePHP.variable_return retval = new TreePHP.variable_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.variable_temp_return variable_temp265 = null;




          ((variable_scope)variable_stack.peek()).list = new LinkedList();

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1409:3: ( variable_temp )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1409:5: variable_temp
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            pushFollow(FOLLOW_variable_temp_in_variable3107);
            variable_temp265=variable_temp();

            state._fsp--;

            adaptor.addChild(root_0, variable_temp265.getTree());

            //    retval.var = (variable_temp265!=null?variable_temp265.var:null);
            //    SimpleReference ref = new SimpleReference(99, 99, "ok");
            //    
            //    Expression var = (variable_temp265!=null?variable_temp265.expr:null);
            //    Expression memberProperty = (Expression)ref;
            //    
            //    PHPCallArgumentsList paramsList = new PHPCallArgumentsList();
            //    if ((variable_temp265!=null?variable_temp265.parameterList:null) != null) {
            //       paramsList = (variable_temp265!=null?variable_temp265.parameterList:null);
            //    }
            //    
            //    Iterator iter = ((variable_scope)variable_stack.peek()).list.iterator();
            //    while (iter.hasNext()) {
            //       Expression firstVarProperty = (Expression)iter.next();
            //	     if (paramsList == null) {
            //	        firstVarProperty = ref;
            //	     } else {
            //	       if (memberProperty.getClass().equals(SimpleReference.class)) {
            //	          firstVarProperty = new PHPCallExpression(99, 999, null, (SimpleReference)memberProperty, paramsList);
            //	       } else {
            //	          firstVarProperty = new ReflectionCallExpression(99, 999, null, memberProperty, paramsList);
            //	       }
            //	     }
            //	     iter.next();
            //    }
                
                Iterator iter = ((variable_scope)variable_stack.peek()).list.iterator();
                Expression dispatcher = (variable_temp265!=null?variable_temp265.var:null);
                iter = ((variable_scope)variable_stack.peek()).list.iterator();
                while (iter.hasNext()) {
                  Expression property = (Expression)iter.next();
                  dispatcher = createDispatch(dispatcher, property);
                }
                retval.expr = dispatcher;
                retval.var = dispatcher;
                System.out.println(retval.expr);
              

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
            variable_stack.pop();
        }
        return retval;
    }
    // $ANTLR end "variable"

    public static class variable_temp_return extends TreeRuleReturnScope {
        public Expression expr;
        public Expression var;
        public PHPCallArgumentsList parameterList;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "variable_temp"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1451:1: variable_temp returns [Expression expr, Expression var, PHPCallArgumentsList parameterList] : ( base_variable_with_function_calls | ^( CALL v1= variable_temp obj= object_property ( ctor_arguments )? ) );
    public final TreePHP.variable_temp_return variable_temp() throws RecognitionException {
        TreePHP.variable_temp_return retval = new TreePHP.variable_temp_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST CALL267=null;
        TreePHP.variable_temp_return v1 = null;

        TreePHP.object_property_return obj = null;

        TreePHP.base_variable_with_function_calls_return base_variable_with_function_calls266 = null;

        TreePHP.ctor_arguments_return ctor_arguments268 = null;


        SLAST CALL267_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1452:3: ( base_variable_with_function_calls | ^( CALL v1= variable_temp obj= object_property ( ctor_arguments )? ) )
            int alt86=2;
            int LA86_0 = input.LA(1);

            if ( (LA86_0==VAR_DECL) ) {
                alt86=1;
            }
            else if ( (LA86_0==CALL) ) {
                int LA86_2 = input.LA(2);

                if ( (LA86_2==DOWN) ) {
                    int LA86_3 = input.LA(3);

                    if ( (LA86_3==VAR_DECL||LA86_3==CALL) ) {
                        alt86=2;
                    }
                    else if ( (LA86_3==IDENTIFIER||LA86_3==DOMAIN_T) ) {
                        alt86=1;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 86, 3, input);

                        throw nvae;
                    }
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 86, 2, input);

                    throw nvae;
                }
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 86, 0, input);

                throw nvae;
            }
            switch (alt86) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1452:5: base_variable_with_function_calls
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_base_variable_with_function_calls_in_variable_temp3131);
                    base_variable_with_function_calls266=base_variable_with_function_calls();

                    state._fsp--;

                    adaptor.addChild(root_0, base_variable_with_function_calls266.getTree());

                         retval.expr = (base_variable_with_function_calls266!=null?base_variable_with_function_calls266.expr:null);
                         retval.var = (base_variable_with_function_calls266!=null?base_variable_with_function_calls266.var:null);
                         
                         retval.parameterList = (base_variable_with_function_calls266!=null?base_variable_with_function_calls266.parameterList:null);
                      

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1459:5: ^( CALL v1= variable_temp obj= object_property ( ctor_arguments )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    CALL267=(SLAST)match(input,CALL,FOLLOW_CALL_in_variable_temp3143); 
                    CALL267_tree = (SLAST)adaptor.dupNode(CALL267);

                    root_1 = (SLAST)adaptor.becomeRoot(CALL267_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_variable_temp_in_variable_temp3147);
                    v1=variable_temp();

                    state._fsp--;

                    adaptor.addChild(root_1, v1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_object_property_in_variable_temp3151);
                    obj=object_property();

                    state._fsp--;

                    adaptor.addChild(root_1, obj.getTree());
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1459:49: ( ctor_arguments )?
                    int alt85=2;
                    int LA85_0 = input.LA(1);

                    if ( (LA85_0==ARGU) ) {
                        alt85=1;
                    }
                    switch (alt85) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1459:49: ctor_arguments
                            {
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_ctor_arguments_in_variable_temp3153);
                            ctor_arguments268=ctor_arguments();

                            state._fsp--;

                            adaptor.addChild(root_1, ctor_arguments268.getTree());

                            }
                            break;

                    }


                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                          retval.var = (v1!=null?v1.var:null);
                          retval.expr = (v1!=null?v1.expr:null);
                          
                    //      System.out.println("$$retval.var: " + retval.var);
                          int objLeft = ((CommonToken)(obj!=null?((SLAST)obj.tree):null).token).getStartIndex();
                          int objRight = ((CommonToken)(obj!=null?((SLAST)obj.tree):null).token).getStopIndex();

                          Expression firstVarProperty = null;
                          if ((ctor_arguments268!=null?ctor_arguments268.argumentList:null) == null) {
                            firstVarProperty = (obj!=null?obj.expr:null);
                          }
                          else {
                            int paramListLeft = ((CommonToken)(ctor_arguments268!=null?((SLAST)ctor_arguments268.tree):null).token).getStartIndex();
                            int paramListRight = ((CommonToken)(ctor_arguments268!=null?((SLAST)ctor_arguments268.tree):null).token).getStopIndex();
                            if ((obj!=null?obj.simpleRef:null).getClass().equals(SimpleReference.class)) {
                    		      firstVarProperty = new PHPCallExpression(objLeft, paramListRight, null, (obj!=null?obj.simpleRef:null), (ctor_arguments268!=null?ctor_arguments268.argumentList:null));
                    		    } else {
                    		      firstVarProperty = new ReflectionCallExpression(objLeft, paramListRight, null, (SimpleReference)(obj!=null?obj.simpleRef:null), (ctor_arguments268!=null?ctor_arguments268.argumentList:null));
                    		    }
                          }
                          
                          ((variable_scope)variable_stack.peek()).list.add(firstVarProperty);
                      

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "variable_temp"

    public static class base_variable_with_function_calls_return extends TreeRuleReturnScope {
        public Expression expr;
        public Expression var;
        public PHPCallArgumentsList parameterList;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "base_variable_with_function_calls"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1486:1: base_variable_with_function_calls returns [Expression expr, Expression var, PHPCallArgumentsList parameterList] : ( ^( VAR_DECL ( fully_qualified_class_name )? object_property ( ctor_arguments )? ) | ^( CALL fully_qualified_class_name ctor_arguments ) );
    public final TreePHP.base_variable_with_function_calls_return base_variable_with_function_calls() throws RecognitionException {
        TreePHP.base_variable_with_function_calls_return retval = new TreePHP.base_variable_with_function_calls_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST VAR_DECL269=null;
        SLAST CALL273=null;
        TreePHP.fully_qualified_class_name_return fully_qualified_class_name270 = null;

        TreePHP.object_property_return object_property271 = null;

        TreePHP.ctor_arguments_return ctor_arguments272 = null;

        TreePHP.fully_qualified_class_name_return fully_qualified_class_name274 = null;

        TreePHP.ctor_arguments_return ctor_arguments275 = null;


        SLAST VAR_DECL269_tree=null;
        SLAST CALL273_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1487:3: ( ^( VAR_DECL ( fully_qualified_class_name )? object_property ( ctor_arguments )? ) | ^( CALL fully_qualified_class_name ctor_arguments ) )
            int alt89=2;
            int LA89_0 = input.LA(1);

            if ( (LA89_0==VAR_DECL) ) {
                alt89=1;
            }
            else if ( (LA89_0==CALL) ) {
                alt89=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 89, 0, input);

                throw nvae;
            }
            switch (alt89) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1487:5: ^( VAR_DECL ( fully_qualified_class_name )? object_property ( ctor_arguments )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    VAR_DECL269=(SLAST)match(input,VAR_DECL,FOLLOW_VAR_DECL_in_base_variable_with_function_calls3179); 
                    VAR_DECL269_tree = (SLAST)adaptor.dupNode(VAR_DECL269);

                    root_1 = (SLAST)adaptor.becomeRoot(VAR_DECL269_tree, root_1);



                    match(input, Token.DOWN, null); 
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1487:16: ( fully_qualified_class_name )?
                    int alt87=2;
                    int LA87_0 = input.LA(1);

                    if ( (LA87_0==IDENTIFIER||LA87_0==DOMAIN_T) ) {
                        alt87=1;
                    }
                    switch (alt87) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1487:16: fully_qualified_class_name
                            {
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_fully_qualified_class_name_in_base_variable_with_function_calls3181);
                            fully_qualified_class_name270=fully_qualified_class_name();

                            state._fsp--;

                            adaptor.addChild(root_1, fully_qualified_class_name270.getTree());

                            }
                            break;

                    }

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_object_property_in_base_variable_with_function_calls3184);
                    object_property271=object_property();

                    state._fsp--;

                    adaptor.addChild(root_1, object_property271.getTree());
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1487:60: ( ctor_arguments )?
                    int alt88=2;
                    int LA88_0 = input.LA(1);

                    if ( (LA88_0==ARGU) ) {
                        alt88=1;
                    }
                    switch (alt88) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1487:60: ctor_arguments
                            {
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_ctor_arguments_in_base_variable_with_function_calls3186);
                            ctor_arguments272=ctor_arguments();

                            state._fsp--;

                            adaptor.addChild(root_1, ctor_arguments272.getTree());

                            }
                            break;

                    }


                        int startIndex = VAR_DECL269.startIndex;
                        int endIndex = ((CommonToken)(object_property271!=null?((SLAST)object_property271.tree):null).token).getStopIndex();
                        retval.var = (object_property271!=null?object_property271.expr:null);
                        if ((fully_qualified_class_name270!=null?fully_qualified_class_name270.type:null) != null) {
                            retval.var = new StaticFieldAccess(startIndex, endIndex, (fully_qualified_class_name270!=null?fully_qualified_class_name270.type:null), (object_property271!=null?object_property271.expr:null));
                        }
                        System.out.println("var:" + retval.var);
                        retval.expr = retval.var;
                      
                        if ((ctor_arguments272!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(ctor_arguments272.start),
                      input.getTreeAdaptor().getTokenStopIndex(ctor_arguments272.start))):null) != null) {
                          PHPCallArgumentsList parameters = (ctor_arguments272!=null?ctor_arguments272.argumentList:null);
                          parameters.addNode(retval.var);
                          retval.parameterList = parameters;
                        }
                        else {
                          retval.parameterList = new PHPCallArgumentsList();
                        }
                      

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1508:5: ^( CALL fully_qualified_class_name ctor_arguments )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    CALL273=(SLAST)match(input,CALL,FOLLOW_CALL_in_base_variable_with_function_calls3207); 
                    CALL273_tree = (SLAST)adaptor.dupNode(CALL273);

                    root_1 = (SLAST)adaptor.becomeRoot(CALL273_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_fully_qualified_class_name_in_base_variable_with_function_calls3209);
                    fully_qualified_class_name274=fully_qualified_class_name();

                    state._fsp--;

                    adaptor.addChild(root_1, fully_qualified_class_name274.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_ctor_arguments_in_base_variable_with_function_calls3211);
                    ctor_arguments275=ctor_arguments();

                    state._fsp--;

                    adaptor.addChild(root_1, ctor_arguments275.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = CALL273.startIndex;
                        int endIndex = CALL273.endIndex + 1;
                        int functionNameLeft= ((CommonToken)(fully_qualified_class_name274!=null?((SLAST)fully_qualified_class_name274.tree):null).token).getStartIndex();
                        int functionNameRight= ((CommonToken)(fully_qualified_class_name274!=null?((SLAST)fully_qualified_class_name274.tree):null).token).getStopIndex() + 1;
                        String functionName = (fully_qualified_class_name274!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(fully_qualified_class_name274.start),
                      input.getTreeAdaptor().getTokenStopIndex(fully_qualified_class_name274.start))):null);
                        PHPCallArgumentsList parameters = (ctor_arguments275!=null?ctor_arguments275.argumentList:null);
                        System.out.println("fff:" + functionName + " " + parameters);
                        SimpleReference name = new SimpleReference(functionNameLeft, functionNameRight, functionName);
                        retval.var = new PHPCallExpression(startIndex, endIndex, null, name, parameters);
                    //    retval.var = (Expression)(fully_qualified_class_name274!=null?fully_qualified_class_name274.type:null);
                        retval.parameterList = parameters;
                      

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "base_variable_with_function_calls"

    public static class object_property_return extends TreeRuleReturnScope {
        public String str;
        public Expression expr;
        public SimpleReference simpleRef;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "object_property"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1526:1: object_property returns [String str, Expression expr, SimpleReference simpleRef] : ( ^( VAR ( DOLLAR_T )* IDENTIFIER ) | ^( VAR ( DOLLAR_T )* expression ) | ^( INDEX obj= object_property ( expression )? ) );
    public final TreePHP.object_property_return object_property() throws RecognitionException {
        TreePHP.object_property_return retval = new TreePHP.object_property_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST VAR276=null;
        SLAST DOLLAR_T277=null;
        SLAST IDENTIFIER278=null;
        SLAST VAR279=null;
        SLAST DOLLAR_T280=null;
        SLAST INDEX282=null;
        TreePHP.object_property_return obj = null;

        TreePHP.expression_return expression281 = null;

        TreePHP.expression_return expression283 = null;


        SLAST VAR276_tree=null;
        SLAST DOLLAR_T277_tree=null;
        SLAST IDENTIFIER278_tree=null;
        SLAST VAR279_tree=null;
        SLAST DOLLAR_T280_tree=null;
        SLAST INDEX282_tree=null;


          SLAST ast = null;
          int startIndex = -1;
          int endIndex = -1;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1538:3: ( ^( VAR ( DOLLAR_T )* IDENTIFIER ) | ^( VAR ( DOLLAR_T )* expression ) | ^( INDEX obj= object_property ( expression )? ) )
            int alt93=3;
            alt93 = dfa93.predict(input);
            switch (alt93) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1538:5: ^( VAR ( DOLLAR_T )* IDENTIFIER )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    VAR276=(SLAST)match(input,VAR,FOLLOW_VAR_in_object_property3250); 
                    VAR276_tree = (SLAST)adaptor.dupNode(VAR276);

                    root_1 = (SLAST)adaptor.becomeRoot(VAR276_tree, root_1);



                    match(input, Token.DOWN, null); 
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1538:11: ( DOLLAR_T )*
                    loop90:
                    do {
                        int alt90=2;
                        int LA90_0 = input.LA(1);

                        if ( (LA90_0==DOLLAR_T) ) {
                            alt90=1;
                        }


                        switch (alt90) {
                    	case 1 :
                    	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1538:11: DOLLAR_T
                    	    {
                    	    _last = (SLAST)input.LT(1);
                    	    DOLLAR_T277=(SLAST)match(input,DOLLAR_T,FOLLOW_DOLLAR_T_in_object_property3252); 
                    	    DOLLAR_T277_tree = (SLAST)adaptor.dupNode(DOLLAR_T277);

                    	    adaptor.addChild(root_1, DOLLAR_T277_tree);


                    	    }
                    	    break;

                    	default :
                    	    break loop90;
                        }
                    } while (true);

                    _last = (SLAST)input.LT(1);
                    IDENTIFIER278=(SLAST)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_object_property3255); 
                    IDENTIFIER278_tree = (SLAST)adaptor.dupNode(IDENTIFIER278);

                    adaptor.addChild(root_1, IDENTIFIER278_tree);


                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                            retval.str = (IDENTIFIER278!=null?IDENTIFIER278.getText():null);
                            startIndex = ((CommonToken)IDENTIFIER278.token).getStartIndex();
                            endIndex = ((CommonToken)IDENTIFIER278.token).getStopIndex() + 1;
                            if ((DOLLAR_T277!=null?DOLLAR_T277.getText():null) != null) {
                                retval.str = (DOLLAR_T277!=null?DOLLAR_T277.getText():null) + (IDENTIFIER278!=null?IDENTIFIER278.getText():null);
                                startIndex = ((CommonToken)DOLLAR_T277.token).getStartIndex();
                            }
                            VariableReference variableRef = new VariableReference(startIndex, endIndex, retval.str ,PHPVariableKind.LOCAL);
                            retval.expr = variableRef;
                            
                            retval.simpleRef = new SimpleReference(startIndex, endIndex, retval.str);
                            ast = VAR276_tree;
                    //        (((SLAST)retval.tree).token).setStartIndex(startInndex);
                        

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1554:5: ^( VAR ( DOLLAR_T )* expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    VAR279=(SLAST)match(input,VAR,FOLLOW_VAR_in_object_property3269); 
                    VAR279_tree = (SLAST)adaptor.dupNode(VAR279);

                    root_1 = (SLAST)adaptor.becomeRoot(VAR279_tree, root_1);



                    match(input, Token.DOWN, null); 
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1554:11: ( DOLLAR_T )*
                    loop91:
                    do {
                        int alt91=2;
                        int LA91_0 = input.LA(1);

                        if ( (LA91_0==DOLLAR_T) ) {
                            alt91=1;
                        }


                        switch (alt91) {
                    	case 1 :
                    	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1554:11: DOLLAR_T
                    	    {
                    	    _last = (SLAST)input.LT(1);
                    	    DOLLAR_T280=(SLAST)match(input,DOLLAR_T,FOLLOW_DOLLAR_T_in_object_property3271); 
                    	    DOLLAR_T280_tree = (SLAST)adaptor.dupNode(DOLLAR_T280);

                    	    adaptor.addChild(root_1, DOLLAR_T280_tree);


                    	    }
                    	    break;

                    	default :
                    	    break loop91;
                        }
                    } while (true);

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_object_property3274);
                    expression281=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression281.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        startIndex = VAR279.startIndex;
                        endIndex = VAR279.endIndex;
                        retval.expr = new ReflectionVariableReference(startIndex, endIndex, (expression281!=null?expression281.expr:null));
                        System.out.println("**" + retval.expr);
                      

                    }
                    break;
                case 3 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1561:5: ^( INDEX obj= object_property ( expression )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    INDEX282=(SLAST)match(input,INDEX,FOLLOW_INDEX_in_object_property3286); 
                    INDEX282_tree = (SLAST)adaptor.dupNode(INDEX282);

                    root_1 = (SLAST)adaptor.becomeRoot(INDEX282_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_object_property_in_object_property3290);
                    obj=object_property();

                    state._fsp--;

                    adaptor.addChild(root_1, obj.getTree());
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1561:33: ( expression )?
                    int alt92=2;
                    int LA92_0 = input.LA(1);

                    if ( (LA92_0==METHOD_DECL||LA92_0==VAR_DECL||LA92_0==CALL||LA92_0==EXPR||(LA92_0>=SCALAR && LA92_0<=CAST_EXPR)||LA92_0==REF_T||LA92_0==EQUAL_T||(LA92_0>=OR_T && LA92_0<=EXC_NOT_T)||(LA92_0>=INSTANCEOF_T && LA92_0<=BACKTRICKLITERAL)) ) {
                        alt92=1;
                    }
                    switch (alt92) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1561:33: expression
                            {
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_expression_in_object_property3292);
                            expression283=expression();

                            state._fsp--;

                            adaptor.addChild(root_1, expression283.getTree());

                            }
                            break;

                    }


                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        startIndex = INDEX282.startIndex;
                        endIndex = INDEX282.endIndex + 1;
                       
                        if (startIndex == 0 && (expression283!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(expression283.start),
                      input.getTreeAdaptor().getTokenStopIndex(expression283.start))):null) != null) {
                           startIndex = (obj!=null?((SLAST)obj.tree):null).startIndex;
                           endIndex = (obj!=null?((SLAST)obj.tree):null).endIndex + (expression283!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(expression283.start),
                      input.getTreeAdaptor().getTokenStopIndex(expression283.start))):null).length();
                        }
                        Expression varName = (obj!=null?obj.expr:null);
                        Expression index = (expression283!=null?expression283.expr:null);
                        if ((expression283!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(expression283.start),
                      input.getTreeAdaptor().getTokenStopIndex(expression283.start))):null) != null) {
                    	    if(varName.getKind() == ExpressionConstants.E_IDENTIFIER) {
                    	       retval.expr = new ArrayVariableReference(startIndex, endIndex, ((SimpleReference)varName).getName(), index, ArrayVariableReference.VARIABLE_ARRAY);
                    	    } else {
                    	       retval.expr = new ReflectionArrayVariableReference(startIndex, endIndex, varName, index, ReflectionArrayVariableReference.VARIABLE_ARRAY);
                    	    }
                    	  }
                    	  else {
                    	     retval.expr = new ArrayVariableReference(startIndex, endIndex, ((SimpleReference)varName).getName(), index, ArrayVariableReference.VARIABLE_ARRAY);
                    	  }
                        ast = INDEX282_tree;
                      

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);


              if (ast != null) {
                retval.tree = ast;
              }
              ((SLAST)retval.tree).setIndex(startIndex, endIndex);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "object_property"

    public static class ctor_arguments_return extends TreeRuleReturnScope {
        public PHPCallArgumentsList argumentList;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "ctor_arguments"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1586:1: ctor_arguments returns [PHPCallArgumentsList argumentList] : ^( ARGU ( expr_list )? ) ;
    public final TreePHP.ctor_arguments_return ctor_arguments() throws RecognitionException {
        TreePHP.ctor_arguments_return retval = new TreePHP.ctor_arguments_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST ARGU284=null;
        TreePHP.expr_list_return expr_list285 = null;


        SLAST ARGU284_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1587:3: ( ^( ARGU ( expr_list )? ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1587:6: ^( ARGU ( expr_list )? )
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_1 = _last;
            SLAST _first_1 = null;
            SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            ARGU284=(SLAST)match(input,ARGU,FOLLOW_ARGU_in_ctor_arguments3321); 
            ARGU284_tree = (SLAST)adaptor.dupNode(ARGU284);

            root_1 = (SLAST)adaptor.becomeRoot(ARGU284_tree, root_1);



            if ( input.LA(1)==Token.DOWN ) {
                match(input, Token.DOWN, null); 
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1587:13: ( expr_list )?
                int alt94=2;
                int LA94_0 = input.LA(1);

                if ( (LA94_0==METHOD_DECL||LA94_0==VAR_DECL||LA94_0==CALL||LA94_0==EXPR||(LA94_0>=SCALAR && LA94_0<=CAST_EXPR)||LA94_0==REF_T||LA94_0==EQUAL_T||(LA94_0>=OR_T && LA94_0<=EXC_NOT_T)||(LA94_0>=INSTANCEOF_T && LA94_0<=BACKTRICKLITERAL)) ) {
                    alt94=1;
                }
                switch (alt94) {
                    case 1 :
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1587:13: expr_list
                        {
                        _last = (SLAST)input.LT(1);
                        pushFollow(FOLLOW_expr_list_in_ctor_arguments3323);
                        expr_list285=expr_list();

                        state._fsp--;

                        adaptor.addChild(root_1, expr_list285.getTree());

                        }
                        break;

                }


                match(input, Token.UP, null); 
            }adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


                int startIndex = ARGU284.startIndex;
                int endIndex = ARGU284.endIndex + 1;

            	  retval.argumentList = new PHPCallArgumentsList();
            	  retval.argumentList.setStart(startIndex);
            	  retval.argumentList.setEnd(endIndex);
            	  
            	  if ((expr_list285!=null?expr_list285.exprList:null) != null) {
            	    Iterator iter = (expr_list285!=null?expr_list285.exprList:null).iterator();
            	    while (iter.hasNext()) {
            	      retval.argumentList.addNode((Expression)iter.next());
            	    }
            	  }
              

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "ctor_arguments"

    public static class pure_variable_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "pure_variable"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1605:1: pure_variable : ^( VAR_DECL ( REF_T )? ( DOLLAR_T )+ IDENTIFIER ) ;
    public final TreePHP.pure_variable_return pure_variable() throws RecognitionException {
        TreePHP.pure_variable_return retval = new TreePHP.pure_variable_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST VAR_DECL286=null;
        SLAST REF_T287=null;
        SLAST DOLLAR_T288=null;
        SLAST IDENTIFIER289=null;

        SLAST VAR_DECL286_tree=null;
        SLAST REF_T287_tree=null;
        SLAST DOLLAR_T288_tree=null;
        SLAST IDENTIFIER289_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1606:3: ( ^( VAR_DECL ( REF_T )? ( DOLLAR_T )+ IDENTIFIER ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1606:5: ^( VAR_DECL ( REF_T )? ( DOLLAR_T )+ IDENTIFIER )
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_1 = _last;
            SLAST _first_1 = null;
            SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            VAR_DECL286=(SLAST)match(input,VAR_DECL,FOLLOW_VAR_DECL_in_pure_variable3345); 
            VAR_DECL286_tree = (SLAST)adaptor.dupNode(VAR_DECL286);

            root_1 = (SLAST)adaptor.becomeRoot(VAR_DECL286_tree, root_1);



            match(input, Token.DOWN, null); 
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1606:16: ( REF_T )?
            int alt95=2;
            int LA95_0 = input.LA(1);

            if ( (LA95_0==REF_T) ) {
                alt95=1;
            }
            switch (alt95) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1606:16: REF_T
                    {
                    _last = (SLAST)input.LT(1);
                    REF_T287=(SLAST)match(input,REF_T,FOLLOW_REF_T_in_pure_variable3347); 
                    REF_T287_tree = (SLAST)adaptor.dupNode(REF_T287);

                    adaptor.addChild(root_1, REF_T287_tree);


                    }
                    break;

            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1606:23: ( DOLLAR_T )+
            int cnt96=0;
            loop96:
            do {
                int alt96=2;
                int LA96_0 = input.LA(1);

                if ( (LA96_0==DOLLAR_T) ) {
                    alt96=1;
                }


                switch (alt96) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1606:23: DOLLAR_T
            	    {
            	    _last = (SLAST)input.LT(1);
            	    DOLLAR_T288=(SLAST)match(input,DOLLAR_T,FOLLOW_DOLLAR_T_in_pure_variable3350); 
            	    DOLLAR_T288_tree = (SLAST)adaptor.dupNode(DOLLAR_T288);

            	    adaptor.addChild(root_1, DOLLAR_T288_tree);


            	    }
            	    break;

            	default :
            	    if ( cnt96 >= 1 ) break loop96;
                        EarlyExitException eee =
                            new EarlyExitException(96, input);
                        throw eee;
                }
                cnt96++;
            } while (true);

            _last = (SLAST)input.LT(1);
            IDENTIFIER289=(SLAST)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_pure_variable3353); 
            IDENTIFIER289_tree = (SLAST)adaptor.dupNode(IDENTIFIER289);

            adaptor.addChild(root_1, IDENTIFIER289_tree);


            match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "pure_variable"

    public static class scalar_return extends TreeRuleReturnScope {
        public Expression expr;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "scalar"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1609:1: scalar returns [Expression expr] : ^( SCALAR constant ) ;
    public final TreePHP.scalar_return scalar() throws RecognitionException {
        TreePHP.scalar_return retval = new TreePHP.scalar_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST SCALAR290=null;
        TreePHP.constant_return constant291 = null;


        SLAST SCALAR290_tree=null;


          SLAST ast = null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1616:3: ( ^( SCALAR constant ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1616:5: ^( SCALAR constant )
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_1 = _last;
            SLAST _first_1 = null;
            SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            SCALAR290=(SLAST)match(input,SCALAR,FOLLOW_SCALAR_in_scalar3384); 
            SCALAR290_tree = (SLAST)adaptor.dupNode(SCALAR290);

            root_1 = (SLAST)adaptor.becomeRoot(SCALAR290_tree, root_1);



            match(input, Token.DOWN, null); 
            _last = (SLAST)input.LT(1);
            pushFollow(FOLLOW_constant_in_scalar3386);
            constant291=constant();

            state._fsp--;

            adaptor.addChild(root_1, constant291.getTree());

            match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


                if ((constant291!=null?constant291.expr:null) != null ) {
                  retval.expr = (constant291!=null?constant291.expr:null);
                }
                else {
                  retval.expr = (constant291!=null?constant291.scalar:null);
                }
                ast = (constant291!=null?((SLAST)constant291.tree):null);
              

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);


              retval.tree = ast;

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "scalar"

    public static class constant_return extends TreeRuleReturnScope {
        public Scalar scalar;
        public Expression expr;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "constant"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1628:1: constant returns [Scalar scalar, Expression expr] : ( INTLITERAL | FLOATLITERAL | STRINGLITERAL | DOUBLELITERRAL | common_scalar | IDENTIFIER | fully_qualified_class_name );
    public final TreePHP.constant_return constant() throws RecognitionException {
        TreePHP.constant_return retval = new TreePHP.constant_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST INTLITERAL292=null;
        SLAST FLOATLITERAL293=null;
        SLAST STRINGLITERAL294=null;
        SLAST DOUBLELITERRAL295=null;
        SLAST IDENTIFIER297=null;
        TreePHP.common_scalar_return common_scalar296 = null;

        TreePHP.fully_qualified_class_name_return fully_qualified_class_name298 = null;


        SLAST INTLITERAL292_tree=null;
        SLAST FLOATLITERAL293_tree=null;
        SLAST STRINGLITERAL294_tree=null;
        SLAST DOUBLELITERRAL295_tree=null;
        SLAST IDENTIFIER297_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1629:3: ( INTLITERAL | FLOATLITERAL | STRINGLITERAL | DOUBLELITERRAL | common_scalar | IDENTIFIER | fully_qualified_class_name )
            int alt97=7;
            switch ( input.LA(1) ) {
            case INTLITERAL:
                {
                alt97=1;
                }
                break;
            case FLOATLITERAL:
                {
                alt97=2;
                }
                break;
            case STRINGLITERAL:
                {
                alt97=3;
                }
                break;
            case DOUBLELITERRAL:
                {
                alt97=4;
                }
                break;
            case 177:
            case 178:
            case 179:
            case 180:
            case 181:
            case 182:
                {
                alt97=5;
                }
                break;
            case IDENTIFIER:
                {
                alt97=6;
                }
                break;
            case DOMAIN_T:
                {
                alt97=7;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 97, 0, input);

                throw nvae;
            }

            switch (alt97) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1629:7: INTLITERAL
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    INTLITERAL292=(SLAST)match(input,INTLITERAL,FOLLOW_INTLITERAL_in_constant3412); 
                    INTLITERAL292_tree = (SLAST)adaptor.dupNode(INTLITERAL292);

                    adaptor.addChild(root_0, INTLITERAL292_tree);


                        CommonToken token = (CommonToken)INTLITERAL292.token;
                        int startIndex = token.getStartIndex();
                        int endIndex = token.getStopIndex() + 1;
                        retval.scalar = new Scalar(startIndex, endIndex, (INTLITERAL292!=null?INTLITERAL292.getText():null), Scalar.TYPE_INT);
                      

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1636:7: FLOATLITERAL
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    FLOATLITERAL293=(SLAST)match(input,FLOATLITERAL,FOLLOW_FLOATLITERAL_in_constant3424); 
                    FLOATLITERAL293_tree = (SLAST)adaptor.dupNode(FLOATLITERAL293);

                    adaptor.addChild(root_0, FLOATLITERAL293_tree);


                    }
                    break;
                case 3 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1637:7: STRINGLITERAL
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    STRINGLITERAL294=(SLAST)match(input,STRINGLITERAL,FOLLOW_STRINGLITERAL_in_constant3432); 
                    STRINGLITERAL294_tree = (SLAST)adaptor.dupNode(STRINGLITERAL294);

                    adaptor.addChild(root_0, STRINGLITERAL294_tree);


                        CommonToken token = (CommonToken)STRINGLITERAL294.token;
                        int startIndex = token.getStartIndex();
                        int endIndex = token.getStopIndex() + 1;
                        retval.scalar = new Scalar(startIndex, endIndex, (STRINGLITERAL294!=null?STRINGLITERAL294.getText():null), Scalar.TYPE_STRING);
                      

                    }
                    break;
                case 4 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1644:7: DOUBLELITERRAL
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    DOUBLELITERRAL295=(SLAST)match(input,DOUBLELITERRAL,FOLLOW_DOUBLELITERRAL_in_constant3444); 
                    DOUBLELITERRAL295_tree = (SLAST)adaptor.dupNode(DOUBLELITERRAL295);

                    adaptor.addChild(root_0, DOUBLELITERRAL295_tree);


                    }
                    break;
                case 5 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1645:7: common_scalar
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_common_scalar_in_constant3452);
                    common_scalar296=common_scalar();

                    state._fsp--;

                    adaptor.addChild(root_0, common_scalar296.getTree());

                    }
                    break;
                case 6 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1646:7: IDENTIFIER
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    IDENTIFIER297=(SLAST)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_constant3460); 
                    IDENTIFIER297_tree = (SLAST)adaptor.dupNode(IDENTIFIER297);

                    adaptor.addChild(root_0, IDENTIFIER297_tree);


                          CommonToken token = (CommonToken)IDENTIFIER297.token;
                    	    int startIndex = token.getStartIndex();
                    	    int endIndex = token.getStopIndex() + 1;
                    	    retval.scalar = new Scalar(startIndex, endIndex, (IDENTIFIER297!=null?IDENTIFIER297.getText():null), Scalar.TYPE_STRING);
                      

                    }
                    break;
                case 7 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1653:7: fully_qualified_class_name
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_fully_qualified_class_name_in_constant3472);
                    fully_qualified_class_name298=fully_qualified_class_name();

                    state._fsp--;

                    adaptor.addChild(root_0, fully_qualified_class_name298.getTree());

                     //   retval.expr = (fully_qualified_class_name298!=null?fully_qualified_class_name298.constant:null);
                          retval.expr = (fully_qualified_class_name298!=null?fully_qualified_class_name298.type:null);
                      

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "constant"

    public static class common_scalar_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "common_scalar"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1660:1: common_scalar : ( '__CLASS__' | '__DIR__' | '__FILE__' | '__FUNCTION__' | '__METHOD__' | '__NAMESPACE__' );
    public final TreePHP.common_scalar_return common_scalar() throws RecognitionException {
        TreePHP.common_scalar_return retval = new TreePHP.common_scalar_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST set299=null;

        SLAST set299_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1661:3: ( '__CLASS__' | '__DIR__' | '__FILE__' | '__FUNCTION__' | '__METHOD__' | '__NAMESPACE__' )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            set299=(SLAST)input.LT(1);
            if ( (input.LA(1)>=177 && input.LA(1)<=182) ) {
                input.consume();

                set299_tree = (SLAST)adaptor.dupNode(set299);

                adaptor.addChild(root_0, set299_tree);

                state.errorRecovery=false;
            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                throw mse;
            }

             

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "common_scalar"

    // Delegated rules


    protected DFA71 dfa71 = new DFA71(this);
    protected DFA93 dfa93 = new DFA93(this);
    static final String DFA71_eotS =
        "\70\uffff";
    static final String DFA71_eofS =
        "\70\uffff";
    static final String DFA71_minS =
        "\1\11\54\uffff\1\15\12\uffff";
    static final String DFA71_maxS =
        "\1\u008a\54\uffff\1\44\12\uffff";
    static final String DFA71_acceptS =
        "\1\uffff\1\1\1\2\1\3\1\4\1\5\1\6\1\7\1\10\1\11\1\12\1\13\1\14\1"+
        "\15\1\16\1\17\1\20\1\21\1\22\1\23\1\24\1\25\1\26\1\27\1\30\1\31"+
        "\1\32\1\33\1\34\1\35\1\36\1\37\1\40\1\41\1\42\1\43\1\44\1\45\1\46"+
        "\1\47\1\50\1\51\1\52\1\53\1\54\1\uffff\1\55\1\56\1\57\1\60\1\61"+
        "\1\62\1\63\1\64\1\65\1\66";
    static final String DFA71_specialS =
        "\70\uffff}>";
    static final String[] DFA71_transitionS = {
            "\1\66\3\uffff\1\56\5\uffff\1\56\1\uffff\1\1\16\uffff\1\57\1"+
            "\61\1\53\1\52\1\47\17\uffff\1\26\25\uffff\1\5\15\uffff\1\2\1"+
            "\3\1\4\1\6\1\7\1\10\1\11\1\12\1\13\1\14\1\15\1\16\1\17\1\20"+
            "\1\21\1\22\1\23\1\24\1\25\1\27\1\30\1\31\1\32\1\33\1\34\1\35"+
            "\1\36\1\37\1\40\1\41\1\42\1\43\1\44\1\45\1\46\1\65\1\63\1\50"+
            "\1\51\2\uffff\1\54\1\55\1\60\1\62\1\64\1\67",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\1\56\5\uffff\1\56\20\uffff\1\57",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA71_eot = DFA.unpackEncodedString(DFA71_eotS);
    static final short[] DFA71_eof = DFA.unpackEncodedString(DFA71_eofS);
    static final char[] DFA71_min = DFA.unpackEncodedStringToUnsignedChars(DFA71_minS);
    static final char[] DFA71_max = DFA.unpackEncodedStringToUnsignedChars(DFA71_maxS);
    static final short[] DFA71_accept = DFA.unpackEncodedString(DFA71_acceptS);
    static final short[] DFA71_special = DFA.unpackEncodedString(DFA71_specialS);
    static final short[][] DFA71_transition;

    static {
        int numStates = DFA71_transitionS.length;
        DFA71_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA71_transition[i] = DFA.unpackEncodedString(DFA71_transitionS[i]);
        }
    }

    class DFA71 extends DFA {

        public DFA71(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 71;
            this.eot = DFA71_eot;
            this.eof = DFA71_eof;
            this.min = DFA71_min;
            this.max = DFA71_max;
            this.accept = DFA71_accept;
            this.special = DFA71_special;
            this.transition = DFA71_transition;
        }
        public String getDescription() {
            return "860:1: expression returns [Expression expr] : ( ^( EXPR etop= expression ) | ^( OR_T e1= expression e2= expression ) | ^( XOR_T e1= expression e2= expression ) | ^( AND_T e1= expression e2= expression ) | ^( EQUAL_T e1= expression e2= expression ) | ^( PLUS_EQ e1= expression e2= expression ) | ^( MINUS_EQ e1= expression e2= expression ) | ^( MUL_EQ e1= expression e2= expression ) | ^( DIV_EQ e1= expression e2= expression ) | ^( DOT_EQ e1= expression e2= expression ) | ^( PERCENT_EQ e1= expression e2= expression ) | ^( BIT_AND_EQ e1= expression e2= expression ) | ^( BIT_OR_EQ e1= expression e2= expression ) | ^( POWER_EQ e1= expression e2= expression ) | ^( LMOVE_EQ e1= expression e2= expression ) | ^( RMOVE_EQ e1= expression e2= expression ) | ^( QUESTION_T e1= expression ^( COLON_T e2= expression e3= expression ) ) | ^( LOGICAL_OR_T e1= expression e2= expression ) | ^( LOGICAL_AND_T e1= expression e2= expression ) | ^( BIT_OR_T e1= expression e2= expression ) | ^( POWER_T expression expression ) | ^( REF_T e1= expression e2= expression ) | ^( DOT_T e1= expression e2= expression ) | ^( EQUAL_EQUAL_T e1= expression e2= expression ) | ^( NOT_EQUAL_T e1= expression e2= expression ) | ^( EQUAL_EQUAL_EQUAL_T e1= expression e2= expression ) | ^( NOT_EQUAL_EQUAL_T e1= expression e2= expression ) | ^( LT_T e1= expression e2= expression ) | ^( MT_T e1= expression e2= expression ) | ^( LE_T e1= expression e2= expression ) | ^( ME_T expression expression ) | ^( LSHIFT_T e1= expression e2= expression ) | ^( RSHIFT_T e1= expression e2= expression ) | ^( PLUS_T e1= expression e2= expression ) | ^( MINUS_T e1= expression e2= expression ) | ^( MUL_T e1= expression e2= expression ) | ^( DIV_T e1= expression e2= expression ) | ^( PERCENT_T e1= expression e2= expression ) | ^( CAST_EXPR cast_option e= expression ) | ^( TILDA_T e= expression ) | ^( EXC_NOT_T expression ) | ^( POSTFIX_EXPR e= expression plus_minus ) | ^( PREFIX_EXPR ( plus_minus )+ e= expression ) | ^( INSTANCEOF_T expression class_name_reference ) | ( AT_T )? variable | ( AT_T )? scalar | ^( LIST_T ( assignment_list )? ) | ^( ARRAY_DECL ( array_pair_list )? ) | ^( NEW_T class_name_reference ) | ^( CLONE_T variable ) | ^( EXIT_T ( expression )? ) | ^( UNSET_T variable ) | lambda_function_declaration | BACKTRICKLITERAL );";
        }
    }
    static final String DFA93_eotS =
        "\7\uffff";
    static final String DFA93_eofS =
        "\7\uffff";
    static final String DFA93_minS =
        "\1\21\1\2\1\uffff\2\11\2\uffff";
    static final String DFA93_maxS =
        "\1\51\1\2\1\uffff\2\u008e\2\uffff";
    static final String DFA93_acceptS =
        "\2\uffff\1\3\2\uffff\1\2\1\1";
    static final String DFA93_specialS =
        "\7\uffff}>";
    static final String[] DFA93_transitionS = {
            "\1\2\27\uffff\1\1",
            "\1\3",
            "",
            "\1\5\3\uffff\1\5\5\uffff\1\5\1\uffff\1\5\16\uffff\5\5\10\uffff"+
            "\1\6\6\uffff\1\5\25\uffff\1\5\15\uffff\47\5\2\uffff\6\5\3\uffff"+
            "\1\4",
            "\1\5\3\uffff\1\5\5\uffff\1\5\1\uffff\1\5\16\uffff\5\5\10\uffff"+
            "\1\6\6\uffff\1\5\25\uffff\1\5\15\uffff\47\5\2\uffff\6\5\3\uffff"+
            "\1\4",
            "",
            ""
    };

    static final short[] DFA93_eot = DFA.unpackEncodedString(DFA93_eotS);
    static final short[] DFA93_eof = DFA.unpackEncodedString(DFA93_eofS);
    static final char[] DFA93_min = DFA.unpackEncodedStringToUnsignedChars(DFA93_minS);
    static final char[] DFA93_max = DFA.unpackEncodedStringToUnsignedChars(DFA93_maxS);
    static final short[] DFA93_accept = DFA.unpackEncodedString(DFA93_acceptS);
    static final short[] DFA93_special = DFA.unpackEncodedString(DFA93_specialS);
    static final short[][] DFA93_transition;

    static {
        int numStates = DFA93_transitionS.length;
        DFA93_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA93_transition[i] = DFA.unpackEncodedString(DFA93_transitionS[i]);
        }
    }

    class DFA93 extends DFA {

        public DFA93(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 93;
            this.eot = DFA93_eot;
            this.eof = DFA93_eof;
            this.min = DFA93_min;
            this.max = DFA93_max;
            this.accept = DFA93_accept;
            this.special = DFA93_special;
            this.transition = DFA93_transition;
        }
        public String getDescription() {
            return "1526:1: object_property returns [String str, Expression expr, SimpleReference simpleRef] : ( ^( VAR ( DOLLAR_T )* IDENTIFIER ) | ^( VAR ( DOLLAR_T )* expression ) | ^( INDEX obj= object_property ( expression )? ) );";
        }
    }
 

    public static final BitSet FOLLOW_ModuleDeclaration_in_php_source58 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_top_statement_list_in_php_source60 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_top_statement_in_top_statement_list80 = new BitSet(new long[]{0x00C1000000004002L,0x0000000000000000L,0x0000000200000000L});
    public static final BitSet FOLLOW_statement_in_top_statement94 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_function_declaration_statement_in_top_statement104 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_class_declaration_statement_in_top_statement110 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_halt_compiler_statement_in_top_statement120 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_inner_statement_in_inner_statement_list147 = new BitSet(new long[]{0x00C1000000004002L,0x0000000000000000L,0x0000000200000000L});
    public static final BitSet FOLLOW_statement_in_inner_statement169 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_function_declaration_statement_in_inner_statement179 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_class_declaration_statement_in_inner_statement185 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_halt_compiler_statement_in_inner_statement191 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_161_in_halt_compiler_statement206 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_CLASS_T_in_class_declaration_statement226 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_class_entr_type_in_class_declaration_statement228 = new BitSet(new long[]{0x0002000000000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_class_declaration_statement231 = new BitSet(new long[]{0x000C000000000088L});
    public static final BitSet FOLLOW_EXTENDS_T_in_class_declaration_statement245 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_fully_qualified_class_name_in_class_declaration_statement247 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_IMPLEMENTS_T_in_class_declaration_statement254 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_fully_qualified_class_name_list_in_class_declaration_statement256 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_CLASS_BODY_in_class_declaration_statement269 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_class_statement_list_in_class_declaration_statement271 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_INTERFACE_T_in_class_declaration_statement288 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_IDENTIFIER_in_class_declaration_statement290 = new BitSet(new long[]{0x000C000000000088L});
    public static final BitSet FOLLOW_EXTENDS_T_in_class_declaration_statement294 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_fully_qualified_class_name_list_in_class_declaration_statement296 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_IMPLEMENTS_T_in_class_declaration_statement303 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_fully_qualified_class_name_list_in_class_declaration_statement305 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_CLASS_BODY_in_class_declaration_statement318 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_class_statement_list_in_class_declaration_statement320 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_set_in_class_entr_type0 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_class_statement_in_class_statement_list360 = new BitSet(new long[]{0x0000000000000302L});
    public static final BitSet FOLLOW_FIELD_DECL_in_class_statement385 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_variable_modifiers_in_class_statement389 = new BitSet(new long[]{0x0000000000002000L,0x0000000000004000L});
    public static final BitSet FOLLOW_static_var_element_in_class_statement391 = new BitSet(new long[]{0x0000000000002008L,0x0000000000004000L});
    public static final BitSet FOLLOW_METHOD_DECL_in_class_statement406 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_modifier_in_class_statement408 = new BitSet(new long[]{0x0102000000000000L});
    public static final BitSet FOLLOW_REF_T_in_class_statement410 = new BitSet(new long[]{0x0002000000000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_class_statement413 = new BitSet(new long[]{0x0000000800001800L});
    public static final BitSet FOLLOW_parameter_list_in_class_statement427 = new BitSet(new long[]{0x0000000800001000L});
    public static final BitSet FOLLOW_block_in_class_statement443 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_EMPTYSTATEMENT_in_class_statement462 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_FIELD_DECL_in_class_statement485 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_CONST_T_in_class_statement489 = new BitSet(new long[]{0x0000000000000000L,0x0000000000004000L});
    public static final BitSet FOLLOW_directive_in_class_statement491 = new BitSet(new long[]{0x0000000000000008L,0x0000000000004000L});
    public static final BitSet FOLLOW_FUNCTION_T_in_function_declaration_statement513 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_REF_T_in_function_declaration_statement515 = new BitSet(new long[]{0x0002000000000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_function_declaration_statement518 = new BitSet(new long[]{0x0000000000001800L});
    public static final BitSet FOLLOW_parameter_list_in_function_declaration_statement520 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_block_in_function_declaration_statement523 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_BLOCK_in_block543 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_inner_statement_list_in_block545 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_STATEMENT_in_statement581 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_topStatement_in_statement583 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_block_in_topStatement609 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_if_stat_in_topStatement620 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_WHILE_T_in_topStatement631 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_CONDITION_in_topStatement634 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_topStatement638 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_while_statement_in_topStatement641 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_DO_T_in_topStatement656 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_CONDITION_in_topStatement659 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_topStatement663 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_statement_in_topStatement666 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_FOR_T_in_topStatement678 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_list_in_topStatement682 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_CONDITION_in_topStatement686 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_list_in_topStatement690 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_ITERATE_in_topStatement695 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_list_in_topStatement699 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_for_statement_in_topStatement705 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_SWITCH_T_in_topStatement717 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_CONDITION_in_topStatement720 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_topStatement722 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_switch_case_list_in_topStatement725 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_BREAK_T_in_topStatement733 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_topStatement735 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_CONTINUE_T_in_topStatement748 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_topStatement752 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_RETURN_T_in_topStatement765 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_topStatement769 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_GLOBAL_T_in_topStatement782 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_variable_in_topStatement784 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_STATIC_T_in_topStatement792 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_static_var_list_in_topStatement794 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_ECHO_T_in_topStatement806 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_list_in_topStatement808 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_EMPTYSTATEMENT_in_topStatement820 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_SEMI_COLON_in_topStatement822 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_expression_in_topStatement833 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_FOREACH_T_in_topStatement844 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_AS_T_in_topStatement847 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_topStatement851 = new BitSet(new long[]{0x0100000000082000L});
    public static final BitSet FOLLOW_foreach_variable_in_topStatement855 = new BitSet(new long[]{0x0100000000082008L});
    public static final BitSet FOLLOW_foreach_variable_in_topStatement859 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_foreach_statement_in_topStatement863 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_DECLARE_T_in_topStatement882 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_directive_in_topStatement884 = new BitSet(new long[]{0x00C1000000004008L,0x0000000000000000L,0x0000000200000000L});
    public static final BitSet FOLLOW_declare_statement_in_topStatement886 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_TRY_T_in_topStatement899 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_BLOCK_in_topStatement902 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_top_statement_in_topStatement904 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_catch_branch_in_topStatement907 = new BitSet(new long[]{0x0000000000000008L,0x0000000000800000L});
    public static final BitSet FOLLOW_THROW_T_in_topStatement916 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_topStatement918 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_USE_T_in_topStatement926 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_use_filename_in_topStatement928 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_REF_T_in_foreach_variable954 = new BitSet(new long[]{0x0100000000082000L});
    public static final BitSet FOLLOW_variable_in_foreach_variable957 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_STRINGLITERAL_in_use_filename976 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_METHOD_DECL_in_method_declaration992 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_REF_T_in_method_declaration994 = new BitSet(new long[]{0x0002000000000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_method_declaration997 = new BitSet(new long[]{0x0000000800001800L});
    public static final BitSet FOLLOW_parameter_list_in_method_declaration999 = new BitSet(new long[]{0x0000000800001000L});
    public static final BitSet FOLLOW_block_in_method_declaration1003 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_EMPTYSTATEMENT_in_method_declaration1006 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_fully_qualified_class_name_in_fully_qualified_class_name_list1024 = new BitSet(new long[]{0x0002000000000002L,0x0000000000001000L});
    public static final BitSet FOLLOW_DOMAIN_T_in_fully_qualified_class_name1047 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_fully_qualified_class_name_in_fully_qualified_class_name1051 = new BitSet(new long[]{0x0002000000000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_fully_qualified_class_name1053 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_DOMAIN_T_in_fully_qualified_class_name1056 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IDENTIFIER_in_fully_qualified_class_name1067 = new BitSet(new long[]{0x0000000000000002L,0x0000000000001000L});
    public static final BitSet FOLLOW_DOMAIN_T_in_fully_qualified_class_name1069 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_SCALAR_ELEMENT_in_static_array_pair_list1091 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_static_scalar_element_in_static_array_pair_list1093 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_scalar_in_static_scalar_element1110 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000040L});
    public static final BitSet FOLLOW_ARROW_T_in_static_scalar_element1113 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_scalar_in_static_scalar_element1116 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_static_var_element_in_static_var_list1146 = new BitSet(new long[]{0x0000000000002002L,0x0000000000004000L});
    public static final BitSet FOLLOW_pure_variable_in_static_var_element1164 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_EQUAL_T_in_static_var_element1175 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_pure_variable_in_static_var_element1177 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_scalar_in_static_var_element1179 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_IF_T_in_if_stat1213 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_CONDITION_in_if_stat1216 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_if_stat1218 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_inner_statement_list_in_if_stat1234 = new BitSet(new long[]{0x0000000000000008L,0x0000000000030000L});
    public static final BitSet FOLLOW_else_if_stat_in_if_stat1243 = new BitSet(new long[]{0x0000000000000008L,0x0000000000030000L});
    public static final BitSet FOLLOW_ELSE_T_in_if_stat1248 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_statement_in_if_stat1250 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_ELSEIF_T_in_else_if_stat1280 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_CONDITION_in_else_if_stat1283 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_else_if_stat1285 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_inner_statement_list_in_else_if_stat1288 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_case_list_in_switch_case_list1309 = new BitSet(new long[]{0x0000000000000002L,0x0000000000600000L});
    public static final BitSet FOLLOW_CASE_T_in_case_list1324 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_case_list1326 = new BitSet(new long[]{0x00C1000000004008L,0x0000000000000000L,0x0000000200000000L});
    public static final BitSet FOLLOW_inner_statement_list_in_case_list1328 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_DEFAULT_T_in_case_list1337 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_inner_statement_list_in_case_list1339 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_CATCH_T_in_catch_branch1356 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_IDENTIFIER_in_catch_branch1358 = new BitSet(new long[]{0x0100000000082000L});
    public static final BitSet FOLLOW_variable_in_catch_branch1360 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_block_in_catch_branch1362 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_inner_statement_list_in_for_statement1379 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_inner_statement_list_in_while_statement1402 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_inner_statement_list_in_foreach_statement1427 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_inner_statement_list_in_declare_statement1463 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_parameter_in_parameter_list1498 = new BitSet(new long[]{0x0000000000000802L});
    public static final BitSet FOLLOW_PARAMETER_in_parameter1519 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_TYPE_in_parameter1523 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_parameter_type_in_parameter1525 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_CONST_T_in_parameter1530 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_pure_variable_in_parameter1533 = new BitSet(new long[]{0x0000001000000008L});
    public static final BitSet FOLLOW_scalar_in_parameter1535 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_fully_qualified_class_name_in_parameter_type1556 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_cast_option_in_parameter_type1562 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_164_in_variable_modifiers1576 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_modifier_in_variable_modifiers1582 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_modifier1596 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000004L,0x000000EC00000000L});
    public static final BitSet FOLLOW_EQUAL_T_in_directive1652 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_IDENTIFIER_in_directive1654 = new BitSet(new long[]{0x010001F000282200L,0xFFFFFFFFF0004000L,0x00000000000007E7L});
    public static final BitSet FOLLOW_expression_in_directive1656 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_expression_in_expr_list1693 = new BitSet(new long[]{0x010001F000282202L,0xFFFFFFFFF0004000L,0x00000000000007E7L});
    public static final BitSet FOLLOW_EXPR_in_expression1727 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1731 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_OR_T_in_expression1743 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1747 = new BitSet(new long[]{0x010001F000282200L,0xFFFFFFFFF0004000L,0x00000000000007E7L});
    public static final BitSet FOLLOW_expression_in_expression1751 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_XOR_T_in_expression1763 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1767 = new BitSet(new long[]{0x010001F000282200L,0xFFFFFFFFF0004000L,0x00000000000007E7L});
    public static final BitSet FOLLOW_expression_in_expression1771 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_AND_T_in_expression1783 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1787 = new BitSet(new long[]{0x010001F000282200L,0xFFFFFFFFF0004000L,0x00000000000007E7L});
    public static final BitSet FOLLOW_expression_in_expression1791 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_EQUAL_T_in_expression1803 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1807 = new BitSet(new long[]{0x010001F000282200L,0xFFFFFFFFF0004000L,0x00000000000007E7L});
    public static final BitSet FOLLOW_expression_in_expression1811 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_PLUS_EQ_in_expression1824 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1828 = new BitSet(new long[]{0x010001F000282200L,0xFFFFFFFFF0004000L,0x00000000000007E7L});
    public static final BitSet FOLLOW_expression_in_expression1832 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_MINUS_EQ_in_expression1844 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1848 = new BitSet(new long[]{0x010001F000282200L,0xFFFFFFFFF0004000L,0x00000000000007E7L});
    public static final BitSet FOLLOW_expression_in_expression1852 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_MUL_EQ_in_expression1864 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1868 = new BitSet(new long[]{0x010001F000282200L,0xFFFFFFFFF0004000L,0x00000000000007E7L});
    public static final BitSet FOLLOW_expression_in_expression1872 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_DIV_EQ_in_expression1884 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1888 = new BitSet(new long[]{0x010001F000282200L,0xFFFFFFFFF0004000L,0x00000000000007E7L});
    public static final BitSet FOLLOW_expression_in_expression1892 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_DOT_EQ_in_expression1904 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1908 = new BitSet(new long[]{0x010001F000282200L,0xFFFFFFFFF0004000L,0x00000000000007E7L});
    public static final BitSet FOLLOW_expression_in_expression1912 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_PERCENT_EQ_in_expression1924 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1928 = new BitSet(new long[]{0x010001F000282200L,0xFFFFFFFFF0004000L,0x00000000000007E7L});
    public static final BitSet FOLLOW_expression_in_expression1932 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_BIT_AND_EQ_in_expression1944 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1948 = new BitSet(new long[]{0x010001F000282200L,0xFFFFFFFFF0004000L,0x00000000000007E7L});
    public static final BitSet FOLLOW_expression_in_expression1952 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_BIT_OR_EQ_in_expression1964 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1968 = new BitSet(new long[]{0x010001F000282200L,0xFFFFFFFFF0004000L,0x00000000000007E7L});
    public static final BitSet FOLLOW_expression_in_expression1972 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_POWER_EQ_in_expression1984 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1988 = new BitSet(new long[]{0x010001F000282200L,0xFFFFFFFFF0004000L,0x00000000000007E7L});
    public static final BitSet FOLLOW_expression_in_expression1992 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_LMOVE_EQ_in_expression2004 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2008 = new BitSet(new long[]{0x010001F000282200L,0xFFFFFFFFF0004000L,0x00000000000007E7L});
    public static final BitSet FOLLOW_expression_in_expression2012 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_RMOVE_EQ_in_expression2024 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2028 = new BitSet(new long[]{0x010001F000282200L,0xFFFFFFFFF0004000L,0x00000000000007E7L});
    public static final BitSet FOLLOW_expression_in_expression2032 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_QUESTION_T_in_expression2044 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2048 = new BitSet(new long[]{0x0000000000000000L,0x0000000000040000L});
    public static final BitSet FOLLOW_COLON_T_in_expression2051 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2055 = new BitSet(new long[]{0x010001F000282200L,0xFFFFFFFFF0004000L,0x00000000000007E7L});
    public static final BitSet FOLLOW_expression_in_expression2059 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_LOGICAL_OR_T_in_expression2074 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2078 = new BitSet(new long[]{0x010001F000282200L,0xFFFFFFFFF0004000L,0x00000000000007E7L});
    public static final BitSet FOLLOW_expression_in_expression2082 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_LOGICAL_AND_T_in_expression2094 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2098 = new BitSet(new long[]{0x010001F000282200L,0xFFFFFFFFF0004000L,0x00000000000007E7L});
    public static final BitSet FOLLOW_expression_in_expression2102 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_BIT_OR_T_in_expression2114 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2118 = new BitSet(new long[]{0x010001F000282200L,0xFFFFFFFFF0004000L,0x00000000000007E7L});
    public static final BitSet FOLLOW_expression_in_expression2122 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_POWER_T_in_expression2134 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2136 = new BitSet(new long[]{0x010001F000282200L,0xFFFFFFFFF0004000L,0x00000000000007E7L});
    public static final BitSet FOLLOW_expression_in_expression2138 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_REF_T_in_expression2150 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2154 = new BitSet(new long[]{0x010001F000282200L,0xFFFFFFFFF0004000L,0x00000000000007E7L});
    public static final BitSet FOLLOW_expression_in_expression2158 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_DOT_T_in_expression2170 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2174 = new BitSet(new long[]{0x010001F000282200L,0xFFFFFFFFF0004000L,0x00000000000007E7L});
    public static final BitSet FOLLOW_expression_in_expression2178 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_EQUAL_EQUAL_T_in_expression2190 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2194 = new BitSet(new long[]{0x010001F000282200L,0xFFFFFFFFF0004000L,0x00000000000007E7L});
    public static final BitSet FOLLOW_expression_in_expression2198 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_NOT_EQUAL_T_in_expression2210 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2214 = new BitSet(new long[]{0x010001F000282200L,0xFFFFFFFFF0004000L,0x00000000000007E7L});
    public static final BitSet FOLLOW_expression_in_expression2218 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_EQUAL_EQUAL_EQUAL_T_in_expression2230 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2234 = new BitSet(new long[]{0x010001F000282200L,0xFFFFFFFFF0004000L,0x00000000000007E7L});
    public static final BitSet FOLLOW_expression_in_expression2238 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_NOT_EQUAL_EQUAL_T_in_expression2250 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2254 = new BitSet(new long[]{0x010001F000282200L,0xFFFFFFFFF0004000L,0x00000000000007E7L});
    public static final BitSet FOLLOW_expression_in_expression2258 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_LT_T_in_expression2270 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2274 = new BitSet(new long[]{0x010001F000282200L,0xFFFFFFFFF0004000L,0x00000000000007E7L});
    public static final BitSet FOLLOW_expression_in_expression2278 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_MT_T_in_expression2290 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2294 = new BitSet(new long[]{0x010001F000282200L,0xFFFFFFFFF0004000L,0x00000000000007E7L});
    public static final BitSet FOLLOW_expression_in_expression2298 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_LE_T_in_expression2310 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2314 = new BitSet(new long[]{0x010001F000282200L,0xFFFFFFFFF0004000L,0x00000000000007E7L});
    public static final BitSet FOLLOW_expression_in_expression2318 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_ME_T_in_expression2330 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2332 = new BitSet(new long[]{0x010001F000282200L,0xFFFFFFFFF0004000L,0x00000000000007E7L});
    public static final BitSet FOLLOW_expression_in_expression2334 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_LSHIFT_T_in_expression2346 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2350 = new BitSet(new long[]{0x010001F000282200L,0xFFFFFFFFF0004000L,0x00000000000007E7L});
    public static final BitSet FOLLOW_expression_in_expression2354 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_RSHIFT_T_in_expression2366 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2370 = new BitSet(new long[]{0x010001F000282200L,0xFFFFFFFFF0004000L,0x00000000000007E7L});
    public static final BitSet FOLLOW_expression_in_expression2374 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_PLUS_T_in_expression2386 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2390 = new BitSet(new long[]{0x010001F000282200L,0xFFFFFFFFF0004000L,0x00000000000007E7L});
    public static final BitSet FOLLOW_expression_in_expression2394 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_MINUS_T_in_expression2406 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2410 = new BitSet(new long[]{0x010001F000282200L,0xFFFFFFFFF0004000L,0x00000000000007E7L});
    public static final BitSet FOLLOW_expression_in_expression2414 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_MUL_T_in_expression2426 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2430 = new BitSet(new long[]{0x010001F000282200L,0xFFFFFFFFF0004000L,0x00000000000007E7L});
    public static final BitSet FOLLOW_expression_in_expression2434 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_DIV_T_in_expression2446 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2450 = new BitSet(new long[]{0x010001F000282200L,0xFFFFFFFFF0004000L,0x00000000000007E7L});
    public static final BitSet FOLLOW_expression_in_expression2454 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_PERCENT_T_in_expression2466 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2470 = new BitSet(new long[]{0x010001F000282200L,0xFFFFFFFFF0004000L,0x00000000000007E7L});
    public static final BitSet FOLLOW_expression_in_expression2474 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_CAST_EXPR_in_expression2486 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_cast_option_in_expression2488 = new BitSet(new long[]{0x010001F000282200L,0xFFFFFFFFF0004000L,0x00000000000007E7L});
    public static final BitSet FOLLOW_expression_in_expression2492 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_TILDA_T_in_expression2504 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2508 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_EXC_NOT_T_in_expression2520 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2522 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_POSTFIX_EXPR_in_expression2530 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2534 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000000018L});
    public static final BitSet FOLLOW_plus_minus_in_expression2536 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_PREFIX_EXPR_in_expression2548 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_plus_minus_in_expression2550 = new BitSet(new long[]{0x010001F000282200L,0xFFFFFFFFF0004000L,0x00000000000007FFL});
    public static final BitSet FOLLOW_expression_in_expression2555 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_INSTANCEOF_T_in_expression2567 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2569 = new BitSet(new long[]{0x0002000000082000L,0x0000000000001000L});
    public static final BitSet FOLLOW_class_name_reference_in_expression2571 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_AT_T_in_expression2578 = new BitSet(new long[]{0x0100000000082000L});
    public static final BitSet FOLLOW_variable_in_expression2581 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_AT_T_in_expression2591 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_scalar_in_expression2594 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LIST_T_in_expression2605 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_assignment_list_in_expression2607 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_ARRAY_DECL_in_expression2616 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_array_pair_list_in_expression2618 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_NEW_T_in_expression2631 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_class_name_reference_in_expression2633 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_CLONE_T_in_expression2648 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_variable_in_expression2650 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_EXIT_T_in_expression2662 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2664 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_UNSET_T_in_expression2673 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_variable_in_expression2675 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_lambda_function_declaration_in_expression2682 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_BACKTRICKLITERAL_in_expression2688 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_plus_minus0 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_168_in_cast_option2727 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_169_in_cast_option2738 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_170_in_cast_option2746 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_171_in_cast_option2758 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_172_in_cast_option2768 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_176_in_cast_option2777 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_175_in_cast_option2787 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_173_in_cast_option2796 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_174_in_cast_option2807 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_UNSET_T_in_cast_option2816 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_CLONE_T_in_cast_option2826 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_METHOD_DECL_in_lambda_function_declaration2845 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_REF_T_in_lambda_function_declaration2847 = new BitSet(new long[]{0x0000000000001800L,0x0000000000000400L});
    public static final BitSet FOLLOW_parameter_list_in_lambda_function_declaration2850 = new BitSet(new long[]{0x0000000000001000L,0x0000000000000400L});
    public static final BitSet FOLLOW_USE_T_in_lambda_function_declaration2855 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_list_in_lambda_function_declaration2857 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_block_in_lambda_function_declaration2869 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_dynamic_name_reference_in_class_name_reference2902 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_fully_qualified_class_name_in_class_name_reference2913 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_base_variable_with_function_calls_in_dynamic_name_reference2936 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_CALL_in_dynamic_name_reference2948 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_dynamic_name_reference_in_dynamic_name_reference2952 = new BitSet(new long[]{0x0000020000020000L});
    public static final BitSet FOLLOW_object_property_in_dynamic_name_reference2956 = new BitSet(new long[]{0x0000000040000008L});
    public static final BitSet FOLLOW_ctor_arguments_in_dynamic_name_reference2958 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_assignment_element_in_assignment_list2977 = new BitSet(new long[]{0x0100000000082002L,0x0000000000000000L,0x0000000000000080L});
    public static final BitSet FOLLOW_variable_in_assignment_element2993 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LIST_T_in_assignment_element3000 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_assignment_list_in_assignment_element3002 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_array_pair_element_in_array_pair_list3032 = new BitSet(new long[]{0x010001F000282202L,0xFFFFFFFFF0004040L,0x00000000000007E7L});
    public static final BitSet FOLLOW_ARROW_T_in_array_pair_element3053 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_array_pair_element3057 = new BitSet(new long[]{0x010001F000282200L,0xFFFFFFFFF0004000L,0x00000000000007E7L});
    public static final BitSet FOLLOW_expression_in_array_pair_element3061 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_expression_in_array_pair_element3072 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_variable_temp_in_variable3107 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_base_variable_with_function_calls_in_variable_temp3131 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_CALL_in_variable_temp3143 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_variable_temp_in_variable_temp3147 = new BitSet(new long[]{0x0000020000020000L});
    public static final BitSet FOLLOW_object_property_in_variable_temp3151 = new BitSet(new long[]{0x0000000040000008L});
    public static final BitSet FOLLOW_ctor_arguments_in_variable_temp3153 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_VAR_DECL_in_base_variable_with_function_calls3179 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_fully_qualified_class_name_in_base_variable_with_function_calls3181 = new BitSet(new long[]{0x0000020000020000L});
    public static final BitSet FOLLOW_object_property_in_base_variable_with_function_calls3184 = new BitSet(new long[]{0x0000000040000008L});
    public static final BitSet FOLLOW_ctor_arguments_in_base_variable_with_function_calls3186 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_CALL_in_base_variable_with_function_calls3207 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_fully_qualified_class_name_in_base_variable_with_function_calls3209 = new BitSet(new long[]{0x0000000040000000L});
    public static final BitSet FOLLOW_ctor_arguments_in_base_variable_with_function_calls3211 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_VAR_in_object_property3250 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_DOLLAR_T_in_object_property3252 = new BitSet(new long[]{0x0002000000000000L,0x0000000000000000L,0x0000000000004000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_object_property3255 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_VAR_in_object_property3269 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_DOLLAR_T_in_object_property3271 = new BitSet(new long[]{0x010001F000282200L,0xFFFFFFFFF0004000L,0x00000000000047E7L});
    public static final BitSet FOLLOW_expression_in_object_property3274 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_INDEX_in_object_property3286 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_object_property_in_object_property3290 = new BitSet(new long[]{0x010001F000282208L,0xFFFFFFFFF0004000L,0x00000000000007E7L});
    public static final BitSet FOLLOW_expression_in_object_property3292 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_ARGU_in_ctor_arguments3321 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_list_in_ctor_arguments3323 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_VAR_DECL_in_pure_variable3345 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_REF_T_in_pure_variable3347 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000004000L});
    public static final BitSet FOLLOW_DOLLAR_T_in_pure_variable3350 = new BitSet(new long[]{0x0002000000000000L,0x0000000000000000L,0x0000000000004000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_pure_variable3353 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_SCALAR_in_scalar3384 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_constant_in_scalar3386 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_INTLITERAL_in_constant3412 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_FLOATLITERAL_in_constant3424 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_STRINGLITERAL_in_constant3432 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_DOUBLELITERRAL_in_constant3444 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_common_scalar_in_constant3452 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IDENTIFIER_in_constant3460 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_fully_qualified_class_name_in_constant3472 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_common_scalar0 = new BitSet(new long[]{0x0000000000000002L});

}