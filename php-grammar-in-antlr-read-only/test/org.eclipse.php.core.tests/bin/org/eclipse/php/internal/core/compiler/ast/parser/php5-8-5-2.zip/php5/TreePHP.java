// $ANTLR 3.1.3 Mar 17, 2009 19:23:44 /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g 2009-08-05 23:16:11

  package org.eclipse.php.internal.core.compiler.ast.parser.php5;
  
  import org.eclipse.dltk.ast.*;
import org.eclipse.dltk.ast.declarations.*;
import org.eclipse.dltk.ast.expressions.*;
import org.eclipse.dltk.ast.references.*;
import org.eclipse.dltk.ast.statements.*;
import org.eclipse.php.internal.core.compiler.ast.nodes.*;
import org.eclipse.php.internal.core.compiler.ast.parser.*;
import java.util.*;
import org.antlr.runtime.BitSet;


import org.antlr.runtime.*;
import org.antlr.runtime.tree.*;import java.util.Stack;
import java.util.List;
import java.util.ArrayList;


public class TreePHP extends TreeParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "ModuleDeclaration", "ClassDeclaration", "PROG", "CLASS_BODY", "FIELD_DECL", "METHOD_DECL", "TYPE", "PARAMETER", "BLOCK", "VAR_DECL", "STATEMENT", "CONDITION", "LIST", "INDEX", "MEMBERACCESS", "CALL", "ELIST", "EXPR", "ASSIGN", "LIST_DECL", "SCALAR_ELEMENT", "SCALAR_VAR", "CAST", "LABEL", "ITERATE", "USE_DECL", "ARGU", "CALLED_OBJ", "PREFIX", "POSTFIX", "NAMESPACE", "EMPTYSTATEMENT", "SCALAR", "ARRAY_DECL", "PREFIX_EXPR", "POSTFIX_EXPR", "CAST_EXPR", "UNARY_EXPR", "VAR", "HASH_INDEX", "SOC_T", "SOC_PHP_T", "EOC_T", "LEFT_PARETHESIS", "RIGHT_PARETHESIS", "SEMI_COLON", "CLASS_T", "IDENTIFIER", "EXTENDS_T", "IMPLEMENTS_T", "LEFT_BRACKET", "RIGHT_BRACKET", "INTERFACE_T", "FUNCTION_T", "REF_T", "CONST_T", "WHILE_T", "DO_T", "FOR_T", "SWITCH_T", "BREAK_T", "CONTINUE_T", "RETURN_T", "GLOBAL_T", "STATIC_T", "ECHO_T", "FOREACH_T", "AS_T", "ARROW_T", "DECLARE_T", "TRY_T", "THROW_T", "USE_T", "INCLUDE_T", "INCLUDE_ONCE_T", "REQUIRE_T", "REQUIRE_ONCE_T", "STRINGLITERAL", "DOMAIN_T", "COMMA_T", "EQUAL_T", "IF_T", "ELSEIF_T", "ELSE_T", "COLON_T", "ENDIF_T", "ENDSWITCH_T", "CASE_T", "DEFAULT_T", "CATCH_T", "ENDFOR_T", "ENDWHILE_T", "ENDFOREACH_T", "ENDDECLARE_T", "OR_T", "XOR_T", "AND_T", "PLUS_EQ", "MINUS_EQ", "MUL_EQ", "DIV_EQ", "DOT_EQ", "PERCENT_EQ", "BIT_AND_EQ", "BIT_OR_EQ", "POWER_EQ", "LMOVE_EQ", "RMOVE_EQ", "QUESTION_T", "LOGICAL_OR_T", "LOGICAL_AND_T", "BIT_OR_T", "POWER_T", "DOT_T", "EQUAL_EQUAL_T", "NOT_EQUAL_T", "EQUAL_EQUAL_EQUAL_T", "NOT_EQUAL_EQUAL_T", "LT_T", "MT_T", "LE_T", "ME_T", "LSHIFT_T", "RSHIFT_T", "PLUS_T", "MINUS_T", "MUL_T", "DIV_T", "PERCENT_T", "CLONE_T", "TILDA_T", "EXC_NOT_T", "PLUS_PLUS_T", "MINUS_MINUS_T", "INSTANCEOF_T", "AT_T", "LIST_T", "NEW_T", "BACKTRICKLITERAL", "PRINT_T", "SINGLE_ARROW_T", "LEFT_OPEN_RECT", "RIGHT_OPEN_RECT", "DOLLAR_T", "INTLITERAL", "FLOATLITERAL", "DOUBLELITERRAL", "IntegerNumber", "LongSuffix", "HexPrefix", "HexDigit", "STATIC", "NonIntegerNumber", "FloatSuffix", "DoubleSuffix", "Exponent", "EscapeSequence", "IdentifierStart", "IdentifierPart", "WS", "COMMENT", "LINE_COMMENT", "'__halt_compiler'", "'abstract'", "'final'", "'var'", "'public'", "'protected'", "'private'", "'bool'", "'boolean'", "'int'", "'float'", "'double'", "'real'", "'string'", "'unset'", "'object'", "'array'", "'__CLASS__'", "'__DIR__'", "'__FILE__'", "'__FUNCTION__'", "'__METHOD__'", "'__NAMESPACE__'"
    };
    public static final int RIGHT_OPEN_RECT=146;
    public static final int ENDFOR_T=94;
    public static final int LOGICAL_OR_T=113;
    public static final int CONDITION=15;
    public static final int DOMAIN_T=82;
    public static final int T__167=167;
    public static final int T__168=168;
    public static final int EOF=-1;
    public static final int EQUAL_EQUAL_T=118;
    public static final int T__166=166;
    public static final int STATEMENT=14;
    public static final int TYPE=10;
    public static final int EOC_T=46;
    public static final int NOT_EQUAL_EQUAL_T=121;
    public static final int CAST_EXPR=40;
    public static final int AT_T=139;
    public static final int NonIntegerNumber=156;
    public static final int FloatSuffix=157;
    public static final int RIGHT_BRACKET=55;
    public static final int AND_T=100;
    public static final int ARGU=30;
    public static final int FOR_T=62;
    public static final int MINUS_MINUS_T=137;
    public static final int RMOVE_EQ=111;
    public static final int STATIC=155;
    public static final int WHILE_T=60;
    public static final int ARRAY_DECL=37;
    public static final int MUL_EQ=103;
    public static final int SEMI_COLON=49;
    public static final int INTERFACE_T=56;
    public static final int OR_T=98;
    public static final int INTLITERAL=148;
    public static final int PLUS_EQ=101;
    public static final int ENDDECLARE_T=97;
    public static final int PLUS_T=128;
    public static final int MINUS_EQ=102;
    public static final int LongSuffix=152;
    public static final int REQUIRE_T=79;
    public static final int ENDFOREACH_T=96;
    public static final int WS=163;
    public static final int DO_T=61;
    public static final int EQUAL_T=84;
    public static final int COLON_T=88;
    public static final int USE_T=76;
    public static final int SOC_PHP_T=45;
    public static final int MINUS_T=129;
    public static final int CALL=19;
    public static final int SCALAR_ELEMENT=24;
    public static final int POWER_EQ=109;
    public static final int BIT_AND_EQ=107;
    public static final int INCLUDE_ONCE_T=78;
    public static final int LEFT_BRACKET=54;
    public static final int DOUBLELITERRAL=150;
    public static final int UNARY_EXPR=41;
    public static final int CATCH_T=93;
    public static final int IMPLEMENTS_T=53;
    public static final int HexDigit=154;
    public static final int DEFAULT_T=92;
    public static final int REQUIRE_ONCE_T=80;
    public static final int CONST_T=59;
    public static final int FUNCTION_T=57;
    public static final int MUL_T=130;
    public static final int BIT_OR_EQ=108;
    public static final int BIT_OR_T=115;
    public static final int FOREACH_T=70;
    public static final int FIELD_DECL=8;
    public static final int PREFIX_EXPR=38;
    public static final int LIST_T=140;
    public static final int CLASS_BODY=7;
    public static final int LIST_DECL=23;
    public static final int BACKTRICKLITERAL=142;
    public static final int ITERATE=28;
    public static final int LEFT_PARETHESIS=47;
    public static final int RETURN_T=66;
    public static final int DoubleSuffix=158;
    public static final int ENDWHILE_T=95;
    public static final int STRINGLITERAL=81;
    public static final int BLOCK=12;
    public static final int EXTENDS_T=52;
    public static final int CONTINUE_T=65;
    public static final int PRINT_T=143;
    public static final int FLOATLITERAL=149;
    public static final int ENDSWITCH_T=90;
    public static final int CAST=26;
    public static final int PREFIX=32;
    public static final int XOR_T=99;
    public static final int TRY_T=74;
    public static final int POSTFIX=33;
    public static final int HASH_INDEX=43;
    public static final int PERCENT_EQ=106;
    public static final int INCLUDE_T=77;
    public static final int AS_T=71;
    public static final int VAR_DECL=13;
    public static final int DIV_T=131;
    public static final int COMMA_T=83;
    public static final int STATIC_T=68;
    public static final int DOT_T=117;
    public static final int ENDIF_T=89;
    public static final int POSTFIX_EXPR=39;
    public static final int CALLED_OBJ=31;
    public static final int DIV_EQ=104;
    public static final int GLOBAL_T=67;
    public static final int ELIST=20;
    public static final int IF_T=85;
    public static final int PARAMETER=11;
    public static final int MT_T=123;
    public static final int SCALAR=36;
    public static final int ELSE_T=87;
    public static final int SINGLE_ARROW_T=144;
    public static final int VAR=42;
    public static final int RSHIFT_T=127;
    public static final int COMMENT=164;
    public static final int HexPrefix=153;
    public static final int ARROW_T=72;
    public static final int LINE_COMMENT=165;
    public static final int EQUAL_EQUAL_EQUAL_T=120;
    public static final int CLONE_T=133;
    public static final int IdentifierStart=161;
    public static final int DECLARE_T=73;
    public static final int THROW_T=75;
    public static final int REF_T=58;
    public static final int LIST=16;
    public static final int NAMESPACE=34;
    public static final int EMPTYSTATEMENT=35;
    public static final int NEW_T=141;
    public static final int MEMBERACCESS=18;
    public static final int PLUS_PLUS_T=136;
    public static final int EscapeSequence=160;
    public static final int CLASS_T=50;
    public static final int IntegerNumber=151;
    public static final int ECHO_T=69;
    public static final int DOLLAR_T=147;
    public static final int SOC_T=44;
    public static final int METHOD_DECL=9;
    public static final int Exponent=159;
    public static final int LE_T=124;
    public static final int PERCENT_T=132;
    public static final int INDEX=17;
    public static final int PROG=6;
    public static final int EXPR=21;
    public static final int USE_DECL=29;
    public static final int NOT_EQUAL_T=119;
    public static final int POWER_T=116;
    public static final int IDENTIFIER=51;
    public static final int LEFT_OPEN_RECT=145;
    public static final int LMOVE_EQ=110;
    public static final int SCALAR_VAR=25;
    public static final int TILDA_T=134;
    public static final int IdentifierPart=162;
    public static final int T__184=184;
    public static final int SWITCH_T=63;
    public static final int T__183=183;
    public static final int T__186=186;
    public static final int T__185=185;
    public static final int T__188=188;
    public static final int T__187=187;
    public static final int LOGICAL_AND_T=114;
    public static final int QUESTION_T=112;
    public static final int LSHIFT_T=126;
    public static final int T__180=180;
    public static final int INSTANCEOF_T=138;
    public static final int ELSEIF_T=86;
    public static final int T__182=182;
    public static final int T__181=181;
    public static final int LT_T=122;
    public static final int ModuleDeclaration=4;
    public static final int T__175=175;
    public static final int T__174=174;
    public static final int T__173=173;
    public static final int T__172=172;
    public static final int T__179=179;
    public static final int T__178=178;
    public static final int T__177=177;
    public static final int T__176=176;
    public static final int ME_T=125;
    public static final int LABEL=27;
    public static final int T__171=171;
    public static final int T__170=170;
    public static final int RIGHT_PARETHESIS=48;
    public static final int ASSIGN=22;
    public static final int EXC_NOT_T=135;
    public static final int BREAK_T=64;
    public static final int CASE_T=91;
    public static final int DOT_EQ=105;
    public static final int ClassDeclaration=5;
    public static final int T__169=169;

    // delegates
    // delegators


        public TreePHP(TreeNodeStream input) {
            this(input, new RecognizerSharedState());
        }
        public TreePHP(TreeNodeStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        
    protected TreeAdaptor adaptor = new CommonTreeAdaptor();

    public void setTreeAdaptor(TreeAdaptor adaptor) {
        this.adaptor = adaptor;
    }
    public TreeAdaptor getTreeAdaptor() {
        return adaptor;
    }

    public String[] getTokenNames() { return TreePHP.tokenNames; }
    public String getGrammarFileName() { return "/home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g"; }


      ModuleDeclaration program;
      
      AbstractASTParser parser;
      
      boolean inExprList = false;
      
      boolean inClassStatementList = false;
      
      boolean inVarList = false;
        
      public TreePHP(TreeNodeStream input, AbstractASTParser parser) {
         this(input, new RecognizerSharedState());
         this.parser = parser;
      }
       
      public ModuleDeclaration getModuleDeclaration() {
        return program;
      }
      
      class ModifierDocPair {
        public int modifier;
        public PHPDocBlock doc;
        
        public ModifierDocPair(int modifier, PHPDocBlock doc) {
          this.modifier = modifier;
          this.doc = doc;
        }
      }
      
      public Expression createDispatch(Expression dispatcher, Expression property) {

        if (property.getKind() == ASTNodeKinds.REFLECTION_CALL_EXPRESSION) {
          ((ReflectionCallExpression) property).setReceiver (dispatcher);
          dispatcher = property;
        } else if (property.getKind() == ASTNodeKinds.METHOD_INVOCATION) {
          PHPCallExpression callExpression = (PHPCallExpression) property;
          dispatcher = new PHPCallExpression(dispatcher.sourceStart(), callExpression.sourceEnd(), dispatcher, callExpression.getCallName(), callExpression.getArgs());
        } else {
          dispatcher =  new FieldAccess(dispatcher.sourceStart(), property.sourceEnd(), dispatcher, property);
        }

        return dispatcher;
      }
      
        private List errors = new LinkedList();
        public void displayRecognitionError(String[] tokenNames,
                                            RecognitionException e) {
            String hdr = getErrorHeader(e);
            String msg = getErrorMessage(e, tokenNames);
            errors.add(hdr + " " + msg);
        }
        public List<String> getErrors() {
            return errors;
        }


    public static class php_source_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "php_source"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:84:1: php_source : ^( ModuleDeclaration ( top_statement_list )? ) ;
    public final TreePHP.php_source_return php_source() throws RecognitionException {
        TreePHP.php_source_return retval = new TreePHP.php_source_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST ModuleDeclaration1=null;
        TreePHP.top_statement_list_return top_statement_list2 = null;


        SLAST ModuleDeclaration1_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:85:3: ( ^( ModuleDeclaration ( top_statement_list )? ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:85:6: ^( ModuleDeclaration ( top_statement_list )? )
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_1 = _last;
            SLAST _first_1 = null;
            SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            ModuleDeclaration1=(SLAST)match(input,ModuleDeclaration,FOLLOW_ModuleDeclaration_in_php_source58); 
            ModuleDeclaration1_tree = (SLAST)adaptor.dupNode(ModuleDeclaration1);

            root_1 = (SLAST)adaptor.becomeRoot(ModuleDeclaration1_tree, root_1);



            if ( input.LA(1)==Token.DOWN ) {
                match(input, Token.DOWN, null); 
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:85:26: ( top_statement_list )?
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( (LA1_0==METHOD_DECL||LA1_0==STATEMENT||LA1_0==CLASS_T||LA1_0==INTERFACE_T||LA1_0==166) ) {
                    alt1=1;
                }
                switch (alt1) {
                    case 1 :
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:85:26: top_statement_list
                        {
                        _last = (SLAST)input.LT(1);
                        pushFollow(FOLLOW_top_statement_list_in_php_source60);
                        top_statement_list2=top_statement_list();

                        state._fsp--;

                        adaptor.addChild(root_1, top_statement_list2.getTree());

                        }
                        break;

                }


                match(input, Token.UP, null); 
            }adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


                ModuleDeclaration RESULT = null;
                int startIndex = ModuleDeclaration1.startIndex;
                int endIndex = ModuleDeclaration1.endIndex + 2;
             
                PHPModuleDeclaration program = parser.getModuleDeclaration();
            	  program.setStart(startIndex);
            	  program.setEnd(endIndex);
            	  RESULT = program;
            	  
            	  System.out.println("module: \n" + RESULT);
              

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "php_source"

    public static class top_statement_list_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "top_statement_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:100:1: top_statement_list : ( top_statement )+ ;
    public final TreePHP.top_statement_list_return top_statement_list() throws RecognitionException {
        TreePHP.top_statement_list_return retval = new TreePHP.top_statement_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.top_statement_return top_statement3 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:101:3: ( ( top_statement )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:101:5: ( top_statement )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:101:5: ( top_statement )+
            int cnt2=0;
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( (LA2_0==METHOD_DECL||LA2_0==STATEMENT||LA2_0==CLASS_T||LA2_0==INTERFACE_T||LA2_0==166) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:101:5: top_statement
            	    {
            	    _last = (SLAST)input.LT(1);
            	    pushFollow(FOLLOW_top_statement_in_top_statement_list79);
            	    top_statement3=top_statement();

            	    state._fsp--;

            	    adaptor.addChild(root_0, top_statement3.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt2 >= 1 ) break loop2;
                        EarlyExitException eee =
                            new EarlyExitException(2, input);
                        throw eee;
                }
                cnt2++;
            } while (true);


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "top_statement_list"

    public static class top_statement_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "top_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:104:1: top_statement : ( statement | function_declaration_statement | class_declaration_statement | halt_compiler_statement );
    public final TreePHP.top_statement_return top_statement() throws RecognitionException {
        TreePHP.top_statement_return retval = new TreePHP.top_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.statement_return statement4 = null;

        TreePHP.function_declaration_statement_return function_declaration_statement5 = null;

        TreePHP.class_declaration_statement_return class_declaration_statement6 = null;

        TreePHP.halt_compiler_statement_return halt_compiler_statement7 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:105:3: ( statement | function_declaration_statement | class_declaration_statement | halt_compiler_statement )
            int alt3=4;
            switch ( input.LA(1) ) {
            case STATEMENT:
                {
                alt3=1;
                }
                break;
            case METHOD_DECL:
                {
                alt3=2;
                }
                break;
            case CLASS_T:
            case INTERFACE_T:
                {
                alt3=3;
                }
                break;
            case 166:
                {
                alt3=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 3, 0, input);

                throw nvae;
            }

            switch (alt3) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:105:5: statement
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_statement_in_top_statement93);
                    statement4=statement();

                    state._fsp--;

                    adaptor.addChild(root_0, statement4.getTree());

                        Statement stat = (statement4!=null?statement4.stat:null);
                        parser.addStatement(stat);
                    //    System.out.println("state:" + stat);
                      

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:111:5: function_declaration_statement
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_function_declaration_statement_in_top_statement103);
                    function_declaration_statement5=function_declaration_statement();

                    state._fsp--;

                    adaptor.addChild(root_0, function_declaration_statement5.getTree());

                        parser.addStatement((function_declaration_statement5!=null?function_declaration_statement5.stat:null));
                      

                    }
                    break;
                case 3 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:115:5: class_declaration_statement
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_class_declaration_statement_in_top_statement113);
                    class_declaration_statement6=class_declaration_statement();

                    state._fsp--;

                    adaptor.addChild(root_0, class_declaration_statement6.getTree());

                        ClassDeclaration classDeclaration = (class_declaration_statement6!=null?class_declaration_statement6.classDeclaration:null);
                        parser.addDeclarationStatement(classDeclaration);
                        parser.declarations.push(classDeclaration);
                        parser.addStatement(classDeclaration);
                      

                    }
                    break;
                case 4 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:122:5: halt_compiler_statement
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_halt_compiler_statement_in_top_statement123);
                    halt_compiler_statement7=halt_compiler_statement();

                    state._fsp--;

                    adaptor.addChild(root_0, halt_compiler_statement7.getTree());

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "top_statement"

    protected static class inner_statement_list_scope {
        List list;
    }
    protected Stack inner_statement_list_stack = new Stack();

    public static class inner_statement_list_return extends TreeRuleReturnScope {
        public List innerStatementList;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "inner_statement_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:125:1: inner_statement_list returns [List innerStatementList] : ( inner_statement )+ ;
    public final TreePHP.inner_statement_list_return inner_statement_list() throws RecognitionException {
        inner_statement_list_stack.push(new inner_statement_list_scope());
        TreePHP.inner_statement_list_return retval = new TreePHP.inner_statement_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.inner_statement_return inner_statement8 = null;




          ((inner_statement_list_scope)inner_statement_list_stack.peek()).list = new LinkedList();

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:132:3: ( ( inner_statement )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:132:5: ( inner_statement )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:132:5: ( inner_statement )+
            int cnt4=0;
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( (LA4_0==METHOD_DECL||LA4_0==STATEMENT||LA4_0==CLASS_T||LA4_0==INTERFACE_T||LA4_0==166) ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:132:6: inner_statement
            	    {
            	    _last = (SLAST)input.LT(1);
            	    pushFollow(FOLLOW_inner_statement_in_inner_statement_list150);
            	    inner_statement8=inner_statement();

            	    state._fsp--;

            	    adaptor.addChild(root_0, inner_statement8.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt4 >= 1 ) break loop4;
                        EarlyExitException eee =
                            new EarlyExitException(4, input);
                        throw eee;
                }
                cnt4++;
            } while (true);


                retval.innerStatementList = ((inner_statement_list_scope)inner_statement_list_stack.peek()).list;
              

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
            inner_statement_list_stack.pop();
        }
        return retval;
    }
    // $ANTLR end "inner_statement_list"

    public static class inner_statement_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "inner_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:138:1: inner_statement : ( statement | function_declaration_statement | class_declaration_statement | halt_compiler_statement );
    public final TreePHP.inner_statement_return inner_statement() throws RecognitionException {
        TreePHP.inner_statement_return retval = new TreePHP.inner_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.statement_return statement9 = null;

        TreePHP.function_declaration_statement_return function_declaration_statement10 = null;

        TreePHP.class_declaration_statement_return class_declaration_statement11 = null;

        TreePHP.halt_compiler_statement_return halt_compiler_statement12 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:139:3: ( statement | function_declaration_statement | class_declaration_statement | halt_compiler_statement )
            int alt5=4;
            switch ( input.LA(1) ) {
            case STATEMENT:
                {
                alt5=1;
                }
                break;
            case METHOD_DECL:
                {
                alt5=2;
                }
                break;
            case CLASS_T:
            case INTERFACE_T:
                {
                alt5=3;
                }
                break;
            case 166:
                {
                alt5=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 5, 0, input);

                throw nvae;
            }

            switch (alt5) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:139:5: statement
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_statement_in_inner_statement172);
                    statement9=statement();

                    state._fsp--;

                    adaptor.addChild(root_0, statement9.getTree());

                        if ((statement9!=null?statement9.stat:null) != null) {
                          ((inner_statement_list_scope)inner_statement_list_stack.peek()).list.add((statement9!=null?statement9.stat:null));
                          System.out.println("inner state: " + (statement9!=null?statement9.stat:null));
                        }
                      

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:146:5: function_declaration_statement
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_function_declaration_statement_in_inner_statement182);
                    function_declaration_statement10=function_declaration_statement();

                    state._fsp--;

                    adaptor.addChild(root_0, function_declaration_statement10.getTree());

                        if ((function_declaration_statement10!=null?function_declaration_statement10.stat:null) != null) {
                          ((inner_statement_list_scope)inner_statement_list_stack.peek()).list.add((function_declaration_statement10!=null?function_declaration_statement10.stat:null));
                        }  
                      

                    }
                    break;
                case 3 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:152:5: class_declaration_statement
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_class_declaration_statement_in_inner_statement192);
                    class_declaration_statement11=class_declaration_statement();

                    state._fsp--;

                    adaptor.addChild(root_0, class_declaration_statement11.getTree());

                    }
                    break;
                case 4 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:153:5: halt_compiler_statement
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_halt_compiler_statement_in_inner_statement198);
                    halt_compiler_statement12=halt_compiler_statement();

                    state._fsp--;

                    adaptor.addChild(root_0, halt_compiler_statement12.getTree());

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "inner_statement"

    public static class halt_compiler_statement_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "halt_compiler_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:156:1: halt_compiler_statement : '__halt_compiler' ;
    public final TreePHP.halt_compiler_statement_return halt_compiler_statement() throws RecognitionException {
        TreePHP.halt_compiler_statement_return retval = new TreePHP.halt_compiler_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST string_literal13=null;

        SLAST string_literal13_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:157:3: ( '__halt_compiler' )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:157:5: '__halt_compiler'
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            string_literal13=(SLAST)match(input,166,FOLLOW_166_in_halt_compiler_statement213); 
            string_literal13_tree = (SLAST)adaptor.dupNode(string_literal13);

            adaptor.addChild(root_0, string_literal13_tree);


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "halt_compiler_statement"

    public static class class_declaration_statement_return extends TreeRuleReturnScope {
        public ClassDeclaration classDeclaration;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "class_declaration_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:160:1: class_declaration_statement returns [ClassDeclaration classDeclaration] : ( ^( CLASS_T ( class_entr_type )? IDENTIFIER ( ^( EXTENDS_T fully_qualified_class_name ) )? ( ^( IMPLEMENTS_T fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? ) | ^( INTERFACE_T IDENTIFIER ( ^( EXTENDS_T fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? ) );
    public final TreePHP.class_declaration_statement_return class_declaration_statement() throws RecognitionException {
        TreePHP.class_declaration_statement_return retval = new TreePHP.class_declaration_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST CLASS_T14=null;
        SLAST IDENTIFIER16=null;
        SLAST EXTENDS_T17=null;
        SLAST IMPLEMENTS_T19=null;
        SLAST CLASS_BODY21=null;
        SLAST INTERFACE_T23=null;
        SLAST IDENTIFIER24=null;
        SLAST EXTENDS_T25=null;
        SLAST CLASS_BODY27=null;
        TreePHP.class_entr_type_return class_entr_type15 = null;

        TreePHP.fully_qualified_class_name_return fully_qualified_class_name18 = null;

        TreePHP.fully_qualified_class_name_list_return fully_qualified_class_name_list20 = null;

        TreePHP.class_statement_list_return class_statement_list22 = null;

        TreePHP.fully_qualified_class_name_list_return fully_qualified_class_name_list26 = null;

        TreePHP.class_statement_list_return class_statement_list28 = null;


        SLAST CLASS_T14_tree=null;
        SLAST IDENTIFIER16_tree=null;
        SLAST EXTENDS_T17_tree=null;
        SLAST IMPLEMENTS_T19_tree=null;
        SLAST CLASS_BODY21_tree=null;
        SLAST INTERFACE_T23_tree=null;
        SLAST IDENTIFIER24_tree=null;
        SLAST EXTENDS_T25_tree=null;
        SLAST CLASS_BODY27_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:161:3: ( ^( CLASS_T ( class_entr_type )? IDENTIFIER ( ^( EXTENDS_T fully_qualified_class_name ) )? ( ^( IMPLEMENTS_T fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? ) | ^( INTERFACE_T IDENTIFIER ( ^( EXTENDS_T fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? ) )
            int alt12=2;
            int LA12_0 = input.LA(1);

            if ( (LA12_0==CLASS_T) ) {
                alt12=1;
            }
            else if ( (LA12_0==INTERFACE_T) ) {
                alt12=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 12, 0, input);

                throw nvae;
            }
            switch (alt12) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:161:5: ^( CLASS_T ( class_entr_type )? IDENTIFIER ( ^( EXTENDS_T fully_qualified_class_name ) )? ( ^( IMPLEMENTS_T fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    CLASS_T14=(SLAST)match(input,CLASS_T,FOLLOW_CLASS_T_in_class_declaration_statement233); 
                    CLASS_T14_tree = (SLAST)adaptor.dupNode(CLASS_T14);

                    root_1 = (SLAST)adaptor.becomeRoot(CLASS_T14_tree, root_1);



                    match(input, Token.DOWN, null); 
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:161:15: ( class_entr_type )?
                    int alt6=2;
                    int LA6_0 = input.LA(1);

                    if ( ((LA6_0>=167 && LA6_0<=168)) ) {
                        alt6=1;
                    }
                    switch (alt6) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:161:15: class_entr_type
                            {
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_class_entr_type_in_class_declaration_statement235);
                            class_entr_type15=class_entr_type();

                            state._fsp--;

                            adaptor.addChild(root_1, class_entr_type15.getTree());

                            }
                            break;

                    }

                    _last = (SLAST)input.LT(1);
                    IDENTIFIER16=(SLAST)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_class_declaration_statement238); 
                    IDENTIFIER16_tree = (SLAST)adaptor.dupNode(IDENTIFIER16);

                    adaptor.addChild(root_1, IDENTIFIER16_tree);


                          TreePHP.ModifierDocPair modifier = new ModifierDocPair(Modifiers.AccDefault, null);
                          int startIndex = CLASS_T14.startIndex;
                          int endIndex = CLASS_T14.endIndex + 1;
                          if ((class_entr_type15!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(class_entr_type15.start),
                      input.getTreeAdaptor().getTokenStopIndex(class_entr_type15.start))):null) != null) {
                              if ((class_entr_type15!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(class_entr_type15.start),
                      input.getTreeAdaptor().getTokenStopIndex(class_entr_type15.start))):null).equals("abstract")) {
                                modifier = new ModifierDocPair(Modifiers.AccAbstract, null);
                              }
                          }
                          
                          CommonToken token = (CommonToken)IDENTIFIER16.token;
                          int classNameLeft = token.getStartIndex();
                          int classNameRight = token.getStopIndex() + 1;
                          String className = (IDENTIFIER16!=null?IDENTIFIER16.getText():null);
                          
                          retval.classDeclaration = new ClassDeclaration(startIndex ,endIndex, classNameLeft, classNameRight, modifier.modifier, className, null, null, new Block(classNameRight,classNameRight,null), null);
                          parser.addDeclarationStatement(retval.classDeclaration);
                          parser.declarations.push(retval.classDeclaration);
                      
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:182:4: ( ^( EXTENDS_T fully_qualified_class_name ) )?
                    int alt7=2;
                    int LA7_0 = input.LA(1);

                    if ( (LA7_0==EXTENDS_T) ) {
                        alt7=1;
                    }
                    switch (alt7) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:182:5: ^( EXTENDS_T fully_qualified_class_name )
                            {
                            _last = (SLAST)input.LT(1);
                            {
                            SLAST _save_last_2 = _last;
                            SLAST _first_2 = null;
                            SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                            EXTENDS_T17=(SLAST)match(input,EXTENDS_T,FOLLOW_EXTENDS_T_in_class_declaration_statement252); 
                            EXTENDS_T17_tree = (SLAST)adaptor.dupNode(EXTENDS_T17);

                            root_2 = (SLAST)adaptor.becomeRoot(EXTENDS_T17_tree, root_2);



                            match(input, Token.DOWN, null); 
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_fully_qualified_class_name_in_class_declaration_statement254);
                            fully_qualified_class_name18=fully_qualified_class_name();

                            state._fsp--;

                            adaptor.addChild(root_2, fully_qualified_class_name18.getTree());

                            match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
                            }


                            }
                            break;

                    }

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:182:47: ( ^( IMPLEMENTS_T fully_qualified_class_name_list ) )?
                    int alt8=2;
                    int LA8_0 = input.LA(1);

                    if ( (LA8_0==IMPLEMENTS_T) ) {
                        alt8=1;
                    }
                    switch (alt8) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:182:48: ^( IMPLEMENTS_T fully_qualified_class_name_list )
                            {
                            _last = (SLAST)input.LT(1);
                            {
                            SLAST _save_last_2 = _last;
                            SLAST _first_2 = null;
                            SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                            IMPLEMENTS_T19=(SLAST)match(input,IMPLEMENTS_T,FOLLOW_IMPLEMENTS_T_in_class_declaration_statement261); 
                            IMPLEMENTS_T19_tree = (SLAST)adaptor.dupNode(IMPLEMENTS_T19);

                            root_2 = (SLAST)adaptor.becomeRoot(IMPLEMENTS_T19_tree, root_2);



                            match(input, Token.DOWN, null); 
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_fully_qualified_class_name_list_in_class_declaration_statement263);
                            fully_qualified_class_name_list20=fully_qualified_class_name_list();

                            state._fsp--;

                            adaptor.addChild(root_2, fully_qualified_class_name_list20.getTree());

                            match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
                            }


                            }
                            break;

                    }

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:183:7: ( ^( CLASS_BODY class_statement_list ) )?
                    int alt9=2;
                    int LA9_0 = input.LA(1);

                    if ( (LA9_0==CLASS_BODY) ) {
                        alt9=1;
                    }
                    switch (alt9) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:183:8: ^( CLASS_BODY class_statement_list )
                            {
                            _last = (SLAST)input.LT(1);
                            {
                            SLAST _save_last_2 = _last;
                            SLAST _first_2 = null;
                            SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                            CLASS_BODY21=(SLAST)match(input,CLASS_BODY,FOLLOW_CLASS_BODY_in_class_declaration_statement276); 
                            CLASS_BODY21_tree = (SLAST)adaptor.dupNode(CLASS_BODY21);

                            root_2 = (SLAST)adaptor.becomeRoot(CLASS_BODY21_tree, root_2);



                            match(input, Token.DOWN, null); 
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_class_statement_list_in_class_declaration_statement278);
                            class_statement_list22=class_statement_list();

                            state._fsp--;

                            adaptor.addChild(root_2, class_statement_list22.getTree());

                            match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
                            }


                            }
                            break;

                    }


                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                          
                          TreePHP.ModifierDocPair modifier = new ModifierDocPair(Modifiers.AccDefault, null);
                          int startIndex = CLASS_T14.startIndex;
                          int endIndex = CLASS_T14.endIndex + 1;
                          if ((class_entr_type15!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(class_entr_type15.start),
                      input.getTreeAdaptor().getTokenStopIndex(class_entr_type15.start))):null) != null) {
                              if ((class_entr_type15!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(class_entr_type15.start),
                      input.getTreeAdaptor().getTokenStopIndex(class_entr_type15.start))):null).equals("abstract")) {
                                modifier = new ModifierDocPair(Modifiers.AccAbstract, null);
                              }
                          }
                          
                          CommonToken token = (CommonToken)IDENTIFIER16.token;
                          int classNameLeft = token.getStartIndex();
                          int classNameRight = token.getStopIndex() + 1;
                          String className = (IDENTIFIER16!=null?IDENTIFIER16.getText():null);
                          
                    //      retval.classDeclaration = new ClassDeclaration(startIndex ,endIndex, classNameLeft, classNameRight, modifier.modifier, className, null, null, new Block(classNameRight,classNameRight,null), null);
                    //      parser.addDeclarationStatement(retval.classDeclaration);
                    //      parser.declarations.push(retval.classDeclaration);
                          
                          TypeReference superClass = null;
                          int superClassLeft = 0;
                          int superClassRight = 0;
                          if ((fully_qualified_class_name18!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(fully_qualified_class_name18.start),
                      input.getTreeAdaptor().getTokenStopIndex(fully_qualified_class_name18.start))):null) != null) {
                              superClassLeft = ((CommonToken)(fully_qualified_class_name18!=null?((SLAST)fully_qualified_class_name18.tree):null).token).getStartIndex();
                              superClassRight = ((CommonToken)(fully_qualified_class_name18!=null?((SLAST)fully_qualified_class_name18.tree):null).token).getStopIndex() + 1;
                              superClass = (fully_qualified_class_name18!=null?fully_qualified_class_name18.type:null);
                          }
                          
                          List interfaces = null;
                          int interfacesLeft = 0;
                          int interfacesRight = 0;
                          if ((fully_qualified_class_name_list20!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(fully_qualified_class_name_list20.start),
                      input.getTreeAdaptor().getTokenStopIndex(fully_qualified_class_name_list20.start))):null) != null) {
                              interfacesLeft = ((CommonToken)(fully_qualified_class_name_list20!=null?((SLAST)fully_qualified_class_name_list20.tree):null).token).getStartIndex();
                              interfacesRight = ((CommonToken)(fully_qualified_class_name_list20!=null?((SLAST)fully_qualified_class_name_list20.tree):null).token).getStopIndex() + 1;
                          }
                          
                          retval.classDeclaration = (ClassDeclaration)parser.declarations.pop();
                    		  if (superClass != null) {
                    		    retval.classDeclaration.setSuperClass(superClass);
                    		  }
                    		  if (interfaces != null) {
                    		    retval.classDeclaration.setInterfaceList(interfaces);
                    		  }
                        

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:229:5: ^( INTERFACE_T IDENTIFIER ( ^( EXTENDS_T fully_qualified_class_name_list ) )? ( ^( CLASS_BODY class_statement_list ) )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    INTERFACE_T23=(SLAST)match(input,INTERFACE_T,FOLLOW_INTERFACE_T_in_class_declaration_statement295); 
                    INTERFACE_T23_tree = (SLAST)adaptor.dupNode(INTERFACE_T23);

                    root_1 = (SLAST)adaptor.becomeRoot(INTERFACE_T23_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    IDENTIFIER24=(SLAST)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_class_declaration_statement297); 
                    IDENTIFIER24_tree = (SLAST)adaptor.dupNode(IDENTIFIER24);

                    adaptor.addChild(root_1, IDENTIFIER24_tree);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:229:30: ( ^( EXTENDS_T fully_qualified_class_name_list ) )?
                    int alt10=2;
                    int LA10_0 = input.LA(1);

                    if ( (LA10_0==EXTENDS_T) ) {
                        alt10=1;
                    }
                    switch (alt10) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:229:31: ^( EXTENDS_T fully_qualified_class_name_list )
                            {
                            _last = (SLAST)input.LT(1);
                            {
                            SLAST _save_last_2 = _last;
                            SLAST _first_2 = null;
                            SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                            EXTENDS_T25=(SLAST)match(input,EXTENDS_T,FOLLOW_EXTENDS_T_in_class_declaration_statement301); 
                            EXTENDS_T25_tree = (SLAST)adaptor.dupNode(EXTENDS_T25);

                            root_2 = (SLAST)adaptor.becomeRoot(EXTENDS_T25_tree, root_2);



                            match(input, Token.DOWN, null); 
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_fully_qualified_class_name_list_in_class_declaration_statement303);
                            fully_qualified_class_name_list26=fully_qualified_class_name_list();

                            state._fsp--;

                            adaptor.addChild(root_2, fully_qualified_class_name_list26.getTree());

                            match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
                            }


                            }
                            break;

                    }


                          
                        
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:233:7: ( ^( CLASS_BODY class_statement_list ) )?
                    int alt11=2;
                    int LA11_0 = input.LA(1);

                    if ( (LA11_0==CLASS_BODY) ) {
                        alt11=1;
                    }
                    switch (alt11) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:233:8: ^( CLASS_BODY class_statement_list )
                            {
                            _last = (SLAST)input.LT(1);
                            {
                            SLAST _save_last_2 = _last;
                            SLAST _first_2 = null;
                            SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                            CLASS_BODY27=(SLAST)match(input,CLASS_BODY,FOLLOW_CLASS_BODY_in_class_declaration_statement322); 
                            CLASS_BODY27_tree = (SLAST)adaptor.dupNode(CLASS_BODY27);

                            root_2 = (SLAST)adaptor.becomeRoot(CLASS_BODY27_tree, root_2);



                            match(input, Token.DOWN, null); 
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_class_statement_list_in_class_declaration_statement324);
                            class_statement_list28=class_statement_list();

                            state._fsp--;

                            adaptor.addChild(root_2, class_statement_list28.getTree());

                            match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
                            }


                            }
                            break;

                    }


                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                       
                       

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "class_declaration_statement"

    public static class class_entr_type_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "class_entr_type"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:240:1: class_entr_type : ( 'abstract' | 'final' );
    public final TreePHP.class_entr_type_return class_entr_type() throws RecognitionException {
        TreePHP.class_entr_type_return retval = new TreePHP.class_entr_type_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST set29=null;

        SLAST set29_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:241:3: ( 'abstract' | 'final' )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            set29=(SLAST)input.LT(1);
            if ( (input.LA(1)>=167 && input.LA(1)<=168) ) {
                input.consume();

                set29_tree = (SLAST)adaptor.dupNode(set29);

                adaptor.addChild(root_0, set29_tree);

                state.errorRecovery=false;
            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                throw mse;
            }

             

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "class_entr_type"

    public static class class_statement_list_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "class_statement_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:245:1: class_statement_list : ( class_statement )+ ;
    public final TreePHP.class_statement_list_return class_statement_list() throws RecognitionException {
        TreePHP.class_statement_list_return retval = new TreePHP.class_statement_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.class_statement_return class_statement30 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:246:3: ( ( class_statement )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:246:5: ( class_statement )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:246:5: ( class_statement )+
            int cnt13=0;
            loop13:
            do {
                int alt13=2;
                int LA13_0 = input.LA(1);

                if ( ((LA13_0>=FIELD_DECL && LA13_0<=METHOD_DECL)) ) {
                    alt13=1;
                }


                switch (alt13) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:246:5: class_statement
            	    {
            	    _last = (SLAST)input.LT(1);
            	    pushFollow(FOLLOW_class_statement_in_class_statement_list373);
            	    class_statement30=class_statement();

            	    state._fsp--;

            	    adaptor.addChild(root_0, class_statement30.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt13 >= 1 ) break loop13;
                        EarlyExitException eee =
                            new EarlyExitException(13, input);
                        throw eee;
                }
                cnt13++;
            } while (true);


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "class_statement_list"

    protected static class class_statement_scope {
        List constList;
        List varList;
    }
    protected Stack class_statement_stack = new Stack();

    public static class class_statement_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "class_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:249:1: class_statement : ( ^( FIELD_DECL variable_modifiers ( static_var_element )+ ) | ^( METHOD_DECL modifier ( REF_T )? IDENTIFIER ( parameter_list )? ( block | EMPTYSTATEMENT ) ) | ^( FIELD_DECL CONST_T ( directive )+ ) );
    public final TreePHP.class_statement_return class_statement() throws RecognitionException {
        class_statement_stack.push(new class_statement_scope());
        TreePHP.class_statement_return retval = new TreePHP.class_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST FIELD_DECL31=null;
        SLAST METHOD_DECL34=null;
        SLAST REF_T36=null;
        SLAST IDENTIFIER37=null;
        SLAST EMPTYSTATEMENT40=null;
        SLAST FIELD_DECL41=null;
        SLAST CONST_T42=null;
        TreePHP.variable_modifiers_return variable_modifiers32 = null;

        TreePHP.static_var_element_return static_var_element33 = null;

        TreePHP.modifier_return modifier35 = null;

        TreePHP.parameter_list_return parameter_list38 = null;

        TreePHP.block_return block39 = null;

        TreePHP.directive_return directive43 = null;


        SLAST FIELD_DECL31_tree=null;
        SLAST METHOD_DECL34_tree=null;
        SLAST REF_T36_tree=null;
        SLAST IDENTIFIER37_tree=null;
        SLAST EMPTYSTATEMENT40_tree=null;
        SLAST FIELD_DECL41_tree=null;
        SLAST CONST_T42_tree=null;


          ((class_statement_scope)class_statement_stack.peek()).constList = new LinkedList();
          ((class_statement_scope)class_statement_stack.peek()).varList = new LinkedList();

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:258:3: ( ^( FIELD_DECL variable_modifiers ( static_var_element )+ ) | ^( METHOD_DECL modifier ( REF_T )? IDENTIFIER ( parameter_list )? ( block | EMPTYSTATEMENT ) ) | ^( FIELD_DECL CONST_T ( directive )+ ) )
            int alt19=3;
            int LA19_0 = input.LA(1);

            if ( (LA19_0==FIELD_DECL) ) {
                int LA19_1 = input.LA(2);

                if ( (LA19_1==DOWN) ) {
                    int LA19_3 = input.LA(3);

                    if ( (LA19_3==VAR_DECL||LA19_3==STATIC_T||LA19_3==EQUAL_T||(LA19_3>=167 && LA19_3<=172)) ) {
                        alt19=1;
                    }
                    else if ( (LA19_3==CONST_T) ) {
                        alt19=3;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 19, 3, input);

                        throw nvae;
                    }
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 19, 1, input);

                    throw nvae;
                }
            }
            else if ( (LA19_0==METHOD_DECL) ) {
                alt19=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 19, 0, input);

                throw nvae;
            }
            switch (alt19) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:258:5: ^( FIELD_DECL variable_modifiers ( static_var_element )+ )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    FIELD_DECL31=(SLAST)match(input,FIELD_DECL,FOLLOW_FIELD_DECL_in_class_statement398); 
                    FIELD_DECL31_tree = (SLAST)adaptor.dupNode(FIELD_DECL31);

                    root_1 = (SLAST)adaptor.becomeRoot(FIELD_DECL31_tree, root_1);


                    inClassStatementList = true;

                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_variable_modifiers_in_class_statement402);
                    variable_modifiers32=variable_modifiers();

                    state._fsp--;

                    adaptor.addChild(root_1, variable_modifiers32.getTree());
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:258:68: ( static_var_element )+
                    int cnt14=0;
                    loop14:
                    do {
                        int alt14=2;
                        int LA14_0 = input.LA(1);

                        if ( (LA14_0==VAR_DECL||LA14_0==EQUAL_T) ) {
                            alt14=1;
                        }


                        switch (alt14) {
                    	case 1 :
                    	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:258:68: static_var_element
                    	    {
                    	    _last = (SLAST)input.LT(1);
                    	    pushFollow(FOLLOW_static_var_element_in_class_statement404);
                    	    static_var_element33=static_var_element();

                    	    state._fsp--;

                    	    adaptor.addChild(root_1, static_var_element33.getTree());

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt14 >= 1 ) break loop14;
                                EarlyExitException eee =
                                    new EarlyExitException(14, input);
                                throw eee;
                        }
                        cnt14++;
                    } while (true);

                    inClassStatementList = false;

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        ModifierDocPair modifier = new ModifierDocPair(Modifiers.AccDefault, null);
                        int modifierLeft = ((CommonToken)(variable_modifiers32!=null?((SLAST)variable_modifiers32.tree):null).token).getStartIndex();
                        if ((variable_modifiers32!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(variable_modifiers32.start),
                      input.getTreeAdaptor().getTokenStopIndex(variable_modifiers32.start))):null).equals("var")) {
                          modifier = new ModifierDocPair(Modifiers.AccPublic, null);
                        }
                        
                        Iterator iter = ((class_statement_scope)class_statement_stack.peek()).varList.iterator();
                        while (iter.hasNext()) {
                    	    ASTNode[] decl = (ASTNode[])iter.next();
                    	    if (decl != null) {
                    		    VariableReference variable = (VariableReference)decl[0];
                    		    Expression initializer = (Expression)decl[1];
                    		    int start = variable.sourceStart();
                    		    int end = (initializer == null ? variable.sourceEnd() : initializer.sourceEnd());
                    		    parser.addDeclarationStatement(new PHPFieldDeclaration(variable, initializer, start, end, modifier.modifier, modifierLeft, modifier.doc));
                    		  }
                    		}
                      

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:278:5: ^( METHOD_DECL modifier ( REF_T )? IDENTIFIER ( parameter_list )? ( block | EMPTYSTATEMENT ) )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    METHOD_DECL34=(SLAST)match(input,METHOD_DECL,FOLLOW_METHOD_DECL_in_class_statement419); 
                    METHOD_DECL34_tree = (SLAST)adaptor.dupNode(METHOD_DECL34);

                    root_1 = (SLAST)adaptor.becomeRoot(METHOD_DECL34_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_modifier_in_class_statement421);
                    modifier35=modifier();

                    state._fsp--;

                    adaptor.addChild(root_1, modifier35.getTree());
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:278:28: ( REF_T )?
                    int alt15=2;
                    int LA15_0 = input.LA(1);

                    if ( (LA15_0==REF_T) ) {
                        alt15=1;
                    }
                    switch (alt15) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:278:28: REF_T
                            {
                            _last = (SLAST)input.LT(1);
                            REF_T36=(SLAST)match(input,REF_T,FOLLOW_REF_T_in_class_statement423); 
                            REF_T36_tree = (SLAST)adaptor.dupNode(REF_T36);

                            adaptor.addChild(root_1, REF_T36_tree);


                            }
                            break;

                    }

                    _last = (SLAST)input.LT(1);
                    IDENTIFIER37=(SLAST)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_class_statement426); 
                    IDENTIFIER37_tree = (SLAST)adaptor.dupNode(IDENTIFIER37);

                    adaptor.addChild(root_1, IDENTIFIER37_tree);


                          ModifierDocPair modifier = (modifier35!=null?modifier35.modifierVar:null);
                          PHPDocBlock start = null;
                          Boolean isReference = false;
                          if ((REF_T36!=null?REF_T36.getText():null) != null) {
                             isReference = true;
                          }
                          int functionNameLeft = ((CommonToken)IDENTIFIER37.token).getStartIndex();
                          int functionNameRight = ((CommonToken)IDENTIFIER37.token).getStopIndex() + 1;
                          String functionName = (IDENTIFIER37!=null?IDENTIFIER37.getText():null);
                      
                          int startIndex = METHOD_DECL34.startIndex;
                          int endIndex = METHOD_DECL34.endIndex + 1;
                          int modifierValue = modifier == null ? Modifiers.AccPublic : modifier.modifier;
                          
                          PHPDocBlock docBlock = start;
                          if (modifier != null && modifier.doc != null) {
                            docBlock = modifier.doc;
                          }
                          PHPMethodDeclaration methodDeclaration = new PHPMethodDeclaration(startIndex, endIndex, startIndex, endIndex, functionName, modifierValue, null, new Block(startIndex, endIndex, null), isReference.booleanValue(), docBlock);
                          parser.addDeclarationStatement(methodDeclaration);
                          parser.declarations.push(methodDeclaration);
                        
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:302:7: ( parameter_list )?
                    int alt16=2;
                    int LA16_0 = input.LA(1);

                    if ( (LA16_0==PARAMETER) ) {
                        alt16=1;
                    }
                    switch (alt16) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:302:7: parameter_list
                            {
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_parameter_list_in_class_statement440);
                            parameter_list38=parameter_list();

                            state._fsp--;

                            adaptor.addChild(root_1, parameter_list38.getTree());

                            }
                            break;

                    }


                            if ((parameter_list38!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(parameter_list38.start),
                      input.getTreeAdaptor().getTokenStopIndex(parameter_list38.start))):null) != null) {
                              PHPMethodDeclaration functionDeclaration = (PHPMethodDeclaration)parser.declarations.peek();
                    				  functionDeclaration.acceptArguments((parameter_list38!=null?parameter_list38.parameterList:null));
                            }
                          
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:309:5: ( block | EMPTYSTATEMENT )
                    int alt17=2;
                    int LA17_0 = input.LA(1);

                    if ( (LA17_0==BLOCK) ) {
                        alt17=1;
                    }
                    else if ( (LA17_0==EMPTYSTATEMENT) ) {
                        alt17=2;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 17, 0, input);

                        throw nvae;
                    }
                    switch (alt17) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:309:6: block
                            {
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_block_in_class_statement456);
                            block39=block();

                            state._fsp--;

                            adaptor.addChild(root_1, block39.getTree());

                                    startIndex = ((CommonToken)(block39!=null?((SLAST)block39.tree):null).token).getStartIndex();
                            		    endIndex = ((CommonToken)(block39!=null?((SLAST)block39.tree):null).token).getStopIndex() + 1;
                            		    
                            		    methodDeclaration = (PHPMethodDeclaration)parser.declarations.peek();
                            			  methodDeclaration.getBody().setStart(startIndex);
                            			  methodDeclaration.getBody().setEnd(endIndex);
                            			  methodDeclaration.getBody().getStatements().clear();
                            			  methodDeclaration.getBody().acceptStatements((block39!=null?block39.statList:null));
                            			  
                            			  methodDeclaration = (PHPMethodDeclaration)parser.declarations.pop();
                            //			  if(body instanceof ASTError) {
                            //			    parser.reportError(new ASTError(methodDeclaration.sourceEnd() - 1, methodDeclaration.sourceEnd()), "syntax error, unfinished method declaration");
                            //			  }
                            			  TypeDeclaration type = (TypeDeclaration)parser.declarations.peek();
                            			  methodDeclaration.setDeclaringTypeName(type.getName()); 
                                 

                            }
                            break;
                        case 2 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:328:5: EMPTYSTATEMENT
                            {
                            _last = (SLAST)input.LT(1);
                            EMPTYSTATEMENT40=(SLAST)match(input,EMPTYSTATEMENT,FOLLOW_EMPTYSTATEMENT_in_class_statement475); 
                            EMPTYSTATEMENT40_tree = (SLAST)adaptor.dupNode(EMPTYSTATEMENT40);

                            adaptor.addChild(root_1, EMPTYSTATEMENT40_tree);

                               
                                    startIndex = ((CommonToken)EMPTYSTATEMENT40.token).getStartIndex();
                                    endIndex = ((CommonToken)EMPTYSTATEMENT40.token).getStopIndex() + 1;
                                    
                                    methodDeclaration = (PHPMethodDeclaration)parser.declarations.peek();
                                    methodDeclaration.getBody().setStart(startIndex);
                                    methodDeclaration.getBody().setEnd(endIndex);
                                    methodDeclaration.getBody().getStatements().clear();
                                    methodDeclaration.getBody().acceptStatements(new LinkedList());
                                    
                                    methodDeclaration = (PHPMethodDeclaration)parser.declarations.pop();
                            //        if(body instanceof ASTError) {
                            //          parser.reportError(new ASTError(methodDeclaration.sourceEnd() - 1, methodDeclaration.sourceEnd()), "syntax error, unfinished method declaration");
                            //        }
                                    TypeDeclaration type = (TypeDeclaration)parser.declarations.peek();
                                    methodDeclaration.setDeclaringTypeName(type.getName()); 
                                 

                            }
                            break;

                    }


                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 3 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:347:5: ^( FIELD_DECL CONST_T ( directive )+ )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    FIELD_DECL41=(SLAST)match(input,FIELD_DECL,FOLLOW_FIELD_DECL_in_class_statement498); 
                    FIELD_DECL41_tree = (SLAST)adaptor.dupNode(FIELD_DECL41);

                    root_1 = (SLAST)adaptor.becomeRoot(FIELD_DECL41_tree, root_1);


                    inClassStatementList = true;

                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    CONST_T42=(SLAST)match(input,CONST_T,FOLLOW_CONST_T_in_class_statement502); 
                    CONST_T42_tree = (SLAST)adaptor.dupNode(CONST_T42);

                    adaptor.addChild(root_1, CONST_T42_tree);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:347:57: ( directive )+
                    int cnt18=0;
                    loop18:
                    do {
                        int alt18=2;
                        int LA18_0 = input.LA(1);

                        if ( (LA18_0==EQUAL_T) ) {
                            alt18=1;
                        }


                        switch (alt18) {
                    	case 1 :
                    	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:347:57: directive
                    	    {
                    	    _last = (SLAST)input.LT(1);
                    	    pushFollow(FOLLOW_directive_in_class_statement504);
                    	    directive43=directive();

                    	    state._fsp--;

                    	    adaptor.addChild(root_1, directive43.getTree());

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt18 >= 1 ) break loop18;
                                EarlyExitException eee =
                                    new EarlyExitException(18, input);
                                throw eee;
                        }
                        cnt18++;
                    } while (true);

                    inClassStatementList = false;

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = FIELD_DECL41.startIndex;
                        int endIndex = FIELD_DECL41.endIndex;
                        Iterator iter = ((class_statement_scope)class_statement_stack.peek()).constList.iterator();
                        while (iter.hasNext()) {
                          ASTNode[] decl = (ASTNode[])iter.next();
                    	    if (decl != null) {
                    		    ConstantReference constant = (ConstantReference)decl[0];
                    		    Expression initializer = (Expression)decl[1];
                    		    int decListLeft = ((CommonToken)(directive43!=null?((SLAST)directive43.tree):null).token).getStartIndex();
                    		      
                    		    PHPDocBlock docBlock = null;
                    		    if (decl.length == 3) {
                    		      docBlock = (PHPDocBlock)decl[2];
                    		    }
                    		    int start = constant.sourceStart();
                    		    int end = (initializer == null ? constant.sourceEnd() : initializer.sourceEnd());
                    		    parser.addDeclarationStatement(new ConstantDeclaration(constant, initializer, startIndex, end, docBlock));
                    		  }
                    		}
                      

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
            class_statement_stack.pop();
        }
        return retval;
    }
    // $ANTLR end "class_statement"

    public static class function_declaration_statement_return extends TreeRuleReturnScope {
        public Statement stat;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "function_declaration_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:371:1: function_declaration_statement returns [Statement stat] : ^( METHOD_DECL ( REF_T )? IDENTIFIER ( parameter_list )? block ) ;
    public final TreePHP.function_declaration_statement_return function_declaration_statement() throws RecognitionException {
        TreePHP.function_declaration_statement_return retval = new TreePHP.function_declaration_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST METHOD_DECL44=null;
        SLAST REF_T45=null;
        SLAST IDENTIFIER46=null;
        TreePHP.parameter_list_return parameter_list47 = null;

        TreePHP.block_return block48 = null;


        SLAST METHOD_DECL44_tree=null;
        SLAST REF_T45_tree=null;
        SLAST IDENTIFIER46_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:372:3: ( ^( METHOD_DECL ( REF_T )? IDENTIFIER ( parameter_list )? block ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:372:5: ^( METHOD_DECL ( REF_T )? IDENTIFIER ( parameter_list )? block )
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_1 = _last;
            SLAST _first_1 = null;
            SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            METHOD_DECL44=(SLAST)match(input,METHOD_DECL,FOLLOW_METHOD_DECL_in_function_declaration_statement530); 
            METHOD_DECL44_tree = (SLAST)adaptor.dupNode(METHOD_DECL44);

            root_1 = (SLAST)adaptor.becomeRoot(METHOD_DECL44_tree, root_1);



            match(input, Token.DOWN, null); 
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:372:19: ( REF_T )?
            int alt20=2;
            int LA20_0 = input.LA(1);

            if ( (LA20_0==REF_T) ) {
                alt20=1;
            }
            switch (alt20) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:372:19: REF_T
                    {
                    _last = (SLAST)input.LT(1);
                    REF_T45=(SLAST)match(input,REF_T,FOLLOW_REF_T_in_function_declaration_statement532); 
                    REF_T45_tree = (SLAST)adaptor.dupNode(REF_T45);

                    adaptor.addChild(root_1, REF_T45_tree);


                    }
                    break;

            }

            _last = (SLAST)input.LT(1);
            IDENTIFIER46=(SLAST)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_function_declaration_statement535); 
            IDENTIFIER46_tree = (SLAST)adaptor.dupNode(IDENTIFIER46);

            adaptor.addChild(root_1, IDENTIFIER46_tree);


                Boolean isReference = false;
                if ((REF_T45!=null?REF_T45.getText():null) != null) {
                   isReference = true;
                }
                int functionNameLeft = ((CommonToken)IDENTIFIER46.token).getStartIndex();
                int functionNameRight = ((CommonToken)IDENTIFIER46.token).getStopIndex() + 1;
                String functionName = (IDENTIFIER46!=null?IDENTIFIER46.getText():null);
              
                int startIndex = METHOD_DECL44.startIndex;
                int endIndex = METHOD_DECL44.endIndex + 1;
                int modifierValue = Modifiers.AccDefault;
                  
                PHPDocBlock docBlock = null;
                
                PHPMethodDeclaration methodDeclaration = new PHPMethodDeclaration(startIndex, endIndex, startIndex, endIndex, functionName, modifierValue, null, new Block(startIndex, endIndex, null), isReference.booleanValue(), docBlock);
                parser.addDeclarationStatement(methodDeclaration);
                parser.declarations.push(methodDeclaration);
              
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:392:4: ( parameter_list )?
            int alt21=2;
            int LA21_0 = input.LA(1);

            if ( (LA21_0==PARAMETER) ) {
                alt21=1;
            }
            switch (alt21) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:392:4: parameter_list
                    {
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_parameter_list_in_function_declaration_statement544);
                    parameter_list47=parameter_list();

                    state._fsp--;

                    adaptor.addChild(root_1, parameter_list47.getTree());

                    }
                    break;

            }


                  if ((parameter_list47!=null?(input.getTokenStream().toString(
              input.getTreeAdaptor().getTokenStartIndex(parameter_list47.start),
              input.getTreeAdaptor().getTokenStopIndex(parameter_list47.start))):null) != null) {
                    PHPMethodDeclaration functionDeclaration = (PHPMethodDeclaration)parser.declarations.peek();
                    functionDeclaration.acceptArguments((parameter_list47!=null?parameter_list47.parameterList:null));
                  }
               
            _last = (SLAST)input.LT(1);
            pushFollow(FOLLOW_block_in_function_declaration_statement557);
            block48=block();

            state._fsp--;

            adaptor.addChild(root_1, block48.getTree());

                startIndex = ((CommonToken)(block48!=null?((SLAST)block48.tree):null).token).getStartIndex();
                endIndex = ((CommonToken)(block48!=null?((SLAST)block48.tree):null).token).getStopIndex() + 1;
                    
                methodDeclaration = (PHPMethodDeclaration)parser.declarations.peek();
                methodDeclaration.getBody().setStart(startIndex);
                methodDeclaration.getBody().setEnd(endIndex);
                methodDeclaration.getBody().getStatements().clear();
                methodDeclaration.getBody().acceptStatements((block48!=null?block48.statList:null));
                    
                methodDeclaration = (PHPMethodDeclaration)parser.declarations.pop();
            //        if(body instanceof ASTError) {
            //          parser.reportError(new ASTError(methodDeclaration.sourceEnd() - 1, methodDeclaration.sourceEnd()), "syntax error, unfinished method declaration");
            //        }
            //    TypeDeclaration type = (TypeDeclaration)parser.declarations.peek();
            //    methodDeclaration.setDeclaringTypeName(type.getName());
                retval.stat = methodDeclaration;
                System.out.println("here" + retval.stat);
              

            match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "function_declaration_statement"

    public static class block_return extends TreeRuleReturnScope {
        public Statement stat;
        public List statList;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "block"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:424:1: block returns [Statement stat, List statList] : ^( BLOCK ( inner_statement_list )? ) ;
    public final TreePHP.block_return block() throws RecognitionException {
        TreePHP.block_return retval = new TreePHP.block_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST BLOCK49=null;
        TreePHP.inner_statement_list_return inner_statement_list50 = null;


        SLAST BLOCK49_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:425:3: ( ^( BLOCK ( inner_statement_list )? ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:425:5: ^( BLOCK ( inner_statement_list )? )
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_1 = _last;
            SLAST _first_1 = null;
            SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            BLOCK49=(SLAST)match(input,BLOCK,FOLLOW_BLOCK_in_block592); 
            BLOCK49_tree = (SLAST)adaptor.dupNode(BLOCK49);

            root_1 = (SLAST)adaptor.becomeRoot(BLOCK49_tree, root_1);



            if ( input.LA(1)==Token.DOWN ) {
                match(input, Token.DOWN, null); 
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:425:13: ( inner_statement_list )?
                int alt22=2;
                int LA22_0 = input.LA(1);

                if ( (LA22_0==METHOD_DECL||LA22_0==STATEMENT||LA22_0==CLASS_T||LA22_0==INTERFACE_T||LA22_0==166) ) {
                    alt22=1;
                }
                switch (alt22) {
                    case 1 :
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:425:13: inner_statement_list
                        {
                        _last = (SLAST)input.LT(1);
                        pushFollow(FOLLOW_inner_statement_list_in_block594);
                        inner_statement_list50=inner_statement_list();

                        state._fsp--;

                        adaptor.addChild(root_1, inner_statement_list50.getTree());

                        }
                        break;

                }


                match(input, Token.UP, null); 
            }adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


                  int startIndex = -1;
                  int endIndex = -1;
                  Block block = new Block(startIndex, endIndex, new LinkedList());
                  if ((inner_statement_list50!=null?inner_statement_list50.innerStatementList:null) != null) {
                    block.getStatements().clear();
                    block.acceptStatements((inner_statement_list50!=null?inner_statement_list50.innerStatementList:null));
                    retval.statList = (inner_statement_list50!=null?inner_statement_list50.innerStatementList:null);
                  }
                  else {
                    retval.statList = new LinkedList();
                  }
                  retval.stat = block;
                

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "block"

    public static class statement_return extends TreeRuleReturnScope {
        public Statement stat;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:442:1: statement returns [Statement stat] : ^( STATEMENT topStatement ) ;
    public final TreePHP.statement_return statement() throws RecognitionException {
        TreePHP.statement_return retval = new TreePHP.statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST STATEMENT51=null;
        TreePHP.topStatement_return topStatement52 = null;


        SLAST STATEMENT51_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:443:3: ( ^( STATEMENT topStatement ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:443:5: ^( STATEMENT topStatement )
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_1 = _last;
            SLAST _first_1 = null;
            SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            STATEMENT51=(SLAST)match(input,STATEMENT,FOLLOW_STATEMENT_in_statement623); 
            STATEMENT51_tree = (SLAST)adaptor.dupNode(STATEMENT51);

            root_1 = (SLAST)adaptor.becomeRoot(STATEMENT51_tree, root_1);



            match(input, Token.DOWN, null); 
            _last = (SLAST)input.LT(1);
            pushFollow(FOLLOW_topStatement_in_statement625);
            topStatement52=topStatement();

            state._fsp--;

            adaptor.addChild(root_1, topStatement52.getTree());

            match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


                if ((topStatement52!=null?topStatement52.expr:null) != null) {
            	    int startIndex = STATEMENT51.startIndex;
            	    int endIndex = STATEMENT51.endIndex + 1;
            	    retval.stat = new ExpressionStatement(startIndex, endIndex, (topStatement52!=null?topStatement52.expr:null));
            	    System.out.println("retval.stat:" + retval.stat);
                }
                else {
                  retval.stat = (topStatement52!=null?topStatement52.stat:null);
                }
              

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "statement"

    protected static class topStatement_scope {
        List declareKey;
        List declareValue;
    }
    protected Stack topStatement_stack = new Stack();

    public static class topStatement_return extends TreeRuleReturnScope {
        public Expression expr;
        public Statement stat;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "topStatement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:457:1: topStatement returns [Expression expr, Statement stat] : ( block | if_stat | ^( WHILE_T ^( CONDITION e= expression ) while_statement ) | ^( DO_T ^( CONDITION e= expression ) statement ) | ^( FOR_T (e1= expr_list )? ^( CONDITION (e2= expr_list )? ) ^( ITERATE (e3= expr_list )? ) s1= for_statement ) | ^( SWITCH_T ^( CONDITION e= expression ) switch_case_list ) | ^( BREAK_T ( expression )? ) | ^( CONTINUE_T (e= expression )? ) | ^( RETURN_T (e= expression )? ) | ^( GLOBAL_T variable_list ) | ^( STATIC_T static_var_list ) | ^( ECHO_T expr_list ) | ^( EMPTYSTATEMENT SEMI_COLON ) | expression | ^( FOREACH_T ^( AS_T e= expression v1= foreach_variable (v2= foreach_variable )? ) foreach_statement ) | ^( DECLARE_T directive declare_statement ) | ^( TRY_T block catch_branch_list ) | ^( THROW_T e= expression ) | ^( USE_T use_filename ) | ^( INCLUDE_T e= expression ) | ^( INCLUDE_ONCE_T e= expression ) | ^( REQUIRE_T e= expression ) | ^( REQUIRE_ONCE_T e= expression ) );
    public final TreePHP.topStatement_return topStatement() throws RecognitionException {
        topStatement_stack.push(new topStatement_scope());
        TreePHP.topStatement_return retval = new TreePHP.topStatement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST WHILE_T55=null;
        SLAST CONDITION56=null;
        SLAST DO_T58=null;
        SLAST CONDITION59=null;
        SLAST FOR_T61=null;
        SLAST CONDITION62=null;
        SLAST ITERATE63=null;
        SLAST SWITCH_T64=null;
        SLAST CONDITION65=null;
        SLAST BREAK_T67=null;
        SLAST CONTINUE_T69=null;
        SLAST RETURN_T70=null;
        SLAST GLOBAL_T71=null;
        SLAST STATIC_T73=null;
        SLAST ECHO_T75=null;
        SLAST EMPTYSTATEMENT77=null;
        SLAST SEMI_COLON78=null;
        SLAST FOREACH_T80=null;
        SLAST AS_T81=null;
        SLAST DECLARE_T83=null;
        SLAST TRY_T86=null;
        SLAST THROW_T89=null;
        SLAST USE_T90=null;
        SLAST INCLUDE_T92=null;
        SLAST INCLUDE_ONCE_T93=null;
        SLAST REQUIRE_T94=null;
        SLAST REQUIRE_ONCE_T95=null;
        TreePHP.expression_return e = null;

        TreePHP.expr_list_return e1 = null;

        TreePHP.expr_list_return e2 = null;

        TreePHP.expr_list_return e3 = null;

        TreePHP.for_statement_return s1 = null;

        TreePHP.foreach_variable_return v1 = null;

        TreePHP.foreach_variable_return v2 = null;

        TreePHP.block_return block53 = null;

        TreePHP.if_stat_return if_stat54 = null;

        TreePHP.while_statement_return while_statement57 = null;

        TreePHP.statement_return statement60 = null;

        TreePHP.switch_case_list_return switch_case_list66 = null;

        TreePHP.expression_return expression68 = null;

        TreePHP.variable_list_return variable_list72 = null;

        TreePHP.static_var_list_return static_var_list74 = null;

        TreePHP.expr_list_return expr_list76 = null;

        TreePHP.expression_return expression79 = null;

        TreePHP.foreach_statement_return foreach_statement82 = null;

        TreePHP.directive_return directive84 = null;

        TreePHP.declare_statement_return declare_statement85 = null;

        TreePHP.block_return block87 = null;

        TreePHP.catch_branch_list_return catch_branch_list88 = null;

        TreePHP.use_filename_return use_filename91 = null;


        SLAST WHILE_T55_tree=null;
        SLAST CONDITION56_tree=null;
        SLAST DO_T58_tree=null;
        SLAST CONDITION59_tree=null;
        SLAST FOR_T61_tree=null;
        SLAST CONDITION62_tree=null;
        SLAST ITERATE63_tree=null;
        SLAST SWITCH_T64_tree=null;
        SLAST CONDITION65_tree=null;
        SLAST BREAK_T67_tree=null;
        SLAST CONTINUE_T69_tree=null;
        SLAST RETURN_T70_tree=null;
        SLAST GLOBAL_T71_tree=null;
        SLAST STATIC_T73_tree=null;
        SLAST ECHO_T75_tree=null;
        SLAST EMPTYSTATEMENT77_tree=null;
        SLAST SEMI_COLON78_tree=null;
        SLAST FOREACH_T80_tree=null;
        SLAST AS_T81_tree=null;
        SLAST DECLARE_T83_tree=null;
        SLAST TRY_T86_tree=null;
        SLAST THROW_T89_tree=null;
        SLAST USE_T90_tree=null;
        SLAST INCLUDE_T92_tree=null;
        SLAST INCLUDE_ONCE_T93_tree=null;
        SLAST REQUIRE_T94_tree=null;
        SLAST REQUIRE_ONCE_T95_tree=null;


          ((topStatement_scope)topStatement_stack.peek()).declareKey = new LinkedList();
          ((topStatement_scope)topStatement_stack.peek()).declareValue = new LinkedList();

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:466:3: ( block | if_stat | ^( WHILE_T ^( CONDITION e= expression ) while_statement ) | ^( DO_T ^( CONDITION e= expression ) statement ) | ^( FOR_T (e1= expr_list )? ^( CONDITION (e2= expr_list )? ) ^( ITERATE (e3= expr_list )? ) s1= for_statement ) | ^( SWITCH_T ^( CONDITION e= expression ) switch_case_list ) | ^( BREAK_T ( expression )? ) | ^( CONTINUE_T (e= expression )? ) | ^( RETURN_T (e= expression )? ) | ^( GLOBAL_T variable_list ) | ^( STATIC_T static_var_list ) | ^( ECHO_T expr_list ) | ^( EMPTYSTATEMENT SEMI_COLON ) | expression | ^( FOREACH_T ^( AS_T e= expression v1= foreach_variable (v2= foreach_variable )? ) foreach_statement ) | ^( DECLARE_T directive declare_statement ) | ^( TRY_T block catch_branch_list ) | ^( THROW_T e= expression ) | ^( USE_T use_filename ) | ^( INCLUDE_T e= expression ) | ^( INCLUDE_ONCE_T e= expression ) | ^( REQUIRE_T e= expression ) | ^( REQUIRE_ONCE_T e= expression ) )
            int alt30=23;
            switch ( input.LA(1) ) {
            case BLOCK:
                {
                alt30=1;
                }
                break;
            case IF_T:
                {
                alt30=2;
                }
                break;
            case WHILE_T:
                {
                alt30=3;
                }
                break;
            case DO_T:
                {
                alt30=4;
                }
                break;
            case FOR_T:
                {
                alt30=5;
                }
                break;
            case SWITCH_T:
                {
                alt30=6;
                }
                break;
            case BREAK_T:
                {
                alt30=7;
                }
                break;
            case CONTINUE_T:
                {
                alt30=8;
                }
                break;
            case RETURN_T:
                {
                alt30=9;
                }
                break;
            case GLOBAL_T:
                {
                alt30=10;
                }
                break;
            case STATIC_T:
                {
                alt30=11;
                }
                break;
            case ECHO_T:
                {
                alt30=12;
                }
                break;
            case EMPTYSTATEMENT:
                {
                alt30=13;
                }
                break;
            case VAR_DECL:
            case CALL:
            case EXPR:
            case SCALAR:
            case ARRAY_DECL:
            case PREFIX_EXPR:
            case POSTFIX_EXPR:
            case CAST_EXPR:
            case UNARY_EXPR:
            case REF_T:
            case EQUAL_T:
            case OR_T:
            case XOR_T:
            case AND_T:
            case PLUS_EQ:
            case MINUS_EQ:
            case MUL_EQ:
            case DIV_EQ:
            case DOT_EQ:
            case PERCENT_EQ:
            case BIT_AND_EQ:
            case BIT_OR_EQ:
            case POWER_EQ:
            case LMOVE_EQ:
            case RMOVE_EQ:
            case QUESTION_T:
            case LOGICAL_OR_T:
            case LOGICAL_AND_T:
            case BIT_OR_T:
            case POWER_T:
            case DOT_T:
            case EQUAL_EQUAL_T:
            case NOT_EQUAL_T:
            case EQUAL_EQUAL_EQUAL_T:
            case NOT_EQUAL_EQUAL_T:
            case LT_T:
            case MT_T:
            case LE_T:
            case ME_T:
            case LSHIFT_T:
            case RSHIFT_T:
            case PLUS_T:
            case MINUS_T:
            case MUL_T:
            case DIV_T:
            case PERCENT_T:
            case CLONE_T:
            case INSTANCEOF_T:
            case AT_T:
            case LIST_T:
            case NEW_T:
            case BACKTRICKLITERAL:
            case PRINT_T:
                {
                alt30=14;
                }
                break;
            case FOREACH_T:
                {
                alt30=15;
                }
                break;
            case DECLARE_T:
                {
                alt30=16;
                }
                break;
            case TRY_T:
                {
                alt30=17;
                }
                break;
            case THROW_T:
                {
                alt30=18;
                }
                break;
            case USE_T:
                {
                alt30=19;
                }
                break;
            case INCLUDE_T:
                {
                alt30=20;
                }
                break;
            case INCLUDE_ONCE_T:
                {
                alt30=21;
                }
                break;
            case REQUIRE_T:
                {
                alt30=22;
                }
                break;
            case REQUIRE_ONCE_T:
                {
                alt30=23;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 30, 0, input);

                throw nvae;
            }

            switch (alt30) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:466:5: block
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_block_in_topStatement656);
                    block53=block();

                    state._fsp--;

                    adaptor.addChild(root_0, block53.getTree());

                        retval.stat = (block53!=null?block53.stat:null);
                      

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:470:5: if_stat
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_if_stat_in_topStatement667);
                    if_stat54=if_stat();

                    state._fsp--;

                    adaptor.addChild(root_0, if_stat54.getTree());

                        retval.stat = (if_stat54!=null?if_stat54.stat:null);
                      

                    }
                    break;
                case 3 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:474:5: ^( WHILE_T ^( CONDITION e= expression ) while_statement )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    WHILE_T55=(SLAST)match(input,WHILE_T,FOLLOW_WHILE_T_in_topStatement678); 
                    WHILE_T55_tree = (SLAST)adaptor.dupNode(WHILE_T55);

                    root_1 = (SLAST)adaptor.becomeRoot(WHILE_T55_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_2 = _last;
                    SLAST _first_2 = null;
                    SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    CONDITION56=(SLAST)match(input,CONDITION,FOLLOW_CONDITION_in_topStatement681); 
                    CONDITION56_tree = (SLAST)adaptor.dupNode(CONDITION56);

                    root_2 = (SLAST)adaptor.becomeRoot(CONDITION56_tree, root_2);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_topStatement685);
                    e=expression();

                    state._fsp--;

                    adaptor.addChild(root_2, e.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
                    }

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_while_statement_in_topStatement688);
                    while_statement57=while_statement();

                    state._fsp--;

                    adaptor.addChild(root_1, while_statement57.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = WHILE_T55.startIndex;
                        int endIndex = WHILE_T55.endIndex + 1;
                        retval.stat = new WhileStatement(startIndex, endIndex, (e!=null?e.expr:null), (while_statement57!=null?while_statement57.block:null));   
                      

                    }
                    break;
                case 4 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:481:5: ^( DO_T ^( CONDITION e= expression ) statement )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    DO_T58=(SLAST)match(input,DO_T,FOLLOW_DO_T_in_topStatement703); 
                    DO_T58_tree = (SLAST)adaptor.dupNode(DO_T58);

                    root_1 = (SLAST)adaptor.becomeRoot(DO_T58_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_2 = _last;
                    SLAST _first_2 = null;
                    SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    CONDITION59=(SLAST)match(input,CONDITION,FOLLOW_CONDITION_in_topStatement706); 
                    CONDITION59_tree = (SLAST)adaptor.dupNode(CONDITION59);

                    root_2 = (SLAST)adaptor.becomeRoot(CONDITION59_tree, root_2);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_topStatement710);
                    e=expression();

                    state._fsp--;

                    adaptor.addChild(root_2, e.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
                    }

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_statement_in_topStatement713);
                    statement60=statement();

                    state._fsp--;

                    adaptor.addChild(root_1, statement60.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = DO_T58.startIndex;
                        int endIndex = DO_T58.endIndex + 1;
                        retval.stat = new DoStatement(startIndex, endIndex, (e!=null?e.expr:null), (statement60!=null?statement60.stat:null));      
                      

                    }
                    break;
                case 5 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:487:5: ^( FOR_T (e1= expr_list )? ^( CONDITION (e2= expr_list )? ) ^( ITERATE (e3= expr_list )? ) s1= for_statement )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    FOR_T61=(SLAST)match(input,FOR_T,FOLLOW_FOR_T_in_topStatement725); 
                    FOR_T61_tree = (SLAST)adaptor.dupNode(FOR_T61);

                    root_1 = (SLAST)adaptor.becomeRoot(FOR_T61_tree, root_1);



                    match(input, Token.DOWN, null); 
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:487:15: (e1= expr_list )?
                    int alt23=2;
                    int LA23_0 = input.LA(1);

                    if ( (LA23_0==VAR_DECL||LA23_0==CALL||LA23_0==EXPR||(LA23_0>=SCALAR && LA23_0<=UNARY_EXPR)||LA23_0==REF_T||LA23_0==EQUAL_T||(LA23_0>=OR_T && LA23_0<=CLONE_T)||(LA23_0>=INSTANCEOF_T && LA23_0<=PRINT_T)) ) {
                        alt23=1;
                    }
                    switch (alt23) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:487:15: e1= expr_list
                            {
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_expr_list_in_topStatement729);
                            e1=expr_list();

                            state._fsp--;

                            adaptor.addChild(root_1, e1.getTree());

                            }
                            break;

                    }

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_2 = _last;
                    SLAST _first_2 = null;
                    SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    CONDITION62=(SLAST)match(input,CONDITION,FOLLOW_CONDITION_in_topStatement733); 
                    CONDITION62_tree = (SLAST)adaptor.dupNode(CONDITION62);

                    root_2 = (SLAST)adaptor.becomeRoot(CONDITION62_tree, root_2);



                    if ( input.LA(1)==Token.DOWN ) {
                        match(input, Token.DOWN, null); 
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:487:41: (e2= expr_list )?
                        int alt24=2;
                        int LA24_0 = input.LA(1);

                        if ( (LA24_0==VAR_DECL||LA24_0==CALL||LA24_0==EXPR||(LA24_0>=SCALAR && LA24_0<=UNARY_EXPR)||LA24_0==REF_T||LA24_0==EQUAL_T||(LA24_0>=OR_T && LA24_0<=CLONE_T)||(LA24_0>=INSTANCEOF_T && LA24_0<=PRINT_T)) ) {
                            alt24=1;
                        }
                        switch (alt24) {
                            case 1 :
                                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:487:41: e2= expr_list
                                {
                                _last = (SLAST)input.LT(1);
                                pushFollow(FOLLOW_expr_list_in_topStatement737);
                                e2=expr_list();

                                state._fsp--;

                                adaptor.addChild(root_2, e2.getTree());

                                }
                                break;

                        }


                        match(input, Token.UP, null); 
                    }adaptor.addChild(root_1, root_2);_last = _save_last_2;
                    }

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_2 = _last;
                    SLAST _first_2 = null;
                    SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    ITERATE63=(SLAST)match(input,ITERATE,FOLLOW_ITERATE_in_topStatement742); 
                    ITERATE63_tree = (SLAST)adaptor.dupNode(ITERATE63);

                    root_2 = (SLAST)adaptor.becomeRoot(ITERATE63_tree, root_2);



                    if ( input.LA(1)==Token.DOWN ) {
                        match(input, Token.DOWN, null); 
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:487:66: (e3= expr_list )?
                        int alt25=2;
                        int LA25_0 = input.LA(1);

                        if ( (LA25_0==VAR_DECL||LA25_0==CALL||LA25_0==EXPR||(LA25_0>=SCALAR && LA25_0<=UNARY_EXPR)||LA25_0==REF_T||LA25_0==EQUAL_T||(LA25_0>=OR_T && LA25_0<=CLONE_T)||(LA25_0>=INSTANCEOF_T && LA25_0<=PRINT_T)) ) {
                            alt25=1;
                        }
                        switch (alt25) {
                            case 1 :
                                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:487:66: e3= expr_list
                                {
                                _last = (SLAST)input.LT(1);
                                pushFollow(FOLLOW_expr_list_in_topStatement746);
                                e3=expr_list();

                                state._fsp--;

                                adaptor.addChild(root_2, e3.getTree());

                                }
                                break;

                        }


                        match(input, Token.UP, null); 
                    }adaptor.addChild(root_1, root_2);_last = _save_last_2;
                    }

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_for_statement_in_topStatement752);
                    s1=for_statement();

                    state._fsp--;

                    adaptor.addChild(root_1, s1.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        List initList = new LinkedList(),
                            condList = new LinkedList(),
                            changeList = new LinkedList();
                        if ((e1!=null?e1.exprList:null) != null) initList = (e1!=null?e1.exprList:null);
                        if ((e2!=null?e2.exprList:null) != null) condList = (e2!=null?e2.exprList:null);
                        if ((e3!=null?e3.exprList:null) != null) changeList = (e3!=null?e3.exprList:null);
                        int startIndex = FOR_T61.startIndex;
                        int endIndex = FOR_T61.endIndex + 1;
                        retval.stat = new ForStatement(startIndex, endIndex, initList, condList, changeList, (s1!=null?s1.block:null));
                      

                    }
                    break;
                case 6 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:499:5: ^( SWITCH_T ^( CONDITION e= expression ) switch_case_list )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    SWITCH_T64=(SLAST)match(input,SWITCH_T,FOLLOW_SWITCH_T_in_topStatement764); 
                    SWITCH_T64_tree = (SLAST)adaptor.dupNode(SWITCH_T64);

                    root_1 = (SLAST)adaptor.becomeRoot(SWITCH_T64_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_2 = _last;
                    SLAST _first_2 = null;
                    SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    CONDITION65=(SLAST)match(input,CONDITION,FOLLOW_CONDITION_in_topStatement767); 
                    CONDITION65_tree = (SLAST)adaptor.dupNode(CONDITION65);

                    root_2 = (SLAST)adaptor.becomeRoot(CONDITION65_tree, root_2);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_topStatement771);
                    e=expression();

                    state._fsp--;

                    adaptor.addChild(root_2, e.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
                    }

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_switch_case_list_in_topStatement774);
                    switch_case_list66=switch_case_list();

                    state._fsp--;

                    adaptor.addChild(root_1, switch_case_list66.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = SWITCH_T64.startIndex;
                        int endIndex = SWITCH_T64.endIndex + 1;
                        retval.stat = new SwitchStatement(startIndex, endIndex, (e!=null?e.expr:null), (switch_case_list66!=null?switch_case_list66.block:null));
                      

                    }
                    break;
                case 7 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:505:5: ^( BREAK_T ( expression )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    BREAK_T67=(SLAST)match(input,BREAK_T,FOLLOW_BREAK_T_in_topStatement786); 
                    BREAK_T67_tree = (SLAST)adaptor.dupNode(BREAK_T67);

                    root_1 = (SLAST)adaptor.becomeRoot(BREAK_T67_tree, root_1);



                    if ( input.LA(1)==Token.DOWN ) {
                        match(input, Token.DOWN, null); 
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:505:15: ( expression )?
                        int alt26=2;
                        int LA26_0 = input.LA(1);

                        if ( (LA26_0==VAR_DECL||LA26_0==CALL||LA26_0==EXPR||(LA26_0>=SCALAR && LA26_0<=UNARY_EXPR)||LA26_0==REF_T||LA26_0==EQUAL_T||(LA26_0>=OR_T && LA26_0<=CLONE_T)||(LA26_0>=INSTANCEOF_T && LA26_0<=PRINT_T)) ) {
                            alt26=1;
                        }
                        switch (alt26) {
                            case 1 :
                                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:505:15: expression
                                {
                                _last = (SLAST)input.LT(1);
                                pushFollow(FOLLOW_expression_in_topStatement788);
                                expression68=expression();

                                state._fsp--;

                                adaptor.addChild(root_1, expression68.getTree());

                                }
                                break;

                        }


                        match(input, Token.UP, null); 
                    }adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = BREAK_T67.startIndex;
                        int endIndex = BREAK_T67.endIndex + 1;
                        retval.stat = new BreakStatement(startIndex, endIndex);
                      

                    }
                    break;
                case 8 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:511:5: ^( CONTINUE_T (e= expression )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    CONTINUE_T69=(SLAST)match(input,CONTINUE_T,FOLLOW_CONTINUE_T_in_topStatement801); 
                    CONTINUE_T69_tree = (SLAST)adaptor.dupNode(CONTINUE_T69);

                    root_1 = (SLAST)adaptor.becomeRoot(CONTINUE_T69_tree, root_1);



                    if ( input.LA(1)==Token.DOWN ) {
                        match(input, Token.DOWN, null); 
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:511:19: (e= expression )?
                        int alt27=2;
                        int LA27_0 = input.LA(1);

                        if ( (LA27_0==VAR_DECL||LA27_0==CALL||LA27_0==EXPR||(LA27_0>=SCALAR && LA27_0<=UNARY_EXPR)||LA27_0==REF_T||LA27_0==EQUAL_T||(LA27_0>=OR_T && LA27_0<=CLONE_T)||(LA27_0>=INSTANCEOF_T && LA27_0<=PRINT_T)) ) {
                            alt27=1;
                        }
                        switch (alt27) {
                            case 1 :
                                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:511:19: e= expression
                                {
                                _last = (SLAST)input.LT(1);
                                pushFollow(FOLLOW_expression_in_topStatement805);
                                e=expression();

                                state._fsp--;

                                adaptor.addChild(root_1, e.getTree());

                                }
                                break;

                        }


                        match(input, Token.UP, null); 
                    }adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = CONTINUE_T69.startIndex;
                        int endIndex = CONTINUE_T69.endIndex + 1;
                        retval.stat = new ContinueStatement(startIndex, endIndex);
                        if ((e!=null?e.expr:null) != null) {
                          retval.stat = new ContinueStatement(startIndex, endIndex, (e!=null?e.expr:null));
                        }
                      

                    }
                    break;
                case 9 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:520:5: ^( RETURN_T (e= expression )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    RETURN_T70=(SLAST)match(input,RETURN_T,FOLLOW_RETURN_T_in_topStatement818); 
                    RETURN_T70_tree = (SLAST)adaptor.dupNode(RETURN_T70);

                    root_1 = (SLAST)adaptor.becomeRoot(RETURN_T70_tree, root_1);



                    if ( input.LA(1)==Token.DOWN ) {
                        match(input, Token.DOWN, null); 
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:520:17: (e= expression )?
                        int alt28=2;
                        int LA28_0 = input.LA(1);

                        if ( (LA28_0==VAR_DECL||LA28_0==CALL||LA28_0==EXPR||(LA28_0>=SCALAR && LA28_0<=UNARY_EXPR)||LA28_0==REF_T||LA28_0==EQUAL_T||(LA28_0>=OR_T && LA28_0<=CLONE_T)||(LA28_0>=INSTANCEOF_T && LA28_0<=PRINT_T)) ) {
                            alt28=1;
                        }
                        switch (alt28) {
                            case 1 :
                                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:520:17: e= expression
                                {
                                _last = (SLAST)input.LT(1);
                                pushFollow(FOLLOW_expression_in_topStatement822);
                                e=expression();

                                state._fsp--;

                                adaptor.addChild(root_1, e.getTree());

                                }
                                break;

                        }


                        match(input, Token.UP, null); 
                    }adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = RETURN_T70.startIndex;
                        int endIndex = RETURN_T70.endIndex + 1;
                        retval.stat = new ReturnStatement(startIndex, endIndex);
                        if ((e!=null?e.expr:null) != null) {
                          retval.stat = new ReturnStatement(startIndex, endIndex, (e!=null?e.expr:null));
                        }
                      

                    }
                    break;
                case 10 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:529:5: ^( GLOBAL_T variable_list )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    GLOBAL_T71=(SLAST)match(input,GLOBAL_T,FOLLOW_GLOBAL_T_in_topStatement835); 
                    GLOBAL_T71_tree = (SLAST)adaptor.dupNode(GLOBAL_T71);

                    root_1 = (SLAST)adaptor.becomeRoot(GLOBAL_T71_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_variable_list_in_topStatement837);
                    variable_list72=variable_list();

                    state._fsp--;

                    adaptor.addChild(root_1, variable_list72.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = GLOBAL_T71.startIndex;
                        int endIndex = GLOBAL_T71.endIndex + 1;
                        retval.stat = new GlobalStatement(startIndex, endIndex, (variable_list72!=null?variable_list72.variableList:null));
                      

                    }
                    break;
                case 11 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:535:5: ^( STATIC_T static_var_list )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    STATIC_T73=(SLAST)match(input,STATIC_T,FOLLOW_STATIC_T_in_topStatement849); 
                    STATIC_T73_tree = (SLAST)adaptor.dupNode(STATIC_T73);

                    root_1 = (SLAST)adaptor.becomeRoot(STATIC_T73_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_static_var_list_in_topStatement851);
                    static_var_list74=static_var_list();

                    state._fsp--;

                    adaptor.addChild(root_1, static_var_list74.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = STATIC_T73.startIndex;
                        int endIndex = STATIC_T73.endIndex + 1;
                        retval.stat = new StaticStatement(startIndex, endIndex, (static_var_list74!=null?static_var_list74.staticVarList:null));
                      

                    }
                    break;
                case 12 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:541:5: ^( ECHO_T expr_list )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    ECHO_T75=(SLAST)match(input,ECHO_T,FOLLOW_ECHO_T_in_topStatement863); 
                    ECHO_T75_tree = (SLAST)adaptor.dupNode(ECHO_T75);

                    root_1 = (SLAST)adaptor.becomeRoot(ECHO_T75_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expr_list_in_topStatement865);
                    expr_list76=expr_list();

                    state._fsp--;

                    adaptor.addChild(root_1, expr_list76.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = ECHO_T75.startIndex;
                        int endIndex = ECHO_T75.endIndex + 1;
                        retval.stat = new EchoStatement(startIndex, endIndex, (expr_list76!=null?expr_list76.exprList:null)); 
                      

                    }
                    break;
                case 13 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:547:5: ^( EMPTYSTATEMENT SEMI_COLON )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    EMPTYSTATEMENT77=(SLAST)match(input,EMPTYSTATEMENT,FOLLOW_EMPTYSTATEMENT_in_topStatement877); 
                    EMPTYSTATEMENT77_tree = (SLAST)adaptor.dupNode(EMPTYSTATEMENT77);

                    root_1 = (SLAST)adaptor.becomeRoot(EMPTYSTATEMENT77_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    SEMI_COLON78=(SLAST)match(input,SEMI_COLON,FOLLOW_SEMI_COLON_in_topStatement879); 
                    SEMI_COLON78_tree = (SLAST)adaptor.dupNode(SEMI_COLON78);

                    adaptor.addChild(root_1, SEMI_COLON78_tree);


                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = EMPTYSTATEMENT77.startIndex;
                        int endIndex = EMPTYSTATEMENT77.endIndex + 1;
                        retval.stat = new EmptyStatement(startIndex, endIndex); 
                      

                    }
                    break;
                case 14 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:553:5: expression
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_topStatement890);
                    expression79=expression();

                    state._fsp--;

                    adaptor.addChild(root_0, expression79.getTree());

                         retval.expr = (expression79!=null?expression79.expr:null);
                      

                    }
                    break;
                case 15 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:557:5: ^( FOREACH_T ^( AS_T e= expression v1= foreach_variable (v2= foreach_variable )? ) foreach_statement )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    FOREACH_T80=(SLAST)match(input,FOREACH_T,FOLLOW_FOREACH_T_in_topStatement901); 
                    FOREACH_T80_tree = (SLAST)adaptor.dupNode(FOREACH_T80);

                    root_1 = (SLAST)adaptor.becomeRoot(FOREACH_T80_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_2 = _last;
                    SLAST _first_2 = null;
                    SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    AS_T81=(SLAST)match(input,AS_T,FOLLOW_AS_T_in_topStatement904); 
                    AS_T81_tree = (SLAST)adaptor.dupNode(AS_T81);

                    root_2 = (SLAST)adaptor.becomeRoot(AS_T81_tree, root_2);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_topStatement908);
                    e=expression();

                    state._fsp--;

                    adaptor.addChild(root_2, e.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_foreach_variable_in_topStatement912);
                    v1=foreach_variable();

                    state._fsp--;

                    adaptor.addChild(root_2, v1.getTree());
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:557:59: (v2= foreach_variable )?
                    int alt29=2;
                    int LA29_0 = input.LA(1);

                    if ( (LA29_0==VAR_DECL||LA29_0==CALL||LA29_0==REF_T) ) {
                        alt29=1;
                    }
                    switch (alt29) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:557:59: v2= foreach_variable
                            {
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_foreach_variable_in_topStatement916);
                            v2=foreach_variable();

                            state._fsp--;

                            adaptor.addChild(root_2, v2.getTree());

                            }
                            break;

                    }


                    match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
                    }

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_foreach_statement_in_topStatement920);
                    foreach_statement82=foreach_statement();

                    state._fsp--;

                    adaptor.addChild(root_1, foreach_statement82.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = FOREACH_T80.startIndex;
                        int endIndex = FOREACH_T80.endIndex + 1;
                        
                        if ((v2!=null?v2.expr:null) == null) {
                          retval.stat = new ForEachStatement(startIndex, endIndex, (e!=null?e.expr:null), (v1!=null?v1.expr:null), (foreach_statement82!=null?foreach_statement82.block:null));
                        }
                        else {
                          retval.stat = new ForEachStatement(startIndex, endIndex, (e!=null?e.expr:null), (v1!=null?v1.expr:null), (v2!=null?v2.expr:null), (foreach_statement82!=null?foreach_statement82.block:null));
                        }
                      

                    }
                    break;
                case 16 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:569:5: ^( DECLARE_T directive declare_statement )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    DECLARE_T83=(SLAST)match(input,DECLARE_T,FOLLOW_DECLARE_T_in_topStatement933); 
                    DECLARE_T83_tree = (SLAST)adaptor.dupNode(DECLARE_T83);

                    root_1 = (SLAST)adaptor.becomeRoot(DECLARE_T83_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_directive_in_topStatement935);
                    directive84=directive();

                    state._fsp--;

                    adaptor.addChild(root_1, directive84.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_declare_statement_in_topStatement937);
                    declare_statement85=declare_statement();

                    state._fsp--;

                    adaptor.addChild(root_1, declare_statement85.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    	    int startIndex = DECLARE_T83.startIndex;
                    	    int endIndex = DECLARE_T83.endIndex + 1;
                    	    DeclareStatement declare = new DeclareStatement(startIndex, endIndex, ((topStatement_scope)topStatement_stack.peek()).declareKey, ((topStatement_scope)topStatement_stack.peek()).declareValue, (declare_statement85!=null?declare_statement85.block:null));
                    	    retval.stat = declare;
                    	    System.out.println("declare block");
                    	  

                    }
                    break;
                case 17 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:577:5: ^( TRY_T block catch_branch_list )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    TRY_T86=(SLAST)match(input,TRY_T,FOLLOW_TRY_T_in_topStatement950); 
                    TRY_T86_tree = (SLAST)adaptor.dupNode(TRY_T86);

                    root_1 = (SLAST)adaptor.becomeRoot(TRY_T86_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_block_in_topStatement952);
                    block87=block();

                    state._fsp--;

                    adaptor.addChild(root_1, block87.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_catch_branch_list_in_topStatement954);
                    catch_branch_list88=catch_branch_list();

                    state._fsp--;

                    adaptor.addChild(root_1, catch_branch_list88.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = TRY_T86.startIndex;
                        int endIndex = TRY_T86.endIndex + 1;
                        
                        TryStatement tryStatement = new TryStatement(startIndex, endIndex, (Block)(block87!=null?block87.stat:null), (catch_branch_list88!=null?catch_branch_list88.catchList:null));
                        retval.stat = tryStatement;
                      

                    }
                    break;
                case 18 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:585:5: ^( THROW_T e= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    THROW_T89=(SLAST)match(input,THROW_T,FOLLOW_THROW_T_in_topStatement966); 
                    THROW_T89_tree = (SLAST)adaptor.dupNode(THROW_T89);

                    root_1 = (SLAST)adaptor.becomeRoot(THROW_T89_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_topStatement970);
                    e=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = THROW_T89.startIndex;
                        int endIndex = THROW_T89.endIndex + 1;
                        retval.stat = new ThrowStatement(startIndex, endIndex, (e!=null?e.expr:null)); 
                      

                    }
                    break;
                case 19 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:591:5: ^( USE_T use_filename )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    USE_T90=(SLAST)match(input,USE_T,FOLLOW_USE_T_in_topStatement982); 
                    USE_T90_tree = (SLAST)adaptor.dupNode(USE_T90);

                    root_1 = (SLAST)adaptor.becomeRoot(USE_T90_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_use_filename_in_topStatement984);
                    use_filename91=use_filename();

                    state._fsp--;

                    adaptor.addChild(root_1, use_filename91.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 20 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:592:5: ^( INCLUDE_T e= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    INCLUDE_T92=(SLAST)match(input,INCLUDE_T,FOLLOW_INCLUDE_T_in_topStatement992); 
                    INCLUDE_T92_tree = (SLAST)adaptor.dupNode(INCLUDE_T92);

                    root_1 = (SLAST)adaptor.becomeRoot(INCLUDE_T92_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_topStatement996);
                    e=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = INCLUDE_T92.startIndex;
                        int endIndex = INCLUDE_T92.endIndex;
                        retval.expr = new Include(startIndex, endIndex, (e!=null?e.expr:null), Include.IT_INCLUDE);
                      

                    }
                    break;
                case 21 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:598:5: ^( INCLUDE_ONCE_T e= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    INCLUDE_ONCE_T93=(SLAST)match(input,INCLUDE_ONCE_T,FOLLOW_INCLUDE_ONCE_T_in_topStatement1009); 
                    INCLUDE_ONCE_T93_tree = (SLAST)adaptor.dupNode(INCLUDE_ONCE_T93);

                    root_1 = (SLAST)adaptor.becomeRoot(INCLUDE_ONCE_T93_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_topStatement1013);
                    e=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = INCLUDE_ONCE_T93.startIndex;
                        int endIndex = INCLUDE_ONCE_T93.endIndex;
                        retval.expr = new Include(startIndex, endIndex, (e!=null?e.expr:null), Include.IT_INCLUDE_ONCE);
                      

                    }
                    break;
                case 22 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:604:5: ^( REQUIRE_T e= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    REQUIRE_T94=(SLAST)match(input,REQUIRE_T,FOLLOW_REQUIRE_T_in_topStatement1026); 
                    REQUIRE_T94_tree = (SLAST)adaptor.dupNode(REQUIRE_T94);

                    root_1 = (SLAST)adaptor.becomeRoot(REQUIRE_T94_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_topStatement1030);
                    e=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = REQUIRE_T94.startIndex;
                        int endIndex = REQUIRE_T94.endIndex;
                        retval.expr = new Include(startIndex, endIndex, (e!=null?e.expr:null), Include.IT_REQUIRE);
                      

                    }
                    break;
                case 23 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:610:5: ^( REQUIRE_ONCE_T e= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    REQUIRE_ONCE_T95=(SLAST)match(input,REQUIRE_ONCE_T,FOLLOW_REQUIRE_ONCE_T_in_topStatement1043); 
                    REQUIRE_ONCE_T95_tree = (SLAST)adaptor.dupNode(REQUIRE_ONCE_T95);

                    root_1 = (SLAST)adaptor.becomeRoot(REQUIRE_ONCE_T95_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_topStatement1047);
                    e=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = REQUIRE_ONCE_T95.startIndex;
                        int endIndex = REQUIRE_ONCE_T95.endIndex;
                        retval.expr = new Include(startIndex, endIndex, (e!=null?e.expr:null), Include.IT_REQUIRE_ONCE);
                      

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
            topStatement_stack.pop();
        }
        return retval;
    }
    // $ANTLR end "topStatement"

    public static class foreach_variable_return extends TreeRuleReturnScope {
        public Expression expr;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "foreach_variable"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:621:1: foreach_variable returns [Expression expr] : ( REF_T )? variable ;
    public final TreePHP.foreach_variable_return foreach_variable() throws RecognitionException {
        TreePHP.foreach_variable_return retval = new TreePHP.foreach_variable_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST REF_T96=null;
        TreePHP.variable_return variable97 = null;


        SLAST REF_T96_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:627:3: ( ( REF_T )? variable )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:627:5: ( REF_T )? variable
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:627:5: ( REF_T )?
            int alt31=2;
            int LA31_0 = input.LA(1);

            if ( (LA31_0==REF_T) ) {
                alt31=1;
            }
            switch (alt31) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:627:5: REF_T
                    {
                    _last = (SLAST)input.LT(1);
                    REF_T96=(SLAST)match(input,REF_T,FOLLOW_REF_T_in_foreach_variable1078); 
                    REF_T96_tree = (SLAST)adaptor.dupNode(REF_T96);

                    adaptor.addChild(root_0, REF_T96_tree);


                    }
                    break;

            }

            _last = (SLAST)input.LT(1);
            pushFollow(FOLLOW_variable_in_foreach_variable1081);
            variable97=variable();

            state._fsp--;

            adaptor.addChild(root_0, variable97.getTree());

                retval.expr = (variable97!=null?variable97.var:null);
              

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "foreach_variable"

    public static class use_filename_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "use_filename"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:634:1: use_filename : STRINGLITERAL ;
    public final TreePHP.use_filename_return use_filename() throws RecognitionException {
        TreePHP.use_filename_return retval = new TreePHP.use_filename_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST STRINGLITERAL98=null;

        SLAST STRINGLITERAL98_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:635:3: ( STRINGLITERAL )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:635:5: STRINGLITERAL
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            STRINGLITERAL98=(SLAST)match(input,STRINGLITERAL,FOLLOW_STRINGLITERAL_in_use_filename1102); 
            STRINGLITERAL98_tree = (SLAST)adaptor.dupNode(STRINGLITERAL98);

            adaptor.addChild(root_0, STRINGLITERAL98_tree);


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "use_filename"

    protected static class variable_list_scope {
        List varList;
    }
    protected Stack variable_list_stack = new Stack();

    public static class variable_list_return extends TreeRuleReturnScope {
        public List variableList;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "variable_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:638:1: variable_list returns [List variableList] : ( variable )+ ;
    public final TreePHP.variable_list_return variable_list() throws RecognitionException {
        variable_list_stack.push(new variable_list_scope());
        TreePHP.variable_list_return retval = new TreePHP.variable_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.variable_return variable99 = null;




          ((variable_list_scope)variable_list_stack.peek()).varList = new LinkedList();
          inVarList = true;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:646:3: ( ( variable )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:646:5: ( variable )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:646:5: ( variable )+
            int cnt32=0;
            loop32:
            do {
                int alt32=2;
                int LA32_0 = input.LA(1);

                if ( (LA32_0==VAR_DECL||LA32_0==CALL) ) {
                    alt32=1;
                }


                switch (alt32) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:646:5: variable
            	    {
            	    _last = (SLAST)input.LT(1);
            	    pushFollow(FOLLOW_variable_in_variable_list1130);
            	    variable99=variable();

            	    state._fsp--;

            	    adaptor.addChild(root_0, variable99.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt32 >= 1 ) break loop32;
                        EarlyExitException eee =
                            new EarlyExitException(32, input);
                        throw eee;
                }
                cnt32++;
            } while (true);


                retval.variableList = ((variable_list_scope)variable_list_stack.peek()).varList;
                inVarList = false;
              

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
            variable_list_stack.pop();
        }
        return retval;
    }
    // $ANTLR end "variable_list"

    public static class fully_qualified_class_name_list_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "fully_qualified_class_name_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:653:1: fully_qualified_class_name_list : ( fully_qualified_class_name )+ ;
    public final TreePHP.fully_qualified_class_name_list_return fully_qualified_class_name_list() throws RecognitionException {
        TreePHP.fully_qualified_class_name_list_return retval = new TreePHP.fully_qualified_class_name_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.fully_qualified_class_name_return fully_qualified_class_name100 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:654:3: ( ( fully_qualified_class_name )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:654:5: ( fully_qualified_class_name )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:654:5: ( fully_qualified_class_name )+
            int cnt33=0;
            loop33:
            do {
                int alt33=2;
                int LA33_0 = input.LA(1);

                if ( (LA33_0==IDENTIFIER||LA33_0==DOMAIN_T) ) {
                    alt33=1;
                }


                switch (alt33) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:654:5: fully_qualified_class_name
            	    {
            	    _last = (SLAST)input.LT(1);
            	    pushFollow(FOLLOW_fully_qualified_class_name_in_fully_qualified_class_name_list1150);
            	    fully_qualified_class_name100=fully_qualified_class_name();

            	    state._fsp--;

            	    adaptor.addChild(root_0, fully_qualified_class_name100.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt33 >= 1 ) break loop33;
                        EarlyExitException eee =
                            new EarlyExitException(33, input);
                        throw eee;
                }
                cnt33++;
            } while (true);


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "fully_qualified_class_name_list"

    public static class fully_qualified_class_name_return extends TreeRuleReturnScope {
        public String name;
        public TypeReference type;
        public StaticConstantAccess constant;
        public SimpleReference simpleRef;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "fully_qualified_class_name"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:657:1: fully_qualified_class_name returns [String name, TypeReference type, StaticConstantAccess constant, SimpleReference simpleRef] : ( ^(d= DOMAIN_T f= fully_qualified_class_name IDENTIFIER ) ( DOMAIN_T )? | IDENTIFIER ( DOMAIN_T )? );
    public final TreePHP.fully_qualified_class_name_return fully_qualified_class_name() throws RecognitionException {
        TreePHP.fully_qualified_class_name_return retval = new TreePHP.fully_qualified_class_name_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST d=null;
        SLAST IDENTIFIER101=null;
        SLAST DOMAIN_T102=null;
        SLAST IDENTIFIER103=null;
        SLAST DOMAIN_T104=null;
        TreePHP.fully_qualified_class_name_return f = null;


        SLAST d_tree=null;
        SLAST IDENTIFIER101_tree=null;
        SLAST DOMAIN_T102_tree=null;
        SLAST IDENTIFIER103_tree=null;
        SLAST DOMAIN_T104_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:658:3: ( ^(d= DOMAIN_T f= fully_qualified_class_name IDENTIFIER ) ( DOMAIN_T )? | IDENTIFIER ( DOMAIN_T )? )
            int alt36=2;
            int LA36_0 = input.LA(1);

            if ( (LA36_0==DOMAIN_T) ) {
                alt36=1;
            }
            else if ( (LA36_0==IDENTIFIER) ) {
                alt36=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 36, 0, input);

                throw nvae;
            }
            switch (alt36) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:658:5: ^(d= DOMAIN_T f= fully_qualified_class_name IDENTIFIER ) ( DOMAIN_T )?
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    d=(SLAST)match(input,DOMAIN_T,FOLLOW_DOMAIN_T_in_fully_qualified_class_name1173); 
                    d_tree = (SLAST)adaptor.dupNode(d);

                    root_1 = (SLAST)adaptor.becomeRoot(d_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_fully_qualified_class_name_in_fully_qualified_class_name1177);
                    f=fully_qualified_class_name();

                    state._fsp--;

                    adaptor.addChild(root_1, f.getTree());
                    _last = (SLAST)input.LT(1);
                    IDENTIFIER101=(SLAST)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_fully_qualified_class_name1179); 
                    IDENTIFIER101_tree = (SLAST)adaptor.dupNode(IDENTIFIER101);

                    adaptor.addChild(root_1, IDENTIFIER101_tree);


                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:658:59: ( DOMAIN_T )?
                    int alt34=2;
                    int LA34_0 = input.LA(1);

                    if ( (LA34_0==DOMAIN_T) ) {
                        int LA34_1 = input.LA(2);

                        if ( (LA34_1==UP||LA34_1==VAR_DECL||LA34_1==INDEX||LA34_1==CALL||LA34_1==ARGU||(LA34_1>=VAR && LA34_1<=HASH_INDEX)||LA34_1==IDENTIFIER||LA34_1==DOMAIN_T) ) {
                            alt34=1;
                        }
                    }
                    switch (alt34) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:658:59: DOMAIN_T
                            {
                            _last = (SLAST)input.LT(1);
                            DOMAIN_T102=(SLAST)match(input,DOMAIN_T,FOLLOW_DOMAIN_T_in_fully_qualified_class_name1182); 
                            DOMAIN_T102_tree = (SLAST)adaptor.dupNode(DOMAIN_T102);

                            adaptor.addChild(root_0, DOMAIN_T102_tree);


                            }
                            break;

                    }


                        int startIndex = d.startIndex;
                        int endIndex = d.endIndex + 1;
                        String className = null;
                        TypeReference type = null;
                        if ((f!=null?f.name:null) != null) {
                          className = (f!=null?f.name:null);
                          int typeLeft = ((CommonToken)(f!=null?((SLAST)f.tree):null).token).getStartIndex();
                          int typeRight = ((CommonToken)(f!=null?((SLAST)f.tree):null).token).getStopIndex() + 1;
                          type = new TypeReference(typeLeft, typeRight, className);
                          retval.simpleRef = new SimpleReference(typeLeft, typeRight, className);
                        }
                        else {
                          type = retval.type;
                        }
                          
                        CommonToken token = (CommonToken)IDENTIFIER101.token;
                        int varLeft = token.getStartIndex();
                        int varRight = token.getStopIndex() + 1;
                        ConstantReference constRef = new ConstantReference(varLeft, varRight, (IDENTIFIER101!=null?IDENTIFIER101.getText():null));
                        retval.constant = new StaticConstantAccess(startIndex, endIndex, type, constRef);
                        
                      

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:682:5: IDENTIFIER ( DOMAIN_T )?
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    IDENTIFIER103=(SLAST)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_fully_qualified_class_name1193); 
                    IDENTIFIER103_tree = (SLAST)adaptor.dupNode(IDENTIFIER103);

                    adaptor.addChild(root_0, IDENTIFIER103_tree);

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:682:16: ( DOMAIN_T )?
                    int alt35=2;
                    int LA35_0 = input.LA(1);

                    if ( (LA35_0==DOMAIN_T) ) {
                        int LA35_1 = input.LA(2);

                        if ( (LA35_1==UP||LA35_1==VAR_DECL||LA35_1==INDEX||LA35_1==CALL||LA35_1==ARGU||(LA35_1>=VAR && LA35_1<=HASH_INDEX)||LA35_1==IDENTIFIER||LA35_1==DOMAIN_T) ) {
                            alt35=1;
                        }
                    }
                    switch (alt35) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:682:16: DOMAIN_T
                            {
                            _last = (SLAST)input.LT(1);
                            DOMAIN_T104=(SLAST)match(input,DOMAIN_T,FOLLOW_DOMAIN_T_in_fully_qualified_class_name1195); 
                            DOMAIN_T104_tree = (SLAST)adaptor.dupNode(DOMAIN_T104);

                            adaptor.addChild(root_0, DOMAIN_T104_tree);


                            }
                            break;

                    }


                        retval.name = (IDENTIFIER103!=null?IDENTIFIER103.getText():null);
                        int typeLeft = ((CommonToken)IDENTIFIER103.token).getStartIndex();
                        int typeRight = ((CommonToken)IDENTIFIER103.token).getStopIndex() + 1;
                        if ((DOMAIN_T104!=null?DOMAIN_T104.getText():null) != null) {
                          typeRight = ((CommonToken)DOMAIN_T104.token).getStopIndex() + 1;
                        }
                        retval.type = new TypeReference(typeLeft, typeRight, (IDENTIFIER103!=null?IDENTIFIER103.getText():null));
                      

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "fully_qualified_class_name"

    protected static class static_var_list_scope {
        List varList;
    }
    protected Stack static_var_list_stack = new Stack();

    public static class static_var_list_return extends TreeRuleReturnScope {
        public List staticVarList;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "static_var_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:695:1: static_var_list returns [List staticVarList] : ( static_var_element )+ ;
    public final TreePHP.static_var_list_return static_var_list() throws RecognitionException {
        static_var_list_stack.push(new static_var_list_scope());
        TreePHP.static_var_list_return retval = new TreePHP.static_var_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.static_var_element_return static_var_element105 = null;




          ((static_var_list_scope)static_var_list_stack.peek()).varList = new LinkedList();

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:702:3: ( ( static_var_element )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:702:5: ( static_var_element )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:702:5: ( static_var_element )+
            int cnt37=0;
            loop37:
            do {
                int alt37=2;
                int LA37_0 = input.LA(1);

                if ( (LA37_0==VAR_DECL||LA37_0==EQUAL_T) ) {
                    alt37=1;
                }


                switch (alt37) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:702:5: static_var_element
            	    {
            	    _last = (SLAST)input.LT(1);
            	    pushFollow(FOLLOW_static_var_element_in_static_var_list1229);
            	    static_var_element105=static_var_element();

            	    state._fsp--;

            	    adaptor.addChild(root_0, static_var_element105.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt37 >= 1 ) break loop37;
                        EarlyExitException eee =
                            new EarlyExitException(37, input);
                        throw eee;
                }
                cnt37++;
            } while (true);


                retval.staticVarList = ((static_var_list_scope)static_var_list_stack.peek()).varList;
              

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
            static_var_list_stack.pop();
        }
        return retval;
    }
    // $ANTLR end "static_var_list"

    public static class static_var_element_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "static_var_element"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:708:1: static_var_element : ( pure_variable | ^( EQUAL_T pure_variable scalar ) );
    public final TreePHP.static_var_element_return static_var_element() throws RecognitionException {
        TreePHP.static_var_element_return retval = new TreePHP.static_var_element_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST EQUAL_T107=null;
        TreePHP.pure_variable_return pure_variable106 = null;

        TreePHP.pure_variable_return pure_variable108 = null;

        TreePHP.scalar_return scalar109 = null;


        SLAST EQUAL_T107_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:709:3: ( pure_variable | ^( EQUAL_T pure_variable scalar ) )
            int alt38=2;
            int LA38_0 = input.LA(1);

            if ( (LA38_0==VAR_DECL) ) {
                alt38=1;
            }
            else if ( (LA38_0==EQUAL_T) ) {
                alt38=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 38, 0, input);

                throw nvae;
            }
            switch (alt38) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:709:5: pure_variable
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_pure_variable_in_static_var_element1247);
                    pure_variable106=pure_variable();

                    state._fsp--;

                    adaptor.addChild(root_0, pure_variable106.getTree());

                        int varNameLeft = ((CommonToken)(pure_variable106!=null?((SLAST)pure_variable106.tree):null).token).getStartIndex();
                        int varNameRight = ((CommonToken)(pure_variable106!=null?((SLAST)pure_variable106.tree):null).token).getStopIndex() + 1;
                        String varName = (pure_variable106!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(pure_variable106.start),
                      input.getTreeAdaptor().getTokenStopIndex(pure_variable106.start))):null);
                        VariableReference varId = new VariableReference(varNameLeft, varNameRight, varName);
                        
                        if (inClassStatementList) {
                          Object obj = new ASTNode[] {varId, null};
                          ((class_statement_scope)class_statement_stack.peek()).varList.add(obj);
                        }
                        else {
                          ((static_var_list_scope)static_var_list_stack.peek()).varList.add(varId);
                          System.out.println("var id:" + varId);
                        }
                      

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:725:5: ^( EQUAL_T pure_variable scalar )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    EQUAL_T107=(SLAST)match(input,EQUAL_T,FOLLOW_EQUAL_T_in_static_var_element1258); 
                    EQUAL_T107_tree = (SLAST)adaptor.dupNode(EQUAL_T107);

                    root_1 = (SLAST)adaptor.becomeRoot(EQUAL_T107_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_pure_variable_in_static_var_element1260);
                    pure_variable108=pure_variable();

                    state._fsp--;

                    adaptor.addChild(root_1, pure_variable108.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_scalar_in_static_var_element1262);
                    scalar109=scalar();

                    state._fsp--;

                    adaptor.addChild(root_1, scalar109.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = EQUAL_T107.startIndex;
                        int endIndex = EQUAL_T107.endIndex + 1;
                        int varNameLeft = ((CommonToken)(pure_variable108!=null?((SLAST)pure_variable108.tree):null).token).getStartIndex();
                        int varNameRight = ((CommonToken)(pure_variable108!=null?((SLAST)pure_variable108.tree):null).token).getStopIndex() + 1;
                        String varName = (pure_variable108!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(pure_variable108.start),
                      input.getTreeAdaptor().getTokenStopIndex(pure_variable108.start))):null);
                        Expression expr = (scalar109!=null?scalar109.expr:null);
                        
                        VariableReference varId = new VariableReference(varNameLeft, varNameRight, varName);

                        Expression assignExpr = new Assignment(startIndex, endIndex, varId, Assignment.OP_EQUAL, expr);
                        if (inClassStatementList) {
                          Object obj = new ASTNode[] {varId, expr};
                          ((class_statement_scope)class_statement_stack.peek()).varList.add(assignExpr);
                        }
                        else {
                          ((static_var_list_scope)static_var_list_stack.peek()).varList.add(assignExpr);
                        }
                      

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "static_var_element"

    protected static class if_stat_scope {
        List conditionList;
        List statementList;
        List tokenList;
    }
    protected Stack if_stat_stack = new Stack();

    public static class if_stat_return extends TreeRuleReturnScope {
        public Statement stat;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "if_stat"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:747:1: if_stat returns [Statement stat] : ^( IF_T ^( CONDITION expression ) ( ( inner_statement_list )? ( else_if_stat )* ( ^( ELSE_T statement ) )? ) ) ;
    public final TreePHP.if_stat_return if_stat() throws RecognitionException {
        if_stat_stack.push(new if_stat_scope());
        TreePHP.if_stat_return retval = new TreePHP.if_stat_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST IF_T110=null;
        SLAST CONDITION111=null;
        SLAST ELSE_T115=null;
        TreePHP.expression_return expression112 = null;

        TreePHP.inner_statement_list_return inner_statement_list113 = null;

        TreePHP.else_if_stat_return else_if_stat114 = null;

        TreePHP.statement_return statement116 = null;


        SLAST IF_T110_tree=null;
        SLAST CONDITION111_tree=null;
        SLAST ELSE_T115_tree=null;


          ((if_stat_scope)if_stat_stack.peek()).conditionList = new LinkedList();
          ((if_stat_scope)if_stat_stack.peek()).statementList = new LinkedList();
          ((if_stat_scope)if_stat_stack.peek()).tokenList = new LinkedList();

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:758:3: ( ^( IF_T ^( CONDITION expression ) ( ( inner_statement_list )? ( else_if_stat )* ( ^( ELSE_T statement ) )? ) ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:758:5: ^( IF_T ^( CONDITION expression ) ( ( inner_statement_list )? ( else_if_stat )* ( ^( ELSE_T statement ) )? ) )
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_1 = _last;
            SLAST _first_1 = null;
            SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            IF_T110=(SLAST)match(input,IF_T,FOLLOW_IF_T_in_if_stat1296); 
            IF_T110_tree = (SLAST)adaptor.dupNode(IF_T110);

            root_1 = (SLAST)adaptor.becomeRoot(IF_T110_tree, root_1);



            match(input, Token.DOWN, null); 
            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_2 = _last;
            SLAST _first_2 = null;
            SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            CONDITION111=(SLAST)match(input,CONDITION,FOLLOW_CONDITION_in_if_stat1300); 
            CONDITION111_tree = (SLAST)adaptor.dupNode(CONDITION111);

            root_2 = (SLAST)adaptor.becomeRoot(CONDITION111_tree, root_2);



            match(input, Token.DOWN, null); 
            _last = (SLAST)input.LT(1);
            pushFollow(FOLLOW_expression_in_if_stat1302);
            expression112=expression();

            state._fsp--;

            adaptor.addChild(root_2, expression112.getTree());

            match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:759:5: ( ( inner_statement_list )? ( else_if_stat )* ( ^( ELSE_T statement ) )? )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:760:7: ( inner_statement_list )? ( else_if_stat )* ( ^( ELSE_T statement ) )?
            {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:760:7: ( inner_statement_list )?
            int alt39=2;
            int LA39_0 = input.LA(1);

            if ( (LA39_0==METHOD_DECL||LA39_0==STATEMENT||LA39_0==CLASS_T||LA39_0==INTERFACE_T||LA39_0==166) ) {
                alt39=1;
            }
            switch (alt39) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:760:7: inner_statement_list
                    {
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_inner_statement_list_in_if_stat1318);
                    inner_statement_list113=inner_statement_list();

                    state._fsp--;

                    adaptor.addChild(root_1, inner_statement_list113.getTree());

                    }
                    break;

            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:761:7: ( else_if_stat )*
            loop40:
            do {
                int alt40=2;
                int LA40_0 = input.LA(1);

                if ( (LA40_0==ELSEIF_T) ) {
                    alt40=1;
                }


                switch (alt40) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:761:7: else_if_stat
            	    {
            	    _last = (SLAST)input.LT(1);
            	    pushFollow(FOLLOW_else_if_stat_in_if_stat1327);
            	    else_if_stat114=else_if_stat();

            	    state._fsp--;

            	    adaptor.addChild(root_1, else_if_stat114.getTree());

            	    }
            	    break;

            	default :
            	    break loop40;
                }
            } while (true);

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:761:21: ( ^( ELSE_T statement ) )?
            int alt41=2;
            int LA41_0 = input.LA(1);

            if ( (LA41_0==ELSE_T) ) {
                alt41=1;
            }
            switch (alt41) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:761:22: ^( ELSE_T statement )
                    {
                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_2 = _last;
                    SLAST _first_2 = null;
                    SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    ELSE_T115=(SLAST)match(input,ELSE_T,FOLLOW_ELSE_T_in_if_stat1332); 
                    ELSE_T115_tree = (SLAST)adaptor.dupNode(ELSE_T115);

                    root_2 = (SLAST)adaptor.becomeRoot(ELSE_T115_tree, root_2);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_statement_in_if_stat1334);
                    statement116=statement();

                    state._fsp--;

                    adaptor.addChild(root_2, statement116.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
                    }


                    }
                    break;

            }


            }


            match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


                  int startIndex = IF_T110.startIndex;
                  int endIndex = IF_T110.endIndex + 1;
                  System.out.println("if:" + startIndex + " " + endIndex);
                  Expression innerCondition = null; 
                  Statement trueStatement = null;
                  Statement falseStatement = (statement116!=null?statement116.stat:null);
                  Iterator iterCond = ((if_stat_scope)if_stat_stack.peek()).conditionList.iterator(),
                          iterIfTrueStat = ((if_stat_scope)if_stat_stack.peek()).statementList.iterator(),
                          iterTokenList = ((if_stat_scope)if_stat_stack.peek()).tokenList.iterator();
                  while (iterCond.hasNext()) {
                     innerCondition = (Expression)iterCond.next();
                     trueStatement = (Statement)iterIfTrueStat.next();
                     int start = (Integer)iterTokenList.next();
                     falseStatement = new IfStatement(start, 999, innerCondition, trueStatement, falseStatement);
                  }
                  
                  int sid = ((CommonToken)(inner_statement_list113!=null?((SLAST)inner_statement_list113.tree):null).token).getStartIndex();
                  int eid = ((CommonToken)(inner_statement_list113!=null?((SLAST)inner_statement_list113.tree):null).token).getStopIndex() + 1;
                  Block block = new Block(sid, eid, new LinkedList());
                  if ((inner_statement_list113!=null?inner_statement_list113.innerStatementList:null) != null) {
                    block.getStatements().clear();
                    block.acceptStatements((inner_statement_list113!=null?inner_statement_list113.innerStatementList:null));
                  }
                  retval.stat = new IfStatement(startIndex, endIndex, (expression112!=null?expression112.expr:null), block, falseStatement);  
                

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
            if_stat_stack.pop();
        }
        return retval;
    }
    // $ANTLR end "if_stat"

    public static class else_if_stat_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "else_if_stat"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:791:1: else_if_stat : ^( ELSEIF_T ^( CONDITION expression ) ( inner_statement_list )? ) ;
    public final TreePHP.else_if_stat_return else_if_stat() throws RecognitionException {
        TreePHP.else_if_stat_return retval = new TreePHP.else_if_stat_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST ELSEIF_T117=null;
        SLAST CONDITION118=null;
        TreePHP.expression_return expression119 = null;

        TreePHP.inner_statement_list_return inner_statement_list120 = null;


        SLAST ELSEIF_T117_tree=null;
        SLAST CONDITION118_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:792:3: ( ^( ELSEIF_T ^( CONDITION expression ) ( inner_statement_list )? ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:792:5: ^( ELSEIF_T ^( CONDITION expression ) ( inner_statement_list )? )
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_1 = _last;
            SLAST _first_1 = null;
            SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            ELSEIF_T117=(SLAST)match(input,ELSEIF_T,FOLLOW_ELSEIF_T_in_else_if_stat1364); 
            ELSEIF_T117_tree = (SLAST)adaptor.dupNode(ELSEIF_T117);

            root_1 = (SLAST)adaptor.becomeRoot(ELSEIF_T117_tree, root_1);



            match(input, Token.DOWN, null); 
            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_2 = _last;
            SLAST _first_2 = null;
            SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            CONDITION118=(SLAST)match(input,CONDITION,FOLLOW_CONDITION_in_else_if_stat1367); 
            CONDITION118_tree = (SLAST)adaptor.dupNode(CONDITION118);

            root_2 = (SLAST)adaptor.becomeRoot(CONDITION118_tree, root_2);



            match(input, Token.DOWN, null); 
            _last = (SLAST)input.LT(1);
            pushFollow(FOLLOW_expression_in_else_if_stat1369);
            expression119=expression();

            state._fsp--;

            adaptor.addChild(root_2, expression119.getTree());

            match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:792:40: ( inner_statement_list )?
            int alt42=2;
            int LA42_0 = input.LA(1);

            if ( (LA42_0==METHOD_DECL||LA42_0==STATEMENT||LA42_0==CLASS_T||LA42_0==INTERFACE_T||LA42_0==166) ) {
                alt42=1;
            }
            switch (alt42) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:792:40: inner_statement_list
                    {
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_inner_statement_list_in_else_if_stat1372);
                    inner_statement_list120=inner_statement_list();

                    state._fsp--;

                    adaptor.addChild(root_1, inner_statement_list120.getTree());

                    }
                    break;

            }


            match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


                int startIndex = ELSEIF_T117.startIndex;
                ((if_stat_scope)if_stat_stack.peek()).conditionList.add((expression119!=null?expression119.expr:null));
                
                Block block = new Block(999, 999, new LinkedList());
                if ((inner_statement_list120!=null?inner_statement_list120.innerStatementList:null) != null) {
                  block.getStatements().clear();
                  block.acceptStatements((inner_statement_list120!=null?inner_statement_list120.innerStatementList:null));
                }
                ((if_stat_scope)if_stat_stack.peek()).statementList.add(block);
                ((if_stat_scope)if_stat_stack.peek()).tokenList.add(startIndex);
              

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "else_if_stat"

    protected static class switch_case_list_scope {
        List list;
    }
    protected Stack switch_case_list_stack = new Stack();

    public static class switch_case_list_return extends TreeRuleReturnScope {
        public Block block;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "switch_case_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:808:1: switch_case_list returns [Block block] : ( case_list )+ ;
    public final TreePHP.switch_case_list_return switch_case_list() throws RecognitionException {
        switch_case_list_stack.push(new switch_case_list_scope());
        TreePHP.switch_case_list_return retval = new TreePHP.switch_case_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.case_list_return case_list121 = null;




          ((switch_case_list_scope)switch_case_list_stack.peek()).list = new LinkedList();

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:815:3: ( ( case_list )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:815:5: ( case_list )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:815:5: ( case_list )+
            int cnt43=0;
            loop43:
            do {
                int alt43=2;
                int LA43_0 = input.LA(1);

                if ( ((LA43_0>=CASE_T && LA43_0<=DEFAULT_T)) ) {
                    alt43=1;
                }


                switch (alt43) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:815:5: case_list
            	    {
            	    _last = (SLAST)input.LT(1);
            	    pushFollow(FOLLOW_case_list_in_switch_case_list1406);
            	    case_list121=case_list();

            	    state._fsp--;

            	    adaptor.addChild(root_0, case_list121.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt43 >= 1 ) break loop43;
                        EarlyExitException eee =
                            new EarlyExitException(43, input);
                        throw eee;
                }
                cnt43++;
            } while (true);


                int startIndex = -1;
                int endIndex = -1;
                Block block = new Block(startIndex, endIndex, new LinkedList());
                block.getStatements().clear();
                block.acceptStatements(((switch_case_list_scope)switch_case_list_stack.peek()).list);
                retval.block = block;
              

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
            switch_case_list_stack.pop();
        }
        return retval;
    }
    // $ANTLR end "switch_case_list"

    public static class case_list_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "case_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:826:1: case_list : ( ^( CASE_T e= expression ( inner_statement_list )? ) | ^( DEFAULT_T ( inner_statement_list )? ) );
    public final TreePHP.case_list_return case_list() throws RecognitionException {
        TreePHP.case_list_return retval = new TreePHP.case_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST CASE_T122=null;
        SLAST DEFAULT_T124=null;
        TreePHP.expression_return e = null;

        TreePHP.inner_statement_list_return inner_statement_list123 = null;

        TreePHP.inner_statement_list_return inner_statement_list125 = null;


        SLAST CASE_T122_tree=null;
        SLAST DEFAULT_T124_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:827:3: ( ^( CASE_T e= expression ( inner_statement_list )? ) | ^( DEFAULT_T ( inner_statement_list )? ) )
            int alt46=2;
            int LA46_0 = input.LA(1);

            if ( (LA46_0==CASE_T) ) {
                alt46=1;
            }
            else if ( (LA46_0==DEFAULT_T) ) {
                alt46=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 46, 0, input);

                throw nvae;
            }
            switch (alt46) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:827:5: ^( CASE_T e= expression ( inner_statement_list )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    CASE_T122=(SLAST)match(input,CASE_T,FOLLOW_CASE_T_in_case_list1425); 
                    CASE_T122_tree = (SLAST)adaptor.dupNode(CASE_T122);

                    root_1 = (SLAST)adaptor.becomeRoot(CASE_T122_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_case_list1429);
                    e=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e.getTree());
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:827:27: ( inner_statement_list )?
                    int alt44=2;
                    int LA44_0 = input.LA(1);

                    if ( (LA44_0==METHOD_DECL||LA44_0==STATEMENT||LA44_0==CLASS_T||LA44_0==INTERFACE_T||LA44_0==166) ) {
                        alt44=1;
                    }
                    switch (alt44) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:827:27: inner_statement_list
                            {
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_inner_statement_list_in_case_list1431);
                            inner_statement_list123=inner_statement_list();

                            state._fsp--;

                            adaptor.addChild(root_1, inner_statement_list123.getTree());

                            }
                            break;

                    }


                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = CASE_T122.startIndex;
                        int endIndex = CASE_T122.endIndex + 1;
                        List list = new LinkedList();
                        if ((inner_statement_list123!=null?inner_statement_list123.innerStatementList:null) != null) {
                          list = (inner_statement_list123!=null?inner_statement_list123.innerStatementList:null);
                        }
                        SwitchCase switchCase = new SwitchCase(startIndex, endIndex, (e!=null?e.expr:null), list, false);
                        ((switch_case_list_scope)switch_case_list_stack.peek()).list.add(switchCase);
                      

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:838:5: ^( DEFAULT_T ( inner_statement_list )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    DEFAULT_T124=(SLAST)match(input,DEFAULT_T,FOLLOW_DEFAULT_T_in_case_list1446); 
                    DEFAULT_T124_tree = (SLAST)adaptor.dupNode(DEFAULT_T124);

                    root_1 = (SLAST)adaptor.becomeRoot(DEFAULT_T124_tree, root_1);



                    if ( input.LA(1)==Token.DOWN ) {
                        match(input, Token.DOWN, null); 
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:838:17: ( inner_statement_list )?
                        int alt45=2;
                        int LA45_0 = input.LA(1);

                        if ( (LA45_0==METHOD_DECL||LA45_0==STATEMENT||LA45_0==CLASS_T||LA45_0==INTERFACE_T||LA45_0==166) ) {
                            alt45=1;
                        }
                        switch (alt45) {
                            case 1 :
                                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:838:17: inner_statement_list
                                {
                                _last = (SLAST)input.LT(1);
                                pushFollow(FOLLOW_inner_statement_list_in_case_list1448);
                                inner_statement_list125=inner_statement_list();

                                state._fsp--;

                                adaptor.addChild(root_1, inner_statement_list125.getTree());

                                }
                                break;

                        }


                        match(input, Token.UP, null); 
                    }adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = DEFAULT_T124.startIndex;
                        int endIndex = DEFAULT_T124.endIndex + 1;
                        List list = new LinkedList();
                        if ((inner_statement_list125!=null?inner_statement_list125.innerStatementList:null) != null) {
                          list = (inner_statement_list125!=null?inner_statement_list125.innerStatementList:null);
                        }
                        SwitchCase switchCase = new SwitchCase(startIndex, endIndex, null, list, true);
                        ((switch_case_list_scope)switch_case_list_stack.peek()).list.add(switchCase);
                      

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "case_list"

    protected static class catch_branch_list_scope {
        List list;
    }
    protected Stack catch_branch_list_stack = new Stack();

    public static class catch_branch_list_return extends TreeRuleReturnScope {
        public List catchList;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "catch_branch_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:851:1: catch_branch_list returns [List catchList] : ( catch_branch )+ ;
    public final TreePHP.catch_branch_list_return catch_branch_list() throws RecognitionException {
        catch_branch_list_stack.push(new catch_branch_list_scope());
        TreePHP.catch_branch_list_return retval = new TreePHP.catch_branch_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.catch_branch_return catch_branch126 = null;




          ((catch_branch_list_scope)catch_branch_list_stack.peek()).list = new LinkedList();

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:858:3: ( ( catch_branch )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:858:5: ( catch_branch )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:858:5: ( catch_branch )+
            int cnt47=0;
            loop47:
            do {
                int alt47=2;
                int LA47_0 = input.LA(1);

                if ( (LA47_0==CATCH_T) ) {
                    alt47=1;
                }


                switch (alt47) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:858:5: catch_branch
            	    {
            	    _last = (SLAST)input.LT(1);
            	    pushFollow(FOLLOW_catch_branch_in_catch_branch_list1482);
            	    catch_branch126=catch_branch();

            	    state._fsp--;

            	    adaptor.addChild(root_0, catch_branch126.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt47 >= 1 ) break loop47;
                        EarlyExitException eee =
                            new EarlyExitException(47, input);
                        throw eee;
                }
                cnt47++;
            } while (true);


                retval.catchList = ((catch_branch_list_scope)catch_branch_list_stack.peek()).list;
              

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
            catch_branch_list_stack.pop();
        }
        return retval;
    }
    // $ANTLR end "catch_branch_list"

    public static class catch_branch_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "catch_branch"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:864:1: catch_branch : ^( CATCH_T fully_qualified_class_name variable block ) ;
    public final TreePHP.catch_branch_return catch_branch() throws RecognitionException {
        TreePHP.catch_branch_return retval = new TreePHP.catch_branch_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST CATCH_T127=null;
        TreePHP.fully_qualified_class_name_return fully_qualified_class_name128 = null;

        TreePHP.variable_return variable129 = null;

        TreePHP.block_return block130 = null;


        SLAST CATCH_T127_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:865:3: ( ^( CATCH_T fully_qualified_class_name variable block ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:865:5: ^( CATCH_T fully_qualified_class_name variable block )
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_1 = _last;
            SLAST _first_1 = null;
            SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            CATCH_T127=(SLAST)match(input,CATCH_T,FOLLOW_CATCH_T_in_catch_branch1504); 
            CATCH_T127_tree = (SLAST)adaptor.dupNode(CATCH_T127);

            root_1 = (SLAST)adaptor.becomeRoot(CATCH_T127_tree, root_1);



            match(input, Token.DOWN, null); 
            _last = (SLAST)input.LT(1);
            pushFollow(FOLLOW_fully_qualified_class_name_in_catch_branch1506);
            fully_qualified_class_name128=fully_qualified_class_name();

            state._fsp--;

            adaptor.addChild(root_1, fully_qualified_class_name128.getTree());
            _last = (SLAST)input.LT(1);
            pushFollow(FOLLOW_variable_in_catch_branch1508);
            variable129=variable();

            state._fsp--;

            adaptor.addChild(root_1, variable129.getTree());
            _last = (SLAST)input.LT(1);
            pushFollow(FOLLOW_block_in_catch_branch1510);
            block130=block();

            state._fsp--;

            adaptor.addChild(root_1, block130.getTree());

            match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


                int startIndex = CATCH_T127.startIndex;
                int endIndex = CATCH_T127.endIndex + 1;
                CatchClause catchClause = new CatchClause(startIndex, endIndex, (fully_qualified_class_name128!=null?fully_qualified_class_name128.type:null), (VariableReference)(variable129!=null?variable129.var:null), (Block)(block130!=null?block130.stat:null));
                ((catch_branch_list_scope)catch_branch_list_stack.peek()).list.add(catchClause);
              

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "catch_branch"

    public static class for_statement_return extends TreeRuleReturnScope {
        public Statement block;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "for_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:874:1: for_statement returns [Statement block] : ( inner_statement_list )? ;
    public final TreePHP.for_statement_return for_statement() throws RecognitionException {
        TreePHP.for_statement_return retval = new TreePHP.for_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.inner_statement_list_return inner_statement_list131 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:875:2: ( ( inner_statement_list )? )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:875:4: ( inner_statement_list )?
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:875:4: ( inner_statement_list )?
            int alt48=2;
            int LA48_0 = input.LA(1);

            if ( (LA48_0==METHOD_DECL||LA48_0==STATEMENT||LA48_0==CLASS_T||LA48_0==INTERFACE_T||LA48_0==166) ) {
                alt48=1;
            }
            switch (alt48) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:875:4: inner_statement_list
                    {
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_inner_statement_list_in_for_statement1531);
                    inner_statement_list131=inner_statement_list();

                    state._fsp--;

                    adaptor.addChild(root_0, inner_statement_list131.getTree());

                    }
                    break;

            }


                  int startIndex = -1;
                  int endIndex = -1;
                  Block block = new Block(startIndex, endIndex, new LinkedList());
                  if ((inner_statement_list131!=null?inner_statement_list131.innerStatementList:null) != null) {
                    block.getStatements().clear();
                    block.acceptStatements((inner_statement_list131!=null?inner_statement_list131.innerStatementList:null));
                  }

                  retval.block = block;
                  System.out.println("what block" + block);
                

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "for_statement"

    public static class while_statement_return extends TreeRuleReturnScope {
        public Statement block;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "while_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:890:1: while_statement returns [Statement block] : ( inner_statement_list )? ;
    public final TreePHP.while_statement_return while_statement() throws RecognitionException {
        TreePHP.while_statement_return retval = new TreePHP.while_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.inner_statement_list_return inner_statement_list132 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:891:3: ( ( inner_statement_list )? )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:891:5: ( inner_statement_list )?
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:891:5: ( inner_statement_list )?
            int alt49=2;
            int LA49_0 = input.LA(1);

            if ( (LA49_0==METHOD_DECL||LA49_0==STATEMENT||LA49_0==CLASS_T||LA49_0==INTERFACE_T||LA49_0==166) ) {
                alt49=1;
            }
            switch (alt49) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:891:5: inner_statement_list
                    {
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_inner_statement_list_in_while_statement1554);
                    inner_statement_list132=inner_statement_list();

                    state._fsp--;

                    adaptor.addChild(root_0, inner_statement_list132.getTree());

                    }
                    break;

            }


                  int startIndex = -1;
                  int endIndex = -1;
                  Block block = new Block(startIndex, endIndex, new LinkedList());
                  if ((inner_statement_list132!=null?inner_statement_list132.innerStatementList:null) != null) {
                    block.getStatements().clear();
                    block.acceptStatements((inner_statement_list132!=null?inner_statement_list132.innerStatementList:null));
                  }
                  retval.block = block;
                

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "while_statement"

    public static class foreach_statement_return extends TreeRuleReturnScope {
        public Statement block;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "foreach_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:904:1: foreach_statement returns [Statement block] : ( inner_statement_list )? ;
    public final TreePHP.foreach_statement_return foreach_statement() throws RecognitionException {
        TreePHP.foreach_statement_return retval = new TreePHP.foreach_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.inner_statement_list_return inner_statement_list133 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:905:3: ( ( inner_statement_list )? )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:905:5: ( inner_statement_list )?
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:905:5: ( inner_statement_list )?
            int alt50=2;
            int LA50_0 = input.LA(1);

            if ( (LA50_0==METHOD_DECL||LA50_0==STATEMENT||LA50_0==CLASS_T||LA50_0==INTERFACE_T||LA50_0==166) ) {
                alt50=1;
            }
            switch (alt50) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:905:5: inner_statement_list
                    {
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_inner_statement_list_in_foreach_statement1579);
                    inner_statement_list133=inner_statement_list();

                    state._fsp--;

                    adaptor.addChild(root_0, inner_statement_list133.getTree());

                    }
                    break;

            }


                  int startIndex = -1;
                  int endIndex = -1;
                  Block block = new Block(startIndex, endIndex, new LinkedList());
                  if ((inner_statement_list133!=null?inner_statement_list133.innerStatementList:null) != null) {
                    block.getStatements().clear();
                    block.acceptStatements((inner_statement_list133!=null?inner_statement_list133.innerStatementList:null));
                  }
                  retval.block = block;
                

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "foreach_statement"

    public static class declare_statement_return extends TreeRuleReturnScope {
        public Statement block;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "declare_statement"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:918:1: declare_statement returns [Statement block] : ( inner_statement_list )? ;
    public final TreePHP.declare_statement_return declare_statement() throws RecognitionException {
        TreePHP.declare_statement_return retval = new TreePHP.declare_statement_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.inner_statement_list_return inner_statement_list134 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:919:3: ( ( inner_statement_list )? )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:920:3: ( inner_statement_list )?
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:920:3: ( inner_statement_list )?
            int alt51=2;
            int LA51_0 = input.LA(1);

            if ( (LA51_0==METHOD_DECL||LA51_0==STATEMENT||LA51_0==CLASS_T||LA51_0==INTERFACE_T||LA51_0==166) ) {
                alt51=1;
            }
            switch (alt51) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:920:3: inner_statement_list
                    {
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_inner_statement_list_in_declare_statement1607);
                    inner_statement_list134=inner_statement_list();

                    state._fsp--;

                    adaptor.addChild(root_0, inner_statement_list134.getTree());

                    }
                    break;

            }


                  System.out.println("declare stat");
                  int startIndex = -1;
                  int endIndex = -1;
                  Block block = new Block(startIndex, endIndex, new LinkedList());
                  if ((inner_statement_list134!=null?inner_statement_list134.innerStatementList:null) != null) {
            			  block.getStatements().clear();
            			  block.acceptStatements((inner_statement_list134!=null?inner_statement_list134.innerStatementList:null));
            			}
            			retval.block = block;
            			System.out.println("block: " + block);
                

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "declare_statement"

    protected static class parameter_list_scope {
        List paramList;
    }
    protected Stack parameter_list_stack = new Stack();

    public static class parameter_list_return extends TreeRuleReturnScope {
        public List parameterList;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "parameter_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:935:1: parameter_list returns [List parameterList] : ( parameter )+ ;
    public final TreePHP.parameter_list_return parameter_list() throws RecognitionException {
        parameter_list_stack.push(new parameter_list_scope());
        TreePHP.parameter_list_return retval = new TreePHP.parameter_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.parameter_return parameter135 = null;




          ((parameter_list_scope)parameter_list_stack.peek()).paramList = new LinkedList();

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:942:3: ( ( parameter )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:942:5: ( parameter )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:942:5: ( parameter )+
            int cnt52=0;
            loop52:
            do {
                int alt52=2;
                int LA52_0 = input.LA(1);

                if ( (LA52_0==PARAMETER) ) {
                    alt52=1;
                }


                switch (alt52) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:942:5: parameter
            	    {
            	    _last = (SLAST)input.LT(1);
            	    pushFollow(FOLLOW_parameter_in_parameter_list1642);
            	    parameter135=parameter();

            	    state._fsp--;

            	    adaptor.addChild(root_0, parameter135.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt52 >= 1 ) break loop52;
                        EarlyExitException eee =
                            new EarlyExitException(52, input);
                        throw eee;
                }
                cnt52++;
            } while (true);


                retval.parameterList = ((parameter_list_scope)parameter_list_stack.peek()).paramList;
              

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
            parameter_list_stack.pop();
        }
        return retval;
    }
    // $ANTLR end "parameter_list"

    public static class parameter_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "parameter"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:948:1: parameter : ^( PARAMETER ( ^( TYPE parameter_type ) )? ( CONST_T )? pure_variable ( scalar )? ) ;
    public final TreePHP.parameter_return parameter() throws RecognitionException {
        TreePHP.parameter_return retval = new TreePHP.parameter_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST PARAMETER136=null;
        SLAST TYPE137=null;
        SLAST CONST_T139=null;
        TreePHP.parameter_type_return parameter_type138 = null;

        TreePHP.pure_variable_return pure_variable140 = null;

        TreePHP.scalar_return scalar141 = null;


        SLAST PARAMETER136_tree=null;
        SLAST TYPE137_tree=null;
        SLAST CONST_T139_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:949:3: ( ^( PARAMETER ( ^( TYPE parameter_type ) )? ( CONST_T )? pure_variable ( scalar )? ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:949:5: ^( PARAMETER ( ^( TYPE parameter_type ) )? ( CONST_T )? pure_variable ( scalar )? )
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_1 = _last;
            SLAST _first_1 = null;
            SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            PARAMETER136=(SLAST)match(input,PARAMETER,FOLLOW_PARAMETER_in_parameter1663); 
            PARAMETER136_tree = (SLAST)adaptor.dupNode(PARAMETER136);

            root_1 = (SLAST)adaptor.becomeRoot(PARAMETER136_tree, root_1);



            match(input, Token.DOWN, null); 
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:949:17: ( ^( TYPE parameter_type ) )?
            int alt53=2;
            int LA53_0 = input.LA(1);

            if ( (LA53_0==TYPE) ) {
                alt53=1;
            }
            switch (alt53) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:949:18: ^( TYPE parameter_type )
                    {
                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_2 = _last;
                    SLAST _first_2 = null;
                    SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    TYPE137=(SLAST)match(input,TYPE,FOLLOW_TYPE_in_parameter1667); 
                    TYPE137_tree = (SLAST)adaptor.dupNode(TYPE137);

                    root_2 = (SLAST)adaptor.becomeRoot(TYPE137_tree, root_2);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_parameter_type_in_parameter1669);
                    parameter_type138=parameter_type();

                    state._fsp--;

                    adaptor.addChild(root_2, parameter_type138.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
                    }


                    }
                    break;

            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:949:43: ( CONST_T )?
            int alt54=2;
            int LA54_0 = input.LA(1);

            if ( (LA54_0==CONST_T) ) {
                alt54=1;
            }
            switch (alt54) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:949:43: CONST_T
                    {
                    _last = (SLAST)input.LT(1);
                    CONST_T139=(SLAST)match(input,CONST_T,FOLLOW_CONST_T_in_parameter1674); 
                    CONST_T139_tree = (SLAST)adaptor.dupNode(CONST_T139);

                    adaptor.addChild(root_1, CONST_T139_tree);


                    }
                    break;

            }

            _last = (SLAST)input.LT(1);
            pushFollow(FOLLOW_pure_variable_in_parameter1677);
            pure_variable140=pure_variable();

            state._fsp--;

            adaptor.addChild(root_1, pure_variable140.getTree());
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:949:66: ( scalar )?
            int alt55=2;
            int LA55_0 = input.LA(1);

            if ( (LA55_0==SCALAR) ) {
                alt55=1;
            }
            switch (alt55) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:949:66: scalar
                    {
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_scalar_in_parameter1679);
                    scalar141=scalar();

                    state._fsp--;

                    adaptor.addChild(root_1, scalar141.getTree());

                    }
                    break;

            }


            match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


                FormalParameter RESULT = null;
                TypeReference classType = (parameter_type138!=null?parameter_type138.type:null);
                int varLeft = ((CommonToken)(pure_variable140!=null?((SLAST)pure_variable140.tree):null).token).getStartIndex();
                int varRight = ((CommonToken)(pure_variable140!=null?((SLAST)pure_variable140.tree):null).token).getStopIndex() + 1;
                String varName = (pure_variable140!=null?(input.getTokenStream().toString(
              input.getTreeAdaptor().getTokenStartIndex(pure_variable140.start),
              input.getTreeAdaptor().getTokenStopIndex(pure_variable140.start))):null);
                
                int startIndex = PARAMETER136.startIndex;
                int endIndex = PARAMETER136.endIndex + 1;
                VariableReference var = new VariableReference(varLeft, varRight, varName, PHPVariableKind.LOCAL);
                
                if ((scalar141!=null?scalar141.expr:null) == null) {
                  ((parameter_list_scope)parameter_list_stack.peek()).paramList.add(new FormalParameter(startIndex, endIndex, classType, var));
                }
                else {
                  ((parameter_list_scope)parameter_list_stack.peek()).paramList.add(new FormalParameter(startIndex, endIndex, classType, var, (scalar141!=null?scalar141.expr:null)));
                }
              

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "parameter"

    public static class parameter_type_return extends TreeRuleReturnScope {
        public TypeReference type;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "parameter_type"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:970:1: parameter_type returns [TypeReference type] : ( fully_qualified_class_name | cast_option );
    public final TreePHP.parameter_type_return parameter_type() throws RecognitionException {
        TreePHP.parameter_type_return retval = new TreePHP.parameter_type_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.fully_qualified_class_name_return fully_qualified_class_name142 = null;

        TreePHP.cast_option_return cast_option143 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:971:3: ( fully_qualified_class_name | cast_option )
            int alt56=2;
            int LA56_0 = input.LA(1);

            if ( (LA56_0==IDENTIFIER||LA56_0==DOMAIN_T) ) {
                alt56=1;
            }
            else if ( (LA56_0==CLONE_T||(LA56_0>=173 && LA56_0<=182)) ) {
                alt56=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 56, 0, input);

                throw nvae;
            }
            switch (alt56) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:971:5: fully_qualified_class_name
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_fully_qualified_class_name_in_parameter_type1704);
                    fully_qualified_class_name142=fully_qualified_class_name();

                    state._fsp--;

                    adaptor.addChild(root_0, fully_qualified_class_name142.getTree());

                        retval.type = (fully_qualified_class_name142!=null?fully_qualified_class_name142.type:null);
                      

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:975:5: cast_option
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_cast_option_in_parameter_type1714);
                    cast_option143=cast_option();

                    state._fsp--;

                    adaptor.addChild(root_0, cast_option143.getTree());

                        int startIndex = ((CommonToken)(cast_option143!=null?((SLAST)cast_option143.tree):null).token).getStartIndex();
                        int endIndex = ((CommonToken)(cast_option143!=null?((SLAST)cast_option143.tree):null).token).getStopIndex() + 1;
                        retval.type = new TypeReference(startIndex, endIndex, (cast_option143!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(cast_option143.start),
                      input.getTreeAdaptor().getTokenStopIndex(cast_option143.start))):null));
                      

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "parameter_type"

    public static class variable_modifiers_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "variable_modifiers"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:983:1: variable_modifiers : ( 'var' | modifier );
    public final TreePHP.variable_modifiers_return variable_modifiers() throws RecognitionException {
        TreePHP.variable_modifiers_return retval = new TreePHP.variable_modifiers_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST string_literal144=null;
        TreePHP.modifier_return modifier145 = null;


        SLAST string_literal144_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:984:3: ( 'var' | modifier )
            int alt57=2;
            int LA57_0 = input.LA(1);

            if ( (LA57_0==169) ) {
                alt57=1;
            }
            else if ( (LA57_0==VAR_DECL||LA57_0==IDENTIFIER||LA57_0==REF_T||LA57_0==STATIC_T||LA57_0==EQUAL_T||(LA57_0>=167 && LA57_0<=168)||(LA57_0>=170 && LA57_0<=172)) ) {
                alt57=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 57, 0, input);

                throw nvae;
            }
            switch (alt57) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:984:5: 'var'
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    string_literal144=(SLAST)match(input,169,FOLLOW_169_in_variable_modifiers1732); 
                    string_literal144_tree = (SLAST)adaptor.dupNode(string_literal144);

                    adaptor.addChild(root_0, string_literal144_tree);


                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:985:5: modifier
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_modifier_in_variable_modifiers1738);
                    modifier145=modifier();

                    state._fsp--;

                    adaptor.addChild(root_0, modifier145.getTree());

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "variable_modifiers"

    protected static class modifier_scope {
        ModifierDocPair m;
    }
    protected Stack modifier_stack = new Stack();

    public static class modifier_return extends TreeRuleReturnScope {
        public ModifierDocPair modifierVar;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "modifier"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:988:1: modifier returns [ModifierDocPair modifierVar] : ( 'public' | 'protected' | 'private' | 'static' | 'abstract' | 'final' )* ;
    public final TreePHP.modifier_return modifier() throws RecognitionException {
        modifier_stack.push(new modifier_scope());
        TreePHP.modifier_return retval = new TreePHP.modifier_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST string_literal146=null;
        SLAST string_literal147=null;
        SLAST string_literal148=null;
        SLAST string_literal149=null;
        SLAST string_literal150=null;
        SLAST string_literal151=null;

        SLAST string_literal146_tree=null;
        SLAST string_literal147_tree=null;
        SLAST string_literal148_tree=null;
        SLAST string_literal149_tree=null;
        SLAST string_literal150_tree=null;
        SLAST string_literal151_tree=null;


          ((modifier_scope)modifier_stack.peek()).m = new ModifierDocPair(Modifiers.AccDefault, null);

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:995:3: ( ( 'public' | 'protected' | 'private' | 'static' | 'abstract' | 'final' )* )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:995:5: ( 'public' | 'protected' | 'private' | 'static' | 'abstract' | 'final' )*
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:995:5: ( 'public' | 'protected' | 'private' | 'static' | 'abstract' | 'final' )*
            loop58:
            do {
                int alt58=7;
                switch ( input.LA(1) ) {
                case 170:
                    {
                    alt58=1;
                    }
                    break;
                case 171:
                    {
                    alt58=2;
                    }
                    break;
                case 172:
                    {
                    alt58=3;
                    }
                    break;
                case STATIC_T:
                    {
                    alt58=4;
                    }
                    break;
                case 167:
                    {
                    alt58=5;
                    }
                    break;
                case 168:
                    {
                    alt58=6;
                    }
                    break;

                }

                switch (alt58) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:995:6: 'public'
            	    {
            	    _last = (SLAST)input.LT(1);
            	    string_literal146=(SLAST)match(input,170,FOLLOW_170_in_modifier1766); 
            	    string_literal146_tree = (SLAST)adaptor.dupNode(string_literal146);

            	    adaptor.addChild(root_0, string_literal146_tree);

            	    ((modifier_scope)modifier_stack.peek()).m = new ModifierDocPair(Modifiers.AccPublic, null);

            	    }
            	    break;
            	case 2 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:996:5: 'protected'
            	    {
            	    _last = (SLAST)input.LT(1);
            	    string_literal147=(SLAST)match(input,171,FOLLOW_171_in_modifier1774); 
            	    string_literal147_tree = (SLAST)adaptor.dupNode(string_literal147);

            	    adaptor.addChild(root_0, string_literal147_tree);

            	    ((modifier_scope)modifier_stack.peek()).m = new ModifierDocPair(Modifiers.AccProtected, null);

            	    }
            	    break;
            	case 3 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:997:5: 'private'
            	    {
            	    _last = (SLAST)input.LT(1);
            	    string_literal148=(SLAST)match(input,172,FOLLOW_172_in_modifier1782); 
            	    string_literal148_tree = (SLAST)adaptor.dupNode(string_literal148);

            	    adaptor.addChild(root_0, string_literal148_tree);

            	    ((modifier_scope)modifier_stack.peek()).m = new ModifierDocPair(Modifiers.AccPrivate, null);

            	    }
            	    break;
            	case 4 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:998:5: 'static'
            	    {
            	    _last = (SLAST)input.LT(1);
            	    string_literal149=(SLAST)match(input,STATIC_T,FOLLOW_STATIC_T_in_modifier1790); 
            	    string_literal149_tree = (SLAST)adaptor.dupNode(string_literal149);

            	    adaptor.addChild(root_0, string_literal149_tree);

            	    ((modifier_scope)modifier_stack.peek()).m = new ModifierDocPair(Modifiers.AccStatic, null);

            	    }
            	    break;
            	case 5 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:999:5: 'abstract'
            	    {
            	    _last = (SLAST)input.LT(1);
            	    string_literal150=(SLAST)match(input,167,FOLLOW_167_in_modifier1799); 
            	    string_literal150_tree = (SLAST)adaptor.dupNode(string_literal150);

            	    adaptor.addChild(root_0, string_literal150_tree);

            	    ((modifier_scope)modifier_stack.peek()).m = new ModifierDocPair(Modifiers.AccAbstract, null);

            	    }
            	    break;
            	case 6 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1000:5: 'final'
            	    {
            	    _last = (SLAST)input.LT(1);
            	    string_literal151=(SLAST)match(input,168,FOLLOW_168_in_modifier1808); 
            	    string_literal151_tree = (SLAST)adaptor.dupNode(string_literal151);

            	    adaptor.addChild(root_0, string_literal151_tree);

            	    ((modifier_scope)modifier_stack.peek()).m = new ModifierDocPair(Modifiers.AccFinal, null);

            	    }
            	    break;

            	default :
            	    break loop58;
                }
            } while (true);


                retval.modifierVar = ((modifier_scope)modifier_stack.peek()).m;
              

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
            modifier_stack.pop();
        }
        return retval;
    }
    // $ANTLR end "modifier"

    public static class directive_return extends TreeRuleReturnScope {
        public Object astNode;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "directive"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1007:1: directive returns [Object astNode] : ^( EQUAL_T IDENTIFIER expression ) ;
    public final TreePHP.directive_return directive() throws RecognitionException {
        TreePHP.directive_return retval = new TreePHP.directive_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST EQUAL_T152=null;
        SLAST IDENTIFIER153=null;
        TreePHP.expression_return expression154 = null;


        SLAST EQUAL_T152_tree=null;
        SLAST IDENTIFIER153_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1008:3: ( ^( EQUAL_T IDENTIFIER expression ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1008:5: ^( EQUAL_T IDENTIFIER expression )
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_1 = _last;
            SLAST _first_1 = null;
            SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            EQUAL_T152=(SLAST)match(input,EQUAL_T,FOLLOW_EQUAL_T_in_directive1840); 
            EQUAL_T152_tree = (SLAST)adaptor.dupNode(EQUAL_T152);

            root_1 = (SLAST)adaptor.becomeRoot(EQUAL_T152_tree, root_1);



            match(input, Token.DOWN, null); 
            _last = (SLAST)input.LT(1);
            IDENTIFIER153=(SLAST)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_directive1842); 
            IDENTIFIER153_tree = (SLAST)adaptor.dupNode(IDENTIFIER153);

            adaptor.addChild(root_1, IDENTIFIER153_tree);

            _last = (SLAST)input.LT(1);
            pushFollow(FOLLOW_expression_in_directive1844);
            expression154=expression();

            state._fsp--;

            adaptor.addChild(root_1, expression154.getTree());

            match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


                if (inClassStatementList) {
            	    int constNameleft = ((CommonToken)IDENTIFIER153.token).getStartIndex();
            	    int constNameright = ((CommonToken)IDENTIFIER153.token).getStopIndex() + 1;
            	    String constName = (IDENTIFIER153!=null?IDENTIFIER153.getText():null);
            	    int exprLeft = ((CommonToken)((expression154!=null?((SLAST)expression154.tree):null).token)).getStartIndex();
            	    int exprRight = ((CommonToken)((expression154!=null?((SLAST)expression154.tree):null).token)).getStopIndex() + 1;
            	    Expression expr = (expression154!=null?expression154.expr:null);
            	    
            	    ConstantReference constId = new ConstantReference(constNameleft, constNameright, constName);
            	    Object obj = new ASTNode[]{constId, expr};
            	    ((class_statement_scope)class_statement_stack.peek()).constList.add(obj);
            	  }
            	  else {
                  ((topStatement_scope)topStatement_stack.peek()).declareKey.add((IDENTIFIER153!=null?IDENTIFIER153.getText():null));
                  ((topStatement_scope)topStatement_stack.peek()).declareValue.add((expression154!=null?expression154.expr:null));
                }
              

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "directive"

    protected static class expr_list_scope {
        List list;
    }
    protected Stack expr_list_stack = new Stack();

    public static class expr_list_return extends TreeRuleReturnScope {
        public List exprList;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "expr_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1029:1: expr_list returns [List exprList] : ( expression )+ ;
    public final TreePHP.expr_list_return expr_list() throws RecognitionException {
        expr_list_stack.push(new expr_list_scope());
        TreePHP.expr_list_return retval = new TreePHP.expr_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.expression_return expression155 = null;




          ((expr_list_scope)expr_list_stack.peek()).list = new LinkedList();
          inExprList = true;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1040:2: ( ( expression )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1040:4: ( expression )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1040:4: ( expression )+
            int cnt59=0;
            loop59:
            do {
                int alt59=2;
                int LA59_0 = input.LA(1);

                if ( (LA59_0==VAR_DECL||LA59_0==CALL||LA59_0==EXPR||(LA59_0>=SCALAR && LA59_0<=UNARY_EXPR)||LA59_0==REF_T||LA59_0==EQUAL_T||(LA59_0>=OR_T && LA59_0<=CLONE_T)||(LA59_0>=INSTANCEOF_T && LA59_0<=PRINT_T)) ) {
                    alt59=1;
                }


                switch (alt59) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1040:4: expression
            	    {
            	    _last = (SLAST)input.LT(1);
            	    pushFollow(FOLLOW_expression_in_expr_list1881);
            	    expression155=expression();

            	    state._fsp--;

            	    adaptor.addChild(root_0, expression155.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt59 >= 1 ) break loop59;
                        EarlyExitException eee =
                            new EarlyExitException(59, input);
                        throw eee;
                }
                cnt59++;
            } while (true);


              retval.exprList = ((expr_list_scope)expr_list_stack.peek()).list;
             

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);


              inExprList = false;

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
            expr_list_stack.pop();
        }
        return retval;
    }
    // $ANTLR end "expr_list"

    public static class expression_return extends TreeRuleReturnScope {
        public Expression expr;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "expression"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1046:1: expression returns [Expression expr] : ( ^( EXPR etop= expression ) | ^( OR_T e1= expression e2= expression ) | ^( XOR_T e1= expression e2= expression ) | ^( AND_T e1= expression e2= expression ) | ^( EQUAL_T e1= expression e2= expression ) | ^( PLUS_EQ e1= expression e2= expression ) | ^( MINUS_EQ e1= expression e2= expression ) | ^( MUL_EQ e1= expression e2= expression ) | ^( DIV_EQ e1= expression e2= expression ) | ^( DOT_EQ e1= expression e2= expression ) | ^( PERCENT_EQ e1= expression e2= expression ) | ^( BIT_AND_EQ e1= expression e2= expression ) | ^( BIT_OR_EQ e1= expression e2= expression ) | ^( POWER_EQ e1= expression e2= expression ) | ^( LMOVE_EQ e1= expression e2= expression ) | ^( RMOVE_EQ e1= expression e2= expression ) | ^( QUESTION_T e1= expression ^( COLON_T e2= expression e3= expression ) ) | ^( LOGICAL_OR_T e1= expression e2= expression ) | ^( LOGICAL_AND_T e1= expression e2= expression ) | ^( BIT_OR_T e1= expression e2= expression ) | ^( POWER_T e1= expression e2= expression ) | ^( REF_T e1= expression e2= expression ) | ^( UNARY_EXPR unary_symbol_list e= expression ) | ^( DOT_T e1= expression e2= expression ) | ^( EQUAL_EQUAL_T e1= expression e2= expression ) | ^( NOT_EQUAL_T e1= expression e2= expression ) | ^( EQUAL_EQUAL_EQUAL_T e1= expression e2= expression ) | ^( NOT_EQUAL_EQUAL_T e1= expression e2= expression ) | ^( LT_T e1= expression e2= expression ) | ^( MT_T e1= expression e2= expression ) | ^( LE_T e1= expression e2= expression ) | ^( ME_T e1= expression e2= expression ) | ^( LSHIFT_T e1= expression e2= expression ) | ^( RSHIFT_T e1= expression e2= expression ) | ^( PLUS_T e1= expression e2= expression ) | ^( MINUS_T e1= expression e2= expression ) | ^( MUL_T e1= expression e2= expression ) | ^( DIV_T e1= expression e2= expression ) | ^( PERCENT_T e1= expression e2= expression ) | ^( CAST_EXPR cast_option e= expression ) | ^( POSTFIX_EXPR e= expression plus_minus ) | ^( PREFIX_EXPR ( plus_minus )+ e= expression ) | ^( INSTANCEOF_T e= expression class_name_reference ) | ( AT_T )? variable | ( AT_T )? scalar | list_decl | ^( ARRAY_DECL ( array_pair_list )? ) | ^( NEW_T class_name_reference ) | ^( CLONE_T variable ) | BACKTRICKLITERAL | ^( PRINT_T e= expression ) );
    public final TreePHP.expression_return expression() throws RecognitionException {
        TreePHP.expression_return retval = new TreePHP.expression_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST EXPR156=null;
        SLAST OR_T157=null;
        SLAST XOR_T158=null;
        SLAST AND_T159=null;
        SLAST EQUAL_T160=null;
        SLAST PLUS_EQ161=null;
        SLAST MINUS_EQ162=null;
        SLAST MUL_EQ163=null;
        SLAST DIV_EQ164=null;
        SLAST DOT_EQ165=null;
        SLAST PERCENT_EQ166=null;
        SLAST BIT_AND_EQ167=null;
        SLAST BIT_OR_EQ168=null;
        SLAST POWER_EQ169=null;
        SLAST LMOVE_EQ170=null;
        SLAST RMOVE_EQ171=null;
        SLAST QUESTION_T172=null;
        SLAST COLON_T173=null;
        SLAST LOGICAL_OR_T174=null;
        SLAST LOGICAL_AND_T175=null;
        SLAST BIT_OR_T176=null;
        SLAST POWER_T177=null;
        SLAST REF_T178=null;
        SLAST UNARY_EXPR179=null;
        SLAST DOT_T181=null;
        SLAST EQUAL_EQUAL_T182=null;
        SLAST NOT_EQUAL_T183=null;
        SLAST EQUAL_EQUAL_EQUAL_T184=null;
        SLAST NOT_EQUAL_EQUAL_T185=null;
        SLAST LT_T186=null;
        SLAST MT_T187=null;
        SLAST LE_T188=null;
        SLAST ME_T189=null;
        SLAST LSHIFT_T190=null;
        SLAST RSHIFT_T191=null;
        SLAST PLUS_T192=null;
        SLAST MINUS_T193=null;
        SLAST MUL_T194=null;
        SLAST DIV_T195=null;
        SLAST PERCENT_T196=null;
        SLAST CAST_EXPR197=null;
        SLAST POSTFIX_EXPR199=null;
        SLAST PREFIX_EXPR201=null;
        SLAST INSTANCEOF_T203=null;
        SLAST AT_T205=null;
        SLAST AT_T207=null;
        SLAST ARRAY_DECL210=null;
        SLAST NEW_T212=null;
        SLAST CLONE_T214=null;
        SLAST BACKTRICKLITERAL216=null;
        SLAST PRINT_T217=null;
        TreePHP.expression_return etop = null;

        TreePHP.expression_return e1 = null;

        TreePHP.expression_return e2 = null;

        TreePHP.expression_return e3 = null;

        TreePHP.expression_return e = null;

        TreePHP.unary_symbol_list_return unary_symbol_list180 = null;

        TreePHP.cast_option_return cast_option198 = null;

        TreePHP.plus_minus_return plus_minus200 = null;

        TreePHP.plus_minus_return plus_minus202 = null;

        TreePHP.class_name_reference_return class_name_reference204 = null;

        TreePHP.variable_return variable206 = null;

        TreePHP.scalar_return scalar208 = null;

        TreePHP.list_decl_return list_decl209 = null;

        TreePHP.array_pair_list_return array_pair_list211 = null;

        TreePHP.class_name_reference_return class_name_reference213 = null;

        TreePHP.variable_return variable215 = null;


        SLAST EXPR156_tree=null;
        SLAST OR_T157_tree=null;
        SLAST XOR_T158_tree=null;
        SLAST AND_T159_tree=null;
        SLAST EQUAL_T160_tree=null;
        SLAST PLUS_EQ161_tree=null;
        SLAST MINUS_EQ162_tree=null;
        SLAST MUL_EQ163_tree=null;
        SLAST DIV_EQ164_tree=null;
        SLAST DOT_EQ165_tree=null;
        SLAST PERCENT_EQ166_tree=null;
        SLAST BIT_AND_EQ167_tree=null;
        SLAST BIT_OR_EQ168_tree=null;
        SLAST POWER_EQ169_tree=null;
        SLAST LMOVE_EQ170_tree=null;
        SLAST RMOVE_EQ171_tree=null;
        SLAST QUESTION_T172_tree=null;
        SLAST COLON_T173_tree=null;
        SLAST LOGICAL_OR_T174_tree=null;
        SLAST LOGICAL_AND_T175_tree=null;
        SLAST BIT_OR_T176_tree=null;
        SLAST POWER_T177_tree=null;
        SLAST REF_T178_tree=null;
        SLAST UNARY_EXPR179_tree=null;
        SLAST DOT_T181_tree=null;
        SLAST EQUAL_EQUAL_T182_tree=null;
        SLAST NOT_EQUAL_T183_tree=null;
        SLAST EQUAL_EQUAL_EQUAL_T184_tree=null;
        SLAST NOT_EQUAL_EQUAL_T185_tree=null;
        SLAST LT_T186_tree=null;
        SLAST MT_T187_tree=null;
        SLAST LE_T188_tree=null;
        SLAST ME_T189_tree=null;
        SLAST LSHIFT_T190_tree=null;
        SLAST RSHIFT_T191_tree=null;
        SLAST PLUS_T192_tree=null;
        SLAST MINUS_T193_tree=null;
        SLAST MUL_T194_tree=null;
        SLAST DIV_T195_tree=null;
        SLAST PERCENT_T196_tree=null;
        SLAST CAST_EXPR197_tree=null;
        SLAST POSTFIX_EXPR199_tree=null;
        SLAST PREFIX_EXPR201_tree=null;
        SLAST INSTANCEOF_T203_tree=null;
        SLAST AT_T205_tree=null;
        SLAST AT_T207_tree=null;
        SLAST ARRAY_DECL210_tree=null;
        SLAST NEW_T212_tree=null;
        SLAST CLONE_T214_tree=null;
        SLAST BACKTRICKLITERAL216_tree=null;
        SLAST PRINT_T217_tree=null;


          SLAST ast = null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1055:3: ( ^( EXPR etop= expression ) | ^( OR_T e1= expression e2= expression ) | ^( XOR_T e1= expression e2= expression ) | ^( AND_T e1= expression e2= expression ) | ^( EQUAL_T e1= expression e2= expression ) | ^( PLUS_EQ e1= expression e2= expression ) | ^( MINUS_EQ e1= expression e2= expression ) | ^( MUL_EQ e1= expression e2= expression ) | ^( DIV_EQ e1= expression e2= expression ) | ^( DOT_EQ e1= expression e2= expression ) | ^( PERCENT_EQ e1= expression e2= expression ) | ^( BIT_AND_EQ e1= expression e2= expression ) | ^( BIT_OR_EQ e1= expression e2= expression ) | ^( POWER_EQ e1= expression e2= expression ) | ^( LMOVE_EQ e1= expression e2= expression ) | ^( RMOVE_EQ e1= expression e2= expression ) | ^( QUESTION_T e1= expression ^( COLON_T e2= expression e3= expression ) ) | ^( LOGICAL_OR_T e1= expression e2= expression ) | ^( LOGICAL_AND_T e1= expression e2= expression ) | ^( BIT_OR_T e1= expression e2= expression ) | ^( POWER_T e1= expression e2= expression ) | ^( REF_T e1= expression e2= expression ) | ^( UNARY_EXPR unary_symbol_list e= expression ) | ^( DOT_T e1= expression e2= expression ) | ^( EQUAL_EQUAL_T e1= expression e2= expression ) | ^( NOT_EQUAL_T e1= expression e2= expression ) | ^( EQUAL_EQUAL_EQUAL_T e1= expression e2= expression ) | ^( NOT_EQUAL_EQUAL_T e1= expression e2= expression ) | ^( LT_T e1= expression e2= expression ) | ^( MT_T e1= expression e2= expression ) | ^( LE_T e1= expression e2= expression ) | ^( ME_T e1= expression e2= expression ) | ^( LSHIFT_T e1= expression e2= expression ) | ^( RSHIFT_T e1= expression e2= expression ) | ^( PLUS_T e1= expression e2= expression ) | ^( MINUS_T e1= expression e2= expression ) | ^( MUL_T e1= expression e2= expression ) | ^( DIV_T e1= expression e2= expression ) | ^( PERCENT_T e1= expression e2= expression ) | ^( CAST_EXPR cast_option e= expression ) | ^( POSTFIX_EXPR e= expression plus_minus ) | ^( PREFIX_EXPR ( plus_minus )+ e= expression ) | ^( INSTANCEOF_T e= expression class_name_reference ) | ( AT_T )? variable | ( AT_T )? scalar | list_decl | ^( ARRAY_DECL ( array_pair_list )? ) | ^( NEW_T class_name_reference ) | ^( CLONE_T variable ) | BACKTRICKLITERAL | ^( PRINT_T e= expression ) )
            int alt64=51;
            alt64 = dfa64.predict(input);
            switch (alt64) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1055:5: ^( EXPR etop= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    EXPR156=(SLAST)match(input,EXPR,FOLLOW_EXPR_in_expression1915); 
                    EXPR156_tree = (SLAST)adaptor.dupNode(EXPR156);

                    root_1 = (SLAST)adaptor.becomeRoot(EXPR156_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1919);
                    etop=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, etop.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        retval.expr = (etop!=null?etop.expr:null);
                        ast = (etop!=null?((SLAST)etop.tree):null);
                        if (inExprList) {
                          ((expr_list_scope)expr_list_stack.peek()).list.add(retval.expr);
                        }
                      

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1063:5: ^( OR_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    OR_T157=(SLAST)match(input,OR_T,FOLLOW_OR_T_in_expression1931); 
                    OR_T157_tree = (SLAST)adaptor.dupNode(OR_T157);

                    root_1 = (SLAST)adaptor.becomeRoot(OR_T157_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1935);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1939);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = OR_T157.startIndex;
                        int endIndex = OR_T157.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1 , InfixExpression.OP_STRING_OR, expr2); 
                      

                    }
                    break;
                case 3 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1071:5: ^( XOR_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    XOR_T158=(SLAST)match(input,XOR_T,FOLLOW_XOR_T_in_expression1951); 
                    XOR_T158_tree = (SLAST)adaptor.dupNode(XOR_T158);

                    root_1 = (SLAST)adaptor.becomeRoot(XOR_T158_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1955);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1959);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = XOR_T158.startIndex;
                        int endIndex = XOR_T158.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1 , InfixExpression.OP_STRING_XOR, expr2);
                      

                    }
                    break;
                case 4 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1079:5: ^( AND_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    AND_T159=(SLAST)match(input,AND_T,FOLLOW_AND_T_in_expression1971); 
                    AND_T159_tree = (SLAST)adaptor.dupNode(AND_T159);

                    root_1 = (SLAST)adaptor.becomeRoot(AND_T159_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1975);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1979);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = AND_T159.startIndex;
                        int endIndex = AND_T159.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1 , InfixExpression.OP_STRING_AND, expr2);
                      

                    }
                    break;
                case 5 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1087:5: ^( EQUAL_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    EQUAL_T160=(SLAST)match(input,EQUAL_T,FOLLOW_EQUAL_T_in_expression1991); 
                    EQUAL_T160_tree = (SLAST)adaptor.dupNode(EQUAL_T160);

                    root_1 = (SLAST)adaptor.becomeRoot(EQUAL_T160_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1995);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1999);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = EQUAL_T160.startIndex;
                        int endIndex = EQUAL_T160.endIndex + 1;
                        Expression var = (e1!=null?e1.expr:null);
                        Expression expr = (e2!=null?e2.expr:null);
                        retval.expr = new Assignment(startIndex, endIndex, var, Assignment.OP_EQUAL, expr);
                      

                    }
                    break;
                case 6 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1095:5: ^( PLUS_EQ e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    PLUS_EQ161=(SLAST)match(input,PLUS_EQ,FOLLOW_PLUS_EQ_in_expression2012); 
                    PLUS_EQ161_tree = (SLAST)adaptor.dupNode(PLUS_EQ161);

                    root_1 = (SLAST)adaptor.becomeRoot(PLUS_EQ161_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2016);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2020);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = PLUS_EQ161.startIndex;
                        int endIndex = PLUS_EQ161.endIndex + 1;
                        Expression var = (e1!=null?e1.expr:null);
                        Expression expr = (e2!=null?e2.expr:null);
                        retval.expr = new Assignment(startIndex, endIndex, var, Assignment.OP_PLUS_EQUAL, expr);
                      

                    }
                    break;
                case 7 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1103:5: ^( MINUS_EQ e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    MINUS_EQ162=(SLAST)match(input,MINUS_EQ,FOLLOW_MINUS_EQ_in_expression2032); 
                    MINUS_EQ162_tree = (SLAST)adaptor.dupNode(MINUS_EQ162);

                    root_1 = (SLAST)adaptor.becomeRoot(MINUS_EQ162_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2036);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2040);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = MINUS_EQ162.startIndex;
                        int endIndex = MINUS_EQ162.endIndex + 1;
                        Expression var = (e1!=null?e1.expr:null);
                        Expression expr = (e2!=null?e2.expr:null);
                        retval.expr = new Assignment(startIndex, endIndex, var, Assignment.OP_MINUS_EQUAL, expr);
                      

                    }
                    break;
                case 8 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1111:5: ^( MUL_EQ e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    MUL_EQ163=(SLAST)match(input,MUL_EQ,FOLLOW_MUL_EQ_in_expression2052); 
                    MUL_EQ163_tree = (SLAST)adaptor.dupNode(MUL_EQ163);

                    root_1 = (SLAST)adaptor.becomeRoot(MUL_EQ163_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2056);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2060);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = MUL_EQ163.startIndex;
                        int endIndex = MUL_EQ163.endIndex + 1;
                        Expression var = (e1!=null?e1.expr:null);
                        Expression expr = (e2!=null?e2.expr:null);
                        retval.expr = new Assignment(startIndex, endIndex, var, Assignment.OP_MUL_EQUAL, expr);
                      

                    }
                    break;
                case 9 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1119:5: ^( DIV_EQ e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    DIV_EQ164=(SLAST)match(input,DIV_EQ,FOLLOW_DIV_EQ_in_expression2072); 
                    DIV_EQ164_tree = (SLAST)adaptor.dupNode(DIV_EQ164);

                    root_1 = (SLAST)adaptor.becomeRoot(DIV_EQ164_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2076);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2080);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = DIV_EQ164.startIndex;
                        int endIndex = DIV_EQ164.endIndex + 1;
                        Expression var = (e1!=null?e1.expr:null);
                        Expression expr = (e2!=null?e2.expr:null);
                        retval.expr = new Assignment(startIndex, endIndex, var, Assignment.OP_DIV_EQUAL, expr);
                      

                    }
                    break;
                case 10 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1127:5: ^( DOT_EQ e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    DOT_EQ165=(SLAST)match(input,DOT_EQ,FOLLOW_DOT_EQ_in_expression2092); 
                    DOT_EQ165_tree = (SLAST)adaptor.dupNode(DOT_EQ165);

                    root_1 = (SLAST)adaptor.becomeRoot(DOT_EQ165_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2096);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2100);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = DOT_EQ165.startIndex;
                        int endIndex = DOT_EQ165.endIndex + 1;
                        Expression var = (e1!=null?e1.expr:null);
                        Expression expr = (e2!=null?e2.expr:null);
                        retval.expr = new Assignment(startIndex, endIndex, var, Assignment.OP_CONCAT_EQUAL, expr);
                      

                    }
                    break;
                case 11 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1135:5: ^( PERCENT_EQ e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    PERCENT_EQ166=(SLAST)match(input,PERCENT_EQ,FOLLOW_PERCENT_EQ_in_expression2112); 
                    PERCENT_EQ166_tree = (SLAST)adaptor.dupNode(PERCENT_EQ166);

                    root_1 = (SLAST)adaptor.becomeRoot(PERCENT_EQ166_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2116);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2120);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = PERCENT_EQ166.startIndex;
                        int endIndex = PERCENT_EQ166.endIndex + 1;
                        Expression var = (e1!=null?e1.expr:null);
                        Expression expr = (e2!=null?e2.expr:null);
                        retval.expr = new Assignment(startIndex, endIndex, var, Assignment.OP_MOD_EQUAL, expr);
                      

                    }
                    break;
                case 12 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1143:5: ^( BIT_AND_EQ e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    BIT_AND_EQ167=(SLAST)match(input,BIT_AND_EQ,FOLLOW_BIT_AND_EQ_in_expression2132); 
                    BIT_AND_EQ167_tree = (SLAST)adaptor.dupNode(BIT_AND_EQ167);

                    root_1 = (SLAST)adaptor.becomeRoot(BIT_AND_EQ167_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2136);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2140);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = BIT_AND_EQ167.startIndex;
                        int endIndex = BIT_AND_EQ167.endIndex + 1;
                        Expression var = (e1!=null?e1.expr:null);
                        Expression expr = (e2!=null?e2.expr:null);
                        retval.expr = new Assignment(startIndex, endIndex, var, Assignment.OP_AND_EQUAL, expr);
                      

                    }
                    break;
                case 13 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1151:5: ^( BIT_OR_EQ e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    BIT_OR_EQ168=(SLAST)match(input,BIT_OR_EQ,FOLLOW_BIT_OR_EQ_in_expression2152); 
                    BIT_OR_EQ168_tree = (SLAST)adaptor.dupNode(BIT_OR_EQ168);

                    root_1 = (SLAST)adaptor.becomeRoot(BIT_OR_EQ168_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2156);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2160);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = BIT_OR_EQ168.startIndex;
                        int endIndex = BIT_OR_EQ168.endIndex + 1;
                        Expression var = (e1!=null?e1.expr:null);
                        Expression expr = (e2!=null?e2.expr:null);
                        retval.expr = new Assignment(startIndex, endIndex, var, Assignment.OP_OR_EQUAL, expr);
                      

                    }
                    break;
                case 14 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1159:5: ^( POWER_EQ e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    POWER_EQ169=(SLAST)match(input,POWER_EQ,FOLLOW_POWER_EQ_in_expression2172); 
                    POWER_EQ169_tree = (SLAST)adaptor.dupNode(POWER_EQ169);

                    root_1 = (SLAST)adaptor.becomeRoot(POWER_EQ169_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2176);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2180);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = POWER_EQ169.startIndex;
                        int endIndex = POWER_EQ169.endIndex + 1;
                        Expression var = (e1!=null?e1.expr:null);
                        Expression expr = (e2!=null?e2.expr:null);
                        retval.expr = new Assignment(startIndex, endIndex, var, Assignment.OP_XOR_EQUAL, expr);
                      

                    }
                    break;
                case 15 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1167:5: ^( LMOVE_EQ e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    LMOVE_EQ170=(SLAST)match(input,LMOVE_EQ,FOLLOW_LMOVE_EQ_in_expression2192); 
                    LMOVE_EQ170_tree = (SLAST)adaptor.dupNode(LMOVE_EQ170);

                    root_1 = (SLAST)adaptor.becomeRoot(LMOVE_EQ170_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2196);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2200);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = LMOVE_EQ170.startIndex;
                        int endIndex = LMOVE_EQ170.endIndex + 1;
                        Expression var = (e1!=null?e1.expr:null);
                        Expression expr = (e2!=null?e2.expr:null);
                        retval.expr = new Assignment(startIndex, endIndex, var, Assignment.OP_SL_EQUAL, expr);
                      

                    }
                    break;
                case 16 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1175:5: ^( RMOVE_EQ e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    RMOVE_EQ171=(SLAST)match(input,RMOVE_EQ,FOLLOW_RMOVE_EQ_in_expression2212); 
                    RMOVE_EQ171_tree = (SLAST)adaptor.dupNode(RMOVE_EQ171);

                    root_1 = (SLAST)adaptor.becomeRoot(RMOVE_EQ171_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2216);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2220);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = RMOVE_EQ171.startIndex;
                        int endIndex = RMOVE_EQ171.endIndex + 1;
                        Expression var = (e1!=null?e1.expr:null);
                        Expression expr = (e2!=null?e2.expr:null);
                        retval.expr = new Assignment(startIndex, endIndex, var, Assignment.OP_SR_EQUAL, expr);
                      

                    }
                    break;
                case 17 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1183:5: ^( QUESTION_T e1= expression ^( COLON_T e2= expression e3= expression ) )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    QUESTION_T172=(SLAST)match(input,QUESTION_T,FOLLOW_QUESTION_T_in_expression2232); 
                    QUESTION_T172_tree = (SLAST)adaptor.dupNode(QUESTION_T172);

                    root_1 = (SLAST)adaptor.becomeRoot(QUESTION_T172_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2236);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_2 = _last;
                    SLAST _first_2 = null;
                    SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    COLON_T173=(SLAST)match(input,COLON_T,FOLLOW_COLON_T_in_expression2239); 
                    COLON_T173_tree = (SLAST)adaptor.dupNode(COLON_T173);

                    root_2 = (SLAST)adaptor.becomeRoot(COLON_T173_tree, root_2);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2243);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_2, e2.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2247);
                    e3=expression();

                    state._fsp--;

                    adaptor.addChild(root_2, e3.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_1, root_2);_last = _save_last_2;
                    }


                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = QUESTION_T172.startIndex;
                        int endIndex = QUESTION_T172.endIndex + 1;
                        retval.expr = new ConditionalExpression(startIndex, endIndex, (e1!=null?e1.expr:null), (e2!=null?e2.expr:null), (e3!=null?e3.expr:null)); 
                      

                    }
                    break;
                case 18 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1189:5: ^( LOGICAL_OR_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    LOGICAL_OR_T174=(SLAST)match(input,LOGICAL_OR_T,FOLLOW_LOGICAL_OR_T_in_expression2262); 
                    LOGICAL_OR_T174_tree = (SLAST)adaptor.dupNode(LOGICAL_OR_T174);

                    root_1 = (SLAST)adaptor.becomeRoot(LOGICAL_OR_T174_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2266);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2270);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = LOGICAL_OR_T174.startIndex;
                        int endIndex = LOGICAL_OR_T174.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1 , InfixExpression.OP_BOOL_OR, expr2); 
                      

                    }
                    break;
                case 19 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1197:5: ^( LOGICAL_AND_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    LOGICAL_AND_T175=(SLAST)match(input,LOGICAL_AND_T,FOLLOW_LOGICAL_AND_T_in_expression2282); 
                    LOGICAL_AND_T175_tree = (SLAST)adaptor.dupNode(LOGICAL_AND_T175);

                    root_1 = (SLAST)adaptor.becomeRoot(LOGICAL_AND_T175_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2286);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2290);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = LOGICAL_AND_T175.startIndex;
                        int endIndex = LOGICAL_AND_T175.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1 , InfixExpression.OP_BOOL_AND, expr2);
                      

                    }
                    break;
                case 20 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1205:5: ^( BIT_OR_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    BIT_OR_T176=(SLAST)match(input,BIT_OR_T,FOLLOW_BIT_OR_T_in_expression2302); 
                    BIT_OR_T176_tree = (SLAST)adaptor.dupNode(BIT_OR_T176);

                    root_1 = (SLAST)adaptor.becomeRoot(BIT_OR_T176_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2306);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2310);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = BIT_OR_T176.startIndex;
                        int endIndex = BIT_OR_T176.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1 , InfixExpression.OP_OR, expr2); 
                      

                    }
                    break;
                case 21 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1213:5: ^( POWER_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    POWER_T177=(SLAST)match(input,POWER_T,FOLLOW_POWER_T_in_expression2322); 
                    POWER_T177_tree = (SLAST)adaptor.dupNode(POWER_T177);

                    root_1 = (SLAST)adaptor.becomeRoot(POWER_T177_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2326);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2330);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = POWER_T177.startIndex;
                        int endIndex = POWER_T177.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1 , InfixExpression.OP_XOR, expr2); 
                      

                    }
                    break;
                case 22 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1221:5: ^( REF_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    REF_T178=(SLAST)match(input,REF_T,FOLLOW_REF_T_in_expression2342); 
                    REF_T178_tree = (SLAST)adaptor.dupNode(REF_T178);

                    root_1 = (SLAST)adaptor.becomeRoot(REF_T178_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2346);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2350);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = REF_T178.startIndex;
                        int endIndex = REF_T178.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                    //    if (expr2 != null) {
                          retval.expr = new InfixExpression(startIndex, endIndex, expr1 , InfixExpression.OP_AND, expr2);
                    //    }
                    //    else {
                    //      retval.expr = new ReferenceExpression(startIndex, endIndex, expr1);
                    //    }
                      

                    }
                    break;
                case 23 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1234:5: ^( UNARY_EXPR unary_symbol_list e= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    UNARY_EXPR179=(SLAST)match(input,UNARY_EXPR,FOLLOW_UNARY_EXPR_in_expression2362); 
                    UNARY_EXPR179_tree = (SLAST)adaptor.dupNode(UNARY_EXPR179);

                    root_1 = (SLAST)adaptor.becomeRoot(UNARY_EXPR179_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_unary_symbol_list_in_expression2364);
                    unary_symbol_list180=unary_symbol_list();

                    state._fsp--;

                    adaptor.addChild(root_1, unary_symbol_list180.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2368);
                    e=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        Iterator iter = (unary_symbol_list180!=null?unary_symbol_list180.symbolList:null).iterator();
                        int symbolIndex;
                        int startIndex = UNARY_EXPR179.startIndex + (unary_symbol_list180!=null?unary_symbol_list180.symbolList:null).size() - 1;
                        int endIndex = UNARY_EXPR179.endIndex + 1;
                        retval.expr = (e!=null?e.expr:null);
                        while (iter.hasNext()) {
                          symbolIndex = (Integer)iter.next();
                          System.out.println("symbolIndex: " + symbolIndex);
                          switch(symbolIndex) {
                            case 1:
                              retval.expr = new UnaryOperation(startIndex--, endIndex, retval.expr, UnaryOperation.OP_PLUS);
                              break;
                            case 2:
                              retval.expr = new UnaryOperation(startIndex--, endIndex, retval.expr, UnaryOperation.OP_MINUS);
                              break;
                            case 3:
                              retval.expr = new ReferenceExpression(startIndex--, endIndex, retval.expr);
                              break;
                            case 4:
                              retval.expr = new UnaryOperation(startIndex--, endIndex, retval.expr, UnaryOperation.OP_TILDA);
                              break;
                            case 5:
                              retval.expr = new UnaryOperation(startIndex--, endIndex, retval.expr, UnaryOperation.OP_NOT);
                              break;
                            default:
                              break;
                          }
                        }
                      

                    }
                    break;
                case 24 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1265:5: ^( DOT_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    DOT_T181=(SLAST)match(input,DOT_T,FOLLOW_DOT_T_in_expression2380); 
                    DOT_T181_tree = (SLAST)adaptor.dupNode(DOT_T181);

                    root_1 = (SLAST)adaptor.becomeRoot(DOT_T181_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2384);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2388);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = DOT_T181.startIndex;
                        int endIndex = DOT_T181.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1 , InfixExpression.OP_CONCAT, expr2); 
                      

                    }
                    break;
                case 25 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1273:5: ^( EQUAL_EQUAL_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    EQUAL_EQUAL_T182=(SLAST)match(input,EQUAL_EQUAL_T,FOLLOW_EQUAL_EQUAL_T_in_expression2400); 
                    EQUAL_EQUAL_T182_tree = (SLAST)adaptor.dupNode(EQUAL_EQUAL_T182);

                    root_1 = (SLAST)adaptor.becomeRoot(EQUAL_EQUAL_T182_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2404);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2408);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = EQUAL_EQUAL_T182.startIndex;
                        int endIndex = EQUAL_EQUAL_T182.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1 , InfixExpression.OP_IS_EQUAL, expr2);
                      

                    }
                    break;
                case 26 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1281:5: ^( NOT_EQUAL_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    NOT_EQUAL_T183=(SLAST)match(input,NOT_EQUAL_T,FOLLOW_NOT_EQUAL_T_in_expression2420); 
                    NOT_EQUAL_T183_tree = (SLAST)adaptor.dupNode(NOT_EQUAL_T183);

                    root_1 = (SLAST)adaptor.becomeRoot(NOT_EQUAL_T183_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2424);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2428);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = NOT_EQUAL_T183.startIndex;
                        int endIndex = NOT_EQUAL_T183.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1 , InfixExpression.OP_IS_NOT_EQUAL, expr2);
                      

                    }
                    break;
                case 27 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1289:5: ^( EQUAL_EQUAL_EQUAL_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    EQUAL_EQUAL_EQUAL_T184=(SLAST)match(input,EQUAL_EQUAL_EQUAL_T,FOLLOW_EQUAL_EQUAL_EQUAL_T_in_expression2440); 
                    EQUAL_EQUAL_EQUAL_T184_tree = (SLAST)adaptor.dupNode(EQUAL_EQUAL_EQUAL_T184);

                    root_1 = (SLAST)adaptor.becomeRoot(EQUAL_EQUAL_EQUAL_T184_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2444);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2448);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = EQUAL_EQUAL_EQUAL_T184.startIndex;
                        int endIndex = EQUAL_EQUAL_EQUAL_T184.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1 , InfixExpression.OP_IS_IDENTICAL, expr2);
                      

                    }
                    break;
                case 28 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1297:5: ^( NOT_EQUAL_EQUAL_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    NOT_EQUAL_EQUAL_T185=(SLAST)match(input,NOT_EQUAL_EQUAL_T,FOLLOW_NOT_EQUAL_EQUAL_T_in_expression2460); 
                    NOT_EQUAL_EQUAL_T185_tree = (SLAST)adaptor.dupNode(NOT_EQUAL_EQUAL_T185);

                    root_1 = (SLAST)adaptor.becomeRoot(NOT_EQUAL_EQUAL_T185_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2464);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2468);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = NOT_EQUAL_EQUAL_T185.startIndex;
                        int endIndex = NOT_EQUAL_EQUAL_T185.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1 , InfixExpression.OP_IS_NOT_IDENTICAL, expr2);
                      

                    }
                    break;
                case 29 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1305:5: ^( LT_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    LT_T186=(SLAST)match(input,LT_T,FOLLOW_LT_T_in_expression2480); 
                    LT_T186_tree = (SLAST)adaptor.dupNode(LT_T186);

                    root_1 = (SLAST)adaptor.becomeRoot(LT_T186_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2484);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2488);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = LT_T186.startIndex;
                        int endIndex = LT_T186.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1 , InfixExpression.OP_RGREATER, expr2); 
                      

                    }
                    break;
                case 30 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1313:5: ^( MT_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    MT_T187=(SLAST)match(input,MT_T,FOLLOW_MT_T_in_expression2500); 
                    MT_T187_tree = (SLAST)adaptor.dupNode(MT_T187);

                    root_1 = (SLAST)adaptor.becomeRoot(MT_T187_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2504);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2508);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = MT_T187.startIndex;
                        int endIndex = MT_T187.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1 , InfixExpression.OP_LGREATER, expr2); 
                      

                    }
                    break;
                case 31 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1321:5: ^( LE_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    LE_T188=(SLAST)match(input,LE_T,FOLLOW_LE_T_in_expression2520); 
                    LE_T188_tree = (SLAST)adaptor.dupNode(LE_T188);

                    root_1 = (SLAST)adaptor.becomeRoot(LE_T188_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2524);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2528);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = LE_T188.startIndex;
                        int endIndex = LE_T188.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1 , InfixExpression.OP_IS_SMALLER_OR_EQUAL, expr2); 
                      

                    }
                    break;
                case 32 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1329:5: ^( ME_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    ME_T189=(SLAST)match(input,ME_T,FOLLOW_ME_T_in_expression2540); 
                    ME_T189_tree = (SLAST)adaptor.dupNode(ME_T189);

                    root_1 = (SLAST)adaptor.becomeRoot(ME_T189_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2544);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2548);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = ME_T189.startIndex;
                        int endIndex = ME_T189.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1 , InfixExpression.OP_IS_GREATER_OR_EQUAL, expr2); 
                      

                    }
                    break;
                case 33 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1337:5: ^( LSHIFT_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    LSHIFT_T190=(SLAST)match(input,LSHIFT_T,FOLLOW_LSHIFT_T_in_expression2560); 
                    LSHIFT_T190_tree = (SLAST)adaptor.dupNode(LSHIFT_T190);

                    root_1 = (SLAST)adaptor.becomeRoot(LSHIFT_T190_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2564);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2568);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = LSHIFT_T190.startIndex;
                        int endIndex = LSHIFT_T190.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1, InfixExpression.OP_SL, expr2); 
                      

                    }
                    break;
                case 34 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1345:5: ^( RSHIFT_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    RSHIFT_T191=(SLAST)match(input,RSHIFT_T,FOLLOW_RSHIFT_T_in_expression2580); 
                    RSHIFT_T191_tree = (SLAST)adaptor.dupNode(RSHIFT_T191);

                    root_1 = (SLAST)adaptor.becomeRoot(RSHIFT_T191_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2584);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2588);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = RSHIFT_T191.startIndex;
                        int endIndex = RSHIFT_T191.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1, InfixExpression.OP_SR, expr2); 
                      

                    }
                    break;
                case 35 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1353:5: ^( PLUS_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    PLUS_T192=(SLAST)match(input,PLUS_T,FOLLOW_PLUS_T_in_expression2600); 
                    PLUS_T192_tree = (SLAST)adaptor.dupNode(PLUS_T192);

                    root_1 = (SLAST)adaptor.becomeRoot(PLUS_T192_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2604);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2608);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = PLUS_T192.startIndex;
                        int endIndex = PLUS_T192.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                    //    if (expr2 != null) {
                          retval.expr = new InfixExpression(startIndex, endIndex, expr1, InfixExpression.OP_PLUS, expr2);
                    //    }
                    //    else {
                    //      retval.expr = new UnaryOperation(startIndex, endIndex, (e1!=null?e1.expr:null) , UnaryOperation.OP_PLUS);
                    //    }
                      

                    }
                    break;
                case 36 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1366:5: ^( MINUS_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    MINUS_T193=(SLAST)match(input,MINUS_T,FOLLOW_MINUS_T_in_expression2620); 
                    MINUS_T193_tree = (SLAST)adaptor.dupNode(MINUS_T193);

                    root_1 = (SLAST)adaptor.becomeRoot(MINUS_T193_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2624);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2628);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = MINUS_T193.startIndex;
                        int endIndex = MINUS_T193.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                    //    if (expr2 != null) {
                          retval.expr = new InfixExpression(startIndex, endIndex, expr1, InfixExpression.OP_MINUS, expr2);
                    //    }
                    //    else {
                    //      retval.expr = new UnaryOperation(startIndex, endIndex, (e1!=null?e1.expr:null) , UnaryOperation.OP_MINUS);
                    //    }
                      

                    }
                    break;
                case 37 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1379:5: ^( MUL_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    MUL_T194=(SLAST)match(input,MUL_T,FOLLOW_MUL_T_in_expression2640); 
                    MUL_T194_tree = (SLAST)adaptor.dupNode(MUL_T194);

                    root_1 = (SLAST)adaptor.becomeRoot(MUL_T194_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2644);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2648);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = MUL_T194.startIndex;
                        int endIndex = MUL_T194.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1, InfixExpression.OP_MUL, expr2);
                      

                    }
                    break;
                case 38 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1387:5: ^( DIV_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    DIV_T195=(SLAST)match(input,DIV_T,FOLLOW_DIV_T_in_expression2660); 
                    DIV_T195_tree = (SLAST)adaptor.dupNode(DIV_T195);

                    root_1 = (SLAST)adaptor.becomeRoot(DIV_T195_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2664);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2668);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = DIV_T195.startIndex;
                        int endIndex = DIV_T195.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1, InfixExpression.OP_DIV, expr2);
                      

                    }
                    break;
                case 39 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1395:5: ^( PERCENT_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    PERCENT_T196=(SLAST)match(input,PERCENT_T,FOLLOW_PERCENT_T_in_expression2680); 
                    PERCENT_T196_tree = (SLAST)adaptor.dupNode(PERCENT_T196);

                    root_1 = (SLAST)adaptor.becomeRoot(PERCENT_T196_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2684);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2688);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = PERCENT_T196.startIndex;
                        int endIndex = PERCENT_T196.endIndex + 1;
                        Expression expr1 = (e1!=null?e1.expr:null);
                        Expression expr2 = (e2!=null?e2.expr:null);
                        retval.expr = new InfixExpression(startIndex, endIndex, expr1, InfixExpression.OP_MOD, expr2);
                      

                    }
                    break;
                case 40 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1403:5: ^( CAST_EXPR cast_option e= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    CAST_EXPR197=(SLAST)match(input,CAST_EXPR,FOLLOW_CAST_EXPR_in_expression2700); 
                    CAST_EXPR197_tree = (SLAST)adaptor.dupNode(CAST_EXPR197);

                    root_1 = (SLAST)adaptor.becomeRoot(CAST_EXPR197_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_cast_option_in_expression2702);
                    cast_option198=cast_option();

                    state._fsp--;

                    adaptor.addChild(root_1, cast_option198.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2706);
                    e=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int result = (cast_option198!=null?cast_option198.castOption:0);
                        int startIndex = CAST_EXPR197.startIndex;
                        int endIndex = CAST_EXPR197.endIndex + 1;
                        Expression expr = (e!=null?e.expr:null);
                        switch(result) {
                          case 1:
                          case 2:
                            retval.expr = new CastExpression(startIndex, endIndex, expr, CastExpression.TYPE_BOOL);
                            break;
                          case 3:
                            retval.expr = new CastExpression(startIndex, endIndex, expr, CastExpression.TYPE_INT);
                            break;
                          case 6:
                            retval.expr = new CastExpression(startIndex, endIndex, expr, CastExpression.TYPE_ARRAY);
                            break;
                          case 7:
                            retval.expr = new CastExpression(startIndex, endIndex, expr, CastExpression.TYPE_OBJECT);
                            break;
                          case 8:
                            retval.expr = new CastExpression(startIndex, endIndex, expr, CastExpression.TYPE_REAL);
                            break;
                          case 9:
                            retval.expr = new CastExpression(startIndex, endIndex, expr, CastExpression.TYPE_STRING);
                            break;
                          case 10:
                            retval.expr = new CastExpression(startIndex, endIndex, expr, CastExpression.TYPE_UNSET);
                            break;
                          default:
                            retval.expr = new CastExpression(startIndex, endIndex, expr, CastExpression.TYPE_OBJECT);
                            break;
                        }
                      

                    }
                    break;
                case 41 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1449:5: ^( POSTFIX_EXPR e= expression plus_minus )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    POSTFIX_EXPR199=(SLAST)match(input,POSTFIX_EXPR,FOLLOW_POSTFIX_EXPR_in_expression2730); 
                    POSTFIX_EXPR199_tree = (SLAST)adaptor.dupNode(POSTFIX_EXPR199);

                    root_1 = (SLAST)adaptor.becomeRoot(POSTFIX_EXPR199_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2734);
                    e=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_plus_minus_in_expression2736);
                    plus_minus200=plus_minus();

                    state._fsp--;

                    adaptor.addChild(root_1, plus_minus200.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                          int startIndex = POSTFIX_EXPR199.startIndex;
                          int endIndex = POSTFIX_EXPR199.endIndex + 1;
                          if ((plus_minus200!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(plus_minus200.start),
                      input.getTreeAdaptor().getTokenStopIndex(plus_minus200.start))):null).equals("++")) {
                            retval.expr = new PostfixExpression(startIndex, endIndex, (e!=null?e.expr:null) , PostfixExpression.OP_INC);
                          }
                          else {
                            retval.expr = new PostfixExpression(startIndex, endIndex, (e!=null?e.expr:null) , PostfixExpression.OP_DEC);
                          } 
                      

                    }
                    break;
                case 42 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1460:5: ^( PREFIX_EXPR ( plus_minus )+ e= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    PREFIX_EXPR201=(SLAST)match(input,PREFIX_EXPR,FOLLOW_PREFIX_EXPR_in_expression2748); 
                    PREFIX_EXPR201_tree = (SLAST)adaptor.dupNode(PREFIX_EXPR201);

                    root_1 = (SLAST)adaptor.becomeRoot(PREFIX_EXPR201_tree, root_1);



                    match(input, Token.DOWN, null); 
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1460:19: ( plus_minus )+
                    int cnt60=0;
                    loop60:
                    do {
                        int alt60=2;
                        int LA60_0 = input.LA(1);

                        if ( ((LA60_0>=PLUS_PLUS_T && LA60_0<=MINUS_MINUS_T)) ) {
                            alt60=1;
                        }


                        switch (alt60) {
                    	case 1 :
                    	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1460:19: plus_minus
                    	    {
                    	    _last = (SLAST)input.LT(1);
                    	    pushFollow(FOLLOW_plus_minus_in_expression2750);
                    	    plus_minus202=plus_minus();

                    	    state._fsp--;

                    	    adaptor.addChild(root_1, plus_minus202.getTree());

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt60 >= 1 ) break loop60;
                                EarlyExitException eee =
                                    new EarlyExitException(60, input);
                                throw eee;
                        }
                        cnt60++;
                    } while (true);

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2755);
                    e=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                          int startIndex = PREFIX_EXPR201.startIndex;
                          int endIndex = PREFIX_EXPR201.endIndex + 1;
                          if ((plus_minus202!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(plus_minus202.start),
                      input.getTreeAdaptor().getTokenStopIndex(plus_minus202.start))):null).equals("++")) {
                            retval.expr = new PrefixExpression(startIndex, endIndex, (e!=null?e.expr:null), PrefixExpression.OP_INC);
                          }
                          else {
                            retval.expr = new PrefixExpression(startIndex, endIndex, (e!=null?e.expr:null), PrefixExpression.OP_DEC);
                          }
                      

                    }
                    break;
                case 43 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1471:5: ^( INSTANCEOF_T e= expression class_name_reference )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    INSTANCEOF_T203=(SLAST)match(input,INSTANCEOF_T,FOLLOW_INSTANCEOF_T_in_expression2767); 
                    INSTANCEOF_T203_tree = (SLAST)adaptor.dupNode(INSTANCEOF_T203);

                    root_1 = (SLAST)adaptor.becomeRoot(INSTANCEOF_T203_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2771);
                    e=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_class_name_reference_in_expression2773);
                    class_name_reference204=class_name_reference();

                    state._fsp--;

                    adaptor.addChild(root_1, class_name_reference204.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = INSTANCEOF_T203.startIndex;
                        int endIndex = INSTANCEOF_T203.endIndex + 1;
                        retval.expr = new InstanceOfExpression(startIndex, endIndex, (e!=null?e.expr:null), (class_name_reference204!=null?class_name_reference204.var:null)); 
                      

                    }
                    break;
                case 44 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1477:5: ( AT_T )? variable
                    {
                    root_0 = (SLAST)adaptor.nil();

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1477:5: ( AT_T )?
                    int alt61=2;
                    int LA61_0 = input.LA(1);

                    if ( (LA61_0==AT_T) ) {
                        alt61=1;
                    }
                    switch (alt61) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1477:5: AT_T
                            {
                            _last = (SLAST)input.LT(1);
                            AT_T205=(SLAST)match(input,AT_T,FOLLOW_AT_T_in_expression2784); 
                            AT_T205_tree = (SLAST)adaptor.dupNode(AT_T205);

                            adaptor.addChild(root_0, AT_T205_tree);


                            }
                            break;

                    }

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_variable_in_expression2787);
                    variable206=variable();

                    state._fsp--;

                    adaptor.addChild(root_0, variable206.getTree());

                        retval.expr = (variable206!=null?variable206.var:null);
                      

                    }
                    break;
                case 45 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1481:5: ( AT_T )? scalar
                    {
                    root_0 = (SLAST)adaptor.nil();

                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1481:5: ( AT_T )?
                    int alt62=2;
                    int LA62_0 = input.LA(1);

                    if ( (LA62_0==AT_T) ) {
                        alt62=1;
                    }
                    switch (alt62) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1481:5: AT_T
                            {
                            _last = (SLAST)input.LT(1);
                            AT_T207=(SLAST)match(input,AT_T,FOLLOW_AT_T_in_expression2797); 
                            AT_T207_tree = (SLAST)adaptor.dupNode(AT_T207);

                            adaptor.addChild(root_0, AT_T207_tree);


                            }
                            break;

                    }

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_scalar_in_expression2800);
                    scalar208=scalar();

                    state._fsp--;

                    adaptor.addChild(root_0, scalar208.getTree());

                        retval.expr = (scalar208!=null?scalar208.expr:null);
                        ast = (scalar208!=null?((SLAST)scalar208.tree):null);
                      

                    }
                    break;
                case 46 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1486:5: list_decl
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_list_decl_in_expression2810);
                    list_decl209=list_decl();

                    state._fsp--;

                    adaptor.addChild(root_0, list_decl209.getTree());

                        retval.expr = (list_decl209!=null?list_decl209.expr:null);
                      

                    }
                    break;
                case 47 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1490:5: ^( ARRAY_DECL ( array_pair_list )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    ARRAY_DECL210=(SLAST)match(input,ARRAY_DECL,FOLLOW_ARRAY_DECL_in_expression2821); 
                    ARRAY_DECL210_tree = (SLAST)adaptor.dupNode(ARRAY_DECL210);

                    root_1 = (SLAST)adaptor.becomeRoot(ARRAY_DECL210_tree, root_1);



                    if ( input.LA(1)==Token.DOWN ) {
                        match(input, Token.DOWN, null); 
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1490:18: ( array_pair_list )?
                        int alt63=2;
                        int LA63_0 = input.LA(1);

                        if ( (LA63_0==VAR_DECL||LA63_0==CALL||LA63_0==EXPR||(LA63_0>=SCALAR && LA63_0<=UNARY_EXPR)||LA63_0==REF_T||LA63_0==ARROW_T||LA63_0==EQUAL_T||(LA63_0>=OR_T && LA63_0<=CLONE_T)||(LA63_0>=INSTANCEOF_T && LA63_0<=PRINT_T)) ) {
                            alt63=1;
                        }
                        switch (alt63) {
                            case 1 :
                                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1490:18: array_pair_list
                                {
                                _last = (SLAST)input.LT(1);
                                pushFollow(FOLLOW_array_pair_list_in_expression2823);
                                array_pair_list211=array_pair_list();

                                state._fsp--;

                                adaptor.addChild(root_1, array_pair_list211.getTree());

                                }
                                break;

                        }


                        match(input, Token.UP, null); 
                    }adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = ARRAY_DECL210.startIndex;
                        int endIndex = ARRAY_DECL210.endIndex + 1;
                        if ((array_pair_list211!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(array_pair_list211.start),
                      input.getTreeAdaptor().getTokenStopIndex(array_pair_list211.start))):null) != null) {
                           retval.expr = new ArrayCreation(startIndex, endIndex, (array_pair_list211!=null?array_pair_list211.arrayList:null));
                        }
                        else {
                           retval.expr = new ArrayCreation(startIndex, endIndex, new LinkedList());
                        }
                      

                    }
                    break;
                case 48 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1501:5: ^( NEW_T class_name_reference )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    NEW_T212=(SLAST)match(input,NEW_T,FOLLOW_NEW_T_in_expression2836); 
                    NEW_T212_tree = (SLAST)adaptor.dupNode(NEW_T212);

                    root_1 = (SLAST)adaptor.becomeRoot(NEW_T212_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_class_name_reference_in_expression2838);
                    class_name_reference213=class_name_reference();

                    state._fsp--;

                    adaptor.addChild(root_1, class_name_reference213.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = NEW_T212.startIndex;
                        int endIndex = NEW_T212.endIndex + 1;
                        Expression className = (class_name_reference213!=null?class_name_reference213.var:null);
                        PHPCallArgumentsList ctor = (class_name_reference213!=null?class_name_reference213.parameterList:null);
                        if (ctor == null) {
                          ctor = new PHPCallArgumentsList();
                          ctor.setStart(endIndex);
                          ctor.setEnd(endIndex);
                        }
                        
                        ClassInstanceCreation classInstanceCreation = new ClassInstanceCreation(startIndex, endIndex, className, ctor);
                        retval.expr = classInstanceCreation;
                      

                    }
                    break;
                case 49 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1517:5: ^( CLONE_T variable )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    CLONE_T214=(SLAST)match(input,CLONE_T,FOLLOW_CLONE_T_in_expression2853); 
                    CLONE_T214_tree = (SLAST)adaptor.dupNode(CLONE_T214);

                    root_1 = (SLAST)adaptor.becomeRoot(CLONE_T214_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_variable_in_expression2855);
                    variable215=variable();

                    state._fsp--;

                    adaptor.addChild(root_1, variable215.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = CLONE_T214.startIndex;
                        int endIndex = CLONE_T214.endIndex + 1;
                        retval.expr = new CloneExpression(startIndex, endIndex, (variable215!=null?variable215.var:null));
                      

                    }
                    break;
                case 50 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1526:5: BACKTRICKLITERAL
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    BACKTRICKLITERAL216=(SLAST)match(input,BACKTRICKLITERAL,FOLLOW_BACKTRICKLITERAL_in_expression2869); 
                    BACKTRICKLITERAL216_tree = (SLAST)adaptor.dupNode(BACKTRICKLITERAL216);

                    adaptor.addChild(root_0, BACKTRICKLITERAL216_tree);


                    }
                    break;
                case 51 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1527:5: ^( PRINT_T e= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    PRINT_T217=(SLAST)match(input,PRINT_T,FOLLOW_PRINT_T_in_expression2876); 
                    PRINT_T217_tree = (SLAST)adaptor.dupNode(PRINT_T217);

                    root_1 = (SLAST)adaptor.becomeRoot(PRINT_T217_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression2880);
                    e=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = PRINT_T217.startIndex;
                        int endIndex = PRINT_T217.endIndex + 1;
                        
                        PHPCallArgumentsList list = new PHPCallArgumentsList();
                    	  if ((e!=null?e.expr:null) != null) {
                    	    list.addNode((e!=null?e.expr:null));
                    	    list.setStart((e!=null?e.expr:null).sourceStart());
                    	    list.setEnd((e!=null?e.expr:null).sourceEnd());
                    	  } else {
                    	    list.setStart(startIndex);
                    	    list.setEnd(startIndex);
                    	  }
                        
                        SimpleReference name = new SimpleReference(startIndex, startIndex, "print");
                    	  retval.expr = new PHPCallExpression(endIndex, endIndex, null, name, list);
                      

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "expression"

    protected static class unary_symbol_list_scope {
        List list;
    }
    protected Stack unary_symbol_list_stack = new Stack();

    public static class unary_symbol_list_return extends TreeRuleReturnScope {
        public List symbolList;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "unary_symbol_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1548:1: unary_symbol_list returns [List symbolList] : ( unary_symbol )+ ;
    public final TreePHP.unary_symbol_list_return unary_symbol_list() throws RecognitionException {
        unary_symbol_list_stack.push(new unary_symbol_list_scope());
        TreePHP.unary_symbol_list_return retval = new TreePHP.unary_symbol_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.unary_symbol_return unary_symbol218 = null;




          ((unary_symbol_list_scope)unary_symbol_list_stack.peek()).list = new ArrayList();

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1555:3: ( ( unary_symbol )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1555:5: ( unary_symbol )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1555:5: ( unary_symbol )+
            int cnt65=0;
            loop65:
            do {
                int alt65=2;
                switch ( input.LA(1) ) {
                case REF_T:
                    {
                    int LA65_2 = input.LA(2);

                    if ( (LA65_2==VAR_DECL||LA65_2==CALL||LA65_2==EXPR||(LA65_2>=SCALAR && LA65_2<=UNARY_EXPR)||LA65_2==REF_T||LA65_2==EQUAL_T||(LA65_2>=OR_T && LA65_2<=EXC_NOT_T)||(LA65_2>=INSTANCEOF_T && LA65_2<=PRINT_T)) ) {
                        alt65=1;
                    }


                    }
                    break;
                case PLUS_T:
                    {
                    int LA65_3 = input.LA(2);

                    if ( (LA65_3==VAR_DECL||LA65_3==CALL||LA65_3==EXPR||(LA65_3>=SCALAR && LA65_3<=UNARY_EXPR)||LA65_3==REF_T||LA65_3==EQUAL_T||(LA65_3>=OR_T && LA65_3<=EXC_NOT_T)||(LA65_3>=INSTANCEOF_T && LA65_3<=PRINT_T)) ) {
                        alt65=1;
                    }


                    }
                    break;
                case MINUS_T:
                    {
                    int LA65_4 = input.LA(2);

                    if ( (LA65_4==VAR_DECL||LA65_4==CALL||LA65_4==EXPR||(LA65_4>=SCALAR && LA65_4<=UNARY_EXPR)||LA65_4==REF_T||LA65_4==EQUAL_T||(LA65_4>=OR_T && LA65_4<=EXC_NOT_T)||(LA65_4>=INSTANCEOF_T && LA65_4<=PRINT_T)) ) {
                        alt65=1;
                    }


                    }
                    break;
                case TILDA_T:
                case EXC_NOT_T:
                    {
                    alt65=1;
                    }
                    break;

                }

                switch (alt65) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1555:5: unary_symbol
            	    {
            	    _last = (SLAST)input.LT(1);
            	    pushFollow(FOLLOW_unary_symbol_in_unary_symbol_list2914);
            	    unary_symbol218=unary_symbol();

            	    state._fsp--;

            	    adaptor.addChild(root_0, unary_symbol218.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt65 >= 1 ) break loop65;
                        EarlyExitException eee =
                            new EarlyExitException(65, input);
                        throw eee;
                }
                cnt65++;
            } while (true);


                retval.symbolList = ((unary_symbol_list_scope)unary_symbol_list_stack.peek()).list;
              

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
            unary_symbol_list_stack.pop();
        }
        return retval;
    }
    // $ANTLR end "unary_symbol_list"

    public static class unary_symbol_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "unary_symbol"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1561:1: unary_symbol : ( PLUS_T | MINUS_T | REF_T | TILDA_T | EXC_NOT_T );
    public final TreePHP.unary_symbol_return unary_symbol() throws RecognitionException {
        TreePHP.unary_symbol_return retval = new TreePHP.unary_symbol_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST PLUS_T219=null;
        SLAST MINUS_T220=null;
        SLAST REF_T221=null;
        SLAST TILDA_T222=null;
        SLAST EXC_NOT_T223=null;

        SLAST PLUS_T219_tree=null;
        SLAST MINUS_T220_tree=null;
        SLAST REF_T221_tree=null;
        SLAST TILDA_T222_tree=null;
        SLAST EXC_NOT_T223_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1562:3: ( PLUS_T | MINUS_T | REF_T | TILDA_T | EXC_NOT_T )
            int alt66=5;
            switch ( input.LA(1) ) {
            case PLUS_T:
                {
                alt66=1;
                }
                break;
            case MINUS_T:
                {
                alt66=2;
                }
                break;
            case REF_T:
                {
                alt66=3;
                }
                break;
            case TILDA_T:
                {
                alt66=4;
                }
                break;
            case EXC_NOT_T:
                {
                alt66=5;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 66, 0, input);

                throw nvae;
            }

            switch (alt66) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1562:5: PLUS_T
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    PLUS_T219=(SLAST)match(input,PLUS_T,FOLLOW_PLUS_T_in_unary_symbol2934); 
                    PLUS_T219_tree = (SLAST)adaptor.dupNode(PLUS_T219);

                    adaptor.addChild(root_0, PLUS_T219_tree);

                    ((unary_symbol_list_scope)unary_symbol_list_stack.peek()).list.add(0,1);

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1563:5: MINUS_T
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    MINUS_T220=(SLAST)match(input,MINUS_T,FOLLOW_MINUS_T_in_unary_symbol2943); 
                    MINUS_T220_tree = (SLAST)adaptor.dupNode(MINUS_T220);

                    adaptor.addChild(root_0, MINUS_T220_tree);

                    ((unary_symbol_list_scope)unary_symbol_list_stack.peek()).list.add(0,2);

                    }
                    break;
                case 3 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1564:5: REF_T
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    REF_T221=(SLAST)match(input,REF_T,FOLLOW_REF_T_in_unary_symbol2951); 
                    REF_T221_tree = (SLAST)adaptor.dupNode(REF_T221);

                    adaptor.addChild(root_0, REF_T221_tree);

                    ((unary_symbol_list_scope)unary_symbol_list_stack.peek()).list.add(0,3);

                    }
                    break;
                case 4 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1565:5: TILDA_T
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    TILDA_T222=(SLAST)match(input,TILDA_T,FOLLOW_TILDA_T_in_unary_symbol2961); 
                    TILDA_T222_tree = (SLAST)adaptor.dupNode(TILDA_T222);

                    adaptor.addChild(root_0, TILDA_T222_tree);

                    ((unary_symbol_list_scope)unary_symbol_list_stack.peek()).list.add(0,4);

                    }
                    break;
                case 5 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1566:5: EXC_NOT_T
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    EXC_NOT_T223=(SLAST)match(input,EXC_NOT_T,FOLLOW_EXC_NOT_T_in_unary_symbol2969); 
                    EXC_NOT_T223_tree = (SLAST)adaptor.dupNode(EXC_NOT_T223);

                    adaptor.addChild(root_0, EXC_NOT_T223_tree);

                    ((unary_symbol_list_scope)unary_symbol_list_stack.peek()).list.add(0,5);

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "unary_symbol"

    public static class plus_minus_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "plus_minus"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1569:1: plus_minus : ( PLUS_PLUS_T | MINUS_MINUS_T );
    public final TreePHP.plus_minus_return plus_minus() throws RecognitionException {
        TreePHP.plus_minus_return retval = new TreePHP.plus_minus_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST set224=null;

        SLAST set224_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1570:3: ( PLUS_PLUS_T | MINUS_MINUS_T )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            set224=(SLAST)input.LT(1);
            if ( (input.LA(1)>=PLUS_PLUS_T && input.LA(1)<=MINUS_MINUS_T) ) {
                input.consume();

                set224_tree = (SLAST)adaptor.dupNode(set224);

                adaptor.addChild(root_0, set224_tree);

                state.errorRecovery=false;
            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                throw mse;
            }

             

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "plus_minus"

    public static class cast_option_return extends TreeRuleReturnScope {
        public int castOption;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "cast_option"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1574:1: cast_option returns [int castOption] : ( 'bool' | 'boolean' | 'int' | 'float' | 'double' | 'array' | 'object' | 'real' | 'string' | 'unset' | CLONE_T );
    public final TreePHP.cast_option_return cast_option() throws RecognitionException {
        TreePHP.cast_option_return retval = new TreePHP.cast_option_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST string_literal225=null;
        SLAST string_literal226=null;
        SLAST string_literal227=null;
        SLAST string_literal228=null;
        SLAST string_literal229=null;
        SLAST string_literal230=null;
        SLAST string_literal231=null;
        SLAST string_literal232=null;
        SLAST string_literal233=null;
        SLAST string_literal234=null;
        SLAST CLONE_T235=null;

        SLAST string_literal225_tree=null;
        SLAST string_literal226_tree=null;
        SLAST string_literal227_tree=null;
        SLAST string_literal228_tree=null;
        SLAST string_literal229_tree=null;
        SLAST string_literal230_tree=null;
        SLAST string_literal231_tree=null;
        SLAST string_literal232_tree=null;
        SLAST string_literal233_tree=null;
        SLAST string_literal234_tree=null;
        SLAST CLONE_T235_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1575:3: ( 'bool' | 'boolean' | 'int' | 'float' | 'double' | 'array' | 'object' | 'real' | 'string' | 'unset' | CLONE_T )
            int alt67=11;
            switch ( input.LA(1) ) {
            case 173:
                {
                alt67=1;
                }
                break;
            case 174:
                {
                alt67=2;
                }
                break;
            case 175:
                {
                alt67=3;
                }
                break;
            case 176:
                {
                alt67=4;
                }
                break;
            case 177:
                {
                alt67=5;
                }
                break;
            case 182:
                {
                alt67=6;
                }
                break;
            case 181:
                {
                alt67=7;
                }
                break;
            case 178:
                {
                alt67=8;
                }
                break;
            case 179:
                {
                alt67=9;
                }
                break;
            case 180:
                {
                alt67=10;
                }
                break;
            case CLONE_T:
                {
                alt67=11;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 67, 0, input);

                throw nvae;
            }

            switch (alt67) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1575:5: 'bool'
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    string_literal225=(SLAST)match(input,173,FOLLOW_173_in_cast_option3007); 
                    string_literal225_tree = (SLAST)adaptor.dupNode(string_literal225);

                    adaptor.addChild(root_0, string_literal225_tree);

                    retval.castOption = 1;

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1576:5: 'boolean'
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    string_literal226=(SLAST)match(input,174,FOLLOW_174_in_cast_option3018); 
                    string_literal226_tree = (SLAST)adaptor.dupNode(string_literal226);

                    adaptor.addChild(root_0, string_literal226_tree);

                    retval.castOption = 2;

                    }
                    break;
                case 3 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1577:5: 'int'
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    string_literal227=(SLAST)match(input,175,FOLLOW_175_in_cast_option3026); 
                    string_literal227_tree = (SLAST)adaptor.dupNode(string_literal227);

                    adaptor.addChild(root_0, string_literal227_tree);

                    retval.castOption = 3;

                    }
                    break;
                case 4 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1578:5: 'float'
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    string_literal228=(SLAST)match(input,176,FOLLOW_176_in_cast_option3038); 
                    string_literal228_tree = (SLAST)adaptor.dupNode(string_literal228);

                    adaptor.addChild(root_0, string_literal228_tree);

                    retval.castOption = 4;

                    }
                    break;
                case 5 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1579:5: 'double'
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    string_literal229=(SLAST)match(input,177,FOLLOW_177_in_cast_option3048); 
                    string_literal229_tree = (SLAST)adaptor.dupNode(string_literal229);

                    adaptor.addChild(root_0, string_literal229_tree);

                    retval.castOption = 5;

                    }
                    break;
                case 6 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1580:5: 'array'
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    string_literal230=(SLAST)match(input,182,FOLLOW_182_in_cast_option3057); 
                    string_literal230_tree = (SLAST)adaptor.dupNode(string_literal230);

                    adaptor.addChild(root_0, string_literal230_tree);

                    retval.castOption = 6;

                    }
                    break;
                case 7 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1581:5: 'object'
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    string_literal231=(SLAST)match(input,181,FOLLOW_181_in_cast_option3067); 
                    string_literal231_tree = (SLAST)adaptor.dupNode(string_literal231);

                    adaptor.addChild(root_0, string_literal231_tree);

                    retval.castOption = 7;

                    }
                    break;
                case 8 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1582:5: 'real'
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    string_literal232=(SLAST)match(input,178,FOLLOW_178_in_cast_option3076); 
                    string_literal232_tree = (SLAST)adaptor.dupNode(string_literal232);

                    adaptor.addChild(root_0, string_literal232_tree);

                    retval.castOption = 8;

                    }
                    break;
                case 9 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1583:5: 'string'
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    string_literal233=(SLAST)match(input,179,FOLLOW_179_in_cast_option3087); 
                    string_literal233_tree = (SLAST)adaptor.dupNode(string_literal233);

                    adaptor.addChild(root_0, string_literal233_tree);

                    retval.castOption = 9;

                    }
                    break;
                case 10 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1584:5: 'unset'
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    string_literal234=(SLAST)match(input,180,FOLLOW_180_in_cast_option3096); 
                    string_literal234_tree = (SLAST)adaptor.dupNode(string_literal234);

                    adaptor.addChild(root_0, string_literal234_tree);

                    retval.castOption = 10;

                    }
                    break;
                case 11 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1585:5: CLONE_T
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    CLONE_T235=(SLAST)match(input,CLONE_T,FOLLOW_CLONE_T_in_cast_option3106); 
                    CLONE_T235_tree = (SLAST)adaptor.dupNode(CLONE_T235);

                    adaptor.addChild(root_0, CLONE_T235_tree);

                    retval.castOption = 11;

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "cast_option"

    public static class lambda_function_declaration_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "lambda_function_declaration"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1588:1: lambda_function_declaration : ^( METHOD_DECL ( REF_T )? ( parameter_list )? ( ^( USE_T ( expr_list )? ) )? block ) ;
    public final TreePHP.lambda_function_declaration_return lambda_function_declaration() throws RecognitionException {
        TreePHP.lambda_function_declaration_return retval = new TreePHP.lambda_function_declaration_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST METHOD_DECL236=null;
        SLAST REF_T237=null;
        SLAST USE_T239=null;
        TreePHP.parameter_list_return parameter_list238 = null;

        TreePHP.expr_list_return expr_list240 = null;

        TreePHP.block_return block241 = null;


        SLAST METHOD_DECL236_tree=null;
        SLAST REF_T237_tree=null;
        SLAST USE_T239_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1589:3: ( ^( METHOD_DECL ( REF_T )? ( parameter_list )? ( ^( USE_T ( expr_list )? ) )? block ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1589:5: ^( METHOD_DECL ( REF_T )? ( parameter_list )? ( ^( USE_T ( expr_list )? ) )? block )
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_1 = _last;
            SLAST _first_1 = null;
            SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            METHOD_DECL236=(SLAST)match(input,METHOD_DECL,FOLLOW_METHOD_DECL_in_lambda_function_declaration3125); 
            METHOD_DECL236_tree = (SLAST)adaptor.dupNode(METHOD_DECL236);

            root_1 = (SLAST)adaptor.becomeRoot(METHOD_DECL236_tree, root_1);



            match(input, Token.DOWN, null); 
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1589:19: ( REF_T )?
            int alt68=2;
            int LA68_0 = input.LA(1);

            if ( (LA68_0==REF_T) ) {
                alt68=1;
            }
            switch (alt68) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1589:19: REF_T
                    {
                    _last = (SLAST)input.LT(1);
                    REF_T237=(SLAST)match(input,REF_T,FOLLOW_REF_T_in_lambda_function_declaration3127); 
                    REF_T237_tree = (SLAST)adaptor.dupNode(REF_T237);

                    adaptor.addChild(root_1, REF_T237_tree);


                    }
                    break;

            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1589:26: ( parameter_list )?
            int alt69=2;
            int LA69_0 = input.LA(1);

            if ( (LA69_0==PARAMETER) ) {
                alt69=1;
            }
            switch (alt69) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1589:26: parameter_list
                    {
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_parameter_list_in_lambda_function_declaration3130);
                    parameter_list238=parameter_list();

                    state._fsp--;

                    adaptor.addChild(root_1, parameter_list238.getTree());

                    }
                    break;

            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1589:42: ( ^( USE_T ( expr_list )? ) )?
            int alt71=2;
            int LA71_0 = input.LA(1);

            if ( (LA71_0==USE_T) ) {
                alt71=1;
            }
            switch (alt71) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1589:43: ^( USE_T ( expr_list )? )
                    {
                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_2 = _last;
                    SLAST _first_2 = null;
                    SLAST root_2 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    USE_T239=(SLAST)match(input,USE_T,FOLLOW_USE_T_in_lambda_function_declaration3135); 
                    USE_T239_tree = (SLAST)adaptor.dupNode(USE_T239);

                    root_2 = (SLAST)adaptor.becomeRoot(USE_T239_tree, root_2);



                    if ( input.LA(1)==Token.DOWN ) {
                        match(input, Token.DOWN, null); 
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1589:51: ( expr_list )?
                        int alt70=2;
                        int LA70_0 = input.LA(1);

                        if ( (LA70_0==VAR_DECL||LA70_0==CALL||LA70_0==EXPR||(LA70_0>=SCALAR && LA70_0<=UNARY_EXPR)||LA70_0==REF_T||LA70_0==EQUAL_T||(LA70_0>=OR_T && LA70_0<=CLONE_T)||(LA70_0>=INSTANCEOF_T && LA70_0<=PRINT_T)) ) {
                            alt70=1;
                        }
                        switch (alt70) {
                            case 1 :
                                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1589:51: expr_list
                                {
                                _last = (SLAST)input.LT(1);
                                pushFollow(FOLLOW_expr_list_in_lambda_function_declaration3137);
                                expr_list240=expr_list();

                                state._fsp--;

                                adaptor.addChild(root_2, expr_list240.getTree());

                                }
                                break;

                        }


                        match(input, Token.UP, null); 
                    }adaptor.addChild(root_1, root_2);_last = _save_last_2;
                    }


                    }
                    break;

            }

            _last = (SLAST)input.LT(1);
            pushFollow(FOLLOW_block_in_lambda_function_declaration3149);
            block241=block();

            state._fsp--;

            adaptor.addChild(root_1, block241.getTree());

            match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "lambda_function_declaration"

    protected static class class_name_reference_scope {
        List list;
        List argList;
    }
    protected Stack class_name_reference_stack = new Stack();

    public static class class_name_reference_return extends TreeRuleReturnScope {
        public Expression var;
        public Expression expr;
        public PHPCallArgumentsList parameterList;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "class_name_reference"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1593:1: class_name_reference returns [Expression var, Expression expr, PHPCallArgumentsList parameterList] : ( dynamic_name_reference | fully_qualified_class_name );
    public final TreePHP.class_name_reference_return class_name_reference() throws RecognitionException {
        class_name_reference_stack.push(new class_name_reference_scope());
        TreePHP.class_name_reference_return retval = new TreePHP.class_name_reference_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.dynamic_name_reference_return dynamic_name_reference242 = null;

        TreePHP.fully_qualified_class_name_return fully_qualified_class_name243 = null;




          ((class_name_reference_scope)class_name_reference_stack.peek()).list = new LinkedList();
          ((class_name_reference_scope)class_name_reference_stack.peek()).argList = new LinkedList();

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1602:3: ( dynamic_name_reference | fully_qualified_class_name )
            int alt72=2;
            int LA72_0 = input.LA(1);

            if ( (LA72_0==VAR_DECL||LA72_0==CALL) ) {
                alt72=1;
            }
            else if ( (LA72_0==IDENTIFIER||LA72_0==DOMAIN_T) ) {
                alt72=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 72, 0, input);

                throw nvae;
            }
            switch (alt72) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1602:5: dynamic_name_reference
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_dynamic_name_reference_in_class_name_reference3182);
                    dynamic_name_reference242=dynamic_name_reference();

                    state._fsp--;

                    adaptor.addChild(root_0, dynamic_name_reference242.getTree());

                        retval.var = (dynamic_name_reference242!=null?dynamic_name_reference242.var:null);
                        retval.parameterList = (dynamic_name_reference242!=null?dynamic_name_reference242.parameterList:null);
                        retval.expr = (dynamic_name_reference242!=null?dynamic_name_reference242.expr:null);
                        
                        Expression dispatcher = retval.var;
                        Iterator iter = ((class_name_reference_scope)class_name_reference_stack.peek()).list.iterator();
                        while (iter.hasNext()) {
                          Expression property = (Expression)iter.next();
                          dispatcher = createDispatch(dispatcher, property);
                        }
                        retval.var = dispatcher;
                      

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1616:5: fully_qualified_class_name
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_fully_qualified_class_name_in_class_name_reference3193);
                    fully_qualified_class_name243=fully_qualified_class_name();

                    state._fsp--;

                    adaptor.addChild(root_0, fully_qualified_class_name243.getTree());

                        retval.var = (fully_qualified_class_name243!=null?fully_qualified_class_name243.type:null);
                      

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
            class_name_reference_stack.pop();
        }
        return retval;
    }
    // $ANTLR end "class_name_reference"

    public static class dynamic_name_reference_return extends TreeRuleReturnScope {
        public Expression var;
        public PHPCallArgumentsList parameterList;
        public Expression expr;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "dynamic_name_reference"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1622:1: dynamic_name_reference returns [Expression var, PHPCallArgumentsList parameterList, Expression expr] : ( base_variable_with_function_calls | ^( CALL v1= dynamic_name_reference obj= object_property ( ctor_arguments )? ) );
    public final TreePHP.dynamic_name_reference_return dynamic_name_reference() throws RecognitionException {
        TreePHP.dynamic_name_reference_return retval = new TreePHP.dynamic_name_reference_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST CALL245=null;
        TreePHP.dynamic_name_reference_return v1 = null;

        TreePHP.object_property_return obj = null;

        TreePHP.base_variable_with_function_calls_return base_variable_with_function_calls244 = null;

        TreePHP.ctor_arguments_return ctor_arguments246 = null;


        SLAST CALL245_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1623:3: ( base_variable_with_function_calls | ^( CALL v1= dynamic_name_reference obj= object_property ( ctor_arguments )? ) )
            int alt74=2;
            int LA74_0 = input.LA(1);

            if ( (LA74_0==VAR_DECL) ) {
                alt74=1;
            }
            else if ( (LA74_0==CALL) ) {
                int LA74_2 = input.LA(2);

                if ( (LA74_2==DOWN) ) {
                    int LA74_3 = input.LA(3);

                    if ( (LA74_3==VAR_DECL||LA74_3==CALL) ) {
                        alt74=2;
                    }
                    else if ( (LA74_3==IDENTIFIER||LA74_3==DOMAIN_T) ) {
                        alt74=1;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 74, 3, input);

                        throw nvae;
                    }
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 74, 2, input);

                    throw nvae;
                }
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 74, 0, input);

                throw nvae;
            }
            switch (alt74) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1623:5: base_variable_with_function_calls
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_base_variable_with_function_calls_in_dynamic_name_reference3216);
                    base_variable_with_function_calls244=base_variable_with_function_calls();

                    state._fsp--;

                    adaptor.addChild(root_0, base_variable_with_function_calls244.getTree());

                         retval.expr = (base_variable_with_function_calls244!=null?base_variable_with_function_calls244.var:null);
                         retval.var = (base_variable_with_function_calls244!=null?base_variable_with_function_calls244.var:null);
                         retval.parameterList = (base_variable_with_function_calls244!=null?base_variable_with_function_calls244.parameterList:null);
                      

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1629:5: ^( CALL v1= dynamic_name_reference obj= object_property ( ctor_arguments )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    CALL245=(SLAST)match(input,CALL,FOLLOW_CALL_in_dynamic_name_reference3228); 
                    CALL245_tree = (SLAST)adaptor.dupNode(CALL245);

                    root_1 = (SLAST)adaptor.becomeRoot(CALL245_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_dynamic_name_reference_in_dynamic_name_reference3232);
                    v1=dynamic_name_reference();

                    state._fsp--;

                    adaptor.addChild(root_1, v1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_object_property_in_dynamic_name_reference3236);
                    obj=object_property();

                    state._fsp--;

                    adaptor.addChild(root_1, obj.getTree());
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1629:58: ( ctor_arguments )?
                    int alt73=2;
                    int LA73_0 = input.LA(1);

                    if ( (LA73_0==ARGU) ) {
                        alt73=1;
                    }
                    switch (alt73) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1629:58: ctor_arguments
                            {
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_ctor_arguments_in_dynamic_name_reference3238);
                            ctor_arguments246=ctor_arguments();

                            state._fsp--;

                            adaptor.addChild(root_1, ctor_arguments246.getTree());

                            }
                            break;

                    }


                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                          retval.var = (v1!=null?v1.expr:null);
                          retval.expr = (v1!=null?v1.var:null);
                          
                          ((class_name_reference_scope)class_name_reference_stack.peek()).list.add((obj!=null?obj.expr:null));
                          
                          System.out.println("ctor:");
                          if ((ctor_arguments246!=null?ctor_arguments246.argumentList:null) != null) {
                            retval.parameterList = (ctor_arguments246!=null?ctor_arguments246.argumentList:null);
                          }
                          else if ((v1!=null?v1.parameterList:null) != null) {
                            retval.parameterList = (ctor_arguments246!=null?ctor_arguments246.argumentList:null);
                          }
                      

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "dynamic_name_reference"

    public static class list_decl_return extends TreeRuleReturnScope {
        public Expression expr;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "list_decl"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1646:1: list_decl returns [Expression expr] : ^( LIST_T ( assignment_list )? ) ;
    public final TreePHP.list_decl_return list_decl() throws RecognitionException {
        TreePHP.list_decl_return retval = new TreePHP.list_decl_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST LIST_T247=null;
        TreePHP.assignment_list_return assignment_list248 = null;


        SLAST LIST_T247_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1647:3: ( ^( LIST_T ( assignment_list )? ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1647:5: ^( LIST_T ( assignment_list )? )
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_1 = _last;
            SLAST _first_1 = null;
            SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            LIST_T247=(SLAST)match(input,LIST_T,FOLLOW_LIST_T_in_list_decl3262); 
            LIST_T247_tree = (SLAST)adaptor.dupNode(LIST_T247);

            root_1 = (SLAST)adaptor.becomeRoot(LIST_T247_tree, root_1);



            if ( input.LA(1)==Token.DOWN ) {
                match(input, Token.DOWN, null); 
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1647:14: ( assignment_list )?
                int alt75=2;
                int LA75_0 = input.LA(1);

                if ( (LA75_0==VAR_DECL||LA75_0==CALL||LA75_0==LIST_T) ) {
                    alt75=1;
                }
                switch (alt75) {
                    case 1 :
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1647:14: assignment_list
                        {
                        _last = (SLAST)input.LT(1);
                        pushFollow(FOLLOW_assignment_list_in_list_decl3264);
                        assignment_list248=assignment_list();

                        state._fsp--;

                        adaptor.addChild(root_1, assignment_list248.getTree());

                        }
                        break;

                }


                match(input, Token.UP, null); 
            }adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


                int startIndex = (LIST_T247).startIndex;
                int endIndex = LIST_T247.endIndex + 1;
                retval.expr = new ListVariable(startIndex, endIndex, (assignment_list248!=null?assignment_list248.assignList:null));
              

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "list_decl"

    protected static class assignment_list_scope {
        List list;
    }
    protected Stack assignment_list_stack = new Stack();

    public static class assignment_list_return extends TreeRuleReturnScope {
        public List assignList;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "assignment_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1655:1: assignment_list returns [List assignList] : ( assignment_element )+ ;
    public final TreePHP.assignment_list_return assignment_list() throws RecognitionException {
        assignment_list_stack.push(new assignment_list_scope());
        TreePHP.assignment_list_return retval = new TreePHP.assignment_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.assignment_element_return assignment_element249 = null;




          ((assignment_list_scope)assignment_list_stack.peek()).list = new LinkedList();

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1662:3: ( ( assignment_element )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1662:5: ( assignment_element )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1662:5: ( assignment_element )+
            int cnt76=0;
            loop76:
            do {
                int alt76=2;
                int LA76_0 = input.LA(1);

                if ( (LA76_0==VAR_DECL||LA76_0==CALL||LA76_0==LIST_T) ) {
                    alt76=1;
                }


                switch (alt76) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1662:5: assignment_element
            	    {
            	    _last = (SLAST)input.LT(1);
            	    pushFollow(FOLLOW_assignment_element_in_assignment_list3296);
            	    assignment_element249=assignment_element();

            	    state._fsp--;

            	    adaptor.addChild(root_0, assignment_element249.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt76 >= 1 ) break loop76;
                        EarlyExitException eee =
                            new EarlyExitException(76, input);
                        throw eee;
                }
                cnt76++;
            } while (true);


                retval.assignList = ((assignment_list_scope)assignment_list_stack.peek()).list;
              

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
            assignment_list_stack.pop();
        }
        return retval;
    }
    // $ANTLR end "assignment_list"

    public static class assignment_element_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "assignment_element"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1668:1: assignment_element : ( variable | list_decl );
    public final TreePHP.assignment_element_return assignment_element() throws RecognitionException {
        TreePHP.assignment_element_return retval = new TreePHP.assignment_element_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.variable_return variable250 = null;

        TreePHP.list_decl_return list_decl251 = null;



        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1669:3: ( variable | list_decl )
            int alt77=2;
            int LA77_0 = input.LA(1);

            if ( (LA77_0==VAR_DECL||LA77_0==CALL) ) {
                alt77=1;
            }
            else if ( (LA77_0==LIST_T) ) {
                alt77=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 77, 0, input);

                throw nvae;
            }
            switch (alt77) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1669:5: variable
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_variable_in_assignment_element3314);
                    variable250=variable();

                    state._fsp--;

                    adaptor.addChild(root_0, variable250.getTree());

                        System.out.println("var: " + (variable250!=null?variable250.var:null));
                        ((assignment_list_scope)assignment_list_stack.peek()).list.add((variable250!=null?variable250.var:null));
                      

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1674:5: list_decl
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_list_decl_in_assignment_element3324);
                    list_decl251=list_decl();

                    state._fsp--;

                    adaptor.addChild(root_0, list_decl251.getTree());

                        ((assignment_list_scope)assignment_list_stack.peek()).list.add((list_decl251!=null?list_decl251.expr:null));
                      

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "assignment_element"

    protected static class array_pair_list_scope {
        List list;
    }
    protected Stack array_pair_list_stack = new Stack();

    public static class array_pair_list_return extends TreeRuleReturnScope {
        public List arrayList;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "array_pair_list"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1680:1: array_pair_list returns [List arrayList] : ( array_pair_element )+ ;
    public final TreePHP.array_pair_list_return array_pair_list() throws RecognitionException {
        array_pair_list_stack.push(new array_pair_list_scope());
        TreePHP.array_pair_list_return retval = new TreePHP.array_pair_list_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.array_pair_element_return array_pair_element252 = null;




          ((array_pair_list_scope)array_pair_list_stack.peek()).list = new LinkedList();

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1687:3: ( ( array_pair_element )+ )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1687:5: ( array_pair_element )+
            {
            root_0 = (SLAST)adaptor.nil();

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1687:5: ( array_pair_element )+
            int cnt78=0;
            loop78:
            do {
                int alt78=2;
                int LA78_0 = input.LA(1);

                if ( (LA78_0==VAR_DECL||LA78_0==CALL||LA78_0==EXPR||(LA78_0>=SCALAR && LA78_0<=UNARY_EXPR)||LA78_0==REF_T||LA78_0==ARROW_T||LA78_0==EQUAL_T||(LA78_0>=OR_T && LA78_0<=CLONE_T)||(LA78_0>=INSTANCEOF_T && LA78_0<=PRINT_T)) ) {
                    alt78=1;
                }


                switch (alt78) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1687:5: array_pair_element
            	    {
            	    _last = (SLAST)input.LT(1);
            	    pushFollow(FOLLOW_array_pair_element_in_array_pair_list3356);
            	    array_pair_element252=array_pair_element();

            	    state._fsp--;

            	    adaptor.addChild(root_0, array_pair_element252.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt78 >= 1 ) break loop78;
                        EarlyExitException eee =
                            new EarlyExitException(78, input);
                        throw eee;
                }
                cnt78++;
            } while (true);


                retval.arrayList = ((array_pair_list_scope)array_pair_list_stack.peek()).list;
              

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
            array_pair_list_stack.pop();
        }
        return retval;
    }
    // $ANTLR end "array_pair_list"

    public static class array_pair_element_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "array_pair_element"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1693:1: array_pair_element : ( ^( ARROW_T e1= expression e2= expression ) | e= expression );
    public final TreePHP.array_pair_element_return array_pair_element() throws RecognitionException {
        TreePHP.array_pair_element_return retval = new TreePHP.array_pair_element_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST ARROW_T253=null;
        TreePHP.expression_return e1 = null;

        TreePHP.expression_return e2 = null;

        TreePHP.expression_return e = null;


        SLAST ARROW_T253_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1694:3: ( ^( ARROW_T e1= expression e2= expression ) | e= expression )
            int alt79=2;
            int LA79_0 = input.LA(1);

            if ( (LA79_0==ARROW_T) ) {
                alt79=1;
            }
            else if ( (LA79_0==VAR_DECL||LA79_0==CALL||LA79_0==EXPR||(LA79_0>=SCALAR && LA79_0<=UNARY_EXPR)||LA79_0==REF_T||LA79_0==EQUAL_T||(LA79_0>=OR_T && LA79_0<=CLONE_T)||(LA79_0>=INSTANCEOF_T && LA79_0<=PRINT_T)) ) {
                alt79=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 79, 0, input);

                throw nvae;
            }
            switch (alt79) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1694:5: ^( ARROW_T e1= expression e2= expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    ARROW_T253=(SLAST)match(input,ARROW_T,FOLLOW_ARROW_T_in_array_pair_element3377); 
                    ARROW_T253_tree = (SLAST)adaptor.dupNode(ARROW_T253);

                    root_1 = (SLAST)adaptor.becomeRoot(ARROW_T253_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_array_pair_element3381);
                    e1=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_array_pair_element3385);
                    e2=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, e2.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = ARROW_T253.startIndex;
                        int endIndex = ARROW_T253.endIndex + 1;
                        Expression key = (e1!=null?e1.expr:null);
                        Expression value = (e2!=null?e2.expr:null); 
                        ArrayElement element = new ArrayElement(startIndex, endIndex, key, value);
                        ((array_pair_list_scope)array_pair_list_stack.peek()).list.add(element);
                      

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1703:5: e= expression
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_array_pair_element3398);
                    e=expression();

                    state._fsp--;

                    adaptor.addChild(root_0, e.getTree());

                        int startIndex = (e!=null?e.expr:null).sourceStart();
                        int endIndex = (e!=null?e.expr:null).sourceEnd();
                        Expression expr = (e!=null?e.expr:null);
                        ArrayElement element = new ArrayElement(startIndex, endIndex, expr);
                        ((array_pair_list_scope)array_pair_list_stack.peek()).list.add(element);
                      

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "array_pair_element"

    protected static class variable_scope {
        List list;
    }
    protected Stack variable_stack = new Stack();

    public static class variable_return extends TreeRuleReturnScope {
        public Expression expr;
        public Expression var;
        public PHPCallArgumentsList parameterList;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "variable"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1713:1: variable returns [Expression expr, Expression var, PHPCallArgumentsList parameterList] : variable_temp ;
    public final TreePHP.variable_return variable() throws RecognitionException {
        variable_stack.push(new variable_scope());
        TreePHP.variable_return retval = new TreePHP.variable_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        TreePHP.variable_temp_return variable_temp254 = null;




          ((variable_scope)variable_stack.peek()).list = new LinkedList();

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1720:3: ( variable_temp )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1720:5: variable_temp
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            pushFollow(FOLLOW_variable_temp_in_variable3433);
            variable_temp254=variable_temp();

            state._fsp--;

            adaptor.addChild(root_0, variable_temp254.getTree());

                Iterator iter = ((variable_scope)variable_stack.peek()).list.iterator();
                Expression dispatcher = (variable_temp254!=null?variable_temp254.var:null);
                iter = ((variable_scope)variable_stack.peek()).list.iterator();
                while (iter.hasNext()) {
                  Expression property = (Expression)iter.next();
                  dispatcher = createDispatch(dispatcher, property);
                }
                retval.expr = dispatcher;
                retval.var = dispatcher;
                System.out.println(retval.expr);
                if (inVarList) {
                  ((variable_list_scope)variable_list_stack.peek()).varList.add(retval.var);
                }
              

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
            variable_stack.pop();
        }
        return retval;
    }
    // $ANTLR end "variable"

    public static class variable_temp_return extends TreeRuleReturnScope {
        public Expression expr;
        public Expression var;
        public PHPCallArgumentsList parameterList;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "variable_temp"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1739:1: variable_temp returns [Expression expr, Expression var, PHPCallArgumentsList parameterList] : ( base_variable_with_function_calls | ^( CALL v1= variable_temp obj= object_property ( ctor_arguments )? ) );
    public final TreePHP.variable_temp_return variable_temp() throws RecognitionException {
        TreePHP.variable_temp_return retval = new TreePHP.variable_temp_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST CALL256=null;
        TreePHP.variable_temp_return v1 = null;

        TreePHP.object_property_return obj = null;

        TreePHP.base_variable_with_function_calls_return base_variable_with_function_calls255 = null;

        TreePHP.ctor_arguments_return ctor_arguments257 = null;


        SLAST CALL256_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1740:3: ( base_variable_with_function_calls | ^( CALL v1= variable_temp obj= object_property ( ctor_arguments )? ) )
            int alt81=2;
            int LA81_0 = input.LA(1);

            if ( (LA81_0==VAR_DECL) ) {
                alt81=1;
            }
            else if ( (LA81_0==CALL) ) {
                int LA81_2 = input.LA(2);

                if ( (LA81_2==DOWN) ) {
                    int LA81_3 = input.LA(3);

                    if ( (LA81_3==VAR_DECL||LA81_3==CALL) ) {
                        alt81=2;
                    }
                    else if ( (LA81_3==IDENTIFIER||LA81_3==DOMAIN_T) ) {
                        alt81=1;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 81, 3, input);

                        throw nvae;
                    }
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 81, 2, input);

                    throw nvae;
                }
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 81, 0, input);

                throw nvae;
            }
            switch (alt81) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1740:5: base_variable_with_function_calls
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_base_variable_with_function_calls_in_variable_temp3457);
                    base_variable_with_function_calls255=base_variable_with_function_calls();

                    state._fsp--;

                    adaptor.addChild(root_0, base_variable_with_function_calls255.getTree());

                         System.out.println("here");
                         retval.expr = (base_variable_with_function_calls255!=null?base_variable_with_function_calls255.expr:null);
                         retval.var = (base_variable_with_function_calls255!=null?base_variable_with_function_calls255.var:null);
                         
                         retval.parameterList = (base_variable_with_function_calls255!=null?base_variable_with_function_calls255.parameterList:null);
                      

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1748:5: ^( CALL v1= variable_temp obj= object_property ( ctor_arguments )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    CALL256=(SLAST)match(input,CALL,FOLLOW_CALL_in_variable_temp3469); 
                    CALL256_tree = (SLAST)adaptor.dupNode(CALL256);

                    root_1 = (SLAST)adaptor.becomeRoot(CALL256_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_variable_temp_in_variable_temp3473);
                    v1=variable_temp();

                    state._fsp--;

                    adaptor.addChild(root_1, v1.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_object_property_in_variable_temp3477);
                    obj=object_property();

                    state._fsp--;

                    adaptor.addChild(root_1, obj.getTree());
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1748:49: ( ctor_arguments )?
                    int alt80=2;
                    int LA80_0 = input.LA(1);

                    if ( (LA80_0==ARGU) ) {
                        alt80=1;
                    }
                    switch (alt80) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1748:49: ctor_arguments
                            {
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_ctor_arguments_in_variable_temp3479);
                            ctor_arguments257=ctor_arguments();

                            state._fsp--;

                            adaptor.addChild(root_1, ctor_arguments257.getTree());

                            }
                            break;

                    }


                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                          retval.var = (v1!=null?v1.var:null);
                          retval.expr = (v1!=null?v1.expr:null);
                          
                    //      System.out.println("$$retval.var: " + retval.var);
                          int objLeft = ((CommonToken)(obj!=null?((SLAST)obj.tree):null).token).getStartIndex();
                          int objRight = ((CommonToken)(obj!=null?((SLAST)obj.tree):null).token).getStopIndex() + 1;

                          Expression firstVarProperty = null;
                          if ((ctor_arguments257!=null?ctor_arguments257.argumentList:null) == null) {
                            firstVarProperty = (obj!=null?obj.expr:null);
                          }
                          else {
                            int paramListLeft = ((CommonToken)(ctor_arguments257!=null?((SLAST)ctor_arguments257.tree):null).token).getStartIndex();
                            int paramListRight = ((CommonToken)(ctor_arguments257!=null?((SLAST)ctor_arguments257.tree):null).token).getStopIndex() + 1;
                            if ((obj!=null?obj.simpleRef:null).getClass().equals(SimpleReference.class)) {
                    		      firstVarProperty = new PHPCallExpression(objLeft, paramListRight, null, (obj!=null?obj.simpleRef:null), (ctor_arguments257!=null?ctor_arguments257.argumentList:null));
                    		    } else {
                    		      firstVarProperty = new ReflectionCallExpression(objLeft, paramListRight, null, (SimpleReference)(obj!=null?obj.simpleRef:null), (ctor_arguments257!=null?ctor_arguments257.argumentList:null));
                    		    }
                          }
                          
                          ((variable_scope)variable_stack.peek()).list.add(firstVarProperty);
                      

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "variable_temp"

    public static class base_variable_with_function_calls_return extends TreeRuleReturnScope {
        public Expression expr;
        public Expression var;
        public PHPCallArgumentsList parameterList;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "base_variable_with_function_calls"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1775:1: base_variable_with_function_calls returns [Expression expr, Expression var, PHPCallArgumentsList parameterList] : ( ^( VAR_DECL ( fully_qualified_class_name )? obj= object_property ( ctor_arguments )? ) | ^( CALL fully_qualified_class_name ctor_arguments ) );
    public final TreePHP.base_variable_with_function_calls_return base_variable_with_function_calls() throws RecognitionException {
        TreePHP.base_variable_with_function_calls_return retval = new TreePHP.base_variable_with_function_calls_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST VAR_DECL258=null;
        SLAST CALL261=null;
        TreePHP.object_property_return obj = null;

        TreePHP.fully_qualified_class_name_return fully_qualified_class_name259 = null;

        TreePHP.ctor_arguments_return ctor_arguments260 = null;

        TreePHP.fully_qualified_class_name_return fully_qualified_class_name262 = null;

        TreePHP.ctor_arguments_return ctor_arguments263 = null;


        SLAST VAR_DECL258_tree=null;
        SLAST CALL261_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1776:3: ( ^( VAR_DECL ( fully_qualified_class_name )? obj= object_property ( ctor_arguments )? ) | ^( CALL fully_qualified_class_name ctor_arguments ) )
            int alt84=2;
            int LA84_0 = input.LA(1);

            if ( (LA84_0==VAR_DECL) ) {
                alt84=1;
            }
            else if ( (LA84_0==CALL) ) {
                alt84=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 84, 0, input);

                throw nvae;
            }
            switch (alt84) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1776:5: ^( VAR_DECL ( fully_qualified_class_name )? obj= object_property ( ctor_arguments )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    VAR_DECL258=(SLAST)match(input,VAR_DECL,FOLLOW_VAR_DECL_in_base_variable_with_function_calls3505); 
                    VAR_DECL258_tree = (SLAST)adaptor.dupNode(VAR_DECL258);

                    root_1 = (SLAST)adaptor.becomeRoot(VAR_DECL258_tree, root_1);



                    match(input, Token.DOWN, null); 
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1776:16: ( fully_qualified_class_name )?
                    int alt82=2;
                    int LA82_0 = input.LA(1);

                    if ( (LA82_0==IDENTIFIER||LA82_0==DOMAIN_T) ) {
                        alt82=1;
                    }
                    switch (alt82) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1776:16: fully_qualified_class_name
                            {
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_fully_qualified_class_name_in_base_variable_with_function_calls3507);
                            fully_qualified_class_name259=fully_qualified_class_name();

                            state._fsp--;

                            adaptor.addChild(root_1, fully_qualified_class_name259.getTree());

                            }
                            break;

                    }

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_object_property_in_base_variable_with_function_calls3512);
                    obj=object_property();

                    state._fsp--;

                    adaptor.addChild(root_1, obj.getTree());
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1776:64: ( ctor_arguments )?
                    int alt83=2;
                    int LA83_0 = input.LA(1);

                    if ( (LA83_0==ARGU) ) {
                        alt83=1;
                    }
                    switch (alt83) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1776:64: ctor_arguments
                            {
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_ctor_arguments_in_base_variable_with_function_calls3514);
                            ctor_arguments260=ctor_arguments();

                            state._fsp--;

                            adaptor.addChild(root_1, ctor_arguments260.getTree());

                            }
                            break;

                    }


                        int startIndex = VAR_DECL258.startIndex;
                        int endIndex = VAR_DECL258.endIndex + 1;
                        System.out.println("varid: " + startIndex + " " + endIndex);
                        retval.var = (obj!=null?obj.expr:null);
                        if ((fully_qualified_class_name259!=null?fully_qualified_class_name259.type:null) != null) {
                            retval.var = new StaticFieldAccess(startIndex, endIndex, (fully_qualified_class_name259!=null?fully_qualified_class_name259.type:null), (obj!=null?obj.expr:null));
                        }
                        
                        retval.expr = retval.var;
                      
                        if ((ctor_arguments260!=null?ctor_arguments260.argumentList:null) != null) {
                          PHPCallArgumentsList parameters = (ctor_arguments260!=null?ctor_arguments260.argumentList:null);
                      //    parameters.addNode(retval.var);
                          retval.parameterList = parameters;
                          retval.var = new ReflectionCallExpression(startIndex, endIndex, null, (obj!=null?obj.expr:null), parameters); 
                          System.out.println("var:" + retval.var);
                        }
                        else {
                          retval.parameterList = new PHPCallArgumentsList();
                        }
                      

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1800:5: ^( CALL fully_qualified_class_name ctor_arguments )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    CALL261=(SLAST)match(input,CALL,FOLLOW_CALL_in_base_variable_with_function_calls3535); 
                    CALL261_tree = (SLAST)adaptor.dupNode(CALL261);

                    root_1 = (SLAST)adaptor.becomeRoot(CALL261_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_fully_qualified_class_name_in_base_variable_with_function_calls3537);
                    fully_qualified_class_name262=fully_qualified_class_name();

                    state._fsp--;

                    adaptor.addChild(root_1, fully_qualified_class_name262.getTree());
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_ctor_arguments_in_base_variable_with_function_calls3539);
                    ctor_arguments263=ctor_arguments();

                    state._fsp--;

                    adaptor.addChild(root_1, ctor_arguments263.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        int startIndex = CALL261.startIndex;
                        int endIndex = CALL261.endIndex + 1;
                        
                        PHPCallArgumentsList parameters = (ctor_arguments263!=null?ctor_arguments263.argumentList:null);
                        if ((fully_qualified_class_name262!=null?fully_qualified_class_name262.simpleRef:null) != null) {
                          retval.var = new StaticMethodInvocation(startIndex, endIndex, (TypeReference)(fully_qualified_class_name262!=null?fully_qualified_class_name262.type:null), (fully_qualified_class_name262!=null?fully_qualified_class_name262.simpleRef:null), parameters);
                        }
                        else {
                        
                    	    int functionNameLeft= ((CommonToken)(fully_qualified_class_name262!=null?((SLAST)fully_qualified_class_name262.tree):null).token).getStartIndex();
                    	    int functionNameRight= ((CommonToken)(fully_qualified_class_name262!=null?((SLAST)fully_qualified_class_name262.tree):null).token).getStopIndex() + 1;
                    	    String functionName = (fully_qualified_class_name262!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(fully_qualified_class_name262.start),
                      input.getTreeAdaptor().getTokenStopIndex(fully_qualified_class_name262.start))):null);
                    	    SimpleReference name = new SimpleReference(functionNameLeft, functionNameRight, functionName);
                    	    retval.var = new PHPCallExpression(startIndex, endIndex, null, name, parameters);
                    	//    retval.var = (Expression)(fully_qualified_class_name262!=null?fully_qualified_class_name262.type:null);
                    	    retval.parameterList = parameters;
                    	  }    
                      

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "base_variable_with_function_calls"

    public static class object_property_return extends TreeRuleReturnScope {
        public String str;
        public Expression expr;
        public SimpleReference simpleRef;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "object_property"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1824:1: object_property returns [String str, Expression expr, SimpleReference simpleRef] : ( ^( VAR ( DOLLAR_T )* IDENTIFIER ) | ^( VAR ( DOLLAR_T )* expression ) | ^( INDEX obj= object_property ( expression )? ) | ^( HASH_INDEX obj= object_property ( expression )? ) );
    public final TreePHP.object_property_return object_property() throws RecognitionException {
        TreePHP.object_property_return retval = new TreePHP.object_property_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST VAR264=null;
        SLAST DOLLAR_T265=null;
        SLAST IDENTIFIER266=null;
        SLAST VAR267=null;
        SLAST DOLLAR_T268=null;
        SLAST INDEX270=null;
        SLAST HASH_INDEX272=null;
        TreePHP.object_property_return obj = null;

        TreePHP.expression_return expression269 = null;

        TreePHP.expression_return expression271 = null;

        TreePHP.expression_return expression273 = null;


        SLAST VAR264_tree=null;
        SLAST DOLLAR_T265_tree=null;
        SLAST IDENTIFIER266_tree=null;
        SLAST VAR267_tree=null;
        SLAST DOLLAR_T268_tree=null;
        SLAST INDEX270_tree=null;
        SLAST HASH_INDEX272_tree=null;


          int startIndex = -1;
          int endIndex = -1;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1829:3: ( ^( VAR ( DOLLAR_T )* IDENTIFIER ) | ^( VAR ( DOLLAR_T )* expression ) | ^( INDEX obj= object_property ( expression )? ) | ^( HASH_INDEX obj= object_property ( expression )? ) )
            int alt89=4;
            alt89 = dfa89.predict(input);
            switch (alt89) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1829:5: ^( VAR ( DOLLAR_T )* IDENTIFIER )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    VAR264=(SLAST)match(input,VAR,FOLLOW_VAR_in_object_property3573); 
                    VAR264_tree = (SLAST)adaptor.dupNode(VAR264);

                    root_1 = (SLAST)adaptor.becomeRoot(VAR264_tree, root_1);



                    match(input, Token.DOWN, null); 
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1829:11: ( DOLLAR_T )*
                    loop85:
                    do {
                        int alt85=2;
                        int LA85_0 = input.LA(1);

                        if ( (LA85_0==DOLLAR_T) ) {
                            alt85=1;
                        }


                        switch (alt85) {
                    	case 1 :
                    	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1829:11: DOLLAR_T
                    	    {
                    	    _last = (SLAST)input.LT(1);
                    	    DOLLAR_T265=(SLAST)match(input,DOLLAR_T,FOLLOW_DOLLAR_T_in_object_property3575); 
                    	    DOLLAR_T265_tree = (SLAST)adaptor.dupNode(DOLLAR_T265);

                    	    adaptor.addChild(root_1, DOLLAR_T265_tree);


                    	    }
                    	    break;

                    	default :
                    	    break loop85;
                        }
                    } while (true);

                    _last = (SLAST)input.LT(1);
                    IDENTIFIER266=(SLAST)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_object_property3578); 
                    IDENTIFIER266_tree = (SLAST)adaptor.dupNode(IDENTIFIER266);

                    adaptor.addChild(root_1, IDENTIFIER266_tree);


                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                            retval.str = (IDENTIFIER266!=null?IDENTIFIER266.getText():null);
                            startIndex = ((CommonToken)IDENTIFIER266.token).getStartIndex();
                            endIndex = ((CommonToken)IDENTIFIER266.token).getStopIndex() + 1;
                            if ((DOLLAR_T265!=null?DOLLAR_T265.getText():null) != null) {
                                retval.str = (DOLLAR_T265!=null?DOLLAR_T265.getText():null) + (IDENTIFIER266!=null?IDENTIFIER266.getText():null);
                                startIndex = ((CommonToken)DOLLAR_T265.token).getStartIndex();
                            }
                            VariableReference variableRef = new VariableReference(startIndex, endIndex, retval.str ,PHPVariableKind.LOCAL);
                            retval.expr = variableRef;
                            
                            retval.simpleRef = new SimpleReference(startIndex, endIndex, retval.str);
                    //        (((SLAST)retval.tree).token).setStartIndex(startInndex);
                        

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1844:5: ^( VAR ( DOLLAR_T )* expression )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    VAR267=(SLAST)match(input,VAR,FOLLOW_VAR_in_object_property3592); 
                    VAR267_tree = (SLAST)adaptor.dupNode(VAR267);

                    root_1 = (SLAST)adaptor.becomeRoot(VAR267_tree, root_1);



                    match(input, Token.DOWN, null); 
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1844:11: ( DOLLAR_T )*
                    loop86:
                    do {
                        int alt86=2;
                        int LA86_0 = input.LA(1);

                        if ( (LA86_0==DOLLAR_T) ) {
                            alt86=1;
                        }


                        switch (alt86) {
                    	case 1 :
                    	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1844:11: DOLLAR_T
                    	    {
                    	    _last = (SLAST)input.LT(1);
                    	    DOLLAR_T268=(SLAST)match(input,DOLLAR_T,FOLLOW_DOLLAR_T_in_object_property3594); 
                    	    DOLLAR_T268_tree = (SLAST)adaptor.dupNode(DOLLAR_T268);

                    	    adaptor.addChild(root_1, DOLLAR_T268_tree);


                    	    }
                    	    break;

                    	default :
                    	    break loop86;
                        }
                    } while (true);

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_expression_in_object_property3597);
                    expression269=expression();

                    state._fsp--;

                    adaptor.addChild(root_1, expression269.getTree());

                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        startIndex = VAR267.startIndex;
                        endIndex = VAR267.endIndex + 1;
                        retval.expr = new ReflectionVariableReference(startIndex, endIndex, (expression269!=null?expression269.expr:null));
                        System.out.println("**" + retval.expr);
                      

                    }
                    break;
                case 3 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1851:5: ^( INDEX obj= object_property ( expression )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    INDEX270=(SLAST)match(input,INDEX,FOLLOW_INDEX_in_object_property3609); 
                    INDEX270_tree = (SLAST)adaptor.dupNode(INDEX270);

                    root_1 = (SLAST)adaptor.becomeRoot(INDEX270_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_object_property_in_object_property3613);
                    obj=object_property();

                    state._fsp--;

                    adaptor.addChild(root_1, obj.getTree());
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1851:33: ( expression )?
                    int alt87=2;
                    int LA87_0 = input.LA(1);

                    if ( (LA87_0==VAR_DECL||LA87_0==CALL||LA87_0==EXPR||(LA87_0>=SCALAR && LA87_0<=UNARY_EXPR)||LA87_0==REF_T||LA87_0==EQUAL_T||(LA87_0>=OR_T && LA87_0<=CLONE_T)||(LA87_0>=INSTANCEOF_T && LA87_0<=PRINT_T)) ) {
                        alt87=1;
                    }
                    switch (alt87) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1851:33: expression
                            {
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_expression_in_object_property3615);
                            expression271=expression();

                            state._fsp--;

                            adaptor.addChild(root_1, expression271.getTree());

                            }
                            break;

                    }


                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        startIndex = INDEX270.startIndex;
                        endIndex = INDEX270.endIndex + 1;
                       
                        if (startIndex == 0 && (expression271!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(expression271.start),
                      input.getTreeAdaptor().getTokenStopIndex(expression271.start))):null) != null) {
                           startIndex = (obj!=null?((SLAST)obj.tree):null).startIndex;
                           endIndex = (obj!=null?((SLAST)obj.tree):null).endIndex + (expression271!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(expression271.start),
                      input.getTreeAdaptor().getTokenStopIndex(expression271.start))):null).length();
                        }
                        Expression varName = (obj!=null?obj.expr:null);
                        Expression index = (expression271!=null?expression271.expr:null);
                        if ((expression271!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(expression271.start),
                      input.getTreeAdaptor().getTokenStopIndex(expression271.start))):null) != null) {
                          if(varName.getKind() == ExpressionConstants.E_IDENTIFIER) {
                             retval.expr = new ArrayVariableReference(startIndex, endIndex, ((SimpleReference)varName).getName(), index, ArrayVariableReference.VARIABLE_ARRAY);
                          } else {
                             retval.expr = new ReflectionArrayVariableReference(startIndex, endIndex, varName, index, ReflectionArrayVariableReference.VARIABLE_ARRAY);
                          }
                        }
                        else {
                           retval.expr = new ArrayVariableReference(startIndex, endIndex, ((SimpleReference)varName).getName(), index, ArrayVariableReference.VARIABLE_ARRAY);
                        }
                      

                    }
                    break;
                case 4 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1873:5: ^( HASH_INDEX obj= object_property ( expression )? )
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    {
                    SLAST _save_last_1 = _last;
                    SLAST _first_1 = null;
                    SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
                    HASH_INDEX272=(SLAST)match(input,HASH_INDEX,FOLLOW_HASH_INDEX_in_object_property3628); 
                    HASH_INDEX272_tree = (SLAST)adaptor.dupNode(HASH_INDEX272);

                    root_1 = (SLAST)adaptor.becomeRoot(HASH_INDEX272_tree, root_1);



                    match(input, Token.DOWN, null); 
                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_object_property_in_object_property3632);
                    obj=object_property();

                    state._fsp--;

                    adaptor.addChild(root_1, obj.getTree());
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1873:38: ( expression )?
                    int alt88=2;
                    int LA88_0 = input.LA(1);

                    if ( (LA88_0==VAR_DECL||LA88_0==CALL||LA88_0==EXPR||(LA88_0>=SCALAR && LA88_0<=UNARY_EXPR)||LA88_0==REF_T||LA88_0==EQUAL_T||(LA88_0>=OR_T && LA88_0<=CLONE_T)||(LA88_0>=INSTANCEOF_T && LA88_0<=PRINT_T)) ) {
                        alt88=1;
                    }
                    switch (alt88) {
                        case 1 :
                            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1873:38: expression
                            {
                            _last = (SLAST)input.LT(1);
                            pushFollow(FOLLOW_expression_in_object_property3634);
                            expression273=expression();

                            state._fsp--;

                            adaptor.addChild(root_1, expression273.getTree());

                            }
                            break;

                    }


                    match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                        startIndex = HASH_INDEX272.startIndex;
                        endIndex = HASH_INDEX272.endIndex + 1;
                       
                        if (startIndex == 0 && (expression273!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(expression273.start),
                      input.getTreeAdaptor().getTokenStopIndex(expression273.start))):null) != null) {
                           startIndex = (obj!=null?((SLAST)obj.tree):null).startIndex;
                           endIndex = (obj!=null?((SLAST)obj.tree):null).endIndex + (expression273!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(expression273.start),
                      input.getTreeAdaptor().getTokenStopIndex(expression273.start))):null).length();
                        }
                        Expression varName = (obj!=null?obj.expr:null);
                        Expression index = (expression273!=null?expression273.expr:null);
                        if ((expression273!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(expression273.start),
                      input.getTreeAdaptor().getTokenStopIndex(expression273.start))):null) != null) {
                          if(varName.getKind() == ExpressionConstants.E_IDENTIFIER) {
                             retval.expr = new ArrayVariableReference(startIndex, endIndex, ((SimpleReference)varName).getName(), index, ArrayVariableReference.VARIABLE_HASHTABLE);
                          } else {
                             retval.expr = new ReflectionArrayVariableReference(startIndex, endIndex, varName, index, ReflectionArrayVariableReference.VARIABLE_HASHTABLE);
                          }
                        }
                        else {
                           retval.expr = new ArrayVariableReference(startIndex, endIndex, ((SimpleReference)varName).getName(), index, ArrayVariableReference.VARIABLE_HASHTABLE);
                        }
                      

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "object_property"

    public static class ctor_arguments_return extends TreeRuleReturnScope {
        public PHPCallArgumentsList argumentList;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "ctor_arguments"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1898:1: ctor_arguments returns [PHPCallArgumentsList argumentList] : ^( ARGU ( expr_list )? ) ;
    public final TreePHP.ctor_arguments_return ctor_arguments() throws RecognitionException {
        TreePHP.ctor_arguments_return retval = new TreePHP.ctor_arguments_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST ARGU274=null;
        TreePHP.expr_list_return expr_list275 = null;


        SLAST ARGU274_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1899:3: ( ^( ARGU ( expr_list )? ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1899:6: ^( ARGU ( expr_list )? )
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_1 = _last;
            SLAST _first_1 = null;
            SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            ARGU274=(SLAST)match(input,ARGU,FOLLOW_ARGU_in_ctor_arguments3664); 
            ARGU274_tree = (SLAST)adaptor.dupNode(ARGU274);

            root_1 = (SLAST)adaptor.becomeRoot(ARGU274_tree, root_1);



            if ( input.LA(1)==Token.DOWN ) {
                match(input, Token.DOWN, null); 
                // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1899:13: ( expr_list )?
                int alt90=2;
                int LA90_0 = input.LA(1);

                if ( (LA90_0==VAR_DECL||LA90_0==CALL||LA90_0==EXPR||(LA90_0>=SCALAR && LA90_0<=UNARY_EXPR)||LA90_0==REF_T||LA90_0==EQUAL_T||(LA90_0>=OR_T && LA90_0<=CLONE_T)||(LA90_0>=INSTANCEOF_T && LA90_0<=PRINT_T)) ) {
                    alt90=1;
                }
                switch (alt90) {
                    case 1 :
                        // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1899:13: expr_list
                        {
                        _last = (SLAST)input.LT(1);
                        pushFollow(FOLLOW_expr_list_in_ctor_arguments3666);
                        expr_list275=expr_list();

                        state._fsp--;

                        adaptor.addChild(root_1, expr_list275.getTree());

                        }
                        break;

                }


                match(input, Token.UP, null); 
            }adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


                int startIndex = ARGU274.startIndex + 1;
                int endIndex = ARGU274.endIndex;

            	  retval.argumentList = new PHPCallArgumentsList();
            	  retval.argumentList.setStart(startIndex);
            	  retval.argumentList.setEnd(endIndex);
            	  
            	  if ((expr_list275!=null?expr_list275.exprList:null) != null) {
            	    Iterator iter = (expr_list275!=null?expr_list275.exprList:null).iterator();
            	    while (iter.hasNext()) {
            	      retval.argumentList.addNode((Expression)iter.next());
            	    }
            	  }
              

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "ctor_arguments"

    public static class pure_variable_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "pure_variable"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1917:1: pure_variable : ^( VAR_DECL ( REF_T )? ( DOLLAR_T )+ IDENTIFIER ) ;
    public final TreePHP.pure_variable_return pure_variable() throws RecognitionException {
        TreePHP.pure_variable_return retval = new TreePHP.pure_variable_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST VAR_DECL276=null;
        SLAST REF_T277=null;
        SLAST DOLLAR_T278=null;
        SLAST IDENTIFIER279=null;

        SLAST VAR_DECL276_tree=null;
        SLAST REF_T277_tree=null;
        SLAST DOLLAR_T278_tree=null;
        SLAST IDENTIFIER279_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1918:3: ( ^( VAR_DECL ( REF_T )? ( DOLLAR_T )+ IDENTIFIER ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1918:5: ^( VAR_DECL ( REF_T )? ( DOLLAR_T )+ IDENTIFIER )
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_1 = _last;
            SLAST _first_1 = null;
            SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            VAR_DECL276=(SLAST)match(input,VAR_DECL,FOLLOW_VAR_DECL_in_pure_variable3688); 
            VAR_DECL276_tree = (SLAST)adaptor.dupNode(VAR_DECL276);

            root_1 = (SLAST)adaptor.becomeRoot(VAR_DECL276_tree, root_1);



            match(input, Token.DOWN, null); 
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1918:16: ( REF_T )?
            int alt91=2;
            int LA91_0 = input.LA(1);

            if ( (LA91_0==REF_T) ) {
                alt91=1;
            }
            switch (alt91) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1918:16: REF_T
                    {
                    _last = (SLAST)input.LT(1);
                    REF_T277=(SLAST)match(input,REF_T,FOLLOW_REF_T_in_pure_variable3690); 
                    REF_T277_tree = (SLAST)adaptor.dupNode(REF_T277);

                    adaptor.addChild(root_1, REF_T277_tree);


                    }
                    break;

            }

            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1918:23: ( DOLLAR_T )+
            int cnt92=0;
            loop92:
            do {
                int alt92=2;
                int LA92_0 = input.LA(1);

                if ( (LA92_0==DOLLAR_T) ) {
                    alt92=1;
                }


                switch (alt92) {
            	case 1 :
            	    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1918:23: DOLLAR_T
            	    {
            	    _last = (SLAST)input.LT(1);
            	    DOLLAR_T278=(SLAST)match(input,DOLLAR_T,FOLLOW_DOLLAR_T_in_pure_variable3693); 
            	    DOLLAR_T278_tree = (SLAST)adaptor.dupNode(DOLLAR_T278);

            	    adaptor.addChild(root_1, DOLLAR_T278_tree);


            	    }
            	    break;

            	default :
            	    if ( cnt92 >= 1 ) break loop92;
                        EarlyExitException eee =
                            new EarlyExitException(92, input);
                        throw eee;
                }
                cnt92++;
            } while (true);

            _last = (SLAST)input.LT(1);
            IDENTIFIER279=(SLAST)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_pure_variable3696); 
            IDENTIFIER279_tree = (SLAST)adaptor.dupNode(IDENTIFIER279);

            adaptor.addChild(root_1, IDENTIFIER279_tree);


            match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "pure_variable"

    public static class scalar_return extends TreeRuleReturnScope {
        public Expression expr;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "scalar"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1921:1: scalar returns [Expression expr] : ^( SCALAR constant ) ;
    public final TreePHP.scalar_return scalar() throws RecognitionException {
        TreePHP.scalar_return retval = new TreePHP.scalar_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST SCALAR280=null;
        TreePHP.constant_return constant281 = null;


        SLAST SCALAR280_tree=null;


          SLAST ast = null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1928:3: ( ^( SCALAR constant ) )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1928:5: ^( SCALAR constant )
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            {
            SLAST _save_last_1 = _last;
            SLAST _first_1 = null;
            SLAST root_1 = (SLAST)adaptor.nil();_last = (SLAST)input.LT(1);
            SCALAR280=(SLAST)match(input,SCALAR,FOLLOW_SCALAR_in_scalar3725); 
            SCALAR280_tree = (SLAST)adaptor.dupNode(SCALAR280);

            root_1 = (SLAST)adaptor.becomeRoot(SCALAR280_tree, root_1);



            match(input, Token.DOWN, null); 
            _last = (SLAST)input.LT(1);
            pushFollow(FOLLOW_constant_in_scalar3727);
            constant281=constant();

            state._fsp--;

            adaptor.addChild(root_1, constant281.getTree());

            match(input, Token.UP, null); adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


                if ((constant281!=null?constant281.expr:null) != null ) {
                  retval.expr = (constant281!=null?constant281.expr:null);
                }
                else {
                  retval.expr = (constant281!=null?constant281.scalar:null);
                }
                ast = (constant281!=null?((SLAST)constant281.tree):null);
              

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "scalar"

    public static class constant_return extends TreeRuleReturnScope {
        public Scalar scalar;
        public Expression expr;
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "constant"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1940:1: constant returns [Scalar scalar, Expression expr] : ( INTLITERAL | FLOATLITERAL | STRINGLITERAL | DOUBLELITERRAL | common_scalar | IDENTIFIER | fully_qualified_class_name );
    public final TreePHP.constant_return constant() throws RecognitionException {
        TreePHP.constant_return retval = new TreePHP.constant_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST INTLITERAL282=null;
        SLAST FLOATLITERAL283=null;
        SLAST STRINGLITERAL284=null;
        SLAST DOUBLELITERRAL285=null;
        SLAST IDENTIFIER287=null;
        TreePHP.common_scalar_return common_scalar286 = null;

        TreePHP.fully_qualified_class_name_return fully_qualified_class_name288 = null;


        SLAST INTLITERAL282_tree=null;
        SLAST FLOATLITERAL283_tree=null;
        SLAST STRINGLITERAL284_tree=null;
        SLAST DOUBLELITERRAL285_tree=null;
        SLAST IDENTIFIER287_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1941:3: ( INTLITERAL | FLOATLITERAL | STRINGLITERAL | DOUBLELITERRAL | common_scalar | IDENTIFIER | fully_qualified_class_name )
            int alt93=7;
            switch ( input.LA(1) ) {
            case INTLITERAL:
                {
                alt93=1;
                }
                break;
            case FLOATLITERAL:
                {
                alt93=2;
                }
                break;
            case STRINGLITERAL:
                {
                alt93=3;
                }
                break;
            case DOUBLELITERRAL:
                {
                alt93=4;
                }
                break;
            case 183:
            case 184:
            case 185:
            case 186:
            case 187:
            case 188:
                {
                alt93=5;
                }
                break;
            case IDENTIFIER:
                {
                alt93=6;
                }
                break;
            case DOMAIN_T:
                {
                alt93=7;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 93, 0, input);

                throw nvae;
            }

            switch (alt93) {
                case 1 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1941:7: INTLITERAL
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    INTLITERAL282=(SLAST)match(input,INTLITERAL,FOLLOW_INTLITERAL_in_constant3753); 
                    INTLITERAL282_tree = (SLAST)adaptor.dupNode(INTLITERAL282);

                    adaptor.addChild(root_0, INTLITERAL282_tree);


                        CommonToken token = (CommonToken)INTLITERAL282.token;
                        int startIndex = token.getStartIndex();
                        int endIndex = token.getStopIndex() + 1;
                        retval.scalar = new Scalar(startIndex, endIndex, (INTLITERAL282!=null?INTLITERAL282.getText():null), Scalar.TYPE_INT);
                      

                    }
                    break;
                case 2 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1948:7: FLOATLITERAL
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    FLOATLITERAL283=(SLAST)match(input,FLOATLITERAL,FOLLOW_FLOATLITERAL_in_constant3765); 
                    FLOATLITERAL283_tree = (SLAST)adaptor.dupNode(FLOATLITERAL283);

                    adaptor.addChild(root_0, FLOATLITERAL283_tree);


                    }
                    break;
                case 3 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1949:7: STRINGLITERAL
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    STRINGLITERAL284=(SLAST)match(input,STRINGLITERAL,FOLLOW_STRINGLITERAL_in_constant3773); 
                    STRINGLITERAL284_tree = (SLAST)adaptor.dupNode(STRINGLITERAL284);

                    adaptor.addChild(root_0, STRINGLITERAL284_tree);


                        CommonToken token = (CommonToken)STRINGLITERAL284.token;
                        int startIndex = token.getStartIndex();
                        int endIndex = token.getStopIndex() + 1;
                        retval.scalar = new Scalar(startIndex, endIndex, (STRINGLITERAL284!=null?STRINGLITERAL284.getText():null), Scalar.TYPE_STRING);
                      

                    }
                    break;
                case 4 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1956:7: DOUBLELITERRAL
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    DOUBLELITERRAL285=(SLAST)match(input,DOUBLELITERRAL,FOLLOW_DOUBLELITERRAL_in_constant3785); 
                    DOUBLELITERRAL285_tree = (SLAST)adaptor.dupNode(DOUBLELITERRAL285);

                    adaptor.addChild(root_0, DOUBLELITERRAL285_tree);


                    }
                    break;
                case 5 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1957:7: common_scalar
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_common_scalar_in_constant3793);
                    common_scalar286=common_scalar();

                    state._fsp--;

                    adaptor.addChild(root_0, common_scalar286.getTree());

                          CommonToken token = (CommonToken)(common_scalar286!=null?((SLAST)common_scalar286.tree):null).token;
                          int startIndex = token.getStartIndex();
                          int endIndex = token.getStopIndex() + 1;
                          retval.scalar = new Scalar(startIndex, endIndex, (common_scalar286!=null?(input.getTokenStream().toString(
                      input.getTreeAdaptor().getTokenStartIndex(common_scalar286.start),
                      input.getTreeAdaptor().getTokenStopIndex(common_scalar286.start))):null), Scalar.TYPE_SYSTEM);
                      

                    }
                    break;
                case 6 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1964:7: IDENTIFIER
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    IDENTIFIER287=(SLAST)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_constant3805); 
                    IDENTIFIER287_tree = (SLAST)adaptor.dupNode(IDENTIFIER287);

                    adaptor.addChild(root_0, IDENTIFIER287_tree);


                          CommonToken token = (CommonToken)IDENTIFIER287.token;
                    	    int startIndex = token.getStartIndex();
                    	    int endIndex = token.getStopIndex() + 1;
                    	    retval.scalar = new Scalar(startIndex, endIndex, (IDENTIFIER287!=null?IDENTIFIER287.getText():null), Scalar.TYPE_STRING);
                      

                    }
                    break;
                case 7 :
                    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1971:7: fully_qualified_class_name
                    {
                    root_0 = (SLAST)adaptor.nil();

                    _last = (SLAST)input.LT(1);
                    pushFollow(FOLLOW_fully_qualified_class_name_in_constant3817);
                    fully_qualified_class_name288=fully_qualified_class_name();

                    state._fsp--;

                    adaptor.addChild(root_0, fully_qualified_class_name288.getTree());

                     //   retval.expr = (fully_qualified_class_name288!=null?fully_qualified_class_name288.constant:null);
                          if ((fully_qualified_class_name288!=null?fully_qualified_class_name288.type:null) != null) {
                            retval.expr = (fully_qualified_class_name288!=null?fully_qualified_class_name288.type:null);
                          }
                          else {
                            retval.expr = (fully_qualified_class_name288!=null?fully_qualified_class_name288.constant:null);
                          }
                          System.out.println("expr:" + retval.expr);
                      

                    }
                    break;

            }
            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "constant"

    public static class common_scalar_return extends TreeRuleReturnScope {
        SLAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "common_scalar"
    // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1984:1: common_scalar : ( '__CLASS__' | '__DIR__' | '__FILE__' | '__FUNCTION__' | '__METHOD__' | '__NAMESPACE__' );
    public final TreePHP.common_scalar_return common_scalar() throws RecognitionException {
        TreePHP.common_scalar_return retval = new TreePHP.common_scalar_return();
        retval.start = input.LT(1);

        SLAST root_0 = null;

        SLAST _first_0 = null;
        SLAST _last = null;

        SLAST set289=null;

        SLAST set289_tree=null;

        try {
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:1985:3: ( '__CLASS__' | '__DIR__' | '__FILE__' | '__FUNCTION__' | '__METHOD__' | '__NAMESPACE__' )
            // /home/dustin/ws-soc/org.eclipse.php.core/src/org/eclipse/php/internal/core/compiler/ast/parser/php5/TreePHP.g:
            {
            root_0 = (SLAST)adaptor.nil();

            _last = (SLAST)input.LT(1);
            set289=(SLAST)input.LT(1);
            if ( (input.LA(1)>=183 && input.LA(1)<=188) ) {
                input.consume();

                set289_tree = (SLAST)adaptor.dupNode(set289);

                adaptor.addChild(root_0, set289_tree);

                state.errorRecovery=false;
            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                throw mse;
            }

             

            }

            retval.tree = (SLAST)adaptor.rulePostProcessing(root_0);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "common_scalar"

    // Delegated rules


    protected DFA64 dfa64 = new DFA64(this);
    protected DFA89 dfa89 = new DFA89(this);
    static final String DFA64_eotS =
        "\65\uffff";
    static final String DFA64_eofS =
        "\65\uffff";
    static final String DFA64_minS =
        "\1\15\53\uffff\1\15\10\uffff";
    static final String DFA64_maxS =
        "\1\u008f\53\uffff\1\44\10\uffff";
    static final String DFA64_acceptS =
        "\1\uffff\1\1\1\2\1\3\1\4\1\5\1\6\1\7\1\10\1\11\1\12\1\13\1\14\1"+
        "\15\1\16\1\17\1\20\1\21\1\22\1\23\1\24\1\25\1\26\1\27\1\30\1\31"+
        "\1\32\1\33\1\34\1\35\1\36\1\37\1\40\1\41\1\42\1\43\1\44\1\45\1\46"+
        "\1\47\1\50\1\51\1\52\1\53\1\uffff\1\54\1\55\1\56\1\57\1\60\1\61"+
        "\1\62\1\63";
    static final String DFA64_specialS =
        "\65\uffff}>";
    static final String[] DFA64_transitionS = {
            "\1\55\5\uffff\1\55\1\uffff\1\1\16\uffff\1\56\1\60\1\52\1\51"+
            "\1\50\1\27\20\uffff\1\26\31\uffff\1\5\15\uffff\1\2\1\3\1\4\1"+
            "\6\1\7\1\10\1\11\1\12\1\13\1\14\1\15\1\16\1\17\1\20\1\21\1\22"+
            "\1\23\1\24\1\25\1\30\1\31\1\32\1\33\1\34\1\35\1\36\1\37\1\40"+
            "\1\41\1\42\1\43\1\44\1\45\1\46\1\47\1\62\4\uffff\1\53\1\54\1"+
            "\57\1\61\1\63\1\64",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\1\55\5\uffff\1\55\20\uffff\1\56",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA64_eot = DFA.unpackEncodedString(DFA64_eotS);
    static final short[] DFA64_eof = DFA.unpackEncodedString(DFA64_eofS);
    static final char[] DFA64_min = DFA.unpackEncodedStringToUnsignedChars(DFA64_minS);
    static final char[] DFA64_max = DFA.unpackEncodedStringToUnsignedChars(DFA64_maxS);
    static final short[] DFA64_accept = DFA.unpackEncodedString(DFA64_acceptS);
    static final short[] DFA64_special = DFA.unpackEncodedString(DFA64_specialS);
    static final short[][] DFA64_transition;

    static {
        int numStates = DFA64_transitionS.length;
        DFA64_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA64_transition[i] = DFA.unpackEncodedString(DFA64_transitionS[i]);
        }
    }

    class DFA64 extends DFA {

        public DFA64(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 64;
            this.eot = DFA64_eot;
            this.eof = DFA64_eof;
            this.min = DFA64_min;
            this.max = DFA64_max;
            this.accept = DFA64_accept;
            this.special = DFA64_special;
            this.transition = DFA64_transition;
        }
        public String getDescription() {
            return "1046:1: expression returns [Expression expr] : ( ^( EXPR etop= expression ) | ^( OR_T e1= expression e2= expression ) | ^( XOR_T e1= expression e2= expression ) | ^( AND_T e1= expression e2= expression ) | ^( EQUAL_T e1= expression e2= expression ) | ^( PLUS_EQ e1= expression e2= expression ) | ^( MINUS_EQ e1= expression e2= expression ) | ^( MUL_EQ e1= expression e2= expression ) | ^( DIV_EQ e1= expression e2= expression ) | ^( DOT_EQ e1= expression e2= expression ) | ^( PERCENT_EQ e1= expression e2= expression ) | ^( BIT_AND_EQ e1= expression e2= expression ) | ^( BIT_OR_EQ e1= expression e2= expression ) | ^( POWER_EQ e1= expression e2= expression ) | ^( LMOVE_EQ e1= expression e2= expression ) | ^( RMOVE_EQ e1= expression e2= expression ) | ^( QUESTION_T e1= expression ^( COLON_T e2= expression e3= expression ) ) | ^( LOGICAL_OR_T e1= expression e2= expression ) | ^( LOGICAL_AND_T e1= expression e2= expression ) | ^( BIT_OR_T e1= expression e2= expression ) | ^( POWER_T e1= expression e2= expression ) | ^( REF_T e1= expression e2= expression ) | ^( UNARY_EXPR unary_symbol_list e= expression ) | ^( DOT_T e1= expression e2= expression ) | ^( EQUAL_EQUAL_T e1= expression e2= expression ) | ^( NOT_EQUAL_T e1= expression e2= expression ) | ^( EQUAL_EQUAL_EQUAL_T e1= expression e2= expression ) | ^( NOT_EQUAL_EQUAL_T e1= expression e2= expression ) | ^( LT_T e1= expression e2= expression ) | ^( MT_T e1= expression e2= expression ) | ^( LE_T e1= expression e2= expression ) | ^( ME_T e1= expression e2= expression ) | ^( LSHIFT_T e1= expression e2= expression ) | ^( RSHIFT_T e1= expression e2= expression ) | ^( PLUS_T e1= expression e2= expression ) | ^( MINUS_T e1= expression e2= expression ) | ^( MUL_T e1= expression e2= expression ) | ^( DIV_T e1= expression e2= expression ) | ^( PERCENT_T e1= expression e2= expression ) | ^( CAST_EXPR cast_option e= expression ) | ^( POSTFIX_EXPR e= expression plus_minus ) | ^( PREFIX_EXPR ( plus_minus )+ e= expression ) | ^( INSTANCEOF_T e= expression class_name_reference ) | ( AT_T )? variable | ( AT_T )? scalar | list_decl | ^( ARRAY_DECL ( array_pair_list )? ) | ^( NEW_T class_name_reference ) | ^( CLONE_T variable ) | BACKTRICKLITERAL | ^( PRINT_T e= expression ) );";
        }
    }
    static final String DFA89_eotS =
        "\10\uffff";
    static final String DFA89_eofS =
        "\10\uffff";
    static final String DFA89_minS =
        "\1\21\1\2\2\uffff\2\15\2\uffff";
    static final String DFA89_maxS =
        "\1\53\1\2\2\uffff\2\u0093\2\uffff";
    static final String DFA89_acceptS =
        "\2\uffff\1\3\1\4\2\uffff\1\2\1\1";
    static final String DFA89_specialS =
        "\10\uffff}>";
    static final String[] DFA89_transitionS = {
            "\1\2\30\uffff\1\1\1\3",
            "\1\4",
            "",
            "",
            "\1\6\5\uffff\1\6\1\uffff\1\6\16\uffff\6\6\11\uffff\1\7\6\uffff"+
            "\1\6\31\uffff\1\6\15\uffff\44\6\4\uffff\6\6\3\uffff\1\5",
            "\1\6\5\uffff\1\6\1\uffff\1\6\16\uffff\6\6\11\uffff\1\7\6\uffff"+
            "\1\6\31\uffff\1\6\15\uffff\44\6\4\uffff\6\6\3\uffff\1\5",
            "",
            ""
    };

    static final short[] DFA89_eot = DFA.unpackEncodedString(DFA89_eotS);
    static final short[] DFA89_eof = DFA.unpackEncodedString(DFA89_eofS);
    static final char[] DFA89_min = DFA.unpackEncodedStringToUnsignedChars(DFA89_minS);
    static final char[] DFA89_max = DFA.unpackEncodedStringToUnsignedChars(DFA89_maxS);
    static final short[] DFA89_accept = DFA.unpackEncodedString(DFA89_acceptS);
    static final short[] DFA89_special = DFA.unpackEncodedString(DFA89_specialS);
    static final short[][] DFA89_transition;

    static {
        int numStates = DFA89_transitionS.length;
        DFA89_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA89_transition[i] = DFA.unpackEncodedString(DFA89_transitionS[i]);
        }
    }

    class DFA89 extends DFA {

        public DFA89(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 89;
            this.eot = DFA89_eot;
            this.eof = DFA89_eof;
            this.min = DFA89_min;
            this.max = DFA89_max;
            this.accept = DFA89_accept;
            this.special = DFA89_special;
            this.transition = DFA89_transition;
        }
        public String getDescription() {
            return "1824:1: object_property returns [String str, Expression expr, SimpleReference simpleRef] : ( ^( VAR ( DOLLAR_T )* IDENTIFIER ) | ^( VAR ( DOLLAR_T )* expression ) | ^( INDEX obj= object_property ( expression )? ) | ^( HASH_INDEX obj= object_property ( expression )? ) );";
        }
    }
 

    public static final BitSet FOLLOW_ModuleDeclaration_in_php_source58 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_top_statement_list_in_php_source60 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_top_statement_in_top_statement_list79 = new BitSet(new long[]{0x0104000000004202L,0x0000000000000000L,0x0000004000000000L});
    public static final BitSet FOLLOW_statement_in_top_statement93 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_function_declaration_statement_in_top_statement103 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_class_declaration_statement_in_top_statement113 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_halt_compiler_statement_in_top_statement123 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_inner_statement_in_inner_statement_list150 = new BitSet(new long[]{0x0104000000004202L,0x0000000000000000L,0x0000004000000000L});
    public static final BitSet FOLLOW_statement_in_inner_statement172 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_function_declaration_statement_in_inner_statement182 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_class_declaration_statement_in_inner_statement192 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_halt_compiler_statement_in_inner_statement198 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_166_in_halt_compiler_statement213 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_CLASS_T_in_class_declaration_statement233 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_class_entr_type_in_class_declaration_statement235 = new BitSet(new long[]{0x0008000000000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_class_declaration_statement238 = new BitSet(new long[]{0x0030000000000088L});
    public static final BitSet FOLLOW_EXTENDS_T_in_class_declaration_statement252 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_fully_qualified_class_name_in_class_declaration_statement254 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_IMPLEMENTS_T_in_class_declaration_statement261 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_fully_qualified_class_name_list_in_class_declaration_statement263 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_CLASS_BODY_in_class_declaration_statement276 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_class_statement_list_in_class_declaration_statement278 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_INTERFACE_T_in_class_declaration_statement295 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_IDENTIFIER_in_class_declaration_statement297 = new BitSet(new long[]{0x0010000000000088L});
    public static final BitSet FOLLOW_EXTENDS_T_in_class_declaration_statement301 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_fully_qualified_class_name_list_in_class_declaration_statement303 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_CLASS_BODY_in_class_declaration_statement322 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_class_statement_list_in_class_declaration_statement324 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_set_in_class_entr_type0 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_class_statement_in_class_statement_list373 = new BitSet(new long[]{0x0000000000000302L});
    public static final BitSet FOLLOW_FIELD_DECL_in_class_statement398 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_variable_modifiers_in_class_statement402 = new BitSet(new long[]{0x0000000000002000L,0x0000000000100000L});
    public static final BitSet FOLLOW_static_var_element_in_class_statement404 = new BitSet(new long[]{0x0000000000002008L,0x0000000000100000L});
    public static final BitSet FOLLOW_METHOD_DECL_in_class_statement419 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_modifier_in_class_statement421 = new BitSet(new long[]{0x0408000000000000L});
    public static final BitSet FOLLOW_REF_T_in_class_statement423 = new BitSet(new long[]{0x0008000000000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_class_statement426 = new BitSet(new long[]{0x0000000800001800L});
    public static final BitSet FOLLOW_parameter_list_in_class_statement440 = new BitSet(new long[]{0x0000000800001000L});
    public static final BitSet FOLLOW_block_in_class_statement456 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_EMPTYSTATEMENT_in_class_statement475 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_FIELD_DECL_in_class_statement498 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_CONST_T_in_class_statement502 = new BitSet(new long[]{0x0000000000000000L,0x0000000000100000L});
    public static final BitSet FOLLOW_directive_in_class_statement504 = new BitSet(new long[]{0x0000000000000008L,0x0000000000100000L});
    public static final BitSet FOLLOW_METHOD_DECL_in_function_declaration_statement530 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_REF_T_in_function_declaration_statement532 = new BitSet(new long[]{0x0008000000000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_function_declaration_statement535 = new BitSet(new long[]{0x0000000000001800L});
    public static final BitSet FOLLOW_parameter_list_in_function_declaration_statement544 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_block_in_function_declaration_statement557 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_BLOCK_in_block592 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_inner_statement_list_in_block594 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_STATEMENT_in_statement623 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_topStatement_in_statement625 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_block_in_topStatement656 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_if_stat_in_topStatement667 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_WHILE_T_in_topStatement678 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_CONDITION_in_topStatement681 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_topStatement685 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_while_statement_in_topStatement688 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_DO_T_in_topStatement703 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_CONDITION_in_topStatement706 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_topStatement710 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_statement_in_topStatement713 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_FOR_T_in_topStatement725 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_list_in_topStatement729 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_CONDITION_in_topStatement733 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_list_in_topStatement737 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_ITERATE_in_topStatement742 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_list_in_topStatement746 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_for_statement_in_topStatement752 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_SWITCH_T_in_topStatement764 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_CONDITION_in_topStatement767 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_topStatement771 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_switch_case_list_in_topStatement774 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_BREAK_T_in_topStatement786 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_topStatement788 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_CONTINUE_T_in_topStatement801 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_topStatement805 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_RETURN_T_in_topStatement818 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_topStatement822 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_GLOBAL_T_in_topStatement835 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_variable_list_in_topStatement837 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_STATIC_T_in_topStatement849 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_static_var_list_in_topStatement851 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_ECHO_T_in_topStatement863 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_list_in_topStatement865 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_EMPTYSTATEMENT_in_topStatement877 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_SEMI_COLON_in_topStatement879 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_expression_in_topStatement890 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_FOREACH_T_in_topStatement901 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_AS_T_in_topStatement904 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_topStatement908 = new BitSet(new long[]{0x0400000000082000L});
    public static final BitSet FOLLOW_foreach_variable_in_topStatement912 = new BitSet(new long[]{0x0400000000082008L});
    public static final BitSet FOLLOW_foreach_variable_in_topStatement916 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_foreach_statement_in_topStatement920 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_DECLARE_T_in_topStatement933 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_directive_in_topStatement935 = new BitSet(new long[]{0x0104000000004208L,0x0000000000000000L,0x0000004000000000L});
    public static final BitSet FOLLOW_declare_statement_in_topStatement937 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_TRY_T_in_topStatement950 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_block_in_topStatement952 = new BitSet(new long[]{0x0000000000000000L,0x0000000020000000L});
    public static final BitSet FOLLOW_catch_branch_list_in_topStatement954 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_THROW_T_in_topStatement966 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_topStatement970 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_USE_T_in_topStatement982 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_use_filename_in_topStatement984 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_INCLUDE_T_in_topStatement992 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_topStatement996 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_INCLUDE_ONCE_T_in_topStatement1009 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_topStatement1013 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_REQUIRE_T_in_topStatement1026 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_topStatement1030 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_REQUIRE_ONCE_T_in_topStatement1043 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_topStatement1047 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_REF_T_in_foreach_variable1078 = new BitSet(new long[]{0x0400000000082000L});
    public static final BitSet FOLLOW_variable_in_foreach_variable1081 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_STRINGLITERAL_in_use_filename1102 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_variable_in_variable_list1130 = new BitSet(new long[]{0x0400000000082002L});
    public static final BitSet FOLLOW_fully_qualified_class_name_in_fully_qualified_class_name_list1150 = new BitSet(new long[]{0x0008000000000002L,0x0000000000040000L});
    public static final BitSet FOLLOW_DOMAIN_T_in_fully_qualified_class_name1173 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_fully_qualified_class_name_in_fully_qualified_class_name1177 = new BitSet(new long[]{0x0008000000000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_fully_qualified_class_name1179 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_DOMAIN_T_in_fully_qualified_class_name1182 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IDENTIFIER_in_fully_qualified_class_name1193 = new BitSet(new long[]{0x0000000000000002L,0x0000000000040000L});
    public static final BitSet FOLLOW_DOMAIN_T_in_fully_qualified_class_name1195 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_static_var_element_in_static_var_list1229 = new BitSet(new long[]{0x0000000000002002L,0x0000000000100000L});
    public static final BitSet FOLLOW_pure_variable_in_static_var_element1247 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_EQUAL_T_in_static_var_element1258 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_pure_variable_in_static_var_element1260 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_scalar_in_static_var_element1262 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_IF_T_in_if_stat1296 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_CONDITION_in_if_stat1300 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_if_stat1302 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_inner_statement_list_in_if_stat1318 = new BitSet(new long[]{0x0000000000000008L,0x0000000000C00000L});
    public static final BitSet FOLLOW_else_if_stat_in_if_stat1327 = new BitSet(new long[]{0x0000000000000008L,0x0000000000C00000L});
    public static final BitSet FOLLOW_ELSE_T_in_if_stat1332 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_statement_in_if_stat1334 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_ELSEIF_T_in_else_if_stat1364 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_CONDITION_in_else_if_stat1367 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_else_if_stat1369 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_inner_statement_list_in_else_if_stat1372 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_case_list_in_switch_case_list1406 = new BitSet(new long[]{0x0000000000000002L,0x0000000018000000L});
    public static final BitSet FOLLOW_CASE_T_in_case_list1425 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_case_list1429 = new BitSet(new long[]{0x0104000000004208L,0x0000000000000000L,0x0000004000000000L});
    public static final BitSet FOLLOW_inner_statement_list_in_case_list1431 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_DEFAULT_T_in_case_list1446 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_inner_statement_list_in_case_list1448 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_catch_branch_in_catch_branch_list1482 = new BitSet(new long[]{0x0000000000000002L,0x0000000020000000L});
    public static final BitSet FOLLOW_CATCH_T_in_catch_branch1504 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_fully_qualified_class_name_in_catch_branch1506 = new BitSet(new long[]{0x0400000000082000L});
    public static final BitSet FOLLOW_variable_in_catch_branch1508 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_block_in_catch_branch1510 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_inner_statement_list_in_for_statement1531 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_inner_statement_list_in_while_statement1554 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_inner_statement_list_in_foreach_statement1579 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_inner_statement_list_in_declare_statement1607 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_parameter_in_parameter_list1642 = new BitSet(new long[]{0x0000000000000802L});
    public static final BitSet FOLLOW_PARAMETER_in_parameter1663 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_TYPE_in_parameter1667 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_parameter_type_in_parameter1669 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_CONST_T_in_parameter1674 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_pure_variable_in_parameter1677 = new BitSet(new long[]{0x0000001000000008L});
    public static final BitSet FOLLOW_scalar_in_parameter1679 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_fully_qualified_class_name_in_parameter_type1704 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_cast_option_in_parameter_type1714 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_169_in_variable_modifiers1732 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_modifier_in_variable_modifiers1738 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_170_in_modifier1766 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000010L,0x00001D8000000000L});
    public static final BitSet FOLLOW_171_in_modifier1774 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000010L,0x00001D8000000000L});
    public static final BitSet FOLLOW_172_in_modifier1782 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000010L,0x00001D8000000000L});
    public static final BitSet FOLLOW_STATIC_T_in_modifier1790 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000010L,0x00001D8000000000L});
    public static final BitSet FOLLOW_167_in_modifier1799 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000010L,0x00001D8000000000L});
    public static final BitSet FOLLOW_168_in_modifier1808 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000010L,0x00001D8000000000L});
    public static final BitSet FOLLOW_EQUAL_T_in_directive1840 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_IDENTIFIER_in_directive1842 = new BitSet(new long[]{0x040003F000282000L,0xFFFFFFFC00100000L,0x000000000000FC3FL});
    public static final BitSet FOLLOW_expression_in_directive1844 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_expression_in_expr_list1881 = new BitSet(new long[]{0x040003F000282002L,0xFFFFFFFC00100000L,0x000000000000FC3FL});
    public static final BitSet FOLLOW_EXPR_in_expression1915 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1919 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_OR_T_in_expression1931 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1935 = new BitSet(new long[]{0x040003F000282000L,0xFFFFFFFC00100000L,0x000000000000FC3FL});
    public static final BitSet FOLLOW_expression_in_expression1939 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_XOR_T_in_expression1951 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1955 = new BitSet(new long[]{0x040003F000282000L,0xFFFFFFFC00100000L,0x000000000000FC3FL});
    public static final BitSet FOLLOW_expression_in_expression1959 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_AND_T_in_expression1971 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1975 = new BitSet(new long[]{0x040003F000282000L,0xFFFFFFFC00100000L,0x000000000000FC3FL});
    public static final BitSet FOLLOW_expression_in_expression1979 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_EQUAL_T_in_expression1991 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1995 = new BitSet(new long[]{0x040003F000282000L,0xFFFFFFFC00100000L,0x000000000000FC3FL});
    public static final BitSet FOLLOW_expression_in_expression1999 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_PLUS_EQ_in_expression2012 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2016 = new BitSet(new long[]{0x040003F000282000L,0xFFFFFFFC00100000L,0x000000000000FC3FL});
    public static final BitSet FOLLOW_expression_in_expression2020 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_MINUS_EQ_in_expression2032 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2036 = new BitSet(new long[]{0x040003F000282000L,0xFFFFFFFC00100000L,0x000000000000FC3FL});
    public static final BitSet FOLLOW_expression_in_expression2040 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_MUL_EQ_in_expression2052 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2056 = new BitSet(new long[]{0x040003F000282000L,0xFFFFFFFC00100000L,0x000000000000FC3FL});
    public static final BitSet FOLLOW_expression_in_expression2060 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_DIV_EQ_in_expression2072 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2076 = new BitSet(new long[]{0x040003F000282000L,0xFFFFFFFC00100000L,0x000000000000FC3FL});
    public static final BitSet FOLLOW_expression_in_expression2080 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_DOT_EQ_in_expression2092 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2096 = new BitSet(new long[]{0x040003F000282000L,0xFFFFFFFC00100000L,0x000000000000FC3FL});
    public static final BitSet FOLLOW_expression_in_expression2100 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_PERCENT_EQ_in_expression2112 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2116 = new BitSet(new long[]{0x040003F000282000L,0xFFFFFFFC00100000L,0x000000000000FC3FL});
    public static final BitSet FOLLOW_expression_in_expression2120 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_BIT_AND_EQ_in_expression2132 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2136 = new BitSet(new long[]{0x040003F000282000L,0xFFFFFFFC00100000L,0x000000000000FC3FL});
    public static final BitSet FOLLOW_expression_in_expression2140 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_BIT_OR_EQ_in_expression2152 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2156 = new BitSet(new long[]{0x040003F000282000L,0xFFFFFFFC00100000L,0x000000000000FC3FL});
    public static final BitSet FOLLOW_expression_in_expression2160 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_POWER_EQ_in_expression2172 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2176 = new BitSet(new long[]{0x040003F000282000L,0xFFFFFFFC00100000L,0x000000000000FC3FL});
    public static final BitSet FOLLOW_expression_in_expression2180 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_LMOVE_EQ_in_expression2192 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2196 = new BitSet(new long[]{0x040003F000282000L,0xFFFFFFFC00100000L,0x000000000000FC3FL});
    public static final BitSet FOLLOW_expression_in_expression2200 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_RMOVE_EQ_in_expression2212 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2216 = new BitSet(new long[]{0x040003F000282000L,0xFFFFFFFC00100000L,0x000000000000FC3FL});
    public static final BitSet FOLLOW_expression_in_expression2220 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_QUESTION_T_in_expression2232 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2236 = new BitSet(new long[]{0x0000000000000000L,0x0000000001000000L});
    public static final BitSet FOLLOW_COLON_T_in_expression2239 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2243 = new BitSet(new long[]{0x040003F000282000L,0xFFFFFFFC00100000L,0x000000000000FC3FL});
    public static final BitSet FOLLOW_expression_in_expression2247 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_LOGICAL_OR_T_in_expression2262 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2266 = new BitSet(new long[]{0x040003F000282000L,0xFFFFFFFC00100000L,0x000000000000FC3FL});
    public static final BitSet FOLLOW_expression_in_expression2270 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_LOGICAL_AND_T_in_expression2282 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2286 = new BitSet(new long[]{0x040003F000282000L,0xFFFFFFFC00100000L,0x000000000000FC3FL});
    public static final BitSet FOLLOW_expression_in_expression2290 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_BIT_OR_T_in_expression2302 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2306 = new BitSet(new long[]{0x040003F000282000L,0xFFFFFFFC00100000L,0x000000000000FC3FL});
    public static final BitSet FOLLOW_expression_in_expression2310 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_POWER_T_in_expression2322 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2326 = new BitSet(new long[]{0x040003F000282000L,0xFFFFFFFC00100000L,0x000000000000FC3FL});
    public static final BitSet FOLLOW_expression_in_expression2330 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_REF_T_in_expression2342 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2346 = new BitSet(new long[]{0x040003F000282000L,0xFFFFFFFC00100000L,0x000000000000FC3FL});
    public static final BitSet FOLLOW_expression_in_expression2350 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_UNARY_EXPR_in_expression2362 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_unary_symbol_list_in_expression2364 = new BitSet(new long[]{0x040003F000282000L,0xFFFFFFFC00100000L,0x000000000000FC3FL});
    public static final BitSet FOLLOW_expression_in_expression2368 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_DOT_T_in_expression2380 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2384 = new BitSet(new long[]{0x040003F000282000L,0xFFFFFFFC00100000L,0x000000000000FC3FL});
    public static final BitSet FOLLOW_expression_in_expression2388 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_EQUAL_EQUAL_T_in_expression2400 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2404 = new BitSet(new long[]{0x040003F000282000L,0xFFFFFFFC00100000L,0x000000000000FC3FL});
    public static final BitSet FOLLOW_expression_in_expression2408 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_NOT_EQUAL_T_in_expression2420 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2424 = new BitSet(new long[]{0x040003F000282000L,0xFFFFFFFC00100000L,0x000000000000FC3FL});
    public static final BitSet FOLLOW_expression_in_expression2428 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_EQUAL_EQUAL_EQUAL_T_in_expression2440 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2444 = new BitSet(new long[]{0x040003F000282000L,0xFFFFFFFC00100000L,0x000000000000FC3FL});
    public static final BitSet FOLLOW_expression_in_expression2448 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_NOT_EQUAL_EQUAL_T_in_expression2460 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2464 = new BitSet(new long[]{0x040003F000282000L,0xFFFFFFFC00100000L,0x000000000000FC3FL});
    public static final BitSet FOLLOW_expression_in_expression2468 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_LT_T_in_expression2480 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2484 = new BitSet(new long[]{0x040003F000282000L,0xFFFFFFFC00100000L,0x000000000000FC3FL});
    public static final BitSet FOLLOW_expression_in_expression2488 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_MT_T_in_expression2500 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2504 = new BitSet(new long[]{0x040003F000282000L,0xFFFFFFFC00100000L,0x000000000000FC3FL});
    public static final BitSet FOLLOW_expression_in_expression2508 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_LE_T_in_expression2520 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2524 = new BitSet(new long[]{0x040003F000282000L,0xFFFFFFFC00100000L,0x000000000000FC3FL});
    public static final BitSet FOLLOW_expression_in_expression2528 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_ME_T_in_expression2540 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2544 = new BitSet(new long[]{0x040003F000282000L,0xFFFFFFFC00100000L,0x000000000000FC3FL});
    public static final BitSet FOLLOW_expression_in_expression2548 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_LSHIFT_T_in_expression2560 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2564 = new BitSet(new long[]{0x040003F000282000L,0xFFFFFFFC00100000L,0x000000000000FC3FL});
    public static final BitSet FOLLOW_expression_in_expression2568 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_RSHIFT_T_in_expression2580 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2584 = new BitSet(new long[]{0x040003F000282000L,0xFFFFFFFC00100000L,0x000000000000FC3FL});
    public static final BitSet FOLLOW_expression_in_expression2588 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_PLUS_T_in_expression2600 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2604 = new BitSet(new long[]{0x040003F000282000L,0xFFFFFFFC00100000L,0x000000000000FC3FL});
    public static final BitSet FOLLOW_expression_in_expression2608 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_MINUS_T_in_expression2620 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2624 = new BitSet(new long[]{0x040003F000282000L,0xFFFFFFFC00100000L,0x000000000000FC3FL});
    public static final BitSet FOLLOW_expression_in_expression2628 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_MUL_T_in_expression2640 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2644 = new BitSet(new long[]{0x040003F000282000L,0xFFFFFFFC00100000L,0x000000000000FC3FL});
    public static final BitSet FOLLOW_expression_in_expression2648 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_DIV_T_in_expression2660 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2664 = new BitSet(new long[]{0x040003F000282000L,0xFFFFFFFC00100000L,0x000000000000FC3FL});
    public static final BitSet FOLLOW_expression_in_expression2668 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_PERCENT_T_in_expression2680 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2684 = new BitSet(new long[]{0x040003F000282000L,0xFFFFFFFC00100000L,0x000000000000FC3FL});
    public static final BitSet FOLLOW_expression_in_expression2688 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_CAST_EXPR_in_expression2700 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_cast_option_in_expression2702 = new BitSet(new long[]{0x040003F000282000L,0xFFFFFFFC00100000L,0x000000000000FC3FL});
    public static final BitSet FOLLOW_expression_in_expression2706 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_POSTFIX_EXPR_in_expression2730 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2734 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000000300L});
    public static final BitSet FOLLOW_plus_minus_in_expression2736 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_PREFIX_EXPR_in_expression2748 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_plus_minus_in_expression2750 = new BitSet(new long[]{0x040003F000282000L,0xFFFFFFFC00100000L,0x000000000000FF3FL});
    public static final BitSet FOLLOW_expression_in_expression2755 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_INSTANCEOF_T_in_expression2767 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2771 = new BitSet(new long[]{0x0008000000082000L,0x0000000000040000L});
    public static final BitSet FOLLOW_class_name_reference_in_expression2773 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_AT_T_in_expression2784 = new BitSet(new long[]{0x0400000000082000L});
    public static final BitSet FOLLOW_variable_in_expression2787 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_AT_T_in_expression2797 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_scalar_in_expression2800 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_list_decl_in_expression2810 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ARRAY_DECL_in_expression2821 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_array_pair_list_in_expression2823 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_NEW_T_in_expression2836 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_class_name_reference_in_expression2838 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_CLONE_T_in_expression2853 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_variable_in_expression2855 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_BACKTRICKLITERAL_in_expression2869 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_PRINT_T_in_expression2876 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression2880 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_unary_symbol_in_unary_symbol_list2914 = new BitSet(new long[]{0x0400000000000002L,0x0000000000000000L,0x00000000000000C3L});
    public static final BitSet FOLLOW_PLUS_T_in_unary_symbol2934 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_MINUS_T_in_unary_symbol2943 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_REF_T_in_unary_symbol2951 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_TILDA_T_in_unary_symbol2961 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_EXC_NOT_T_in_unary_symbol2969 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_plus_minus0 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_173_in_cast_option3007 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_174_in_cast_option3018 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_175_in_cast_option3026 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_176_in_cast_option3038 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_177_in_cast_option3048 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_182_in_cast_option3057 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_181_in_cast_option3067 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_178_in_cast_option3076 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_179_in_cast_option3087 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_180_in_cast_option3096 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_CLONE_T_in_cast_option3106 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_METHOD_DECL_in_lambda_function_declaration3125 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_REF_T_in_lambda_function_declaration3127 = new BitSet(new long[]{0x0000000000001800L,0x0000000000001000L});
    public static final BitSet FOLLOW_parameter_list_in_lambda_function_declaration3130 = new BitSet(new long[]{0x0000000000001000L,0x0000000000001000L});
    public static final BitSet FOLLOW_USE_T_in_lambda_function_declaration3135 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_list_in_lambda_function_declaration3137 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_block_in_lambda_function_declaration3149 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_dynamic_name_reference_in_class_name_reference3182 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_fully_qualified_class_name_in_class_name_reference3193 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_base_variable_with_function_calls_in_dynamic_name_reference3216 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_CALL_in_dynamic_name_reference3228 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_dynamic_name_reference_in_dynamic_name_reference3232 = new BitSet(new long[]{0x00000C0000020000L});
    public static final BitSet FOLLOW_object_property_in_dynamic_name_reference3236 = new BitSet(new long[]{0x0000000040000008L});
    public static final BitSet FOLLOW_ctor_arguments_in_dynamic_name_reference3238 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_LIST_T_in_list_decl3262 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_assignment_list_in_list_decl3264 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_assignment_element_in_assignment_list3296 = new BitSet(new long[]{0x0400000000082002L,0x0000000000000000L,0x0000000000001000L});
    public static final BitSet FOLLOW_variable_in_assignment_element3314 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_list_decl_in_assignment_element3324 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_array_pair_element_in_array_pair_list3356 = new BitSet(new long[]{0x040003F000282002L,0xFFFFFFFC00100100L,0x000000000000FC3FL});
    public static final BitSet FOLLOW_ARROW_T_in_array_pair_element3377 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_array_pair_element3381 = new BitSet(new long[]{0x040003F000282000L,0xFFFFFFFC00100000L,0x000000000000FC3FL});
    public static final BitSet FOLLOW_expression_in_array_pair_element3385 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_expression_in_array_pair_element3398 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_variable_temp_in_variable3433 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_base_variable_with_function_calls_in_variable_temp3457 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_CALL_in_variable_temp3469 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_variable_temp_in_variable_temp3473 = new BitSet(new long[]{0x00000C0000020000L});
    public static final BitSet FOLLOW_object_property_in_variable_temp3477 = new BitSet(new long[]{0x0000000040000008L});
    public static final BitSet FOLLOW_ctor_arguments_in_variable_temp3479 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_VAR_DECL_in_base_variable_with_function_calls3505 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_fully_qualified_class_name_in_base_variable_with_function_calls3507 = new BitSet(new long[]{0x00000C0000020000L});
    public static final BitSet FOLLOW_object_property_in_base_variable_with_function_calls3512 = new BitSet(new long[]{0x0000000040000008L});
    public static final BitSet FOLLOW_ctor_arguments_in_base_variable_with_function_calls3514 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_CALL_in_base_variable_with_function_calls3535 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_fully_qualified_class_name_in_base_variable_with_function_calls3537 = new BitSet(new long[]{0x0000000040000000L});
    public static final BitSet FOLLOW_ctor_arguments_in_base_variable_with_function_calls3539 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_VAR_in_object_property3573 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_DOLLAR_T_in_object_property3575 = new BitSet(new long[]{0x0008000000000000L,0x0000000000000000L,0x0000000000080000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_object_property3578 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_VAR_in_object_property3592 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_DOLLAR_T_in_object_property3594 = new BitSet(new long[]{0x040003F000282000L,0xFFFFFFFC00100000L,0x000000000008FC3FL});
    public static final BitSet FOLLOW_expression_in_object_property3597 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_INDEX_in_object_property3609 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_object_property_in_object_property3613 = new BitSet(new long[]{0x040003F000282008L,0xFFFFFFFC00100000L,0x000000000000FC3FL});
    public static final BitSet FOLLOW_expression_in_object_property3615 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_HASH_INDEX_in_object_property3628 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_object_property_in_object_property3632 = new BitSet(new long[]{0x040003F000282008L,0xFFFFFFFC00100000L,0x000000000000FC3FL});
    public static final BitSet FOLLOW_expression_in_object_property3634 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_ARGU_in_ctor_arguments3664 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_list_in_ctor_arguments3666 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_VAR_DECL_in_pure_variable3688 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_REF_T_in_pure_variable3690 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000080000L});
    public static final BitSet FOLLOW_DOLLAR_T_in_pure_variable3693 = new BitSet(new long[]{0x0008000000000000L,0x0000000000000000L,0x0000000000080000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_pure_variable3696 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_SCALAR_in_scalar3725 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_constant_in_scalar3727 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_INTLITERAL_in_constant3753 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_FLOATLITERAL_in_constant3765 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_STRINGLITERAL_in_constant3773 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_DOUBLELITERRAL_in_constant3785 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_common_scalar_in_constant3793 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IDENTIFIER_in_constant3805 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_fully_qualified_class_name_in_constant3817 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_common_scalar0 = new BitSet(new long[]{0x0000000000000002L});

}